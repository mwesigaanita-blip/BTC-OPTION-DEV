> ## Documentation Index
> Fetch the complete documentation index at: https://docs.deribit.com/llms.txt
> Use this file to discover all available pages before exploring further.

<AgentInstructions>

## Submitting Feedback

If you encounter incorrect, outdated, or confusing documentation on this page, submit feedback:

POST https://docs.deribit.com/feedback

```json
{
  "path": "/api-reference/market-data/public-get_last_trades_by_currency",
  "feedback": "Description of the issue"
}
```

Only submit feedback when you have something specific and actionable to report.

</AgentInstructions>

# public/get_last_trades_by_currency

> Retrieves the latest trades that have occurred for instruments in a specific currency. Returns trade details including price, amount, direction, timestamp, and trade ID for all instruments in the currency.

Results can be filtered by instrument kind and trade ID range or timestamp range. Use the `count` parameter to limit the number of trades returned, and `sorting` to control the order (ascending or descending by trade ID).

[Try in API console](https://test.deribit.com/api_console?method=%2Fpublic%2Fget_last_trades_by_currency)





## OpenAPI

````yaml /specifications/deribit_openapi.json get /public/get_last_trades_by_currency
openapi: 3.0.0
info:
  title: Deribit API
  version: 2.1.1
servers:
  - url: https://test.deribit.com/api/v2
security: []
tags:
  - name: WebSocket Only
    description: Can only be used over websockets.
  - name: Public
    description: Public methods can be used without authentication.
  - name: Private
    description: >-
      <p>Private methods require authentication. All requests must include a
      valid OAuth2 token.</p>

      <p>A token can be requested using the <a
      href="#public-auth">/public/auth</a> method.</p>

      <p>When using the websockets protocol, the token must be included as a
      parameter <code>access_token</code> in the message. When using REST (HTTP
      GET), the token may also be passed in the <code>Authorization</code>
      header.</p>
  - name: Authentication
  - name: Session Management
  - name: Subscription Management
    description: >-
      Subscription works as [notifications](#notifications), so users will
      automatically (after subscribing) receive messages from the server.
      Overview for each channel response format is described in
      [subscriptions](#subscriptions) section.
  - name: Account Management
  - name: Trading
  - name: Market Data
  - name: Wallet
  - name: Chat
paths:
  /public/get_last_trades_by_currency:
    get:
      tags:
        - Market Data
        - Public
      description: >+
        Retrieves the latest trades that have occurred for instruments in a
        specific currency. Returns trade details including price, amount,
        direction, timestamp, and trade ID for all instruments in the currency.


        Results can be filtered by instrument kind and trade ID range or
        timestamp range. Use the `count` parameter to limit the number of trades
        returned, and `sorting` to control the order (ascending or descending by
        trade ID).


        [Try in API
        console](https://test.deribit.com/api_console?method=%2Fpublic%2Fget_last_trades_by_currency)

      parameters:
        - name: currency
          required: true
          in: query
          schema:
            $ref: '#/components/schemas/currency'
          description: The currency symbol
        - name: kind
          required: false
          in: query
          schema:
            $ref: '#/components/schemas/kind_with_combo_all'
          description: >-
            Instrument kind, `"combo"` for any combo or `"any"` for all. If not
            provided instruments of all kinds are considered
        - name: start_id
          required: false
          in: query
          schema:
            $ref: '#/components/schemas/trade_id'
          description: >-
            The ID of the first trade to be returned. Number for BTC trades, or
            hyphen name in ex. `"ETH-15"` # `"ETH_USDC-16"`
        - name: end_id
          required: false
          in: query
          schema:
            $ref: '#/components/schemas/trade_id'
          description: >-
            The ID of the last trade to be returned. Number for BTC trades, or
            hyphen name in ex. `"ETH-15"` # `"ETH_USDC-16"`
        - name: start_timestamp
          required: false
          in: query
          schema:
            $ref: '#/components/schemas/timestamp'
          description: >-
            The earliest timestamp to return result from (milliseconds since the
            UNIX epoch). When param is provided trades are returned from the
            earliest
        - name: end_timestamp
          required: false
          in: query
          schema:
            $ref: '#/components/schemas/timestamp'
          description: >-
            The most recent timestamp to return result from (milliseconds since
            the UNIX epoch). Only one of params: start_timestamp, end_timestamp
            is truly required
        - name: count
          required: false
          in: query
          schema:
            type: integer
            maximum: 1000
            minimum: 1
          description: Number of requested items, default - `10`, maximum - `1000`
        - name: sorting
          required: false
          in: query
          schema:
            $ref: '#/components/schemas/sorting'
          description: >-
            Direction of results sorting (`default` value means no sorting,
            results will be returned in order in which they left the database)
      requestBody:
        content:
          application/json:
            examples:
              request:
                value:
                  jsonrpc: '2.0'
                  id: 9290
                  method: public/get_last_trades_by_currency
                  params:
                    currency: BTC
                    count: 3
                description: JSON-RPC Request Example
        description: JSON-RPC request body
      responses:
        '200':
          $ref: '#/components/responses/PublicTradesHistoryResponse'
components:
  schemas:
    currency:
      enum:
        - BTC
        - ETH
        - USDC
        - USDT
        - EURR
      type: string
      description: Currency, i.e `"BTC"`, `"ETH"`, `"USDC"`
    kind_with_combo_all:
      enum:
        - future
        - option
        - spot
        - future_combo
        - option_combo
        - combo
        - any
      type: string
      description: >-
        Instrument kind: `"future"`, `"option"`, `"spot"`, `"future_combo"`,
        `"option_combo"`, `"combo"` for any combo or `"any"` for all
    trade_id:
      type: string
      description: Unique (per currency) trade identifier
    timestamp:
      example: 1536569522277
      type: integer
      description: The timestamp (milliseconds since the Unix epoch)
    sorting:
      enum:
        - asc
        - desc
        - default
      type: string
    PublicTradesHistoryResponse:
      properties:
        jsonrpc:
          type: string
          enum:
            - '2.0'
          description: The JSON-RPC version (2.0)
        id:
          type: integer
          description: The id that was sent in the request
        result:
          type: object
          properties:
            trades:
              type: array
              items:
                $ref: '#/components/schemas/public_trade'
            has_more:
              type: boolean
          required:
            - trades
            - has_more
      required:
        - jsonrpc
        - result
      type: object
    public_trade:
      properties:
        trade_id:
          $ref: '#/components/schemas/trade_id'
        trade_seq:
          $ref: '#/components/schemas/trade_seq'
        instrument_name:
          $ref: '#/components/schemas/instrument_name'
        timestamp:
          $ref: '#/components/schemas/trade_timestamp'
        direction:
          $ref: '#/components/schemas/direction'
          description: Trade direction of the taker
        tick_direction:
          $ref: '#/components/schemas/tick_direction'
        index_price:
          type: number
          description: Index Price at the moment of trade
        price:
          $ref: '#/components/schemas/price'
          description: The price of the trade
        amount:
          type: number
          description: >-
            Trade amount. For perpetual and inverse futures the amount is in USD
            units. For options and linear futures it is the underlying base
            currency coin.
        contracts:
          type: number
          description: >-
            Trade size in contract units (optional, may be absent in historical
            trades)
        iv:
          type: number
          description: Option implied volatility for the price (Option only)
        liquidation:
          type: string
          enum:
            - M
            - T
            - MT
          description: >-
            Optional field (only for trades caused by liquidation): `"M"` when
            maker side of trade was under liquidation, `"T"` when taker side was
            under liquidation, `"MT"` when both sides of trade were under
            liquidation
        mark_price:
          type: number
          description: Mark Price at the moment of trade
        block_trade_id:
          $ref: '#/components/schemas/block_trade_id_in_result'
        block_trade_leg_count:
          $ref: '#/components/schemas/block_trade_leg_count'
        combo_id:
          type: string
          description: >-
            Optional field containing combo instrument name if the trade is a
            combo trade
        combo_trade_id:
          type: number
          description: >-
            Optional field containing combo trade identifier if the trade is a
            combo trade
        block_rfq_id:
          type: integer
          description: ID of the Block RFQ - when trade was part of the Block RFQ
      required:
        - trade_id
        - instrument_name
        - timestamp
        - trade_seq
        - direction
        - tick_direction
        - index_price
        - price
        - amount
        - mark_price
      type: object
    trade_seq:
      type: integer
      description: The sequence number of the trade within instrument
    instrument_name:
      example: BTC-PERPETUAL
      type: string
      description: Unique instrument identifier
    trade_timestamp:
      example: 1517329113791
      type: integer
      description: The timestamp of the trade (milliseconds since the UNIX epoch)
    direction:
      enum:
        - buy
        - sell
      type: string
      description: 'Direction: `buy`, or `sell`'
    tick_direction:
      enum:
        - 0
        - 1
        - 2
        - 3
      type: integer
      description: >-
        Direction of the "tick" (`0` = Plus Tick, `1` = Zero-Plus Tick, `2` =
        Minus Tick, `3` = Zero-Minus Tick).
    price:
      type: number
      description: Price in base currency
    block_trade_id_in_result:
      example: '154'
      type: string
      description: Block trade id - when trade was part of a block trade
    block_trade_leg_count:
      example: 3
      type: integer
      description: Block trade leg count - when trade was part of a block trade
  responses:
    PublicTradesHistoryResponse:
      content:
        application/json:
          schema:
            $ref: '#/components/schemas/PublicTradesHistoryResponse'
          examples:
            response:
              value:
                jsonrpc: '2.0'
                id: 1469
                result:
                  trades:
                    - trade_seq: 467
                      trade_id: '415305279'
                      timestamp: 1770984454552
                      tick_direction: 2
                      price: 0.0525
                      mark_price: 0.05253883
                      iv: 45.91
                      instrument_name: BTC-24APR26-72000-C
                      index_price: 66930.31
                      direction: buy
                      amount: 3
                      contracts: 3
                  has_more: true
              description: Response example
      description: Success response

````

 
  
  

<AgentInstructions>

## Submitting Feedback

If you encounter incorrect, outdated, or confusing documentation on this page, submit feedback:

POST https://docs.deribit.com/feedback

```json
{
  "path": "/api-reference/market-data/public-get_last_trades_by_currency",
  "feedback": "Description of the issue"
}
```

Only submit feedback when you have something specific and actionable to report.

</AgentInstructions>

# public/get_last_trades_by_currency

> Retrieves the latest trades that have occurred for instruments in a specific currency. Returns trade details including price, amount, direction, timestamp, and trade ID for all instruments in the currency.

Results can be filtered by instrument kind and trade ID range or timestamp range. Use the `count` parameter to limit the number of trades returned, and `sorting` to control the order (ascending or descending by trade ID).

[Try in API console](https://test.deribit.com/api_console?method=%2Fpublic%2Fget_last_trades_by_currency)





## OpenAPI

````yaml /specifications/deribit_openapi.json get /public/get_last_trades_by_currency
openapi: 3.0.0
info:
  title: Deribit API
  version: 2.1.1
servers:
  - url: https://test.deribit.com/api/v2
security: []
tags:
  - name: WebSocket Only
    description: Can only be used over websockets.
  - name: Public
    description: Public methods can be used without authentication.
  - name: Private
    description: >-
      <p>Private methods require authentication. All requests must include a
      valid OAuth2 token.</p>

      <p>A token can be requested using the <a
      href="#public-auth">/public/auth</a> method.</p>

      <p>When using the websockets protocol, the token must be included as a
      parameter <code>access_token</code> in the message. When using REST (HTTP
      GET), the token may also be passed in the <code>Authorization</code>
      header.</p>
  - name: Authentication
  - name: Session Management
  - name: Subscription Management
    description: >-
      Subscription works as [notifications](#notifications), so users will
      automatically (after subscribing) receive messages from the server.
      Overview for each channel response format is described in
      [subscriptions](#subscriptions) section.
  - name: Account Management
  - name: Trading
  - name: Market Data
  - name: Wallet
  - name: Chat
paths:
  /public/get_last_trades_by_currency:
    get:
      tags:
        - Market Data
        - Public
      description: >+
        Retrieves the latest trades that have occurred for instruments in a
        specific currency. Returns trade details including price, amount,
        direction, timestamp, and trade ID for all instruments in the currency.


        Results can be filtered by instrument kind and trade ID range or
        timestamp range. Use the `count` parameter to limit the number of trades
        returned, and `sorting` to control the order (ascending or descending by
        trade ID).


        [Try in API
        console](https://test.deribit.com/api_console?method=%2Fpublic%2Fget_last_trades_by_currency)

      parameters:
        - name: currency
          required: true
          in: query
          schema:
            $ref: '#/components/schemas/currency'
          description: The currency symbol
        - name: kind
          required: false
          in: query
          schema:
            $ref: '#/components/schemas/kind_with_combo_all'
          description: >-
            Instrument kind, `"combo"` for any combo or `"any"` for all. If not
            provided instruments of all kinds are considered
        - name: start_id
          required: false
          in: query
          schema:
            $ref: '#/components/schemas/trade_id'
          description: >-
            The ID of the first trade to be returned. Number for BTC trades, or
            hyphen name in ex. `"ETH-15"` # `"ETH_USDC-16"`
        - name: end_id
          required: false
          in: query
          schema:
            $ref: '#/components/schemas/trade_id'
          description: >-
            The ID of the last trade to be returned. Number for BTC trades, or
            hyphen name in ex. `"ETH-15"` # `"ETH_USDC-16"`
        - name: start_timestamp
          required: false
          in: query
          schema:
            $ref: '#/components/schemas/timestamp'
          description: >-
            The earliest timestamp to return result from (milliseconds since the
            UNIX epoch). When param is provided trades are returned from the
            earliest
        - name: end_timestamp
          required: false
          in: query
          schema:
            $ref: '#/components/schemas/timestamp'
          description: >-
            The most recent timestamp to return result from (milliseconds since
            the UNIX epoch). Only one of params: start_timestamp, end_timestamp
            is truly required
        - name: count
          required: false
          in: query
          schema:
            type: integer
            maximum: 1000
            minimum: 1
          description: Number of requested items, default - `10`, maximum - `1000`
        - name: sorting
          required: false
          in: query
          schema:
            $ref: '#/components/schemas/sorting'
          description: >-
            Direction of results sorting (`default` value means no sorting,
            results will be returned in order in which they left the database)
      requestBody:
        content:
          application/json:
            examples:
              request:
                value:
                  jsonrpc: '2.0'
                  id: 9290
                  method: public/get_last_trades_by_currency
                  params:
                    currency: BTC
                    count: 3
                description: JSON-RPC Request Example
        description: JSON-RPC request body
      responses:
        '200':
          $ref: '#/components/responses/PublicTradesHistoryResponse'
components:
  schemas:
    currency:
      enum:
        - BTC
        - ETH
        - USDC
        - USDT
        - EURR
      type: string
      description: Currency, i.e `"BTC"`, `"ETH"`, `"USDC"`
    kind_with_combo_all:
      enum:
        - future
        - option
        - spot
        - future_combo
        - option_combo
        - combo
        - any
      type: string
      description: >-
        Instrument kind: `"future"`, `"option"`, `"spot"`, `"future_combo"`,
        `"option_combo"`, `"combo"` for any combo or `"any"` for all
    trade_id:
      type: string
      description: Unique (per currency) trade identifier
    timestamp:
      example: 1536569522277
      type: integer
      description: The timestamp (milliseconds since the Unix epoch)
    sorting:
      enum:
        - asc
        - desc
        - default
      type: string
    PublicTradesHistoryResponse:
      properties:
        jsonrpc:
          type: string
          enum:
            - '2.0'
          description: The JSON-RPC version (2.0)
        id:
          type: integer
          description: The id that was sent in the request
        result:
          type: object
          properties:
            trades:
              type: array
              items:
                $ref: '#/components/schemas/public_trade'
            has_more:
              type: boolean
          required:
            - trades
            - has_more
      required:
        - jsonrpc
        - result
      type: object
    public_trade:
      properties:
        trade_id:
          $ref: '#/components/schemas/trade_id'
        trade_seq:
          $ref: '#/components/schemas/trade_seq'
        instrument_name:
          $ref: '#/components/schemas/instrument_name'
        timestamp:
          $ref: '#/components/schemas/trade_timestamp'
        direction:
          $ref: '#/components/schemas/direction'
          description: Trade direction of the taker
        tick_direction:
          $ref: '#/components/schemas/tick_direction'
        index_price:
          type: number
          description: Index Price at the moment of trade
        price:
          $ref: '#/components/schemas/price'
          description: The price of the trade
        amount:
          type: number
          description: >-
            Trade amount. For perpetual and inverse futures the amount is in USD
            units. For options and linear futures it is the underlying base
            currency coin.
        contracts:
          type: number
          description: >-
            Trade size in contract units (optional, may be absent in historical
            trades)
        iv:
          type: number
          description: Option implied volatility for the price (Option only)
        liquidation:
          type: string
          enum:
            - M
            - T
            - MT
          description: >-
            Optional field (only for trades caused by liquidation): `"M"` when
            maker side of trade was under liquidation, `"T"` when taker side was
            under liquidation, `"MT"` when both sides of trade were under
            liquidation
        mark_price:
          type: number
          description: Mark Price at the moment of trade
        block_trade_id:
          $ref: '#/components/schemas/block_trade_id_in_result'
        block_trade_leg_count:
          $ref: '#/components/schemas/block_trade_leg_count'
        combo_id:
          type: string
          description: >-
            Optional field containing combo instrument name if the trade is a
            combo trade
        combo_trade_id:
          type: number
          description: >-
            Optional field containing combo trade identifier if the trade is a
            combo trade
        block_rfq_id:
          type: integer
          description: ID of the Block RFQ - when trade was part of the Block RFQ
      required:
        - trade_id
        - instrument_name
        - timestamp
        - trade_seq
        - direction
        - tick_direction
        - index_price
        - price
        - amount
        - mark_price
      type: object
    trade_seq:
      type: integer
      description: The sequence number of the trade within instrument
    instrument_name:
      example: BTC-PERPETUAL
      type: string
      description: Unique instrument identifier
    trade_timestamp:
      example: 1517329113791
      type: integer
      description: The timestamp of the trade (milliseconds since the UNIX epoch)
    direction:
      enum:
        - buy
        - sell
      type: string
      description: 'Direction: `buy`, or `sell`'
    tick_direction:
      enum:
        - 0
        - 1
        - 2
        - 3
      type: integer
      description: >-
        Direction of the "tick" (`0` = Plus Tick, `1` = Zero-Plus Tick, `2` =
        Minus Tick, `3` = Zero-Minus Tick).
    price:
      type: number
      description: Price in base currency
    block_trade_id_in_result:
      example: '154'
      type: string
      description: Block trade id - when trade was part of a block trade
    block_trade_leg_count:
      example: 3
      type: integer
      description: Block trade leg count - when trade was part of a block trade
  responses:
    PublicTradesHistoryResponse:
      content:
        application/json:
          schema:
            $ref: '#/components/schemas/PublicTradesHistoryResponse'
          examples:
            response:
              value:
                jsonrpc: '2.0'
                id: 1469
                result:
                  trades:
                    - trade_seq: 467
                      trade_id: '415305279'
                      timestamp: 1770984454552
                      tick_direction: 2
                      price: 0.0525
                      mark_price: 0.05253883
                      iv: 45.91
                      instrument_name: BTC-24APR26-72000-C
                      index_price: 66930.31
                      direction: buy
                      amount: 3
                      contracts: 3
                  has_more: true
              description: Response example
      description: Success response

````

 
  
  

<AgentInstructions>

## Submitting Feedback

If you encounter incorrect, outdated, or confusing documentation on this page, submit feedback:

POST https://docs.deribit.com/feedback

```json
{
  "path": "/api-reference/market-data/public-get_book_summary_by_instrument",
  "feedback": "Description of the issue"
}
```

Only submit feedback when you have something specific and actionable to report.

</AgentInstructions>

# public/get_book_summary_by_instrument

> Retrieves summary information such as open interest, 24-hour volume, best bid/ask prices, last trade price, mark price, and other market statistics for a specific instrument.

This method provides a quick overview of current market activity and liquidity for a single instrument.

[Try in API console](https://test.deribit.com/api_console?method=%2Fpublic%2Fget_book_summary_by_instrument)





## OpenAPI

````yaml /specifications/deribit_openapi.json get /public/get_book_summary_by_instrument
openapi: 3.0.0
info:
  title: Deribit API
  version: 2.1.1
servers:
  - url: https://test.deribit.com/api/v2
security: []
tags:
  - name: WebSocket Only
    description: Can only be used over websockets.
  - name: Public
    description: Public methods can be used without authentication.
  - name: Private
    description: >-
      <p>Private methods require authentication. All requests must include a
      valid OAuth2 token.</p>

      <p>A token can be requested using the <a
      href="#public-auth">/public/auth</a> method.</p>

      <p>When using the websockets protocol, the token must be included as a
      parameter <code>access_token</code> in the message. When using REST (HTTP
      GET), the token may also be passed in the <code>Authorization</code>
      header.</p>
  - name: Authentication
  - name: Session Management
  - name: Subscription Management
    description: >-
      Subscription works as [notifications](#notifications), so users will
      automatically (after subscribing) receive messages from the server.
      Overview for each channel response format is described in
      [subscriptions](#subscriptions) section.
  - name: Account Management
  - name: Trading
  - name: Market Data
  - name: Wallet
  - name: Chat
paths:
  /public/get_book_summary_by_instrument:
    get:
      tags:
        - Market Data
        - Public
      description: >+
        Retrieves summary information such as open interest, 24-hour volume,
        best bid/ask prices, last trade price, mark price, and other market
        statistics for a specific instrument.


        This method provides a quick overview of current market activity and
        liquidity for a single instrument.


        [Try in API
        console](https://test.deribit.com/api_console?method=%2Fpublic%2Fget_book_summary_by_instrument)

      parameters:
        - name: instrument_name
          required: true
          in: query
          schema:
            $ref: '#/components/schemas/instrument_name'
          description: Instrument name
      requestBody:
        content:
          application/json:
            examples:
              request:
                value:
                  jsonrpc: '2.0'
                  id: 3659
                  method: public/get_book_summary_by_instrument
                  params:
                    instrument_name: ETH-22FEB19-140-P
                description: JSON-RPC Request Example
        description: JSON-RPC request body
      responses:
        '200':
          $ref: '#/components/responses/PublicGetBookSummaryResponse'
components:
  schemas:
    instrument_name:
      example: BTC-PERPETUAL
      type: string
      description: Unique instrument identifier
    PublicGetBookSummaryResponse:
      properties:
        jsonrpc:
          type: string
          enum:
            - '2.0'
          description: The JSON-RPC version (2.0)
        id:
          type: integer
          description: The id that was sent in the request
        result:
          type: array
          items:
            $ref: '#/components/schemas/book_summary'
      required:
        - jsonrpc
        - result
      type: object
    book_summary:
      properties:
        instrument_name:
          $ref: '#/components/schemas/instrument_name'
        high:
          example: 7022.89
          type: number
          description: Price of the 24h highest trade
        low:
          example: 7022.89
          type: number
          description: Price of the 24h lowest trade, `null` if there weren't any trades
        base_currency:
          example: ETH
          type: string
          description: Base currency
        quote_currency:
          example: USD
          type: string
          description: Quote currency
        volume:
          example: 223
          type: number
          description: The total 24h traded volume (in base currency)
        bid_price:
          example: 7022.89
          type: number
          description: The current best bid price, `null` if there aren't any bids
        ask_price:
          example: 7022.89
          type: number
          description: The current best ask price, `null` if there aren't any asks
        mid_price:
          example: 7022.89
          type: number
          description: >-
            The average of the best bid and ask, `null` if there aren't any asks
            or bids
        mark_price:
          example: 7022.89
          type: number
          description: The current instrument market price
        last:
          example: 7022.89
          type: number
          description: The price of the latest trade, `null` if there weren't any trades
        open_interest:
          example: 0.5
          type: number
          description: >-
            Optional (only for derivatives). The total amount of outstanding
            contracts in the corresponding amount units. For perpetual and
            inverse futures the amount is in USD units. For options and linear
            futures it is the underlying base currency coin.
        creation_timestamp:
          $ref: '#/components/schemas/timestamp'
        estimated_delivery_price:
          example: 11628.81
          type: number
          description: >-
            Optional (only for derivatives). Estimated delivery price for the
            market.
        volume_usd:
          type: number
          description: Volume in USD
        volume_notional:
          type: number
          description: Volume in quote currency (futures and spots only)
        current_funding:
          type: number
          example: 0.12344
          description: Current funding (perpetual only)
        funding_8h:
          type: number
          description: Funding 8h (perpetual only)
        mark_iv:
          $ref: '#/components/schemas/mark_iv'
        interest_rate:
          example: 0
          type: number
          description: Interest rate used in implied volatility calculations (options only)
        underlying_index:
          example: index_price
          type: string
          description: Name of the underlying future, or `'index_price'` (options only)
        underlying_price:
          example: 6745.34
          type: number
          description: underlying price for implied volatility calculations (options only)
        price_change:
          example: 10.23
          type: number
          description: >-
            24-hour price change expressed as a percentage, `null` if there
            weren't any trades
      required:
        - instrument_name
        - high
        - low
        - base_currency
        - quote_currency
        - volume
        - bid_price
        - ask_price
        - mid_price
        - mark_price
        - last
        - open_interest
        - creation_timestamp
      type: object
    timestamp:
      example: 1536569522277
      type: integer
      description: The timestamp (milliseconds since the Unix epoch)
    mark_iv:
      type: number
      description: (Only for option) implied volatility for mark price
  responses:
    PublicGetBookSummaryResponse:
      content:
        application/json:
          schema:
            $ref: '#/components/schemas/PublicGetBookSummaryResponse'
          examples:
            response:
              value:
                jsonrpc: '2.0'
                id: 3659
                result:
                  - volume: 0.55
                    underlying_price: 121.38
                    underlying_index: index_price
                    quote_currency: USD
                    price_change: -26.7793594
                    open_interest: 0.55
                    mid_price: 0.2444
                    mark_price: 80
                    low: 0.34
                    last: 0.34
                    interest_rate: 0.207
                    instrument_name: ETH-22FEB19-140-P
                    high: 0.34
                    creation_timestamp: 1550227952163
                    bid_price: 0.1488
                    base_currency: ETH
                    ask_price: 0.34
              description: Response example
      description: Success response

````

 
  
  

<AgentInstructions>

## Submitting Feedback

If you encounter incorrect, outdated, or confusing documentation on this page, submit feedback:

POST https://docs.deribit.com/feedback

```json
{
  "path": "/api-reference/market-data/public-get_contract_size",
  "feedback": "Description of the issue"
}
```

Only submit feedback when you have something specific and actionable to report.

</AgentInstructions>

# public/get_contract_size

> Retrieves the contract size (also known as contract multiplier) for a given instrument. The contract size determines how many units of the underlying asset one contract represents.

This value is essential for calculating position values, margin requirements, and P&L calculations. Different instruments may have different contract sizes.

[Try in API console](https://test.deribit.com/api_console?method=%2Fpublic%2Fget_contract_size)





## OpenAPI

````yaml /specifications/deribit_openapi.json get /public/get_contract_size
openapi: 3.0.0
info:
  title: Deribit API
  version: 2.1.1
servers:
  - url: https://test.deribit.com/api/v2
security: []
tags:
  - name: WebSocket Only
    description: Can only be used over websockets.
  - name: Public
    description: Public methods can be used without authentication.
  - name: Private
    description: >-
      <p>Private methods require authentication. All requests must include a
      valid OAuth2 token.</p>

      <p>A token can be requested using the <a
      href="#public-auth">/public/auth</a> method.</p>

      <p>When using the websockets protocol, the token must be included as a
      parameter <code>access_token</code> in the message. When using REST (HTTP
      GET), the token may also be passed in the <code>Authorization</code>
      header.</p>
  - name: Authentication
  - name: Session Management
  - name: Subscription Management
    description: >-
      Subscription works as [notifications](#notifications), so users will
      automatically (after subscribing) receive messages from the server.
      Overview for each channel response format is described in
      [subscriptions](#subscriptions) section.
  - name: Account Management
  - name: Trading
  - name: Market Data
  - name: Wallet
  - name: Chat
paths:
  /public/get_contract_size:
    get:
      tags:
        - Market Data
        - Public
      description: >+
        Retrieves the contract size (also known as contract multiplier) for a
        given instrument. The contract size determines how many units of the
        underlying asset one contract represents.


        This value is essential for calculating position values, margin
        requirements, and P&L calculations. Different instruments may have
        different contract sizes.


        [Try in API
        console](https://test.deribit.com/api_console?method=%2Fpublic%2Fget_contract_size)

      parameters:
        - name: instrument_name
          required: true
          in: query
          schema:
            $ref: '#/components/schemas/instrument_name'
          description: Instrument name
      responses:
        '200':
          $ref: '#/components/responses/PublicGetContractSizeResponse'
components:
  schemas:
    instrument_name:
      example: BTC-PERPETUAL
      type: string
      description: Unique instrument identifier
    PublicGetContractSizeResponse:
      properties:
        jsonrpc:
          type: string
          enum:
            - '2.0'
          description: The JSON-RPC version (2.0)
        id:
          type: integer
          description: The id that was sent in the request
        result:
          type: object
          properties:
            contract_size:
              $ref: '#/components/schemas/contract_size'
          required:
            - contract_size
      required:
        - jsonrpc
        - result
      type: object
    contract_size:
      example: 10
      type: integer
      description: >-
        Contract size, for futures in USD, for options in base currency of the
        instrument (BTC, ETH, ...)
  responses:
    PublicGetContractSizeResponse:
      content:
        application/json:
          schema:
            $ref: '#/components/schemas/PublicGetContractSizeResponse'
      description: Success response

````

 
  
  

<AgentInstructions>

## Submitting Feedback

If you encounter incorrect, outdated, or confusing documentation on this page, submit feedback:

POST https://docs.deribit.com/feedback

```json
{
  "path": "/api-reference/market-data/public-get_currencies",
  "feedback": "Description of the issue"
}
```

Only submit feedback when you have something specific and actionable to report.

</AgentInstructions>

# public/get_currencies

> Retrieves all cryptocurrencies supported by the Deribit API. Returns a list of available currencies with their codes and basic information.

This method takes no parameters and is useful for discovering which currencies are available for trading on the platform.

[Try in API console](https://test.deribit.com/api_console?method=%2Fpublic%2Fget_currencies)





## OpenAPI

````yaml /specifications/deribit_openapi.json get /public/get_currencies
openapi: 3.0.0
info:
  title: Deribit API
  version: 2.1.1
servers:
  - url: https://test.deribit.com/api/v2
security: []
tags:
  - name: WebSocket Only
    description: Can only be used over websockets.
  - name: Public
    description: Public methods can be used without authentication.
  - name: Private
    description: >-
      <p>Private methods require authentication. All requests must include a
      valid OAuth2 token.</p>

      <p>A token can be requested using the <a
      href="#public-auth">/public/auth</a> method.</p>

      <p>When using the websockets protocol, the token must be included as a
      parameter <code>access_token</code> in the message. When using REST (HTTP
      GET), the token may also be passed in the <code>Authorization</code>
      header.</p>
  - name: Authentication
  - name: Session Management
  - name: Subscription Management
    description: >-
      Subscription works as [notifications](#notifications), so users will
      automatically (after subscribing) receive messages from the server.
      Overview for each channel response format is described in
      [subscriptions](#subscriptions) section.
  - name: Account Management
  - name: Trading
  - name: Market Data
  - name: Wallet
  - name: Chat
paths:
  /public/get_currencies:
    get:
      tags:
        - Market Data
        - Public
      description: >+
        Retrieves all cryptocurrencies supported by the Deribit API. Returns a
        list of available currencies with their codes and basic information.


        This method takes no parameters and is useful for discovering which
        currencies are available for trading on the platform.


        [Try in API
        console](https://test.deribit.com/api_console?method=%2Fpublic%2Fget_currencies)

      requestBody:
        content:
          application/json:
            examples:
              request:
                value:
                  jsonrpc: '2.0'
                  id: 7538
                  method: public/get_currencies
                  params: {}
                description: JSON-RPC Request Example
        description: JSON-RPC request body
      responses:
        '200':
          $ref: '#/components/responses/PublicGetCurrenciesResponse'
components:
  responses:
    PublicGetCurrenciesResponse:
      content:
        application/json:
          schema:
            $ref: '#/components/schemas/PublicGetCurrenciesResponse'
          examples:
            response:
              value:
                jsonrpc: '2.0'
                id: 7538
                result:
                  - coin_type: ETHER
                    currency: ETH
                    currency_long: Ethereum
                    min_confirmations: 1
                    min_withdrawal_fee: 0.0001
                    withdrawal_fee: 0.0006
                    withdrawal_priorities: []
                    network_currency: ETH
                    network_fee: 0.0006
                    decimals: 6
                  - coin_type: BITCOIN
                    currency: BTC
                    currency_long: Bitcoin
                    min_confirmations: 1
                    min_withdrawal_fee: 0.0001
                    withdrawal_fee: 0.0001
                    withdrawal_priorities:
                      - value: 0.15
                        name: very_low
                      - value: 1.5
                        name: very_high
                    network_currency: BTC
                    network_fee: 0.0001
                    decimals: 8
              description: Response example
      description: Success response
  schemas:
    PublicGetCurrenciesResponse:
      properties:
        jsonrpc:
          type: string
          enum:
            - '2.0'
          description: The JSON-RPC version (2.0)
        id:
          type: integer
          description: The id that was sent in the request
        result:
          type: array
          items:
            $ref: '#/components/schemas/currency_with_apr'
      required:
        - jsonrpc
        - result
      type: object
    currency_with_apr:
      properties:
        withdrawal_fee:
          type: number
          example: 0.0001
          description: The total transaction fee paid for withdrawals
        withdrawal_priorities:
          type: array
          items:
            $ref: '#/components/schemas/key_number_pair'
        min_withdrawal_fee:
          type: number
          example: 0.0001
          description: The minimum transaction fee paid for withdrawals
        currency:
          type: string
          example: BTC
          description: >-
            The abbreviation of the currency. This abbreviation is used
            elsewhere in the API to identify the currency.
        currency_long:
          type: string
          example: Bitcoin
          description: The full name for the currency.
        min_confirmations:
          type: integer
          example: 2
          description: >-
            Minimum number of block chain confirmations before deposit is
            accepted.
        coin_type:
          type: string
          enum:
            - BITCOIN
            - ETHER
          description: The type of the currency.
        in_cross_collateral_pool:
          type: boolean
          description: '`true` if the currency is part of the cross collateral pool'
        apr:
          type: number
          description: >-
            Simple Moving Average (SMA) of the last 7 days of rewards. If fewer
            than 7 days of reward data are available, the APR is calculated as
            the average of the available rewards. Only applicable to
            yield-generating tokens (`USDE`, `STETH`, `USDC`, `BUILD`).
        network_fee:
          type: number
          example: 0.0001
          description: The network fee
        network_currency:
          type: string
          example: BTC
          description: The currency of the network
        decimals:
          type: integer
          example: 6
          description: The number of decimal places for the currency
      required:
        - currency
        - currency_long
        - min_confirmations
        - withdrawal_fee
        - coin_type
        - in_cross_collateral_pool
      type: object
    key_number_pair:
      properties:
        name:
          type: string
        value:
          type: number
      required:
        - name
        - value
      type: object

````

 
  
  

<AgentInstructions>

## Submitting Feedback

If you encounter incorrect, outdated, or confusing documentation on this page, submit feedback:

POST https://docs.deribit.com/feedback

```json
{
  "path": "/api-reference/market-data/public-get_delivery_prices",
  "feedback": "Description of the issue"
}
```

Only submit feedback when you have something specific and actionable to report.

</AgentInstructions>

# public/get_delivery_prices

> Retrieves historical delivery prices for a given index. Delivery prices are the settlement prices used when futures or options contracts expire and are settled.

Results can be paginated using the `offset` and `count` parameters. This method is useful for analyzing historical settlement prices and understanding how contracts have been settled over time.

[Try in API console](https://test.deribit.com/api_console?method=%2Fpublic%2Fget_delivery_prices)





## OpenAPI

````yaml /specifications/deribit_openapi.json get /public/get_delivery_prices
openapi: 3.0.0
info:
  title: Deribit API
  version: 2.1.1
servers:
  - url: https://test.deribit.com/api/v2
security: []
tags:
  - name: WebSocket Only
    description: Can only be used over websockets.
  - name: Public
    description: Public methods can be used without authentication.
  - name: Private
    description: >-
      <p>Private methods require authentication. All requests must include a
      valid OAuth2 token.</p>

      <p>A token can be requested using the <a
      href="#public-auth">/public/auth</a> method.</p>

      <p>When using the websockets protocol, the token must be included as a
      parameter <code>access_token</code> in the message. When using REST (HTTP
      GET), the token may also be passed in the <code>Authorization</code>
      header.</p>
  - name: Authentication
  - name: Session Management
  - name: Subscription Management
    description: >-
      Subscription works as [notifications](#notifications), so users will
      automatically (after subscribing) receive messages from the server.
      Overview for each channel response format is described in
      [subscriptions](#subscriptions) section.
  - name: Account Management
  - name: Trading
  - name: Market Data
  - name: Wallet
  - name: Chat
paths:
  /public/get_delivery_prices:
    get:
      tags:
        - Market Data
      description: >+
        Retrieves historical delivery prices for a given index. Delivery prices
        are the settlement prices used when futures or options contracts expire
        and are settled.


        Results can be paginated using the `offset` and `count` parameters. This
        method is useful for analyzing historical settlement prices and
        understanding how contracts have been settled over time.


        [Try in API
        console](https://test.deribit.com/api_console?method=%2Fpublic%2Fget_delivery_prices)

      parameters:
        - name: index_name
          required: true
          in: query
          schema:
            $ref: '#/components/schemas/index_name'
          description: Index identifier, matches (base) cryptocurrency with quote currency
        - name: offset
          in: query
          required: false
          schema:
            example: 10
            type: integer
          description: The offset for pagination, default - `0`
        - name: count
          required: false
          in: query
          schema:
            type: integer
            maximum: 1000
            minimum: 1
          description: Number of requested items, default - `10`, maximum - `1000`
      requestBody:
        content:
          application/json:
            examples:
              request:
                value:
                  jsonrpc: '2.0'
                  id: 3601
                  method: public/get_delivery_prices
                  params:
                    index_name: btc_usd
                    offset: 0
                    count: 5
                description: JSON-RPC Request Example
        description: JSON-RPC request body
      responses:
        '200':
          $ref: '#/components/responses/PublicGetDeliveryPricesResponse'
components:
  schemas:
    index_name:
      enum:
        - btc_usd
        - eth_usd
        - ada_usdc
        - algo_usdc
        - avax_usdc
        - bch_usdc
        - bnb_usdc
        - btc_usdc
        - btcdvol_usdc
        - buidl_usdc
        - doge_usdc
        - dot_usdc
        - eurr_usdc
        - eth_usdc
        - ethdvol_usdc
        - link_usdc
        - ltc_usdc
        - near_usdc
        - paxg_usdc
        - shib_usdc
        - sol_usdc
        - steth_usdc
        - ton_usdc
        - trump_usdc
        - trx_usdc
        - uni_usdc
        - usde_usdc
        - usyc_usdc
        - xrp_usdc
        - btc_usdt
        - eth_usdt
        - eurr_usdt
        - sol_usdt
        - steth_usdt
        - usdc_usdt
        - usde_usdt
        - btc_eurr
        - btc_usde
        - btc_usyc
        - eth_btc
        - eth_eurr
        - eth_usde
        - eth_usyc
        - steth_eth
        - paxg_btc
        - drbfix-btc_usdc
        - drbfix-eth_usdc
      type: string
      description: Index identifier, matches (base) cryptocurrency with quote currency
    PublicGetDeliveryPricesResponse:
      properties:
        jsonrpc:
          type: string
          enum:
            - '2.0'
          description: The JSON-RPC version (2.0)
        id:
          type: integer
          description: The id that was sent in the request
        result:
          type: object
          properties:
            records_total:
              type: number
              example: 120
              description: Available delivery prices
            data:
              type: array
              items:
                type: object
                properties:
                  date:
                    $ref: '#/components/schemas/date'
                  delivery_price:
                    $ref: '#/components/schemas/delivery_price'
                required:
                  - date
                  - delivery_price
          required:
            - records_total
            - data
      required:
        - jsonrpc
        - result
      type: object
    date:
      example: '2019-11-24'
      type: string
      description: The event date with year, month and day
    delivery_price:
      type: number
      description: The settlement price for the instrument. Only when `state = closed`
  responses:
    PublicGetDeliveryPricesResponse:
      content:
        application/json:
          schema:
            $ref: '#/components/schemas/PublicGetDeliveryPricesResponse'
          examples:
            response:
              value:
                jsonrpc: '2.0'
                id: 3601
                result:
                  data:
                    - date: '2020-01-02'
                      delivery_price: 7131.214606410254
                    - date: '2019-12-21'
                      delivery_price: 7150.943217777777
                    - date: '2019-12-20'
                      delivery_price: 7175.988445532345
                    - date: '2019-12-19'
                      delivery_price: 7189.540776143791
                    - date: '2019-12-18'
                      delivery_price: 6698.353743857118
                  records_total: 58
              description: Response example
      description: Success response

````

 
  
  

<AgentInstructions>

## Submitting Feedback

If you encounter incorrect, outdated, or confusing documentation on this page, submit feedback:

POST https://docs.deribit.com/feedback

```json
{
  "path": "/api-reference/market-data/public-get_expirations",
  "feedback": "Description of the issue"
}
```

Only submit feedback when you have something specific and actionable to report.

</AgentInstructions>

# public/get_expirations

> Retrieves all available expiration timestamps for instruments. This method can be used to discover which expiration dates are available for trading, which is useful for finding instruments with specific expiration dates.

Results can be filtered by settlement currency, instrument kind (future or option), and currency pair. The response includes expiration timestamps in milliseconds since the UNIX epoch.

[Try in API console](https://test.deribit.com/api_console?method=%2Fpublic%2Fget_expirations)





## OpenAPI

````yaml /specifications/deribit_openapi.json get /public/get_expirations
openapi: 3.0.0
info:
  title: Deribit API
  version: 2.1.1
servers:
  - url: https://test.deribit.com/api/v2
security: []
tags:
  - name: WebSocket Only
    description: Can only be used over websockets.
  - name: Public
    description: Public methods can be used without authentication.
  - name: Private
    description: >-
      <p>Private methods require authentication. All requests must include a
      valid OAuth2 token.</p>

      <p>A token can be requested using the <a
      href="#public-auth">/public/auth</a> method.</p>

      <p>When using the websockets protocol, the token must be included as a
      parameter <code>access_token</code> in the message. When using REST (HTTP
      GET), the token may also be passed in the <code>Authorization</code>
      header.</p>
  - name: Authentication
  - name: Session Management
  - name: Subscription Management
    description: >-
      Subscription works as [notifications](#notifications), so users will
      automatically (after subscribing) receive messages from the server.
      Overview for each channel response format is described in
      [subscriptions](#subscriptions) section.
  - name: Account Management
  - name: Trading
  - name: Market Data
  - name: Wallet
  - name: Chat
paths:
  /public/get_expirations:
    get:
      tags:
        - Market Data
        - Public
      description: >+
        Retrieves all available expiration timestamps for instruments. This
        method can be used to discover which expiration dates are available for
        trading, which is useful for finding instruments with specific
        expiration dates.


        Results can be filtered by settlement currency, instrument kind (future
        or option), and currency pair. The response includes expiration
        timestamps in milliseconds since the UNIX epoch.


        [Try in API
        console](https://test.deribit.com/api_console?method=%2Fpublic%2Fget_expirations)

      parameters:
        - name: currency
          required: true
          in: query
          schema:
            $ref: '#/components/schemas/settlement_currency_with_any_and_grouped'
          description: >-
            The currency symbol or `"any"` for all or '"grouped"' for all
            grouped by currency
        - name: kind
          required: true
          in: query
          schema:
            $ref: '#/components/schemas/kind_future_or_option_with_any'
          description: Instrument kind, `"future"` or `"option"` or `"any"`
        - name: currency_pair
          required: false
          in: query
          schema:
            $ref: '#/components/schemas/index_name'
          description: The currency pair symbol
      requestBody:
        content:
          application/json:
            examples:
              request:
                value:
                  jsonrpc: '2.0'
                  id: 1
                  method: public/get_expirations
                  params:
                    currency: any
                    kind: any
                description: JSON-RPC Request Example
        description: JSON-RPC request body
      responses:
        '200':
          $ref: '#/components/responses/PublicGetExpirationsResponse'
components:
  schemas:
    settlement_currency_with_any_and_grouped:
      enum:
        - BTC
        - ETH
        - USDC
        - USDT
        - any
        - grouped
      type: string
      description: >-
        Currency name or `"any"` if don't care or `"grouped"` if grouped by
        currencies
    kind_future_or_option_with_any:
      enum:
        - future
        - option
        - any
      type: string
      description: 'Instrument kind: `"future"`, `"option"` or `"any"` for all'
    index_name:
      enum:
        - btc_usd
        - eth_usd
        - ada_usdc
        - algo_usdc
        - avax_usdc
        - bch_usdc
        - bnb_usdc
        - btc_usdc
        - btcdvol_usdc
        - buidl_usdc
        - doge_usdc
        - dot_usdc
        - eurr_usdc
        - eth_usdc
        - ethdvol_usdc
        - link_usdc
        - ltc_usdc
        - near_usdc
        - paxg_usdc
        - shib_usdc
        - sol_usdc
        - steth_usdc
        - ton_usdc
        - trump_usdc
        - trx_usdc
        - uni_usdc
        - usde_usdc
        - usyc_usdc
        - xrp_usdc
        - btc_usdt
        - eth_usdt
        - eurr_usdt
        - sol_usdt
        - steth_usdt
        - usdc_usdt
        - usde_usdt
        - btc_eurr
        - btc_usde
        - btc_usyc
        - eth_btc
        - eth_eurr
        - eth_usde
        - eth_usyc
        - steth_eth
        - paxg_btc
        - drbfix-btc_usdc
        - drbfix-eth_usdc
      type: string
      description: Index identifier, matches (base) cryptocurrency with quote currency
    PublicGetExpirationsResponse:
      properties:
        jsonrpc:
          type: string
          enum:
            - '2.0'
          description: The JSON-RPC version (2.0)
        id:
          type: integer
          description: The id that was sent in the request
        result:
          type: array
          items:
            $ref: '#/components/schemas/expirations'
      required:
        - jsonrpc
        - result
      type: object
    expirations:
      properties:
        currency:
          $ref: '#/components/schemas/currency_with_any_and_grouped'
        kind:
          $ref: '#/components/schemas/kind_future_or_option_with_any'
      type: object
      description: >-
        A map where each key is valid currency (e.g. btc, eth, usdc), and the
        value is a list of expirations or a map where each key is a valid kind
        (future or options) and value is a list of expirations from every
        instrument
    currency_with_any_and_grouped:
      enum:
        - BTC
        - ETH
        - USDC
        - SOL
        - USDT
        - EURR
        - XRP
        - STETH
        - USYC
        - PAXG
        - BNB
        - USDE
        - any
        - grouped
      type: string
      description: >-
        Currency name or `"any"` if don't care or `"grouped"` if grouped by
        currencies
  responses:
    PublicGetExpirationsResponse:
      content:
        application/json:
          schema:
            $ref: '#/components/schemas/PublicGetExpirationsResponse'
          examples:
            response:
              value:
                jsonrpc: '2.0'
                result:
                  future:
                    - 21SEP24
                    - 22SEP24
                    - PERPETUAL
                  option:
                    - 21SEP24
                    - 22SEP24
                    - 23SEP24
              description: Response example
      description: Success response

````

 
  
  

<AgentInstructions>

## Submitting Feedback

If you encounter incorrect, outdated, or confusing documentation on this page, submit feedback:

POST https://docs.deribit.com/feedback

```json
{
  "path": "/api-reference/market-data/public-get_funding_chart_data",
  "feedback": "Description of the issue"
}
```

Only submit feedback when you have something specific and actionable to report.

</AgentInstructions>

# public/get_funding_chart_data

> Retrieves funding rate chart data points for a PERPETUAL instrument within a given time period. The data is formatted for use in charting applications and includes funding rate values at regular intervals.

Use the `length` parameter to specify the time period for which to retrieve chart data. This method is useful for visualizing funding rate trends over time.

[Try in API console](https://test.deribit.com/api_console?method=%2Fpublic%2Fget_funding_chart_data)





## OpenAPI

````yaml /specifications/deribit_openapi.json get /public/get_funding_chart_data
openapi: 3.0.0
info:
  title: Deribit API
  version: 2.1.1
servers:
  - url: https://test.deribit.com/api/v2
security: []
tags:
  - name: WebSocket Only
    description: Can only be used over websockets.
  - name: Public
    description: Public methods can be used without authentication.
  - name: Private
    description: >-
      <p>Private methods require authentication. All requests must include a
      valid OAuth2 token.</p>

      <p>A token can be requested using the <a
      href="#public-auth">/public/auth</a> method.</p>

      <p>When using the websockets protocol, the token must be included as a
      parameter <code>access_token</code> in the message. When using REST (HTTP
      GET), the token may also be passed in the <code>Authorization</code>
      header.</p>
  - name: Authentication
  - name: Session Management
  - name: Subscription Management
    description: >-
      Subscription works as [notifications](#notifications), so users will
      automatically (after subscribing) receive messages from the server.
      Overview for each channel response format is described in
      [subscriptions](#subscriptions) section.
  - name: Account Management
  - name: Trading
  - name: Market Data
  - name: Wallet
  - name: Chat
paths:
  /public/get_funding_chart_data:
    get:
      tags:
        - Market Data
        - Public
      description: >+
        Retrieves funding rate chart data points for a PERPETUAL instrument
        within a given time period. The data is formatted for use in charting
        applications and includes funding rate values at regular intervals.


        Use the `length` parameter to specify the time period for which to
        retrieve chart data. This method is useful for visualizing funding rate
        trends over time.


        [Try in API
        console](https://test.deribit.com/api_console?method=%2Fpublic%2Fget_funding_chart_data)

      parameters:
        - name: instrument_name
          required: true
          in: query
          schema:
            $ref: '#/components/schemas/instrument_name'
          description: Instrument name
        - name: length
          in: query
          schema:
            type: string
            enum:
              - 8h
              - 24h
              - 1m
          required: true
          description: >-
            Specifies time period. `8h` - 8 hours, `24h` - 24 hours, `1m` - 1
            month
      responses:
        '200':
          $ref: '#/components/responses/PublicGetFundingChartDataResponse'
components:
  schemas:
    instrument_name:
      example: BTC-PERPETUAL
      type: string
      description: Unique instrument identifier
    PublicGetFundingChartDataResponse:
      properties:
        jsonrpc:
          type: string
          enum:
            - '2.0'
          description: The JSON-RPC version (2.0)
        id:
          type: integer
          description: The id that was sent in the request
        result:
          type: object
          properties:
            current_interest:
              type: number
              example: 0.005000670552845
              description: Current interest
            interest_8h:
              type: number
              example: 0.0040080896931
              description: Current interest 8h
            data:
              type: array
              items:
                type: object
                properties:
                  timestamp:
                    $ref: '#/components/schemas/timestamp'
                  index_price:
                    $ref: '#/components/schemas/index_price'
                  interest_8h:
                    type: number
                    example: 0.004999511380756577
                    description: Historical interest 8h value
                required:
                  - timestamp
                  - index_price
                  - interest_8h
          required:
            - current_interest
            - data
            - interest_8h
      required:
        - jsonrpc
        - result
      type: object
    timestamp:
      example: 1536569522277
      type: integer
      description: The timestamp (milliseconds since the Unix epoch)
    index_price:
      example: 8247.27
      type: number
      description: Current index price
  responses:
    PublicGetFundingChartDataResponse:
      content:
        application/json:
          schema:
            $ref: '#/components/schemas/PublicGetFundingChartDataResponse'
      description: Success response

````

 
  
  

<AgentInstructions>

## Submitting Feedback

If you encounter incorrect, outdated, or confusing documentation on this page, submit feedback:

POST https://docs.deribit.com/feedback

```json
{
  "path": "/api-reference/market-data/public-get_funding_rate_history",
  "feedback": "Description of the issue"
}
```

Only submit feedback when you have something specific and actionable to report.

</AgentInstructions>

# public/get_funding_rate_history

> Retrieves hourly historical funding rate (interest rate) data for a PERPETUAL instrument over a specified time period. Funding rates are periodic payments exchanged between long and short positions in perpetual contracts.

The response includes hourly funding rate values, which can be used to analyze funding rate trends and calculate historical funding costs. This method is applicable only for PERPETUAL instruments.

[Try in API console](https://test.deribit.com/api_console?method=%2Fpublic%2Fget_funding_rate_history)





## OpenAPI

````yaml /specifications/deribit_openapi.json get /public/get_funding_rate_history
openapi: 3.0.0
info:
  title: Deribit API
  version: 2.1.1
servers:
  - url: https://test.deribit.com/api/v2
security: []
tags:
  - name: WebSocket Only
    description: Can only be used over websockets.
  - name: Public
    description: Public methods can be used without authentication.
  - name: Private
    description: >-
      <p>Private methods require authentication. All requests must include a
      valid OAuth2 token.</p>

      <p>A token can be requested using the <a
      href="#public-auth">/public/auth</a> method.</p>

      <p>When using the websockets protocol, the token must be included as a
      parameter <code>access_token</code> in the message. When using REST (HTTP
      GET), the token may also be passed in the <code>Authorization</code>
      header.</p>
  - name: Authentication
  - name: Session Management
  - name: Subscription Management
    description: >-
      Subscription works as [notifications](#notifications), so users will
      automatically (after subscribing) receive messages from the server.
      Overview for each channel response format is described in
      [subscriptions](#subscriptions) section.
  - name: Account Management
  - name: Trading
  - name: Market Data
  - name: Wallet
  - name: Chat
paths:
  /public/get_funding_rate_history:
    get:
      tags:
        - Market Data
        - Public
      description: >+
        Retrieves hourly historical funding rate (interest rate) data for a
        PERPETUAL instrument over a specified time period. Funding rates are
        periodic payments exchanged between long and short positions in
        perpetual contracts.


        The response includes hourly funding rate values, which can be used to
        analyze funding rate trends and calculate historical funding costs. This
        method is applicable only for PERPETUAL instruments.


        [Try in API
        console](https://test.deribit.com/api_console?method=%2Fpublic%2Fget_funding_rate_history)

      parameters:
        - name: instrument_name
          required: true
          in: query
          schema:
            $ref: '#/components/schemas/instrument_name'
          description: Instrument name
        - name: start_timestamp
          required: true
          in: query
          schema:
            $ref: '#/components/schemas/timestamp'
          description: >-
            The earliest timestamp to return result from (milliseconds since the
            UNIX epoch)
        - name: end_timestamp
          required: true
          in: query
          schema:
            $ref: '#/components/schemas/timestamp'
          description: >-
            The most recent timestamp to return result from (milliseconds since
            the UNIX epoch)
      requestBody:
        content:
          application/json:
            examples:
              request:
                value:
                  jsonrpc: '2.0'
                  id: 7617
                  method: public/get_funding_rate_history
                  params:
                    instrument_name: BTC-PERPETUAL
                    start_timestamp: 1569888000000
                    end_timestamp: 1569902400000
                description: JSON-RPC Request Example
        description: JSON-RPC request body
      responses:
        '200':
          $ref: '#/components/responses/PublicGetFundingRateHistoryResponse'
components:
  schemas:
    instrument_name:
      example: BTC-PERPETUAL
      type: string
      description: Unique instrument identifier
    timestamp:
      example: 1536569522277
      type: integer
      description: The timestamp (milliseconds since the Unix epoch)
    PublicGetFundingRateHistoryResponse:
      properties:
        jsonrpc:
          type: string
          enum:
            - '2.0'
          description: The JSON-RPC version (2.0)
        id:
          type: integer
          description: The id that was sent in the request
        result:
          type: array
          items:
            type: object
            properties:
              timestamp:
                $ref: '#/components/schemas/timestamp'
              prev_index_price:
                $ref: '#/components/schemas/price'
              index_price:
                $ref: '#/components/schemas/price'
              interest_1h:
                type: number
                description: 1hour interest rate
              interest_8h:
                type: number
                description: 8hour interest rate
      required:
        - jsonrpc
        - result
      type: object
    price:
      type: number
      description: Price in base currency
  responses:
    PublicGetFundingRateHistoryResponse:
      content:
        application/json:
          schema:
            $ref: '#/components/schemas/PublicGetFundingRateHistoryResponse'
          examples:
            response:
              value:
                jsonrpc: '2.0'
                id: 7617
                result:
                  - timestamp: 1569891600000
                    index_price: 8222.87
                    prev_index_price: 8305.72
                    interest_8h: -0.00009234260068476106
                    interest_1h: -4.739622041017375e-7
                  - timestamp: 1569895200000
                    index_price: 8286.49
                    prev_index_price: 8222.87
                    interest_8h: -0.00006720918180255509
                    interest_1h: -2.8583510923267753e-7
                  - timestamp: 1569898800000
                    index_price: 8431.97
                    prev_index_price: 8286.49
                    interest_8h: -0.00003544496169694662
                    interest_1h: -0.000003815906848177951
                  - timestamp: 1569902400000
                    index_price: 8422.36
                    prev_index_price: 8431.97
                    interest_8h: -0.00001404147515584998
                    interest_1h: 8.312033064379086e-7
              description: Response example
      description: Success response

````

 
  
  

<AgentInstructions>

## Submitting Feedback

If you encounter incorrect, outdated, or confusing documentation on this page, submit feedback:

POST https://docs.deribit.com/feedback

```json
{
  "path": "/api-reference/market-data/public-get_funding_rate_value",
  "feedback": "Description of the issue"
}
```

Only submit feedback when you have something specific and actionable to report.

</AgentInstructions>

# public/get_funding_rate_value

> Retrieves the funding rate (interest rate) value for a perpetual instrument over a specified time period. Funding rates are periodic payments exchanged between long and short positions in perpetual contracts.

This method is applicable only for PERPETUAL instruments. The funding rate is typically expressed as a percentage and is used to keep the perpetual contract price aligned with the underlying index price.

[Try in API console](https://test.deribit.com/api_console?method=%2Fpublic%2Fget_funding_rate_value)





## OpenAPI

````yaml /specifications/deribit_openapi.json get /public/get_funding_rate_value
openapi: 3.0.0
info:
  title: Deribit API
  version: 2.1.1
servers:
  - url: https://test.deribit.com/api/v2
security: []
tags:
  - name: WebSocket Only
    description: Can only be used over websockets.
  - name: Public
    description: Public methods can be used without authentication.
  - name: Private
    description: >-
      <p>Private methods require authentication. All requests must include a
      valid OAuth2 token.</p>

      <p>A token can be requested using the <a
      href="#public-auth">/public/auth</a> method.</p>

      <p>When using the websockets protocol, the token must be included as a
      parameter <code>access_token</code> in the message. When using REST (HTTP
      GET), the token may also be passed in the <code>Authorization</code>
      header.</p>
  - name: Authentication
  - name: Session Management
  - name: Subscription Management
    description: >-
      Subscription works as [notifications](#notifications), so users will
      automatically (after subscribing) receive messages from the server.
      Overview for each channel response format is described in
      [subscriptions](#subscriptions) section.
  - name: Account Management
  - name: Trading
  - name: Market Data
  - name: Wallet
  - name: Chat
paths:
  /public/get_funding_rate_value:
    get:
      tags:
        - Market Data
        - Public
      description: >+
        Retrieves the funding rate (interest rate) value for a perpetual
        instrument over a specified time period. Funding rates are periodic
        payments exchanged between long and short positions in perpetual
        contracts.


        This method is applicable only for PERPETUAL instruments. The funding
        rate is typically expressed as a percentage and is used to keep the
        perpetual contract price aligned with the underlying index price.


        [Try in API
        console](https://test.deribit.com/api_console?method=%2Fpublic%2Fget_funding_rate_value)

      parameters:
        - name: instrument_name
          required: true
          in: query
          schema:
            $ref: '#/components/schemas/instrument_name'
          description: Instrument name
        - name: start_timestamp
          required: true
          in: query
          schema:
            $ref: '#/components/schemas/timestamp'
          description: >-
            The earliest timestamp to return result from (milliseconds since the
            UNIX epoch)
        - name: end_timestamp
          required: true
          in: query
          schema:
            $ref: '#/components/schemas/timestamp'
          description: >-
            The most recent timestamp to return result from (milliseconds since
            the UNIX epoch)
      requestBody:
        content:
          application/json:
            examples:
              request:
                value:
                  jsonrpc: '2.0'
                  id: 7617
                  method: public/get_funding_rate_value
                  params:
                    instrument_name: BTC-PERPETUAL
                    start_timestamp: 1569888000000
                    end_timestamp: 1569974400000
                description: JSON-RPC Request Example
        description: JSON-RPC request body
      responses:
        '200':
          $ref: '#/components/responses/PublicGetFundingRateValueResponse'
components:
  schemas:
    instrument_name:
      example: BTC-PERPETUAL
      type: string
      description: Unique instrument identifier
    timestamp:
      example: 1536569522277
      type: integer
      description: The timestamp (milliseconds since the Unix epoch)
    PublicGetFundingRateValueResponse:
      properties:
        jsonrpc:
          type: string
          enum:
            - '2.0'
          description: The JSON-RPC version (2.0)
        id:
          type: integer
          description: The id that was sent in the request
        result:
          type: number
      required:
        - jsonrpc
        - result
      type: object
  responses:
    PublicGetFundingRateValueResponse:
      content:
        application/json:
          schema:
            $ref: '#/components/schemas/PublicGetFundingRateValueResponse'
          examples:
            response:
              value:
                jsonrpc: '2.0'
                id: 7617
                result: -0.00025056853702101664
              description: Response example
      description: Success response

````

 
  
  

<AgentInstructions>

## Submitting Feedback

If you encounter incorrect, outdated, or confusing documentation on this page, submit feedback:

POST https://docs.deribit.com/feedback

```json
{
  "path": "/api-reference/market-data/public-get_historical_volatility",
  "feedback": "Description of the issue"
}
```

Only submit feedback when you have something specific and actionable to report.

</AgentInstructions>

# public/get_historical_volatility

> Provides historical volatility data for a given cryptocurrency. Historical volatility measures the degree of price variation over a past period and is useful for risk assessment and option pricing.

The response includes volatility statistics calculated from historical price movements. This data can be used for portfolio risk analysis and understanding market conditions.

[Try in API console](https://test.deribit.com/api_console?method=%2Fpublic%2Fget_historical_volatility)





## OpenAPI

````yaml /specifications/deribit_openapi.json get /public/get_historical_volatility
openapi: 3.0.0
info:
  title: Deribit API
  version: 2.1.1
servers:
  - url: https://test.deribit.com/api/v2
security: []
tags:
  - name: WebSocket Only
    description: Can only be used over websockets.
  - name: Public
    description: Public methods can be used without authentication.
  - name: Private
    description: >-
      <p>Private methods require authentication. All requests must include a
      valid OAuth2 token.</p>

      <p>A token can be requested using the <a
      href="#public-auth">/public/auth</a> method.</p>

      <p>When using the websockets protocol, the token must be included as a
      parameter <code>access_token</code> in the message. When using REST (HTTP
      GET), the token may also be passed in the <code>Authorization</code>
      header.</p>
  - name: Authentication
  - name: Session Management
  - name: Subscription Management
    description: >-
      Subscription works as [notifications](#notifications), so users will
      automatically (after subscribing) receive messages from the server.
      Overview for each channel response format is described in
      [subscriptions](#subscriptions) section.
  - name: Account Management
  - name: Trading
  - name: Market Data
  - name: Wallet
  - name: Chat
paths:
  /public/get_historical_volatility:
    get:
      tags:
        - Market Data
        - Public
      description: >+
        Provides historical volatility data for a given cryptocurrency.
        Historical volatility measures the degree of price variation over a past
        period and is useful for risk assessment and option pricing.


        The response includes volatility statistics calculated from historical
        price movements. This data can be used for portfolio risk analysis and
        understanding market conditions.


        [Try in API
        console](https://test.deribit.com/api_console?method=%2Fpublic%2Fget_historical_volatility)

      parameters:
        - name: currency
          required: true
          in: query
          schema:
            $ref: '#/components/schemas/currency'
          description: The currency symbol
      requestBody:
        content:
          application/json:
            examples:
              request:
                value:
                  jsonrpc: '2.0'
                  id: 8387
                  method: public/get_historical_volatility
                  params:
                    currency: BTC
                description: JSON-RPC Request Example
        description: JSON-RPC request body
      responses:
        '200':
          $ref: '#/components/responses/PublicGetHistoricalVolatilityResponse'
components:
  schemas:
    currency:
      enum:
        - BTC
        - ETH
        - USDC
        - USDT
        - EURR
      type: string
      description: Currency, i.e `"BTC"`, `"ETH"`, `"USDC"`
    PublicGetHistoricalVolatilityResponse:
      properties:
        jsonrpc:
          type: string
          enum:
            - '2.0'
          description: The JSON-RPC version (2.0)
        id:
          type: integer
          description: The id that was sent in the request
        result:
          type: array
          items:
            type: object
            properties:
              timestamp:
                type: integer
              value:
                type: number
            required:
              - timestamp
              - value
      required:
        - jsonrpc
        - result
      type: object
  responses:
    PublicGetHistoricalVolatilityResponse:
      content:
        application/json:
          schema:
            $ref: '#/components/schemas/PublicGetHistoricalVolatilityResponse'
          examples:
            response:
              value:
                jsonrpc: '2.0'
                id: 8387
                result:
                  - - 1549720800000
                    - 14.747743607344217
                  - - 1549720800000
                    - 14.747743607344217
                  - - 1549724400000
                    - 14.74257778551467
                  - - 1549728000000
                    - 14.73502799931767
                  - - 1549731600000
                    - 14.73502799931767
                  - - 1549735200000
                    - 14.73502799931767
                  - - 1550228400000
                    - 46.371891307340015
              description: Response example
      description: Success response

````

 
  
  

<AgentInstructions>

## Submitting Feedback

If you encounter incorrect, outdated, or confusing documentation on this page, submit feedback:

POST https://docs.deribit.com/feedback

```json
{
  "path": "/api-reference/market-data/public-get_index_price",
  "feedback": "Description of the issue"
}
```

Only submit feedback when you have something specific and actionable to report.

</AgentInstructions>

# public/get_index_price

> Retrieves the current index price value for a given index name. Index prices are used as reference prices for mark price calculations and settlement.

Use `get_index_price_names` or `get_supported_index_names` to retrieve available index names.

[Try in API console](https://test.deribit.com/api_console?method=%2Fpublic%2Fget_index_price)





## OpenAPI

````yaml /specifications/deribit_openapi.json get /public/get_index_price
openapi: 3.0.0
info:
  title: Deribit API
  version: 2.1.1
servers:
  - url: https://test.deribit.com/api/v2
security: []
tags:
  - name: WebSocket Only
    description: Can only be used over websockets.
  - name: Public
    description: Public methods can be used without authentication.
  - name: Private
    description: >-
      <p>Private methods require authentication. All requests must include a
      valid OAuth2 token.</p>

      <p>A token can be requested using the <a
      href="#public-auth">/public/auth</a> method.</p>

      <p>When using the websockets protocol, the token must be included as a
      parameter <code>access_token</code> in the message. When using REST (HTTP
      GET), the token may also be passed in the <code>Authorization</code>
      header.</p>
  - name: Authentication
  - name: Session Management
  - name: Subscription Management
    description: >-
      Subscription works as [notifications](#notifications), so users will
      automatically (after subscribing) receive messages from the server.
      Overview for each channel response format is described in
      [subscriptions](#subscriptions) section.
  - name: Account Management
  - name: Trading
  - name: Market Data
  - name: Wallet
  - name: Chat
paths:
  /public/get_index_price:
    get:
      tags:
        - Market Data
        - Public
      description: >+
        Retrieves the current index price value for a given index name. Index
        prices are used as reference prices for mark price calculations and
        settlement.


        Use `get_index_price_names` or `get_supported_index_names` to retrieve
        available index names.


        [Try in API
        console](https://test.deribit.com/api_console?method=%2Fpublic%2Fget_index_price)

      parameters:
        - name: index_name
          required: true
          in: query
          schema:
            $ref: '#/components/schemas/index_name'
          description: Index identifier, matches (base) cryptocurrency with quote currency
      responses:
        '200':
          $ref: '#/components/responses/PublicGetIndexPriceResponse'
components:
  schemas:
    index_name:
      enum:
        - btc_usd
        - eth_usd
        - ada_usdc
        - algo_usdc
        - avax_usdc
        - bch_usdc
        - bnb_usdc
        - btc_usdc
        - btcdvol_usdc
        - buidl_usdc
        - doge_usdc
        - dot_usdc
        - eurr_usdc
        - eth_usdc
        - ethdvol_usdc
        - link_usdc
        - ltc_usdc
        - near_usdc
        - paxg_usdc
        - shib_usdc
        - sol_usdc
        - steth_usdc
        - ton_usdc
        - trump_usdc
        - trx_usdc
        - uni_usdc
        - usde_usdc
        - usyc_usdc
        - xrp_usdc
        - btc_usdt
        - eth_usdt
        - eurr_usdt
        - sol_usdt
        - steth_usdt
        - usdc_usdt
        - usde_usdt
        - btc_eurr
        - btc_usde
        - btc_usyc
        - eth_btc
        - eth_eurr
        - eth_usde
        - eth_usyc
        - steth_eth
        - paxg_btc
        - drbfix-btc_usdc
        - drbfix-eth_usdc
      type: string
      description: Index identifier, matches (base) cryptocurrency with quote currency
    PublicGetIndexPriceResponse:
      properties:
        jsonrpc:
          type: string
          enum:
            - '2.0'
          description: The JSON-RPC version (2.0)
        id:
          type: integer
          description: The id that was sent in the request
        result:
          properties:
            index_price:
              example: 11628.81
              type: number
              description: Value of requested index
            estimated_delivery_price:
              example: 11628.81
              type: number
              description: >-
                Estimated delivery price for the market. For more details, see
                Documentation > General > Expiration Price
          required:
            - index_price
            - estimated_delivery_price
          type: object
      required:
        - jsonrpc
        - result
      type: object
  responses:
    PublicGetIndexPriceResponse:
      content:
        application/json:
          schema:
            $ref: '#/components/schemas/PublicGetIndexPriceResponse'
      description: Success response

````

 
  
  

<AgentInstructions>

## Submitting Feedback

If you encounter incorrect, outdated, or confusing documentation on this page, submit feedback:

POST https://docs.deribit.com/feedback

```json
{
  "path": "/api-reference/market-data/public-get_index_price_names",
  "feedback": "Description of the issue"
}
```

Only submit feedback when you have something specific and actionable to report.

</AgentInstructions>

# public/get_index_price_names

> Retrieves the identifiers (names) of all supported price indexes. Price indexes are reference prices used for mark price calculations, settlement, and other market operations.

When the `extended` parameter is set to `true`, the response includes additional information such as whether future combo creation and option combo creation are enabled for each index.

[Try in API console](https://test.deribit.com/api_console?method=%2Fpublic%2Fget_index_price_names)





## OpenAPI

````yaml /specifications/deribit_openapi.json get /public/get_index_price_names
openapi: 3.0.0
info:
  title: Deribit API
  version: 2.1.1
servers:
  - url: https://test.deribit.com/api/v2
security: []
tags:
  - name: WebSocket Only
    description: Can only be used over websockets.
  - name: Public
    description: Public methods can be used without authentication.
  - name: Private
    description: >-
      <p>Private methods require authentication. All requests must include a
      valid OAuth2 token.</p>

      <p>A token can be requested using the <a
      href="#public-auth">/public/auth</a> method.</p>

      <p>When using the websockets protocol, the token must be included as a
      parameter <code>access_token</code> in the message. When using REST (HTTP
      GET), the token may also be passed in the <code>Authorization</code>
      header.</p>
  - name: Authentication
  - name: Session Management
  - name: Subscription Management
    description: >-
      Subscription works as [notifications](#notifications), so users will
      automatically (after subscribing) receive messages from the server.
      Overview for each channel response format is described in
      [subscriptions](#subscriptions) section.
  - name: Account Management
  - name: Trading
  - name: Market Data
  - name: Wallet
  - name: Chat
paths:
  /public/get_index_price_names:
    get:
      tags:
        - Market Data
        - Public
      description: >+
        Retrieves the identifiers (names) of all supported price indexes. Price
        indexes are reference prices used for mark price calculations,
        settlement, and other market operations.


        When the `extended` parameter is set to `true`, the response includes
        additional information such as whether future combo creation and option
        combo creation are enabled for each index.


        [Try in API
        console](https://test.deribit.com/api_console?method=%2Fpublic%2Fget_index_price_names)

      parameters:
        - name: extended
          in: query
          required: false
          schema:
            type: boolean
            default: false
            example: true
          description: >-
            When set to `true`, returns additional information including
            `future_combo_creation_enabled` and `option_combo_creation_enabled`
            for each index
      requestBody:
        content:
          application/json:
            examples:
              request:
                value:
                  jsonrpc: '2.0'
                  id: 1
                  method: public/get_index_price_names
                  params:
                    extended: true
                description: JSON-RPC Request Example
        description: JSON-RPC request body
      responses:
        '200':
          $ref: '#/components/responses/PublicGetIndexPriceNamesResponse'
components:
  responses:
    PublicGetIndexPriceNamesResponse:
      content:
        application/json:
          schema:
            $ref: '#/components/schemas/PublicGetIndexPriceNamesResponse'
          examples:
            response:
              value:
                jsonrpc: '2.0'
                id: 25718
                result:
                  - btc_eth
                  - btc_usdc
                  - eth_usdc
              description: Response example
      description: Success response
  schemas:
    PublicGetIndexPriceNamesResponse:
      properties:
        jsonrpc:
          type: string
          enum:
            - '2.0'
          description: The JSON-RPC version (2.0)
        id:
          type: integer
          description: The id that was sent in the request
        result:
          type: array
          items:
            type: object
            properties:
              name:
                type: string
                description: Index name
              future_combo_creation_enabled:
                type: boolean
                description: >-
                  Whether future combo creation is enabled for this index (only
                  present when `extended`=`true`)
              option_combo_creation_enabled:
                type: boolean
                description: >-
                  Whether option combo creation is enabled for this index (only
                  present when `extended`=`true`)
            required:
              - name
      required:
        - jsonrpc
        - result
      type: object

````

 
  
  

<AgentInstructions>

## Submitting Feedback

If you encounter incorrect, outdated, or confusing documentation on this page, submit feedback:

POST https://docs.deribit.com/feedback

```json
{
  "path": "/api-reference/market-data/public-get_index_price_names",
  "feedback": "Description of the issue"
}
```

Only submit feedback when you have something specific and actionable to report.

</AgentInstructions>

# public/get_index_price_names

> Retrieves the identifiers (names) of all supported price indexes. Price indexes are reference prices used for mark price calculations, settlement, and other market operations.

When the `extended` parameter is set to `true`, the response includes additional information such as whether future combo creation and option combo creation are enabled for each index.

[Try in API console](https://test.deribit.com/api_console?method=%2Fpublic%2Fget_index_price_names)





## OpenAPI

````yaml /specifications/deribit_openapi.json get /public/get_index_price_names
openapi: 3.0.0
info:
  title: Deribit API
  version: 2.1.1
servers:
  - url: https://test.deribit.com/api/v2
security: []
tags:
  - name: WebSocket Only
    description: Can only be used over websockets.
  - name: Public
    description: Public methods can be used without authentication.
  - name: Private
    description: >-
      <p>Private methods require authentication. All requests must include a
      valid OAuth2 token.</p>

      <p>A token can be requested using the <a
      href="#public-auth">/public/auth</a> method.</p>

      <p>When using the websockets protocol, the token must be included as a
      parameter <code>access_token</code> in the message. When using REST (HTTP
      GET), the token may also be passed in the <code>Authorization</code>
      header.</p>
  - name: Authentication
  - name: Session Management
  - name: Subscription Management
    description: >-
      Subscription works as [notifications](#notifications), so users will
      automatically (after subscribing) receive messages from the server.
      Overview for each channel response format is described in
      [subscriptions](#subscriptions) section.
  - name: Account Management
  - name: Trading
  - name: Market Data
  - name: Wallet
  - name: Chat
paths:
  /public/get_index_price_names:
    get:
      tags:
        - Market Data
        - Public
      description: >+
        Retrieves the identifiers (names) of all supported price indexes. Price
        indexes are reference prices used for mark price calculations,
        settlement, and other market operations.


        When the `extended` parameter is set to `true`, the response includes
        additional information such as whether future combo creation and option
        combo creation are enabled for each index.


        [Try in API
        console](https://test.deribit.com/api_console?method=%2Fpublic%2Fget_index_price_names)

      parameters:
        - name: extended
          in: query
          required: false
          schema:
            type: boolean
            default: false
            example: true
          description: >-
            When set to `true`, returns additional information including
            `future_combo_creation_enabled` and `option_combo_creation_enabled`
            for each index
      requestBody:
        content:
          application/json:
            examples:
              request:
                value:
                  jsonrpc: '2.0'
                  id: 1
                  method: public/get_index_price_names
                  params:
                    extended: true
                description: JSON-RPC Request Example
        description: JSON-RPC request body
      responses:
        '200':
          $ref: '#/components/responses/PublicGetIndexPriceNamesResponse'
components:
  responses:
    PublicGetIndexPriceNamesResponse:
      content:
        application/json:
          schema:
            $ref: '#/components/schemas/PublicGetIndexPriceNamesResponse'
          examples:
            response:
              value:
                jsonrpc: '2.0'
                id: 25718
                result:
                  - btc_eth
                  - btc_usdc
                  - eth_usdc
              description: Response example
      description: Success response
  schemas:
    PublicGetIndexPriceNamesResponse:
      properties:
        jsonrpc:
          type: string
          enum:
            - '2.0'
          description: The JSON-RPC version (2.0)
        id:
          type: integer
          description: The id that was sent in the request
        result:
          type: array
          items:
            type: object
            properties:
              name:
                type: string
                description: Index name
              future_combo_creation_enabled:
                type: boolean
                description: >-
                  Whether future combo creation is enabled for this index (only
                  present when `extended`=`true`)
              option_combo_creation_enabled:
                type: boolean
                description: >-
                  Whether option combo creation is enabled for this index (only
                  present when `extended`=`true`)
            required:
              - name
      required:
        - jsonrpc
        - result
      type: object

````

 
  
  

<AgentInstructions>

## Submitting Feedback

If you encounter incorrect, outdated, or confusing documentation on this page, submit feedback:

POST https://docs.deribit.com/feedback

```json
{
  "path": "/api-reference/market-data/public-get_instruments",
  "feedback": "Description of the issue"
}
```

Only submit feedback when you have something specific and actionable to report.

</AgentInstructions>

# public/get_instruments

> Retrieves available trading instruments. This method can be used to see which instruments are available for trading, or which instruments have recently expired.

**Note - This method has distinct API rate limiting requirements:** Sustained rate: 1 request/second. To avoid rate limits, we recommend using either the REST requests for server-cached data or the WebSocket subscription to [instrument_state.{kind}.{currency}](https://docs.deribit.com/api-reference/subscription-channels/instrument-state-kind-currency) for real-time updates. For more information, see [Rate Limits](https://support.deribit.com/hc/en-us/articles/25944617523357-Rate-Limits).

Results can be filtered by currency and instrument kind (future, option, etc.). Set the `expired` parameter to `true` to retrieve recently expired instruments instead of active ones.

[Try in API console](https://test.deribit.com/api_console?method=%2Fpublic%2Fget_instruments)





## OpenAPI

````yaml /specifications/deribit_openapi.json get /public/get_instruments
openapi: 3.0.0
info:
  title: Deribit API
  version: 2.1.1
servers:
  - url: https://test.deribit.com/api/v2
security: []
tags:
  - name: WebSocket Only
    description: Can only be used over websockets.
  - name: Public
    description: Public methods can be used without authentication.
  - name: Private
    description: >-
      <p>Private methods require authentication. All requests must include a
      valid OAuth2 token.</p>

      <p>A token can be requested using the <a
      href="#public-auth">/public/auth</a> method.</p>

      <p>When using the websockets protocol, the token must be included as a
      parameter <code>access_token</code> in the message. When using REST (HTTP
      GET), the token may also be passed in the <code>Authorization</code>
      header.</p>
  - name: Authentication
  - name: Session Management
  - name: Subscription Management
    description: >-
      Subscription works as [notifications](#notifications), so users will
      automatically (after subscribing) receive messages from the server.
      Overview for each channel response format is described in
      [subscriptions](#subscriptions) section.
  - name: Account Management
  - name: Trading
  - name: Market Data
  - name: Wallet
  - name: Chat
paths:
  /public/get_instruments:
    get:
      tags:
        - Market Data
        - Public
      description: >+
        Retrieves available trading instruments. This method can be used to see
        which instruments are available for trading, or which instruments have
        recently expired.


        **Note - This method has distinct API rate limiting requirements:**
        Sustained rate: 1 request/second. To avoid rate limits, we recommend
        using either the REST requests for server-cached data or the WebSocket
        subscription to
        [instrument_state.{kind}.{currency}](https://docs.deribit.com/api-reference/subscription-channels/instrument-state-kind-currency)
        for real-time updates. For more information, see [Rate
        Limits](https://support.deribit.com/hc/en-us/articles/25944617523357-Rate-Limits).


        Results can be filtered by currency and instrument kind (future, option,
        etc.). Set the `expired` parameter to `true` to retrieve recently
        expired instruments instead of active ones.


        [Try in API
        console](https://test.deribit.com/api_console?method=%2Fpublic%2Fget_instruments)

      parameters:
        - name: currency
          required: true
          in: query
          schema:
            $ref: '#/components/schemas/currency_with_any'
          description: The currency symbol or `"any"` for all
        - name: kind
          required: false
          in: query
          schema:
            $ref: '#/components/schemas/kind'
          description: >-
            Instrument kind, if not provided instruments of all kinds are
            considered
        - name: expired
          in: query
          schema:
            type: boolean
            default: false
          description: >-
            Set to true to show recently expired instruments instead of active
            ones.
          required: false
      requestBody:
        content:
          application/json:
            examples:
              request:
                value:
                  jsonrpc: '2.0'
                  id: 1
                  method: public/get_instruments
                  params:
                    currency: BTC
                    kind: future
                description: JSON-RPC Request Example
        description: JSON-RPC request body
      responses:
        '200':
          $ref: '#/components/responses/PublicGetInstrumentsResponse'
components:
  schemas:
    currency_with_any:
      enum:
        - BTC
        - ETH
        - USDC
        - USDT
        - EURR
        - any
      type: string
      description: Currency name or `"any"` if don't care
    kind:
      enum:
        - future
        - option
        - spot
        - future_combo
        - option_combo
      type: string
      description: >-
        Instrument kind: `"future"`, `"option"`, `"spot"`, `"future_combo"`,
        `"option_combo"`
    PublicGetInstrumentsResponse:
      properties:
        jsonrpc:
          type: string
          enum:
            - '2.0'
          description: The JSON-RPC version (2.0)
        id:
          type: integer
          description: The id that was sent in the request
        result:
          type: array
          items:
            $ref: '#/components/schemas/instrument'
      required:
        - jsonrpc
        - result
      type: object
    instrument:
      properties:
        kind:
          $ref: '#/components/schemas/kind'
        settlement_currency:
          type: string
          enum:
            - BTC
            - ETH
          description: >-
            Optional (not added for spot). Settlement currency for the
            instrument.
        counter_currency:
          type: string
          enum:
            - USD
            - USDC
          description: Counter currency for the instrument.
        base_currency:
          type: string
          enum:
            - BTC
            - ETH
          description: The underlying currency being traded.
        quote_currency:
          type: string
          enum:
            - USD
          description: The currency in which the instrument prices are quoted.
        min_trade_amount:
          type: number
          example: 0.1
          description: >-
            Minimum amount for trading. For perpetual and inverse futures the
            amount is in USD units. For options and linear futures it is the
            underlying base currency coin.
        instrument_name:
          $ref: '#/components/schemas/instrument_name'
        instrument_id:
          $ref: '#/components/schemas/instrument_id'
        is_active:
          type: boolean
          description: Indicates if the instrument can currently be traded.
        settlement_period:
          type: string
          enum:
            - month
            - week
            - perpetual
          description: Optional (not added for spot). The settlement period.
        creation_timestamp:
          type: integer
          example: 1536569522277
          description: >-
            The time when the instrument was first created (milliseconds since
            the UNIX epoch).
        tick_size:
          type: number
          example: 0.0001
          description: >-
            Specifies minimal price change and, as follows, the number of
            decimal places for instrument prices.
        tick_size_steps:
          $ref: '#/components/schemas/tick_size_step'
        expiration_timestamp:
          type: integer
          description: >-
            The time when the instrument will expire (milliseconds since the
            UNIX epoch).
        strike:
          type: number
          description: The strike value (only for options).
        option_type:
          type: string
          enum:
            - call
            - put
          description: The option type (only for options).
        future_type:
          type: string
          enum:
            - linear
            - reversed
          description: >-
            Future type (only for futures)(field is deprecated and will be
            removed in the future, `instrument_type` should be used instead).
        instrument_type:
          type: string
          description: Type of the instrument. `linear` or `reversed`
        contract_size:
          type: integer
          example: 1
          description: Contract size for instrument.
        maker_commission:
          type: number
          example: 0.0001
          description: Maker commission for instrument.
        taker_commission:
          type: number
          example: 0.0005
          description: Taker commission for instrument.
        max_liquidation_commission:
          type: number
          example: 0.001
          description: >-
            Maximal liquidation trade commission for instrument (only for
            futures).
        block_trade_commission:
          type: number
          example: 0.0005
          description: Block Trade commission for instrument.
        block_trade_tick_size:
          type: number
          example: 0.01
          description: Specifies minimal price change for block trading.
        block_trade_min_trade_amount:
          type: number
          example: 25
          description: Minimum amount for block trading.
        max_leverage:
          type: integer
          example: 100
          description: Maximal leverage for instrument (only for futures).
        price_index:
          $ref: '#/components/schemas/price_index'
        state:
          $ref: '#/components/schemas/book_state'
      required:
        - kind
        - base_currency
        - quote_currency
        - min_trade_amount
        - instrument_name
        - is_active
        - settlement_period
        - creation_timestamp
        - tick_size
        - expiration_timestamp
        - contract_size
        - price_index
      type: object
    instrument_name:
      example: BTC-PERPETUAL
      type: string
      description: Unique instrument identifier
    instrument_id:
      type: integer
      description: Instrument ID
    tick_size_step:
      properties:
        above_price:
          type: number
          description: The price from which the increased tick size applies
        tick_size:
          type: number
          description: >-
            Tick size to be used above the price. It must be multiple of the
            minimum tick size.
      type: object
    price_index:
      example: btc_usdc
      type: string
      description: Name of price index that is used for this instrument
    book_state:
      enum:
        - open
        - settlement
        - delivered
        - inactive
        - locked
        - halted
        - archivized
      type: string
      description: >
        The state of the order book. Represents the current lifecycle stage of
        the instrument.


        **State Lifecycle and Meanings:**


        - `open`: Default state for running books. In this state book is
        accepting new orders, edits, cancels; prices should be updated, trading
        is live.

        - `settlement`: Books enters to this state during settlement/delivery.
        New orders, edits, cancels are not accepted. After this state normally
        next state should be `open` if it was settlement, or `delivered` if it
        was delivery. On enter to this state good till day orders in book are
        canceled.

        - `delivered`: Final state of book that has been delivered. New orders,
        edits, cancels are not accepted. After some time book process will be
        terminated and, instrument moved to `expired_instruments` and its
        `instrument_state` will become archivized. On enter to this all open
        orders in book are canceled.

        - `inactive`: After a book is deactivated, this state is set on book.
        New orders, edits, cancels are not accepted. On enter to this all open
        orders in book are canceled. Book in this state is not considered as
        open. This can be also final state for book.

        - `locked`: New orders, edits, are not accepted, only cancels ARE
        accepted. In some cases when configured books can start as locked or it
        may become locked on admin request. Settlement is possible on locked
        books.

        - `halted`: The state that books enter as a result of an error.
        Settlement is not possible when there is at least one book in this
        state.

        - `archivized`: Set when instrument is moved to `expired_instruments`
        table, final state.
  responses:
    PublicGetInstrumentsResponse:
      content:
        application/json:
          schema:
            $ref: '#/components/schemas/PublicGetInstrumentsResponse'
          examples:
            response:
              value:
                jsonrpc: '2.0'
                id: 1
                result:
                  - tick_size: 2.5
                    tick_size_steps: []
                    taker_commission: 0.0005
                    settlement_period: month
                    settlement_currency: BTC
                    quote_currency: USD
                    price_index: btc_usd
                    min_trade_amount: 10
                    max_liquidation_commission: 0.0075
                    max_leverage: 50
                    maker_commission: 0
                    kind: future
                    is_active: true
                    instrument_name: BTC-29SEP23
                    instrument_id: 138583
                    instrument_type: reversed
                    expiration_timestamp: 1695974400000
                    creation_timestamp: 1664524802000
                    counter_currency: USD
                    contract_size: 10
                    block_trade_tick_size: 0.01
                    block_trade_min_trade_amount: 200000
                    block_trade_commission: 0.00025
                    base_currency: BTC
                    state: open
                  - tick_size: 0.5
                    tick_size_steps: []
                    taker_commission: 0.0005
                    settlement_period: perpetual
                    settlement_currency: BTC
                    quote_currency: USD
                    price_index: btc_usd
                    min_trade_amount: 10
                    max_liquidation_commission: 0.0075
                    max_leverage: 50
                    maker_commission: 0
                    kind: future
                    is_active: true
                    instrument_name: BTC-PERPETUAL
                    instrument_id: 124972
                    instrument_type: reversed
                    expiration_timestamp: 32503708800000
                    creation_timestamp: 1534167754000
                    counter_currency: USD
                    contract_size: 10
                    block_trade_tick_size: 0.01
                    block_trade_min_trade_amount: 200000
                    block_trade_commission: 0.00025
                    base_currency: BTC
                    state: open
              description: Response example
      description: Success response

````

 
  
  

<AgentInstructions>

## Submitting Feedback

If you encounter incorrect, outdated, or confusing documentation on this page, submit feedback:

POST https://docs.deribit.com/feedback

```json
{
  "path": "/api-reference/market-data/public-get_last_settlements_by_currency",
  "feedback": "Description of the issue"
}
```

Only submit feedback when you have something specific and actionable to report.

</AgentInstructions>

# public/get_last_settlements_by_currency

> Retrieves historical settlement, delivery, and bankruptcy events from all instruments within a given currency. Settlements occur when futures or options contracts expire and are settled at the delivery price.

Results can be filtered by settlement type and timestamp. Use pagination parameters (`count` and `continuation`) to retrieve large settlement histories. This data is useful for analyzing historical contract settlements and understanding market events.

[Try in API console](https://test.deribit.com/api_console?method=%2Fpublic%2Fget_last_settlements_by_currency)





## OpenAPI

````yaml /specifications/deribit_openapi.json get /public/get_last_settlements_by_currency
openapi: 3.0.0
info:
  title: Deribit API
  version: 2.1.1
servers:
  - url: https://test.deribit.com/api/v2
security: []
tags:
  - name: WebSocket Only
    description: Can only be used over websockets.
  - name: Public
    description: Public methods can be used without authentication.
  - name: Private
    description: >-
      <p>Private methods require authentication. All requests must include a
      valid OAuth2 token.</p>

      <p>A token can be requested using the <a
      href="#public-auth">/public/auth</a> method.</p>

      <p>When using the websockets protocol, the token must be included as a
      parameter <code>access_token</code> in the message. When using REST (HTTP
      GET), the token may also be passed in the <code>Authorization</code>
      header.</p>
  - name: Authentication
  - name: Session Management
  - name: Subscription Management
    description: >-
      Subscription works as [notifications](#notifications), so users will
      automatically (after subscribing) receive messages from the server.
      Overview for each channel response format is described in
      [subscriptions](#subscriptions) section.
  - name: Account Management
  - name: Trading
  - name: Market Data
  - name: Wallet
  - name: Chat
paths:
  /public/get_last_settlements_by_currency:
    get:
      tags:
        - Market Data
        - Public
      description: >+
        Retrieves historical settlement, delivery, and bankruptcy events from
        all instruments within a given currency. Settlements occur when futures
        or options contracts expire and are settled at the delivery price.


        Results can be filtered by settlement type and timestamp. Use pagination
        parameters (`count` and `continuation`) to retrieve large settlement
        histories. This data is useful for analyzing historical contract
        settlements and understanding market events.


        [Try in API
        console](https://test.deribit.com/api_console?method=%2Fpublic%2Fget_last_settlements_by_currency)

      parameters:
        - name: currency
          required: true
          in: query
          schema:
            $ref: '#/components/schemas/currency'
          description: The currency symbol
        - in: query
          name: type
          required: false
          schema:
            $ref: '#/components/schemas/settlement_type'
          description: Settlement type
        - name: count
          required: false
          in: query
          schema:
            type: integer
            maximum: 1000
            minimum: 1
          description: Number of requested items, default - `20`, maximum - `1000`
        - name: continuation
          in: query
          required: false
          schema:
            type: string
            example: xY7T6cutS3t2B9YtaDkE6TS379oKnkzTvmEDUnEUP2Msa9xKWNNaT
          description: Continuation token for pagination
        - in: query
          name: search_start_timestamp
          required: false
          schema:
            $ref: '#/components/schemas/timestamp'
          description: >-
            The latest timestamp to return result from (milliseconds since the
            UNIX epoch)
      requestBody:
        content:
          application/json:
            examples:
              request:
                value:
                  jsonrpc: '2.0'
                  id: 4497
                  method: public/get_last_settlements_by_currency
                  params:
                    currency: BTC
                    type: delivery
                    count: 2
                description: JSON-RPC Request Example
        description: JSON-RPC request body
      responses:
        '200':
          $ref: '#/components/responses/PublicSettlementResponse'
components:
  schemas:
    currency:
      enum:
        - BTC
        - ETH
        - USDC
        - USDT
        - EURR
      type: string
      description: Currency, i.e `"BTC"`, `"ETH"`, `"USDC"`
    settlement_type:
      enum:
        - settlement
        - delivery
        - bankruptcy
      type: string
      description: The type of settlement. `settlement`, `delivery` or `bankruptcy`.
    timestamp:
      example: 1536569522277
      type: integer
      description: The timestamp (milliseconds since the Unix epoch)
    PublicSettlementResponse:
      properties:
        jsonrpc:
          type: string
          enum:
            - '2.0'
          description: The JSON-RPC version (2.0)
        id:
          type: integer
          description: The id that was sent in the request
        result:
          properties:
            continuation:
              $ref: '#/components/schemas/continuation'
            settlements:
              type: array
              items:
                $ref: '#/components/schemas/settlement'
          required:
            - continuation
            - settlements
          type: object
      required:
        - jsonrpc
        - result
      type: object
    continuation:
      example: xY7T6cutS3t2B9YtaDkE6TS379oKnkzTvmEDUnEUP2Msa9xKWNNaT
      type: string
      description: Continuation token for pagination.
    settlement:
      properties:
        funding:
          example: -0.000002511
          type: number
          description: funding (in base currency ; settlement for perpetual product only)
        funded:
          example: 0
          type: number
          description: funded amount (bankruptcy only)
        index_price:
          example: 11008.37
          type: number
          description: >-
            underlying index price at time of event (in quote currency;
            settlement and delivery only)
        instrument_name:
          example: BTC-30MAR18
          type: string
          description: instrument name (settlement and delivery only)
        mark_price:
          example: 11000
          type: number
          description: >-
            mark price for at the settlement time (in quote currency; settlement
            and delivery only)
        position:
          example: 1000
          type: number
          description: position size (in quote currency; settlement and delivery only)
        profit_loss:
          example: 0
          type: number
          description: profit and loss (in base currency; settlement and delivery only)
        session_bankruptcy:
          example: 0.001160788
          type: number
          description: value of session bankruptcy (in base currency; bankruptcy only)
        session_profit_loss:
          example: 0.001160788
          type: number
          description: total value of session profit and losses (in base currency)
        session_tax:
          example: -0.001160788
          type: number
          description: total amount of paid taxes/fees (in base currency; bankruptcy only)
        session_tax_rate:
          example: 0.000103333
          type: number
          description: rate of paid taxes/fees (in base currency; bankruptcy only)
        socialized:
          example: -0.001160788
          type: number
          description: >-
            the amount of the socialized losses (in base currency; bankruptcy
            only)
        timestamp:
          $ref: '#/components/schemas/timestamp'
        type:
          $ref: '#/components/schemas/settlement_type'
      required:
        - type
        - timestamp
        - session_profit_loss
        - position
        - instrument_name
        - index_price
        - funding
      type: object
  responses:
    PublicSettlementResponse:
      content:
        application/json:
          schema:
            $ref: '#/components/schemas/PublicSettlementResponse'
          examples:
            response:
              value:
                jsonrpc: '2.0'
                id: 5482
                result:
                  settlements:
                    - type: settlement
                      timestamp: 1550502000023
                      session_profit_loss: 0.116509752
                      profit_loss: -9.999999999886402e-10
                      position: 240
                      mark_price: 3578.16
                      instrument_name: BTC-22FEB19
                      index_price: 3796.43
                  continuation: >-
                    2Z7mdtavzYvfuyYcHkJXvPTr9ZSMsEzM3sLCH7AbYEDd1AzTXY2hnhegQDiaP1TtU4b5iSJZ4
              description: Response example
      description: Success response

````

 
  
  

<AgentInstructions>

## Submitting Feedback

If you encounter incorrect, outdated, or confusing documentation on this page, submit feedback:

POST https://docs.deribit.com/feedback

```json
{
  "path": "/api-reference/market-data/public-get_last_settlements_by_instrument",
  "feedback": "Description of the issue"
}
```

Only submit feedback when you have something specific and actionable to report.

</AgentInstructions>

# public/get_last_settlements_by_instrument

> Retrieves historical settlement, delivery, and bankruptcy events for a specific instrument. Settlements occur when futures or options contracts expire and are settled at the delivery price.

Results can be filtered by settlement type and timestamp. Use pagination parameters (`count` and `continuation`) to retrieve large settlement histories. This method is useful for tracking settlement history for a specific instrument.

[Try in API console](https://test.deribit.com/api_console?method=%2Fpublic%2Fget_last_settlements_by_instrument)





## OpenAPI

````yaml /specifications/deribit_openapi.json get /public/get_last_settlements_by_instrument
openapi: 3.0.0
info:
  title: Deribit API
  version: 2.1.1
servers:
  - url: https://test.deribit.com/api/v2
security: []
tags:
  - name: WebSocket Only
    description: Can only be used over websockets.
  - name: Public
    description: Public methods can be used without authentication.
  - name: Private
    description: >-
      <p>Private methods require authentication. All requests must include a
      valid OAuth2 token.</p>

      <p>A token can be requested using the <a
      href="#public-auth">/public/auth</a> method.</p>

      <p>When using the websockets protocol, the token must be included as a
      parameter <code>access_token</code> in the message. When using REST (HTTP
      GET), the token may also be passed in the <code>Authorization</code>
      header.</p>
  - name: Authentication
  - name: Session Management
  - name: Subscription Management
    description: >-
      Subscription works as [notifications](#notifications), so users will
      automatically (after subscribing) receive messages from the server.
      Overview for each channel response format is described in
      [subscriptions](#subscriptions) section.
  - name: Account Management
  - name: Trading
  - name: Market Data
  - name: Wallet
  - name: Chat
paths:
  /public/get_last_settlements_by_instrument:
    get:
      tags:
        - Market Data
        - Public
      description: >+
        Retrieves historical settlement, delivery, and bankruptcy events for a
        specific instrument. Settlements occur when futures or options contracts
        expire and are settled at the delivery price.


        Results can be filtered by settlement type and timestamp. Use pagination
        parameters (`count` and `continuation`) to retrieve large settlement
        histories. This method is useful for tracking settlement history for a
        specific instrument.


        [Try in API
        console](https://test.deribit.com/api_console?method=%2Fpublic%2Fget_last_settlements_by_instrument)

      parameters:
        - name: instrument_name
          required: true
          in: query
          schema:
            $ref: '#/components/schemas/instrument_name'
          description: Instrument name
        - in: query
          name: type
          required: false
          schema:
            $ref: '#/components/schemas/settlement_type'
          description: Settlement type
        - name: count
          required: false
          in: query
          schema:
            type: integer
            maximum: 1000
            minimum: 1
          description: Number of requested items, default - `20`, maximum - `1000`
        - name: continuation
          in: query
          required: false
          schema:
            type: string
            example: xY7T6cutS3t2B9YtaDkE6TS379oKnkzTvmEDUnEUP2Msa9xKWNNaT
          description: Continuation token for pagination
        - in: query
          name: search_start_timestamp
          required: false
          schema:
            $ref: '#/components/schemas/timestamp'
          description: >-
            The latest timestamp to return result from (milliseconds since the
            UNIX epoch)
      requestBody:
        content:
          application/json:
            examples:
              request:
                value:
                  jsonrpc: '2.0'
                  id: 5482
                  method: public/get_last_settlements_by_instrument
                  params:
                    instrument_name: BTC-22FEB19
                    type: settlement
                    count: 1
                description: JSON-RPC Request Example
        description: JSON-RPC request body
      responses:
        '200':
          $ref: '#/components/responses/PublicSettlementResponse'
components:
  schemas:
    instrument_name:
      example: BTC-PERPETUAL
      type: string
      description: Unique instrument identifier
    settlement_type:
      enum:
        - settlement
        - delivery
        - bankruptcy
      type: string
      description: The type of settlement. `settlement`, `delivery` or `bankruptcy`.
    timestamp:
      example: 1536569522277
      type: integer
      description: The timestamp (milliseconds since the Unix epoch)
    PublicSettlementResponse:
      properties:
        jsonrpc:
          type: string
          enum:
            - '2.0'
          description: The JSON-RPC version (2.0)
        id:
          type: integer
          description: The id that was sent in the request
        result:
          properties:
            continuation:
              $ref: '#/components/schemas/continuation'
            settlements:
              type: array
              items:
                $ref: '#/components/schemas/settlement'
          required:
            - continuation
            - settlements
          type: object
      required:
        - jsonrpc
        - result
      type: object
    continuation:
      example: xY7T6cutS3t2B9YtaDkE6TS379oKnkzTvmEDUnEUP2Msa9xKWNNaT
      type: string
      description: Continuation token for pagination.
    settlement:
      properties:
        funding:
          example: -0.000002511
          type: number
          description: funding (in base currency ; settlement for perpetual product only)
        funded:
          example: 0
          type: number
          description: funded amount (bankruptcy only)
        index_price:
          example: 11008.37
          type: number
          description: >-
            underlying index price at time of event (in quote currency;
            settlement and delivery only)
        instrument_name:
          example: BTC-30MAR18
          type: string
          description: instrument name (settlement and delivery only)
        mark_price:
          example: 11000
          type: number
          description: >-
            mark price for at the settlement time (in quote currency; settlement
            and delivery only)
        position:
          example: 1000
          type: number
          description: position size (in quote currency; settlement and delivery only)
        profit_loss:
          example: 0
          type: number
          description: profit and loss (in base currency; settlement and delivery only)
        session_bankruptcy:
          example: 0.001160788
          type: number
          description: value of session bankruptcy (in base currency; bankruptcy only)
        session_profit_loss:
          example: 0.001160788
          type: number
          description: total value of session profit and losses (in base currency)
        session_tax:
          example: -0.001160788
          type: number
          description: total amount of paid taxes/fees (in base currency; bankruptcy only)
        session_tax_rate:
          example: 0.000103333
          type: number
          description: rate of paid taxes/fees (in base currency; bankruptcy only)
        socialized:
          example: -0.001160788
          type: number
          description: >-
            the amount of the socialized losses (in base currency; bankruptcy
            only)
        timestamp:
          $ref: '#/components/schemas/timestamp'
        type:
          $ref: '#/components/schemas/settlement_type'
      required:
        - type
        - timestamp
        - session_profit_loss
        - position
        - instrument_name
        - index_price
        - funding
      type: object
  responses:
    PublicSettlementResponse:
      content:
        application/json:
          schema:
            $ref: '#/components/schemas/PublicSettlementResponse'
          examples:
            response:
              value:
                jsonrpc: '2.0'
                id: 5482
                result:
                  settlements:
                    - type: settlement
                      timestamp: 1550502000023
                      session_profit_loss: 0.116509752
                      profit_loss: -9.999999999886402e-10
                      position: 240
                      mark_price: 3578.16
                      instrument_name: BTC-22FEB19
                      index_price: 3796.43
                  continuation: >-
                    2Z7mdtavzYvfuyYcHkJXvPTr9ZSMsEzM3sLCH7AbYEDd1AzTXY2hnhegQDiaP1TtU4b5iSJZ4
              description: Response example
      description: Success response

````

 
  
  

<AgentInstructions>

## Submitting Feedback

If you encounter incorrect, outdated, or confusing documentation on this page, submit feedback:

POST https://docs.deribit.com/feedback

```json
{
  "path": "/api-reference/market-data/public-get_last_trades_by_currency",
  "feedback": "Description of the issue"
}
```

Only submit feedback when you have something specific and actionable to report.

</AgentInstructions>

# public/get_last_trades_by_currency

> Retrieves the latest trades that have occurred for instruments in a specific currency. Returns trade details including price, amount, direction, timestamp, and trade ID for all instruments in the currency.

Results can be filtered by instrument kind and trade ID range or timestamp range. Use the `count` parameter to limit the number of trades returned, and `sorting` to control the order (ascending or descending by trade ID).

[Try in API console](https://test.deribit.com/api_console?method=%2Fpublic%2Fget_last_trades_by_currency)





## OpenAPI

````yaml /specifications/deribit_openapi.json get /public/get_last_trades_by_currency
openapi: 3.0.0
info:
  title: Deribit API
  version: 2.1.1
servers:
  - url: https://test.deribit.com/api/v2
security: []
tags:
  - name: WebSocket Only
    description: Can only be used over websockets.
  - name: Public
    description: Public methods can be used without authentication.
  - name: Private
    description: >-
      <p>Private methods require authentication. All requests must include a
      valid OAuth2 token.</p>

      <p>A token can be requested using the <a
      href="#public-auth">/public/auth</a> method.</p>

      <p>When using the websockets protocol, the token must be included as a
      parameter <code>access_token</code> in the message. When using REST (HTTP
      GET), the token may also be passed in the <code>Authorization</code>
      header.</p>
  - name: Authentication
  - name: Session Management
  - name: Subscription Management
    description: >-
      Subscription works as [notifications](#notifications), so users will
      automatically (after subscribing) receive messages from the server.
      Overview for each channel response format is described in
      [subscriptions](#subscriptions) section.
  - name: Account Management
  - name: Trading
  - name: Market Data
  - name: Wallet
  - name: Chat
paths:
  /public/get_last_trades_by_currency:
    get:
      tags:
        - Market Data
        - Public
      description: >+
        Retrieves the latest trades that have occurred for instruments in a
        specific currency. Returns trade details including price, amount,
        direction, timestamp, and trade ID for all instruments in the currency.


        Results can be filtered by instrument kind and trade ID range or
        timestamp range. Use the `count` parameter to limit the number of trades
        returned, and `sorting` to control the order (ascending or descending by
        trade ID).


        [Try in API
        console](https://test.deribit.com/api_console?method=%2Fpublic%2Fget_last_trades_by_currency)

      parameters:
        - name: currency
          required: true
          in: query
          schema:
            $ref: '#/components/schemas/currency'
          description: The currency symbol
        - name: kind
          required: false
          in: query
          schema:
            $ref: '#/components/schemas/kind_with_combo_all'
          description: >-
            Instrument kind, `"combo"` for any combo or `"any"` for all. If not
            provided instruments of all kinds are considered
        - name: start_id
          required: false
          in: query
          schema:
            $ref: '#/components/schemas/trade_id'
          description: >-
            The ID of the first trade to be returned. Number for BTC trades, or
            hyphen name in ex. `"ETH-15"` # `"ETH_USDC-16"`
        - name: end_id
          required: false
          in: query
          schema:
            $ref: '#/components/schemas/trade_id'
          description: >-
            The ID of the last trade to be returned. Number for BTC trades, or
            hyphen name in ex. `"ETH-15"` # `"ETH_USDC-16"`
        - name: start_timestamp
          required: false
          in: query
          schema:
            $ref: '#/components/schemas/timestamp'
          description: >-
            The earliest timestamp to return result from (milliseconds since the
            UNIX epoch). When param is provided trades are returned from the
            earliest
        - name: end_timestamp
          required: false
          in: query
          schema:
            $ref: '#/components/schemas/timestamp'
          description: >-
            The most recent timestamp to return result from (milliseconds since
            the UNIX epoch). Only one of params: start_timestamp, end_timestamp
            is truly required
        - name: count
          required: false
          in: query
          schema:
            type: integer
            maximum: 1000
            minimum: 1
          description: Number of requested items, default - `10`, maximum - `1000`
        - name: sorting
          required: false
          in: query
          schema:
            $ref: '#/components/schemas/sorting'
          description: >-
            Direction of results sorting (`default` value means no sorting,
            results will be returned in order in which they left the database)
      requestBody:
        content:
          application/json:
            examples:
              request:
                value:
                  jsonrpc: '2.0'
                  id: 9290
                  method: public/get_last_trades_by_currency
                  params:
                    currency: BTC
                    count: 3
                description: JSON-RPC Request Example
        description: JSON-RPC request body
      responses:
        '200':
          $ref: '#/components/responses/PublicTradesHistoryResponse'
components:
  schemas:
    currency:
      enum:
        - BTC
        - ETH
        - USDC
        - USDT
        - EURR
      type: string
      description: Currency, i.e `"BTC"`, `"ETH"`, `"USDC"`
    kind_with_combo_all:
      enum:
        - future
        - option
        - spot
        - future_combo
        - option_combo
        - combo
        - any
      type: string
      description: >-
        Instrument kind: `"future"`, `"option"`, `"spot"`, `"future_combo"`,
        `"option_combo"`, `"combo"` for any combo or `"any"` for all
    trade_id:
      type: string
      description: Unique (per currency) trade identifier
    timestamp:
      example: 1536569522277
      type: integer
      description: The timestamp (milliseconds since the Unix epoch)
    sorting:
      enum:
        - asc
        - desc
        - default
      type: string
    PublicTradesHistoryResponse:
      properties:
        jsonrpc:
          type: string
          enum:
            - '2.0'
          description: The JSON-RPC version (2.0)
        id:
          type: integer
          description: The id that was sent in the request
        result:
          type: object
          properties:
            trades:
              type: array
              items:
                $ref: '#/components/schemas/public_trade'
            has_more:
              type: boolean
          required:
            - trades
            - has_more
      required:
        - jsonrpc
        - result
      type: object
    public_trade:
      properties:
        trade_id:
          $ref: '#/components/schemas/trade_id'
        trade_seq:
          $ref: '#/components/schemas/trade_seq'
        instrument_name:
          $ref: '#/components/schemas/instrument_name'
        timestamp:
          $ref: '#/components/schemas/trade_timestamp'
        direction:
          $ref: '#/components/schemas/direction'
          description: Trade direction of the taker
        tick_direction:
          $ref: '#/components/schemas/tick_direction'
        index_price:
          type: number
          description: Index Price at the moment of trade
        price:
          $ref: '#/components/schemas/price'
          description: The price of the trade
        amount:
          type: number
          description: >-
            Trade amount. For perpetual and inverse futures the amount is in USD
            units. For options and linear futures it is the underlying base
            currency coin.
        contracts:
          type: number
          description: >-
            Trade size in contract units (optional, may be absent in historical
            trades)
        iv:
          type: number
          description: Option implied volatility for the price (Option only)
        liquidation:
          type: string
          enum:
            - M
            - T
            - MT
          description: >-
            Optional field (only for trades caused by liquidation): `"M"` when
            maker side of trade was under liquidation, `"T"` when taker side was
            under liquidation, `"MT"` when both sides of trade were under
            liquidation
        mark_price:
          type: number
          description: Mark Price at the moment of trade
        block_trade_id:
          $ref: '#/components/schemas/block_trade_id_in_result'
        block_trade_leg_count:
          $ref: '#/components/schemas/block_trade_leg_count'
        combo_id:
          type: string
          description: >-
            Optional field containing combo instrument name if the trade is a
            combo trade
        combo_trade_id:
          type: number
          description: >-
            Optional field containing combo trade identifier if the trade is a
            combo trade
        block_rfq_id:
          type: integer
          description: ID of the Block RFQ - when trade was part of the Block RFQ
      required:
        - trade_id
        - instrument_name
        - timestamp
        - trade_seq
        - direction
        - tick_direction
        - index_price
        - price
        - amount
        - mark_price
      type: object
    trade_seq:
      type: integer
      description: The sequence number of the trade within instrument
    instrument_name:
      example: BTC-PERPETUAL
      type: string
      description: Unique instrument identifier
    trade_timestamp:
      example: 1517329113791
      type: integer
      description: The timestamp of the trade (milliseconds since the UNIX epoch)
    direction:
      enum:
        - buy
        - sell
      type: string
      description: 'Direction: `buy`, or `sell`'
    tick_direction:
      enum:
        - 0
        - 1
        - 2
        - 3
      type: integer
      description: >-
        Direction of the "tick" (`0` = Plus Tick, `1` = Zero-Plus Tick, `2` =
        Minus Tick, `3` = Zero-Minus Tick).
    price:
      type: number
      description: Price in base currency
    block_trade_id_in_result:
      example: '154'
      type: string
      description: Block trade id - when trade was part of a block trade
    block_trade_leg_count:
      example: 3
      type: integer
      description: Block trade leg count - when trade was part of a block trade
  responses:
    PublicTradesHistoryResponse:
      content:
        application/json:
          schema:
            $ref: '#/components/schemas/PublicTradesHistoryResponse'
          examples:
            response:
              value:
                jsonrpc: '2.0'
                id: 1469
                result:
                  trades:
                    - trade_seq: 467
                      trade_id: '415305279'
                      timestamp: 1770984454552
                      tick_direction: 2
                      price: 0.0525
                      mark_price: 0.05253883
                      iv: 45.91
                      instrument_name: BTC-24APR26-72000-C
                      index_price: 66930.31
                      direction: buy
                      amount: 3
                      contracts: 3
                  has_more: true
              description: Response example
      description: Success response

````

 
  
  

<AgentInstructions>

## Submitting Feedback

If you encounter incorrect, outdated, or confusing documentation on this page, submit feedback:

POST https://docs.deribit.com/feedback

```json
{
  "path": "/api-reference/market-data/public-get_last_trades_by_currency_and_time",
  "feedback": "Description of the issue"
}
```

Only submit feedback when you have something specific and actionable to report.

</AgentInstructions>

# public/get_last_trades_by_currency_and_time

> Retrieves the latest trades that have occurred for instruments in a specific currency within a specified time range. Returns trade details including price, amount, direction, timestamp, and trade ID.

Results can be filtered by instrument kind. Use the `count` parameter to limit the number of trades returned, and `sorting` to control the order (ascending or descending by trade ID).

> **Note:** This endpoint only returns trades from the last **24 hours**. Requests with `start_timestamp` older than 24 hours will return an empty result without an error.

**Scope:** `trade:read`

[Try in API console](https://test.deribit.com/api_console?method=%2Fpublic%2Fget_last_trades_by_currency_and_time)





## OpenAPI

````yaml /specifications/deribit_openapi.json get /public/get_last_trades_by_currency_and_time
openapi: 3.0.0
info:
  title: Deribit API
  version: 2.1.1
servers:
  - url: https://test.deribit.com/api/v2
security: []
tags:
  - name: WebSocket Only
    description: Can only be used over websockets.
  - name: Public
    description: Public methods can be used without authentication.
  - name: Private
    description: >-
      <p>Private methods require authentication. All requests must include a
      valid OAuth2 token.</p>

      <p>A token can be requested using the <a
      href="#public-auth">/public/auth</a> method.</p>

      <p>When using the websockets protocol, the token must be included as a
      parameter <code>access_token</code> in the message. When using REST (HTTP
      GET), the token may also be passed in the <code>Authorization</code>
      header.</p>
  - name: Authentication
  - name: Session Management
  - name: Subscription Management
    description: >-
      Subscription works as [notifications](#notifications), so users will
      automatically (after subscribing) receive messages from the server.
      Overview for each channel response format is described in
      [subscriptions](#subscriptions) section.
  - name: Account Management
  - name: Trading
  - name: Market Data
  - name: Wallet
  - name: Chat
paths:
  /public/get_last_trades_by_currency_and_time:
    get:
      tags:
        - Market Data
        - Public
      description: >+
        Retrieves the latest trades that have occurred for instruments in a
        specific currency within a specified time range. Returns trade details
        including price, amount, direction, timestamp, and trade ID.


        Results can be filtered by instrument kind. Use the `count` parameter to
        limit the number of trades returned, and `sorting` to control the order
        (ascending or descending by trade ID).


        > **Note:** This endpoint only returns trades from the last **24
        hours**. Requests with `start_timestamp` older than 24 hours will return
        an empty result without an error.


        **Scope:** `trade:read`


        [Try in API
        console](https://test.deribit.com/api_console?method=%2Fpublic%2Fget_last_trades_by_currency_and_time)

      parameters:
        - name: currency
          required: true
          in: query
          schema:
            $ref: '#/components/schemas/currency'
          description: The currency symbol
        - name: kind
          required: false
          in: query
          schema:
            $ref: '#/components/schemas/kind_with_combo_all'
          description: >-
            Instrument kind, `"combo"` for any combo or `"any"` for all. If not
            provided instruments of all kinds are considered
        - name: start_timestamp
          required: true
          in: query
          schema:
            $ref: '#/components/schemas/timestamp'
          description: >-
            The earliest timestamp to return result from (milliseconds since the
            UNIX epoch). When param is provided trades are returned from the
            earliest
        - name: end_timestamp
          required: true
          in: query
          schema:
            $ref: '#/components/schemas/timestamp'
          description: >-
            The most recent timestamp to return result from (milliseconds since
            the UNIX epoch). Only one of params: start_timestamp, end_timestamp
            is truly required
        - name: count
          required: false
          in: query
          schema:
            type: integer
            maximum: 1000
            minimum: 1
          description: Number of requested items, default - `10`, maximum - `1000`
        - name: sorting
          required: false
          in: query
          schema:
            $ref: '#/components/schemas/sorting'
          description: >-
            Direction of results sorting (`default` value means no sorting,
            results will be returned in order in which they left the database)
      requestBody:
        content:
          application/json:
            examples:
              request:
                value:
                  jsonrpc: '2.0'
                  id: 1469
                  method: public/get_last_trades_by_currency_and_time
                  params:
                    currency: BTC
                    start_timestamp: 1590470022768
                    end_timestamp: 1590480022768
                    count: 1
                description: JSON-RPC Request Example
        description: JSON-RPC request body
      responses:
        '200':
          $ref: '#/components/responses/PublicTradesHistoryResponse'
components:
  schemas:
    currency:
      enum:
        - BTC
        - ETH
        - USDC
        - USDT
        - EURR
      type: string
      description: Currency, i.e `"BTC"`, `"ETH"`, `"USDC"`
    kind_with_combo_all:
      enum:
        - future
        - option
        - spot
        - future_combo
        - option_combo
        - combo
        - any
      type: string
      description: >-
        Instrument kind: `"future"`, `"option"`, `"spot"`, `"future_combo"`,
        `"option_combo"`, `"combo"` for any combo or `"any"` for all
    timestamp:
      example: 1536569522277
      type: integer
      description: The timestamp (milliseconds since the Unix epoch)
    sorting:
      enum:
        - asc
        - desc
        - default
      type: string
    PublicTradesHistoryResponse:
      properties:
        jsonrpc:
          type: string
          enum:
            - '2.0'
          description: The JSON-RPC version (2.0)
        id:
          type: integer
          description: The id that was sent in the request
        result:
          type: object
          properties:
            trades:
              type: array
              items:
                $ref: '#/components/schemas/public_trade'
            has_more:
              type: boolean
          required:
            - trades
            - has_more
      required:
        - jsonrpc
        - result
      type: object
    public_trade:
      properties:
        trade_id:
          $ref: '#/components/schemas/trade_id'
        trade_seq:
          $ref: '#/components/schemas/trade_seq'
        instrument_name:
          $ref: '#/components/schemas/instrument_name'
        timestamp:
          $ref: '#/components/schemas/trade_timestamp'
        direction:
          $ref: '#/components/schemas/direction'
          description: Trade direction of the taker
        tick_direction:
          $ref: '#/components/schemas/tick_direction'
        index_price:
          type: number
          description: Index Price at the moment of trade
        price:
          $ref: '#/components/schemas/price'
          description: The price of the trade
        amount:
          type: number
          description: >-
            Trade amount. For perpetual and inverse futures the amount is in USD
            units. For options and linear futures it is the underlying base
            currency coin.
        contracts:
          type: number
          description: >-
            Trade size in contract units (optional, may be absent in historical
            trades)
        iv:
          type: number
          description: Option implied volatility for the price (Option only)
        liquidation:
          type: string
          enum:
            - M
            - T
            - MT
          description: >-
            Optional field (only for trades caused by liquidation): `"M"` when
            maker side of trade was under liquidation, `"T"` when taker side was
            under liquidation, `"MT"` when both sides of trade were under
            liquidation
        mark_price:
          type: number
          description: Mark Price at the moment of trade
        block_trade_id:
          $ref: '#/components/schemas/block_trade_id_in_result'
        block_trade_leg_count:
          $ref: '#/components/schemas/block_trade_leg_count'
        combo_id:
          type: string
          description: >-
            Optional field containing combo instrument name if the trade is a
            combo trade
        combo_trade_id:
          type: number
          description: >-
            Optional field containing combo trade identifier if the trade is a
            combo trade
        block_rfq_id:
          type: integer
          description: ID of the Block RFQ - when trade was part of the Block RFQ
      required:
        - trade_id
        - instrument_name
        - timestamp
        - trade_seq
        - direction
        - tick_direction
        - index_price
        - price
        - amount
        - mark_price
      type: object
    trade_id:
      type: string
      description: Unique (per currency) trade identifier
    trade_seq:
      type: integer
      description: The sequence number of the trade within instrument
    instrument_name:
      example: BTC-PERPETUAL
      type: string
      description: Unique instrument identifier
    trade_timestamp:
      example: 1517329113791
      type: integer
      description: The timestamp of the trade (milliseconds since the UNIX epoch)
    direction:
      enum:
        - buy
        - sell
      type: string
      description: 'Direction: `buy`, or `sell`'
    tick_direction:
      enum:
        - 0
        - 1
        - 2
        - 3
      type: integer
      description: >-
        Direction of the "tick" (`0` = Plus Tick, `1` = Zero-Plus Tick, `2` =
        Minus Tick, `3` = Zero-Minus Tick).
    price:
      type: number
      description: Price in base currency
    block_trade_id_in_result:
      example: '154'
      type: string
      description: Block trade id - when trade was part of a block trade
    block_trade_leg_count:
      example: 3
      type: integer
      description: Block trade leg count - when trade was part of a block trade
  responses:
    PublicTradesHistoryResponse:
      content:
        application/json:
          schema:
            $ref: '#/components/schemas/PublicTradesHistoryResponse'
          examples:
            response:
              value:
                jsonrpc: '2.0'
                id: 1469
                result:
                  trades:
                    - trade_seq: 467
                      trade_id: '415305279'
                      timestamp: 1770984454552
                      tick_direction: 2
                      price: 0.0525
                      mark_price: 0.05253883
                      iv: 45.91
                      instrument_name: BTC-24APR26-72000-C
                      index_price: 66930.31
                      direction: buy
                      amount: 3
                      contracts: 3
                  has_more: true
              description: Response example
      description: Success response

````

 
  
  

<AgentInstructions>

## Submitting Feedback

If you encounter incorrect, outdated, or confusing documentation on this page, submit feedback:

POST https://docs.deribit.com/feedback

```json
{
  "path": "/api-reference/market-data/public-get_last_trades_by_currency_and_time",
  "feedback": "Description of the issue"
}
```

Only submit feedback when you have something specific and actionable to report.

</AgentInstructions>

# public/get_last_trades_by_currency_and_time

> Retrieves the latest trades that have occurred for instruments in a specific currency within a specified time range. Returns trade details including price, amount, direction, timestamp, and trade ID.

Results can be filtered by instrument kind. Use the `count` parameter to limit the number of trades returned, and `sorting` to control the order (ascending or descending by trade ID).

> **Note:** This endpoint only returns trades from the last **24 hours**. Requests with `start_timestamp` older than 24 hours will return an empty result without an error.

**Scope:** `trade:read`

[Try in API console](https://test.deribit.com/api_console?method=%2Fpublic%2Fget_last_trades_by_currency_and_time)





## OpenAPI

````yaml /specifications/deribit_openapi.json get /public/get_last_trades_by_currency_and_time
openapi: 3.0.0
info:
  title: Deribit API
  version: 2.1.1
servers:
  - url: https://test.deribit.com/api/v2
security: []
tags:
  - name: WebSocket Only
    description: Can only be used over websockets.
  - name: Public
    description: Public methods can be used without authentication.
  - name: Private
    description: >-
      <p>Private methods require authentication. All requests must include a
      valid OAuth2 token.</p>

      <p>A token can be requested using the <a
      href="#public-auth">/public/auth</a> method.</p>

      <p>When using the websockets protocol, the token must be included as a
      parameter <code>access_token</code> in the message. When using REST (HTTP
      GET), the token may also be passed in the <code>Authorization</code>
      header.</p>
  - name: Authentication
  - name: Session Management
  - name: Subscription Management
    description: >-
      Subscription works as [notifications](#notifications), so users will
      automatically (after subscribing) receive messages from the server.
      Overview for each channel response format is described in
      [subscriptions](#subscriptions) section.
  - name: Account Management
  - name: Trading
  - name: Market Data
  - name: Wallet
  - name: Chat
paths:
  /public/get_last_trades_by_currency_and_time:
    get:
      tags:
        - Market Data
        - Public
      description: >+
        Retrieves the latest trades that have occurred for instruments in a
        specific currency within a specified time range. Returns trade details
        including price, amount, direction, timestamp, and trade ID.


        Results can be filtered by instrument kind. Use the `count` parameter to
        limit the number of trades returned, and `sorting` to control the order
        (ascending or descending by trade ID).


        > **Note:** This endpoint only returns trades from the last **24
        hours**. Requests with `start_timestamp` older than 24 hours will return
        an empty result without an error.


        **Scope:** `trade:read`


        [Try in API
        console](https://test.deribit.com/api_console?method=%2Fpublic%2Fget_last_trades_by_currency_and_time)

      parameters:
        - name: currency
          required: true
          in: query
          schema:
            $ref: '#/components/schemas/currency'
          description: The currency symbol
        - name: kind
          required: false
          in: query
          schema:
            $ref: '#/components/schemas/kind_with_combo_all'
          description: >-
            Instrument kind, `"combo"` for any combo or `"any"` for all. If not
            provided instruments of all kinds are considered
        - name: start_timestamp
          required: true
          in: query
          schema:
            $ref: '#/components/schemas/timestamp'
          description: >-
            The earliest timestamp to return result from (milliseconds since the
            UNIX epoch). When param is provided trades are returned from the
            earliest
        - name: end_timestamp
          required: true
          in: query
          schema:
            $ref: '#/components/schemas/timestamp'
          description: >-
            The most recent timestamp to return result from (milliseconds since
            the UNIX epoch). Only one of params: start_timestamp, end_timestamp
            is truly required
        - name: count
          required: false
          in: query
          schema:
            type: integer
            maximum: 1000
            minimum: 1
          description: Number of requested items, default - `10`, maximum - `1000`
        - name: sorting
          required: false
          in: query
          schema:
            $ref: '#/components/schemas/sorting'
          description: >-
            Direction of results sorting (`default` value means no sorting,
            results will be returned in order in which they left the database)
      requestBody:
        content:
          application/json:
            examples:
              request:
                value:
                  jsonrpc: '2.0'
                  id: 1469
                  method: public/get_last_trades_by_currency_and_time
                  params:
                    currency: BTC
                    start_timestamp: 1590470022768
                    end_timestamp: 1590480022768
                    count: 1
                description: JSON-RPC Request Example
        description: JSON-RPC request body
      responses:
        '200':
          $ref: '#/components/responses/PublicTradesHistoryResponse'
components:
  schemas:
    currency:
      enum:
        - BTC
        - ETH
        - USDC
        - USDT
        - EURR
      type: string
      description: Currency, i.e `"BTC"`, `"ETH"`, `"USDC"`
    kind_with_combo_all:
      enum:
        - future
        - option
        - spot
        - future_combo
        - option_combo
        - combo
        - any
      type: string
      description: >-
        Instrument kind: `"future"`, `"option"`, `"spot"`, `"future_combo"`,
        `"option_combo"`, `"combo"` for any combo or `"any"` for all
    timestamp:
      example: 1536569522277
      type: integer
      description: The timestamp (milliseconds since the Unix epoch)
    sorting:
      enum:
        - asc
        - desc
        - default
      type: string
    PublicTradesHistoryResponse:
      properties:
        jsonrpc:
          type: string
          enum:
            - '2.0'
          description: The JSON-RPC version (2.0)
        id:
          type: integer
          description: The id that was sent in the request
        result:
          type: object
          properties:
            trades:
              type: array
              items:
                $ref: '#/components/schemas/public_trade'
            has_more:
              type: boolean
          required:
            - trades
            - has_more
      required:
        - jsonrpc
        - result
      type: object
    public_trade:
      properties:
        trade_id:
          $ref: '#/components/schemas/trade_id'
        trade_seq:
          $ref: '#/components/schemas/trade_seq'
        instrument_name:
          $ref: '#/components/schemas/instrument_name'
        timestamp:
          $ref: '#/components/schemas/trade_timestamp'
        direction:
          $ref: '#/components/schemas/direction'
          description: Trade direction of the taker
        tick_direction:
          $ref: '#/components/schemas/tick_direction'
        index_price:
          type: number
          description: Index Price at the moment of trade
        price:
          $ref: '#/components/schemas/price'
          description: The price of the trade
        amount:
          type: number
          description: >-
            Trade amount. For perpetual and inverse futures the amount is in USD
            units. For options and linear futures it is the underlying base
            currency coin.
        contracts:
          type: number
          description: >-
            Trade size in contract units (optional, may be absent in historical
            trades)
        iv:
          type: number
          description: Option implied volatility for the price (Option only)
        liquidation:
          type: string
          enum:
            - M
            - T
            - MT
          description: >-
            Optional field (only for trades caused by liquidation): `"M"` when
            maker side of trade was under liquidation, `"T"` when taker side was
            under liquidation, `"MT"` when both sides of trade were under
            liquidation
        mark_price:
          type: number
          description: Mark Price at the moment of trade
        block_trade_id:
          $ref: '#/components/schemas/block_trade_id_in_result'
        block_trade_leg_count:
          $ref: '#/components/schemas/block_trade_leg_count'
        combo_id:
          type: string
          description: >-
            Optional field containing combo instrument name if the trade is a
            combo trade
        combo_trade_id:
          type: number
          description: >-
            Optional field containing combo trade identifier if the trade is a
            combo trade
        block_rfq_id:
          type: integer
          description: ID of the Block RFQ - when trade was part of the Block RFQ
      required:
        - trade_id
        - instrument_name
        - timestamp
        - trade_seq
        - direction
        - tick_direction
        - index_price
        - price
        - amount
        - mark_price
      type: object
    trade_id:
      type: string
      description: Unique (per currency) trade identifier
    trade_seq:
      type: integer
      description: The sequence number of the trade within instrument
    instrument_name:
      example: BTC-PERPETUAL
      type: string
      description: Unique instrument identifier
    trade_timestamp:
      example: 1517329113791
      type: integer
      description: The timestamp of the trade (milliseconds since the UNIX epoch)
    direction:
      enum:
        - buy
        - sell
      type: string
      description: 'Direction: `buy`, or `sell`'
    tick_direction:
      enum:
        - 0
        - 1
        - 2
        - 3
      type: integer
      description: >-
        Direction of the "tick" (`0` = Plus Tick, `1` = Zero-Plus Tick, `2` =
        Minus Tick, `3` = Zero-Minus Tick).
    price:
      type: number
      description: Price in base currency
    block_trade_id_in_result:
      example: '154'
      type: string
      description: Block trade id - when trade was part of a block trade
    block_trade_leg_count:
      example: 3
      type: integer
      description: Block trade leg count - when trade was part of a block trade
  responses:
    PublicTradesHistoryResponse:
      content:
        application/json:
          schema:
            $ref: '#/components/schemas/PublicTradesHistoryResponse'
          examples:
            response:
              value:
                jsonrpc: '2.0'
                id: 1469
                result:
                  trades:
                    - trade_seq: 467
                      trade_id: '415305279'
                      timestamp: 1770984454552
                      tick_direction: 2
                      price: 0.0525
                      mark_price: 0.05253883
                      iv: 45.91
                      instrument_name: BTC-24APR26-72000-C
                      index_price: 66930.31
                      direction: buy
                      amount: 3
                      contracts: 3
                  has_more: true
              description: Response example
      description: Success response

````

 
  
  

<AgentInstructions>

## Submitting Feedback

If you encounter incorrect, outdated, or confusing documentation on this page, submit feedback:

POST https://docs.deribit.com/feedback

```json
{
  "path": "/api-reference/market-data/public-get_last_trades_by_instrument_and_time",
  "feedback": "Description of the issue"
}
```

Only submit feedback when you have something specific and actionable to report.

</AgentInstructions>

# public/get_last_trades_by_instrument_and_time

> Retrieves the latest trades that have occurred for a specific instrument within a specified time range. Returns trade details including price, amount, direction, timestamp, and trade ID.

Use the `count` parameter to limit the number of trades returned, and `sorting` to control the order (ascending or descending by trade ID). This method is useful for analyzing trading activity over specific time periods.

[Try in API console](https://test.deribit.com/api_console?method=%2Fpublic%2Fget_last_trades_by_instrument_and_time)





## OpenAPI

````yaml /specifications/deribit_openapi.json get /public/get_last_trades_by_instrument_and_time
openapi: 3.0.0
info:
  title: Deribit API
  version: 2.1.1
servers:
  - url: https://test.deribit.com/api/v2
security: []
tags:
  - name: WebSocket Only
    description: Can only be used over websockets.
  - name: Public
    description: Public methods can be used without authentication.
  - name: Private
    description: >-
      <p>Private methods require authentication. All requests must include a
      valid OAuth2 token.</p>

      <p>A token can be requested using the <a
      href="#public-auth">/public/auth</a> method.</p>

      <p>When using the websockets protocol, the token must be included as a
      parameter <code>access_token</code> in the message. When using REST (HTTP
      GET), the token may also be passed in the <code>Authorization</code>
      header.</p>
  - name: Authentication
  - name: Session Management
  - name: Subscription Management
    description: >-
      Subscription works as [notifications](#notifications), so users will
      automatically (after subscribing) receive messages from the server.
      Overview for each channel response format is described in
      [subscriptions](#subscriptions) section.
  - name: Account Management
  - name: Trading
  - name: Market Data
  - name: Wallet
  - name: Chat
paths:
  /public/get_last_trades_by_instrument_and_time:
    get:
      tags:
        - Market Data
        - Public
      description: >+
        Retrieves the latest trades that have occurred for a specific instrument
        within a specified time range. Returns trade details including price,
        amount, direction, timestamp, and trade ID.


        Use the `count` parameter to limit the number of trades returned, and
        `sorting` to control the order (ascending or descending by trade ID).
        This method is useful for analyzing trading activity over specific time
        periods.


        [Try in API
        console](https://test.deribit.com/api_console?method=%2Fpublic%2Fget_last_trades_by_instrument_and_time)

      parameters:
        - name: instrument_name
          required: true
          in: query
          schema:
            $ref: '#/components/schemas/instrument_name'
          description: Instrument name
        - name: start_timestamp
          required: true
          in: query
          schema:
            $ref: '#/components/schemas/timestamp'
          description: >-
            The earliest timestamp to return result from (milliseconds since the
            UNIX epoch). When param is provided trades are returned from the
            earliest
        - name: end_timestamp
          required: true
          in: query
          schema:
            $ref: '#/components/schemas/timestamp'
          description: >-
            The most recent timestamp to return result from (milliseconds since
            the UNIX epoch). Only one of params: start_timestamp, end_timestamp
            is truly required
        - name: count
          required: false
          in: query
          schema:
            type: integer
            maximum: 1000
            minimum: 1
          description: Number of requested items, default - `10`, maximum - `1000`
        - name: sorting
          required: false
          in: query
          schema:
            $ref: '#/components/schemas/sorting'
          description: >-
            Direction of results sorting (`default` value means no sorting,
            results will be returned in order in which they left the database)
      requestBody:
        content:
          application/json:
            examples:
              request:
                value:
                  jsonrpc: '2.0'
                  id: 3983
                  method: public/get_last_trades_by_instrument_and_time
                  params:
                    instrument_name: ETH-PERPETUAL
                    end_timestamp: 1590480022768
                    count: 1
                description: JSON-RPC Request Example
        description: JSON-RPC request body
      responses:
        '200':
          $ref: '#/components/responses/PublicTradesHistoryResponse'
components:
  schemas:
    instrument_name:
      example: BTC-PERPETUAL
      type: string
      description: Unique instrument identifier
    timestamp:
      example: 1536569522277
      type: integer
      description: The timestamp (milliseconds since the Unix epoch)
    sorting:
      enum:
        - asc
        - desc
        - default
      type: string
    PublicTradesHistoryResponse:
      properties:
        jsonrpc:
          type: string
          enum:
            - '2.0'
          description: The JSON-RPC version (2.0)
        id:
          type: integer
          description: The id that was sent in the request
        result:
          type: object
          properties:
            trades:
              type: array
              items:
                $ref: '#/components/schemas/public_trade'
            has_more:
              type: boolean
          required:
            - trades
            - has_more
      required:
        - jsonrpc
        - result
      type: object
    public_trade:
      properties:
        trade_id:
          $ref: '#/components/schemas/trade_id'
        trade_seq:
          $ref: '#/components/schemas/trade_seq'
        instrument_name:
          $ref: '#/components/schemas/instrument_name'
        timestamp:
          $ref: '#/components/schemas/trade_timestamp'
        direction:
          $ref: '#/components/schemas/direction'
          description: Trade direction of the taker
        tick_direction:
          $ref: '#/components/schemas/tick_direction'
        index_price:
          type: number
          description: Index Price at the moment of trade
        price:
          $ref: '#/components/schemas/price'
          description: The price of the trade
        amount:
          type: number
          description: >-
            Trade amount. For perpetual and inverse futures the amount is in USD
            units. For options and linear futures it is the underlying base
            currency coin.
        contracts:
          type: number
          description: >-
            Trade size in contract units (optional, may be absent in historical
            trades)
        iv:
          type: number
          description: Option implied volatility for the price (Option only)
        liquidation:
          type: string
          enum:
            - M
            - T
            - MT
          description: >-
            Optional field (only for trades caused by liquidation): `"M"` when
            maker side of trade was under liquidation, `"T"` when taker side was
            under liquidation, `"MT"` when both sides of trade were under
            liquidation
        mark_price:
          type: number
          description: Mark Price at the moment of trade
        block_trade_id:
          $ref: '#/components/schemas/block_trade_id_in_result'
        block_trade_leg_count:
          $ref: '#/components/schemas/block_trade_leg_count'
        combo_id:
          type: string
          description: >-
            Optional field containing combo instrument name if the trade is a
            combo trade
        combo_trade_id:
          type: number
          description: >-
            Optional field containing combo trade identifier if the trade is a
            combo trade
        block_rfq_id:
          type: integer
          description: ID of the Block RFQ - when trade was part of the Block RFQ
      required:
        - trade_id
        - instrument_name
        - timestamp
        - trade_seq
        - direction
        - tick_direction
        - index_price
        - price
        - amount
        - mark_price
      type: object
    trade_id:
      type: string
      description: Unique (per currency) trade identifier
    trade_seq:
      type: integer
      description: The sequence number of the trade within instrument
    trade_timestamp:
      example: 1517329113791
      type: integer
      description: The timestamp of the trade (milliseconds since the UNIX epoch)
    direction:
      enum:
        - buy
        - sell
      type: string
      description: 'Direction: `buy`, or `sell`'
    tick_direction:
      enum:
        - 0
        - 1
        - 2
        - 3
      type: integer
      description: >-
        Direction of the "tick" (`0` = Plus Tick, `1` = Zero-Plus Tick, `2` =
        Minus Tick, `3` = Zero-Minus Tick).
    price:
      type: number
      description: Price in base currency
    block_trade_id_in_result:
      example: '154'
      type: string
      description: Block trade id - when trade was part of a block trade
    block_trade_leg_count:
      example: 3
      type: integer
      description: Block trade leg count - when trade was part of a block trade
  responses:
    PublicTradesHistoryResponse:
      content:
        application/json:
          schema:
            $ref: '#/components/schemas/PublicTradesHistoryResponse'
          examples:
            response:
              value:
                jsonrpc: '2.0'
                id: 1469
                result:
                  trades:
                    - trade_seq: 467
                      trade_id: '415305279'
                      timestamp: 1770984454552
                      tick_direction: 2
                      price: 0.0525
                      mark_price: 0.05253883
                      iv: 45.91
                      instrument_name: BTC-24APR26-72000-C
                      index_price: 66930.31
                      direction: buy
                      amount: 3
                      contracts: 3
                  has_more: true
              description: Response example
      description: Success response

````

 
  
  

<AgentInstructions>

## Submitting Feedback

If you encounter incorrect, outdated, or confusing documentation on this page, submit feedback:

POST https://docs.deribit.com/feedback

```json
{
  "path": "/api-reference/market-data/public-get_mark_price_history",
  "feedback": "Description of the issue"
}
```

Only submit feedback when you have something specific and actionable to report.

</AgentInstructions>

# public/get_mark_price_history

> Retrieves 5-minute historical mark price data for an instrument. Mark prices are used for margin calculations and position valuations.

**Note:** Currently, mark price history is available only for a subset of options that participate in volatility index calculations. All other instruments, including futures and perpetuals, will return an empty list.

[Try in API console](https://test.deribit.com/api_console?method=%2Fpublic%2Fget_mark_price_history)





## OpenAPI

````yaml /specifications/deribit_openapi.json get /public/get_mark_price_history
openapi: 3.0.0
info:
  title: Deribit API
  version: 2.1.1
servers:
  - url: https://test.deribit.com/api/v2
security: []
tags:
  - name: WebSocket Only
    description: Can only be used over websockets.
  - name: Public
    description: Public methods can be used without authentication.
  - name: Private
    description: >-
      <p>Private methods require authentication. All requests must include a
      valid OAuth2 token.</p>

      <p>A token can be requested using the <a
      href="#public-auth">/public/auth</a> method.</p>

      <p>When using the websockets protocol, the token must be included as a
      parameter <code>access_token</code> in the message. When using REST (HTTP
      GET), the token may also be passed in the <code>Authorization</code>
      header.</p>
  - name: Authentication
  - name: Session Management
  - name: Subscription Management
    description: >-
      Subscription works as [notifications](#notifications), so users will
      automatically (after subscribing) receive messages from the server.
      Overview for each channel response format is described in
      [subscriptions](#subscriptions) section.
  - name: Account Management
  - name: Trading
  - name: Market Data
  - name: Wallet
  - name: Chat
paths:
  /public/get_mark_price_history:
    get:
      tags:
        - Market Data
        - Mark Price
        - Public
      description: >+
        Retrieves 5-minute historical mark price data for an instrument. Mark
        prices are used for margin calculations and position valuations.


        **Note:** Currently, mark price history is available only for a subset
        of options that participate in volatility index calculations. All other
        instruments, including futures and perpetuals, will return an empty
        list.


        [Try in API
        console](https://test.deribit.com/api_console?method=%2Fpublic%2Fget_mark_price_history)

      parameters:
        - name: instrument_name
          required: true
          in: query
          schema:
            $ref: '#/components/schemas/instrument_name'
          description: Instrument name
        - name: start_timestamp
          required: true
          in: query
          schema:
            $ref: '#/components/schemas/timestamp'
          description: >-
            The earliest timestamp to return result from (milliseconds since the
            UNIX epoch)
        - name: end_timestamp
          required: true
          in: query
          schema:
            $ref: '#/components/schemas/timestamp'
          description: >-
            The most recent timestamp to return result from (milliseconds since
            the UNIX epoch)
      requestBody:
        content:
          application/json:
            examples:
              request:
                value:
                  jsonrpc: '2.0'
                  id: 1
                  method: public/get_mark_price_history
                  params:
                    instrument_name: BTC-25JUN21-50000-C
                    start_timestamp: 1609376800000
                    end_timestamp: 1609376810000
                description: JSON-RPC Request Example
        description: JSON-RPC request body
      responses:
        '200':
          $ref: '#/components/responses/PublicGetMarkPriceHistoryResponse'
components:
  schemas:
    instrument_name:
      example: BTC-PERPETUAL
      type: string
      description: Unique instrument identifier
    timestamp:
      example: 1536569522277
      type: integer
      description: The timestamp (milliseconds since the Unix epoch)
    PublicGetMarkPriceHistoryResponse:
      properties:
        jsonrpc:
          type: string
          enum:
            - '2.0'
          description: The JSON-RPC version (2.0)
        id:
          type: integer
          description: The id that was sent in the request
        result:
          type: array
          description: >-
            Markprice history values as an array of arrays with 2 values each.
            The inner values correspond to the timestamp in ms and the markprice
            itself.
      required:
        - jsonrpc
        - result
      type: object
  responses:
    PublicGetMarkPriceHistoryResponse:
      content:
        application/json:
          schema:
            $ref: '#/components/schemas/PublicGetMarkPriceHistoryResponse'
          examples:
            response:
              value:
                jsonrpc: '2.0'
                id: 25
                result:
                  - - 1608142381229
                    - 0.5165791606037885
                  - - 1608142380231
                    - 0.5165737855432504
                  - - 1608142379227
                    - 0.5165768236356326
              description: Response example
      description: Success response

````

 
  
  

<AgentInstructions>

## Submitting Feedback

If you encounter incorrect, outdated, or confusing documentation on this page, submit feedback:

POST https://docs.deribit.com/feedback

```json
{
  "path": "/api-reference/market-data/public-get_order_book",
  "feedback": "Description of the issue"
}
```

Only submit feedback when you have something specific and actionable to report.

</AgentInstructions>

# public/get_order_book

> Retrieves the order book (bids and asks) for a given instrument, along with other market values such as best bid/ask prices, last trade price, mark price, and index price.

The order book depth can be controlled using the `depth` parameter, which accepts values from 1 to 10000. The response includes price levels sorted by price (bids descending, asks ascending).

[Try in API console](https://test.deribit.com/api_console?method=%2Fpublic%2Fget_order_book)





## OpenAPI

````yaml /specifications/deribit_openapi.json get /public/get_order_book
openapi: 3.0.0
info:
  title: Deribit API
  version: 2.1.1
servers:
  - url: https://test.deribit.com/api/v2
security: []
tags:
  - name: WebSocket Only
    description: Can only be used over websockets.
  - name: Public
    description: Public methods can be used without authentication.
  - name: Private
    description: >-
      <p>Private methods require authentication. All requests must include a
      valid OAuth2 token.</p>

      <p>A token can be requested using the <a
      href="#public-auth">/public/auth</a> method.</p>

      <p>When using the websockets protocol, the token must be included as a
      parameter <code>access_token</code> in the message. When using REST (HTTP
      GET), the token may also be passed in the <code>Authorization</code>
      header.</p>
  - name: Authentication
  - name: Session Management
  - name: Subscription Management
    description: >-
      Subscription works as [notifications](#notifications), so users will
      automatically (after subscribing) receive messages from the server.
      Overview for each channel response format is described in
      [subscriptions](#subscriptions) section.
  - name: Account Management
  - name: Trading
  - name: Market Data
  - name: Wallet
  - name: Chat
paths:
  /public/get_order_book:
    get:
      tags:
        - Market Data
        - Public
      description: >+
        Retrieves the order book (bids and asks) for a given instrument, along
        with other market values such as best bid/ask prices, last trade price,
        mark price, and index price.


        The order book depth can be controlled using the `depth` parameter,
        which accepts values from 1 to 10000. The response includes price levels
        sorted by price (bids descending, asks ascending).


        [Try in API
        console](https://test.deribit.com/api_console?method=%2Fpublic%2Fget_order_book)

      parameters:
        - in: query
          name: instrument_name
          required: true
          schema:
            type: string
            example: BTC-PERPETUAL
          description: >-
            The instrument name for which to retrieve the order book, see
            [`public/get_instruments`](#public-get_instruments) to obtain
            instrument names.
        - in: query
          name: depth
          required: false
          schema:
            type: integer
            enum:
              - 1
              - 5
              - 10
              - 20
              - 50
              - 100
              - 1000
              - 10000
            example: 5
          description: >-
            The number of entries to return for bids and asks, maximum -
            `10000`.
      requestBody:
        content:
          application/json:
            examples:
              request:
                value:
                  jsonrpc: '2.0'
                  id: 8772
                  method: public/get_order_book
                  params:
                    instrument_name: BTC-PERPETUAL
                    depth: 5
                description: JSON-RPC Request Example
        description: JSON-RPC request body
      responses:
        '200':
          $ref: '#/components/responses/PublicGetOrderBookResponse'
components:
  responses:
    PublicGetOrderBookResponse:
      content:
        application/json:
          schema:
            $ref: '#/components/schemas/PublicGetOrderBookResponse'
          examples:
            response:
              value:
                jsonrpc: '2.0'
                id: 8772
                result:
                  timestamp: 1550757626706
                  stats:
                    volume: 93.35589552
                    price_change: 0.6913
                    low: 3940.75
                    high: 3976.25
                  state: open
                  settlement_price: 3925.85
                  open_interest: 45.27600333464605
                  min_price: 3932.22
                  max_price: 3971.74
                  mark_price: 3931.97
                  last_price: 3955.75
                  instrument_name: BTC-PERPETUAL
                  index_price: 3910.46
                  funding_8h: 0.00455263
                  current_funding: 0.00500063
                  change_id: 474988
                  bids:
                    - - 3955.75
                      - 30
                    - - 3940.75
                      - 102020
                    - - 3423
                      - 42840
                  best_bid_price: 3955.75
                  best_bid_amount: 30
                  best_ask_price: 0
                  best_ask_amount: 0
                  asks: []
              description: Response example
      description: Success response
  schemas:
    PublicGetOrderBookResponse:
      properties:
        jsonrpc:
          type: string
          enum:
            - '2.0'
          description: The JSON-RPC version (2.0)
        id:
          type: integer
          description: The id that was sent in the request
        result:
          $ref: '#/components/schemas/TickerNotificationWithBidsAndAsks'
      required:
        - jsonrpc
        - result
      type: object
    TickerNotificationWithBidsAndAsks:
      properties:
        instrument_name:
          $ref: '#/components/schemas/instrument_name'
        timestamp:
          $ref: '#/components/schemas/timestamp'
        state:
          $ref: '#/components/schemas/book_state'
        stats:
          $ref: '#/components/schemas/stats'
        open_interest:
          $ref: '#/components/schemas/open_interest'
        best_bid_price:
          $ref: '#/components/schemas/best_bid_price'
        best_bid_amount:
          $ref: '#/components/schemas/best_bid_amount'
        best_ask_price:
          $ref: '#/components/schemas/best_ask_price'
        best_ask_amount:
          $ref: '#/components/schemas/best_ask_amount'
        index_price:
          $ref: '#/components/schemas/index_price'
        min_price:
          $ref: '#/components/schemas/min_price'
        max_price:
          $ref: '#/components/schemas/max_price'
        mark_price:
          $ref: '#/components/schemas/mark_price'
        last_price:
          $ref: '#/components/schemas/last_price'
        underlying_price:
          $ref: '#/components/schemas/underlying_price'
        underlying_index:
          $ref: '#/components/schemas/underlying_index'
        interest_rate:
          $ref: '#/components/schemas/interest_rate'
        bid_iv:
          $ref: '#/components/schemas/bid_iv'
        ask_iv:
          $ref: '#/components/schemas/ask_iv'
        mark_iv:
          $ref: '#/components/schemas/mark_iv'
        greeks:
          $ref: '#/components/schemas/greeks'
        funding_8h:
          $ref: '#/components/schemas/funding_8h'
        current_funding:
          $ref: '#/components/schemas/current_funding'
        delivery_price:
          $ref: '#/components/schemas/delivery_price'
        settlement_price:
          $ref: '#/components/schemas/settlement_price'
        bids:
          $ref: '#/components/schemas/bids'
        asks:
          $ref: '#/components/schemas/asks'
      required:
        - instrument_name
        - timestamp
        - state
        - stats
        - open_interest
        - index_price
        - best_bid_price
        - best_bid_amount
        - best_ask_price
        - best_ask_amount
        - min_price
        - max_price
        - mark_price
        - last_price
        - bids
        - asks
      type: object
    instrument_name:
      example: BTC-PERPETUAL
      type: string
      description: Unique instrument identifier
    timestamp:
      example: 1536569522277
      type: integer
      description: The timestamp (milliseconds since the Unix epoch)
    book_state:
      enum:
        - open
        - settlement
        - delivered
        - inactive
        - locked
        - halted
        - archivized
      type: string
      description: >
        The state of the order book. Represents the current lifecycle stage of
        the instrument.


        **State Lifecycle and Meanings:**


        - `open`: Default state for running books. In this state book is
        accepting new orders, edits, cancels; prices should be updated, trading
        is live.

        - `settlement`: Books enters to this state during settlement/delivery.
        New orders, edits, cancels are not accepted. After this state normally
        next state should be `open` if it was settlement, or `delivered` if it
        was delivery. On enter to this state good till day orders in book are
        canceled.

        - `delivered`: Final state of book that has been delivered. New orders,
        edits, cancels are not accepted. After some time book process will be
        terminated and, instrument moved to `expired_instruments` and its
        `instrument_state` will become archivized. On enter to this all open
        orders in book are canceled.

        - `inactive`: After a book is deactivated, this state is set on book.
        New orders, edits, cancels are not accepted. On enter to this all open
        orders in book are canceled. Book in this state is not considered as
        open. This can be also final state for book.

        - `locked`: New orders, edits, are not accepted, only cancels ARE
        accepted. In some cases when configured books can start as locked or it
        may become locked on admin request. Settlement is possible on locked
        books.

        - `halted`: The state that books enter as a result of an error.
        Settlement is not possible when there is at least one book in this
        state.

        - `archivized`: Set when instrument is moved to `expired_instruments`
        table, final state.
    stats:
      properties:
        volume:
          type: number
          description: Volume during last 24h in base currency
        low:
          type: number
          description: Lowest price during 24h
        high:
          type: number
          description: Highest price during 24h
        price_change:
          example: 10.23
          type: number
          description: >-
            24-hour price change expressed as a percentage, `null` if there
            weren't any trades
        volume_usd:
          $ref: '#/components/schemas/volume_usd'
      required:
        - volume
        - high
        - low
      type: object
    open_interest:
      type: number
      description: >-
        The total amount of outstanding contracts in the corresponding amount
        units. For perpetual and inverse futures the amount is in USD units. For
        options and linear futures it is the underlying base currency coin.
    best_bid_price:
      nullable: true
      type: number
      description: The current best bid price, `null` if there aren't any bids
    best_bid_amount:
      nullable: true
      type: number
      description: It represents the requested order size of all best bids
    best_ask_price:
      nullable: true
      type: number
      description: The current best ask price, `null` if there aren't any asks
    best_ask_amount:
      nullable: true
      type: number
      description: It represents the requested order size of all best asks
    index_price:
      example: 8247.27
      type: number
      description: Current index price
    min_price:
      type: number
      description: >-
        The minimum price for the future. Any sell orders you submit lower than
        this price will be clamped to this minimum.
    max_price:
      type: number
      description: >-
        The maximum price for the future. Any buy orders you submit higher than
        this price, will be clamped to this maximum.
    mark_price:
      type: number
      description: The mark price for the instrument
    last_price:
      nullable: true
      type: number
      description: The price for the last trade
    underlying_price:
      type: number
      description: Underlying price for implied volatility calculations (options only)
    underlying_index:
      type: number
      description: Name of the underlying future, or `index_price` (options only)
    interest_rate:
      type: number
      description: Interest rate used in implied volatility calculations (options only)
    bid_iv:
      type: number
      description: (Only for option) implied volatility for best bid
    ask_iv:
      type: number
      description: (Only for option) implied volatility for best ask
    mark_iv:
      type: number
      description: (Only for option) implied volatility for mark price
    greeks:
      properties:
        delta:
          type: number
          description: >
            (Only for option) The delta value for the option. This is the
            **Black Scholes Delta** for individual option expiries. 


            Note that DeltaTotal in account summary uses Net Transaction Delta
            instead. See the greeks object description for more details.
        gamma:
          type: number
          description: >
            (Only for option) The gamma value for the option. Calculated using
            standard Black Scholes without adjustments.


            Gamma measures the rate of change of delta with respect to changes
            in the underlying asset price.
        rho:
          type: number
          description: >
            (Only for option) The rho value for the option. Calculated using
            standard Black Scholes without adjustments.


            Rho measures the sensitivity of the option price to changes in the
            risk-free interest rate.
        theta:
          type: number
          description: >
            (Only for option) The theta value for the option. Deribit uses the
            **minimum of (1 day Theta, lifetime theta of the option)**.


            So if you take an option with 1 hour to expire for example,
            generally Black Scholes Theta will give you the equivalent 1 day
            Theta. Whereas we show the 1 hour Theta, so our Theta would differ
            from Black Scholes Theta when time to expiry is less than 1 day.


            Theta measures the rate of change of the option price with respect
            to time decay.
        vega:
          type: number
          description: >
            (Only for option) The vega value for the option. Calculated using
            standard Black Scholes without adjustments.


            Vega (not actually a Greek symbol) measures the sensitivity of the
            option price to changes in implied volatility.
      required:
        - delta
        - gamma
        - rho
        - theta
        - vega
      type: object
      description: >
        Only for options. Greeks are risk measures that describe how the
        option's price changes with respect to various factors.


        **Delta (Δ)**


        Deribit uses two different Deltas:

        - **DeltaTotal** in the account summary uses the **Net Transaction Delta
        (NTD)**

        - **Delta** for individual option expiries is the **Black Scholes
        Delta**


        In the settings section you can toggle Net Transaction Delta instead.


        **What is DeltaTotal in the account summary?**

        `DeltaTotal = Net Transaction Delta of options + BTC Position of
        Futures`


        **What is Net Transaction Delta?**

        `Net Transaction Delta = Black Scholes Delta - Mark Price of Options`


        **Why do we use a Net Transaction Delta?**

        The Delta Total uses the Net Transaction Delta (or price adjusted Delta)
        of the options. This is because, from a risk perspective, we are
        interested in the change in Bitcoin price as the underlying changes.


        You should actually treat your delta as **Equity + Delta Total** if you
        want to have less risk for your USD PnL.


        **Example:** Consider a call option with strike 0, which has a Black
        Scholes Delta of 1 and Net Transaction Delta = 0.


        Imagine you have 2 BTC equity and no positions and BTC price is at USD
        60k. In that case you would short 2 Futures contracts to hedge your USD
        exposure to BTC.


        Now let's say you buy one call with strike 0. The question is if you
        should sell another future?


        The call will always have a price of 1 BTC. So you buy it at 1 BTC which
        equates to USD 60k. Let's say the price increases to USD 70k. The value
        of the call is still 1 BTC. At settlement you receive 1 BTC for the
        call. So you paid 1 BTC and then receive 1 BTC which means your USD PnL
        on buying the call is 0. If you sold a future on it, then you would
        actually lose on the future.


        ⚠️ **During the 30 minute settlement period we decay your Delta.** See
        [Delta decay during
        settlement](https://support.deribit.com/hc/en-us/articles/25944751433757-Delta-decay-during-settlement)
        for more details.


        **Theta (Θ)**


        The Theta that Deribit uses is the **minimum of (1 day Theta, lifetime
        theta of the option)**. So if you take an option with 1 hour to expire
        for example, generally Black Scholes Theta will give you the equivalent
        1 day Theta. Whereas we show the 1 hour Theta, so our Theta would differ
        from Black Scholes Theta when time to expiry is less than 1 day.


        **Vega, Gamma, and Rho**


        Vega (not actually a Greek symbol), Gamma, Theta and Rho values shown on
        Deribit are calculated using **standard Black Scholes without
        adjustments**.
    funding_8h:
      type: number
      description: Funding 8h (perpetual only)
    current_funding:
      type: number
      description: Current funding (perpetual only)
    delivery_price:
      type: number
      description: The settlement price for the instrument. Only when `state = closed`
    settlement_price:
      type: number
      description: >-
        Optional (not added for spot). The settlement price for the instrument.
        Only when `state = open`
    bids:
      items:
        items:
          type: number
        minItems: 2
        maxItems: 2
        type: array
        description: List of bids (price-amount pairs)
      type: array
    asks:
      items:
        items:
          type: number
        minItems: 2
        maxItems: 2
        type: array
        description: List of asks (price-amount pairs)
      type: array
    volume_usd:
      type: number
      description: Volume in usd (futures only)

````
 
  
  

<AgentInstructions>

## Submitting Feedback

If you encounter incorrect, outdated, or confusing documentation on this page, submit feedback:

POST https://docs.deribit.com/feedback

```json
{
  "path": "/api-reference/market-data/public-get_order_book_by_instrument_id",
  "feedback": "Description of the issue"
}
```

Only submit feedback when you have something specific and actionable to report.

</AgentInstructions>

# public/get_order_book_by_instrument_id

> Retrieves the order book (bids and asks) for a given instrument ID, along with other market values such as best bid/ask prices, last trade price, mark price, and index price.

This method is similar to `get_order_book` but uses instrument ID instead of instrument name. The order book depth can be controlled using the `depth` parameter, which accepts values from 1 to 10000.

[Try in API console](https://test.deribit.com/api_console?method=%2Fpublic%2Fget_order_book_by_instrument_id)





## OpenAPI

````yaml /specifications/deribit_openapi.json get /public/get_order_book_by_instrument_id
openapi: 3.0.0
info:
  title: Deribit API
  version: 2.1.1
servers:
  - url: https://test.deribit.com/api/v2
security: []
tags:
  - name: WebSocket Only
    description: Can only be used over websockets.
  - name: Public
    description: Public methods can be used without authentication.
  - name: Private
    description: >-
      <p>Private methods require authentication. All requests must include a
      valid OAuth2 token.</p>

      <p>A token can be requested using the <a
      href="#public-auth">/public/auth</a> method.</p>

      <p>When using the websockets protocol, the token must be included as a
      parameter <code>access_token</code> in the message. When using REST (HTTP
      GET), the token may also be passed in the <code>Authorization</code>
      header.</p>
  - name: Authentication
  - name: Session Management
  - name: Subscription Management
    description: >-
      Subscription works as [notifications](#notifications), so users will
      automatically (after subscribing) receive messages from the server.
      Overview for each channel response format is described in
      [subscriptions](#subscriptions) section.
  - name: Account Management
  - name: Trading
  - name: Market Data
  - name: Wallet
  - name: Chat
paths:
  /public/get_order_book_by_instrument_id:
    get:
      tags:
        - Market Data
        - Public
      description: >+
        Retrieves the order book (bids and asks) for a given instrument ID,
        along with other market values such as best bid/ask prices, last trade
        price, mark price, and index price.


        This method is similar to `get_order_book` but uses instrument ID
        instead of instrument name. The order book depth can be controlled using
        the `depth` parameter, which accepts values from 1 to 10000.


        [Try in API
        console](https://test.deribit.com/api_console?method=%2Fpublic%2Fget_order_book_by_instrument_id)

      parameters:
        - in: query
          name: instrument_id
          required: true
          schema:
            type: integer
          description: >-
            The instrument ID for which to retrieve the order book, see
            [`public/get_instruments`](#public-get_instruments) to obtain
            instrument IDs.
        - in: query
          name: depth
          required: false
          schema:
            type: integer
            enum:
              - 1
              - 5
              - 10
              - 20
              - 50
              - 100
              - 1000
              - 10000
          description: >-
            The number of entries to return for bids and asks, maximum -
            `10000`.
      responses:
        '200':
          $ref: '#/components/responses/PublicGetOrderBookResponse'
components:
  responses:
    PublicGetOrderBookResponse:
      content:
        application/json:
          schema:
            $ref: '#/components/schemas/PublicGetOrderBookResponse'
          examples:
            response:
              value:
                jsonrpc: '2.0'
                id: 8772
                result:
                  timestamp: 1550757626706
                  stats:
                    volume: 93.35589552
                    price_change: 0.6913
                    low: 3940.75
                    high: 3976.25
                  state: open
                  settlement_price: 3925.85
                  open_interest: 45.27600333464605
                  min_price: 3932.22
                  max_price: 3971.74
                  mark_price: 3931.97
                  last_price: 3955.75
                  instrument_name: BTC-PERPETUAL
                  index_price: 3910.46
                  funding_8h: 0.00455263
                  current_funding: 0.00500063
                  change_id: 474988
                  bids:
                    - - 3955.75
                      - 30
                    - - 3940.75
                      - 102020
                    - - 3423
                      - 42840
                  best_bid_price: 3955.75
                  best_bid_amount: 30
                  best_ask_price: 0
                  best_ask_amount: 0
                  asks: []
              description: Response example
      description: Success response
  schemas:
    PublicGetOrderBookResponse:
      properties:
        jsonrpc:
          type: string
          enum:
            - '2.0'
          description: The JSON-RPC version (2.0)
        id:
          type: integer
          description: The id that was sent in the request
        result:
          $ref: '#/components/schemas/TickerNotificationWithBidsAndAsks'
      required:
        - jsonrpc
        - result
      type: object
    TickerNotificationWithBidsAndAsks:
      properties:
        instrument_name:
          $ref: '#/components/schemas/instrument_name'
        timestamp:
          $ref: '#/components/schemas/timestamp'
        state:
          $ref: '#/components/schemas/book_state'
        stats:
          $ref: '#/components/schemas/stats'
        open_interest:
          $ref: '#/components/schemas/open_interest'
        best_bid_price:
          $ref: '#/components/schemas/best_bid_price'
        best_bid_amount:
          $ref: '#/components/schemas/best_bid_amount'
        best_ask_price:
          $ref: '#/components/schemas/best_ask_price'
        best_ask_amount:
          $ref: '#/components/schemas/best_ask_amount'
        index_price:
          $ref: '#/components/schemas/index_price'
        min_price:
          $ref: '#/components/schemas/min_price'
        max_price:
          $ref: '#/components/schemas/max_price'
        mark_price:
          $ref: '#/components/schemas/mark_price'
        last_price:
          $ref: '#/components/schemas/last_price'
        underlying_price:
          $ref: '#/components/schemas/underlying_price'
        underlying_index:
          $ref: '#/components/schemas/underlying_index'
        interest_rate:
          $ref: '#/components/schemas/interest_rate'
        bid_iv:
          $ref: '#/components/schemas/bid_iv'
        ask_iv:
          $ref: '#/components/schemas/ask_iv'
        mark_iv:
          $ref: '#/components/schemas/mark_iv'
        greeks:
          $ref: '#/components/schemas/greeks'
        funding_8h:
          $ref: '#/components/schemas/funding_8h'
        current_funding:
          $ref: '#/components/schemas/current_funding'
        delivery_price:
          $ref: '#/components/schemas/delivery_price'
        settlement_price:
          $ref: '#/components/schemas/settlement_price'
        bids:
          $ref: '#/components/schemas/bids'
        asks:
          $ref: '#/components/schemas/asks'
      required:
        - instrument_name
        - timestamp
        - state
        - stats
        - open_interest
        - index_price
        - best_bid_price
        - best_bid_amount
        - best_ask_price
        - best_ask_amount
        - min_price
        - max_price
        - mark_price
        - last_price
        - bids
        - asks
      type: object
    instrument_name:
      example: BTC-PERPETUAL
      type: string
      description: Unique instrument identifier
    timestamp:
      example: 1536569522277
      type: integer
      description: The timestamp (milliseconds since the Unix epoch)
    book_state:
      enum:
        - open
        - settlement
        - delivered
        - inactive
        - locked
        - halted
        - archivized
      type: string
      description: >
        The state of the order book. Represents the current lifecycle stage of
        the instrument.


        **State Lifecycle and Meanings:**


        - `open`: Default state for running books. In this state book is
        accepting new orders, edits, cancels; prices should be updated, trading
        is live.

        - `settlement`: Books enters to this state during settlement/delivery.
        New orders, edits, cancels are not accepted. After this state normally
        next state should be `open` if it was settlement, or `delivered` if it
        was delivery. On enter to this state good till day orders in book are
        canceled.

        - `delivered`: Final state of book that has been delivered. New orders,
        edits, cancels are not accepted. After some time book process will be
        terminated and, instrument moved to `expired_instruments` and its
        `instrument_state` will become archivized. On enter to this all open
        orders in book are canceled.

        - `inactive`: After a book is deactivated, this state is set on book.
        New orders, edits, cancels are not accepted. On enter to this all open
        orders in book are canceled. Book in this state is not considered as
        open. This can be also final state for book.

        - `locked`: New orders, edits, are not accepted, only cancels ARE
        accepted. In some cases when configured books can start as locked or it
        may become locked on admin request. Settlement is possible on locked
        books.

        - `halted`: The state that books enter as a result of an error.
        Settlement is not possible when there is at least one book in this
        state.

        - `archivized`: Set when instrument is moved to `expired_instruments`
        table, final state.
    stats:
      properties:
        volume:
          type: number
          description: Volume during last 24h in base currency
        low:
          type: number
          description: Lowest price during 24h
        high:
          type: number
          description: Highest price during 24h
        price_change:
          example: 10.23
          type: number
          description: >-
            24-hour price change expressed as a percentage, `null` if there
            weren't any trades
        volume_usd:
          $ref: '#/components/schemas/volume_usd'
      required:
        - volume
        - high
        - low
      type: object
    open_interest:
      type: number
      description: >-
        The total amount of outstanding contracts in the corresponding amount
        units. For perpetual and inverse futures the amount is in USD units. For
        options and linear futures it is the underlying base currency coin.
    best_bid_price:
      nullable: true
      type: number
      description: The current best bid price, `null` if there aren't any bids
    best_bid_amount:
      nullable: true
      type: number
      description: It represents the requested order size of all best bids
    best_ask_price:
      nullable: true
      type: number
      description: The current best ask price, `null` if there aren't any asks
    best_ask_amount:
      nullable: true
      type: number
      description: It represents the requested order size of all best asks
    index_price:
      example: 8247.27
      type: number
      description: Current index price
    min_price:
      type: number
      description: >-
        The minimum price for the future. Any sell orders you submit lower than
        this price will be clamped to this minimum.
    max_price:
      type: number
      description: >-
        The maximum price for the future. Any buy orders you submit higher than
        this price, will be clamped to this maximum.
    mark_price:
      type: number
      description: The mark price for the instrument
    last_price:
      nullable: true
      type: number
      description: The price for the last trade
    underlying_price:
      type: number
      description: Underlying price for implied volatility calculations (options only)
    underlying_index:
      type: number
      description: Name of the underlying future, or `index_price` (options only)
    interest_rate:
      type: number
      description: Interest rate used in implied volatility calculations (options only)
    bid_iv:
      type: number
      description: (Only for option) implied volatility for best bid
    ask_iv:
      type: number
      description: (Only for option) implied volatility for best ask
    mark_iv:
      type: number
      description: (Only for option) implied volatility for mark price
    greeks:
      properties:
        delta:
          type: number
          description: >
            (Only for option) The delta value for the option. This is the
            **Black Scholes Delta** for individual option expiries. 


            Note that DeltaTotal in account summary uses Net Transaction Delta
            instead. See the greeks object description for more details.
        gamma:
          type: number
          description: >
            (Only for option) The gamma value for the option. Calculated using
            standard Black Scholes without adjustments.


            Gamma measures the rate of change of delta with respect to changes
            in the underlying asset price.
        rho:
          type: number
          description: >
            (Only for option) The rho value for the option. Calculated using
            standard Black Scholes without adjustments.


            Rho measures the sensitivity of the option price to changes in the
            risk-free interest rate.
        theta:
          type: number
          description: >
            (Only for option) The theta value for the option. Deribit uses the
            **minimum of (1 day Theta, lifetime theta of the option)**.


            So if you take an option with 1 hour to expire for example,
            generally Black Scholes Theta will give you the equivalent 1 day
            Theta. Whereas we show the 1 hour Theta, so our Theta would differ
            from Black Scholes Theta when time to expiry is less than 1 day.


            Theta measures the rate of change of the option price with respect
            to time decay.
        vega:
          type: number
          description: >
            (Only for option) The vega value for the option. Calculated using
            standard Black Scholes without adjustments.


            Vega (not actually a Greek symbol) measures the sensitivity of the
            option price to changes in implied volatility.
      required:
        - delta
        - gamma
        - rho
        - theta
        - vega
      type: object
      description: >
        Only for options. Greeks are risk measures that describe how the
        option's price changes with respect to various factors.


        **Delta (Δ)**


        Deribit uses two different Deltas:

        - **DeltaTotal** in the account summary uses the **Net Transaction Delta
        (NTD)**

        - **Delta** for individual option expiries is the **Black Scholes
        Delta**


        In the settings section you can toggle Net Transaction Delta instead.


        **What is DeltaTotal in the account summary?**

        `DeltaTotal = Net Transaction Delta of options + BTC Position of
        Futures`


        **What is Net Transaction Delta?**

        `Net Transaction Delta = Black Scholes Delta - Mark Price of Options`


        **Why do we use a Net Transaction Delta?**

        The Delta Total uses the Net Transaction Delta (or price adjusted Delta)
        of the options. This is because, from a risk perspective, we are
        interested in the change in Bitcoin price as the underlying changes.


        You should actually treat your delta as **Equity + Delta Total** if you
        want to have less risk for your USD PnL.


        **Example:** Consider a call option with strike 0, which has a Black
        Scholes Delta of 1 and Net Transaction Delta = 0.


        Imagine you have 2 BTC equity and no positions and BTC price is at USD
        60k. In that case you would short 2 Futures contracts to hedge your USD
        exposure to BTC.


        Now let's say you buy one call with strike 0. The question is if you
        should sell another future?


        The call will always have a price of 1 BTC. So you buy it at 1 BTC which
        equates to USD 60k. Let's say the price increases to USD 70k. The value
        of the call is still 1 BTC. At settlement you receive 1 BTC for the
        call. So you paid 1 BTC and then receive 1 BTC which means your USD PnL
        on buying the call is 0. If you sold a future on it, then you would
        actually lose on the future.


        ⚠️ **During the 30 minute settlement period we decay your Delta.** See
        [Delta decay during
        settlement](https://support.deribit.com/hc/en-us/articles/25944751433757-Delta-decay-during-settlement)
        for more details.


        **Theta (Θ)**


        The Theta that Deribit uses is the **minimum of (1 day Theta, lifetime
        theta of the option)**. So if you take an option with 1 hour to expire
        for example, generally Black Scholes Theta will give you the equivalent
        1 day Theta. Whereas we show the 1 hour Theta, so our Theta would differ
        from Black Scholes Theta when time to expiry is less than 1 day.


        **Vega, Gamma, and Rho**


        Vega (not actually a Greek symbol), Gamma, Theta and Rho values shown on
        Deribit are calculated using **standard Black Scholes without
        adjustments**.
    funding_8h:
      type: number
      description: Funding 8h (perpetual only)
    current_funding:
      type: number
      description: Current funding (perpetual only)
    delivery_price:
      type: number
      description: The settlement price for the instrument. Only when `state = closed`
    settlement_price:
      type: number
      description: >-
        Optional (not added for spot). The settlement price for the instrument.
        Only when `state = open`
    bids:
      items:
        items:
          type: number
        minItems: 2
        maxItems: 2
        type: array
        description: List of bids (price-amount pairs)
      type: array
    asks:
      items:
        items:
          type: number
        minItems: 2
        maxItems: 2
        type: array
        description: List of asks (price-amount pairs)
      type: array
    volume_usd:
      type: number
      description: Volume in usd (futures only)

````

 
  
  

<AgentInstructions>

## Submitting Feedback

If you encounter incorrect, outdated, or confusing documentation on this page, submit feedback:

POST https://docs.deribit.com/feedback

```json
{
  "path": "/api-reference/market-data/public-get_supported_index_names",
  "feedback": "Description of the issue"
}
```

Only submit feedback when you have something specific and actionable to report.

</AgentInstructions>

# public/get_supported_index_names

> Retrieves the identifiers (names) of all supported price indexes, optionally filtered by index type. Price indexes are reference prices used for mark price calculations, settlement, and other market operations.

Use the `type` parameter to filter indexes by type (e.g., spot, futures, etc.). This method helps discover available indexes for use with other API methods.

[Try in API console](https://test.deribit.com/api_console?method=%2Fpublic%2Fget_supported_index_names)





## OpenAPI

````yaml /specifications/deribit_openapi.json get /public/get_supported_index_names
openapi: 3.0.0
info:
  title: Deribit API
  version: 2.1.1
servers:
  - url: https://test.deribit.com/api/v2
security: []
tags:
  - name: WebSocket Only
    description: Can only be used over websockets.
  - name: Public
    description: Public methods can be used without authentication.
  - name: Private
    description: >-
      <p>Private methods require authentication. All requests must include a
      valid OAuth2 token.</p>

      <p>A token can be requested using the <a
      href="#public-auth">/public/auth</a> method.</p>

      <p>When using the websockets protocol, the token must be included as a
      parameter <code>access_token</code> in the message. When using REST (HTTP
      GET), the token may also be passed in the <code>Authorization</code>
      header.</p>
  - name: Authentication
  - name: Session Management
  - name: Subscription Management
    description: >-
      Subscription works as [notifications](#notifications), so users will
      automatically (after subscribing) receive messages from the server.
      Overview for each channel response format is described in
      [subscriptions](#subscriptions) section.
  - name: Account Management
  - name: Trading
  - name: Market Data
  - name: Wallet
  - name: Chat
paths:
  /public/get_supported_index_names:
    get:
      tags:
        - Market Data
        - Public
      description: >+
        Retrieves the identifiers (names) of all supported price indexes,
        optionally filtered by index type. Price indexes are reference prices
        used for mark price calculations, settlement, and other market
        operations.


        Use the `type` parameter to filter indexes by type (e.g., spot, futures,
        etc.). This method helps discover available indexes for use with other
        API methods.


        [Try in API
        console](https://test.deribit.com/api_console?method=%2Fpublic%2Fget_supported_index_names)

      parameters:
        - name: type
          required: false
          in: query
          schema:
            type: string
            enum:
              - all
              - spot
              - derivative
          description: Type of a cryptocurrency price index
      responses:
        '200':
          $ref: '#/components/responses/PublicGetIndexPriceNamesResponse'
components:
  responses:
    PublicGetIndexPriceNamesResponse:
      content:
        application/json:
          schema:
            $ref: '#/components/schemas/PublicGetIndexPriceNamesResponse'
          examples:
            response:
              value:
                jsonrpc: '2.0'
                id: 25718
                result:
                  - btc_eth
                  - btc_usdc
                  - eth_usdc
              description: Response example
      description: Success response
  schemas:
    PublicGetIndexPriceNamesResponse:
      properties:
        jsonrpc:
          type: string
          enum:
            - '2.0'
          description: The JSON-RPC version (2.0)
        id:
          type: integer
          description: The id that was sent in the request
        result:
          type: array
          items:
            type: object
            properties:
              name:
                type: string
                description: Index name
              future_combo_creation_enabled:
                type: boolean
                description: >-
                  Whether future combo creation is enabled for this index (only
                  present when `extended`=`true`)
              option_combo_creation_enabled:
                type: boolean
                description: >-
                  Whether option combo creation is enabled for this index (only
                  present when `extended`=`true`)
            required:
              - name
      required:
        - jsonrpc
        - result
      type: object

````

 
  
  

<AgentInstructions>

## Submitting Feedback

If you encounter incorrect, outdated, or confusing documentation on this page, submit feedback:

POST https://docs.deribit.com/feedback

```json
{
  "path": "/api-reference/market-data/public-get_trade_volumes",
  "feedback": "Description of the issue"
}
```

Only submit feedback when you have something specific and actionable to report.

</AgentInstructions>

# public/get_trade_volumes

> Retrieves aggregated 24-hour trade volumes for different instrument types and currencies. The volume statistics include all executed trades across the platform.

**Note:** Position moves are not included in this volume. Block trades and Block RFQ trades are included in the volume calculations.

Use the `extended` parameter to include additional volume statistics and breakdowns.

[Try in API console](https://test.deribit.com/api_console?method=%2Fpublic%2Fget_trade_volumes)





## OpenAPI

````yaml /specifications/deribit_openapi.json get /public/get_trade_volumes
openapi: 3.0.0
info:
  title: Deribit API
  version: 2.1.1
servers:
  - url: https://test.deribit.com/api/v2
security: []
tags:
  - name: WebSocket Only
    description: Can only be used over websockets.
  - name: Public
    description: Public methods can be used without authentication.
  - name: Private
    description: >-
      <p>Private methods require authentication. All requests must include a
      valid OAuth2 token.</p>

      <p>A token can be requested using the <a
      href="#public-auth">/public/auth</a> method.</p>

      <p>When using the websockets protocol, the token must be included as a
      parameter <code>access_token</code> in the message. When using REST (HTTP
      GET), the token may also be passed in the <code>Authorization</code>
      header.</p>
  - name: Authentication
  - name: Session Management
  - name: Subscription Management
    description: >-
      Subscription works as [notifications](#notifications), so users will
      automatically (after subscribing) receive messages from the server.
      Overview for each channel response format is described in
      [subscriptions](#subscriptions) section.
  - name: Account Management
  - name: Trading
  - name: Market Data
  - name: Wallet
  - name: Chat
paths:
  /public/get_trade_volumes:
    get:
      tags:
        - Market Data
        - Public
      description: >+
        Retrieves aggregated 24-hour trade volumes for different instrument
        types and currencies. The volume statistics include all executed trades
        across the platform.


        **Note:** Position moves are not included in this volume. Block trades
        and Block RFQ trades are included in the volume calculations.


        Use the `extended` parameter to include additional volume statistics and
        breakdowns.


        [Try in API
        console](https://test.deribit.com/api_console?method=%2Fpublic%2Fget_trade_volumes)

      parameters:
        - name: extended
          in: query
          required: false
          schema:
            type: boolean
          description: >-
            Request for extended statistics. Including also 7 and 30 days
            volumes (default false)
      responses:
        '200':
          $ref: '#/components/responses/PublicGetTradesVolumesResponse'
components:
  responses:
    PublicGetTradesVolumesResponse:
      content:
        application/json:
          schema:
            $ref: '#/components/schemas/PublicGetTradesVolumesResponse'
          examples:
            response:
              value:
                jsonrpc: '2.0'
                id: 6387
                result:
                  - puts_volume: 48
                    futures_volume: 6.25578452
                    currency: BTC
                    calls_volume: 145
                    spot_volume: 11.1
                  - puts_volume: 122.65
                    futures_volume: 374.392173
                    currency: ETH
                    calls_volume: 37.4
                    spot_volume: 57.7
              description: Response example
      description: Success response
  schemas:
    PublicGetTradesVolumesResponse:
      properties:
        jsonrpc:
          type: string
          enum:
            - '2.0'
          description: The JSON-RPC version (2.0)
        id:
          type: integer
          description: The id that was sent in the request
        result:
          type: array
          items:
            $ref: '#/components/schemas/trades_volumes'
      required:
        - jsonrpc
        - result
      type: object
    trades_volumes:
      properties:
        currency:
          $ref: '#/components/schemas/currency'
        calls_volume:
          example: 20.1
          type: number
          description: Total 24h trade volume for call options.
        puts_volume:
          example: 60.2
          type: number
          description: Total 24h trade volume for put options.
        futures_volume:
          example: 30.5178
          type: number
          description: Total 24h trade volume for futures.
        spot_volume:
          example: 11.6
          type: number
          description: Total 24h trade for spot.
        calls_volume_7d:
          example: 75.6
          type: number
          description: Total 7d trade volume for call options.
        puts_volume_7d:
          example: 356.9
          type: number
          description: Total 7d trade volume for put options.
        futures_volume_7d:
          example: 213.8841
          type: number
          description: Total 7d trade volume for futures.
        spot_volume_7d:
          example: 64.8
          type: number
          description: Total 7d trade for spot.
        calls_volume_30d:
          example: 547.3
          type: number
          description: Total 30d trade volume for call options.
        puts_volume_30d:
          example: 785.5
          type: number
          description: Total 30d trade volume for put options.
        futures_volume_30d:
          example: 998.2128
          type: number
          description: Total 30d trade volume for futures.
        spot_volume_30d:
          example: 310.5
          type: number
          description: Total 30d trade for spot.
      required:
        - currency
        - futures_volume
        - puts_volume
        - calls_volume
      type: object
    currency:
      enum:
        - BTC
        - ETH
        - USDC
        - USDT
        - EURR
      type: string
      description: Currency, i.e `"BTC"`, `"ETH"`, `"USDC"`

````

 
  
  

<AgentInstructions>

## Submitting Feedback

If you encounter incorrect, outdated, or confusing documentation on this page, submit feedback:

POST https://docs.deribit.com/feedback

```json
{
  "path": "/api-reference/market-data/public-get_tradingview_chart_data",
  "feedback": "Description of the issue"
}
```

Only submit feedback when you have something specific and actionable to report.

</AgentInstructions>

# public/get_tradingview_chart_data

> Retrieves publicly available market data formatted for generating TradingView-compatible candle charts. The data includes open, high, low, close (OHLC) prices and volume for specified time intervals.

Use the `chart_resolution` parameter to specify the candle interval (e.g., 1m, 5m, 1h, 1d). This method provides the standard format used by TradingView and other charting platforms.

[Try in API console](https://test.deribit.com/api_console?method=%2Fpublic%2Fget_tradingview_chart_data)





## OpenAPI

````yaml /specifications/deribit_openapi.json get /public/get_tradingview_chart_data
openapi: 3.0.0
info:
  title: Deribit API
  version: 2.1.1
servers:
  - url: https://test.deribit.com/api/v2
security: []
tags:
  - name: WebSocket Only
    description: Can only be used over websockets.
  - name: Public
    description: Public methods can be used without authentication.
  - name: Private
    description: >-
      <p>Private methods require authentication. All requests must include a
      valid OAuth2 token.</p>

      <p>A token can be requested using the <a
      href="#public-auth">/public/auth</a> method.</p>

      <p>When using the websockets protocol, the token must be included as a
      parameter <code>access_token</code> in the message. When using REST (HTTP
      GET), the token may also be passed in the <code>Authorization</code>
      header.</p>
  - name: Authentication
  - name: Session Management
  - name: Subscription Management
    description: >-
      Subscription works as [notifications](#notifications), so users will
      automatically (after subscribing) receive messages from the server.
      Overview for each channel response format is described in
      [subscriptions](#subscriptions) section.
  - name: Account Management
  - name: Trading
  - name: Market Data
  - name: Wallet
  - name: Chat
paths:
  /public/get_tradingview_chart_data:
    get:
      tags:
        - Market Data
        - Public
      description: >+
        Retrieves publicly available market data formatted for generating
        TradingView-compatible candle charts. The data includes open, high, low,
        close (OHLC) prices and volume for specified time intervals.


        Use the `chart_resolution` parameter to specify the candle interval
        (e.g., 1m, 5m, 1h, 1d). This method provides the standard format used by
        TradingView and other charting platforms.


        [Try in API
        console](https://test.deribit.com/api_console?method=%2Fpublic%2Fget_tradingview_chart_data)

      parameters:
        - name: instrument_name
          required: true
          in: query
          schema:
            $ref: '#/components/schemas/instrument_name'
          description: Instrument name
        - name: start_timestamp
          required: true
          in: query
          schema:
            $ref: '#/components/schemas/timestamp'
          description: >-
            The earliest timestamp to return result from (milliseconds since the
            UNIX epoch)
        - name: end_timestamp
          required: true
          in: query
          schema:
            $ref: '#/components/schemas/timestamp'
          description: >-
            The most recent timestamp to return result from (milliseconds since
            the UNIX epoch)
        - name: resolution
          in: query
          schema:
            type: string
            enum:
              - 1
              - 3
              - 5
              - 10
              - 15
              - 30
              - 60
              - 120
              - 180
              - 360
              - 720
              - 1D
          required: true
          description: >-
            Chart bars resolution given in full minutes or keyword `1D` (only
            some specific resolutions are supported)
      requestBody:
        content:
          application/json:
            examples:
              request:
                value:
                  jsonrpc: '2.0'
                  id: 833
                  method: public/get_tradingview_chart_data
                  params:
                    instrument_name: BTC-5APR19
                    start_timestamp: 1554373800000
                    end_timestamp: 1554376800000
                    resolution: '30'
                description: JSON-RPC Request Example
        description: JSON-RPC request body
      responses:
        '200':
          $ref: '#/components/responses/PublicGetTradingviewChartDataResponse'
components:
  schemas:
    instrument_name:
      example: BTC-PERPETUAL
      type: string
      description: Unique instrument identifier
    timestamp:
      example: 1536569522277
      type: integer
      description: The timestamp (milliseconds since the Unix epoch)
    PublicGetTradingviewChartDataResponse:
      properties:
        jsonrpc:
          type: string
          enum:
            - '2.0'
          description: The JSON-RPC version (2.0)
        id:
          type: integer
          description: The id that was sent in the request
        result:
          type: object
          properties:
            status:
              type: string
              enum:
                - ok
                - no_data
              description: 'Status of the query: `ok` or `no_data`'
            ticks:
              type: array
              items:
                $ref: '#/components/schemas/timestamp'
              description: Values of the time axis given in milliseconds since UNIX epoch
            volume:
              type: array
              items:
                $ref: '#/components/schemas/chart_volume'
              description: List of volume bars (in base currency, one per candle)
            cost:
              type: array
              items:
                $ref: '#/components/schemas/chart_volume'
              description: List of cost bars (volume in quote currency, one per candle)
            open:
              type: array
              items:
                $ref: '#/components/schemas/quote_price'
              description: List of prices at open (one per candle)
            close:
              type: array
              items:
                $ref: '#/components/schemas/quote_price'
              description: List of prices at close (one per candle)
            high:
              type: array
              items:
                $ref: '#/components/schemas/quote_price'
              description: List of highest price levels (one per candle)
            low:
              type: array
              items:
                $ref: '#/components/schemas/quote_price'
              description: List of lowest price levels (one per candle)
      required:
        - jsonrpc
        - result
      type: object
    chart_volume:
      type: number
      description: // todo
    quote_price:
      type: number
      description: Price in quote currency
  responses:
    PublicGetTradingviewChartDataResponse:
      content:
        application/json:
          schema:
            $ref: '#/components/schemas/PublicGetTradingviewChartDataResponse'
          examples:
            response:
              value:
                jsonrpc: '2.0'
                id: 833
                result:
                  volume:
                    - 19.007942601
                    - 20.095877981
                  cost:
                    - 19000
                    - 23400
                  ticks:
                    - 1554373800000
                    - 1554375600000
                  status: ok
                  open:
                    - 4963.42
                    - 4986.29
                  low:
                    - 4728.94
                    - 4726.6
                  high:
                    - 5185.45
                    - 5250.87
                  close:
                    - 5052.95
                    - 5013.59
                usIn: 1554381680742493
                usOut: 1554381680742698
                usDiff: 205
                testnet: false
              description: Response example
      description: Success response

````

 
  
  

<AgentInstructions>

## Submitting Feedback

If you encounter incorrect, outdated, or confusing documentation on this page, submit feedback:

POST https://docs.deribit.com/feedback

```json
{
  "path": "/api-reference/market-data/public-get_tradingview_chart_data",
  "feedback": "Description of the issue"
}
```

Only submit feedback when you have something specific and actionable to report.

</AgentInstructions>

# public/get_tradingview_chart_data

> Retrieves publicly available market data formatted for generating TradingView-compatible candle charts. The data includes open, high, low, close (OHLC) prices and volume for specified time intervals.

Use the `chart_resolution` parameter to specify the candle interval (e.g., 1m, 5m, 1h, 1d). This method provides the standard format used by TradingView and other charting platforms.

[Try in API console](https://test.deribit.com/api_console?method=%2Fpublic%2Fget_tradingview_chart_data)





## OpenAPI

````yaml /specifications/deribit_openapi.json get /public/get_tradingview_chart_data
openapi: 3.0.0
info:
  title: Deribit API
  version: 2.1.1
servers:
  - url: https://test.deribit.com/api/v2
security: []
tags:
  - name: WebSocket Only
    description: Can only be used over websockets.
  - name: Public
    description: Public methods can be used without authentication.
  - name: Private
    description: >-
      <p>Private methods require authentication. All requests must include a
      valid OAuth2 token.</p>

      <p>A token can be requested using the <a
      href="#public-auth">/public/auth</a> method.</p>

      <p>When using the websockets protocol, the token must be included as a
      parameter <code>access_token</code> in the message. When using REST (HTTP
      GET), the token may also be passed in the <code>Authorization</code>
      header.</p>
  - name: Authentication
  - name: Session Management
  - name: Subscription Management
    description: >-
      Subscription works as [notifications](#notifications), so users will
      automatically (after subscribing) receive messages from the server.
      Overview for each channel response format is described in
      [subscriptions](#subscriptions) section.
  - name: Account Management
  - name: Trading
  - name: Market Data
  - name: Wallet
  - name: Chat
paths:
  /public/get_tradingview_chart_data:
    get:
      tags:
        - Market Data
        - Public
      description: >+
        Retrieves publicly available market data formatted for generating
        TradingView-compatible candle charts. The data includes open, high, low,
        close (OHLC) prices and volume for specified time intervals.


        Use the `chart_resolution` parameter to specify the candle interval
        (e.g., 1m, 5m, 1h, 1d). This method provides the standard format used by
        TradingView and other charting platforms.


        [Try in API
        console](https://test.deribit.com/api_console?method=%2Fpublic%2Fget_tradingview_chart_data)

      parameters:
        - name: instrument_name
          required: true
          in: query
          schema:
            $ref: '#/components/schemas/instrument_name'
          description: Instrument name
        - name: start_timestamp
          required: true
          in: query
          schema:
            $ref: '#/components/schemas/timestamp'
          description: >-
            The earliest timestamp to return result from (milliseconds since the
            UNIX epoch)
        - name: end_timestamp
          required: true
          in: query
          schema:
            $ref: '#/components/schemas/timestamp'
          description: >-
            The most recent timestamp to return result from (milliseconds since
            the UNIX epoch)
        - name: resolution
          in: query
          schema:
            type: string
            enum:
              - 1
              - 3
              - 5
              - 10
              - 15
              - 30
              - 60
              - 120
              - 180
              - 360
              - 720
              - 1D
          required: true
          description: >-
            Chart bars resolution given in full minutes or keyword `1D` (only
            some specific resolutions are supported)
      requestBody:
        content:
          application/json:
            examples:
              request:
                value:
                  jsonrpc: '2.0'
                  id: 833
                  method: public/get_tradingview_chart_data
                  params:
                    instrument_name: BTC-5APR19
                    start_timestamp: 1554373800000
                    end_timestamp: 1554376800000
                    resolution: '30'
                description: JSON-RPC Request Example
        description: JSON-RPC request body
      responses:
        '200':
          $ref: '#/components/responses/PublicGetTradingviewChartDataResponse'
components:
  schemas:
    instrument_name:
      example: BTC-PERPETUAL
      type: string
      description: Unique instrument identifier
    timestamp:
      example: 1536569522277
      type: integer
      description: The timestamp (milliseconds since the Unix epoch)
    PublicGetTradingviewChartDataResponse:
      properties:
        jsonrpc:
          type: string
          enum:
            - '2.0'
          description: The JSON-RPC version (2.0)
        id:
          type: integer
          description: The id that was sent in the request
        result:
          type: object
          properties:
            status:
              type: string
              enum:
                - ok
                - no_data
              description: 'Status of the query: `ok` or `no_data`'
            ticks:
              type: array
              items:
                $ref: '#/components/schemas/timestamp'
              description: Values of the time axis given in milliseconds since UNIX epoch
            volume:
              type: array
              items:
                $ref: '#/components/schemas/chart_volume'
              description: List of volume bars (in base currency, one per candle)
            cost:
              type: array
              items:
                $ref: '#/components/schemas/chart_volume'
              description: List of cost bars (volume in quote currency, one per candle)
            open:
              type: array
              items:
                $ref: '#/components/schemas/quote_price'
              description: List of prices at open (one per candle)
            close:
              type: array
              items:
                $ref: '#/components/schemas/quote_price'
              description: List of prices at close (one per candle)
            high:
              type: array
              items:
                $ref: '#/components/schemas/quote_price'
              description: List of highest price levels (one per candle)
            low:
              type: array
              items:
                $ref: '#/components/schemas/quote_price'
              description: List of lowest price levels (one per candle)
      required:
        - jsonrpc
        - result
      type: object
    chart_volume:
      type: number
      description: // todo
    quote_price:
      type: number
      description: Price in quote currency
  responses:
    PublicGetTradingviewChartDataResponse:
      content:
        application/json:
          schema:
            $ref: '#/components/schemas/PublicGetTradingviewChartDataResponse'
          examples:
            response:
              value:
                jsonrpc: '2.0'
                id: 833
                result:
                  volume:
                    - 19.007942601
                    - 20.095877981
                  cost:
                    - 19000
                    - 23400
                  ticks:
                    - 1554373800000
                    - 1554375600000
                  status: ok
                  open:
                    - 4963.42
                    - 4986.29
                  low:
                    - 4728.94
                    - 4726.6
                  high:
                    - 5185.45
                    - 5250.87
                  close:
                    - 5052.95
                    - 5013.59
                usIn: 1554381680742493
                usOut: 1554381680742698
                usDiff: 205
                testnet: false
              description: Response example
      description: Success response

````

 
  
  

<AgentInstructions>

## Submitting Feedback

If you encounter incorrect, outdated, or confusing documentation on this page, submit feedback:

POST https://docs.deribit.com/feedback

```json
{
  "path": "/api-reference/market-data/public-get_tradingview_chart_data",
  "feedback": "Description of the issue"
}
```

Only submit feedback when you have something specific and actionable to report.

</AgentInstructions>

# public/get_tradingview_chart_data

> Retrieves publicly available market data formatted for generating TradingView-compatible candle charts. The data includes open, high, low, close (OHLC) prices and volume for specified time intervals.

Use the `chart_resolution` parameter to specify the candle interval (e.g., 1m, 5m, 1h, 1d). This method provides the standard format used by TradingView and other charting platforms.

[Try in API console](https://test.deribit.com/api_console?method=%2Fpublic%2Fget_tradingview_chart_data)





## OpenAPI

````yaml /specifications/deribit_openapi.json get /public/get_tradingview_chart_data
openapi: 3.0.0
info:
  title: Deribit API
  version: 2.1.1
servers:
  - url: https://test.deribit.com/api/v2
security: []
tags:
  - name: WebSocket Only
    description: Can only be used over websockets.
  - name: Public
    description: Public methods can be used without authentication.
  - name: Private
    description: >-
      <p>Private methods require authentication. All requests must include a
      valid OAuth2 token.</p>

      <p>A token can be requested using the <a
      href="#public-auth">/public/auth</a> method.</p>

      <p>When using the websockets protocol, the token must be included as a
      parameter <code>access_token</code> in the message. When using REST (HTTP
      GET), the token may also be passed in the <code>Authorization</code>
      header.</p>
  - name: Authentication
  - name: Session Management
  - name: Subscription Management
    description: >-
      Subscription works as [notifications](#notifications), so users will
      automatically (after subscribing) receive messages from the server.
      Overview for each channel response format is described in
      [subscriptions](#subscriptions) section.
  - name: Account Management
  - name: Trading
  - name: Market Data
  - name: Wallet
  - name: Chat
paths:
  /public/get_tradingview_chart_data:
    get:
      tags:
        - Market Data
        - Public
      description: >+
        Retrieves publicly available market data formatted for generating
        TradingView-compatible candle charts. The data includes open, high, low,
        close (OHLC) prices and volume for specified time intervals.


        Use the `chart_resolution` parameter to specify the candle interval
        (e.g., 1m, 5m, 1h, 1d). This method provides the standard format used by
        TradingView and other charting platforms.


        [Try in API
        console](https://test.deribit.com/api_console?method=%2Fpublic%2Fget_tradingview_chart_data)

      parameters:
        - name: instrument_name
          required: true
          in: query
          schema:
            $ref: '#/components/schemas/instrument_name'
          description: Instrument name
        - name: start_timestamp
          required: true
          in: query
          schema:
            $ref: '#/components/schemas/timestamp'
          description: >-
            The earliest timestamp to return result from (milliseconds since the
            UNIX epoch)
        - name: end_timestamp
          required: true
          in: query
          schema:
            $ref: '#/components/schemas/timestamp'
          description: >-
            The most recent timestamp to return result from (milliseconds since
            the UNIX epoch)
        - name: resolution
          in: query
          schema:
            type: string
            enum:
              - 1
              - 3
              - 5
              - 10
              - 15
              - 30
              - 60
              - 120
              - 180
              - 360
              - 720
              - 1D
          required: true
          description: >-
            Chart bars resolution given in full minutes or keyword `1D` (only
            some specific resolutions are supported)
      requestBody:
        content:
          application/json:
            examples:
              request:
                value:
                  jsonrpc: '2.0'
                  id: 833
                  method: public/get_tradingview_chart_data
                  params:
                    instrument_name: BTC-5APR19
                    start_timestamp: 1554373800000
                    end_timestamp: 1554376800000
                    resolution: '30'
                description: JSON-RPC Request Example
        description: JSON-RPC request body
      responses:
        '200':
          $ref: '#/components/responses/PublicGetTradingviewChartDataResponse'
components:
  schemas:
    instrument_name:
      example: BTC-PERPETUAL
      type: string
      description: Unique instrument identifier
    timestamp:
      example: 1536569522277
      type: integer
      description: The timestamp (milliseconds since the Unix epoch)
    PublicGetTradingviewChartDataResponse:
      properties:
        jsonrpc:
          type: string
          enum:
            - '2.0'
          description: The JSON-RPC version (2.0)
        id:
          type: integer
          description: The id that was sent in the request
        result:
          type: object
          properties:
            status:
              type: string
              enum:
                - ok
                - no_data
              description: 'Status of the query: `ok` or `no_data`'
            ticks:
              type: array
              items:
                $ref: '#/components/schemas/timestamp'
              description: Values of the time axis given in milliseconds since UNIX epoch
            volume:
              type: array
              items:
                $ref: '#/components/schemas/chart_volume'
              description: List of volume bars (in base currency, one per candle)
            cost:
              type: array
              items:
                $ref: '#/components/schemas/chart_volume'
              description: List of cost bars (volume in quote currency, one per candle)
            open:
              type: array
              items:
                $ref: '#/components/schemas/quote_price'
              description: List of prices at open (one per candle)
            close:
              type: array
              items:
                $ref: '#/components/schemas/quote_price'
              description: List of prices at close (one per candle)
            high:
              type: array
              items:
                $ref: '#/components/schemas/quote_price'
              description: List of highest price levels (one per candle)
            low:
              type: array
              items:
                $ref: '#/components/schemas/quote_price'
              description: List of lowest price levels (one per candle)
      required:
        - jsonrpc
        - result
      type: object
    chart_volume:
      type: number
      description: // todo
    quote_price:
      type: number
      description: Price in quote currency
  responses:
    PublicGetTradingviewChartDataResponse:
      content:
        application/json:
          schema:
            $ref: '#/components/schemas/PublicGetTradingviewChartDataResponse'
          examples:
            response:
              value:
                jsonrpc: '2.0'
                id: 833
                result:
                  volume:
                    - 19.007942601
                    - 20.095877981
                  cost:
                    - 19000
                    - 23400
                  ticks:
                    - 1554373800000
                    - 1554375600000
                  status: ok
                  open:
                    - 4963.42
                    - 4986.29
                  low:
                    - 4728.94
                    - 4726.6
                  high:
                    - 5185.45
                    - 5250.87
                  close:
                    - 5052.95
                    - 5013.59
                usIn: 1554381680742493
                usOut: 1554381680742698
                usDiff: 205
                testnet: false
              description: Response example
      description: Success response

````

 
  
  

<AgentInstructions>

## Submitting Feedback

If you encounter incorrect, outdated, or confusing documentation on this page, submit feedback:

POST https://docs.deribit.com/feedback

```json
{
  "path": "/api-reference/market-data/public-get_index_chart_data",
  "feedback": "Description of the issue"
}
```

Only submit feedback when you have something specific and actionable to report.

</AgentInstructions>

# public/get_index_chart_data

> Returns historical price index chart data for the specified index name and time range. The data is formatted for use in charting applications and shows price index values over time.

Use the `range` parameter to specify the time period for which to retrieve chart data. This method is useful for visualizing price index trends and historical movements.

[Try in API console](https://test.deribit.com/api_console?method=%2Fpublic%2Fget_index_chart_data)





## OpenAPI

````yaml /specifications/deribit_openapi.json get /public/get_index_chart_data
openapi: 3.0.0
info:
  title: Deribit API
  version: 2.1.1
servers:
  - url: https://test.deribit.com/api/v2
security: []
tags:
  - name: WebSocket Only
    description: Can only be used over websockets.
  - name: Public
    description: Public methods can be used without authentication.
  - name: Private
    description: >-
      <p>Private methods require authentication. All requests must include a
      valid OAuth2 token.</p>

      <p>A token can be requested using the <a
      href="#public-auth">/public/auth</a> method.</p>

      <p>When using the websockets protocol, the token must be included as a
      parameter <code>access_token</code> in the message. When using REST (HTTP
      GET), the token may also be passed in the <code>Authorization</code>
      header.</p>
  - name: Authentication
  - name: Session Management
  - name: Subscription Management
    description: >-
      Subscription works as [notifications](#notifications), so users will
      automatically (after subscribing) receive messages from the server.
      Overview for each channel response format is described in
      [subscriptions](#subscriptions) section.
  - name: Account Management
  - name: Trading
  - name: Market Data
  - name: Wallet
  - name: Chat
paths:
  /public/get_index_chart_data:
    get:
      tags:
        - Market Data
        - Public
      description: >+
        Returns historical price index chart data for the specified index name
        and time range. The data is formatted for use in charting applications
        and shows price index values over time.


        Use the `range` parameter to specify the time period for which to
        retrieve chart data. This method is useful for visualizing price index
        trends and historical movements.


        [Try in API
        console](https://test.deribit.com/api_console?method=%2Fpublic%2Fget_index_chart_data)

      parameters:
        - name: index_name
          required: true
          in: query
          schema:
            $ref: '#/components/schemas/index_name'
          description: Index identifier, matches (base) cryptocurrency with quote currency
        - name: range
          in: query
          required: true
          schema:
            type: string
            enum:
              - 1h
              - 1d
              - 2d
              - 1m
              - 1y
              - all
          description: Range of the data to return
      requestBody:
        content:
          application/json:
            examples:
              request:
                value:
                  jsonrpc: '2.0'
                  id: 1
                  method: public/get_index_chart_data
                  params:
                    index_name: btc_usd
                    range: 1m
                description: JSON-RPC Request Example
        description: JSON-RPC request body
      responses:
        '200':
          $ref: '#/components/responses/PublicGetIndexChartDataResponse'
components:
  schemas:
    index_name:
      enum:
        - btc_usd
        - eth_usd
        - ada_usdc
        - algo_usdc
        - avax_usdc
        - bch_usdc
        - bnb_usdc
        - btc_usdc
        - btcdvol_usdc
        - buidl_usdc
        - doge_usdc
        - dot_usdc
        - eurr_usdc
        - eth_usdc
        - ethdvol_usdc
        - link_usdc
        - ltc_usdc
        - near_usdc
        - paxg_usdc
        - shib_usdc
        - sol_usdc
        - steth_usdc
        - ton_usdc
        - trump_usdc
        - trx_usdc
        - uni_usdc
        - usde_usdc
        - usyc_usdc
        - xrp_usdc
        - btc_usdt
        - eth_usdt
        - eurr_usdt
        - sol_usdt
        - steth_usdt
        - usdc_usdt
        - usde_usdt
        - btc_eurr
        - btc_usde
        - btc_usyc
        - eth_btc
        - eth_eurr
        - eth_usde
        - eth_usyc
        - steth_eth
        - paxg_btc
        - drbfix-btc_usdc
        - drbfix-eth_usdc
      type: string
      description: Index identifier, matches (base) cryptocurrency with quote currency
    PublicGetIndexChartDataResponse:
      properties:
        jsonrpc:
          type: string
          enum:
            - '2.0'
          description: The JSON-RPC version (2.0)
        id:
          type: integer
          description: The id that was sent in the request
        result:
          type: array
          description: >
            **Response:**

            The response returns an array of data points, where each data point
            is an array containing:


            - **Index 0**: Timestamp in milliseconds since the Unix epoch

            - **Index 1**: Average index price at that timestamp


            Example response structure:

            ```json

            [
             [1573228800000, 8751.7138636],
             [1573232400000, 8751.7138636],
             [1573236000000, 8751.7138636]
            ]

            ```


            Each entry in the result array represents a single data point:


            - The first value (timestamp) indicates when the price was recorded

            - The second value (price) is the average index price at that
            timestamp


            The data points are returned in chronological order, making them
            ready for direct use in charting libraries.
      required:
        - jsonrpc
        - result
      type: object
  responses:
    PublicGetIndexChartDataResponse:
      content:
        application/json:
          schema:
            $ref: '#/components/schemas/PublicGetIndexChartDataResponse'
          examples:
            response:
              value:
                jsonrpc: '2.0'
                id: 1
                result:
                  - - 1573228800000
                    - 8751.7138636
                  - - 1573232400000
                    - 8751.7138636
                  - - 1573236000000
                    - 8751.7138636
                  - - 1573239600000
                    - 8751.7138636
                  - - 1573243200000
                    - 8751.7138636
              description: Response example
      description: Success response

````
