> ## Documentation Index
> Fetch the complete documentation index at: https://docs.deribit.com/llms.txt
> Use this file to discover all available pages before exploring further.

<AgentInstructions>

## Submitting Feedback

If you encounter incorrect, outdated, or confusing documentation on this page, submit feedback:

POST https://docs.deribit.com/feedback

```json
{
  "path": "/api-reference/account-management/private-change_api_key_name",
  "feedback": "Description of the issue"
}
```

Only submit feedback when you have something specific and actionable to report.

</AgentInstructions>

# private/change_api_key_name

> Updates the display name for an API key. The name is used for identification purposes in the API key list and does not affect the key's functionality or permissions.

**📖 Related Article:** [Creating new API key on Deribit](https://docs.deribit.com/articles/creating-api-key)

**Scope:** `account:read_write`

[Try in API console](https://test.deribit.com/api_console?method=%2Fprivate%2Fchange_api_key_name)





## OpenAPI

````yaml /specifications/deribit_openapi.json get /private/change_api_key_name
openapi: 3.0.0
info:
  title: Deribit API
  version: 2.1.1
servers:
  - url: https://test.deribit.com/api/v2
security: []
tags:
  - name: WebSocket Only
    description: Can only be used over websockets.
  - name: Public
    description: Public methods can be used without authentication.
  - name: Private
    description: >-
      <p>Private methods require authentication. All requests must include a
      valid OAuth2 token.</p>

      <p>A token can be requested using the <a
      href="#public-auth">/public/auth</a> method.</p>

      <p>When using the websockets protocol, the token must be included as a
      parameter <code>access_token</code> in the message. When using REST (HTTP
      GET), the token may also be passed in the <code>Authorization</code>
      header.</p>
  - name: Authentication
  - name: Session Management
  - name: Subscription Management
    description: >-
      Subscription works as [notifications](#notifications), so users will
      automatically (after subscribing) receive messages from the server.
      Overview for each channel response format is described in
      [subscriptions](#subscriptions) section.
  - name: Account Management
  - name: Trading
  - name: Market Data
  - name: Wallet
  - name: Chat
paths:
  /private/change_api_key_name:
    get:
      tags:
        - Account Management
        - Private
      description: >+
        Updates the display name for an API key. The name is used for
        identification purposes in the API key list and does not affect the
        key's functionality or permissions.


        **📖 Related Article:** [Creating new API key on
        Deribit](https://docs.deribit.com/articles/creating-api-key)


        **Scope:** `account:read_write`


        [Try in API
        console](https://test.deribit.com/api_console?method=%2Fprivate%2Fchange_api_key_name)

      parameters:
        - name: id
          in: query
          required: true
          schema:
            type: integer
            example: 1
          description: API key ID
        - name: name
          in: query
          schema:
            type: string
            example: TestName
          required: true
          description: >-
            Name of key (only letters, numbers and underscores allowed; maximum
            length - 16 characters)
      requestBody:
        content:
          application/json:
            examples:
              request:
                value:
                  jsonrpc: '2.0'
                  id: 2453
                  method: private/change_api_key_name
                  params:
                    name: KeyName3
                    id: 3
                description: JSON-RPC Request Example
        description: JSON-RPC request body
      responses:
        '200':
          $ref: '#/components/responses/PrivateApiKeyResponse'
components:
  responses:
    PrivateApiKeyResponse:
      content:
        application/json:
          schema:
            $ref: '#/components/schemas/PrivateApiKeyResponse'
          examples:
            response:
              value:
                jsonrpc: '2.0'
                id: 2453
                result:
                  timestamp: 1560242482758
                  max_scope: >-
                    account:read_write block_trade:read trade:read_write
                    wallet:read_write
                  id: 3
                  enabled: true
                  default: false
                  client_secret: B6RsF9rrLY5ezEGBQkyLlV-UC7whyPJ34BMA-kKYpes
                  client_id: 1sXMQBhM
                  name: NewKeyName
              description: Response example
      description: Success response
  schemas:
    PrivateApiKeyResponse:
      properties:
        jsonrpc:
          type: string
          enum:
            - '2.0'
          description: The JSON-RPC version (2.0)
        id:
          type: integer
          description: The id that was sent in the request
        result:
          $ref: '#/components/schemas/api_key'
      required:
        - jsonrpc
        - result
      type: object
    api_key:
      properties:
        id:
          $ref: '#/components/schemas/key_id'
        timestamp:
          $ref: '#/components/schemas/timestamp'
        client_id:
          $ref: '#/components/schemas/client_id'
        client_secret:
          $ref: '#/components/schemas/client_secret'
        public_key:
          $ref: '#/components/schemas/public_key'
        max_scope:
          $ref: '#/components/schemas/max_scope'
        enabled:
          $ref: '#/components/schemas/api_key_enabled'
        default:
          $ref: '#/components/schemas/api_key_default'
        name:
          $ref: '#/components/schemas/api_key_name'
        enabled_features:
          $ref: '#/components/schemas/api_key_features'
        ip_whitelist:
          type: array
          description: List of IP addresses whitelisted for a selected key
      required:
        - id
        - timestamp
        - client_id
        - client_secret
        - max_scope
        - default
      type: object
    key_id:
      example: 1
      type: integer
      description: Key identifier
    timestamp:
      example: 1536569522277
      type: integer
      description: The timestamp (milliseconds since the Unix epoch)
    client_id:
      example: IY2D68DS
      type: string
      description: Client identifier used for authentication
    client_secret:
      example: P9Z_c73KaBPwpoTVfsXzehAhjhdJn5kM7Zlz_hhDhE8
      type: string
      description: Client secret or MD5 fingerprint of public key used for authentication
    public_key:
      example: >-
        -----BEGIN PUBLIC KEY-----
        MCowBQYDK2VwAyEApajFN0CSwIaaiIRPiFbiYYvpsLQLSccSLLsKPe984sc= -----END
        PUBLIC KEY-----
      type: string
      description: >-
        PEM encoded public key (Ed25519/RSA) used for asymmetric signatures
        (optional)
    max_scope:
      items:
        type: string
      example:
        - account:read
        - trade:read
        - block_trade:read_write
        - wallet:none
      type: array
      description: >
        Describes maximal access for tokens generated with given key. If scope
        is not provided, its value is set as none.


        **📖 Related Article:** [Access
        Scope](https://docs.deribit.com/articles/access-scope)
    api_key_enabled:
      example: true
      type: boolean
      description: Informs whether api key is enabled and can be used for authentication
    api_key_default:
      example: false
      type: boolean
      description: >-
        Informs whether this api key is default (field is deprecated and will be
        removed in the future)
    api_key_name:
      example: TestName
      type: string
      description: Api key name that can be displayed in transaction log
    api_key_features:
      items:
        type: string
      type: array
      description: >-
        List of enabled advanced on-key features.<br><br><b>Available
        options:</b><br>- <code>restricted_block_trades</code>: Limit the
        block_trade read the scope of the API key to block trades that have been
        made using this specific API key<br>- <code>block_trade_approval</code>:
        Block trades created using this API key require additional user
        approval. Methods that use <code>block_rfq</code> scope are not affected
        by Block Trade approval feature

````

> ## Documentation Index
> Fetch the complete documentation index at: https://docs.deribit.com/llms.txt
> Use this file to discover all available pages before exploring further.

<AgentInstructions>

## Submitting Feedback

If you encounter incorrect, outdated, or confusing documentation on this page, submit feedback:

POST https://docs.deribit.com/feedback

```json
{
  "path": "/api-reference/account-management/private-change_margin_model",
  "feedback": "Description of the issue"
}
```

Only submit feedback when you have something specific and actionable to report.

</AgentInstructions>

# private/change_margin_model

> Changes the margin model for the authenticated account or a specified subaccount. Margin models determine how margin requirements are calculated (e.g., Standard Margin vs. Portfolio Margin).

Changing the margin model may affect margin requirements, available funds, and trading capabilities. Use the `dry_run` parameter to preview the impact of the change before applying it.

**📖 Related Article:** [Margin types and usage](https://support.deribit.com/hc/en-us/articles/25944811317149-Margin-types-and-usage)

**Scope:** `account:read_write`

[Try in API console](https://test.deribit.com/api_console?method=%2Fprivate%2Fchange_margin_model)





## OpenAPI

````yaml /specifications/deribit_openapi.json get /private/change_margin_model
openapi: 3.0.0
info:
  title: Deribit API
  version: 2.1.1
servers:
  - url: https://test.deribit.com/api/v2
security: []
tags:
  - name: WebSocket Only
    description: Can only be used over websockets.
  - name: Public
    description: Public methods can be used without authentication.
  - name: Private
    description: >-
      <p>Private methods require authentication. All requests must include a
      valid OAuth2 token.</p>

      <p>A token can be requested using the <a
      href="#public-auth">/public/auth</a> method.</p>

      <p>When using the websockets protocol, the token must be included as a
      parameter <code>access_token</code> in the message. When using REST (HTTP
      GET), the token may also be passed in the <code>Authorization</code>
      header.</p>
  - name: Authentication
  - name: Session Management
  - name: Subscription Management
    description: >-
      Subscription works as [notifications](#notifications), so users will
      automatically (after subscribing) receive messages from the server.
      Overview for each channel response format is described in
      [subscriptions](#subscriptions) section.
  - name: Account Management
  - name: Trading
  - name: Market Data
  - name: Wallet
  - name: Chat
paths:
  /private/change_margin_model:
    get:
      tags:
        - Account Management
        - Private
      description: >+
        Changes the margin model for the authenticated account or a specified
        subaccount. Margin models determine how margin requirements are
        calculated (e.g., Standard Margin vs. Portfolio Margin).


        Changing the margin model may affect margin requirements, available
        funds, and trading capabilities. Use the `dry_run` parameter to preview
        the impact of the change before applying it.


        **📖 Related Article:** [Margin types and
        usage](https://support.deribit.com/hc/en-us/articles/25944811317149-Margin-types-and-usage)


        **Scope:** `account:read_write`


        [Try in API
        console](https://test.deribit.com/api_console?method=%2Fprivate%2Fchange_margin_model)

      parameters:
        - name: user_id
          in: query
          schema:
            type: integer
            example: 1
          required: false
          description: Id of a (sub)account - by default current user id is used
        - name: margin_model
          in: query
          schema:
            type: string
            enum:
              - cross_pm
              - cross_sm
              - segregated_pm
              - segregated_sm
          required: true
          description: Margin model
        - name: dry_run
          in: query
          schema:
            type: boolean
            example: true
          required: false
          description: >-
            If `true` request returns the result without switching the margining
            model. Default: `false`
      requestBody:
        content:
          application/json:
            examples:
              request:
                value:
                  jsonrpc: '2.0'
                  id: 1
                  method: private/change_margin_model
                  params:
                    user_id: 3
                    margin_model: cross_pm
                description: JSON-RPC Request Example
        description: JSON-RPC request body
      responses:
        '200':
          $ref: '#/components/responses/PrivateChangeMarginModelResponse'
components:
  responses:
    PrivateChangeMarginModelResponse:
      content:
        application/json:
          schema:
            $ref: '#/components/schemas/PrivateChangeMarginModelResponse'
          examples:
            response:
              value:
                jsonrpc: '2.0'
                id: 1
                result:
                  - old_state:
                      maintenance_margin_rate: 0
                      initial_margin_rate: 0
                      available_balance: 0
                    new_state:
                      maintenance_margin_rate: 0
                      initial_margin_rate: 0
                      available_balance: 0
                    currency: eth
                  - old_state:
                      maintenance_margin_rate: 0.02862727
                      initial_margin_rate: 0.45407615
                      available_balance: 0.553590509
                    new_state:
                      maintenance_margin_rate: 0.02710204
                      initial_margin_rate: 0.03252245
                      available_balance: 0.98106428
                    currency: btc
              description: Response example
      description: Success response
  schemas:
    PrivateChangeMarginModelResponse:
      properties:
        jsonrpc:
          type: string
          enum:
            - '2.0'
          description: The JSON-RPC version (2.0)
        id:
          type: integer
          description: The id that was sent in the request
        result:
          type: array
          items:
            type: object
            properties:
              old_state:
                type: object
                properties:
                  maintenance_margin_rate:
                    type: number
                    description: Maintenance margin rate before change
                  initial_margin_rate:
                    type: number
                    description: Initial margin rate before change
                  available_balance:
                    type: number
                    description: Available balance before change
                required:
                  - maintenance_margin_rate
                  - initial_margin_rate
                  - available_balance
                description: Represents portfolio state before change
              new_state:
                type: object
                properties:
                  maintenance_margin_rate:
                    type: number
                    description: Maintenance margin rate after change
                  initial_margin_rate:
                    type: number
                    description: Initial margin rate after change
                  available_balance:
                    type: number
                    description: Available balance after change
                required:
                  - maintenance_margin_rate
                  - initial_margin_rate
                  - available_balance
                description: Represents portfolio state after change
              currency:
                $ref: '#/components/schemas/currency'
            required:
              - old_state
              - new_state
              - currency
      required:
        - jsonrpc
        - result
      type: object
    currency:
      enum:
        - BTC
        - ETH
        - USDC
        - USDT
        - EURR
      type: string
      description: Currency, i.e `"BTC"`, `"ETH"`, `"USDC"`

````

> ## Documentation Index
> Fetch the complete documentation index at: https://docs.deribit.com/llms.txt
> Use this file to discover all available pages before exploring further.

<AgentInstructions>

## Submitting Feedback

If you encounter incorrect, outdated, or confusing documentation on this page, submit feedback:

POST https://docs.deribit.com/feedback

```json
{
  "path": "/api-reference/account-management/private-change_scope_in_api_key",
  "feedback": "Description of the issue"
}
```

Only submit feedback when you have something specific and actionable to report.

</AgentInstructions>

# private/change_scope_in_api_key

> Updates the scope (permissions) for an existing API key. The scope determines which operations the API key can perform (e.g., read-only, read-write, trading, etc.).

When the scope is changed, the API key immediately loses access to operations outside the new scope. Applications using this key may need to be updated to reflect the new permissions.

**[TFA required](https://docs.deribit.com/articles/security-keys)**

**📖 Related Articles:** 
- [Creating new API key on Deribit](https://docs.deribit.com/articles/creating-api-key)
- [Access Scope](https://docs.deribit.com/articles/access-scope)

**Scope:** `account:read_write`

[Try in API console](https://test.deribit.com/api_console?method=%2Fprivate%2Fchange_scope_in_api_key)





## OpenAPI

````yaml /specifications/deribit_openapi.json get /private/change_scope_in_api_key
openapi: 3.0.0
info:
  title: Deribit API
  version: 2.1.1
servers:
  - url: https://test.deribit.com/api/v2
security: []
tags:
  - name: WebSocket Only
    description: Can only be used over websockets.
  - name: Public
    description: Public methods can be used without authentication.
  - name: Private
    description: >-
      <p>Private methods require authentication. All requests must include a
      valid OAuth2 token.</p>

      <p>A token can be requested using the <a
      href="#public-auth">/public/auth</a> method.</p>

      <p>When using the websockets protocol, the token must be included as a
      parameter <code>access_token</code> in the message. When using REST (HTTP
      GET), the token may also be passed in the <code>Authorization</code>
      header.</p>
  - name: Authentication
  - name: Session Management
  - name: Subscription Management
    description: >-
      Subscription works as [notifications](#notifications), so users will
      automatically (after subscribing) receive messages from the server.
      Overview for each channel response format is described in
      [subscriptions](#subscriptions) section.
  - name: Account Management
  - name: Trading
  - name: Market Data
  - name: Wallet
  - name: Chat
paths:
  /private/change_scope_in_api_key:
    get:
      tags:
        - Account Management
        - Private
      description: >+
        Updates the scope (permissions) for an existing API key. The scope
        determines which operations the API key can perform (e.g., read-only,
        read-write, trading, etc.).


        When the scope is changed, the API key immediately loses access to
        operations outside the new scope. Applications using this key may need
        to be updated to reflect the new permissions.


        **[TFA required](https://docs.deribit.com/articles/security-keys)**


        **📖 Related Articles:** 

        - [Creating new API key on
        Deribit](https://docs.deribit.com/articles/creating-api-key)

        - [Access Scope](https://docs.deribit.com/articles/access-scope)


        **Scope:** `account:read_write`


        [Try in API
        console](https://test.deribit.com/api_console?method=%2Fprivate%2Fchange_scope_in_api_key)

      parameters:
        - name: max_scope
          in: query
          required: true
          schema:
            $ref: '#/components/schemas/max_scope'
          description: >
            Describes maximal access for tokens generated with given key. If
            scope is not provided, its value is set as none.


            **📖 Related Article:** [Access
            Scope](https://docs.deribit.com/articles/access-scope)
        - name: id
          in: query
          required: true
          schema:
            type: integer
            example: 1
          description: API key ID
      requestBody:
        content:
          application/json:
            examples:
              request:
                value:
                  jsonrpc: '2.0'
                  id: 2453
                  method: private/change_scope_in_api_key
                  params:
                    max_scope: >-
                      account:read_write wallet:read_write block_trade:read
                      trade:read_write
                    id: 3
                description: JSON-RPC Request Example
        description: JSON-RPC request body
      responses:
        '200':
          $ref: '#/components/responses/PrivateApiKeyResponse'
components:
  schemas:
    max_scope:
      items:
        type: string
      example:
        - account:read
        - trade:read
        - block_trade:read_write
        - wallet:none
      type: array
      description: >
        Describes maximal access for tokens generated with given key. If scope
        is not provided, its value is set as none.


        **📖 Related Article:** [Access
        Scope](https://docs.deribit.com/articles/access-scope)
    PrivateApiKeyResponse:
      properties:
        jsonrpc:
          type: string
          enum:
            - '2.0'
          description: The JSON-RPC version (2.0)
        id:
          type: integer
          description: The id that was sent in the request
        result:
          $ref: '#/components/schemas/api_key'
      required:
        - jsonrpc
        - result
      type: object
    api_key:
      properties:
        id:
          $ref: '#/components/schemas/key_id'
        timestamp:
          $ref: '#/components/schemas/timestamp'
        client_id:
          $ref: '#/components/schemas/client_id'
        client_secret:
          $ref: '#/components/schemas/client_secret'
        public_key:
          $ref: '#/components/schemas/public_key'
        max_scope:
          $ref: '#/components/schemas/max_scope'
        enabled:
          $ref: '#/components/schemas/api_key_enabled'
        default:
          $ref: '#/components/schemas/api_key_default'
        name:
          $ref: '#/components/schemas/api_key_name'
        enabled_features:
          $ref: '#/components/schemas/api_key_features'
        ip_whitelist:
          type: array
          description: List of IP addresses whitelisted for a selected key
      required:
        - id
        - timestamp
        - client_id
        - client_secret
        - max_scope
        - default
      type: object
    key_id:
      example: 1
      type: integer
      description: Key identifier
    timestamp:
      example: 1536569522277
      type: integer
      description: The timestamp (milliseconds since the Unix epoch)
    client_id:
      example: IY2D68DS
      type: string
      description: Client identifier used for authentication
    client_secret:
      example: P9Z_c73KaBPwpoTVfsXzehAhjhdJn5kM7Zlz_hhDhE8
      type: string
      description: Client secret or MD5 fingerprint of public key used for authentication
    public_key:
      example: >-
        -----BEGIN PUBLIC KEY-----
        MCowBQYDK2VwAyEApajFN0CSwIaaiIRPiFbiYYvpsLQLSccSLLsKPe984sc= -----END
        PUBLIC KEY-----
      type: string
      description: >-
        PEM encoded public key (Ed25519/RSA) used for asymmetric signatures
        (optional)
    api_key_enabled:
      example: true
      type: boolean
      description: Informs whether api key is enabled and can be used for authentication
    api_key_default:
      example: false
      type: boolean
      description: >-
        Informs whether this api key is default (field is deprecated and will be
        removed in the future)
    api_key_name:
      example: TestName
      type: string
      description: Api key name that can be displayed in transaction log
    api_key_features:
      items:
        type: string
      type: array
      description: >-
        List of enabled advanced on-key features.<br><br><b>Available
        options:</b><br>- <code>restricted_block_trades</code>: Limit the
        block_trade read the scope of the API key to block trades that have been
        made using this specific API key<br>- <code>block_trade_approval</code>:
        Block trades created using this API key require additional user
        approval. Methods that use <code>block_rfq</code> scope are not affected
        by Block Trade approval feature
  responses:
    PrivateApiKeyResponse:
      content:
        application/json:
          schema:
            $ref: '#/components/schemas/PrivateApiKeyResponse'
          examples:
            response:
              value:
                jsonrpc: '2.0'
                id: 2453
                result:
                  timestamp: 1560242482758
                  max_scope: >-
                    account:read_write block_trade:read trade:read_write
                    wallet:read_write
                  id: 3
                  enabled: true
                  default: false
                  client_secret: B6RsF9rrLY5ezEGBQkyLlV-UC7whyPJ34BMA-kKYpes
                  client_id: 1sXMQBhM
                  name: NewKeyName
              description: Response example
      description: Success response

````

> ## Documentation Index
> Fetch the complete documentation index at: https://docs.deribit.com/llms.txt
> Use this file to discover all available pages before exploring further.

<AgentInstructions>

## Submitting Feedback

If you encounter incorrect, outdated, or confusing documentation on this page, submit feedback:

POST https://docs.deribit.com/feedback

```json
{
  "path": "/api-reference/account-management/private-change_subaccount_name",
  "feedback": "Description of the issue"
}
```

Only submit feedback when you have something specific and actionable to report.

</AgentInstructions>

# private/change_subaccount_name

> Updates the display name (username) for a subaccount. The new name is used for identification purposes and does not affect the subaccount's functionality or access.

Only the main account owner can change subaccount names.

**📖 Related Article:** [Managing Subaccounts](https://docs.deribit.com/articles/managing-subaccounts-api)

**Scope:** `account:read_write` and mainaccount

[Try in API console](https://test.deribit.com/api_console?method=%2Fprivate%2Fchange_subaccount_name)





## OpenAPI

````yaml /specifications/deribit_openapi.json get /private/change_subaccount_name
openapi: 3.0.0
info:
  title: Deribit API
  version: 2.1.1
servers:
  - url: https://test.deribit.com/api/v2
security: []
tags:
  - name: WebSocket Only
    description: Can only be used over websockets.
  - name: Public
    description: Public methods can be used without authentication.
  - name: Private
    description: >-
      <p>Private methods require authentication. All requests must include a
      valid OAuth2 token.</p>

      <p>A token can be requested using the <a
      href="#public-auth">/public/auth</a> method.</p>

      <p>When using the websockets protocol, the token must be included as a
      parameter <code>access_token</code> in the message. When using REST (HTTP
      GET), the token may also be passed in the <code>Authorization</code>
      header.</p>
  - name: Authentication
  - name: Session Management
  - name: Subscription Management
    description: >-
      Subscription works as [notifications](#notifications), so users will
      automatically (after subscribing) receive messages from the server.
      Overview for each channel response format is described in
      [subscriptions](#subscriptions) section.
  - name: Account Management
  - name: Trading
  - name: Market Data
  - name: Wallet
  - name: Chat
paths:
  /private/change_subaccount_name:
    get:
      tags:
        - Account Management
        - Private
      description: >+
        Updates the display name (username) for a subaccount. The new name is
        used for identification purposes and does not affect the subaccount's
        functionality or access.


        Only the main account owner can change subaccount names.


        **📖 Related Article:** [Managing
        Subaccounts](https://docs.deribit.com/articles/managing-subaccounts-api)


        **Scope:** `account:read_write` and mainaccount


        [Try in API
        console](https://test.deribit.com/api_console?method=%2Fprivate%2Fchange_subaccount_name)

      parameters:
        - name: sid
          in: query
          schema:
            type: integer
            example: 7
          required: true
          description: The user id for the subaccount
        - name: name
          in: query
          schema:
            type: string
            example: new_user_1_1
          required: true
          description: The new user name
      requestBody:
        content:
          application/json:
            examples:
              request:
                value:
                  jsonrpc: '2.0'
                  id: 3964
                  method: private/change_subaccount_name
                  params:
                    sid: 7
                    name: new_user_1_1
                description: JSON-RPC Request Example
        description: JSON-RPC request body
      responses:
        '200':
          $ref: '#/components/responses/OkResponse'
components:
  responses:
    OkResponse:
      content:
        application/json:
          schema:
            $ref: '#/components/schemas/OkResponse'
          examples:
            response:
              value:
                jsonrpc: '2.0'
                id: 1569
                result: ok
              description: Response example
      description: Success response
  schemas:
    OkResponse:
      properties:
        jsonrpc:
          type: string
          enum:
            - '2.0'
          description: The JSON-RPC version (2.0)
        id:
          type: integer
          description: The id that was sent in the request
        result:
          type: string
          enum:
            - ok
          description: Result of method execution. `ok` in case of success
      required:
        - jsonrpc
        - result
      type: object

````

> ## Documentation Index
> Fetch the complete documentation index at: https://docs.deribit.com/llms.txt
> Use this file to discover all available pages before exploring further.

<AgentInstructions>

## Submitting Feedback

If you encounter incorrect, outdated, or confusing documentation on this page, submit feedback:

POST https://docs.deribit.com/feedback

```json
{
  "path": "/api-reference/account-management/private-create_api_key",
  "feedback": "Description of the issue"
}
```

Only submit feedback when you have something specific and actionable to report.

</AgentInstructions>

# private/create_api_key

> Creates a new API key with the specified scope and permissions. API keys are used for programmatic access to the Deribit API and can be restricted to specific operations and IP addresses.

The response includes both the API key ID and the secret key. Store the secret securely as it will not be displayed again. You can view the API key details (without the secret) using the `list_api_keys` method.

**[TFA required](https://docs.deribit.com/articles/security-keys)**

**📖 Related Articles:** 
- [Creating new API key on Deribit](https://docs.deribit.com/articles/creating-api-key)
- [Access Scope](https://docs.deribit.com/articles/access-scope)

**Scope:** `account:read_write`

[Try in API console](https://test.deribit.com/api_console?method=%2Fprivate%2Fcreate_api_key)





## OpenAPI

````yaml /specifications/deribit_openapi.json get /private/create_api_key
openapi: 3.0.0
info:
  title: Deribit API
  version: 2.1.1
servers:
  - url: https://test.deribit.com/api/v2
security: []
tags:
  - name: WebSocket Only
    description: Can only be used over websockets.
  - name: Public
    description: Public methods can be used without authentication.
  - name: Private
    description: >-
      <p>Private methods require authentication. All requests must include a
      valid OAuth2 token.</p>

      <p>A token can be requested using the <a
      href="#public-auth">/public/auth</a> method.</p>

      <p>When using the websockets protocol, the token must be included as a
      parameter <code>access_token</code> in the message. When using REST (HTTP
      GET), the token may also be passed in the <code>Authorization</code>
      header.</p>
  - name: Authentication
  - name: Session Management
  - name: Subscription Management
    description: >-
      Subscription works as [notifications](#notifications), so users will
      automatically (after subscribing) receive messages from the server.
      Overview for each channel response format is described in
      [subscriptions](#subscriptions) section.
  - name: Account Management
  - name: Trading
  - name: Market Data
  - name: Wallet
  - name: Chat
paths:
  /private/create_api_key:
    get:
      tags:
        - Account Management
        - Private
      description: >+
        Creates a new API key with the specified scope and permissions. API keys
        are used for programmatic access to the Deribit API and can be
        restricted to specific operations and IP addresses.


        The response includes both the API key ID and the secret key. Store the
        secret securely as it will not be displayed again. You can view the API
        key details (without the secret) using the `list_api_keys` method.


        **[TFA required](https://docs.deribit.com/articles/security-keys)**


        **📖 Related Articles:** 

        - [Creating new API key on
        Deribit](https://docs.deribit.com/articles/creating-api-key)

        - [Access Scope](https://docs.deribit.com/articles/access-scope)


        **Scope:** `account:read_write`


        [Try in API
        console](https://test.deribit.com/api_console?method=%2Fprivate%2Fcreate_api_key)

      parameters:
        - name: max_scope
          in: query
          required: true
          schema:
            $ref: '#/components/schemas/max_scope'
          description: >
            Describes maximal access for tokens generated with given key. If
            scope is not provided, its value is set as none.


            **📖 Related Article:** [Access
            Scope](https://docs.deribit.com/articles/access-scope)
        - name: name
          in: query
          schema:
            type: string
            example: TestName
          description: >-
            Name of key (only letters, numbers and underscores allowed; maximum
            length - 16 characters)
          required: false
        - name: public_key
          in: query
          required: false
          schema:
            type: string
            example: |-
              -----BEGIN PUBLIC KEY-----
              MCowBQYDK2VwAyEAM7FWhKquNqLmTOV4hfYT5r3AjrYiORTT6Tn5HIfFNV8=
              -----END PUBLIC KEY-----
          description: >-
            ED25519 or RSA PEM Encoded public key that should be used to create
            asymmetric API Key for signing requests/authentication requests with
            user's private key.<br></br> **📖 Related Article:** [Asymmetric API
            keys](https://docs.deribit.com/articles/asymmetric-api-keys)
        - name: enabled_features
          in: query
          required: false
          schema:
            type: array
            items:
              type: string
              enum:
                - restricted_block_trades
                - block_trade_approval
          description: >-
            List of enabled advanced on-key features. Available options:<br> -
            `restricted_block_trades`: Limit the block_trade read the scope of
            the API key to block trades that have been made using this specific
            API key<br> - `block_trade_approval`: Block trades created using
            this API key require additional user approval. Methods that use
            `block_rfq` scope are not affected by Block Trade approval
            feature<br> 
          style: form
          explode: true
      requestBody:
        content:
          application/json:
            examples:
              request:
                value:
                  jsonrpc: '2.0'
                  id: 8974
                  method: private/create_api_key
                  params:
                    name: Public key 1
                    max_scope: account:read trade:read block_trade:read_write wallet:none
                    public_key: >-
                      -----BEGIN PUBLIC KEY-----

                      MCowBQYDK2VwAyEAM7FWhKquNqLmTOV4hfYT5r3AjrYiORTT6Tn5HIfFNV8=

                      -----END PUBLIC KEY-----
                description: JSON-RPC Request Example
        description: JSON-RPC request body
      responses:
        '200':
          $ref: '#/components/responses/PrivateApiKeyResponse'
components:
  schemas:
    max_scope:
      items:
        type: string
      example:
        - account:read
        - trade:read
        - block_trade:read_write
        - wallet:none
      type: array
      description: >
        Describes maximal access for tokens generated with given key. If scope
        is not provided, its value is set as none.


        **📖 Related Article:** [Access
        Scope](https://docs.deribit.com/articles/access-scope)
    PrivateApiKeyResponse:
      properties:
        jsonrpc:
          type: string
          enum:
            - '2.0'
          description: The JSON-RPC version (2.0)
        id:
          type: integer
          description: The id that was sent in the request
        result:
          $ref: '#/components/schemas/api_key'
      required:
        - jsonrpc
        - result
      type: object
    api_key:
      properties:
        id:
          $ref: '#/components/schemas/key_id'
        timestamp:
          $ref: '#/components/schemas/timestamp'
        client_id:
          $ref: '#/components/schemas/client_id'
        client_secret:
          $ref: '#/components/schemas/client_secret'
        public_key:
          $ref: '#/components/schemas/public_key'
        max_scope:
          $ref: '#/components/schemas/max_scope'
        enabled:
          $ref: '#/components/schemas/api_key_enabled'
        default:
          $ref: '#/components/schemas/api_key_default'
        name:
          $ref: '#/components/schemas/api_key_name'
        enabled_features:
          $ref: '#/components/schemas/api_key_features'
        ip_whitelist:
          type: array
          description: List of IP addresses whitelisted for a selected key
      required:
        - id
        - timestamp
        - client_id
        - client_secret
        - max_scope
        - default
      type: object
    key_id:
      example: 1
      type: integer
      description: Key identifier
    timestamp:
      example: 1536569522277
      type: integer
      description: The timestamp (milliseconds since the Unix epoch)
    client_id:
      example: IY2D68DS
      type: string
      description: Client identifier used for authentication
    client_secret:
      example: P9Z_c73KaBPwpoTVfsXzehAhjhdJn5kM7Zlz_hhDhE8
      type: string
      description: Client secret or MD5 fingerprint of public key used for authentication
    public_key:
      example: >-
        -----BEGIN PUBLIC KEY-----
        MCowBQYDK2VwAyEApajFN0CSwIaaiIRPiFbiYYvpsLQLSccSLLsKPe984sc= -----END
        PUBLIC KEY-----
      type: string
      description: >-
        PEM encoded public key (Ed25519/RSA) used for asymmetric signatures
        (optional)
    api_key_enabled:
      example: true
      type: boolean
      description: Informs whether api key is enabled and can be used for authentication
    api_key_default:
      example: false
      type: boolean
      description: >-
        Informs whether this api key is default (field is deprecated and will be
        removed in the future)
    api_key_name:
      example: TestName
      type: string
      description: Api key name that can be displayed in transaction log
    api_key_features:
      items:
        type: string
      type: array
      description: >-
        List of enabled advanced on-key features.<br><br><b>Available
        options:</b><br>- <code>restricted_block_trades</code>: Limit the
        block_trade read the scope of the API key to block trades that have been
        made using this specific API key<br>- <code>block_trade_approval</code>:
        Block trades created using this API key require additional user
        approval. Methods that use <code>block_rfq</code> scope are not affected
        by Block Trade approval feature
  responses:
    PrivateApiKeyResponse:
      content:
        application/json:
          schema:
            $ref: '#/components/schemas/PrivateApiKeyResponse'
          examples:
            response:
              value:
                jsonrpc: '2.0'
                id: 2453
                result:
                  timestamp: 1560242482758
                  max_scope: >-
                    account:read_write block_trade:read trade:read_write
                    wallet:read_write
                  id: 3
                  enabled: true
                  default: false
                  client_secret: B6RsF9rrLY5ezEGBQkyLlV-UC7whyPJ34BMA-kKYpes
                  client_id: 1sXMQBhM
                  name: NewKeyName
              description: Response example
      description: Success response

````

> ## Documentation Index
> Fetch the complete documentation index at: https://docs.deribit.com/llms.txt
> Use this file to discover all available pages before exploring further.

<AgentInstructions>

## Submitting Feedback

If you encounter incorrect, outdated, or confusing documentation on this page, submit feedback:

POST https://docs.deribit.com/feedback

```json
{
  "path": "/api-reference/account-management/private-create_subaccount",
  "feedback": "Description of the issue"
}
```

Only submit feedback when you have something specific and actionable to report.

</AgentInstructions>

# private/create_subaccount

> Creates a new subaccount under the authenticated main account. Subaccounts allow you to organize trading activities and manage risk separately from the main account.

This method takes no parameters. The new subaccount will be created with default settings and can be configured using other subaccount management methods.

**📖 Related Article:** [Managing Subaccounts](https://docs.deribit.com/articles/managing-subaccounts-api)

**Scope:** `account:read_write` and mainaccount

[Try in API console](https://test.deribit.com/api_console?method=%2Fprivate%2Fcreate_subaccount)





## OpenAPI

````yaml /specifications/deribit_openapi.json get /private/create_subaccount
openapi: 3.0.0
info:
  title: Deribit API
  version: 2.1.1
servers:
  - url: https://test.deribit.com/api/v2
security: []
tags:
  - name: WebSocket Only
    description: Can only be used over websockets.
  - name: Public
    description: Public methods can be used without authentication.
  - name: Private
    description: >-
      <p>Private methods require authentication. All requests must include a
      valid OAuth2 token.</p>

      <p>A token can be requested using the <a
      href="#public-auth">/public/auth</a> method.</p>

      <p>When using the websockets protocol, the token must be included as a
      parameter <code>access_token</code> in the message. When using REST (HTTP
      GET), the token may also be passed in the <code>Authorization</code>
      header.</p>
  - name: Authentication
  - name: Session Management
  - name: Subscription Management
    description: >-
      Subscription works as [notifications](#notifications), so users will
      automatically (after subscribing) receive messages from the server.
      Overview for each channel response format is described in
      [subscriptions](#subscriptions) section.
  - name: Account Management
  - name: Trading
  - name: Market Data
  - name: Wallet
  - name: Chat
paths:
  /private/create_subaccount:
    get:
      tags:
        - Account Management
        - Private
      description: >+
        Creates a new subaccount under the authenticated main account.
        Subaccounts allow you to organize trading activities and manage risk
        separately from the main account.


        This method takes no parameters. The new subaccount will be created with
        default settings and can be configured using other subaccount management
        methods.


        **📖 Related Article:** [Managing
        Subaccounts](https://docs.deribit.com/articles/managing-subaccounts-api)


        **Scope:** `account:read_write` and mainaccount


        [Try in API
        console](https://test.deribit.com/api_console?method=%2Fprivate%2Fcreate_subaccount)

      requestBody:
        content:
          application/json:
            examples:
              request:
                value:
                  jsonrpc: '2.0'
                  id: 5414
                  method: private/create_subaccount
                  params: {}
                description: JSON-RPC Request Example
        description: JSON-RPC request body
      responses:
        '200':
          $ref: '#/components/responses/PrivateCreateSubaccountResponse'
components:
  responses:
    PrivateCreateSubaccountResponse:
      content:
        application/json:
          schema:
            $ref: '#/components/schemas/PrivateCreateSubaccountResponse'
          examples:
            response:
              value:
                jsonrpc: '2.0'
                id: 5414
                result:
                  email: user_AAA@email.com
                  id: 13
                  is_password: false
                  login_enabled: false
                  portfolio:
                    eth:
                      available_funds: 0
                      available_withdrawal_funds: 0
                      balance: 0
                      currency: eth
                      equity: 0
                      initial_margin: 0
                      maintenance_margin: 0
                      margin_balance: 0
                    btc:
                      available_funds: 0
                      available_withdrawal_funds: 0
                      balance: 0
                      currency: btc
                      equity: 0
                      initial_margin: 0
                      maintenance_margin: 0
                      margin_balance: 0
                  receive_notifications: false
                  system_name: user_1_4
                  security_keys_enabled: false
                  type: subaccount
                  username: user_1_4
              description: Response example
      description: Success response
  schemas:
    PrivateCreateSubaccountResponse:
      properties:
        jsonrpc:
          type: string
          enum:
            - '2.0'
          description: The JSON-RPC version (2.0)
        id:
          type: integer
          description: The id that was sent in the request
        result:
          type: object
          properties:
            email:
              example: user@example.com
              type: string
              description: User email
            login_enabled:
              type: boolean
              description: Informs whether login to the subaccount is enabled
            is_password:
              type: boolean
              description: '`true` when password for the subaccount has been configured'
            receive_notifications:
              type: boolean
              description: When `true` - receive all notification emails on the main email
            system_name:
              example: username_1
              type: string
              description: System generated user nickname
            security_keys_enabled:
              type: boolean
              description: Whether the Security Keys authentication is enabled
            security_keys_assignments:
              type: array
              items:
                type: string
              description: Names of assignments with Security Keys assigned
            username:
              type: string
              description: Account name (given by user)
            type:
              enum:
                - subaccount
              type: string
              description: Account type
            id:
              type: integer
              description: Subaccount identifier
            portfolio:
              $ref: '#/components/schemas/portfolio'
              description: Portfolio information for the subaccount
            margin_model:
              type: string
              description: Margin model
            disabled_trading_products:
              type: array
              items:
                type: string
              description: List of disabled trading products
            proof_id:
              type: string
              description: >-
                hashed identifier used in the Proof Of Liability for the
                subaccount. This identifier allows you to find your entries in
                the Deribit Proof-Of-Reserves files. IMPORTANT: Keep it secret
                to not disclose your entries in the Proof-Of-Reserves.
            proof_id_signature:
              type: string
              description: >-
                signature used as a base string for proof_id hash. IMPORTANT:
                Keep it secret to not disclose your entries in the
                Proof-Of-Reserves.
            trading_products_details:
              type: array
              items:
                type: object
                properties:
                  enabled:
                    type: boolean
                  product:
                    type: string
                  overwriteable:
                    type: boolean
                  requires_consent:
                    type: boolean
              description: Details about trading products availability
            referrals_count:
              type: integer
              description: Number of referrals
          required:
            - username
            - type
            - id
            - login_enabled
            - is_password
            - receive_notifications
            - system_name
            - email
            - security_keys_enabled
            - security_keys_assignments
            - margin_model
            - disabled_trading_products
            - proof_id
            - proof_id_signature
            - trading_products_details
            - referrals_count
      required:
        - jsonrpc
        - result
      type: object
    portfolio:
      properties:
        btc(example):
          $ref: '#/components/schemas/currency_portfolio'
      type: object
    currency_portfolio:
      properties:
        margin_balance:
          type: number
          description: >-
            The account's margin balance. When cross collateral is enabled, this
            aggregated value is calculated by converting the sum of each cross
            collateral currency's value to the given currency, using each cross
            collateral currency's index.
        currency:
          type: string
          enum:
            - btc
            - eth
          description: The selected currency
        maintenance_margin:
          type: number
          description: >-
            The maintenance margin. When cross collateral is enabled, this
            aggregated value is calculated by converting the sum of each cross
            collateral currency's value to the given currency, using each cross
            collateral currency's index.
        initial_margin:
          type: number
          description: >-
            The account's initial margin. When cross collateral is enabled, this
            aggregated value is calculated by converting the sum of each cross
            collateral currency's value to the given currency, using each cross
            collateral currency's index.
        equity:
          type: number
          description: The account's current equity
        balance:
          type: number
          description: The account's balance
        available_withdrawal_funds:
          type: number
          description: The account's available to withdrawal funds
        available_funds:
          type: number
          description: >-
            The account's available funds. When cross collateral is enabled,
            this aggregated value is calculated by converting the sum of each
            cross collateral currency's value to the given currency, using each
            cross collateral currency's index.
        additional_reserve:
          $ref: '#/components/schemas/additional_reserve'
        spot_reserve:
          type: number
          description: The account's balance reserved in active spot orders
      required:
        - margin_balance
        - currency
        - maintenance_margin
        - initial_margin
        - equity
        - balance
        - available_withdrawal_funds
        - available_funds
        - additional_reserve
        - spot_reserve
      type: object
    additional_reserve:
      example: 0.3
      type: number
      description: The account's balance reserved in other orders

````

> ## Documentation Index
> Fetch the complete documentation index at: https://docs.deribit.com/llms.txt
> Use this file to discover all available pages before exploring further.

<AgentInstructions>

## Submitting Feedback

If you encounter incorrect, outdated, or confusing documentation on this page, submit feedback:

POST https://docs.deribit.com/feedback

```json
{
  "path": "/api-reference/account-management/private-disable_api_key",
  "feedback": "Description of the issue"
}
```

Only submit feedback when you have something specific and actionable to report.

</AgentInstructions>

# private/disable_api_key

> Disables an API key, preventing it from being used to authenticate API requests. The key remains in your account but cannot be used until it is re-enabled.

This is useful for temporarily suspending access without permanently deleting the key. All requests using this key will be rejected until it is enabled again.

**[TFA required](https://docs.deribit.com/articles/security-keys)**

**📖 Related Article:** [Creating new API key on Deribit](https://docs.deribit.com/articles/creating-api-key)

**Scope:** `account:read_write`

[Try in API console](https://test.deribit.com/api_console?method=%2Fprivate%2Fdisable_api_key)





## OpenAPI

````yaml /specifications/deribit_openapi.json get /private/disable_api_key
openapi: 3.0.0
info:
  title: Deribit API
  version: 2.1.1
servers:
  - url: https://test.deribit.com/api/v2
security: []
tags:
  - name: WebSocket Only
    description: Can only be used over websockets.
  - name: Public
    description: Public methods can be used without authentication.
  - name: Private
    description: >-
      <p>Private methods require authentication. All requests must include a
      valid OAuth2 token.</p>

      <p>A token can be requested using the <a
      href="#public-auth">/public/auth</a> method.</p>

      <p>When using the websockets protocol, the token must be included as a
      parameter <code>access_token</code> in the message. When using REST (HTTP
      GET), the token may also be passed in the <code>Authorization</code>
      header.</p>
  - name: Authentication
  - name: Session Management
  - name: Subscription Management
    description: >-
      Subscription works as [notifications](#notifications), so users will
      automatically (after subscribing) receive messages from the server.
      Overview for each channel response format is described in
      [subscriptions](#subscriptions) section.
  - name: Account Management
  - name: Trading
  - name: Market Data
  - name: Wallet
  - name: Chat
paths:
  /private/disable_api_key:
    get:
      tags:
        - Account Management
        - Private
      description: >+
        Disables an API key, preventing it from being used to authenticate API
        requests. The key remains in your account but cannot be used until it is
        re-enabled.


        This is useful for temporarily suspending access without permanently
        deleting the key. All requests using this key will be rejected until it
        is enabled again.


        **[TFA required](https://docs.deribit.com/articles/security-keys)**


        **📖 Related Article:** [Creating new API key on
        Deribit](https://docs.deribit.com/articles/creating-api-key)


        **Scope:** `account:read_write`


        [Try in API
        console](https://test.deribit.com/api_console?method=%2Fprivate%2Fdisable_api_key)

      parameters:
        - name: id
          in: query
          required: true
          schema:
            type: integer
            example: 1
          description: API key ID
      requestBody:
        content:
          application/json:
            examples:
              request:
                value:
                  jsonrpc: '2.0'
                  id: 2861
                  method: private/disable_api_key
                  params:
                    id: 3
                description: JSON-RPC Request Example
        description: JSON-RPC request body
      responses:
        '200':
          $ref: '#/components/responses/PrivateApiKeyResponse'
components:
  responses:
    PrivateApiKeyResponse:
      content:
        application/json:
          schema:
            $ref: '#/components/schemas/PrivateApiKeyResponse'
          examples:
            response:
              value:
                jsonrpc: '2.0'
                id: 2453
                result:
                  timestamp: 1560242482758
                  max_scope: >-
                    account:read_write block_trade:read trade:read_write
                    wallet:read_write
                  id: 3
                  enabled: true
                  default: false
                  client_secret: B6RsF9rrLY5ezEGBQkyLlV-UC7whyPJ34BMA-kKYpes
                  client_id: 1sXMQBhM
                  name: NewKeyName
              description: Response example
      description: Success response
  schemas:
    PrivateApiKeyResponse:
      properties:
        jsonrpc:
          type: string
          enum:
            - '2.0'
          description: The JSON-RPC version (2.0)
        id:
          type: integer
          description: The id that was sent in the request
        result:
          $ref: '#/components/schemas/api_key'
      required:
        - jsonrpc
        - result
      type: object
    api_key:
      properties:
        id:
          $ref: '#/components/schemas/key_id'
        timestamp:
          $ref: '#/components/schemas/timestamp'
        client_id:
          $ref: '#/components/schemas/client_id'
        client_secret:
          $ref: '#/components/schemas/client_secret'
        public_key:
          $ref: '#/components/schemas/public_key'
        max_scope:
          $ref: '#/components/schemas/max_scope'
        enabled:
          $ref: '#/components/schemas/api_key_enabled'
        default:
          $ref: '#/components/schemas/api_key_default'
        name:
          $ref: '#/components/schemas/api_key_name'
        enabled_features:
          $ref: '#/components/schemas/api_key_features'
        ip_whitelist:
          type: array
          description: List of IP addresses whitelisted for a selected key
      required:
        - id
        - timestamp
        - client_id
        - client_secret
        - max_scope
        - default
      type: object
    key_id:
      example: 1
      type: integer
      description: Key identifier
    timestamp:
      example: 1536569522277
      type: integer
      description: The timestamp (milliseconds since the Unix epoch)
    client_id:
      example: IY2D68DS
      type: string
      description: Client identifier used for authentication
    client_secret:
      example: P9Z_c73KaBPwpoTVfsXzehAhjhdJn5kM7Zlz_hhDhE8
      type: string
      description: Client secret or MD5 fingerprint of public key used for authentication
    public_key:
      example: >-
        -----BEGIN PUBLIC KEY-----
        MCowBQYDK2VwAyEApajFN0CSwIaaiIRPiFbiYYvpsLQLSccSLLsKPe984sc= -----END
        PUBLIC KEY-----
      type: string
      description: >-
        PEM encoded public key (Ed25519/RSA) used for asymmetric signatures
        (optional)
    max_scope:
      items:
        type: string
      example:
        - account:read
        - trade:read
        - block_trade:read_write
        - wallet:none
      type: array
      description: >
        Describes maximal access for tokens generated with given key. If scope
        is not provided, its value is set as none.


        **📖 Related Article:** [Access
        Scope](https://docs.deribit.com/articles/access-scope)
    api_key_enabled:
      example: true
      type: boolean
      description: Informs whether api key is enabled and can be used for authentication
    api_key_default:
      example: false
      type: boolean
      description: >-
        Informs whether this api key is default (field is deprecated and will be
        removed in the future)
    api_key_name:
      example: TestName
      type: string
      description: Api key name that can be displayed in transaction log
    api_key_features:
      items:
        type: string
      type: array
      description: >-
        List of enabled advanced on-key features.<br><br><b>Available
        options:</b><br>- <code>restricted_block_trades</code>: Limit the
        block_trade read the scope of the API key to block trades that have been
        made using this specific API key<br>- <code>block_trade_approval</code>:
        Block trades created using this API key require additional user
        approval. Methods that use <code>block_rfq</code> scope are not affected
        by Block Trade approval feature

````

> ## Documentation Index
> Fetch the complete documentation index at: https://docs.deribit.com/llms.txt
> Use this file to discover all available pages before exploring further.

<AgentInstructions>

## Submitting Feedback

If you encounter incorrect, outdated, or confusing documentation on this page, submit feedback:

POST https://docs.deribit.com/feedback

```json
{
  "path": "/api-reference/account-management/private-edit_api_key",
  "feedback": "Description of the issue"
}
```

Only submit feedback when you have something specific and actionable to report.

</AgentInstructions>

# private/edit_api_key

> Updates properties of an existing API key. You can modify the key name, scope, enabled status, features, and IP whitelist. At least one parameter must be provided.

Changes take effect immediately. If you modify the scope, the API key will only have access to the newly specified permissions.

**[TFA required](https://docs.deribit.com/articles/security-keys)**

**📖 Related Articles:** 
- [Creating new API key on Deribit](https://docs.deribit.com/articles/creating-api-key)
- [Access Scope](https://docs.deribit.com/articles/access-scope)

**Scope:** `account:read_write`

[Try in API console](https://test.deribit.com/api_console?method=%2Fprivate%2Fedit_api_key)





## OpenAPI

````yaml /specifications/deribit_openapi.json get /private/edit_api_key
openapi: 3.0.0
info:
  title: Deribit API
  version: 2.1.1
servers:
  - url: https://test.deribit.com/api/v2
security: []
tags:
  - name: WebSocket Only
    description: Can only be used over websockets.
  - name: Public
    description: Public methods can be used without authentication.
  - name: Private
    description: >-
      <p>Private methods require authentication. All requests must include a
      valid OAuth2 token.</p>

      <p>A token can be requested using the <a
      href="#public-auth">/public/auth</a> method.</p>

      <p>When using the websockets protocol, the token must be included as a
      parameter <code>access_token</code> in the message. When using REST (HTTP
      GET), the token may also be passed in the <code>Authorization</code>
      header.</p>
  - name: Authentication
  - name: Session Management
  - name: Subscription Management
    description: >-
      Subscription works as [notifications](#notifications), so users will
      automatically (after subscribing) receive messages from the server.
      Overview for each channel response format is described in
      [subscriptions](#subscriptions) section.
  - name: Account Management
  - name: Trading
  - name: Market Data
  - name: Wallet
  - name: Chat
paths:
  /private/edit_api_key:
    get:
      tags:
        - Account Management
        - Private
      description: >+
        Updates properties of an existing API key. You can modify the key name,
        scope, enabled status, features, and IP whitelist. At least one
        parameter must be provided.


        Changes take effect immediately. If you modify the scope, the API key
        will only have access to the newly specified permissions.


        **[TFA required](https://docs.deribit.com/articles/security-keys)**


        **📖 Related Articles:** 

        - [Creating new API key on
        Deribit](https://docs.deribit.com/articles/creating-api-key)

        - [Access Scope](https://docs.deribit.com/articles/access-scope)


        **Scope:** `account:read_write`


        [Try in API
        console](https://test.deribit.com/api_console?method=%2Fprivate%2Fedit_api_key)

      parameters:
        - name: id
          in: query
          required: true
          schema:
            type: integer
            example: 1
          description: API key ID
        - name: max_scope
          in: query
          required: true
          schema:
            $ref: '#/components/schemas/max_scope'
          description: >
            Describes maximal access for tokens generated with given key. If
            scope is not provided, its value is set as none.


            **📖 Related Article:** [Access
            Scope](https://docs.deribit.com/articles/access-scope)
        - name: name
          in: query
          schema:
            type: string
            example: TestName
          description: >-
            Name of key (only letters, numbers and underscores allowed; maximum
            length - 16 characters)
          required: false
        - name: enabled
          in: query
          required: false
          schema:
            type: boolean
          description: Enables/disables the API key. `true` to enable, `false` to disable
        - name: enabled_features
          in: query
          required: false
          schema:
            type: array
            items:
              type: string
              enum:
                - restricted_block_trades
                - block_trade_approval
          description: >-
            List of enabled advanced on-key features. Available options:<br> -
            `restricted_block_trades`: Limit the block_trade read the scope of
            the API key to block trades that have been made using this specific
            API key<br> - `block_trade_approval`: Block trades created using
            this API key require additional user approval. Methods that use
            `block_rfq` scope are not affected by Block Trade approval
            feature<br> 
          style: form
          explode: true
        - name: ip_whitelist
          in: query
          required: false
          schema:
            items:
              type: string
            type: array
          description: Whitelist provided IP address on a selected key
          style: form
          explode: true
      requestBody:
        content:
          application/json:
            examples:
              request:
                value:
                  jsonrpc: '2.0'
                  id: 2453
                  method: private/edit_api_key
                  params:
                    name: NewKeyName
                    max_scope: >-
                      account:read_write wallet:read_write block_trade:read
                      trade:read_write
                    id: 3
                description: JSON-RPC Request Example
        description: JSON-RPC request body
      responses:
        '200':
          $ref: '#/components/responses/PrivateApiKeyResponse'
components:
  schemas:
    max_scope:
      items:
        type: string
      example:
        - account:read
        - trade:read
        - block_trade:read_write
        - wallet:none
      type: array
      description: >
        Describes maximal access for tokens generated with given key. If scope
        is not provided, its value is set as none.


        **📖 Related Article:** [Access
        Scope](https://docs.deribit.com/articles/access-scope)
    PrivateApiKeyResponse:
      properties:
        jsonrpc:
          type: string
          enum:
            - '2.0'
          description: The JSON-RPC version (2.0)
        id:
          type: integer
          description: The id that was sent in the request
        result:
          $ref: '#/components/schemas/api_key'
      required:
        - jsonrpc
        - result
      type: object
    api_key:
      properties:
        id:
          $ref: '#/components/schemas/key_id'
        timestamp:
          $ref: '#/components/schemas/timestamp'
        client_id:
          $ref: '#/components/schemas/client_id'
        client_secret:
          $ref: '#/components/schemas/client_secret'
        public_key:
          $ref: '#/components/schemas/public_key'
        max_scope:
          $ref: '#/components/schemas/max_scope'
        enabled:
          $ref: '#/components/schemas/api_key_enabled'
        default:
          $ref: '#/components/schemas/api_key_default'
        name:
          $ref: '#/components/schemas/api_key_name'
        enabled_features:
          $ref: '#/components/schemas/api_key_features'
        ip_whitelist:
          type: array
          description: List of IP addresses whitelisted for a selected key
      required:
        - id
        - timestamp
        - client_id
        - client_secret
        - max_scope
        - default
      type: object
    key_id:
      example: 1
      type: integer
      description: Key identifier
    timestamp:
      example: 1536569522277
      type: integer
      description: The timestamp (milliseconds since the Unix epoch)
    client_id:
      example: IY2D68DS
      type: string
      description: Client identifier used for authentication
    client_secret:
      example: P9Z_c73KaBPwpoTVfsXzehAhjhdJn5kM7Zlz_hhDhE8
      type: string
      description: Client secret or MD5 fingerprint of public key used for authentication
    public_key:
      example: >-
        -----BEGIN PUBLIC KEY-----
        MCowBQYDK2VwAyEApajFN0CSwIaaiIRPiFbiYYvpsLQLSccSLLsKPe984sc= -----END
        PUBLIC KEY-----
      type: string
      description: >-
        PEM encoded public key (Ed25519/RSA) used for asymmetric signatures
        (optional)
    api_key_enabled:
      example: true
      type: boolean
      description: Informs whether api key is enabled and can be used for authentication
    api_key_default:
      example: false
      type: boolean
      description: >-
        Informs whether this api key is default (field is deprecated and will be
        removed in the future)
    api_key_name:
      example: TestName
      type: string
      description: Api key name that can be displayed in transaction log
    api_key_features:
      items:
        type: string
      type: array
      description: >-
        List of enabled advanced on-key features.<br><br><b>Available
        options:</b><br>- <code>restricted_block_trades</code>: Limit the
        block_trade read the scope of the API key to block trades that have been
        made using this specific API key<br>- <code>block_trade_approval</code>:
        Block trades created using this API key require additional user
        approval. Methods that use <code>block_rfq</code> scope are not affected
        by Block Trade approval feature
  responses:
    PrivateApiKeyResponse:
      content:
        application/json:
          schema:
            $ref: '#/components/schemas/PrivateApiKeyResponse'
          examples:
            response:
              value:
                jsonrpc: '2.0'
                id: 2453
                result:
                  timestamp: 1560242482758
                  max_scope: >-
                    account:read_write block_trade:read trade:read_write
                    wallet:read_write
                  id: 3
                  enabled: true
                  default: false
                  client_secret: B6RsF9rrLY5ezEGBQkyLlV-UC7whyPJ34BMA-kKYpes
                  client_id: 1sXMQBhM
                  name: NewKeyName
              description: Response example
      description: Success response

````

> ## Documentation Index
> Fetch the complete documentation index at: https://docs.deribit.com/llms.txt
> Use this file to discover all available pages before exploring further.

<AgentInstructions>

## Submitting Feedback

If you encounter incorrect, outdated, or confusing documentation on this page, submit feedback:

POST https://docs.deribit.com/feedback

```json
{
  "path": "/api-reference/account-management/private-enable_affiliate_program",
  "feedback": "Description of the issue"
}
```

Only submit feedback when you have something specific and actionable to report.

</AgentInstructions>

# private/enable_affiliate_program

> Enables the affiliate program for the authenticated account. Once enabled, you can earn commissions by referring new users to Deribit.

After enabling, you will receive a unique affiliate link that can be shared with potential users. Commissions are paid based on the trading activity of referred users.

**📖 Related Support Article:** [Affiliate Program](https://support.deribit.com/hc/en-us/articles/25944777728797-Affiliate-Program)

**Scope:** `account:read_write`

[Try in API console](https://test.deribit.com/api_console?method=%2Fprivate%2Fenable_affiliate_program)





## OpenAPI

````yaml /specifications/deribit_openapi.json get /private/enable_affiliate_program
openapi: 3.0.0
info:
  title: Deribit API
  version: 2.1.1
servers:
  - url: https://test.deribit.com/api/v2
security: []
tags:
  - name: WebSocket Only
    description: Can only be used over websockets.
  - name: Public
    description: Public methods can be used without authentication.
  - name: Private
    description: >-
      <p>Private methods require authentication. All requests must include a
      valid OAuth2 token.</p>

      <p>A token can be requested using the <a
      href="#public-auth">/public/auth</a> method.</p>

      <p>When using the websockets protocol, the token must be included as a
      parameter <code>access_token</code> in the message. When using REST (HTTP
      GET), the token may also be passed in the <code>Authorization</code>
      header.</p>
  - name: Authentication
  - name: Session Management
  - name: Subscription Management
    description: >-
      Subscription works as [notifications](#notifications), so users will
      automatically (after subscribing) receive messages from the server.
      Overview for each channel response format is described in
      [subscriptions](#subscriptions) section.
  - name: Account Management
  - name: Trading
  - name: Market Data
  - name: Wallet
  - name: Chat
paths:
  /private/enable_affiliate_program:
    get:
      tags:
        - Account Management
        - Private
      description: >+
        Enables the affiliate program for the authenticated account. Once
        enabled, you can earn commissions by referring new users to Deribit.


        After enabling, you will receive a unique affiliate link that can be
        shared with potential users. Commissions are paid based on the trading
        activity of referred users.


        **📖 Related Support Article:** [Affiliate
        Program](https://support.deribit.com/hc/en-us/articles/25944777728797-Affiliate-Program)


        **Scope:** `account:read_write`


        [Try in API
        console](https://test.deribit.com/api_console?method=%2Fprivate%2Fenable_affiliate_program)

      parameters: []
      requestBody:
        content:
          application/json:
            examples:
              request:
                value:
                  jsonrpc: '2.0'
                  id: 24
                  method: private/enable_affiliate_program
                  params: {}
                description: JSON-RPC Request Example
        description: JSON-RPC request body
      responses:
        '200':
          $ref: '#/components/responses/OkResponse'
components:
  responses:
    OkResponse:
      content:
        application/json:
          schema:
            $ref: '#/components/schemas/OkResponse'
          examples:
            response:
              value:
                jsonrpc: '2.0'
                id: 1569
                result: ok
              description: Response example
      description: Success response
  schemas:
    OkResponse:
      properties:
        jsonrpc:
          type: string
          enum:
            - '2.0'
          description: The JSON-RPC version (2.0)
        id:
          type: integer
          description: The id that was sent in the request
        result:
          type: string
          enum:
            - ok
          description: Result of method execution. `ok` in case of success
      required:
        - jsonrpc
        - result
      type: object

````

> ## Documentation Index
> Fetch the complete documentation index at: https://docs.deribit.com/llms.txt
> Use this file to discover all available pages before exploring further.

<AgentInstructions>

## Submitting Feedback

If you encounter incorrect, outdated, or confusing documentation on this page, submit feedback:

POST https://docs.deribit.com/feedback

```json
{
  "path": "/api-reference/account-management/private-enable_api_key",
  "feedback": "Description of the issue"
}
```

Only submit feedback when you have something specific and actionable to report.

</AgentInstructions>

# private/enable_api_key

> Enables a previously disabled API key, restoring its ability to authenticate API requests. The API key can be used immediately after being enabled.

**📖 Related Article:** [Creating new API key on Deribit](https://docs.deribit.com/articles/creating-api-key)

**Scope:** `account:read_write`

[Try in API console](https://test.deribit.com/api_console?method=%2Fprivate%2Fenable_api_key)





## OpenAPI

````yaml /specifications/deribit_openapi.json get /private/enable_api_key
openapi: 3.0.0
info:
  title: Deribit API
  version: 2.1.1
servers:
  - url: https://test.deribit.com/api/v2
security: []
tags:
  - name: WebSocket Only
    description: Can only be used over websockets.
  - name: Public
    description: Public methods can be used without authentication.
  - name: Private
    description: >-
      <p>Private methods require authentication. All requests must include a
      valid OAuth2 token.</p>

      <p>A token can be requested using the <a
      href="#public-auth">/public/auth</a> method.</p>

      <p>When using the websockets protocol, the token must be included as a
      parameter <code>access_token</code> in the message. When using REST (HTTP
      GET), the token may also be passed in the <code>Authorization</code>
      header.</p>
  - name: Authentication
  - name: Session Management
  - name: Subscription Management
    description: >-
      Subscription works as [notifications](#notifications), so users will
      automatically (after subscribing) receive messages from the server.
      Overview for each channel response format is described in
      [subscriptions](#subscriptions) section.
  - name: Account Management
  - name: Trading
  - name: Market Data
  - name: Wallet
  - name: Chat
paths:
  /private/enable_api_key:
    get:
      tags:
        - Account Management
        - Private
      description: >+
        Enables a previously disabled API key, restoring its ability to
        authenticate API requests. The API key can be used immediately after
        being enabled.


        **📖 Related Article:** [Creating new API key on
        Deribit](https://docs.deribit.com/articles/creating-api-key)


        **Scope:** `account:read_write`


        [Try in API
        console](https://test.deribit.com/api_console?method=%2Fprivate%2Fenable_api_key)

      parameters:
        - name: id
          in: query
          required: true
          schema:
            type: integer
            example: 1
          description: API key ID
      requestBody:
        content:
          application/json:
            examples:
              request:
                value:
                  jsonrpc: '2.0'
                  id: 8580
                  method: private/enable_api_key
                  params:
                    id: 3
                description: JSON-RPC Request Example
        description: JSON-RPC request body
      responses:
        '200':
          $ref: '#/components/responses/PrivateApiKeyResponse'
components:
  responses:
    PrivateApiKeyResponse:
      content:
        application/json:
          schema:
            $ref: '#/components/schemas/PrivateApiKeyResponse'
          examples:
            response:
              value:
                jsonrpc: '2.0'
                id: 2453
                result:
                  timestamp: 1560242482758
                  max_scope: >-
                    account:read_write block_trade:read trade:read_write
                    wallet:read_write
                  id: 3
                  enabled: true
                  default: false
                  client_secret: B6RsF9rrLY5ezEGBQkyLlV-UC7whyPJ34BMA-kKYpes
                  client_id: 1sXMQBhM
                  name: NewKeyName
              description: Response example
      description: Success response
  schemas:
    PrivateApiKeyResponse:
      properties:
        jsonrpc:
          type: string
          enum:
            - '2.0'
          description: The JSON-RPC version (2.0)
        id:
          type: integer
          description: The id that was sent in the request
        result:
          $ref: '#/components/schemas/api_key'
      required:
        - jsonrpc
        - result
      type: object
    api_key:
      properties:
        id:
          $ref: '#/components/schemas/key_id'
        timestamp:
          $ref: '#/components/schemas/timestamp'
        client_id:
          $ref: '#/components/schemas/client_id'
        client_secret:
          $ref: '#/components/schemas/client_secret'
        public_key:
          $ref: '#/components/schemas/public_key'
        max_scope:
          $ref: '#/components/schemas/max_scope'
        enabled:
          $ref: '#/components/schemas/api_key_enabled'
        default:
          $ref: '#/components/schemas/api_key_default'
        name:
          $ref: '#/components/schemas/api_key_name'
        enabled_features:
          $ref: '#/components/schemas/api_key_features'
        ip_whitelist:
          type: array
          description: List of IP addresses whitelisted for a selected key
      required:
        - id
        - timestamp
        - client_id
        - client_secret
        - max_scope
        - default
      type: object
    key_id:
      example: 1
      type: integer
      description: Key identifier
    timestamp:
      example: 1536569522277
      type: integer
      description: The timestamp (milliseconds since the Unix epoch)
    client_id:
      example: IY2D68DS
      type: string
      description: Client identifier used for authentication
    client_secret:
      example: P9Z_c73KaBPwpoTVfsXzehAhjhdJn5kM7Zlz_hhDhE8
      type: string
      description: Client secret or MD5 fingerprint of public key used for authentication
    public_key:
      example: >-
        -----BEGIN PUBLIC KEY-----
        MCowBQYDK2VwAyEApajFN0CSwIaaiIRPiFbiYYvpsLQLSccSLLsKPe984sc= -----END
        PUBLIC KEY-----
      type: string
      description: >-
        PEM encoded public key (Ed25519/RSA) used for asymmetric signatures
        (optional)
    max_scope:
      items:
        type: string
      example:
        - account:read
        - trade:read
        - block_trade:read_write
        - wallet:none
      type: array
      description: >
        Describes maximal access for tokens generated with given key. If scope
        is not provided, its value is set as none.


        **📖 Related Article:** [Access
        Scope](https://docs.deribit.com/articles/access-scope)
    api_key_enabled:
      example: true
      type: boolean
      description: Informs whether api key is enabled and can be used for authentication
    api_key_default:
      example: false
      type: boolean
      description: >-
        Informs whether this api key is default (field is deprecated and will be
        removed in the future)
    api_key_name:
      example: TestName
      type: string
      description: Api key name that can be displayed in transaction log
    api_key_features:
      items:
        type: string
      type: array
      description: >-
        List of enabled advanced on-key features.<br><br><b>Available
        options:</b><br>- <code>restricted_block_trades</code>: Limit the
        block_trade read the scope of the API key to block trades that have been
        made using this specific API key<br>- <code>block_trade_approval</code>:
        Block trades created using this API key require additional user
        approval. Methods that use <code>block_rfq</code> scope are not affected
        by Block Trade approval feature

````

> ## Documentation Index
> Fetch the complete documentation index at: https://docs.deribit.com/llms.txt
> Use this file to discover all available pages before exploring further.

<AgentInstructions>

## Submitting Feedback

If you encounter incorrect, outdated, or confusing documentation on this page, submit feedback:

POST https://docs.deribit.com/feedback

```json
{
  "path": "/api-reference/account-management/private-get_access_log",
  "feedback": "Description of the issue"
}
```

Only submit feedback when you have something specific and actionable to report.

</AgentInstructions>

# private/get_access_log

> Retrieves a log of API access attempts and authentication events for the authenticated account. The log includes information such as IP addresses, timestamps, API methods called, and authentication status.

Use this method to monitor account security, review API usage patterns, and identify unauthorized access attempts. Results can be paginated using the `offset` and `count` parameters.

**Scope:** `account:read`

[Try in API console](https://test.deribit.com/api_console?method=%2Fprivate%2Fget_access_log)





## OpenAPI

````yaml /specifications/deribit_openapi.json get /private/get_access_log
openapi: 3.0.0
info:
  title: Deribit API
  version: 2.1.1
servers:
  - url: https://test.deribit.com/api/v2
security: []
tags:
  - name: WebSocket Only
    description: Can only be used over websockets.
  - name: Public
    description: Public methods can be used without authentication.
  - name: Private
    description: >-
      <p>Private methods require authentication. All requests must include a
      valid OAuth2 token.</p>

      <p>A token can be requested using the <a
      href="#public-auth">/public/auth</a> method.</p>

      <p>When using the websockets protocol, the token must be included as a
      parameter <code>access_token</code> in the message. When using REST (HTTP
      GET), the token may also be passed in the <code>Authorization</code>
      header.</p>
  - name: Authentication
  - name: Session Management
  - name: Subscription Management
    description: >-
      Subscription works as [notifications](#notifications), so users will
      automatically (after subscribing) receive messages from the server.
      Overview for each channel response format is described in
      [subscriptions](#subscriptions) section.
  - name: Account Management
  - name: Trading
  - name: Market Data
  - name: Wallet
  - name: Chat
paths:
  /private/get_access_log:
    get:
      tags:
        - Account Management
        - Private
      description: >+
        Retrieves a log of API access attempts and authentication events for the
        authenticated account. The log includes information such as IP
        addresses, timestamps, API methods called, and authentication status.


        Use this method to monitor account security, review API usage patterns,
        and identify unauthorized access attempts. Results can be paginated
        using the `offset` and `count` parameters.


        **Scope:** `account:read`


        [Try in API
        console](https://test.deribit.com/api_console?method=%2Fprivate%2Fget_access_log)

      parameters:
        - name: offset
          in: query
          required: false
          schema:
            example: 10
            type: integer
          description: The offset for pagination, default - `0`
        - name: count
          required: false
          in: query
          schema:
            type: integer
            maximum: 1000
            minimum: 1
          description: Number of requested items, default - `10`, maximum - `1000`
      requestBody:
        content:
          application/json:
            examples:
              request:
                value:
                  jsonrpc: '2.0'
                  id: 1
                  method: private/get_access_log
                  params:
                    offset: 0
                    count: 3
                description: JSON-RPC Request Example
        description: JSON-RPC request body
      responses:
        '200':
          $ref: '#/components/responses/PrivateGetAccessLogResponse'
components:
  responses:
    PrivateGetAccessLogResponse:
      content:
        application/json:
          schema:
            $ref: '#/components/schemas/PrivateGetAccessLogResponse'
          examples:
            response:
              value:
                jsonrpc: '2.0'
                id: 1
                result:
                  records_total: 34
                  data:
                    - timestamp: 1575876682576
                      result: success
                      ip: 127.0.0.1
                      id: 45
                      country: Local Country
                      city: Local Town
                    - timestamp: 1575876459309
                      result: success
                      ip: 127.0.0.1
                      id: 44
                      country: Local Country
                      city: Local Town
                    - timestamp: 1575546252774
                      result: disabled_tfa
                      ip: 127.0.0.1
                      id: 43
                      country: Local Country
                      city: Local Town
                usIn: 1575903572350348
                usOut: 1575903572351765
                usDiff: 1417
                testnet: false
              description: Response example
      description: Success response
  schemas:
    PrivateGetAccessLogResponse:
      properties:
        jsonrpc:
          type: string
          enum:
            - '2.0'
          description: The JSON-RPC version (2.0)
        id:
          type: integer
          description: The id that was sent in the request
        result:
          type: array
          items:
            $ref: '#/components/schemas/access_log'
      required:
        - jsonrpc
        - result
      type: object
    access_log:
      properties:
        id:
          $ref: '#/components/schemas/id'
        ip:
          type: string
          description: IP address of source that generated action
        timestamp:
          $ref: '#/components/schemas/timestamp'
        country:
          type: string
          description: Country where the IP address is registered (estimated)
        city:
          type: string
          description: City where the IP address is registered (estimated)
        log:
          type: string
          description: >
            Action description. Possible values:


            - ``changed_email`` - email was changed

            - ``changed_password`` - password was changed

            - ``disabled_tfa`` - TFA was disabled

            - ``enabled_tfa`` - TFA was enabled

            - ``success`` - successful login

            - ``failure`` - login failure

            - ``enabled_subaccount_login`` - login was enabled for subaccount
            (in `data` - subaccount uid)

            - ``disabled_subaccount_login`` - login was disabled for subaccount
            (in `data` - subaccount uid)

            - ``new_api_key`` - API key was created (in `data` key client id)

            - ``removed_api_key`` - API key was removed (in `data` key client
            id)

            - ``changed_scope`` - scope of API key was changed (in `data` key
            client id)

            - ``changed_whitelist`` - whitelist of API key was edited (in `data`
            key client id)

            - ``disabled_api_key`` - API key was disabled (in `data` key client
            id)

            - ``enabled_api_key`` - API key was enabled (in `data` key client
            id)

            - ``reset_api_key`` - API key was reset (in `data` key client id)
        data:
          description: >-
            Optional, additional information about action, type depends on `log`
            value
          oneOf:
            - type: object
            - type: string
      required:
        - id
        - ip
        - timestamp
        - country
        - city
        - log
      type: object
    id:
      example: 5967413
      type: integer
      description: Unique identifier
    timestamp:
      example: 1536569522277
      type: integer
      description: The timestamp (milliseconds since the Unix epoch)

````

> ## Documentation Index
> Fetch the complete documentation index at: https://docs.deribit.com/llms.txt
> Use this file to discover all available pages before exploring further.

<AgentInstructions>

## Submitting Feedback

If you encounter incorrect, outdated, or confusing documentation on this page, submit feedback:

POST https://docs.deribit.com/feedback

```json
{
  "path": "/api-reference/account-management/private-get_account_summaries",
  "feedback": "Description of the issue"
}
```

Only submit feedback when you have something specific and actionable to report.

</AgentInstructions>

# private/get_account_summaries

> Retrieves a per-currency list of account summaries for the authenticated user. Each summary includes balance, equity, available funds, and margin information for each currency.

To retrieve summaries for a specific subaccount, use the `subaccount_id` parameter. When the `extended` parameter is set to `true`, additional account details such as account ID, username, email, and account type are included.

**Scope:** `account:read`

[Try in API console](https://test.deribit.com/api_console?method=%2Fprivate%2Fget_account_summaries)





## OpenAPI

````yaml /specifications/deribit_openapi.json get /private/get_account_summaries
openapi: 3.0.0
info:
  title: Deribit API
  version: 2.1.1
servers:
  - url: https://test.deribit.com/api/v2
security: []
tags:
  - name: WebSocket Only
    description: Can only be used over websockets.
  - name: Public
    description: Public methods can be used without authentication.
  - name: Private
    description: >-
      <p>Private methods require authentication. All requests must include a
      valid OAuth2 token.</p>

      <p>A token can be requested using the <a
      href="#public-auth">/public/auth</a> method.</p>

      <p>When using the websockets protocol, the token must be included as a
      parameter <code>access_token</code> in the message. When using REST (HTTP
      GET), the token may also be passed in the <code>Authorization</code>
      header.</p>
  - name: Authentication
  - name: Session Management
  - name: Subscription Management
    description: >-
      Subscription works as [notifications](#notifications), so users will
      automatically (after subscribing) receive messages from the server.
      Overview for each channel response format is described in
      [subscriptions](#subscriptions) section.
  - name: Account Management
  - name: Trading
  - name: Market Data
  - name: Wallet
  - name: Chat
paths:
  /private/get_account_summaries:
    get:
      tags:
        - Account Management
        - Private
      description: >+
        Retrieves a per-currency list of account summaries for the authenticated
        user. Each summary includes balance, equity, available funds, and margin
        information for each currency.


        To retrieve summaries for a specific subaccount, use the `subaccount_id`
        parameter. When the `extended` parameter is set to `true`, additional
        account details such as account ID, username, email, and account type
        are included.


        **Scope:** `account:read`


        [Try in API
        console](https://test.deribit.com/api_console?method=%2Fprivate%2Fget_account_summaries)

      parameters:
        - name: subaccount_id
          in: query
          schema:
            type: integer
          required: false
          description: The user id for the subaccount
        - in: query
          name: extended
          required: false
          schema:
            type: boolean
            example: true
          description: Include additional fields
      requestBody:
        content:
          application/json:
            examples:
              request:
                value:
                  jsonrpc: '2.0'
                  id: 2515
                  method: private/get_account_summaries
                  params:
                    extended: true
                description: JSON-RPC Request Example
        description: JSON-RPC request body
      responses:
        '200':
          $ref: '#/components/responses/PrivateAccountSummariesResponse'
components:
  responses:
    PrivateAccountSummariesResponse:
      content:
        application/json:
          schema:
            $ref: '#/components/schemas/PrivateAccountSummariesResponse'
          examples:
            response:
              value:
                jsonrpc: '2.0'
                id: 2515
                result:
                  id: 10
                  email: user@example.com
                  system_name: user
                  username: user
                  block_rfq_self_match_prevention: true
                  creation_timestamp: 1687352432143
                  type: main
                  referrer_id: null
                  login_enabled: false
                  security_keys_enabled: false
                  mmp_enabled: false
                  interuser_transfers_enabled: false
                  self_trading_reject_mode: cancel_maker
                  self_trading_extended_to_subaccounts: false
                  summaries:
                    - currency: BTC
                      delta_total_map:
                        btc_usd: 31.594357699
                      margin_balance: 302.62729214
                      futures_session_rpl: -0.03258105
                      options_session_rpl: 0
                      estimated_liquidation_ratio_map:
                        btc_usd: 0.1009872222854525
                      session_upl: 0.05271555
                      estimated_liquidation_ratio: 0.10098722
                      options_gamma_map:
                        btc_usd: 0.00001
                      options_vega: 0.0858
                      options_value: -0.0086
                      available_withdrawal_funds: 301.35396172
                      projected_delta_total: 32.613978
                      maintenance_margin: 0.8857841
                      total_pl: -0.33084225
                      limits:
                        limits_per_currency: false
                        non_matching_engine:
                          burst: 1500
                          rate: 1000
                        matching_engine:
                          trading:
                            total:
                              burst: 250
                              rate: 200
                          spot:
                            burst: 250
                            rate: 200
                          quotes:
                            burst: 500
                            rate: 500
                          max_quotes:
                            burst: 10
                            rate: 10
                          guaranteed_quotes:
                            burst: 2
                            rate: 2
                          cancel_all:
                            burst: 250
                            rate: 200
                      projected_maintenance_margin: 0.7543841
                      available_funds: 301.38059622
                      options_delta: -1.01962
                      balance: 302.60065765
                      equity: 302.61869214
                      futures_session_upl: 0.05921555
                      fee_balance: 0
                      options_session_upl: -0.0065
                      projected_initial_margin: 1.01529592
                      options_theta: 15.97071
                      portfolio_margining_enabled: false
                      cross_collateral_enabled: false
                      margin_model: segregated_sm
                      options_vega_map:
                        btc_usd: 0.0858
                      futures_pl: -0.32434225
                      options_pl: -0.0065
                      initial_margin: 1.24669592
                      spot_reserve: 0
                      delta_total: 31.602958
                      options_gamma: 0.00001
                      session_rpl: -0.03258105
                      fees:
                        btc_usd:
                          option:
                            default:
                              type: relative
                              taker: 0.625
                              maker: 0.625
                            block_trade: 0.625
                          perpetual:
                            default:
                              type: fixed
                              taker: 0.00035000000000000005
                              maker: -0.0001
                            block_trade: 0.3
                          future:
                            default:
                              type: fixed
                              taker: 0.00035000000000000005
                              maker: -0.0001
                            block_trade: 0.3
                    - currency: ETH
                      futures_session_upl: 0
                      portfolio_margining_enabled: false
                      available_funds: 99.999598
                      initial_margin: 0.000402
                      futures_session_rpl: 0
                      options_gamma: 0
                      balance: 100
                      options_vega_map: {}
                      session_upl: 0
                      fee_balance: 0
                      delta_total_map:
                        eth_usd: 0
                      projected_maintenance_margin: 0
                      options_gamma_map: {}
                      projected_delta_total: 0
                      margin_model: segregated_sm
                      futures_pl: 0
                      options_theta: 0
                      limits:
                        limits_per_currency: false
                        non_matching_engine:
                          burst: 1500
                          rate: 1000
                        matching_engine:
                          trading:
                            total:
                              burst: 250
                              rate: 200
                          spot:
                            burst: 250
                            rate: 200
                          quotes:
                            burst: 500
                            rate: 500
                          max_quotes:
                            burst: 10
                            rate: 10
                          guaranteed_quotes:
                            burst: 2
                            rate: 2
                          cancel_all:
                            burst: 250
                            rate: 200
                      options_delta: 0
                      equity: 100
                      projected_initial_margin: 0.0002
                      estimated_liquidation_ratio_map:
                        eth_usd: 0
                      spot_reserve: 0.0002
                      cross_collateral_enabled: false
                      available_withdrawal_funds: 99.999597
                      delta_total: 0
                      options_session_upl: 0
                      maintenance_margin: 0
                      options_theta_map: {}
                      additional_reserve: 0
                      estimated_liquidation_ratio: 0
                      options_pl: 0
                      options_session_rpl: 0
                      options_vega: 0
                      total_pl: 0
                      session_rpl: 0
                      options_value: 0
                      margin_balance: 100
                      fees:
                        eth_usd:
                          option:
                            default:
                              type: relative
                              taker: 0.5
                              maker: 0.5
                            block_trade: 0.5
                          perpetual:
                            default:
                              type: fixed
                              taker: 0.00025
                              maker: -0.00005
                            block_trade: 0.2
                          future:
                            default:
                              type: fixed
                              taker: 0.00025
                              maker: -0.00005
                            block_trade: 0.2
              description: Response example
      description: Success response
  schemas:
    PrivateAccountSummariesResponse:
      properties:
        jsonrpc:
          type: string
          enum:
            - '2.0'
          description: The JSON-RPC version (2.0)
        id:
          type: integer
          description: The id that was sent in the request
        result:
          type: object
          properties:
            id:
              type: integer
              example: 12354
              description: Account id (available when parameter `extended` = `true`)
            system_name:
              example: myname
              type: string
              description: >-
                System generated user nickname (available when parameter
                `extended` = `true`)
            username:
              type: string
              example: name
              description: >-
                Account name (given by user) (available when parameter
                `extended` = `true`)
            type:
              enum:
                - main
                - subaccount
              type: string
              description: Account type (available when parameter `extended` = `true`)
            login_enabled:
              type: boolean
              example: false
              description: >-
                Whether account is loginable using email and password (available
                when parameter `extended` = `true` and account is a subaccount)
            email:
              example: support@deribit.com
              type: string
              description: User email (available when parameter `extended` = `true`)
            security_keys_enabled:
              example: false
              type: boolean
              description: >-
                Whether Security Key authentication is enabled (available when
                parameter `extended` = `true`)
            mmp_enabled:
              example: false
              type: boolean
              description: >-
                Whether MMP is enabled (available when parameter `extended` =
                `true`)
            interuser_transfers_enabled:
              type: boolean
              example: false
              description: >-
                `true` when the inter-user transfers are enabled for user
                (available when parameter `extended` = `true`)
            referrer_id:
              type: string
              example: '517.6035'
              description: >-
                Optional identifier of the referrer (of the affiliation program,
                and available when parameter `extended` = `true`), which link
                was used by this account at registration. It coincides with
                suffix of the affiliation link path after `/reg-`
            creation_timestamp:
              type: integer
              example: 1542100802842
              description: >-
                Time at which the account was created (milliseconds since the
                Unix epoch; available when parameter `extended` = `true`)
            self_trading_reject_mode:
              type: string
              description: >-
                Self trading rejection behavior - `reject_taker` or
                `cancel_maker` (available when parameter `extended` = `true`)
            self_trading_extended_to_subaccounts:
              type: string
              description: >-
                `true` if self trading rejection behavior is applied to trades
                between subaccounts (available when parameter `extended` =
                `true`)
            block_rfq_self_match_prevention:
              type: string
              description: >-
                When Block RFQ Self Match Prevention is enabled, it ensures that
                RFQs cannot be executed between accounts that belong to the same
                legal entity. This setting is independent of the general
                self-match prevention settings and must be configured
                separately.
            affiliate_promotion_fee:
              type: number
              example: 0
              description: Affiliate promotion fee (if greater than 0.0)
            trading_products_details:
              type: object
              description: >-
                Which trading products are enabled or can be overwritten for the
                account
            receive_notifications:
              type: boolean
              example: false
              description: Whether the account receives notifications
            summaries:
              type: array
              items:
                type: object
                properties:
                  total_pl:
                    example: 0.02032221
                    type: number
                    description: Profit and loss
                  session_rpl:
                    $ref: '#/components/schemas/rpl'
                  session_upl:
                    $ref: '#/components/schemas/upl'
                  available_funds:
                    example: 2.2638913
                    type: number
                    description: >-
                      The account's available funds. When cross collateral is
                      enabled, this aggregated value is calculated by converting
                      the sum of each cross collateral currency's value to the
                      given currency, using each cross collateral currency's
                      index.
                  available_withdrawal_funds:
                    type: number
                    example: 2.26
                    description: The account's available to withdrawal funds
                  margin_balance:
                    type: number
                    example: 2.25
                    description: >-
                      The account's margin balance. When cross collateral is
                      enabled, this aggregated value is calculated by converting
                      the sum of each cross collateral currency's value to the
                      given currency, using each cross collateral currency's
                      index.
                  balance:
                    example: 3.4906363
                    type: number
                    description: The account's balance
                  spot_reserve:
                    example: 0.3
                    type: number
                    description: The account's balance reserved in active spot orders
                  additional_reserve:
                    $ref: '#/components/schemas/additional_reserve'
                  fee_balance:
                    $ref: '#/components/schemas/fee_balance'
                  fee_group:
                    type: string
                    description: >-
                      Fee group indicates the level of fee discounts applied to
                      an account. Use `extended`: `true` to view this field. If
                      the field is missing, the account is not assigned to any
                      fee group. **📖 Related Support Article:** [Automatically
                      applied volume based fee
                      discounts](https://support.deribit.com/hc/en-us/articles/25944746248989-Fees#heading-11)
                  currency:
                    example: ETH
                    type: string
                    description: Currency of the summary
                  delta_total:
                    $ref: '#/components/schemas/delta_total'
                  projected_delta_total:
                    $ref: '#/components/schemas/projected_delta_total'
                  deposit_address:
                    example: 14diAAyXL5UzhPTCKC998ch2GV7DMb7yDi
                    type: string
                    description: The deposit address for the account (if available)
                  equity:
                    example: 2.6437733
                    type: number
                    description: The account's current equity
                  futures_pl:
                    example: 0
                    type: number
                    description: Futures profit and Loss
                  futures_session_rpl:
                    example: 0
                    type: number
                    description: Futures session realized profit and Loss
                  futures_session_upl:
                    example: 0
                    type: number
                    description: Futures session unrealized profit and Loss
                  initial_margin:
                    example: 0.379882
                    type: number
                    description: >-
                      The account's initial margin. When cross collateral is
                      enabled, this aggregated value is calculated by converting
                      the sum of each cross collateral currency's value to the
                      given currency, using each cross collateral currency's
                      index.
                  maintenance_margin:
                    example: 0.1334519
                    type: number
                    description: >-
                      The maintenance margin. When cross collateral is enabled,
                      this aggregated value is calculated by converting the sum
                      of each cross collateral currency's value to the given
                      currency, using each cross collateral currency's index.
                  estimated_liquidation_ratio:
                    $ref: '#/components/schemas/estimated_liquidation_ratio'
                  options_delta:
                    example: 0
                    type: number
                    description: Options summary delta
                  options_gamma:
                    example: 0
                    type: number
                    description: Options summary gamma
                  options_pl:
                    example: 0
                    type: number
                    description: Options profit and Loss
                  options_session_rpl:
                    example: 0
                    type: number
                    description: Options session realized profit and Loss
                  options_session_upl:
                    example: 0
                    type: number
                    description: Options session unrealized profit and Loss
                  options_theta:
                    example: 0
                    type: number
                    description: Options summary theta
                  options_value:
                    example: 0
                    type: number
                    description: Options value
                  options_vega:
                    example: 0
                    type: number
                    description: Options summary vega
                  options_gamma_map:
                    type: object
                    description: Map of options' gammas per index
                  options_theta_map:
                    type: object
                    description: Map of options' thetas per index
                  options_vega_map:
                    type: object
                    description: Map of options' vegas per index
                  projected_initial_margin:
                    $ref: '#/components/schemas/projected_initial_margin'
                  projected_maintenance_margin:
                    $ref: '#/components/schemas/projected_maintenance_margin'
                  portfolio_margining_enabled:
                    type: boolean
                    example: true
                    description: '`true` when portfolio margining is enabled for user'
                  cross_collateral_enabled:
                    type: boolean
                    example: true
                    description: When `true` cross collateral is enabled for user
                  margin_model:
                    type: string
                    example: segregated_sm
                    description: Name of user's currently enabled margin model
                  total_equity_usd:
                    example: 2.6437733
                    type: number
                    description: >-
                      Optional (only for users using cross margin). The
                      account's total equity in all cross collateral currencies,
                      expressed in USD
                  total_initial_margin_usd:
                    example: 0.379882
                    type: number
                    description: >-
                      Optional (only for users using cross margin). The
                      account's total initial margin in all cross collateral
                      currencies, expressed in USD
                  total_maintenance_margin_usd:
                    example: 0.1334519
                    type: number
                    description: >-
                      Optional (only for users using cross margin). The
                      account's total maintenance margin in all cross collateral
                      currencies, expressed in USD
                  total_margin_balance_usd:
                    type: number
                    example: 2.25
                    description: >-
                      Optional (only for users using cross margin). The
                      account's total margin balance in all cross collateral
                      currencies, expressed in USD
                  total_delta_total_usd:
                    type: number
                    example: 1.8
                    description: >-
                      Optional (only for users using cross margin). The
                      account's total delta total in all cross collateral
                      currencies, expressed in USD
                  limits:
                    $ref: '#/components/schemas/api_limits'
                  has_non_block_chain_equity:
                    type: boolean
                    description: >-
                      Optional field returned with value `true` when user has
                      non block chain equity that is excluded from proof of
                      reserve calculations
                  fees:
                    type: object
                    additionalProperties:
                      type: object
                      additionalProperties:
                        type: object
                        properties:
                          default:
                            type: object
                            properties:
                              type:
                                type: string
                                description: Fee calculation type (e.g., fixed, relative)
                              taker:
                                type: number
                                description: Taker fee
                              maker:
                                type: number
                                description: Maker fee
                            required:
                              - type
                              - taker
                              - maker
                          block_trade:
                            type: number
                            description: Block trade fee (if applicable)
                        required:
                          - default
                    description: >-
                      Fee structure for all currency pairs and instrument types
                      related to the currency (available when parameter
                      `extended` = `true` and user has any discounts). Keys are
                      index names (e.g., "btc_usd"), values are objects with
                      instrument types as keys (option, perpetual, future).
                  affiliate_promotion_fee:
                    type: number
                    example: 0
                    description: Affiliate promotion fee (if greater than 0.0)
                  trading_products_details:
                    type: object
                    description: >-
                      Which trading products are enabled or can be overwritten
                      for the account
                  receive_notifications:
                    type: boolean
                    example: false
                    description: Whether the account receives notifications
                required:
                  - equity
                  - currency
                  - maintenance_margin
                  - initial_margin
                  - available_funds
                  - available_withdrawal_funds
                  - balance
                  - session_upl
                  - session_rpl
                  - total_pl
                  - options_pl
                  - options_session_upl
                  - options_session_rpl
                  - options_delta
                  - options_gamma
                  - options_vega
                  - options_value
                  - options_theta
                  - futures_pl
                  - options_gamma_map
                  - options_theta_map
                  - options_vega_map
                  - futures_session_upl
                  - futures_session_rpl
                  - projected_maintenance_margin
                  - delta_total
                  - projected_delta_total
              description: Aggregated list of per-currency account summaries
          required:
            - security_keys_enabled
            - system_name
            - username
            - email
            - type
            - id
      required:
        - jsonrpc
        - result
      type: object
    rpl:
      example: 0.1
      type: number
      description: Session realized profit and loss
    upl:
      example: 0.846863
      type: number
      description: Session unrealized profit and loss
    additional_reserve:
      example: 0.3
      type: number
      description: The account's balance reserved in other orders
    fee_balance:
      type: number
      description: The account's fee balance (it can be used to pay for fees)
    delta_total:
      example: 0.1334
      type: number
      description: >
        The sum of position deltas. 


        **DeltaTotal = Net Transaction Delta of options + BTC Position of
        Futures**


        The DeltaTotal uses the Net Transaction Delta (or price adjusted Delta)
        of the options, where Net Transaction Delta = Black Scholes Delta - Mark
        Price of Options.


        This is because, from a risk perspective, we are interested in the
        change in Bitcoin price as the underlying changes.


        You should actually treat your delta as **Equity + Delta Total** if you
        want to have less risk for your USD PnL.


        ⚠️ **During the 30 minute settlement period we decay your Delta.** See
        [Delta decay during
        settlement](https://support.deribit.com/hc/en-us/articles/25944751433757-Delta-decay-during-settlement)
        for more details.
    projected_delta_total:
      example: 0.1334
      type: number
      description: >-
        The sum of position deltas without positions that will expire during
        closest expiration
    estimated_liquidation_ratio:
      example: 0.0000234
      type: number
      description: >-
        Estimated Liquidation Ratio is returned only for users without portfolio
        margining enabled. Multiplying it by future position's market price
        returns its estimated liquidation price. When cross collateral is
        enabled, this aggregated value is calculated by converting the sum of
        each cross collateral currency's value to the given currency, using each
        cross collateral currency's index.
    projected_initial_margin:
      example: 1
      type: number
      description: >-
        Projected initial margin. When cross collateral is enabled, this
        aggregated value is calculated by converting the sum of each cross
        collateral currency's value to the given currency, using each cross
        collateral currency's index.
    projected_maintenance_margin:
      example: 1
      type: number
      description: >-
        Projected maintenance margin. When cross collateral is enabled, this
        aggregated value is calculated by converting the sum of each cross
        collateral currency's value to the given currency, using each cross
        collateral currency's index.
    api_limits:
      type: object
      description: >-
        Returned object is described in [separate
        document](https://support.deribit.com/hc/en-us/articles/25944617523357-Rate-Limits).

````

> ## Documentation Index
> Fetch the complete documentation index at: https://docs.deribit.com/llms.txt
> Use this file to discover all available pages before exploring further.

<AgentInstructions>

## Submitting Feedback

If you encounter incorrect, outdated, or confusing documentation on this page, submit feedback:

POST https://docs.deribit.com/feedback

```json
{
  "path": "/api-reference/account-management/private-get_account_summary",
  "feedback": "Description of the issue"
}
```

Only submit feedback when you have something specific and actionable to report.

</AgentInstructions>

# private/get_account_summary

> Retrieves the account summary for a specific currency. The summary includes balance, equity, available funds, initial margin, maintenance margin, and other margin-related information.

To retrieve the summary for a specific subaccount, use the `subaccount_id` parameter. When the `extended` parameter is set to `true`, additional account details such as account ID, username, email, and account type are included.

**Scope:** `account:read`

[Try in API console](https://test.deribit.com/api_console?method=%2Fprivate%2Fget_account_summary)





## OpenAPI

````yaml /specifications/deribit_openapi.json get /private/get_account_summary
openapi: 3.0.0
info:
  title: Deribit API
  version: 2.1.1
servers:
  - url: https://test.deribit.com/api/v2
security: []
tags:
  - name: WebSocket Only
    description: Can only be used over websockets.
  - name: Public
    description: Public methods can be used without authentication.
  - name: Private
    description: >-
      <p>Private methods require authentication. All requests must include a
      valid OAuth2 token.</p>

      <p>A token can be requested using the <a
      href="#public-auth">/public/auth</a> method.</p>

      <p>When using the websockets protocol, the token must be included as a
      parameter <code>access_token</code> in the message. When using REST (HTTP
      GET), the token may also be passed in the <code>Authorization</code>
      header.</p>
  - name: Authentication
  - name: Session Management
  - name: Subscription Management
    description: >-
      Subscription works as [notifications](#notifications), so users will
      automatically (after subscribing) receive messages from the server.
      Overview for each channel response format is described in
      [subscriptions](#subscriptions) section.
  - name: Account Management
  - name: Trading
  - name: Market Data
  - name: Wallet
  - name: Chat
paths:
  /private/get_account_summary:
    get:
      tags:
        - Account Management
        - Private
      description: >+
        Retrieves the account summary for a specific currency. The summary
        includes balance, equity, available funds, initial margin, maintenance
        margin, and other margin-related information.


        To retrieve the summary for a specific subaccount, use the
        `subaccount_id` parameter. When the `extended` parameter is set to
        `true`, additional account details such as account ID, username, email,
        and account type are included.


        **Scope:** `account:read`


        [Try in API
        console](https://test.deribit.com/api_console?method=%2Fprivate%2Fget_account_summary)

      parameters:
        - name: currency
          required: true
          in: query
          schema:
            $ref: '#/components/schemas/wallet_currency'
          description: The currency symbol
        - name: subaccount_id
          in: query
          schema:
            type: integer
          required: false
          description: The user id for the subaccount
        - in: query
          name: extended
          required: false
          schema:
            type: boolean
            example: true
          description: Include additional fields
      requestBody:
        content:
          application/json:
            examples:
              request:
                value:
                  jsonrpc: '2.0'
                  id: 2515
                  method: private/get_account_summary
                  params:
                    currency: BTC
                    extended: true
                description: JSON-RPC Request Example
        description: JSON-RPC request body
      responses:
        '200':
          $ref: '#/components/responses/PrivateAccountResponse'
components:
  schemas:
    wallet_currency:
      enum:
        - BTC
        - ETH
        - STETH
        - ETHW
        - USDC
        - USDT
        - EURR
        - SOL
        - XRP
        - USYC
        - PAXG
        - BNB
        - USDE
      type: string
      description: Currency, i.e `"BTC"`, `"ETH"`, `"USDC"`
    PrivateAccountResponse:
      properties:
        jsonrpc:
          type: string
          enum:
            - '2.0'
          description: The JSON-RPC version (2.0)
        id:
          type: integer
          description: The id that was sent in the request
        result:
          properties:
            total_pl:
              example: 0.02032221
              type: number
              description: Profit and loss
            session_rpl:
              $ref: '#/components/schemas/rpl'
            session_upl:
              $ref: '#/components/schemas/upl'
            available_funds:
              example: 2.2638913
              type: number
              description: >-
                The account's available funds. When cross collateral is enabled,
                this aggregated value is calculated by converting the sum of
                each cross collateral currency's value to the given currency,
                using each cross collateral currency's index.
            available_withdrawal_funds:
              type: number
              example: 2.26
              description: The account's available to withdrawal funds
            margin_balance:
              type: number
              example: 2.25
              description: >-
                The account's margin balance. When cross collateral is enabled,
                this aggregated value is calculated by converting the sum of
                each cross collateral currency's value to the given currency,
                using each cross collateral currency's index.
            balance:
              example: 3.4906363
              type: number
              description: The account's balance
            spot_reserve:
              example: 0.3
              type: number
              description: The account's balance reserved in active spot orders
            additional_reserve:
              $ref: '#/components/schemas/additional_reserve'
            fee_balance:
              $ref: '#/components/schemas/fee_balance'
            fee_group:
              type: string
              description: >-
                Fee group indicates the level of fee discounts applied to an
                account. Use `extended`: `true` to view this field. If the field
                is missing, the account is not assigned to any fee group. **📖
                Related Support Article:** [Automatically applied volume based
                fee
                discounts](https://support.deribit.com/hc/en-us/articles/25944746248989-Fees#heading-11)
            currency:
              example: ETH
              type: string
              description: The selected currency
            delta_total:
              $ref: '#/components/schemas/delta_total'
            projected_delta_total:
              $ref: '#/components/schemas/projected_delta_total'
            deposit_address:
              example: 14diAAyXL5UzhPTCKC998ch2GV7DMb7yDi
              type: string
              description: The deposit address for the account (if available)
            email:
              example: support@deribit.com
              type: string
              description: User email (available when parameter `extended` = `true`)
            equity:
              example: 2.6437733
              type: number
              description: The account's current equity
            futures_pl:
              example: 0
              type: number
              description: Futures profit and Loss
            futures_session_rpl:
              example: 0
              type: number
              description: Futures session realized profit and Loss
            futures_session_upl:
              example: 0
              type: number
              description: Futures session unrealized profit and Loss
            initial_margin:
              example: 0.379882
              type: number
              description: >-
                The account's initial margin. When cross collateral is enabled,
                this aggregated value is calculated by converting the sum of
                each cross collateral currency's value to the given currency,
                using each cross collateral currency's index.
            maintenance_margin:
              example: 0.1334519
              type: number
              description: >-
                The maintenance margin. When cross collateral is enabled, this
                aggregated value is calculated by converting the sum of each
                cross collateral currency's value to the given currency, using
                each cross collateral currency's index.
            estimated_liquidation_ratio:
              $ref: '#/components/schemas/estimated_liquidation_ratio'
            system_name:
              example: myname
              type: string
              description: >-
                System generated user nickname (available when parameter
                `extended` = `true`)
            options_delta:
              example: 0
              type: number
              description: Options summary delta
            options_gamma:
              example: 0
              type: number
              description: Options summary gamma
            options_pl:
              example: 0
              type: number
              description: Options profit and Loss
            options_session_rpl:
              example: 0
              type: number
              description: Options session realized profit and Loss
            options_session_upl:
              example: 0
              type: number
              description: Options session unrealized profit and Loss
            options_theta:
              example: 0
              type: number
              description: Options summary theta
            options_value:
              example: 0
              type: number
              description: Options value
            options_vega:
              example: 0
              type: number
              description: Options summary vega
            options_gamma_map:
              type: object
              description: Map of options' gammas per index
            options_theta_map:
              type: object
              description: Map of options' thetas per index
            options_vega_map:
              type: object
              description: Map of options' vegas per index
            security_keys_enabled:
              example: false
              type: boolean
              description: >-
                Whether Security Key authentication is enabled (available when
                parameter `extended` = `true`)
            mmp_enabled:
              example: false
              type: boolean
              description: >-
                Whether MMP is enabled (available when parameter `extended` =
                `true`)
            projected_initial_margin:
              $ref: '#/components/schemas/projected_initial_margin'
            projected_maintenance_margin:
              $ref: '#/components/schemas/projected_maintenance_margin'
            username:
              type: string
              example: name
              description: >-
                Account name (given by user) (available when parameter
                `extended` = `true`)
            type:
              enum:
                - main
                - subaccount
              type: string
              description: Account type (available when parameter `extended` = `true`)
            login_enabled:
              type: boolean
              example: false
              description: >-
                Whether account is loginable using email and password (available
                when parameter `extended` = `true` and account is a subaccount)
            id:
              type: integer
              example: 12354
              description: Account id (available when parameter `extended` = `true`)
            portfolio_margining_enabled:
              type: boolean
              example: true
              description: '`true` when portfolio margining is enabled for user'
            cross_collateral_enabled:
              type: boolean
              example: true
              description: When `true` cross collateral is enabled for user
            margin_model:
              type: string
              example: segregated_sm
              description: Name of user's currently enabled margin model
            total_equity_usd:
              example: 2.6437733
              type: number
              description: >-
                Optional (only for users using cross margin). The account's
                total equity in all cross collateral currencies, expressed in
                USD
            total_initial_margin_usd:
              example: 0.379882
              type: number
              description: >-
                Optional (only for users using cross margin). The account's
                total initial margin in all cross collateral currencies,
                expressed in USD
            total_maintenance_margin_usd:
              example: 0.1334519
              type: number
              description: >-
                Optional (only for users using cross margin). The account's
                total maintenance margin in all cross collateral currencies,
                expressed in USD
            total_margin_balance_usd:
              type: number
              example: 2.25
              description: >-
                Optional (only for users using cross margin). The account's
                total margin balance in all cross collateral currencies,
                expressed in USD
            total_delta_total_usd:
              type: number
              example: 1.8
              description: >-
                Optional (only for users using cross margin). The account's
                total delta total in all cross collateral currencies, expressed
                in USD
            interuser_transfers_enabled:
              type: boolean
              example: false
              description: >-
                `true` when the inter-user transfers are enabled for user
                (available when parameter `extended` = `true`)
            referrer_id:
              type: string
              example: '517.6035'
              description: >-
                Optional identifier of the referrer (of the affiliation program,
                and available when parameter `extended` = `true`), which link
                was used by this account at registration. It coincides with
                suffix of the affiliation link path after `/reg-`
            limits:
              $ref: '#/components/schemas/api_limits'
            creation_timestamp:
              type: integer
              example: 1542100802842
              description: >-
                Time at which the account was created (milliseconds since the
                Unix epoch; available when parameter `extended` = `true`)
            has_non_block_chain_equity:
              type: boolean
              description: >-
                Optional field returned with value `true` when user has non
                block chain equity that is excluded from proof of reserve
                calculations
            self_trading_reject_mode:
              type: string
              description: >-
                Self trading rejection behavior - `reject_taker` or
                `cancel_maker` (available when parameter `extended` = `true`)
            self_trading_extended_to_subaccounts:
              type: string
              description: >-
                `true` if self trading rejection behavior is applied to trades
                between subaccounts (available when parameter `extended` =
                `true`)
            fees:
              type: object
              additionalProperties:
                type: object
                additionalProperties:
                  type: object
                  properties:
                    default:
                      type: object
                      properties:
                        type:
                          type: string
                          description: >-
                            Fee type - `relative` if fee is calculated as a
                            fraction of base instrument fee, `fixed` if fee is
                            calculated solely using user fee
                        taker:
                          type: number
                          description: Taker fee
                        maker:
                          type: number
                          description: Maker fee
                      required:
                        - type
                        - taker
                        - maker
                    block_trade:
                      type: number
                      description: Block trade fee (if applicable)
                  required:
                    - default
              description: >-
                Fee structure for all currency pairs and instrument types
                related to the currency (available when parameter `extended` =
                `true` and user has any discounts). Keys are index names (e.g.,
                "btc_usd"), values are objects with instrument types as keys
                (option, perpetual, future).
            affiliate_promotion_fee:
              type: number
              example: 0
              description: Affiliate promotion fee (if greater than 0.0)
            trading_products_details:
              type: object
              description: >-
                Which trading products are enabled or can be overwritten for the
                account
            receive_notifications:
              type: boolean
              example: false
              description: Whether the account receives notifications
            is_direct_access_allowed:
              type: boolean
              example: false
              description: Whether Direct Access trading is enabled for the account.
          required:
            - equity
            - currency
            - maintenance_margin
            - initial_margin
            - available_funds
            - available_withdrawal_funds
            - balance
            - session_upl
            - session_rpl
            - total_pl
            - options_pl
            - options_session_upl
            - options_session_rpl
            - options_delta
            - options_gamma
            - options_vega
            - options_value
            - options_theta
            - futures_pl
            - options_gamma_map
            - options_theta_map
            - options_vega_map
            - futures_session_upl
            - futures_session_rpl
            - projected_maintenance_margin
            - delta_total
            - projected_delta_total
            - security_keys_enabled
            - system_name
            - username
            - email
            - type
            - id
          type: object
      required:
        - jsonrpc
        - result
      type: object
    rpl:
      example: 0.1
      type: number
      description: Session realized profit and loss
    upl:
      example: 0.846863
      type: number
      description: Session unrealized profit and loss
    additional_reserve:
      example: 0.3
      type: number
      description: The account's balance reserved in other orders
    fee_balance:
      type: number
      description: The account's fee balance (it can be used to pay for fees)
    delta_total:
      example: 0.1334
      type: number
      description: >
        The sum of position deltas. 


        **DeltaTotal = Net Transaction Delta of options + BTC Position of
        Futures**


        The DeltaTotal uses the Net Transaction Delta (or price adjusted Delta)
        of the options, where Net Transaction Delta = Black Scholes Delta - Mark
        Price of Options.


        This is because, from a risk perspective, we are interested in the
        change in Bitcoin price as the underlying changes.


        You should actually treat your delta as **Equity + Delta Total** if you
        want to have less risk for your USD PnL.


        ⚠️ **During the 30 minute settlement period we decay your Delta.** See
        [Delta decay during
        settlement](https://support.deribit.com/hc/en-us/articles/25944751433757-Delta-decay-during-settlement)
        for more details.
    projected_delta_total:
      example: 0.1334
      type: number
      description: >-
        The sum of position deltas without positions that will expire during
        closest expiration
    estimated_liquidation_ratio:
      example: 0.0000234
      type: number
      description: >-
        Estimated Liquidation Ratio is returned only for users without portfolio
        margining enabled. Multiplying it by future position's market price
        returns its estimated liquidation price. When cross collateral is
        enabled, this aggregated value is calculated by converting the sum of
        each cross collateral currency's value to the given currency, using each
        cross collateral currency's index.
    projected_initial_margin:
      example: 1
      type: number
      description: >-
        Projected initial margin. When cross collateral is enabled, this
        aggregated value is calculated by converting the sum of each cross
        collateral currency's value to the given currency, using each cross
        collateral currency's index.
    projected_maintenance_margin:
      example: 1
      type: number
      description: >-
        Projected maintenance margin. When cross collateral is enabled, this
        aggregated value is calculated by converting the sum of each cross
        collateral currency's value to the given currency, using each cross
        collateral currency's index.
    api_limits:
      type: object
      description: >-
        Returned object is described in [separate
        document](https://support.deribit.com/hc/en-us/articles/25944617523357-Rate-Limits).
  responses:
    PrivateAccountResponse:
      content:
        application/json:
          schema:
            $ref: '#/components/schemas/PrivateAccountResponse'
          examples:
            response:
              value:
                jsonrpc: '2.0'
                id: 2515
                result:
                  delta_total_map:
                    btc_usd: 31.594357699
                  margin_balance: 302.62729214
                  futures_session_rpl: -0.03258105
                  options_session_rpl: 0
                  estimated_liquidation_ratio_map:
                    btc_usd: 0.1009872222854525
                  session_upl: 0.05271555
                  email: user@example.com
                  system_name: user
                  username: user
                  interuser_transfers_enabled: false
                  id: 10
                  estimated_liquidation_ratio: 0.10098722
                  options_gamma_map:
                    btc_usd: 0.00001
                  options_vega: 0.0858
                  options_value: -0.0086
                  available_withdrawal_funds: 301.35396172
                  projected_delta_total: 32.613978
                  maintenance_margin: 0.8857841
                  total_pl: -0.33084225
                  limits:
                    limits_per_currency: false
                    non_matching_engine:
                      burst: 1500
                      rate: 1000
                    matching_engine:
                      trading:
                        total:
                          burst: 250
                          rate: 200
                      spot:
                        burst: 250
                        rate: 200
                      quotes:
                        burst: 500
                        rate: 500
                      max_quotes:
                        burst: 10
                        rate: 10
                      guaranteed_quotes:
                        burst: 2
                        rate: 2
                      cancel_all:
                        burst: 250
                        rate: 200
                  options_theta_map:
                    btc_usd: 15.97071
                  projected_maintenance_margin: 0.7543841
                  available_funds: 301.38059622
                  login_enabled: false
                  options_delta: -1.01962
                  balance: 302.60065765
                  security_keys_enabled: false
                  referrer_id: null
                  mmp_enabled: false
                  equity: 302.61869214
                  block_rfq_self_match_prevention: true
                  futures_session_upl: 0.05921555
                  fee_balance: 0
                  currency: BTC
                  options_session_upl: -0.0065
                  projected_initial_margin: 1.01529592
                  options_theta: 15.97071
                  creation_timestamp: 1687352432143
                  self_trading_extended_to_subaccounts: false
                  portfolio_margining_enabled: false
                  cross_collateral_enabled: false
                  margin_model: segregated_sm
                  options_vega_map:
                    btc_usd: 0.0858
                  futures_pl: -0.32434225
                  options_pl: -0.0065
                  type: main
                  self_trading_reject_mode: cancel_maker
                  initial_margin: 1.24669592
                  spot_reserve: 0
                  delta_total: 31.602958
                  options_gamma: 0.00001
                  session_rpl: -0.03258105
                  fees:
                    btc_usd:
                      option:
                        default:
                          type: relative
                          taker: 0.625
                          maker: 0.625
                        block_trade: 0.625
                      perpetual:
                        default:
                          type: fixed
                          taker: 0.00035000000000000005
                          maker: -0.0001
                        block_trade: 0.3
                      future:
                        default:
                          type: fixed
                          taker: 0.00035000000000000005
                          maker: -0.0001
                        block_trade: 0.3
              description: Response example
      description: Success response

````

> ## Documentation Index
> Fetch the complete documentation index at: https://docs.deribit.com/llms.txt
> Use this file to discover all available pages before exploring further.

<AgentInstructions>

## Submitting Feedback

If you encounter incorrect, outdated, or confusing documentation on this page, submit feedback:

POST https://docs.deribit.com/feedback

```json
{
  "path": "/api-reference/account-management/private-get_affiliate_program_info",
  "feedback": "Description of the issue"
}
```

Only submit feedback when you have something specific and actionable to report.

</AgentInstructions>

# private/get_affiliate_program_info

> Retrieves information about the affiliate program status for the authenticated account. The response includes the number of referred affiliates, total payouts earned, pending payouts, and the unique affiliate referral link.

Use this method to track your affiliate program performance and earnings.

**📖 Related Support Article:** [Affiliate Program](https://support.deribit.com/hc/en-us/articles/25944777728797-Affiliate-Program)

**Scope:** `account:read`

[Try in API console](https://test.deribit.com/api_console?method=%2Fprivate%2Fget_affiliate_program_info)





## OpenAPI

````yaml /specifications/deribit_openapi.json get /private/get_affiliate_program_info
openapi: 3.0.0
info:
  title: Deribit API
  version: 2.1.1
servers:
  - url: https://test.deribit.com/api/v2
security: []
tags:
  - name: WebSocket Only
    description: Can only be used over websockets.
  - name: Public
    description: Public methods can be used without authentication.
  - name: Private
    description: >-
      <p>Private methods require authentication. All requests must include a
      valid OAuth2 token.</p>

      <p>A token can be requested using the <a
      href="#public-auth">/public/auth</a> method.</p>

      <p>When using the websockets protocol, the token must be included as a
      parameter <code>access_token</code> in the message. When using REST (HTTP
      GET), the token may also be passed in the <code>Authorization</code>
      header.</p>
  - name: Authentication
  - name: Session Management
  - name: Subscription Management
    description: >-
      Subscription works as [notifications](#notifications), so users will
      automatically (after subscribing) receive messages from the server.
      Overview for each channel response format is described in
      [subscriptions](#subscriptions) section.
  - name: Account Management
  - name: Trading
  - name: Market Data
  - name: Wallet
  - name: Chat
paths:
  /private/get_affiliate_program_info:
    get:
      tags:
        - Account Management
        - Private
      description: >+
        Retrieves information about the affiliate program status for the
        authenticated account. The response includes the number of referred
        affiliates, total payouts earned, pending payouts, and the unique
        affiliate referral link.


        Use this method to track your affiliate program performance and
        earnings.


        **📖 Related Support Article:** [Affiliate
        Program](https://support.deribit.com/hc/en-us/articles/25944777728797-Affiliate-Program)


        **Scope:** `account:read`


        [Try in API
        console](https://test.deribit.com/api_console?method=%2Fprivate%2Fget_affiliate_program_info)

      parameters: []
      requestBody:
        content:
          application/json:
            examples:
              request:
                value:
                  jsonrpc: '2.0'
                  id: 2
                  method: private/get_affiliate_program_info
                  params: {}
                description: JSON-RPC Request Example
        description: JSON-RPC request body
      responses:
        '200':
          $ref: '#/components/responses/PrivateGetAffiliateProgramInfoResponse'
components:
  responses:
    PrivateGetAffiliateProgramInfoResponse:
      content:
        application/json:
          schema:
            $ref: '#/components/schemas/PrivateGetAffiliateProgramInfoResponse'
          examples:
            response:
              value:
                jsonrpc: '2.0'
                id: 2
                result:
                  received:
                    eth: 0.00004
                    btc: 0.000001
                  number_of_affiliates: 1
                  link: https://www.deribit.com/reg-xxx.zxyq
                  is_enabled: true
              description: Response example
      description: Success response
  schemas:
    PrivateGetAffiliateProgramInfoResponse:
      properties:
        jsonrpc:
          type: string
          enum:
            - '2.0'
          description: The JSON-RPC version (2.0)
        id:
          type: integer
          description: The id that was sent in the request
        result:
          properties:
            is_enabled:
              type: boolean
              description: Status of affiliate program
            number_of_affiliates:
              type: number
              description: Number of affiliates
            link:
              type: string
              description: Affiliate link
            received:
              type: object
              properties:
                eth:
                  type: number
                  description: Total payout received in ETH
                btc:
                  type: number
                  description: Total payout received in BTC
              required:
                - btc
                - eth
          required:
            - is_enabled
          type: object
      required:
        - jsonrpc
        - result
      type: object

````

> ## Documentation Index
> Fetch the complete documentation index at: https://docs.deribit.com/llms.txt
> Use this file to discover all available pages before exploring further.

<AgentInstructions>

## Submitting Feedback

If you encounter incorrect, outdated, or confusing documentation on this page, submit feedback:

POST https://docs.deribit.com/feedback

```json
{
  "path": "/api-reference/account-management/private-get_email_language",
  "feedback": "Description of the issue"
}
```

Only submit feedback when you have something specific and actionable to report.

</AgentInstructions>

# private/get_email_language

> Retrieves the currently configured language preference for email notifications. Returns the language code (e.g., `en`, `ko`, `zh`, `ja`, `ru`) that is used for all email communications sent to the account.

**Scope:** `account:read`

[Try in API console](https://test.deribit.com/api_console?method=%2Fprivate%2Fget_email_language)





## OpenAPI

````yaml /specifications/deribit_openapi.json get /private/get_email_language
openapi: 3.0.0
info:
  title: Deribit API
  version: 2.1.1
servers:
  - url: https://test.deribit.com/api/v2
security: []
tags:
  - name: WebSocket Only
    description: Can only be used over websockets.
  - name: Public
    description: Public methods can be used without authentication.
  - name: Private
    description: >-
      <p>Private methods require authentication. All requests must include a
      valid OAuth2 token.</p>

      <p>A token can be requested using the <a
      href="#public-auth">/public/auth</a> method.</p>

      <p>When using the websockets protocol, the token must be included as a
      parameter <code>access_token</code> in the message. When using REST (HTTP
      GET), the token may also be passed in the <code>Authorization</code>
      header.</p>
  - name: Authentication
  - name: Session Management
  - name: Subscription Management
    description: >-
      Subscription works as [notifications](#notifications), so users will
      automatically (after subscribing) receive messages from the server.
      Overview for each channel response format is described in
      [subscriptions](#subscriptions) section.
  - name: Account Management
  - name: Trading
  - name: Market Data
  - name: Wallet
  - name: Chat
paths:
  /private/get_email_language:
    get:
      tags:
        - Account Management
        - Private
      description: >+
        Retrieves the currently configured language preference for email
        notifications. Returns the language code (e.g., `en`, `ko`, `zh`, `ja`,
        `ru`) that is used for all email communications sent to the account.


        **Scope:** `account:read`


        [Try in API
        console](https://test.deribit.com/api_console?method=%2Fprivate%2Fget_email_language)

      parameters: []
      requestBody:
        content:
          application/json:
            examples:
              request:
                value:
                  jsonrpc: '2.0'
                  id: 9265
                  method: private/get_email_language
                  params: {}
                description: JSON-RPC Request Example
        description: JSON-RPC request body
      responses:
        '200':
          $ref: '#/components/responses/PrivateGetEmailLanguageResponse'
components:
  responses:
    PrivateGetEmailLanguageResponse:
      content:
        application/json:
          schema:
            $ref: '#/components/schemas/PrivateGetEmailLanguageResponse'
          examples:
            response:
              value:
                jsonrpc: '2.0'
                id: 9265
                result: en
              description: Response example
      description: Success response
  schemas:
    PrivateGetEmailLanguageResponse:
      properties:
        jsonrpc:
          type: string
          enum:
            - '2.0'
          description: The JSON-RPC version (2.0)
        id:
          type: integer
          description: The id that was sent in the request
        result:
          type: string
          example: en
          description: The abbreviation of the language
      required:
        - jsonrpc
        - result
      type: object

````

> ## Documentation Index
> Fetch the complete documentation index at: https://docs.deribit.com/llms.txt
> Use this file to discover all available pages before exploring further.

<AgentInstructions>

## Submitting Feedback

If you encounter incorrect, outdated, or confusing documentation on this page, submit feedback:

POST https://docs.deribit.com/feedback

```json
{
  "path": "/api-reference/account-management/private-get_new_announcements",
  "feedback": "Description of the issue"
}
```

Only submit feedback when you have something specific and actionable to report.

</AgentInstructions>

# private/get_new_announcements

> Retrieves only unread announcements for the authenticated account. Announcements are marked as read when you use the `set_announcement_as_read` method or view them through the web interface.

This method is useful for displaying notification badges or highlighting new announcements that require the user's attention.

**Scope:** `account:read`

[Try in API console](https://test.deribit.com/api_console?method=%2Fprivate%2Fget_new_announcements)





## OpenAPI

````yaml /specifications/deribit_openapi.json get /private/get_new_announcements
openapi: 3.0.0
info:
  title: Deribit API
  version: 2.1.1
servers:
  - url: https://test.deribit.com/api/v2
security: []
tags:
  - name: WebSocket Only
    description: Can only be used over websockets.
  - name: Public
    description: Public methods can be used without authentication.
  - name: Private
    description: >-
      <p>Private methods require authentication. All requests must include a
      valid OAuth2 token.</p>

      <p>A token can be requested using the <a
      href="#public-auth">/public/auth</a> method.</p>

      <p>When using the websockets protocol, the token must be included as a
      parameter <code>access_token</code> in the message. When using REST (HTTP
      GET), the token may also be passed in the <code>Authorization</code>
      header.</p>
  - name: Authentication
  - name: Session Management
  - name: Subscription Management
    description: >-
      Subscription works as [notifications](#notifications), so users will
      automatically (after subscribing) receive messages from the server.
      Overview for each channel response format is described in
      [subscriptions](#subscriptions) section.
  - name: Account Management
  - name: Trading
  - name: Market Data
  - name: Wallet
  - name: Chat
paths:
  /private/get_new_announcements:
    get:
      tags:
        - Account Management
        - Private
      description: >+
        Retrieves only unread announcements for the authenticated account.
        Announcements are marked as read when you use the
        `set_announcement_as_read` method or view them through the web
        interface.


        This method is useful for displaying notification badges or highlighting
        new announcements that require the user's attention.


        **Scope:** `account:read`


        [Try in API
        console](https://test.deribit.com/api_console?method=%2Fprivate%2Fget_new_announcements)

      parameters: []
      requestBody:
        content:
          application/json:
            examples:
              request:
                value:
                  jsonrpc: '2.0'
                  id: 3022
                  method: private/get_new_announcements
                  params: {}
                description: JSON-RPC Request Example
        description: JSON-RPC request body
      responses:
        '200':
          $ref: '#/components/responses/PublicGetAnnouncementsResponse'
components:
  responses:
    PublicGetAnnouncementsResponse:
      content:
        application/json:
          schema:
            $ref: '#/components/schemas/PublicGetAnnouncementsResponse'
          examples:
            response:
              value:
                jsonrpc: '2.0'
                id: 3022
                result:
                  - title: Example announcement
                    publication_timestamp: 1550058362418
                    important: false
                    id: 1550058362418
                    body: Lorem ipsum dolor sit amet, consectetur adipiscing elit.
              description: Response example
      description: Success response
  schemas:
    PublicGetAnnouncementsResponse:
      properties:
        jsonrpc:
          type: string
          enum:
            - '2.0'
          description: The JSON-RPC version (2.0)
        id:
          type: integer
          description: The id that was sent in the request
        result:
          type: array
          items:
            properties:
              body:
                example: An&nbsp;announcement
                type: string
                description: The HTML body of the announcement
              publication_timestamp:
                example: 1527844253000
                type: integer
                description: >-
                  The timestamp (milliseconds since the Unix epoch) of
                  announcement publication
              id:
                example: 19288317
                type: number
                description: A unique identifier for the announcement
              important:
                example: false
                type: boolean
                description: Whether the announcement is marked as important
              confirmation:
                type: boolean
                example: false
                description: >-
                  Whether the user confirmation is required for this
                  announcement
              title:
                example: Example announcement
                type: string
                description: The title of the announcement
            required:
              - title
              - body
              - important
              - id
              - publication_timestamp
            type: object
      required:
        - jsonrpc
        - result
      type: object

````

> ## Documentation Index
> Fetch the complete documentation index at: https://docs.deribit.com/llms.txt
> Use this file to discover all available pages before exploring further.

<AgentInstructions>

## Submitting Feedback

If you encounter incorrect, outdated, or confusing documentation on this page, submit feedback:

POST https://docs.deribit.com/feedback

```json
{
  "path": "/api-reference/account-management/private-get_position",
  "feedback": "Description of the issue"
}
```

Only submit feedback when you have something specific and actionable to report.

</AgentInstructions>

# private/get_position

> Retrieves the open position for a specific instrument. Returns detailed position information including size, average entry price, mark price, unrealized P&L, initial margin, maintenance margin, and other position-related metrics.

If no position exists for the specified instrument, the response will indicate a zero position.

**Scope:** `trade:read`

[Try in API console](https://test.deribit.com/api_console?method=%2Fprivate%2Fget_position)





## OpenAPI

````yaml /specifications/deribit_openapi.json get /private/get_position
openapi: 3.0.0
info:
  title: Deribit API
  version: 2.1.1
servers:
  - url: https://test.deribit.com/api/v2
security: []
tags:
  - name: WebSocket Only
    description: Can only be used over websockets.
  - name: Public
    description: Public methods can be used without authentication.
  - name: Private
    description: >-
      <p>Private methods require authentication. All requests must include a
      valid OAuth2 token.</p>

      <p>A token can be requested using the <a
      href="#public-auth">/public/auth</a> method.</p>

      <p>When using the websockets protocol, the token must be included as a
      parameter <code>access_token</code> in the message. When using REST (HTTP
      GET), the token may also be passed in the <code>Authorization</code>
      header.</p>
  - name: Authentication
  - name: Session Management
  - name: Subscription Management
    description: >-
      Subscription works as [notifications](#notifications), so users will
      automatically (after subscribing) receive messages from the server.
      Overview for each channel response format is described in
      [subscriptions](#subscriptions) section.
  - name: Account Management
  - name: Trading
  - name: Market Data
  - name: Wallet
  - name: Chat
paths:
  /private/get_position:
    get:
      tags:
        - Account Management
        - Private
      description: >+
        Retrieves the open position for a specific instrument. Returns detailed
        position information including size, average entry price, mark price,
        unrealized P&L, initial margin, maintenance margin, and other
        position-related metrics.


        If no position exists for the specified instrument, the response will
        indicate a zero position.


        **Scope:** `trade:read`


        [Try in API
        console](https://test.deribit.com/api_console?method=%2Fprivate%2Fget_position)

      parameters:
        - name: instrument_name
          required: true
          in: query
          schema:
            $ref: '#/components/schemas/instrument_name'
          description: Instrument name
      requestBody:
        content:
          application/json:
            examples:
              request:
                value:
                  jsonrpc: '2.0'
                  id: 404
                  method: private/get_position
                  params:
                    instrument_name: BTC-PERPETUAL
                description: JSON-RPC Request Example
        description: JSON-RPC request body
      responses:
        '200':
          $ref: '#/components/responses/PrivateGetPositionResponse'
        '400':
          $ref: '#/components/responses/ErrorMessageResponse'
components:
  schemas:
    instrument_name:
      example: BTC-PERPETUAL
      type: string
      description: Unique instrument identifier
    PrivateGetPositionResponse:
      properties:
        jsonrpc:
          type: string
          enum:
            - '2.0'
          description: The JSON-RPC version (2.0)
        id:
          type: integer
          description: The id that was sent in the request
        result:
          $ref: '#/components/schemas/position_with_elp'
      required:
        - jsonrpc
        - result
      type: object
    ErrorMessageResponse:
      properties:
        jsonrpc:
          type: string
          enum:
            - '2.0'
          description: The JSON-RPC version (2.0)
        id:
          type: integer
          description: The id that was sent in the request
        message:
          type: string
        error:
          type: integer
      required:
        - jsonrpc
        - message
        - error
      type: object
    position_with_elp:
      allOf:
        - $ref: '#/components/schemas/position'
        - properties:
            estimated_liquidation_price:
              type: number
              description: >-
                Estimated liquidation price, added only for futures, for users
                with `segregated_sm` margin model
            open_orders_margin:
              type: number
              description: Open orders margin
          required:
            - estimated_liquidation_price
            - open_orders_margin
    position:
      properties:
        instrument_name:
          $ref: '#/components/schemas/instrument_name'
        kind:
          $ref: '#/components/schemas/kind'
        average_price:
          type: number
          description: Average price of trades that built this position
        direction:
          $ref: '#/components/schemas/position_direction'
        mark_price:
          type: number
          description: Current mark price for position's instrument
        delta:
          type: number
          description: Delta parameter
        gamma:
          type: number
          description: Only for options, Gamma parameter
        vega:
          type: number
          description: Only for options, Vega parameter
        theta:
          type: number
          description: Only for options, Theta parameter
        index_price:
          type: number
          description: Current index price
        initial_margin:
          type: number
          description: Initial margin
        maintenance_margin:
          type: number
          description: Maintenance margin
        settlement_price:
          type: number
          description: >-
            Optional (not added for spot). Last settlement price for position's
            instrument 0 if instrument wasn't settled yet
        total_profit_loss:
          type: number
          description: Profit or loss from position
        floating_profit_loss:
          type: number
          description: Floating profit or loss
        realized_profit_loss:
          type: number
          description: Realized profit or loss
        size:
          type: number
          description: >-
            Position size for futures size in quote currency (e.g. USD), for
            options size is in base currency (e.g. BTC)
        size_currency:
          type: number
          description: Only for futures, position size in base currency
        average_price_usd:
          type: number
          description: Only for options, average price in USD
        floating_profit_loss_usd:
          type: number
          description: Only for options, floating profit or loss in USD
        leverage:
          type: integer
          description: Current available leverage for future position
        realized_funding:
          type: number
          description: >-
            Realized Funding in current session included in session realized
            profit or loss, only for positions of perpetual instruments
        interest_value:
          type: number
          description: Value used to calculate `realized_funding` (perpetual only)
      required:
        - instrument_name
        - kind
        - average_price
        - direction
        - mark_price
        - delta
        - index_price
        - initial_margin
        - maintenance_margin
        - settlement_price
        - total_profit_loss
        - floating_profit_loss
        - realized_profit_loss
        - size
      type: object
    kind:
      enum:
        - future
        - option
        - spot
        - future_combo
        - option_combo
      type: string
      description: >-
        Instrument kind: `"future"`, `"option"`, `"spot"`, `"future_combo"`,
        `"option_combo"`
    position_direction:
      enum:
        - buy
        - sell
        - zero
      type: string
      description: 'Direction: `buy`, `sell` or `zero`'
  responses:
    PrivateGetPositionResponse:
      content:
        application/json:
          schema:
            $ref: '#/components/schemas/PrivateGetPositionResponse'
          examples:
            response:
              value:
                jsonrpc: '2.0'
                id: 404
                result:
                  average_price: 0
                  delta: 0
                  direction: buy
                  estimated_liquidation_price: 0
                  floating_profit_loss: 0
                  index_price: 3555.86
                  initial_margin: 0
                  instrument_name: BTC-PERPETUAL
                  interest_value: 1.7362511643080387
                  leverage: 100
                  kind: future
                  maintenance_margin: 0
                  mark_price: 3556.62
                  open_orders_margin: 0.000165889
                  realized_profit_loss: 0
                  settlement_price: 3555.44
                  size: 0
                  size_currency: 0
                  total_profit_loss: 0
              description: Response example
      description: Success response
    ErrorMessageResponse:
      content:
        application/json:
          schema:
            $ref: '#/components/schemas/ErrorMessageResponse'
      description: Success response

````

> ## Documentation Index
> Fetch the complete documentation index at: https://docs.deribit.com/llms.txt
> Use this file to discover all available pages before exploring further.

<AgentInstructions>

## Submitting Feedback

If you encounter incorrect, outdated, or confusing documentation on this page, submit feedback:

POST https://docs.deribit.com/feedback

```json
{
  "path": "/api-reference/account-management/private-get_positions",
  "feedback": "Description of the issue"
}
```

Only submit feedback when you have something specific and actionable to report.

</AgentInstructions>

# private/get_positions

> Retrieves all open positions for the authenticated account. Returns position details including size, average entry price, mark price, unrealized P&L, initial margin, maintenance margin, and other position-related information.

Results can be filtered by currency and instrument kind (future, option, etc.). To retrieve positions for a specific subaccount, use the `subaccount_id` parameter.

**Scope:** `trade:read`

[Try in API console](https://test.deribit.com/api_console?method=%2Fprivate%2Fget_positions)





## OpenAPI

````yaml /specifications/deribit_openapi.json get /private/get_positions
openapi: 3.0.0
info:
  title: Deribit API
  version: 2.1.1
servers:
  - url: https://test.deribit.com/api/v2
security: []
tags:
  - name: WebSocket Only
    description: Can only be used over websockets.
  - name: Public
    description: Public methods can be used without authentication.
  - name: Private
    description: >-
      <p>Private methods require authentication. All requests must include a
      valid OAuth2 token.</p>

      <p>A token can be requested using the <a
      href="#public-auth">/public/auth</a> method.</p>

      <p>When using the websockets protocol, the token must be included as a
      parameter <code>access_token</code> in the message. When using REST (HTTP
      GET), the token may also be passed in the <code>Authorization</code>
      header.</p>
  - name: Authentication
  - name: Session Management
  - name: Subscription Management
    description: >-
      Subscription works as [notifications](#notifications), so users will
      automatically (after subscribing) receive messages from the server.
      Overview for each channel response format is described in
      [subscriptions](#subscriptions) section.
  - name: Account Management
  - name: Trading
  - name: Market Data
  - name: Wallet
  - name: Chat
paths:
  /private/get_positions:
    get:
      tags:
        - Account Management
        - Private
      description: >+
        Retrieves all open positions for the authenticated account. Returns
        position details including size, average entry price, mark price,
        unrealized P&L, initial margin, maintenance margin, and other
        position-related information.


        Results can be filtered by currency and instrument kind (future, option,
        etc.). To retrieve positions for a specific subaccount, use the
        `subaccount_id` parameter.


        **Scope:** `trade:read`


        [Try in API
        console](https://test.deribit.com/api_console?method=%2Fprivate%2Fget_positions)

      parameters:
        - name: currency
          in: query
          schema:
            $ref: '#/components/schemas/currency_with_any'
            example: BTC
          required: false
        - name: kind
          in: query
          schema:
            $ref: '#/components/schemas/kind_without_spot'
            example: future
          description: Kind filter on positions
          required: false
        - name: subaccount_id
          in: query
          schema:
            type: integer
          required: false
          description: The user id for the subaccount
      requestBody:
        content:
          application/json:
            examples:
              request:
                value:
                  jsonrpc: '2.0'
                  id: 2236
                  method: private/get_positions
                  params:
                    currency: BTC
                    kind: future
                description: JSON-RPC Request Example
        description: JSON-RPC request body
      responses:
        '200':
          $ref: '#/components/responses/PrivateGetPositionsResponse'
        '400':
          $ref: '#/components/responses/ErrorMessageResponse'
components:
  schemas:
    currency_with_any:
      enum:
        - BTC
        - ETH
        - USDC
        - USDT
        - EURR
        - any
      type: string
      description: Currency name or `"any"` if don't care
    kind_without_spot:
      enum:
        - future
        - option
        - future_combo
        - option_combo
      type: string
      description: >-
        Instrument kind: `"future"`, `"option"`, `"future_combo"`,
        `"option_combo"` (spot is excluded as spot trades are settled
        immediately and have no open positions)
    PrivateGetPositionsResponse:
      properties:
        jsonrpc:
          type: string
          enum:
            - '2.0'
          description: The JSON-RPC version (2.0)
        id:
          type: integer
          description: The id that was sent in the request
        result:
          type: array
          items:
            $ref: '#/components/schemas/position_with_elp'
      required:
        - jsonrpc
        - result
      type: object
    ErrorMessageResponse:
      properties:
        jsonrpc:
          type: string
          enum:
            - '2.0'
          description: The JSON-RPC version (2.0)
        id:
          type: integer
          description: The id that was sent in the request
        message:
          type: string
        error:
          type: integer
      required:
        - jsonrpc
        - message
        - error
      type: object
    position_with_elp:
      allOf:
        - $ref: '#/components/schemas/position'
        - properties:
            estimated_liquidation_price:
              type: number
              description: >-
                Estimated liquidation price, added only for futures, for users
                with `segregated_sm` margin model
            open_orders_margin:
              type: number
              description: Open orders margin
          required:
            - estimated_liquidation_price
            - open_orders_margin
    position:
      properties:
        instrument_name:
          $ref: '#/components/schemas/instrument_name'
        kind:
          $ref: '#/components/schemas/kind'
        average_price:
          type: number
          description: Average price of trades that built this position
        direction:
          $ref: '#/components/schemas/position_direction'
        mark_price:
          type: number
          description: Current mark price for position's instrument
        delta:
          type: number
          description: Delta parameter
        gamma:
          type: number
          description: Only for options, Gamma parameter
        vega:
          type: number
          description: Only for options, Vega parameter
        theta:
          type: number
          description: Only for options, Theta parameter
        index_price:
          type: number
          description: Current index price
        initial_margin:
          type: number
          description: Initial margin
        maintenance_margin:
          type: number
          description: Maintenance margin
        settlement_price:
          type: number
          description: >-
            Optional (not added for spot). Last settlement price for position's
            instrument 0 if instrument wasn't settled yet
        total_profit_loss:
          type: number
          description: Profit or loss from position
        floating_profit_loss:
          type: number
          description: Floating profit or loss
        realized_profit_loss:
          type: number
          description: Realized profit or loss
        size:
          type: number
          description: >-
            Position size for futures size in quote currency (e.g. USD), for
            options size is in base currency (e.g. BTC)
        size_currency:
          type: number
          description: Only for futures, position size in base currency
        average_price_usd:
          type: number
          description: Only for options, average price in USD
        floating_profit_loss_usd:
          type: number
          description: Only for options, floating profit or loss in USD
        leverage:
          type: integer
          description: Current available leverage for future position
        realized_funding:
          type: number
          description: >-
            Realized Funding in current session included in session realized
            profit or loss, only for positions of perpetual instruments
        interest_value:
          type: number
          description: Value used to calculate `realized_funding` (perpetual only)
      required:
        - instrument_name
        - kind
        - average_price
        - direction
        - mark_price
        - delta
        - index_price
        - initial_margin
        - maintenance_margin
        - settlement_price
        - total_profit_loss
        - floating_profit_loss
        - realized_profit_loss
        - size
      type: object
    instrument_name:
      example: BTC-PERPETUAL
      type: string
      description: Unique instrument identifier
    kind:
      enum:
        - future
        - option
        - spot
        - future_combo
        - option_combo
      type: string
      description: >-
        Instrument kind: `"future"`, `"option"`, `"spot"`, `"future_combo"`,
        `"option_combo"`
    position_direction:
      enum:
        - buy
        - sell
        - zero
      type: string
      description: 'Direction: `buy`, `sell` or `zero`'
  responses:
    PrivateGetPositionsResponse:
      content:
        application/json:
          schema:
            $ref: '#/components/schemas/PrivateGetPositionsResponse'
          examples:
            response:
              value:
                jsonrpc: '2.0'
                id: 2236
                result:
                  - average_price: 7440.18
                    delta: 0.006687487
                    direction: buy
                    estimated_liquidation_price: 1.74
                    floating_profit_loss: 0
                    index_price: 7466.79
                    initial_margin: 0.000197283
                    instrument_name: BTC-PERPETUAL
                    interest_value: 1.7362511643080387
                    kind: future
                    leverage: 34
                    maintenance_margin: 0.000143783
                    mark_price: 7476.65
                    open_orders_margin: 0.000197288
                    realized_funding: -1.e-8
                    realized_profit_loss: -9.e-9
                    settlement_price: 7476.65
                    size: 50
                    size_currency: 0.006687487
                    total_profit_loss: 0.000032781
              description: Response example
      description: Success response
    ErrorMessageResponse:
      content:
        application/json:
          schema:
            $ref: '#/components/schemas/ErrorMessageResponse'
      description: Success response

````

> ## Documentation Index
> Fetch the complete documentation index at: https://docs.deribit.com/llms.txt
> Use this file to discover all available pages before exploring further.

<AgentInstructions>

## Submitting Feedback

If you encounter incorrect, outdated, or confusing documentation on this page, submit feedback:

POST https://docs.deribit.com/feedback

```json
{
  "path": "/api-reference/account-management/private-get_subaccounts",
  "feedback": "Description of the issue"
}
```

Only submit feedback when you have something specific and actionable to report.

</AgentInstructions>

# private/get_subaccounts

> Retrieves information about all subaccounts associated with the main account. Returns details such as subaccount IDs, names, and status.

When called from a subaccount, the response includes limited details for the main account and full details for the subaccount initiating the request.

Set the `with_portfolio` parameter to `true` to include portfolio information (balances, positions, etc.) in the response. By default, only subaccount metadata is returned.

**📖 Related Article:** [Managing Subaccounts](https://docs.deribit.com/articles/managing-subaccounts-api)

**Scope:** `account:read`

[Try in API console](https://test.deribit.com/api_console?method=%2Fprivate%2Fget_subaccounts)





## OpenAPI

````yaml /specifications/deribit_openapi.json get /private/get_subaccounts
openapi: 3.0.0
info:
  title: Deribit API
  version: 2.1.1
servers:
  - url: https://test.deribit.com/api/v2
security: []
tags:
  - name: WebSocket Only
    description: Can only be used over websockets.
  - name: Public
    description: Public methods can be used without authentication.
  - name: Private
    description: >-
      <p>Private methods require authentication. All requests must include a
      valid OAuth2 token.</p>

      <p>A token can be requested using the <a
      href="#public-auth">/public/auth</a> method.</p>

      <p>When using the websockets protocol, the token must be included as a
      parameter <code>access_token</code> in the message. When using REST (HTTP
      GET), the token may also be passed in the <code>Authorization</code>
      header.</p>
  - name: Authentication
  - name: Session Management
  - name: Subscription Management
    description: >-
      Subscription works as [notifications](#notifications), so users will
      automatically (after subscribing) receive messages from the server.
      Overview for each channel response format is described in
      [subscriptions](#subscriptions) section.
  - name: Account Management
  - name: Trading
  - name: Market Data
  - name: Wallet
  - name: Chat
paths:
  /private/get_subaccounts:
    get:
      tags:
        - Account Management
        - Private
      description: >+
        Retrieves information about all subaccounts associated with the main
        account. Returns details such as subaccount IDs, names, and status.


        When called from a subaccount, the response includes limited details for
        the main account and full details for the subaccount initiating the
        request.


        Set the `with_portfolio` parameter to `true` to include portfolio
        information (balances, positions, etc.) in the response. By default,
        only subaccount metadata is returned.


        **📖 Related Article:** [Managing
        Subaccounts](https://docs.deribit.com/articles/managing-subaccounts-api)


        **Scope:** `account:read`


        [Try in API
        console](https://test.deribit.com/api_console?method=%2Fprivate%2Fget_subaccounts)

      parameters:
        - name: with_portfolio
          in: query
          schema:
            type: boolean
            example: true
          description: >-
            Portfolio flag: `true` for portfolio information, `false` for
            subaccount information only. `false` by default
          required: false
      requestBody:
        content:
          application/json:
            examples:
              request:
                value:
                  jsonrpc: '2.0'
                  id: 4947
                  method: private/get_subaccounts
                  params:
                    with_portfolio: true
                description: JSON-RPC Request Example
        description: JSON-RPC request body
      responses:
        '200':
          $ref: '#/components/responses/PrivateGetSubaccountsResponse'
        '401':
          $ref: '#/components/responses/ErrorMessageResponse'
components:
  responses:
    PrivateGetSubaccountsResponse:
      content:
        application/json:
          schema:
            $ref: '#/components/schemas/PrivateGetSubaccountsResponse'
          examples:
            response:
              value:
                jsonrpc: '2.0'
                id: 4947
                result:
                  - email: user_AAA@email.com
                    id: 2
                    is_password: true
                    margin_model: segregated_sm
                    login_enabled: true
                    portfolio:
                      eth:
                        additional_reserve: 0
                        spot_reserve: 0
                        available_funds: 5
                        available_withdrawal_funds: 5
                        balance: 5
                        currency: eth
                        equity: 5
                        initial_margin: 0
                        maintenance_margin: 0
                        margin_balance: 5
                      btc:
                        additional_reserve: 0
                        spot_reserve: 0
                        available_funds: 5.000413075
                        available_withdrawal_funds: 5.000413075
                        balance: 5.000593987
                        currency: btc
                        equity: 5.000571846
                        initial_margin: 0.000158771
                        maintenance_margin: 0.000115715
                        margin_balance: 5.000571846
                    receive_notifications: false
                    system_name: user_1
                    security_keys_enabled: false
                    security_keys_assignments: []
                    type: main
                    username: user_1
                  - email: user_AAA@gmail.com
                    id: 7
                    is_password: true
                    margin_model: cross_pm
                    login_enabled: false
                    portfolio:
                      eth:
                        additional_reserve: 0
                        spot_reserve: 0
                        available_funds: 0
                        available_withdrawal_funds: 0
                        balance: 0
                        currency: eth
                        equity: 0
                        initial_margin: 0
                        maintenance_margin: 0
                        margin_balance: 0
                      btc:
                        additional_reserve: 0
                        spot_reserve: 0
                        available_funds: 0
                        available_withdrawal_funds: 0
                        balance: 0
                        currency: btc
                        equity: 0
                        initial_margin: 0
                        maintenance_margin: 0
                        margin_balance: 0
                    receive_notifications: false
                    system_name: user_1_1
                    security_keys_enabled: false
                    security_keys_assignments: []
                    type: subaccount
                    username: user_1_1
              description: Response example
      description: Success response
    ErrorMessageResponse:
      content:
        application/json:
          schema:
            $ref: '#/components/schemas/ErrorMessageResponse'
      description: Success response
  schemas:
    PrivateGetSubaccountsResponse:
      properties:
        jsonrpc:
          type: string
          enum:
            - '2.0'
          description: The JSON-RPC version (2.0)
        id:
          type: integer
          description: The id that was sent in the request
        result:
          type: array
          items:
            type: object
            properties:
              username:
                type: string
              type:
                enum:
                  - main
                  - subaccount
                type: string
              id:
                type: integer
                description: Account/Subaccount identifier
              email:
                type: string
                description: User email
              not_confirmed_email:
                type: string
                description: >-
                  New email address that has not yet been confirmed. This field
                  is only included if `with_portfolio` == `true`.
              security_keys_enabled:
                type: boolean
                description: Whether the Security Keys authentication is enabled
              security_keys_assignments:
                type: array
                description: Names of assignments with Security Keys assigned
              system_name:
                type: string
                description: System generated user nickname
              receive_notifications:
                type: boolean
                description: >-
                  When `true` - receive all notification emails on the main
                  email
              is_password:
                type: boolean
                description: '`true` when password for the subaccount has been configured'
              margin_model:
                type: string
                description: Margin model
              proof_id:
                type: string
                description: >-
                  Hashed identifier used in the Proof Of Liability for the
                  subaccount. This identifier allows you to find your entries in
                  the Deribit Proof-Of-Reserves files. IMPORTANT: Keep it secret
                  to not disclose your entries in the Proof-Of-Reserves.
              proof_id_signature:
                type: string
                description: >-
                  Signature used as a base string for proof_id hash. IMPORTANT:
                  Keep it secret to not disclose your entries in the
                  Proof-Of-Reserves.
              login_enabled:
                type: boolean
                description: Informs whether login to the subaccount is enabled
              portfolio:
                $ref: '#/components/schemas/portfolio'
                description: Only if with_portfolio == true
            required:
              - username
              - email
              - type
              - tfa_enabled
              - receive_notifications
              - is_password
              - system_name
              - id
      required:
        - jsonrpc
        - result
      type: object
    ErrorMessageResponse:
      properties:
        jsonrpc:
          type: string
          enum:
            - '2.0'
          description: The JSON-RPC version (2.0)
        id:
          type: integer
          description: The id that was sent in the request
        message:
          type: string
        error:
          type: integer
      required:
        - jsonrpc
        - message
        - error
      type: object
    portfolio:
      properties:
        btc(example):
          $ref: '#/components/schemas/currency_portfolio'
      type: object
    currency_portfolio:
      properties:
        margin_balance:
          type: number
          description: >-
            The account's margin balance. When cross collateral is enabled, this
            aggregated value is calculated by converting the sum of each cross
            collateral currency's value to the given currency, using each cross
            collateral currency's index.
        currency:
          type: string
          enum:
            - btc
            - eth
          description: The selected currency
        maintenance_margin:
          type: number
          description: >-
            The maintenance margin. When cross collateral is enabled, this
            aggregated value is calculated by converting the sum of each cross
            collateral currency's value to the given currency, using each cross
            collateral currency's index.
        initial_margin:
          type: number
          description: >-
            The account's initial margin. When cross collateral is enabled, this
            aggregated value is calculated by converting the sum of each cross
            collateral currency's value to the given currency, using each cross
            collateral currency's index.
        equity:
          type: number
          description: The account's current equity
        balance:
          type: number
          description: The account's balance
        available_withdrawal_funds:
          type: number
          description: The account's available to withdrawal funds
        available_funds:
          type: number
          description: >-
            The account's available funds. When cross collateral is enabled,
            this aggregated value is calculated by converting the sum of each
            cross collateral currency's value to the given currency, using each
            cross collateral currency's index.
        additional_reserve:
          $ref: '#/components/schemas/additional_reserve'
        spot_reserve:
          type: number
          description: The account's balance reserved in active spot orders
      required:
        - margin_balance
        - currency
        - maintenance_margin
        - initial_margin
        - equity
        - balance
        - available_withdrawal_funds
        - available_funds
        - additional_reserve
        - spot_reserve
      type: object
    additional_reserve:
      example: 0.3
      type: number
      description: The account's balance reserved in other orders

````

> ## Documentation Index
> Fetch the complete documentation index at: https://docs.deribit.com/llms.txt
> Use this file to discover all available pages before exploring further.

<AgentInstructions>

## Submitting Feedback

If you encounter incorrect, outdated, or confusing documentation on this page, submit feedback:

POST https://docs.deribit.com/feedback

```json
{
  "path": "/api-reference/account-management/private-get_subaccounts_details",
  "feedback": "Description of the issue"
}
```

Only submit feedback when you have something specific and actionable to report.

</AgentInstructions>

# private/get_subaccounts_details

> Retrieves position details for all subaccounts for a specific currency. Returns positions aggregated across all subaccounts, including size, average entry price, mark price, and P&L information.

Optionally include open orders for each subaccount by setting the `with_open_orders` parameter to `true`.

**📖 Related Article:** [Managing Subaccounts](https://docs.deribit.com/articles/managing-subaccounts-api)

**Scope:** `account:read`

[Try in API console](https://test.deribit.com/api_console?method=%2Fprivate%2Fget_subaccounts_details)





## OpenAPI

````yaml /specifications/deribit_openapi.json get /private/get_subaccounts_details
openapi: 3.0.0
info:
  title: Deribit API
  version: 2.1.1
servers:
  - url: https://test.deribit.com/api/v2
security: []
tags:
  - name: WebSocket Only
    description: Can only be used over websockets.
  - name: Public
    description: Public methods can be used without authentication.
  - name: Private
    description: >-
      <p>Private methods require authentication. All requests must include a
      valid OAuth2 token.</p>

      <p>A token can be requested using the <a
      href="#public-auth">/public/auth</a> method.</p>

      <p>When using the websockets protocol, the token must be included as a
      parameter <code>access_token</code> in the message. When using REST (HTTP
      GET), the token may also be passed in the <code>Authorization</code>
      header.</p>
  - name: Authentication
  - name: Session Management
  - name: Subscription Management
    description: >-
      Subscription works as [notifications](#notifications), so users will
      automatically (after subscribing) receive messages from the server.
      Overview for each channel response format is described in
      [subscriptions](#subscriptions) section.
  - name: Account Management
  - name: Trading
  - name: Market Data
  - name: Wallet
  - name: Chat
paths:
  /private/get_subaccounts_details:
    get:
      tags:
        - Account Management
        - Private
      description: >+
        Retrieves position details for all subaccounts for a specific currency.
        Returns positions aggregated across all subaccounts, including size,
        average entry price, mark price, and P&L information.


        Optionally include open orders for each subaccount by setting the
        `with_open_orders` parameter to `true`.


        **📖 Related Article:** [Managing
        Subaccounts](https://docs.deribit.com/articles/managing-subaccounts-api)


        **Scope:** `account:read`


        [Try in API
        console](https://test.deribit.com/api_console?method=%2Fprivate%2Fget_subaccounts_details)

      parameters:
        - name: currency
          required: true
          in: query
          schema:
            $ref: '#/components/schemas/currency'
          description: The currency symbol
        - name: with_open_orders
          in: query
          schema:
            type: boolean
          description: 'Optional parameter to ask for open orders list, default: `false`'
          required: false
      requestBody:
        content:
          application/json:
            examples:
              request:
                value:
                  jsonrpc: '2.0'
                  id: 1
                  method: private/get_subaccounts_details
                  params:
                    currency: BTC
                description: JSON-RPC Request Example
        description: JSON-RPC request body
      responses:
        '200':
          $ref: '#/components/responses/PrivateGetSubaccountsDetailsResponse'
        '401':
          $ref: '#/components/responses/ErrorMessageResponse'
components:
  schemas:
    currency:
      enum:
        - BTC
        - ETH
        - USDC
        - USDT
        - EURR
      type: string
      description: Currency, i.e `"BTC"`, `"ETH"`, `"USDC"`
    PrivateGetSubaccountsDetailsResponse:
      properties:
        jsonrpc:
          type: string
          enum:
            - '2.0'
          description: The JSON-RPC version (2.0)
        id:
          type: integer
          description: The id that was sent in the request
        result:
          type: array
          items:
            type: object
            properties:
              uid:
                type: integer
                description: Account/Subaccount identifier
              positions:
                type: array
                items:
                  $ref: '#/components/schemas/position'
              open_orders:
                items:
                  $ref: '#/components/schemas/order'
                type: array
            required:
              - uid
              - positions
      required:
        - jsonrpc
        - result
      type: object
    ErrorMessageResponse:
      properties:
        jsonrpc:
          type: string
          enum:
            - '2.0'
          description: The JSON-RPC version (2.0)
        id:
          type: integer
          description: The id that was sent in the request
        message:
          type: string
        error:
          type: integer
      required:
        - jsonrpc
        - message
        - error
      type: object
    position:
      properties:
        instrument_name:
          $ref: '#/components/schemas/instrument_name'
        kind:
          $ref: '#/components/schemas/kind'
        average_price:
          type: number
          description: Average price of trades that built this position
        direction:
          $ref: '#/components/schemas/position_direction'
        mark_price:
          type: number
          description: Current mark price for position's instrument
        delta:
          type: number
          description: Delta parameter
        gamma:
          type: number
          description: Only for options, Gamma parameter
        vega:
          type: number
          description: Only for options, Vega parameter
        theta:
          type: number
          description: Only for options, Theta parameter
        index_price:
          type: number
          description: Current index price
        initial_margin:
          type: number
          description: Initial margin
        maintenance_margin:
          type: number
          description: Maintenance margin
        settlement_price:
          type: number
          description: >-
            Optional (not added for spot). Last settlement price for position's
            instrument 0 if instrument wasn't settled yet
        total_profit_loss:
          type: number
          description: Profit or loss from position
        floating_profit_loss:
          type: number
          description: Floating profit or loss
        realized_profit_loss:
          type: number
          description: Realized profit or loss
        size:
          type: number
          description: >-
            Position size for futures size in quote currency (e.g. USD), for
            options size is in base currency (e.g. BTC)
        size_currency:
          type: number
          description: Only for futures, position size in base currency
        average_price_usd:
          type: number
          description: Only for options, average price in USD
        floating_profit_loss_usd:
          type: number
          description: Only for options, floating profit or loss in USD
        leverage:
          type: integer
          description: Current available leverage for future position
        realized_funding:
          type: number
          description: >-
            Realized Funding in current session included in session realized
            profit or loss, only for positions of perpetual instruments
        interest_value:
          type: number
          description: Value used to calculate `realized_funding` (perpetual only)
      required:
        - instrument_name
        - kind
        - average_price
        - direction
        - mark_price
        - delta
        - index_price
        - initial_margin
        - maintenance_margin
        - settlement_price
        - total_profit_loss
        - floating_profit_loss
        - realized_profit_loss
        - size
      type: object
    order:
      properties:
        order_id:
          $ref: '#/components/schemas/order_id'
        order_state:
          $ref: '#/components/schemas/order_state'
        order_type:
          $ref: '#/components/schemas/order_type'
        original_order_type:
          $ref: '#/components/schemas/original_order_type'
        time_in_force:
          $ref: '#/components/schemas/time_in_force'
        is_rebalance:
          type: boolean
          description: >-
            Optional (only for spot). `true` if order was automatically created
            during cross-collateral balance restoration
        is_liquidation:
          type: boolean
          description: >-
            Optional (not added for spot). `true` if order was automatically
            created during liquidation
        instrument_name:
          $ref: '#/components/schemas/instrument_name'
        creation_timestamp:
          $ref: '#/components/schemas/timestamp'
        last_update_timestamp:
          $ref: '#/components/schemas/timestamp'
        direction:
          $ref: '#/components/schemas/direction'
        price:
          $ref: '#/components/schemas/open_order_price'
        label:
          $ref: '#/components/schemas/label'
        post_only:
          $ref: '#/components/schemas/post_only'
        reject_post_only:
          $ref: '#/components/schemas/reject_post_only'
        reduce_only:
          $ref: '#/components/schemas/reduce_only'
        api:
          $ref: '#/components/schemas/api'
        web:
          $ref: '#/components/schemas/web'
        mobile:
          $ref: '#/components/schemas/mobile'
        refresh_amount:
          $ref: '#/components/schemas/refresh_amount'
        display_amount:
          $ref: '#/components/schemas/display_amount'
        amount:
          $ref: '#/components/schemas/amount'
        contracts:
          $ref: '#/components/schemas/contracts'
        filled_amount:
          $ref: '#/components/schemas/filled_amount'
        average_price:
          $ref: '#/components/schemas/average_price'
        advanced:
          $ref: '#/components/schemas/advanced'
        implv:
          $ref: '#/components/schemas/implv'
        usd:
          $ref: '#/components/schemas/usd'
        triggered:
          $ref: '#/components/schemas/triggered'
        trigger:
          $ref: '#/components/schemas/trigger'
        trigger_price:
          $ref: '#/components/schemas/trigger_price'
        trigger_offset:
          $ref: '#/components/schemas/trigger_offset'
        trigger_reference_price:
          $ref: '#/components/schemas/trigger_reference_price'
        block_trade:
          $ref: '#/components/schemas/block_trade_order'
        mmp:
          type: boolean
          description: '`true` if the order is a MMP order, otherwise `false`.'
        risk_reducing:
          type: boolean
          description: >-
            `true` if the order is marked by the platform as a risk reducing
            order (can apply only to orders placed by PM users), otherwise
            `false`.
        replaced:
          type: boolean
          description: >-
            `true` if the order was edited (by user or - in case of advanced
            options orders - by pricing engine), otherwise `false`.
        auto_replaced:
          type: boolean
          description: >-
            Options, advanced orders only - `true` if last modification of the
            order was performed by the pricing engine, otherwise `false`.
        quote:
          type: boolean
          description: If order is a quote. Present only if true.
        mmp_group:
          type: string
          description: >-
            Name of the MMP group supplied in the `private/mass_quote` request.
            Only present for quote orders.
        quote_set_id:
          type: string
          description: >-
            Identifier of the QuoteSet supplied in the `private/mass_quote`
            request. Only present for quote orders.
        quote_id:
          type: string
          description: >-
            The same QuoteID as supplied in the `private/mass_quote` request.
            Only present for quote orders.
        trigger_order_id:
          type: string
          example: SLIB-370
          description: >-
            Id of the trigger order that created the order (Only for orders that
            were created by triggered orders).
        app_name:
          type: string
          example: Example Application
          description: >-
            The name of the application that placed the order on behalf of the
            user (optional).
        mmp_cancelled:
          type: boolean
          example: true
          description: '`true` if order was cancelled by mmp trigger (optional)'
        cancel_reason:
          $ref: '#/components/schemas/cancel_reason'
        oto_order_ids:
          type: array
          items:
            $ref: '#/components/schemas/order_id'
            description: Order Id
          description: The Ids of the orders that will be triggered if the order is filled
        trigger_fill_condition:
          $ref: '#/components/schemas/trigger_fill_condition'
        oco_ref:
          $ref: '#/components/schemas/oco_ref'
        primary_order_id:
          $ref: '#/components/schemas/order_id'
          description: ID of the order that triggered this order.
        is_secondary_oto:
          $ref: '#/components/schemas/is_secondary_oto'
        is_primary_otoco:
          type: boolean
          description: >-
            `true` if the order is an order that can trigger an OCO pair,
            otherwise not present.
      required:
        - order_id
        - order_state
        - order_type
        - time_in_force
        - instrument_name
        - creation_timestamp
        - last_update_timestamp
        - direction
        - price
        - label
        - post_only
        - api
      type: object
    instrument_name:
      example: BTC-PERPETUAL
      type: string
      description: Unique instrument identifier
    kind:
      enum:
        - future
        - option
        - spot
        - future_combo
        - option_combo
      type: string
      description: >-
        Instrument kind: `"future"`, `"option"`, `"spot"`, `"future_combo"`,
        `"option_combo"`
    position_direction:
      enum:
        - buy
        - sell
        - zero
      type: string
      description: 'Direction: `buy`, `sell` or `zero`'
    order_id:
      example: ETH-100234
      type: string
      description: Unique order identifier
    order_state:
      enum:
        - open
        - filled
        - rejected
        - cancelled
        - untriggered
        - triggered
      type: string
      description: >-
        Order state: `"open"`, `"filled"`, `"rejected"`, `"cancelled"`,
        `"untriggered"`
    order_type:
      enum:
        - market
        - limit
        - stop_market
        - stop_limit
        - take_market
        - take_limit
        - trailing_stop
      type: string
      description: >-
        Order type: `"limit"`, `"market"`, `"stop_limit"`, `"stop_market"`,
        `"take_limit"`, `"take_market"`, `"trailing_stop"`
    original_order_type:
      enum:
        - market
        - market_limit
      type: string
      description: Original order type. Optional field
    time_in_force:
      enum:
        - good_til_cancelled
        - good_til_day
        - fill_or_kill
        - immediate_or_cancel
      type: string
      description: >-
        Order time in force: `"good_til_cancelled"`, `"good_til_day"`,
        `"fill_or_kill"` or `"immediate_or_cancel"`
    timestamp:
      example: 1536569522277
      type: integer
      description: The timestamp (milliseconds since the Unix epoch)
    direction:
      enum:
        - buy
        - sell
      type: string
      description: 'Direction: `buy`, or `sell`'
    open_order_price:
      oneOf:
        - type: number
        - enum:
            - market_price
          type: string
      description: >-
        Price in base currency or "market_price" in case of open trigger market
        orders
    label:
      type: string
      description: User defined label (up to 64 characters)
    post_only:
      type: boolean
      description: '`true` for post-only orders only'
    reject_post_only:
      type: boolean
      description: >-
        `true` if order has `reject_post_only` flag (field is present only when
        `post_only` is `true`)
    reduce_only:
      type: boolean
      description: Optional (not added for spot). '`true` for reduce-only orders only'
    api:
      type: boolean
      description: '`true` if created with API'
    web:
      type: boolean
      description: '`true` if created via Deribit frontend (optional)'
    mobile:
      type: boolean
      description: >-
        Optional field with value `true` added only when created with Mobile
        Application
    refresh_amount:
      type: number
      description: >-
        The initial display amount of iceberg order. Iceberg order display
        amount will be refreshed to that value after match consuming actual
        display amount. Absent for other types of orders
    display_amount:
      type: number
      description: >-
        The actual display amount of iceberg order. Absent for other types of
        orders.
    amount:
      type: number
      description: >-
        It represents the requested order size. For perpetual and inverse
        futures the amount is in USD units. For options and linear futures it is
        the underlying base currency coin.
    contracts:
      type: number
      description: >-
        It represents the order size in contract units. (Optional, may be absent
        in historical data).
    filled_amount:
      type: number
      description: >-
        Filled amount of the order. For perpetual and futures the filled_amount
        is in USD units, for options - in units or corresponding cryptocurrency
        contracts, e.g., BTC or ETH.
    average_price:
      type: number
      description: Average fill price of the order
    advanced:
      enum:
        - usd
        - implv
      type: string
      description: >
        advanced type: `"usd"` or `"implv"` (Only for options; field is omitted
        if not applicable).
    implv:
      type: number
      description: Implied volatility in percent. (Only if `advanced="implv"`)
    usd:
      type: number
      description: Option price in USD (Only if `advanced="usd"`)
    triggered:
      type: boolean
      description: Whether the trigger order has been triggered
    trigger:
      enum:
        - index_price
        - mark_price
        - last_price
      type: string
      description: >-
        Trigger type (only for trigger orders). Allowed values: `"index_price"`,
        `"mark_price"`, `"last_price"`.
    trigger_price:
      type: number
      description: Trigger price (Only for future trigger orders)
    trigger_offset:
      type: number
      description: >-
        The maximum deviation from the price peak beyond which the order will be
        triggered (Only for trailing trigger orders)
    trigger_reference_price:
      type: number
      description: >-
        The price of the given trigger at the time when the order was placed
        (Only for trailing trigger orders)
    block_trade_order:
      example: true
      type: boolean
      description: '`true` if order made from block_trade trade, added only in that case.'
    cancel_reason:
      enum:
        - user_request
        - autoliquidation
        - cancel_on_disconnect
        - risk_mitigation
        - pme_risk_reduction
        - pme_account_locked
        - position_locked
        - mmp_trigger
        - mmp_config_curtailment
        - edit_post_only_reject
        - oco_other_closed
        - oto_primary_closed
        - settlement
      type: string
      description: >-
        Enumerated reason behind cancel `"user_request"`, `"autoliquidation"`,
        `"cancel_on_disconnect"`, `"risk_mitigation"`, `"pme_risk_reduction"`
        (portfolio margining risk reduction), `"pme_account_locked"` (portfolio
        margining account locked per currency), `"position_locked"`,
        `"mmp_trigger"` (market maker protection), `"mmp_config_curtailment"`
        (market maker configured quantity decreased), `"edit_post_only_reject"`
        (cancelled on edit because of `reject_post_only` setting),
        `"oco_other_closed"` (the oco order linked to this order was closed),
        `"oto_primary_closed"` (the oto primary order that was going to trigger
        this order was cancelled), `"settlement"` (closed because of a
        settlement)
    trigger_fill_condition:
      enum:
        - first_hit
        - complete_fill
        - incremental
      type: string
      description: >-
        <p>The fill condition of the linked order (Only for linked order types),
        default: `first_hit`.</p> <ul> <li>`"first_hit"` - any execution of the
        primary order will fully cancel/place all secondary orders.</li>
        <li>`"complete_fill"` - a complete execution (meaning the primary order
        no longer exists) will cancel/place the secondary orders.</li>
        <li>`"incremental"` - any fill of the primary order will cause
        proportional partial cancellation/placement of the secondary order. The
        amount that will be subtracted/added to the secondary order will be
        rounded down to the contract size.</li> </ul>
    oco_ref:
      type: string
      description: Unique reference that identifies a one_cancels_others (OCO) pair.
    is_secondary_oto:
      type: boolean
      description: >-
        `true` if the order is an order that can be triggered by another order,
        otherwise not present.
  responses:
    PrivateGetSubaccountsDetailsResponse:
      content:
        application/json:
          schema:
            $ref: '#/components/schemas/PrivateGetSubaccountsDetailsResponse'
          examples:
            response:
              value:
                jsonrpc: '2.0'
                result:
                  - uid: 3
                    positions:
                      - total_profit_loss: -0.000118183
                        size_currency: 0.004152776
                        size: 200
                        settlement_price: 48150.36
                        realized_profit_loss: -8.79e-7
                        realized_funding: -8.8e-7
                        open_orders_margin: 0
                        mark_price: 48160.55
                        maintenance_margin: 0.000089286
                        leverage: 34
                        kind: future
                        instrument_name: BTC-PERPETUAL
                        initial_margin: 0.000122508
                        index_price: 47897.12
                        floating_profit_loss: -0.00003451
                        estimated_liquidation_price: 2.33
                        direction: buy
                        delta: 0.004152776
                        average_price: 49571.3
                  - uid: 10
                    positions:
                      - total_profit_loss: 0.000037333
                        size_currency: -0.001308984
                        size: -60
                        settlement_price: 47886.98
                        realized_profit_loss: 0
                        open_orders_margin: 0
                        mark_price: 45837.07
                        maintenance_margin: 0.000028143
                        leverage: 34
                        kind: future
                        instrument_name: BTC-3SEP21
                        initial_margin: 0.000038615
                        index_price: 47897.12
                        floating_profit_loss: 0.000037333
                        estimated_liquidation_price: null
                        direction: sell
                        delta: -0.001308984
                        average_price: 47182.76
              description: Response example
      description: Success response
    ErrorMessageResponse:
      content:
        application/json:
          schema:
            $ref: '#/components/schemas/ErrorMessageResponse'
      description: Success response

````

> ## Documentation Index
> Fetch the complete documentation index at: https://docs.deribit.com/llms.txt
> Use this file to discover all available pages before exploring further.

<AgentInstructions>

## Submitting Feedback

If you encounter incorrect, outdated, or confusing documentation on this page, submit feedback:

POST https://docs.deribit.com/feedback

```json
{
  "path": "/api-reference/account-management/private-get_transaction_log",
  "feedback": "Description of the issue"
}
```

Only submit feedback when you have something specific and actionable to report.

</AgentInstructions>

# private/get_transaction_log

> Retrieves a detailed transaction log for the authenticated account. The log includes all account activities such as trades, deposits, withdrawals, transfers, fees, and other balance-affecting operations.

Results can be filtered by currency, time range, and transaction type. Use the `continuation` parameter for pagination when retrieving large transaction histories. To retrieve transactions for a specific subaccount, use the `subaccount_id` parameter.

**History Limit:** This API method has **no time limit** - users can query transaction history back to account creation. Note that the CSV export feature available on the website is year-limited to 2023. 

**Note - This method has distinct API rate limiting requirements:** Sustained rate: 1 request/second. For more information, see [Rate Limits](https://support.deribit.com/hc/en-us/articles/25944617523357-Rate-Limits).

**📖 Related Support Article:** [Transaction log](https://support.deribit.com/hc/en-us/articles/25944587269021-Transaction-log)

**Scope:** `account:read`

[Try in API console](https://test.deribit.com/api_console?method=%2Fprivate%2Fget_transaction_log)





## OpenAPI

````yaml /specifications/deribit_openapi.json get /private/get_transaction_log
openapi: 3.0.0
info:
  title: Deribit API
  version: 2.1.1
servers:
  - url: https://test.deribit.com/api/v2
security: []
tags:
  - name: WebSocket Only
    description: Can only be used over websockets.
  - name: Public
    description: Public methods can be used without authentication.
  - name: Private
    description: >-
      <p>Private methods require authentication. All requests must include a
      valid OAuth2 token.</p>

      <p>A token can be requested using the <a
      href="#public-auth">/public/auth</a> method.</p>

      <p>When using the websockets protocol, the token must be included as a
      parameter <code>access_token</code> in the message. When using REST (HTTP
      GET), the token may also be passed in the <code>Authorization</code>
      header.</p>
  - name: Authentication
  - name: Session Management
  - name: Subscription Management
    description: >-
      Subscription works as [notifications](#notifications), so users will
      automatically (after subscribing) receive messages from the server.
      Overview for each channel response format is described in
      [subscriptions](#subscriptions) section.
  - name: Account Management
  - name: Trading
  - name: Market Data
  - name: Wallet
  - name: Chat
paths:
  /private/get_transaction_log:
    get:
      tags:
        - Account Management
        - Private
      description: >+
        Retrieves a detailed transaction log for the authenticated account. The
        log includes all account activities such as trades, deposits,
        withdrawals, transfers, fees, and other balance-affecting operations.


        Results can be filtered by currency, time range, and transaction type.
        Use the `continuation` parameter for pagination when retrieving large
        transaction histories. To retrieve transactions for a specific
        subaccount, use the `subaccount_id` parameter.


        **History Limit:** This API method has **no time limit** - users can
        query transaction history back to account creation. Note that the CSV
        export feature available on the website is year-limited to 2023. 


        **Note - This method has distinct API rate limiting requirements:**
        Sustained rate: 1 request/second. For more information, see [Rate
        Limits](https://support.deribit.com/hc/en-us/articles/25944617523357-Rate-Limits).


        **📖 Related Support Article:** [Transaction
        log](https://support.deribit.com/hc/en-us/articles/25944587269021-Transaction-log)


        **Scope:** `account:read`


        [Try in API
        console](https://test.deribit.com/api_console?method=%2Fprivate%2Fget_transaction_log)

      parameters:
        - name: currency
          required: true
          in: query
          schema:
            $ref: '#/components/schemas/wallet_currency'
          description: The currency symbol
        - name: start_timestamp
          required: true
          in: query
          schema:
            $ref: '#/components/schemas/timestamp'
          description: >-
            The earliest timestamp to return result from (milliseconds since the
            UNIX epoch)
        - name: end_timestamp
          required: true
          in: query
          schema:
            $ref: '#/components/schemas/timestamp'
          description: >-
            The most recent timestamp to return result from (milliseconds since
            the UNIX epoch)
        - name: query
          in: query
          schema:
            type: string
            example: settlement
          required: false
          description: >-
            The following keywords can be used to filter the results: `trade`,
            `maker`, `taker`, `open`, `close`, `liquidation`, `buy`, `sell`,
            `withdrawal`, `delivery`, `settlement`, `deposit`, `transfer`,
            `option`, `future`, `correction`, `block_trade`, `swap`. Plus
            withdrawal or transfer addresses
        - name: count
          in: query
          required: false
          schema:
            type: integer
            maximum: 250
            minimum: 1
          description: >-
            Count of transaction log entries returned, default - `100`, maximum
            - `250`
        - name: subaccount_id
          in: query
          required: false
          schema:
            type: integer
            example: 9
          description: Id of a subaccount
        - name: continuation
          in: query
          required: false
          schema:
            type: integer
            example: 429946
          description: Continuation token for pagination
      requestBody:
        content:
          application/json:
            examples:
              request:
                value:
                  jsonrpc: '2.0'
                  id: 4
                  method: private/get_transaction_log
                  params:
                    currency: BTC
                    start_timestamp: '1613657734000'
                    end_timestamp: '1613660407000'
                    count: 5
                description: JSON-RPC Request Example
        description: JSON-RPC request body
      responses:
        '200':
          $ref: '#/components/responses/PrivateGetTransactionLogResponse'
components:
  schemas:
    wallet_currency:
      enum:
        - BTC
        - ETH
        - STETH
        - ETHW
        - USDC
        - USDT
        - EURR
        - SOL
        - XRP
        - USYC
        - PAXG
        - BNB
        - USDE
      type: string
      description: Currency, i.e `"BTC"`, `"ETH"`, `"USDC"`
    timestamp:
      example: 1536569522277
      type: integer
      description: The timestamp (milliseconds since the Unix epoch)
    PrivateGetTransactionLogResponse:
      properties:
        jsonrpc:
          type: string
          enum:
            - '2.0'
          description: The JSON-RPC version (2.0)
        id:
          type: integer
          description: The id that was sent in the request
        result:
          type: object
          properties:
            continuation:
              $ref: '#/components/schemas/continuation_with_null'
            logs:
              type: array
              items:
                $ref: '#/components/schemas/transaction_log'
          required:
            - continuation
            - logs
      required:
        - jsonrpc
        - result
      type: object
    continuation_with_null:
      example: 429946
      type: integer
      description: Continuation token for pagination. `NULL` when no continuation.
    transaction_log:
      properties:
        id:
          $ref: '#/components/schemas/id'
        currency:
          $ref: '#/components/schemas/currency'
        timestamp:
          $ref: '#/components/schemas/timestamp'
        user_id:
          $ref: '#/components/schemas/user_id'
        username:
          $ref: '#/components/schemas/username'
        commission:
          $ref: '#/components/schemas/commission'
        cashflow:
          type: number
          description: >-
            For futures and perpetual contracts: Realized session PNL (since
            last settlement). For options: the amount paid or received for the
            options traded.
        balance:
          type: number
          description: Cash balance after the transaction
        change:
          type: number
          description: >-
            Change in cash balance. For trades: fees and options premium
            paid/received. For settlement: Futures session PNL and perpetual
            session funding.
        user_seq:
          type: integer
          description: Sequential identifier of user transaction
        type:
          type: string
          description: >-
            Transaction category/type. The most common are: `trade`, `deposit`,
            `withdrawal`, `settlement`, `delivery`, `transfer`, `swap`,
            `correction`. New types can be added any time in the future
        info:
          type: object
          description: >-
            Additional information regarding transaction. Strongly dependent on
            the log entry type
        equity:
          type: number
          description: Updated equity value after the transaction
        mark_price:
          type: number
          description: Market price during the trade
        settlement_price:
          type: number
          description: The settlement price for the instrument during the delivery
        index_price:
          type: number
          description: The index price for the instrument during the delivery
        instrument_name:
          $ref: '#/components/schemas/instrument_name'
        position:
          type: number
          description: Updated position size after the transaction
        side:
          type: string
          description: >-
            One of: `short` or `long` in case of settlements, `close sell` or
            `close buy` in case of deliveries, `open sell`, `open buy`, `close
            sell`, `close buy` in case of trades
        amount:
          type: number
          description: >-
            It represents the requested order size. For perpetual and inverse
            futures the amount is in USD units. For options and linear futures
            it is the underlying base currency coin.
        price:
          type: number
          description: Settlement/delivery price or the price level of the traded contracts
        price_currency:
          type: string
          description: Currency symbol associated with the `price` field value
        trade_id:
          $ref: '#/components/schemas/trade_id'
        order_id:
          $ref: '#/components/schemas/order_id'
        user_role:
          $ref: '#/components/schemas/role'
        fee_role:
          $ref: '#/components/schemas/fee_role'
        profit_as_cashflow:
          type: boolean
          description: >-
            Indicator informing whether the cashflow is waiting for settlement
            or not
        interest_pl:
          type: number
          description: >-
            Actual funding rate of trades and settlements on perpetual
            instruments
        block_rfq_id:
          type: integer
          description: ID of the Block RFQ - when trade was part of the Block RFQ
        ip:
          type: string
          description: The IP address from which the trade was initiated
        session_rpl:
          $ref: '#/components/schemas/rpl'
        session_upl:
          $ref: '#/components/schemas/upl'
        total_interest_pl:
          type: number
          description: Total session funding rate
        contracts:
          $ref: '#/components/schemas/contracts'
      required:
        - id
        - currency
        - timestamp
        - user_id
        - commission
        - cashflow
        - balance
        - change
        - user_seq
        - type
      type: object
    id:
      example: 5967413
      type: integer
      description: Unique identifier
    currency:
      enum:
        - BTC
        - ETH
        - USDC
        - USDT
        - EURR
      type: string
      description: Currency, i.e `"BTC"`, `"ETH"`, `"USDC"`
    user_id:
      example: 57874
      type: integer
      description: Unique user identifier
    username:
      example: MrTrader
      type: string
      description: System name or user defined subaccount alias
    commission:
      type: number
      description: Commission paid so far (in base currency)
    instrument_name:
      example: BTC-PERPETUAL
      type: string
      description: Unique instrument identifier
    trade_id:
      type: string
      description: Unique (per currency) trade identifier
    order_id:
      example: ETH-100234
      type: string
      description: Unique order identifier
    role:
      enum:
        - maker
        - taker
      type: string
      description: 'Trade role of the user: `maker` or `taker`'
    fee_role:
      enum:
        - maker
        - taker
      type: string
      description: >-
        Fee role of the user: `maker` or `taker`. Can be different from trade
        role of the user when iceberg order was involved in matching.
    rpl:
      example: 0.1
      type: number
      description: Session realized profit and loss
    upl:
      example: 0.846863
      type: number
      description: Session unrealized profit and loss
    contracts:
      type: number
      description: >-
        It represents the order size in contract units. (Optional, may be absent
        in historical data).
  responses:
    PrivateGetTransactionLogResponse:
      content:
        application/json:
          schema:
            $ref: '#/components/schemas/PrivateGetTransactionLogResponse'
          examples:
            response:
              value:
                jsonrpc: '2.0'
                id: 4
                result:
                  logs:
                    - username: TestUser
                      user_seq: 6009
                      user_id: 7
                      type: transfer
                      trade_id: null
                      timestamp: 1613659830333
                      side: '-'
                      price: null
                      position: null
                      order_id: null
                      interest_pl: null
                      instrument_name: null
                      info:
                        transfer_type: subaccount
                        other_user_id: 27
                        other_user: Subaccount
                      id: 61312
                      equity: 3000.9275869
                      currency: BTC
                      commission: 0
                      change: -2.5
                      cashflow: -2.5
                      balance: 3001.22270418
                    - username: TestUser
                      user_seq: 6008
                      user_id: 7
                      type: settlement
                      trade_id: null
                      total_interest_pl: 0.00001243
                      timestamp: 1613659544153
                      side: long
                      session_upl: 0.00220172
                      session_rpl: -0.00004467
                      price_currency: USD
                      price: 51807.07
                      position: 1520
                      order_id: null
                      interest_pl: 0.00000993
                      instrument_name: BTC-PERPETUAL
                      info:
                        settlement_price: 51807
                        floating_pl: 0.00220172
                      id: 61311
                      equity: 3003.42821428
                      currency: BTC
                      commission: null
                      change: 0.00215706
                      cashflow: 0.00215706
                      balance: 3003.72270418
                      amount: 1520
                    - username: TestUser
                      user_seq: 6007
                      user_id: 7
                      type: deposit
                      trade_id: null
                      timestamp: 1613657828414
                      side: '-'
                      price: null
                      position: null
                      order_id: null
                      interest_pl: null
                      instrument_name: null
                      info:
                        transaction: >-
                          de6eba075855f32c9510f338d3ca0900376cedcb9f7b142caccfbdc292d3237e
                        deposit_type: wallet
                        addr: 2N8prMvpZHr8aYqodX3S4yhz5wMxjY8La3p
                      id: 61291
                      equity: 3003.4876111
                      currency: BTC
                      commission: 0
                      change: 0.65
                      cashflow: 0.65
                      balance: 3003.72054712
                    - username: TestUser
                      user_seq: 6006
                      user_role: maker
                      user_id: 7
                      type: trade
                      ip: 11.222.33.44
                      trade_id: '28349'
                      timestamp: 1613657734620
                      side: open buy
                      profit_as_cashflow: false
                      price_currency: BTC
                      price: 0.1537
                      position: 0.7
                      order_id: '67546'
                      mark_price: 0.04884653215049635
                      interest_pl: 0
                      instrument_name: BTC-19FEB21-49200-C
                      info: 'Source: api'
                      id: 61289
                      equity: 3002.83270455
                      currency: BTC
                      commission: 0
                      change: -0.10759
                      cashflow: -0.10759
                      balance: 3003.07054712
                      amount: 0.7
                    - username: TestUser
                      user_seq: 6005
                      user_role: maker
                      user_id: 7
                      type: trade
                      trade_id: '28349'
                      timestamp: 1613657734620
                      side: close buy
                      profit_as_cashflow: false
                      price_currency: BTC
                      price: 0.1537
                      position: 0
                      order_id: '67546'
                      mark_price: 0.04884653215049635
                      interest_pl: 0
                      instrument_name: BTC-19FEB21-49200-C
                      info: 'Source: api'
                      id: 61288
                      equity: 3002.83270455
                      currency: BTC
                      commission: 0
                      change: -0.04611
                      cashflow: -0.04611
                      balance: 3003.17813712
                      amount: 0.3
                  continuation: 61282
              description: Response example
      description: Success response

````

> ## Documentation Index
> Fetch the complete documentation index at: https://docs.deribit.com/llms.txt
> Use this file to discover all available pages before exploring further.

<AgentInstructions>

## Submitting Feedback

If you encounter incorrect, outdated, or confusing documentation on this page, submit feedback:

POST https://docs.deribit.com/feedback

```json
{
  "path": "/api-reference/account-management/private-get_user_locks",
  "feedback": "Description of the issue"
}
```

Only submit feedback when you have something specific and actionable to report.

</AgentInstructions>

# private/get_user_locks

> Retrieves information about any account locks or restrictions currently active on the authenticated account. Account locks may be applied for security reasons, compliance requirements, or administrative purposes.

The response includes details about the type of lock, reason, and duration (if applicable). Some locks may prevent trading, withdrawals, or other account operations.

**📖 Related Support Article:** [Emergency locking an account](https://support.deribit.com/hc/en-us/articles/25944602715805-Emergency-locking-an-account)

**Scope:** `account:read`

[Try in API console](https://test.deribit.com/api_console?method=%2Fprivate%2Fget_user_locks)





## OpenAPI

````yaml /specifications/deribit_openapi.json get /private/get_user_locks
openapi: 3.0.0
info:
  title: Deribit API
  version: 2.1.1
servers:
  - url: https://test.deribit.com/api/v2
security: []
tags:
  - name: WebSocket Only
    description: Can only be used over websockets.
  - name: Public
    description: Public methods can be used without authentication.
  - name: Private
    description: >-
      <p>Private methods require authentication. All requests must include a
      valid OAuth2 token.</p>

      <p>A token can be requested using the <a
      href="#public-auth">/public/auth</a> method.</p>

      <p>When using the websockets protocol, the token must be included as a
      parameter <code>access_token</code> in the message. When using REST (HTTP
      GET), the token may also be passed in the <code>Authorization</code>
      header.</p>
  - name: Authentication
  - name: Session Management
  - name: Subscription Management
    description: >-
      Subscription works as [notifications](#notifications), so users will
      automatically (after subscribing) receive messages from the server.
      Overview for each channel response format is described in
      [subscriptions](#subscriptions) section.
  - name: Account Management
  - name: Trading
  - name: Market Data
  - name: Wallet
  - name: Chat
paths:
  /private/get_user_locks:
    get:
      tags:
        - Account Management
        - Private
      description: >+
        Retrieves information about any account locks or restrictions currently
        active on the authenticated account. Account locks may be applied for
        security reasons, compliance requirements, or administrative purposes.


        The response includes details about the type of lock, reason, and
        duration (if applicable). Some locks may prevent trading, withdrawals,
        or other account operations.


        **📖 Related Support Article:** [Emergency locking an
        account](https://support.deribit.com/hc/en-us/articles/25944602715805-Emergency-locking-an-account)


        **Scope:** `account:read`


        [Try in API
        console](https://test.deribit.com/api_console?method=%2Fprivate%2Fget_user_locks)

      parameters: []
      requestBody:
        content:
          application/json:
            examples:
              request:
                value:
                  jsonrpc: '2.0'
                  id: 74
                  method: private/get_user_locks
                  params: {}
                description: JSON-RPC Request Example
        description: JSON-RPC request body
      responses:
        '200':
          $ref: '#/components/responses/PrivateGetUserLocksResponse'
components:
  responses:
    PrivateGetUserLocksResponse:
      content:
        application/json:
          schema:
            $ref: '#/components/schemas/PrivateGetUserLocksResponse'
          examples:
            response:
              value:
                id: 74
                result:
                  - message: locked in one currency
                    locked: true
                    currency: BTC
                  - locked: false
                    currency: ETH
                  - locked: false
                    currency: USDC
                  - locked: false
                    currency: SOL
              description: Response example
      description: Success response
  schemas:
    PrivateGetUserLocksResponse:
      properties:
        jsonrpc:
          type: string
          enum:
            - '2.0'
          description: The JSON-RPC version (2.0)
        id:
          type: integer
          description: The id that was sent in the request
        result:
          items:
            type: object
            properties:
              currency:
                $ref: '#/components/schemas/currency'
              enabled:
                type: boolean
                description: Value is set to 'true' when user account is locked in currency
              message:
                type: string
                description: Optional information for user why his account is locked
            required:
              - currency
              - enabled
          type: array
      required:
        - jsonrpc
        - result
      type: object
    currency:
      enum:
        - BTC
        - ETH
        - USDC
        - USDT
        - EURR
      type: string
      description: Currency, i.e `"BTC"`, `"ETH"`, `"USDC"`

````

> ## Documentation Index
> Fetch the complete documentation index at: https://docs.deribit.com/llms.txt
> Use this file to discover all available pages before exploring further.

<AgentInstructions>

## Submitting Feedback

If you encounter incorrect, outdated, or confusing documentation on this page, submit feedback:

POST https://docs.deribit.com/feedback

```json
{
  "path": "/api-reference/account-management/private-list_api_keys",
  "feedback": "Description of the issue"
}
```

Only submit feedback when you have something specific and actionable to report.

</AgentInstructions>

# private/list_api_keys

> Retrieves a list of all API keys associated with the authenticated account. The response includes key details such as ID, name, scope, creation date, last usage, and status (enabled/disabled), but does not include the secret keys for security reasons.

Use this method to review and manage your API keys, check their permissions, and monitor their usage.

**[TFA required](https://docs.deribit.com/articles/security-keys)**

**📖 Related Article:** [Creating new API key on Deribit](https://docs.deribit.com/articles/creating-api-key)

**Scope:** `account:read`

[Try in API console](https://test.deribit.com/api_console?method=%2Fprivate%2Flist_api_keys)





## OpenAPI

````yaml /specifications/deribit_openapi.json get /private/list_api_keys
openapi: 3.0.0
info:
  title: Deribit API
  version: 2.1.1
servers:
  - url: https://test.deribit.com/api/v2
security: []
tags:
  - name: WebSocket Only
    description: Can only be used over websockets.
  - name: Public
    description: Public methods can be used without authentication.
  - name: Private
    description: >-
      <p>Private methods require authentication. All requests must include a
      valid OAuth2 token.</p>

      <p>A token can be requested using the <a
      href="#public-auth">/public/auth</a> method.</p>

      <p>When using the websockets protocol, the token must be included as a
      parameter <code>access_token</code> in the message. When using REST (HTTP
      GET), the token may also be passed in the <code>Authorization</code>
      header.</p>
  - name: Authentication
  - name: Session Management
  - name: Subscription Management
    description: >-
      Subscription works as [notifications](#notifications), so users will
      automatically (after subscribing) receive messages from the server.
      Overview for each channel response format is described in
      [subscriptions](#subscriptions) section.
  - name: Account Management
  - name: Trading
  - name: Market Data
  - name: Wallet
  - name: Chat
paths:
  /private/list_api_keys:
    get:
      tags:
        - Account Management
        - Private
      description: >+
        Retrieves a list of all API keys associated with the authenticated
        account. The response includes key details such as ID, name, scope,
        creation date, last usage, and status (enabled/disabled), but does not
        include the secret keys for security reasons.


        Use this method to review and manage your API keys, check their
        permissions, and monitor their usage.


        **[TFA required](https://docs.deribit.com/articles/security-keys)**


        **📖 Related Article:** [Creating new API key on
        Deribit](https://docs.deribit.com/articles/creating-api-key)


        **Scope:** `account:read`


        [Try in API
        console](https://test.deribit.com/api_console?method=%2Fprivate%2Flist_api_keys)

      parameters: []
      responses:
        '200':
          $ref: '#/components/responses/PublicListApiKeysResponse'
components:
  responses:
    PublicListApiKeysResponse:
      content:
        application/json:
          schema:
            $ref: '#/components/schemas/PublicListApiKeysResponse'
          examples:
            response:
              value:
                jsonrpc: '2.0'
                id: 2553
                result:
                  - timestamp: 1560236001108
                    max_scope: account:read block_trade:read trade:read_write wallet:read
                    id: 1
                    enabled: false
                    default: false
                    client_secret: SjM57m1T2CfXZ4vZ76X1APjqRlJdtzHI8IwVXoQnfoM
                    client_id: TiA4AyLPq3
                    name: ''
                    enabled_features: []
                  - timestamp: 1560236287708
                    max_scope: >-
                      account:read_write block_trade:read_write trade:read_write
                      wallet:read_write
                    id: 2
                    enabled: true
                    default: true
                    client_secret: mwNOvbUVyQczytQ5IVM8CbzmgqNJ81WvLKfu6MXcJPs
                    client_id: aD-KFx-H
                    name: ''
                    enabled_features: []
              description: Response example
      description: Success response
  schemas:
    PublicListApiKeysResponse:
      properties:
        jsonrpc:
          type: string
          enum:
            - '2.0'
          description: The JSON-RPC version (2.0)
        id:
          type: integer
          description: The id that was sent in the request
        result:
          type: array
          items:
            $ref: '#/components/schemas/api_key'
      required:
        - jsonrpc
        - result
      type: object
    api_key:
      properties:
        id:
          $ref: '#/components/schemas/key_id'
        timestamp:
          $ref: '#/components/schemas/timestamp'
        client_id:
          $ref: '#/components/schemas/client_id'
        client_secret:
          $ref: '#/components/schemas/client_secret'
        public_key:
          $ref: '#/components/schemas/public_key'
        max_scope:
          $ref: '#/components/schemas/max_scope'
        enabled:
          $ref: '#/components/schemas/api_key_enabled'
        default:
          $ref: '#/components/schemas/api_key_default'
        name:
          $ref: '#/components/schemas/api_key_name'
        enabled_features:
          $ref: '#/components/schemas/api_key_features'
        ip_whitelist:
          type: array
          description: List of IP addresses whitelisted for a selected key
      required:
        - id
        - timestamp
        - client_id
        - client_secret
        - max_scope
        - default
      type: object
    key_id:
      example: 1
      type: integer
      description: Key identifier
    timestamp:
      example: 1536569522277
      type: integer
      description: The timestamp (milliseconds since the Unix epoch)
    client_id:
      example: IY2D68DS
      type: string
      description: Client identifier used for authentication
    client_secret:
      example: P9Z_c73KaBPwpoTVfsXzehAhjhdJn5kM7Zlz_hhDhE8
      type: string
      description: Client secret or MD5 fingerprint of public key used for authentication
    public_key:
      example: >-
        -----BEGIN PUBLIC KEY-----
        MCowBQYDK2VwAyEApajFN0CSwIaaiIRPiFbiYYvpsLQLSccSLLsKPe984sc= -----END
        PUBLIC KEY-----
      type: string
      description: >-
        PEM encoded public key (Ed25519/RSA) used for asymmetric signatures
        (optional)
    max_scope:
      items:
        type: string
      example:
        - account:read
        - trade:read
        - block_trade:read_write
        - wallet:none
      type: array
      description: >
        Describes maximal access for tokens generated with given key. If scope
        is not provided, its value is set as none.


        **📖 Related Article:** [Access
        Scope](https://docs.deribit.com/articles/access-scope)
    api_key_enabled:
      example: true
      type: boolean
      description: Informs whether api key is enabled and can be used for authentication
    api_key_default:
      example: false
      type: boolean
      description: >-
        Informs whether this api key is default (field is deprecated and will be
        removed in the future)
    api_key_name:
      example: TestName
      type: string
      description: Api key name that can be displayed in transaction log
    api_key_features:
      items:
        type: string
      type: array
      description: >-
        List of enabled advanced on-key features.<br><br><b>Available
        options:</b><br>- <code>restricted_block_trades</code>: Limit the
        block_trade read the scope of the API key to block trades that have been
        made using this specific API key<br>- <code>block_trade_approval</code>:
        Block trades created using this API key require additional user
        approval. Methods that use <code>block_rfq</code> scope are not affected
        by Block Trade approval feature

````

> ## Documentation Index
> Fetch the complete documentation index at: https://docs.deribit.com/llms.txt
> Use this file to discover all available pages before exploring further.

<AgentInstructions>

## Submitting Feedback

If you encounter incorrect, outdated, or confusing documentation on this page, submit feedback:

POST https://docs.deribit.com/feedback

```json
{
  "path": "/api-reference/account-management/private-list_custody_accounts",
  "feedback": "Description of the issue"
}
```

Only submit feedback when you have something specific and actionable to report.

</AgentInstructions>

# private/list_custody_accounts

> Retrieves a list of all custody accounts associated with the authenticated account for a specific currency. Custody accounts are used for clients who require segregated custody of their assets.

The response includes custody account details such as account name, status, balances, and configuration settings.

**📖 Related Support Article:** [Custody Options](https://support.deribit.com/hc/en-us/articles/26533163120413-Custody-Options)

[Try in API console](https://test.deribit.com/api_console?method=%2Fprivate%2Flist_custody_accounts)





## OpenAPI

````yaml /specifications/deribit_openapi.json get /private/list_custody_accounts
openapi: 3.0.0
info:
  title: Deribit API
  version: 2.1.1
servers:
  - url: https://test.deribit.com/api/v2
security: []
tags:
  - name: WebSocket Only
    description: Can only be used over websockets.
  - name: Public
    description: Public methods can be used without authentication.
  - name: Private
    description: >-
      <p>Private methods require authentication. All requests must include a
      valid OAuth2 token.</p>

      <p>A token can be requested using the <a
      href="#public-auth">/public/auth</a> method.</p>

      <p>When using the websockets protocol, the token must be included as a
      parameter <code>access_token</code> in the message. When using REST (HTTP
      GET), the token may also be passed in the <code>Authorization</code>
      header.</p>
  - name: Authentication
  - name: Session Management
  - name: Subscription Management
    description: >-
      Subscription works as [notifications](#notifications), so users will
      automatically (after subscribing) receive messages from the server.
      Overview for each channel response format is described in
      [subscriptions](#subscriptions) section.
  - name: Account Management
  - name: Trading
  - name: Market Data
  - name: Wallet
  - name: Chat
paths:
  /private/list_custody_accounts:
    get:
      tags:
        - Account Management
        - Private
      description: >+
        Retrieves a list of all custody accounts associated with the
        authenticated account for a specific currency. Custody accounts are used
        for clients who require segregated custody of their assets.


        The response includes custody account details such as account name,
        status, balances, and configuration settings.


        **📖 Related Support Article:** [Custody
        Options](https://support.deribit.com/hc/en-us/articles/26533163120413-Custody-Options)


        [Try in API
        console](https://test.deribit.com/api_console?method=%2Fprivate%2Flist_custody_accounts)

      parameters:
        - name: currency
          required: true
          in: query
          schema:
            $ref: '#/components/schemas/currency'
          description: The currency symbol
      requestBody:
        content:
          application/json:
            examples:
              request:
                value:
                  jsonrpc: '2.0'
                  id: 2515
                  method: private/list_custody_accounts
                  params:
                    currency: BTC
                description: JSON-RPC Request Example
        description: JSON-RPC request body
      responses:
        '200':
          $ref: '#/components/responses/GetlistCustodyAccounts200response'
components:
  schemas:
    currency:
      enum:
        - BTC
        - ETH
        - USDC
        - USDT
        - EURR
      type: string
      description: Currency, i.e `"BTC"`, `"ETH"`, `"USDC"`
    GetlistCustodyAccounts200response:
      allOf:
        - $ref: '#/components/schemas/ErrorResponse'
        - properties:
            result:
              type: array
              items:
                $ref: '#/components/schemas/custody_account'
    ErrorResponse:
      type: object
      properties:
        jsonrpc:
          type: string
          enum:
            - '2.0'
        error:
          type: object
          properties:
            code:
              type: integer
              description: Error code
            message:
              type: string
              description: Error message
          required:
            - code
            - message
      required:
        - jsonrpc
        - error
      description: Generic error response for broken references
    custody_account:
      properties:
        currency:
          $ref: '#/components/schemas/currency'
        name:
          $ref: '#/components/schemas/custody_name'
        balance:
          $ref: '#/components/schemas/currency_amount'
          description: Balance available on custody account
        pending_withdrawal_balance:
          $ref: '#/components/schemas/currency_amount'
          description: Pending balance transferred from trading account to custody account
        auto_deposit:
          type: boolean
          description: >-
            When set to 'true' all new funds added to custody balance will be
            automatically transferred to trading balance
        client_id:
          type: string
          description: >-
            API key 'client id' used to reserve/release funds in custody
            platform, requires scope 'custody:read_write'
        external_id:
          $ref: '#/components/schemas/external_id'
        withdrawal_address:
          type: string
          description: Address that is used for withdrawals
        withdrawal_address_change:
          type: number
          description: >-
            UNIX timestamp after when new withdrawal address will be used for
            withdrawals
        pending_withdrawal_addres:
          type: string
          description: >-
            New withdrawal address that will be used after
            'withdrawal_address_change'
        deposit_address:
          type: string
          description: Address that can be used for deposits
      required:
        - currency
        - name
        - pending_withdrawal_balance
      type: object
      description: Custody account
    custody_name:
      enum:
        - copper
        - cobo
      type: string
      description: Custody name
    currency_amount:
      example: 1
      type: number
      description: Amount of funds in given currency
    external_id:
      example: 4b4cee3d-2dfc-4402-a9ae-f8f9785fa966
      type: string
      description: User ID in external systems
  responses:
    GetlistCustodyAccounts200response:
      content:
        application/json:
          schema:
            $ref: '#/components/schemas/GetlistCustodyAccounts200response'
          examples:
            jsonObject:
              value:
                jsonrpc: '2.0'
                id: 2515
                result:
                  - name: copper
                    currency: BTC
                    client_id: 4KVcFrrzmXBR
                    external_id: 24f97d44-1d72-4641-8527-811268a0bdd3
                    balance: 0.5
                    withdrawals_require_security_key: false
                    pending_withdrawal_balance: 0.1
                    auto_deposit: false
            response:
              value:
                jsonrpc: '2.0'
                id: 2515
                result:
                  - name: copper
                    currency: BTC
                    client_id: 4KVcFrrzmXBR
                    external_id: 24f97d44-1d72-4641-8527-811268a0bdd3
                    balance: 0.5
                    withdrawals_require_security_key: false
                    pending_withdrawal_balance: 0.1
                    auto_deposit: false
              description: Response example
      description: Success response

````

> ## Documentation Index
> Fetch the complete documentation index at: https://docs.deribit.com/llms.txt
> Use this file to discover all available pages before exploring further.

<AgentInstructions>

## Submitting Feedback

If you encounter incorrect, outdated, or confusing documentation on this page, submit feedback:

POST https://docs.deribit.com/feedback

```json
{
  "path": "/api-reference/account-management/private-simulate",
  "feedback": "Description of the issue"
}
```

Only submit feedback when you have something specific and actionable to report.

</AgentInstructions>

# private/pme/simulate

> Calculates the Extended Risk Matrix (ERM) and detailed margin information for Portfolio Margin accounts. The ERM provides a comprehensive view of portfolio risk across different scenarios and market conditions.

You can calculate the ERM for a specific currency or for the entire Cross-Collateral portfolio. The response includes margin requirements, risk metrics, and scenario analysis that helps assess portfolio risk under various market conditions.

Use this method to understand margin requirements and risk exposure before making trading decisions in a Portfolio Margin account.

**📖 Related Article:** [Portfolio Margin](https://support.deribit.com/hc/en-us/articles/25944756247837-Portfolio-Margin)

**Scope:** `account:read`

[Try in API console](https://test.deribit.com/api_console?method=%2Fprivate%2Fpme%2Fsimulate)





## OpenAPI

````yaml /specifications/deribit_openapi.json get /private/pme/simulate
openapi: 3.0.0
info:
  title: Deribit API
  version: 2.1.1
servers:
  - url: https://test.deribit.com/api/v2
security: []
tags:
  - name: WebSocket Only
    description: Can only be used over websockets.
  - name: Public
    description: Public methods can be used without authentication.
  - name: Private
    description: >-
      <p>Private methods require authentication. All requests must include a
      valid OAuth2 token.</p>

      <p>A token can be requested using the <a
      href="#public-auth">/public/auth</a> method.</p>

      <p>When using the websockets protocol, the token must be included as a
      parameter <code>access_token</code> in the message. When using REST (HTTP
      GET), the token may also be passed in the <code>Authorization</code>
      header.</p>
  - name: Authentication
  - name: Session Management
  - name: Subscription Management
    description: >-
      Subscription works as [notifications](#notifications), so users will
      automatically (after subscribing) receive messages from the server.
      Overview for each channel response format is described in
      [subscriptions](#subscriptions) section.
  - name: Account Management
  - name: Trading
  - name: Market Data
  - name: Wallet
  - name: Chat
paths:
  /private/pme/simulate:
    get:
      tags:
        - Account Management
        - Private
      description: >+
        Calculates the Extended Risk Matrix (ERM) and detailed margin
        information for Portfolio Margin accounts. The ERM provides a
        comprehensive view of portfolio risk across different scenarios and
        market conditions.


        You can calculate the ERM for a specific currency or for the entire
        Cross-Collateral portfolio. The response includes margin requirements,
        risk metrics, and scenario analysis that helps assess portfolio risk
        under various market conditions.


        Use this method to understand margin requirements and risk exposure
        before making trading decisions in a Portfolio Margin account.


        **📖 Related Article:** [Portfolio
        Margin](https://support.deribit.com/hc/en-us/articles/25944756247837-Portfolio-Margin)


        **Scope:** `account:read`


        [Try in API
        console](https://test.deribit.com/api_console?method=%2Fprivate%2Fpme%2Fsimulate)

      parameters:
        - name: currency
          required: true
          in: query
          schema:
            $ref: '#/components/schemas/pme_currency'
            example: BTC
          description: >-
            The currency for which the Extended Risk Matrix will be calculated.
            Use `CROSS` for Cross Collateral simulation.
        - name: add_positions
          required: false
          in: query
          schema:
            type: boolean
          description: >-
            If `true`, adds simulated positions to current positions, otherwise
            uses only simulated positions. By default `true`
        - name: simulated_positions
          required: false
          in: query
          schema:
            type: string
            description: 'JSON string containing: object data'
          description: >-
            Object with positions in following form: `{InstrumentName1:
            Position1, InstrumentName2: Position2...}`, for example
            `{"BTC-PERPETUAL": -1.0}` (or corresponding URI-encoding for GET).
            Size in base currency.
      requestBody:
        content:
          application/json:
            examples:
              request:
                value:
                  jsonrpc: '2.0'
                  id: 2255
                  method: private/pme/simulate
                  params:
                    currency: BTC
                description: JSON-RPC Request Example
        description: JSON-RPC request body
      responses:
        '200':
          $ref: '#/components/responses/PrivatePmeSimulateResponse'
components:
  schemas:
    pme_currency:
      enum:
        - BTC
        - ETH
        - USDC
        - USDT
        - CROSS
      type: string
      description: >-
        The currency for which the Extended Risk Matrix will be calculated. Use
        `CROSS` for Cross Collateral simulation.
    PrivatePmeSimulateResponse:
      properties:
        jsonrpc:
          type: string
          enum:
            - '2.0'
          description: The JSON-RPC version (2.0)
        id:
          type: integer
          description: The id that was sent in the request
        result:
          type: object
          description: Simulation details
      required:
        - jsonrpc
        - result
      type: object
  responses:
    PrivatePmeSimulateResponse:
      content:
        application/json:
          schema:
            $ref: '#/components/schemas/PrivatePmeSimulateResponse'
          examples:
            response:
              value:
                jsonrpc: '2.0'
                id: 2255
                result:
                  model_params:
                    currency_pair:
                      btc_usd:
                        extended_table_factor: 1
                        m_inc: 0.00005
                        min_volatility_for_shock_up: 0.5
                        max_delta_shock: 0.1
                        delta_total_liq_shock_threshold: 20000000
                        volatility_range_down: 0.25
                        volatility_range_up: 0.5
                        long_term_vega_power: 0.13
                        short_term_vega_power: 0.3
                        price_range: 0.16
                    currency:
                      usd:
                        max_offsetable_pnl: 0
                        annualised_move_risk: 0.1
                        extended_dampener: 25000
                        min_annualised_move: 0.01
                        haircut: 0
                        equity_side_impact: none
                        pnl_offset: 0
                        correlation_set: false
                      btc:
                        max_offsetable_pnl: 0
                        annualised_move_risk: 0.075
                        extended_dampener: 100000
                        min_annualised_move: 0.01
                        haircut: 0
                        equity_side_impact: both
                        pnl_offset: 0
                        correlation_set: false
                    general:
                      mm_factor: 0.8
                      buckets_count: 4
                      vol_scenarios_count: 3
                      timestamp: 1718619740501
                  aggregated_risk_vectors:
                    btc_btc:
                      standard:
                        - -0.05968587238095239
                        - -0.05968587238095239
                        - -0.05968587238095239
                        - -0.04272965863636364
                        - -0.04272965863636364
                        - -0.04272965863636364
                        - -0.02724789826086957
                        - -0.02724789826086957
                        - -0.02724789826086957
                        - -0.013056284583333334
                        - -0.013056284583333334
                        - -0.013056284583333334
                        - 0
                        - 0
                        - 0
                        - 0
                        - 0
                        - 0
                        - 0
                        - 0
                        - 0
                        - 0
                        - 0
                        - 0
                        - 0
                        - 0
                        - 0
                      extended:
                        - 0
                        - 0
                        - 0
                        - 0
                        - 0
                        - 0
                        - 0
                        - 0
                  initial_risk_vectors:
                    BTC-PERPETUAL:
                      standard:
                        - -0.05991206933333334
                        - -0.05991206933333334
                        - -0.05991206933333334
                        - -0.04289159509090909
                        - -0.04289159509090909
                        - -0.04289159509090909
                        - -0.027351162086956524
                        - -0.027351162086956524
                        - -0.027351162086956524
                        - -0.013105765166666668
                        - -0.013105765166666668
                        - -0.013105765166666668
                        - 0
                        - 0
                        - 0
                        - 0.012097629384615385
                        - 0.012097629384615385
                        - 0.012097629384615385
                        - 0.023299138074074074
                        - 0.023299138074074074
                        - 0.023299138074074074
                        - 0.033700538999999995
                        - 0.033700538999999995
                        - 0.033700538999999995
                        - 0.043384601931034494
                        - 0.043384601931034494
                        - 0.043384601931034494
                      extended:
                        - -0.05991206933333334
                        - -0.05991206933333334
                        - 0.04338460193103449
                        - 0.04338460193103449
                        - 0.04338460193103449
                        - 0.04338460193103449
                        - 0.04338460193103449
                        - 0.04338460193103449
                    BTC-28JUN24:
                      standard:
                        - 0.0002261969523809524
                        - 0.0002261969523809524
                        - 0.0002261969523809524
                        - 0.00016193645454545456
                        - 0.00016193645454545456
                        - 0.00016193645454545456
                        - 0.00010326382608695652
                        - 0.00010326382608695652
                        - 0.00010326382608695652
                        - 0.00004948058333333334
                        - 0.00004948058333333334
                        - 0.00004948058333333334
                        - 0
                        - 0
                        - 0
                        - -0.00004567438461538462
                        - -0.00004567438461538462
                        - -0.00004567438461538462
                        - -0.00008796548148148148
                        - -0.00008796548148148148
                        - -0.00008796548148148148
                        - -0.0001272357857142857
                        - -0.0001272357857142857
                        - -0.0001272357857142857
                        - -0.00016379779310344832
                        - -0.00016379779310344832
                        - -0.00016379779310344832
                      extended:
                        - 0.0002261969523809524
                        - 0.0002261969523809524
                        - -0.0001637977931034483
                        - -0.0001637977931034483
                        - -0.0001637977931034483
                        - -0.0001637977931034483
                        - -0.0001637977931034483
                        - -0.0001637977931034483
                  margins:
                    btc:
                      initial_margin_details:
                        risk_matrix_margin_details:
                          delta_shock: 0
                          roll_shock: 0.00315725898
                          worst_case_bucket:
                            bucket: 1
                            side: left
                            source: standard
                            index: 1
                          worst_case: 0.05968587238095239
                          correlation_contingency: 0
                        risk_matrix_margin: 0.06284313098
                        spot_margin: 0
                        mmp_margin: 0.06
                        open_orders_margin: 0.000018212
                      initial_margin: 0.122861343
                      maintenance_margin: 0.050274504784
                  portfolio:
                    currency: {}
                    position:
                      BTC-PERPETUAL: 0.314538364
                      BTC-28JUN24: -0.001187534
                  index_price:
                    btc_usd: 65666.19
                  ticker:
                    BTC-PERPETUAL:
                      mark_price: 65910.57
                      index_price: 65666.19
                    BTC-28JUN24:
                      mark_price: 67371.75
                      index_price: 65666.19
              description: Response example
      description: Success response

````

> ## Documentation Index
> Fetch the complete documentation index at: https://docs.deribit.com/llms.txt
> Use this file to discover all available pages before exploring further.

<AgentInstructions>

## Submitting Feedback

If you encounter incorrect, outdated, or confusing documentation on this page, submit feedback:

POST https://docs.deribit.com/feedback

```json
{
  "path": "/api-reference/account-management/private-remove_api_key",
  "feedback": "Description of the issue"
}
```

Only submit feedback when you have something specific and actionable to report.

</AgentInstructions>

# private/remove_api_key

> Permanently deletes an API key from your account. This operation cannot be undone. Once removed, the API key can no longer be used to authenticate requests, and all applications using this key will lose access.

Consider disabling the key first if you want to temporarily suspend access, as disabled keys can be re-enabled later.

**📖 Related Article:** [Creating new API key on Deribit](https://docs.deribit.com/articles/creating-api-key)

**Scope:** `account:read_write`

[Try in API console](https://test.deribit.com/api_console?method=%2Fprivate%2Fremove_api_key)





## OpenAPI

````yaml /specifications/deribit_openapi.json get /private/remove_api_key
openapi: 3.0.0
info:
  title: Deribit API
  version: 2.1.1
servers:
  - url: https://test.deribit.com/api/v2
security: []
tags:
  - name: WebSocket Only
    description: Can only be used over websockets.
  - name: Public
    description: Public methods can be used without authentication.
  - name: Private
    description: >-
      <p>Private methods require authentication. All requests must include a
      valid OAuth2 token.</p>

      <p>A token can be requested using the <a
      href="#public-auth">/public/auth</a> method.</p>

      <p>When using the websockets protocol, the token must be included as a
      parameter <code>access_token</code> in the message. When using REST (HTTP
      GET), the token may also be passed in the <code>Authorization</code>
      header.</p>
  - name: Authentication
  - name: Session Management
  - name: Subscription Management
    description: >-
      Subscription works as [notifications](#notifications), so users will
      automatically (after subscribing) receive messages from the server.
      Overview for each channel response format is described in
      [subscriptions](#subscriptions) section.
  - name: Account Management
  - name: Trading
  - name: Market Data
  - name: Wallet
  - name: Chat
paths:
  /private/remove_api_key:
    get:
      tags:
        - Account Management
        - Private
      description: >+
        Permanently deletes an API key from your account. This operation cannot
        be undone. Once removed, the API key can no longer be used to
        authenticate requests, and all applications using this key will lose
        access.


        Consider disabling the key first if you want to temporarily suspend
        access, as disabled keys can be re-enabled later.


        **📖 Related Article:** [Creating new API key on
        Deribit](https://docs.deribit.com/articles/creating-api-key)


        **Scope:** `account:read_write`


        [Try in API
        console](https://test.deribit.com/api_console?method=%2Fprivate%2Fremove_api_key)

      parameters:
        - name: id
          in: query
          required: true
          schema:
            type: integer
            example: 1
          description: API key ID
      requestBody:
        content:
          application/json:
            examples:
              request:
                value:
                  jsonrpc: '2.0'
                  id: 8190
                  method: private/remove_api_key
                  params:
                    id: 2
                description: JSON-RPC Request Example
        description: JSON-RPC request body
      responses:
        '200':
          $ref: '#/components/responses/OkResponse'
components:
  responses:
    OkResponse:
      content:
        application/json:
          schema:
            $ref: '#/components/schemas/OkResponse'
          examples:
            response:
              value:
                jsonrpc: '2.0'
                id: 1569
                result: ok
              description: Response example
      description: Success response
  schemas:
    OkResponse:
      properties:
        jsonrpc:
          type: string
          enum:
            - '2.0'
          description: The JSON-RPC version (2.0)
        id:
          type: integer
          description: The id that was sent in the request
        result:
          type: string
          enum:
            - ok
          description: Result of method execution. `ok` in case of success
      required:
        - jsonrpc
        - result
      type: object

````

> ## Documentation Index
> Fetch the complete documentation index at: https://docs.deribit.com/llms.txt
> Use this file to discover all available pages before exploring further.

<AgentInstructions>

## Submitting Feedback

If you encounter incorrect, outdated, or confusing documentation on this page, submit feedback:

POST https://docs.deribit.com/feedback

```json
{
  "path": "/api-reference/account-management/private-remove_subaccount",
  "feedback": "Description of the issue"
}
```

Only submit feedback when you have something specific and actionable to report.

</AgentInstructions>

# private/remove_subaccount

> Permanently removes a subaccount. The subaccount must be empty (no positions, no open orders, and zero balance) before it can be removed.

This operation cannot be undone. All subaccount data will be permanently deleted.

**[TFA required](https://docs.deribit.com/articles/security-keys)**

**📖 Related Article:** [Managing Subaccounts](https://docs.deribit.com/articles/managing-subaccounts-api)

**Scope:** `account:read_write`

[Try in API console](https://test.deribit.com/api_console?method=%2Fprivate%2Fremove_subaccount)





## OpenAPI

````yaml /specifications/deribit_openapi.json get /private/remove_subaccount
openapi: 3.0.0
info:
  title: Deribit API
  version: 2.1.1
servers:
  - url: https://test.deribit.com/api/v2
security: []
tags:
  - name: WebSocket Only
    description: Can only be used over websockets.
  - name: Public
    description: Public methods can be used without authentication.
  - name: Private
    description: >-
      <p>Private methods require authentication. All requests must include a
      valid OAuth2 token.</p>

      <p>A token can be requested using the <a
      href="#public-auth">/public/auth</a> method.</p>

      <p>When using the websockets protocol, the token must be included as a
      parameter <code>access_token</code> in the message. When using REST (HTTP
      GET), the token may also be passed in the <code>Authorization</code>
      header.</p>
  - name: Authentication
  - name: Session Management
  - name: Subscription Management
    description: >-
      Subscription works as [notifications](#notifications), so users will
      automatically (after subscribing) receive messages from the server.
      Overview for each channel response format is described in
      [subscriptions](#subscriptions) section.
  - name: Account Management
  - name: Trading
  - name: Market Data
  - name: Wallet
  - name: Chat
paths:
  /private/remove_subaccount:
    get:
      tags:
        - Account Management
        - Private
      description: >+
        Permanently removes a subaccount. The subaccount must be empty (no
        positions, no open orders, and zero balance) before it can be removed.


        This operation cannot be undone. All subaccount data will be permanently
        deleted.


        **[TFA required](https://docs.deribit.com/articles/security-keys)**


        **📖 Related Article:** [Managing
        Subaccounts](https://docs.deribit.com/articles/managing-subaccounts-api)


        **Scope:** `account:read_write`


        [Try in API
        console](https://test.deribit.com/api_console?method=%2Fprivate%2Fremove_subaccount)

      parameters:
        - name: subaccount_id
          in: query
          schema:
            type: integer
            example: 120
          required: true
          description: The user id for the subaccount
      requestBody:
        content:
          application/json:
            examples:
              request:
                value:
                  jsonrpc: '2.0'
                  id: 6
                  method: private/remove_subaccount
                  params:
                    subaccount_id: 120
                description: JSON-RPC Request Example
        description: JSON-RPC request body
      responses:
        '200':
          $ref: '#/components/responses/OkResponse'
components:
  responses:
    OkResponse:
      content:
        application/json:
          schema:
            $ref: '#/components/schemas/OkResponse'
          examples:
            response:
              value:
                jsonrpc: '2.0'
                id: 1569
                result: ok
              description: Response example
      description: Success response
  schemas:
    OkResponse:
      properties:
        jsonrpc:
          type: string
          enum:
            - '2.0'
          description: The JSON-RPC version (2.0)
        id:
          type: integer
          description: The id that was sent in the request
        result:
          type: string
          enum:
            - ok
          description: Result of method execution. `ok` in case of success
      required:
        - jsonrpc
        - result
      type: object

````


> ## Documentation Index
> Fetch the complete documentation index at: https://docs.deribit.com/llms.txt
> Use this file to discover all available pages before exploring further.

<AgentInstructions>

## Submitting Feedback

If you encounter incorrect, outdated, or confusing documentation on this page, submit feedback:

POST https://docs.deribit.com/feedback

```json
{
  "path": "/api-reference/account-management/private-reset_api_key",
  "feedback": "Description of the issue"
}
```

Only submit feedback when you have something specific and actionable to report.

</AgentInstructions>

# private/reset_api_key

> Generates a new secret key for an existing API key while keeping the same key ID and other properties. This is useful if the secret has been compromised or needs to be rotated for security purposes.

The old secret becomes invalid immediately, and the new secret is returned in the response. Store the new secret securely as it will not be displayed again. All applications using the old secret will need to be updated with the new secret.

**📖 Related Article:** [Creating new API key on Deribit](https://docs.deribit.com/articles/creating-api-key)

**Scope:** `account:read_write`

[Try in API console](https://test.deribit.com/api_console?method=%2Fprivate%2Freset_api_key)





## OpenAPI

````yaml /specifications/deribit_openapi.json get /private/reset_api_key
openapi: 3.0.0
info:
  title: Deribit API
  version: 2.1.1
servers:
  - url: https://test.deribit.com/api/v2
security: []
tags:
  - name: WebSocket Only
    description: Can only be used over websockets.
  - name: Public
    description: Public methods can be used without authentication.
  - name: Private
    description: >-
      <p>Private methods require authentication. All requests must include a
      valid OAuth2 token.</p>

      <p>A token can be requested using the <a
      href="#public-auth">/public/auth</a> method.</p>

      <p>When using the websockets protocol, the token must be included as a
      parameter <code>access_token</code> in the message. When using REST (HTTP
      GET), the token may also be passed in the <code>Authorization</code>
      header.</p>
  - name: Authentication
  - name: Session Management
  - name: Subscription Management
    description: >-
      Subscription works as [notifications](#notifications), so users will
      automatically (after subscribing) receive messages from the server.
      Overview for each channel response format is described in
      [subscriptions](#subscriptions) section.
  - name: Account Management
  - name: Trading
  - name: Market Data
  - name: Wallet
  - name: Chat
paths:
  /private/reset_api_key:
    get:
      tags:
        - Account Management
        - Private
      description: >+
        Generates a new secret key for an existing API key while keeping the
        same key ID and other properties. This is useful if the secret has been
        compromised or needs to be rotated for security purposes.


        The old secret becomes invalid immediately, and the new secret is
        returned in the response. Store the new secret securely as it will not
        be displayed again. All applications using the old secret will need to
        be updated with the new secret.


        **📖 Related Article:** [Creating new API key on
        Deribit](https://docs.deribit.com/articles/creating-api-key)


        **Scope:** `account:read_write`


        [Try in API
        console](https://test.deribit.com/api_console?method=%2Fprivate%2Freset_api_key)

      parameters:
        - name: id
          in: query
          required: true
          schema:
            type: integer
            example: 1
          description: API key ID
      requestBody:
        content:
          application/json:
            examples:
              request:
                value:
                  jsonrpc: '2.0'
                  id: 6524
                  method: private/reset_api_key
                  params:
                    id: 3
                description: JSON-RPC Request Example
        description: JSON-RPC request body
      responses:
        '200':
          $ref: '#/components/responses/PrivateApiKeyResponse'
components:
  responses:
    PrivateApiKeyResponse:
      content:
        application/json:
          schema:
            $ref: '#/components/schemas/PrivateApiKeyResponse'
          examples:
            response:
              value:
                jsonrpc: '2.0'
                id: 2453
                result:
                  timestamp: 1560242482758
                  max_scope: >-
                    account:read_write block_trade:read trade:read_write
                    wallet:read_write
                  id: 3
                  enabled: true
                  default: false
                  client_secret: B6RsF9rrLY5ezEGBQkyLlV-UC7whyPJ34BMA-kKYpes
                  client_id: 1sXMQBhM
                  name: NewKeyName
              description: Response example
      description: Success response
  schemas:
    PrivateApiKeyResponse:
      properties:
        jsonrpc:
          type: string
          enum:
            - '2.0'
          description: The JSON-RPC version (2.0)
        id:
          type: integer
          description: The id that was sent in the request
        result:
          $ref: '#/components/schemas/api_key'
      required:
        - jsonrpc
        - result
      type: object
    api_key:
      properties:
        id:
          $ref: '#/components/schemas/key_id'
        timestamp:
          $ref: '#/components/schemas/timestamp'
        client_id:
          $ref: '#/components/schemas/client_id'
        client_secret:
          $ref: '#/components/schemas/client_secret'
        public_key:
          $ref: '#/components/schemas/public_key'
        max_scope:
          $ref: '#/components/schemas/max_scope'
        enabled:
          $ref: '#/components/schemas/api_key_enabled'
        default:
          $ref: '#/components/schemas/api_key_default'
        name:
          $ref: '#/components/schemas/api_key_name'
        enabled_features:
          $ref: '#/components/schemas/api_key_features'
        ip_whitelist:
          type: array
          description: List of IP addresses whitelisted for a selected key
      required:
        - id
        - timestamp
        - client_id
        - client_secret
        - max_scope
        - default
      type: object
    key_id:
      example: 1
      type: integer
      description: Key identifier
    timestamp:
      example: 1536569522277
      type: integer
      description: The timestamp (milliseconds since the Unix epoch)
    client_id:
      example: IY2D68DS
      type: string
      description: Client identifier used for authentication
    client_secret:
      example: P9Z_c73KaBPwpoTVfsXzehAhjhdJn5kM7Zlz_hhDhE8
      type: string
      description: Client secret or MD5 fingerprint of public key used for authentication
    public_key:
      example: >-
        -----BEGIN PUBLIC KEY-----
        MCowBQYDK2VwAyEApajFN0CSwIaaiIRPiFbiYYvpsLQLSccSLLsKPe984sc= -----END
        PUBLIC KEY-----
      type: string
      description: >-
        PEM encoded public key (Ed25519/RSA) used for asymmetric signatures
        (optional)
    max_scope:
      items:
        type: string
      example:
        - account:read
        - trade:read
        - block_trade:read_write
        - wallet:none
      type: array
      description: >
        Describes maximal access for tokens generated with given key. If scope
        is not provided, its value is set as none.


        **📖 Related Article:** [Access
        Scope](https://docs.deribit.com/articles/access-scope)
    api_key_enabled:
      example: true
      type: boolean
      description: Informs whether api key is enabled and can be used for authentication
    api_key_default:
      example: false
      type: boolean
      description: >-
        Informs whether this api key is default (field is deprecated and will be
        removed in the future)
    api_key_name:
      example: TestName
      type: string
      description: Api key name that can be displayed in transaction log
    api_key_features:
      items:
        type: string
      type: array
      description: >-
        List of enabled advanced on-key features.<br><br><b>Available
        options:</b><br>- <code>restricted_block_trades</code>: Limit the
        block_trade read the scope of the API key to block trades that have been
        made using this specific API key<br>- <code>block_trade_approval</code>:
        Block trades created using this API key require additional user
        approval. Methods that use <code>block_rfq</code> scope are not affected
        by Block Trade approval feature

````

> ## Documentation Index
> Fetch the complete documentation index at: https://docs.deribit.com/llms.txt
> Use this file to discover all available pages before exploring further.

<AgentInstructions>

## Submitting Feedback

If you encounter incorrect, outdated, or confusing documentation on this page, submit feedback:

POST https://docs.deribit.com/feedback

```json
{
  "path": "/api-reference/account-management/private-set_announcement_as_read",
  "feedback": "Description of the issue"
}
```

Only submit feedback when you have something specific and actionable to report.

</AgentInstructions>

# private/set_announcement_as_read

> Marks a specific announcement as read. Once marked as read, the announcement will no longer appear in the `get_new_announcements` response, though it will still be available through `get_announcements`.

This helps track which announcements have been viewed and reduces notification clutter.

**Scope:** `account:read_write`

[Try in API console](https://test.deribit.com/api_console?method=%2Fprivate%2Fset_announcement_as_read)





## OpenAPI

````yaml /specifications/deribit_openapi.json get /private/set_announcement_as_read
openapi: 3.0.0
info:
  title: Deribit API
  version: 2.1.1
servers:
  - url: https://test.deribit.com/api/v2
security: []
tags:
  - name: WebSocket Only
    description: Can only be used over websockets.
  - name: Public
    description: Public methods can be used without authentication.
  - name: Private
    description: >-
      <p>Private methods require authentication. All requests must include a
      valid OAuth2 token.</p>

      <p>A token can be requested using the <a
      href="#public-auth">/public/auth</a> method.</p>

      <p>When using the websockets protocol, the token must be included as a
      parameter <code>access_token</code> in the message. When using REST (HTTP
      GET), the token may also be passed in the <code>Authorization</code>
      header.</p>
  - name: Authentication
  - name: Session Management
  - name: Subscription Management
    description: >-
      Subscription works as [notifications](#notifications), so users will
      automatically (after subscribing) receive messages from the server.
      Overview for each channel response format is described in
      [subscriptions](#subscriptions) section.
  - name: Account Management
  - name: Trading
  - name: Market Data
  - name: Wallet
  - name: Chat
paths:
  /private/set_announcement_as_read:
    get:
      tags:
        - Account Management
        - Private
      description: >+
        Marks a specific announcement as read. Once marked as read, the
        announcement will no longer appear in the `get_new_announcements`
        response, though it will still be available through `get_announcements`.


        This helps track which announcements have been viewed and reduces
        notification clutter.


        **Scope:** `account:read_write`


        [Try in API
        console](https://test.deribit.com/api_console?method=%2Fprivate%2Fset_announcement_as_read)

      parameters:
        - in: query
          name: announcement_id
          required: true
          schema:
            type: number
            example: 1550058362418
          description: the ID of the announcement
      requestBody:
        content:
          application/json:
            examples:
              request:
                value:
                  jsonrpc: '2.0'
                  id: 5147
                  method: private/set_announcement_as_read
                  params:
                    announcement_id: 1550058362418
                description: JSON-RPC Request Example
        description: JSON-RPC request body
      responses:
        '200':
          $ref: '#/components/responses/OkResponse'
components:
  responses:
    OkResponse:
      content:
        application/json:
          schema:
            $ref: '#/components/schemas/OkResponse'
          examples:
            response:
              value:
                jsonrpc: '2.0'
                id: 1569
                result: ok
              description: Response example
      description: Success response
  schemas:
    OkResponse:
      properties:
        jsonrpc:
          type: string
          enum:
            - '2.0'
          description: The JSON-RPC version (2.0)
        id:
          type: integer
          description: The id that was sent in the request
        result:
          type: string
          enum:
            - ok
          description: Result of method execution. `ok` in case of success
      required:
        - jsonrpc
        - result
      type: object

````

> ## Documentation Index
> Fetch the complete documentation index at: https://docs.deribit.com/llms.txt
> Use this file to discover all available pages before exploring further.

<AgentInstructions>

## Submitting Feedback

If you encounter incorrect, outdated, or confusing documentation on this page, submit feedback:

POST https://docs.deribit.com/feedback

```json
{
  "path": "/api-reference/account-management/private-set_announcement_as_read",
  "feedback": "Description of the issue"
}
```

Only submit feedback when you have something specific and actionable to report.

</AgentInstructions>

# private/set_announcement_as_read

> Marks a specific announcement as read. Once marked as read, the announcement will no longer appear in the `get_new_announcements` response, though it will still be available through `get_announcements`.

This helps track which announcements have been viewed and reduces notification clutter.

**Scope:** `account:read_write`

[Try in API console](https://test.deribit.com/api_console?method=%2Fprivate%2Fset_announcement_as_read)





## OpenAPI

````yaml /specifications/deribit_openapi.json get /private/set_announcement_as_read
openapi: 3.0.0
info:
  title: Deribit API
  version: 2.1.1
servers:
  - url: https://test.deribit.com/api/v2
security: []
tags:
  - name: WebSocket Only
    description: Can only be used over websockets.
  - name: Public
    description: Public methods can be used without authentication.
  - name: Private
    description: >-
      <p>Private methods require authentication. All requests must include a
      valid OAuth2 token.</p>

      <p>A token can be requested using the <a
      href="#public-auth">/public/auth</a> method.</p>

      <p>When using the websockets protocol, the token must be included as a
      parameter <code>access_token</code> in the message. When using REST (HTTP
      GET), the token may also be passed in the <code>Authorization</code>
      header.</p>
  - name: Authentication
  - name: Session Management
  - name: Subscription Management
    description: >-
      Subscription works as [notifications](#notifications), so users will
      automatically (after subscribing) receive messages from the server.
      Overview for each channel response format is described in
      [subscriptions](#subscriptions) section.
  - name: Account Management
  - name: Trading
  - name: Market Data
  - name: Wallet
  - name: Chat
paths:
  /private/set_announcement_as_read:
    get:
      tags:
        - Account Management
        - Private
      description: >+
        Marks a specific announcement as read. Once marked as read, the
        announcement will no longer appear in the `get_new_announcements`
        response, though it will still be available through `get_announcements`.


        This helps track which announcements have been viewed and reduces
        notification clutter.


        **Scope:** `account:read_write`


        [Try in API
        console](https://test.deribit.com/api_console?method=%2Fprivate%2Fset_announcement_as_read)

      parameters:
        - in: query
          name: announcement_id
          required: true
          schema:
            type: number
            example: 1550058362418
          description: the ID of the announcement
      requestBody:
        content:
          application/json:
            examples:
              request:
                value:
                  jsonrpc: '2.0'
                  id: 5147
                  method: private/set_announcement_as_read
                  params:
                    announcement_id: 1550058362418
                description: JSON-RPC Request Example
        description: JSON-RPC request body
      responses:
        '200':
          $ref: '#/components/responses/OkResponse'
components:
  responses:
    OkResponse:
      content:
        application/json:
          schema:
            $ref: '#/components/schemas/OkResponse'
          examples:
            response:
              value:
                jsonrpc: '2.0'
                id: 1569
                result: ok
              description: Response example
      description: Success response
  schemas:
    OkResponse:
      properties:
        jsonrpc:
          type: string
          enum:
            - '2.0'
          description: The JSON-RPC version (2.0)
        id:
          type: integer
          description: The id that was sent in the request
        result:
          type: string
          enum:
            - ok
          description: Result of method execution. `ok` in case of success
      required:
        - jsonrpc
        - result
      type: object

````

> ## Documentation Index
> Fetch the complete documentation index at: https://docs.deribit.com/llms.txt
> Use this file to discover all available pages before exploring further.

<AgentInstructions>

## Submitting Feedback

If you encounter incorrect, outdated, or confusing documentation on this page, submit feedback:

POST https://docs.deribit.com/feedback

```json
{
  "path": "/api-reference/account-management/private-set_email_for_subaccount",
  "feedback": "Description of the issue"
}
```

Only submit feedback when you have something specific and actionable to report.

</AgentInstructions>

# private/set_email_for_subaccount

> Assigns an email address to a subaccount. This email can be used for direct login to the subaccount and for receiving notifications.

The email address owner will receive a confirmation email with a link to verify the email address. The email must be confirmed before it can be used for login.

**[TFA required](https://docs.deribit.com/articles/security-keys)**

**📖 Related Article:** [Managing Subaccounts](https://docs.deribit.com/articles/managing-subaccounts-api)

**Scope:** `account:read_write`

[Try in API console](https://test.deribit.com/api_console?method=%2Fprivate%2Fset_email_for_subaccount)





## OpenAPI

````yaml /specifications/deribit_openapi.json get /private/set_email_for_subaccount
openapi: 3.0.0
info:
  title: Deribit API
  version: 2.1.1
servers:
  - url: https://test.deribit.com/api/v2
security: []
tags:
  - name: WebSocket Only
    description: Can only be used over websockets.
  - name: Public
    description: Public methods can be used without authentication.
  - name: Private
    description: >-
      <p>Private methods require authentication. All requests must include a
      valid OAuth2 token.</p>

      <p>A token can be requested using the <a
      href="#public-auth">/public/auth</a> method.</p>

      <p>When using the websockets protocol, the token must be included as a
      parameter <code>access_token</code> in the message. When using REST (HTTP
      GET), the token may also be passed in the <code>Authorization</code>
      header.</p>
  - name: Authentication
  - name: Session Management
  - name: Subscription Management
    description: >-
      Subscription works as [notifications](#notifications), so users will
      automatically (after subscribing) receive messages from the server.
      Overview for each channel response format is described in
      [subscriptions](#subscriptions) section.
  - name: Account Management
  - name: Trading
  - name: Market Data
  - name: Wallet
  - name: Chat
paths:
  /private/set_email_for_subaccount:
    get:
      tags:
        - Account Management
        - Private
      description: >+
        Assigns an email address to a subaccount. This email can be used for
        direct login to the subaccount and for receiving notifications.


        The email address owner will receive a confirmation email with a link to
        verify the email address. The email must be confirmed before it can be
        used for login.


        **[TFA required](https://docs.deribit.com/articles/security-keys)**


        **📖 Related Article:** [Managing
        Subaccounts](https://docs.deribit.com/articles/managing-subaccounts-api)


        **Scope:** `account:read_write`


        [Try in API
        console](https://test.deribit.com/api_console?method=%2Fprivate%2Fset_email_for_subaccount)

      parameters:
        - name: sid
          in: query
          schema:
            type: integer
            example: 7
          required: true
          description: The user id for the subaccount
        - name: email
          in: query
          schema:
            type: string
            example: user_1_1@email.com
          required: true
          description: The email address for the subaccount
      requestBody:
        content:
          application/json:
            examples:
              request:
                value:
                  jsonrpc: '2.0'
                  id: 1667
                  method: private/set_email_for_subaccount
                  params:
                    sid: 7
                    email: user_1_1@email.com
                description: JSON-RPC Request Example
        description: JSON-RPC request body
      responses:
        '200':
          $ref: '#/components/responses/OkResponse'
components:
  responses:
    OkResponse:
      content:
        application/json:
          schema:
            $ref: '#/components/schemas/OkResponse'
          examples:
            response:
              value:
                jsonrpc: '2.0'
                id: 1569
                result: ok
              description: Response example
      description: Success response
  schemas:
    OkResponse:
      properties:
        jsonrpc:
          type: string
          enum:
            - '2.0'
          description: The JSON-RPC version (2.0)
        id:
          type: integer
          description: The id that was sent in the request
        result:
          type: string
          enum:
            - ok
          description: Result of method execution. `ok` in case of success
      required:
        - jsonrpc
        - result
      type: object

````

> ## Documentation Index
> Fetch the complete documentation index at: https://docs.deribit.com/llms.txt
> Use this file to discover all available pages before exploring further.

<AgentInstructions>

## Submitting Feedback

If you encounter incorrect, outdated, or confusing documentation on this page, submit feedback:

POST https://docs.deribit.com/feedback

```json
{
  "path": "/api-reference/account-management/private-set_email_language",
  "feedback": "Description of the issue"
}
```

Only submit feedback when you have something specific and actionable to report.

</AgentInstructions>

# private/set_email_language

> Sets the preferred language for email notifications sent to the authenticated account. Supported languages include English (`en`), Korean (`ko`), Chinese (`zh`), Japanese (`ja`), and Russian (`ru`).

All future email notifications will be sent in the selected language. This setting does not affect the language of the web interface or API responses.

**Scope:** `account:read_write`

[Try in API console](https://test.deribit.com/api_console?method=%2Fprivate%2Fset_email_language)





## OpenAPI

````yaml /specifications/deribit_openapi.json get /private/set_email_language
openapi: 3.0.0
info:
  title: Deribit API
  version: 2.1.1
servers:
  - url: https://test.deribit.com/api/v2
security: []
tags:
  - name: WebSocket Only
    description: Can only be used over websockets.
  - name: Public
    description: Public methods can be used without authentication.
  - name: Private
    description: >-
      <p>Private methods require authentication. All requests must include a
      valid OAuth2 token.</p>

      <p>A token can be requested using the <a
      href="#public-auth">/public/auth</a> method.</p>

      <p>When using the websockets protocol, the token must be included as a
      parameter <code>access_token</code> in the message. When using REST (HTTP
      GET), the token may also be passed in the <code>Authorization</code>
      header.</p>
  - name: Authentication
  - name: Session Management
  - name: Subscription Management
    description: >-
      Subscription works as [notifications](#notifications), so users will
      automatically (after subscribing) receive messages from the server.
      Overview for each channel response format is described in
      [subscriptions](#subscriptions) section.
  - name: Account Management
  - name: Trading
  - name: Market Data
  - name: Wallet
  - name: Chat
paths:
  /private/set_email_language:
    get:
      tags:
        - Account Management
        - Private
      description: >+
        Sets the preferred language for email notifications sent to the
        authenticated account. Supported languages include English (`en`),
        Korean (`ko`), Chinese (`zh`), Japanese (`ja`), and Russian (`ru`).


        All future email notifications will be sent in the selected language.
        This setting does not affect the language of the web interface or API
        responses.


        **Scope:** `account:read_write`


        [Try in API
        console](https://test.deribit.com/api_console?method=%2Fprivate%2Fset_email_language)

      parameters:
        - in: query
          name: language
          required: true
          schema:
            type: string
            example: en
          description: >-
            The abbreviated language name. Valid values include `"en"`, `"ko"`,
            `"zh"`,  `"ja"`, `"ru"`
      requestBody:
        content:
          application/json:
            examples:
              request:
                value:
                  jsonrpc: '2.0'
                  id: 3269
                  method: private/set_email_language
                  params:
                    language: en
                description: JSON-RPC Request Example
        description: JSON-RPC request body
      responses:
        '200':
          $ref: '#/components/responses/OkResponse'
components:
  responses:
    OkResponse:
      content:
        application/json:
          schema:
            $ref: '#/components/schemas/OkResponse'
          examples:
            response:
              value:
                jsonrpc: '2.0'
                id: 1569
                result: ok
              description: Response example
      description: Success response
  schemas:
    OkResponse:
      properties:
        jsonrpc:
          type: string
          enum:
            - '2.0'
          description: The JSON-RPC version (2.0)
        id:
          type: integer
          description: The id that was sent in the request
        result:
          type: string
          enum:
            - ok
          description: Result of method execution. `ok` in case of success
      required:
        - jsonrpc
        - result
      type: object

````

> ## Documentation Index
> Fetch the complete documentation index at: https://docs.deribit.com/llms.txt
> Use this file to discover all available pages before exploring further.

<AgentInstructions>

## Submitting Feedback

If you encounter incorrect, outdated, or confusing documentation on this page, submit feedback:

POST https://docs.deribit.com/feedback

```json
{
  "path": "/api-reference/account-management/private-set_self_trading_config",
  "feedback": "Description of the issue"
}
```

Only submit feedback when you have something specific and actionable to report.

</AgentInstructions>

# private/set_self_trading_config

> Configures self-trading prevention settings for the account. Self-trading occurs when orders from the same account (or related subaccounts) match against each other.

You can configure whether self-trading is allowed, blocked, or allowed only for specific scenarios. Settings can be extended to apply to subaccounts as well. For Block RFQ trading, separate self-match prevention settings are available.

**📖 Related Support Article:** [Account settings page](https://support.deribit.com/hc/en-us/articles/25944634289693-Account-settings-page#heading-4)

**Scope:** `account:read_write`

[Try in API console](https://test.deribit.com/api_console?method=%2Fprivate%2Fset_self_trading_config)





## OpenAPI

````yaml /specifications/deribit_openapi.json get /private/set_self_trading_config
openapi: 3.0.0
info:
  title: Deribit API
  version: 2.1.1
servers:
  - url: https://test.deribit.com/api/v2
security: []
tags:
  - name: WebSocket Only
    description: Can only be used over websockets.
  - name: Public
    description: Public methods can be used without authentication.
  - name: Private
    description: >-
      <p>Private methods require authentication. All requests must include a
      valid OAuth2 token.</p>

      <p>A token can be requested using the <a
      href="#public-auth">/public/auth</a> method.</p>

      <p>When using the websockets protocol, the token must be included as a
      parameter <code>access_token</code> in the message. When using REST (HTTP
      GET), the token may also be passed in the <code>Authorization</code>
      header.</p>
  - name: Authentication
  - name: Session Management
  - name: Subscription Management
    description: >-
      Subscription works as [notifications](#notifications), so users will
      automatically (after subscribing) receive messages from the server.
      Overview for each channel response format is described in
      [subscriptions](#subscriptions) section.
  - name: Account Management
  - name: Trading
  - name: Market Data
  - name: Wallet
  - name: Chat
paths:
  /private/set_self_trading_config:
    get:
      tags:
        - Account Management
        - Private
      description: >+
        Configures self-trading prevention settings for the account.
        Self-trading occurs when orders from the same account (or related
        subaccounts) match against each other.


        You can configure whether self-trading is allowed, blocked, or allowed
        only for specific scenarios. Settings can be extended to apply to
        subaccounts as well. For Block RFQ trading, separate self-match
        prevention settings are available.


        **📖 Related Support Article:** [Account settings
        page](https://support.deribit.com/hc/en-us/articles/25944634289693-Account-settings-page#heading-4)


        **Scope:** `account:read_write`


        [Try in API
        console](https://test.deribit.com/api_console?method=%2Fprivate%2Fset_self_trading_config)

      parameters:
        - name: mode
          in: query
          required: true
          schema:
            type: string
            enum:
              - reject_taker
              - cancel_maker
          description: >-
            Self trading prevention behavior: `reject_taker` (reject the
            incoming order), `cancel_maker` (cancel the matched order in the
            book)
        - name: extended_to_subaccounts
          in: query
          required: true
          schema:
            type: boolean
          description: >-
            If value is `true` trading is prevented between subaccounts of given
            account, otherwise they are treated separately
        - name: block_rfq_self_match_prevention
          in: query
          required: false
          schema:
            type: boolean
          description: >-
            When Block RFQ Self Match Prevention is enabled, it ensures that
            RFQs cannot be executed between accounts that belong to the same
            legal entity. This setting is independent of the general self-match
            prevention settings and must be configured separately.
      requestBody:
        content:
          application/json:
            examples:
              request:
                value:
                  jsonrpc: '2.0'
                  id: 1
                  method: private/set_self_trading_config
                  params:
                    mode: cancel_maker
                    extended_to_subaccounts: true
                    block_rfq_self_match_prevention: true
                description: JSON-RPC Request Example
        description: JSON-RPC request body
      responses:
        '200':
          $ref: '#/components/responses/OkResponse'
components:
  responses:
    OkResponse:
      content:
        application/json:
          schema:
            $ref: '#/components/schemas/OkResponse'
          examples:
            response:
              value:
                jsonrpc: '2.0'
                id: 1569
                result: ok
              description: Response example
      description: Success response
  schemas:
    OkResponse:
      properties:
        jsonrpc:
          type: string
          enum:
            - '2.0'
          description: The JSON-RPC version (2.0)
        id:
          type: integer
          description: The id that was sent in the request
        result:
          type: string
          enum:
            - ok
          description: Result of method execution. `ok` in case of success
      required:
        - jsonrpc
        - result
      type: object

````

> ## Documentation Index
> Fetch the complete documentation index at: https://docs.deribit.com/llms.txt
> Use this file to discover all available pages before exploring further.

<AgentInstructions>

## Submitting Feedback

If you encounter incorrect, outdated, or confusing documentation on this page, submit feedback:

POST https://docs.deribit.com/feedback

```json
{
  "path": "/api-reference/account-management/private-simulate_portfolio",
  "feedback": "Description of the issue"
}
```

Only submit feedback when you have something specific and actionable to report.

</AgentInstructions>

# private/simulate_portfolio

> Calculates portfolio margin requirements and risk metrics for simulated positions or the current portfolio. This method helps you understand margin requirements before opening new positions or assess the impact of potential trades.

You can simulate adding new positions to the current portfolio or calculate margin for a completely simulated portfolio. The response includes initial margin, maintenance margin, available funds, and other risk metrics.

**Note:** This method has a restricted rate limit of not more than once per second due to the computational complexity of portfolio margin calculations.

**📖 Related Article:** [Portfolio Margin](https://support.deribit.com/hc/en-us/articles/25944756247837-Portfolio-Margin)

**Scope:** `account:read`

[Try in API console](https://test.deribit.com/api_console?method=%2Fprivate%2Fsimulate_portfolio)





## OpenAPI

````yaml /specifications/deribit_openapi.json get /private/simulate_portfolio
openapi: 3.0.0
info:
  title: Deribit API
  version: 2.1.1
servers:
  - url: https://test.deribit.com/api/v2
security: []
tags:
  - name: WebSocket Only
    description: Can only be used over websockets.
  - name: Public
    description: Public methods can be used without authentication.
  - name: Private
    description: >-
      <p>Private methods require authentication. All requests must include a
      valid OAuth2 token.</p>

      <p>A token can be requested using the <a
      href="#public-auth">/public/auth</a> method.</p>

      <p>When using the websockets protocol, the token must be included as a
      parameter <code>access_token</code> in the message. When using REST (HTTP
      GET), the token may also be passed in the <code>Authorization</code>
      header.</p>
  - name: Authentication
  - name: Session Management
  - name: Subscription Management
    description: >-
      Subscription works as [notifications](#notifications), so users will
      automatically (after subscribing) receive messages from the server.
      Overview for each channel response format is described in
      [subscriptions](#subscriptions) section.
  - name: Account Management
  - name: Trading
  - name: Market Data
  - name: Wallet
  - name: Chat
paths:
  /private/simulate_portfolio:
    get:
      tags:
        - Account Management
        - Private
      description: >+
        Calculates portfolio margin requirements and risk metrics for simulated
        positions or the current portfolio. This method helps you understand
        margin requirements before opening new positions or assess the impact of
        potential trades.


        You can simulate adding new positions to the current portfolio or
        calculate margin for a completely simulated portfolio. The response
        includes initial margin, maintenance margin, available funds, and other
        risk metrics.


        **Note:** This method has a restricted rate limit of not more than once
        per second due to the computational complexity of portfolio margin
        calculations.


        **📖 Related Article:** [Portfolio
        Margin](https://support.deribit.com/hc/en-us/articles/25944756247837-Portfolio-Margin)


        **Scope:** `account:read`


        [Try in API
        console](https://test.deribit.com/api_console?method=%2Fprivate%2Fsimulate_portfolio)

      parameters:
        - name: currency
          required: true
          in: query
          schema:
            $ref: '#/components/schemas/currency'
            example: BTC
          description: The currency symbol
        - name: add_positions
          required: false
          in: query
          schema:
            type: boolean
          description: >-
            If `true`, adds simulated positions to current positions, otherwise
            uses only simulated positions. By default `true`
        - name: simulated_positions
          required: false
          in: query
          schema:
            type: string
            description: 'JSON string containing: object data'
          description: >-
            Object with positions in following form: `{InstrumentName1:
            Position1, InstrumentName2: Position2...}`, for example
            `{"BTC-PERPETUAL": -1000.0}` (or corresponding URI-encoding for
            GET). For futures in USD, for options in base currency.
      requestBody:
        content:
          application/json:
            examples:
              request:
                value:
                  jsonrpc: '2.0'
                  id: 22222
                  method: private/simulate_portfolio
                  params:
                    currency: BTC
                    add_positions: true
                    simulated_positions:
                      BTC-PERPETUAL: 1
                description: JSON-RPC Request Example
        description: JSON-RPC request body
      responses:
        '200':
          $ref: '#/components/responses/PrivateSimulatePortfolioResponse'
components:
  schemas:
    currency:
      enum:
        - BTC
        - ETH
        - USDC
        - USDT
        - EURR
      type: string
      description: Currency, i.e `"BTC"`, `"ETH"`, `"USDC"`
    PrivateSimulatePortfolioResponse:
      properties:
        jsonrpc:
          type: string
          enum:
            - '2.0'
          description: The JSON-RPC version (2.0)
        id:
          type: integer
          description: The id that was sent in the request
        result:
          type: object
          properties:
            currency:
              example: BTC
              type: string
              description: Currency of the simulation
            equity:
              example: 150075253.91354558
              type: number
              description: The account's current equity
            balance:
              example: 150076473.4995114
              type: number
              description: The account's balance
            margin_balance:
              example: 153534213.79481918
              type: number
              description: >-
                The account's margin balance. When cross collateral is enabled,
                this aggregated value is calculated by converting the sum of
                each cross collateral currency's value to the given currency,
                using each cross collateral currency's index.
            initial_margin:
              example: 37662472.03416069
              type: number
              description: >-
                The account's initial margin. When cross collateral is enabled,
                this aggregated value is calculated by converting the sum of
                each cross collateral currency's value to the given currency,
                using each cross collateral currency's index.
            maintenance_margin:
              example: 30129215.84817124
              type: number
              description: >-
                The maintenance margin. When cross collateral is enabled, this
                aggregated value is calculated by converting the sum of each
                cross collateral currency's value to the given currency, using
                each cross collateral currency's index.
            projected_initial_margin:
              $ref: '#/components/schemas/projected_initial_margin'
            projected_maintenance_margin:
              $ref: '#/components/schemas/projected_maintenance_margin'
            available_funds:
              example: 115871741.76065847
              type: number
              description: >-
                The account's available funds. When cross collateral is enabled,
                this aggregated value is calculated by converting the sum of
                each cross collateral currency's value to the given currency,
                using each cross collateral currency's index.
            available_withdrawal_funds:
              example: 115871741.76065847
              type: number
              description: The account's available to withdrawal funds
            available_subaccount_transfer_funds:
              example: 0
              type: number
              description: The account's available funds for subaccount transfers
            total_pl:
              example: 40419.10179263
              type: number
              description: Profit and loss
            session_rpl:
              $ref: '#/components/schemas/rpl'
            session_upl:
              $ref: '#/components/schemas/upl'
            futures_pl:
              example: 39497.54616685
              type: number
              description: Futures profit and loss
            futures_session_rpl:
              example: 1.309136
              type: number
              description: Futures session realized profit and loss
            futures_session_upl:
              example: -164.48253509
              type: number
              description: Futures session unrealized profit and loss
            options_pl:
              example: 921.55562578
              type: number
              description: Options profit and loss
            options_session_rpl:
              example: 0
              type: number
              description: Options session realized profit and loss
            options_session_upl:
              example: -174.67960675
              type: number
              description: Options session unrealized profit and loss
            options_value:
              example: -1056.41256672
              type: number
              description: Options value
            options_delta:
              example: 2883.38481
              type: number
              description: Options summary delta
            options_gamma:
              example: -0.03907
              type: number
              description: Options summary gamma
            options_theta:
              example: 142583.29246
              type: number
              description: Options summary theta
            options_vega:
              example: -39322.23046
              type: number
              description: Options summary vega
            options_gamma_map:
              type: object
              description: Map of options' gammas per index
            options_theta_map:
              type: object
              description: Map of options' thetas per index
            options_vega_map:
              type: object
              description: Map of options' vegas per index
            delta_total:
              $ref: '#/components/schemas/delta_total'
            delta_total_map:
              type: object
              description: Map of total deltas per index
            projected_delta_total:
              $ref: '#/components/schemas/projected_delta_total'
            additional_reserve:
              $ref: '#/components/schemas/additional_reserve'
            spot_reserve:
              example: 0
              type: number
              description: The account's balance reserved in active spot orders
            fee_balance:
              $ref: '#/components/schemas/fee_balance'
            locked_balance:
              example: 0
              type: number
              description: The account's locked balance
            margin_model:
              type: string
              example: cross_pm
              description: Name of user's currently enabled margin model
            portfolio_margining_enabled:
              type: boolean
              example: true
              description: '`true` when portfolio margining is enabled for user'
            cross_collateral_enabled:
              type: boolean
              example: true
              description: When `true` cross collateral is enabled for user
            total_equity_usd:
              example: 13075634611389.318
              type: number
              description: >-
                Optional (only for users using cross margin). The account's
                total equity in all cross collateral currencies, expressed in
                USD
            total_initial_margin_usd:
              example: 3139528603778.822
              type: number
              description: >-
                Optional (only for users using cross margin). The account's
                total initial margin in all cross collateral currencies,
                expressed in USD
            total_maintenance_margin_usd:
              example: 2511559381417.215
              type: number
              description: >-
                Optional (only for users using cross margin). The account's
                total maintenance margin in all cross collateral currencies,
                expressed in USD
            total_margin_balance_usd:
              example: 12798550648250.61
              type: number
              description: >-
                Optional (only for users using cross margin). The account's
                total margin balance in all cross collateral currencies,
                expressed in USD
            total_delta_total_usd:
              example: 6157454218.3753195
              type: number
              description: >-
                Optional (only for users using cross margin). The account's
                total delta total in all cross collateral currencies, expressed
                in USD
          description: Portfolio margin simulation result
      required:
        - jsonrpc
        - result
      type: object
    projected_initial_margin:
      example: 1
      type: number
      description: >-
        Projected initial margin. When cross collateral is enabled, this
        aggregated value is calculated by converting the sum of each cross
        collateral currency's value to the given currency, using each cross
        collateral currency's index.
    projected_maintenance_margin:
      example: 1
      type: number
      description: >-
        Projected maintenance margin. When cross collateral is enabled, this
        aggregated value is calculated by converting the sum of each cross
        collateral currency's value to the given currency, using each cross
        collateral currency's index.
    rpl:
      example: 0.1
      type: number
      description: Session realized profit and loss
    upl:
      example: 0.846863
      type: number
      description: Session unrealized profit and loss
    delta_total:
      example: 0.1334
      type: number
      description: >
        The sum of position deltas. 


        **DeltaTotal = Net Transaction Delta of options + BTC Position of
        Futures**


        The DeltaTotal uses the Net Transaction Delta (or price adjusted Delta)
        of the options, where Net Transaction Delta = Black Scholes Delta - Mark
        Price of Options.


        This is because, from a risk perspective, we are interested in the
        change in Bitcoin price as the underlying changes.


        You should actually treat your delta as **Equity + Delta Total** if you
        want to have less risk for your USD PnL.


        ⚠️ **During the 30 minute settlement period we decay your Delta.** See
        [Delta decay during
        settlement](https://support.deribit.com/hc/en-us/articles/25944751433757-Delta-decay-during-settlement)
        for more details.
    projected_delta_total:
      example: 0.1334
      type: number
      description: >-
        The sum of position deltas without positions that will expire during
        closest expiration
    additional_reserve:
      example: 0.3
      type: number
      description: The account's balance reserved in other orders
    fee_balance:
      type: number
      description: The account's fee balance (it can be used to pay for fees)
  responses:
    PrivateSimulatePortfolioResponse:
      content:
        application/json:
          schema:
            $ref: '#/components/schemas/PrivateSimulatePortfolioResponse'
          examples:
            response:
              value:
                jsonrpc: '2.0'
                id: 2
                result:
                  projected_initial_margin: 37662472.03416069
                  initial_margin: 37662472.03416069
                  total_pl: 40419.10179263
                  additional_reserve: 0
                  available_withdrawal_funds: 115871741.76065847
                  options_pl: 921.55562578
                  delta_total_map:
                    btc_usd: 68024.519462366
                  available_subaccount_transfer_funds: 0
                  projected_delta_total: 69080.932029
                  projected_maintenance_margin: 30129215.84817124
                  total_equity_usd: 13075634611389.318
                  options_gamma: -0.03907
                  currency: BTC
                  options_theta: 142583.29246
                  spot_reserve: 0
                  total_initial_margin_usd: 3139528603778.822
                  options_vega: -39322.23046
                  margin_balance: 153534213.79481918
                  futures_session_rpl: 1.309136
                  options_gamma_map:
                    btc_usd: -0.03907
                  available_funds: 115871741.76065847
                  futures_pl: 39497.54616685
                  cross_collateral_enabled: true
                  delta_total: 69080.932029
                  options_session_rpl: 0
                  total_margin_balance_usd: 12798550648250.61
                  options_value: -1056.41256672
                  options_session_upl: -174.67960675
                  maintenance_margin: 30129215.84817124
                  total_maintenance_margin_usd: 2511559381417.215
                  options_vega_map:
                    btc_usd: -39322.23046
                  session_rpl: 1.309136
                  locked_balance: 0
                  session_upl: -339.16214185
                  margin_model: cross_pm
                  portfolio_margining_enabled: true
                  equity: 150075253.91354558
                  balance: 150076473.4995114
                  total_delta_total_usd: 6157454218.3753195
                  fee_balance: 0
                  options_delta: 2883.38481
                  options_theta_map:
                    btc_usd: 142583.29246
                  futures_session_upl: -164.48253509
                usIn: 1742210019774525
                usOut: 1742210019788175
                usDiff: 13650
                testnet: true
              description: Response example
      description: Success response

````

> ## Documentation Index
> Fetch the complete documentation index at: https://docs.deribit.com/llms.txt
> Use this file to discover all available pages before exploring further.

<AgentInstructions>

## Submitting Feedback

If you encounter incorrect, outdated, or confusing documentation on this page, submit feedback:

POST https://docs.deribit.com/feedback

```json
{
  "path": "/api-reference/account-management/private-toggle_notifications_from_subaccount",
  "feedback": "Description of the issue"
}
```

Only submit feedback when you have something specific and actionable to report.

</AgentInstructions>

# private/toggle_notifications_from_subaccount

> Enables or disables email and other notifications for a subaccount. When notifications are disabled, the subaccount will not receive email alerts, trade confirmations, or other notification messages.

This setting only affects notifications sent to the subaccount's email address. Notifications sent to the main account are not affected.

**[TFA required](https://docs.deribit.com/articles/security-keys)**

**📖 Related Article:** [Managing Subaccounts](https://docs.deribit.com/articles/managing-subaccounts-api)

**Scope:** `account:read_write`

[Try in API console](https://test.deribit.com/api_console?method=%2Fprivate%2Ftoggle_notifications_from_subaccount)





## OpenAPI

````yaml /specifications/deribit_openapi.json get /private/toggle_notifications_from_subaccount
openapi: 3.0.0
info:
  title: Deribit API
  version: 2.1.1
servers:
  - url: https://test.deribit.com/api/v2
security: []
tags:
  - name: WebSocket Only
    description: Can only be used over websockets.
  - name: Public
    description: Public methods can be used without authentication.
  - name: Private
    description: >-
      <p>Private methods require authentication. All requests must include a
      valid OAuth2 token.</p>

      <p>A token can be requested using the <a
      href="#public-auth">/public/auth</a> method.</p>

      <p>When using the websockets protocol, the token must be included as a
      parameter <code>access_token</code> in the message. When using REST (HTTP
      GET), the token may also be passed in the <code>Authorization</code>
      header.</p>
  - name: Authentication
  - name: Session Management
  - name: Subscription Management
    description: >-
      Subscription works as [notifications](#notifications), so users will
      automatically (after subscribing) receive messages from the server.
      Overview for each channel response format is described in
      [subscriptions](#subscriptions) section.
  - name: Account Management
  - name: Trading
  - name: Market Data
  - name: Wallet
  - name: Chat
paths:
  /private/toggle_notifications_from_subaccount:
    get:
      tags:
        - Account Management
        - Private
      description: >+
        Enables or disables email and other notifications for a subaccount. When
        notifications are disabled, the subaccount will not receive email
        alerts, trade confirmations, or other notification messages.


        This setting only affects notifications sent to the subaccount's email
        address. Notifications sent to the main account are not affected.


        **[TFA required](https://docs.deribit.com/articles/security-keys)**


        **📖 Related Article:** [Managing
        Subaccounts](https://docs.deribit.com/articles/managing-subaccounts-api)


        **Scope:** `account:read_write`


        [Try in API
        console](https://test.deribit.com/api_console?method=%2Fprivate%2Ftoggle_notifications_from_subaccount)

      parameters:
        - name: sid
          in: query
          schema:
            type: integer
            example: 7
          required: true
          description: The user id for the subaccount
        - name: state
          in: query
          schema:
            type: boolean
            example: true
          required: true
          description: enable (`true`) or disable (`false`) notifications
      requestBody:
        content:
          application/json:
            examples:
              request:
                value:
                  jsonrpc: '2.0'
                  id: 9995
                  method: private/toggle_notifications_from_subaccount
                  params:
                    sid: 7
                    state: true
                description: JSON-RPC Request Example
        description: JSON-RPC request body
      responses:
        '200':
          $ref: '#/components/responses/OkResponse'
components:
  responses:
    OkResponse:
      content:
        application/json:
          schema:
            $ref: '#/components/schemas/OkResponse'
          examples:
            response:
              value:
                jsonrpc: '2.0'
                id: 1569
                result: ok
              description: Response example
      description: Success response
  schemas:
    OkResponse:
      properties:
        jsonrpc:
          type: string
          enum:
            - '2.0'
          description: The JSON-RPC version (2.0)
        id:
          type: integer
          description: The id that was sent in the request
        result:
          type: string
          enum:
            - ok
          description: Result of method execution. `ok` in case of success
      required:
        - jsonrpc
        - result
      type: object

````

> ## Documentation Index
> Fetch the complete documentation index at: https://docs.deribit.com/llms.txt
> Use this file to discover all available pages before exploring further.

<AgentInstructions>

## Submitting Feedback

If you encounter incorrect, outdated, or confusing documentation on this page, submit feedback:

POST https://docs.deribit.com/feedback

```json
{
  "path": "/api-reference/account-management/private-toggle_subaccount_login",
  "feedback": "Description of the issue"
}
```

Only submit feedback when you have something specific and actionable to report.

</AgentInstructions>

# private/toggle_subaccount_login

> Enables or disables direct login access for a subaccount. When login is disabled, the subaccount cannot be accessed directly using email and password authentication, but can still be accessed through the main account.

If login is disabled while an active session exists for the subaccount, that session will be immediately terminated.

**[TFA required](https://docs.deribit.com/articles/security-keys)**

**📖 Related Article:** [Managing Subaccounts](https://docs.deribit.com/articles/managing-subaccounts-api)

**Scope:** `account:read_write`

[Try in API console](https://test.deribit.com/api_console?method=%2Fprivate%2Ftoggle_subaccount_login)





## OpenAPI

````yaml /specifications/deribit_openapi.json get /private/toggle_subaccount_login
openapi: 3.0.0
info:
  title: Deribit API
  version: 2.1.1
servers:
  - url: https://test.deribit.com/api/v2
security: []
tags:
  - name: WebSocket Only
    description: Can only be used over websockets.
  - name: Public
    description: Public methods can be used without authentication.
  - name: Private
    description: >-
      <p>Private methods require authentication. All requests must include a
      valid OAuth2 token.</p>

      <p>A token can be requested using the <a
      href="#public-auth">/public/auth</a> method.</p>

      <p>When using the websockets protocol, the token must be included as a
      parameter <code>access_token</code> in the message. When using REST (HTTP
      GET), the token may also be passed in the <code>Authorization</code>
      header.</p>
  - name: Authentication
  - name: Session Management
  - name: Subscription Management
    description: >-
      Subscription works as [notifications](#notifications), so users will
      automatically (after subscribing) receive messages from the server.
      Overview for each channel response format is described in
      [subscriptions](#subscriptions) section.
  - name: Account Management
  - name: Trading
  - name: Market Data
  - name: Wallet
  - name: Chat
paths:
  /private/toggle_subaccount_login:
    get:
      tags:
        - Account Management
        - Private
      description: >+
        Enables or disables direct login access for a subaccount. When login is
        disabled, the subaccount cannot be accessed directly using email and
        password authentication, but can still be accessed through the main
        account.


        If login is disabled while an active session exists for the subaccount,
        that session will be immediately terminated.


        **[TFA required](https://docs.deribit.com/articles/security-keys)**


        **📖 Related Article:** [Managing
        Subaccounts](https://docs.deribit.com/articles/managing-subaccounts-api)


        **Scope:** `account:read_write`


        [Try in API
        console](https://test.deribit.com/api_console?method=%2Fprivate%2Ftoggle_subaccount_login)

      parameters:
        - name: sid
          in: query
          schema:
            type: integer
            example: 7
          required: true
          description: The user id for the subaccount
        - name: state
          in: query
          schema:
            type: string
            enum:
              - enable
              - disable
            example: enable
          required: true
          description: enable or disable login.
      requestBody:
        content:
          application/json:
            examples:
              request:
                value:
                  jsonrpc: '2.0'
                  id: 938
                  method: private/toggle_subaccount_login
                  params:
                    sid: 7
                    state: enable
                description: JSON-RPC Request Example
        description: JSON-RPC request body
      responses:
        '200':
          $ref: '#/components/responses/OkResponse'
components:
  responses:
    OkResponse:
      content:
        application/json:
          schema:
            $ref: '#/components/schemas/OkResponse'
          examples:
            response:
              value:
                jsonrpc: '2.0'
                id: 1569
                result: ok
              description: Response example
      description: Success response
  schemas:
    OkResponse:
      properties:
        jsonrpc:
          type: string
          enum:
            - '2.0'
          description: The JSON-RPC version (2.0)
        id:
          type: integer
          description: The id that was sent in the request
        result:
          type: string
          enum:
            - ok
          description: Result of method execution. `ok` in case of success
      required:
        - jsonrpc
        - result
      type: object

````

> ## Documentation Index
> Fetch the complete documentation index at: https://docs.deribit.com/llms.txt
> Use this file to discover all available pages before exploring further.

<AgentInstructions>

## Submitting Feedback

If you encounter incorrect, outdated, or confusing documentation on this page, submit feedback:

POST https://docs.deribit.com/feedback

```json
{
  "path": "/api-reference/account-management/public-get_announcements",
  "feedback": "Description of the issue"
}
```

Only submit feedback when you have something specific and actionable to report.

</AgentInstructions>

# public/get_announcements

> Retrieves platform announcements and important notices. Announcements include system updates, maintenance schedules, new features, policy changes, and other important information.

Results are returned in reverse chronological order (newest first). The default `start_timestamp` is the current time, and the `count` parameter must be between 1 and 50 (default is 5).

[Try in API console](https://test.deribit.com/api_console?method=%2Fpublic%2Fget_announcements)





## OpenAPI

````yaml /specifications/deribit_openapi.json get /public/get_announcements
openapi: 3.0.0
info:
  title: Deribit API
  version: 2.1.1
servers:
  - url: https://test.deribit.com/api/v2
security: []
tags:
  - name: WebSocket Only
    description: Can only be used over websockets.
  - name: Public
    description: Public methods can be used without authentication.
  - name: Private
    description: >-
      <p>Private methods require authentication. All requests must include a
      valid OAuth2 token.</p>

      <p>A token can be requested using the <a
      href="#public-auth">/public/auth</a> method.</p>

      <p>When using the websockets protocol, the token must be included as a
      parameter <code>access_token</code> in the message. When using REST (HTTP
      GET), the token may also be passed in the <code>Authorization</code>
      header.</p>
  - name: Authentication
  - name: Session Management
  - name: Subscription Management
    description: >-
      Subscription works as [notifications](#notifications), so users will
      automatically (after subscribing) receive messages from the server.
      Overview for each channel response format is described in
      [subscriptions](#subscriptions) section.
  - name: Account Management
  - name: Trading
  - name: Market Data
  - name: Wallet
  - name: Chat
paths:
  /public/get_announcements:
    get:
      tags:
        - Account Management
        - Public
      description: >+
        Retrieves platform announcements and important notices. Announcements
        include system updates, maintenance schedules, new features, policy
        changes, and other important information.


        Results are returned in reverse chronological order (newest first). The
        default `start_timestamp` is the current time, and the `count` parameter
        must be between 1 and 50 (default is 5).


        [Try in API
        console](https://test.deribit.com/api_console?method=%2Fpublic%2Fget_announcements)

      parameters:
        - name: start_timestamp
          in: query
          schema:
            $ref: '#/components/schemas/timestamp'
            default: Current time
          description: >-
            The most recent timestamp to return the results for (milliseconds
            since the UNIX epoch)
          required: false
        - name: count
          in: query
          schema:
            type: integer
            default: 5
            example: 10
            maximum: 50
            minimum: 1
          description: >-
            Maximum count of returned announcements, default - `5`, maximum -
            `50`
          required: false
      requestBody:
        content:
          application/json:
            examples:
              request:
                value:
                  jsonrpc: '2.0'
                  id: 7661
                  method: public/get_announcements
                  params: {}
                description: JSON-RPC Request Example
        description: JSON-RPC request body
      responses:
        '200':
          $ref: '#/components/responses/PublicGetAnnouncementsResponse'
components:
  schemas:
    timestamp:
      example: 1536569522277
      type: integer
      description: The timestamp (milliseconds since the Unix epoch)
    PublicGetAnnouncementsResponse:
      properties:
        jsonrpc:
          type: string
          enum:
            - '2.0'
          description: The JSON-RPC version (2.0)
        id:
          type: integer
          description: The id that was sent in the request
        result:
          type: array
          items:
            properties:
              body:
                example: An&nbsp;announcement
                type: string
                description: The HTML body of the announcement
              publication_timestamp:
                example: 1527844253000
                type: integer
                description: >-
                  The timestamp (milliseconds since the Unix epoch) of
                  announcement publication
              id:
                example: 19288317
                type: number
                description: A unique identifier for the announcement
              important:
                example: false
                type: boolean
                description: Whether the announcement is marked as important
              confirmation:
                type: boolean
                example: false
                description: >-
                  Whether the user confirmation is required for this
                  announcement
              title:
                example: Example announcement
                type: string
                description: The title of the announcement
            required:
              - title
              - body
              - important
              - id
              - publication_timestamp
            type: object
      required:
        - jsonrpc
        - result
      type: object
  responses:
    PublicGetAnnouncementsResponse:
      content:
        application/json:
          schema:
            $ref: '#/components/schemas/PublicGetAnnouncementsResponse'
          examples:
            response:
              value:
                jsonrpc: '2.0'
                id: 3022
                result:
                  - title: Example announcement
                    publication_timestamp: 1550058362418
                    important: false
                    id: 1550058362418
                    body: Lorem ipsum dolor sit amet, consectetur adipiscing elit.
              description: Response example
      description: Success response

````

