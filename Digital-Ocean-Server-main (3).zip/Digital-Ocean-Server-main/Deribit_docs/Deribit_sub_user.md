> ## Documentation Index
> Fetch the complete documentation index at: https://docs.deribit.com/llms.txt
> Use this file to discover all available pages before exploring further.

<AgentInstructions>

## Submitting Feedback

If you encounter incorrect, outdated, or confusing documentation on this page, submit feedback:

POST https://docs.deribit.com/feedback

```json
{
  "path": "/subscriptions/user/usermmp_triggerindex_name",
  "feedback": "Description of the issue"
}
```

Only submit feedback when you have something specific and actionable to report.

</AgentInstructions>

# user.mmp_trigger.(index_name) 

> Real-time notifications for Market Maker Protection (MMP) triggers. This subscription provides feedback when MMP protection is activated for a given index, enabling clients to react promptly when protection is triggered.

Upon MMP being triggered for a given index, the client will receive a trigger notification containing:

- **frozen_until**: Unix timestamp in milliseconds indicating until when the MMP is active (orders remain blocked). If `frozen_until: 0`, it means MMP will remain active until manually reset using the `private/reset_mmp` method.
- **index_name**: Index identifier of derivative instrument on the platform. For Block RFQ MMP, this will be "all" when triggered by trade count limit.
- **mmp_group**: Triggered MMP group (optional, appears only for Mass Quote orders trigger)
- **block_rfq**: If true, indicates that the MMP trigger is for Block RFQ. Block RFQ MMP triggers are completely separate from normal order/quote MMP triggers.

This notification allows the client to track MMP state per index and avoid submitting new orders that would be rejected due to ongoing MMP freeze.

**📖 Related Article:** [Market Maker Protection API Configuration](https://docs.deribit.com/articles/market-maker-protection)




## AsyncAPI

````yaml specifications/deribit_asyncapi.json user.mmp_trigger.(index_name)
id: user.mmp_trigger.(index_name)
title: 'user.mmp_trigger.(index_name) '
description: >
  Real-time notifications for Market Maker Protection (MMP) triggers. This
  subscription provides feedback when MMP protection is activated for a given
  index, enabling clients to react promptly when protection is triggered.


  Upon MMP being triggered for a given index, the client will receive a trigger
  notification containing:


  - **frozen_until**: Unix timestamp in milliseconds indicating until when the
  MMP is active (orders remain blocked). If `frozen_until: 0`, it means MMP will
  remain active until manually reset using the `private/reset_mmp` method.

  - **index_name**: Index identifier of derivative instrument on the platform.
  For Block RFQ MMP, this will be "all" when triggered by trade count limit.

  - **mmp_group**: Triggered MMP group (optional, appears only for Mass Quote
  orders trigger)

  - **block_rfq**: If true, indicates that the MMP trigger is for Block RFQ.
  Block RFQ MMP triggers are completely separate from normal order/quote MMP
  triggers.


  This notification allows the client to track MMP state per index and avoid
  submitting new orders that would be rejected due to ongoing MMP freeze.


  **📖 Related Article:** [Market Maker Protection API
  Configuration](https://docs.deribit.com/articles/market-maker-protection)
servers:
  - id: production
    protocol: wss
    host: deribit.com/ws/api/v2
    bindings: []
    variables: []
  - id: testnet
    protocol: wss
    host: test.deribit.com/ws/api/v2
    bindings: []
    variables: []
address: user.mmp_trigger.(index_name)
parameters:
  - id: index_name
    jsonSchema:
      type: string
      description: >-
        Index identifier, matches (base) cryptocurrency with quote currency


        **Allowed values:** `btc_usd`, `eth_usd`, `ada_usdc`, `algo_usdc`,
        `avax_usdc`, ... (total 47 values)
      enum:
        - btc_usd
        - eth_usd
        - ada_usdc
        - algo_usdc
        - avax_usdc
        - bch_usdc
        - bnb_usdc
        - btc_usdc
        - btcdvol_usdc
        - buidl_usdc
        - doge_usdc
        - dot_usdc
        - eurr_usdc
        - eth_usdc
        - ethdvol_usdc
        - link_usdc
        - ltc_usdc
        - near_usdc
        - paxg_usdc
        - shib_usdc
        - sol_usdc
        - steth_usdc
        - ton_usdc
        - trump_usdc
        - trx_usdc
        - uni_usdc
        - usde_usdc
        - usyc_usdc
        - xrp_usdc
        - btc_usdt
        - eth_usdt
        - eurr_usdt
        - sol_usdt
        - steth_usdt
        - usdc_usdt
        - usde_usdt
        - btc_eurr
        - btc_usde
        - btc_usyc
        - eth_btc
        - eth_eurr
        - eth_usde
        - eth_usyc
        - steth_eth
        - paxg_btc
        - drbfix-btc_usdc
        - drbfix-eth_usdc
    description: >-
      Index identifier, matches (base) cryptocurrency with quote currency


      **Allowed values:** `btc_usd`, `eth_usd`, `ada_usdc`, `algo_usdc`,
      `avax_usdc`, ... (total 47 values)
    type: string
    required: true
    deprecated: false
bindings: []
operations:
  - &ref_2
    id: send_subscribe_user_mmp_trigger_index_name
    title: Send subscribe request for user
    description: Client sends subscription request for user updates
    type: send
    messages:
      - &ref_4
        id: subscription_message
        contentType: application/json
        payload:
          - name: Subscription Notification Data
            description: Server sends subscription notification data
            type: object
            properties:
              - name: data
                type: object
                required: true
                properties:
                  - name: frozen_until
                    type: integer
                    description: >-
                      Timestamp (milliseconds since the UNIX epoch) until the
                      user will be frozen - 0 means that the user is frozen
                      until manual reset.
                    required: false
                  - name: index_name
                    type: string
                    description: >-
                      Index identifier of derivative instrument on the platform.
                      For Block RFQ MMP, this will be "all" when triggered by
                      trade count limit.
                    required: false
                  - name: mmp_group
                    type: string
                    description: >-
                      Triggered mmp group, this parameter is optional (appears
                      only for Mass Quote orders trigger)
                    required: false
                  - name: block_rfq
                    type: boolean
                    description: >-
                      If true, indicates that the MMP trigger is for Block RFQ.
                      Block RFQ MMP triggers are completely separate from normal
                      order/quote MMP triggers.
                    required: false
        headers: []
        jsonPayloadSchema:
          type: object
          description: Response containing notification data
          properties:
            data:
              type: object
              properties:
                frozen_until:
                  type: integer
                  description: >-
                    Timestamp (milliseconds since the UNIX epoch) until the user
                    will be frozen - 0 means that the user is frozen until
                    manual reset.
                  example: 0
                  x-parser-schema-id: <anonymous-schema-303>
                index_name:
                  type: string
                  description: >-
                    Index identifier of derivative instrument on the platform.
                    For Block RFQ MMP, this will be "all" when triggered by
                    trade count limit.
                  example: eth_usdc
                  x-parser-schema-id: <anonymous-schema-304>
                mmp_group:
                  type: string
                  description: >-
                    Triggered mmp group, this parameter is optional (appears
                    only for Mass Quote orders trigger)
                  example: MassQuoteBot7
                  x-parser-schema-id: <anonymous-schema-305>
                block_rfq:
                  type: boolean
                  description: >-
                    If true, indicates that the MMP trigger is for Block RFQ.
                    Block RFQ MMP triggers are completely separate from normal
                    order/quote MMP triggers.
                  x-parser-schema-id: <anonymous-schema-306>
              required:
                - frozen_until
              additionalProperties: false
              x-parser-schema-id: <anonymous-schema-302>
          required:
            - data
          additionalProperties: false
          x-parser-schema-id: <anonymous-schema-301>
        title: Subscription Notification Data
        description: Server sends subscription notification data
        example: |-
          {
            "data": {
              "frozen_until": 123,
              "index_name": "<string>",
              "mmp_group": "<string>",
              "block_rfq": true
            }
          }
        bindings: []
        extensions:
          - id: x-parser-unique-object-id
            value: subscription_message
    bindings: []
    extensions: &ref_0
      - id: x-parser-unique-object-id
        value: user.mmp_trigger.(index_name)
  - &ref_1
    id: receive_user_mmp_trigger_index_name_updates
    title: Receive user updates
    description: Client receives user update notifications
    type: receive
    messages:
      - &ref_3
        id: subscribe_request
        contentType: application/json
        payload:
          - name: Subscription Request
            description: >-
              Client sends subscription request to subscribe to notification
              channel. Please refer to [Notification
              page](https://deribit.mintlify.app/articles/notifications) for
              more information.
            type: object
            properties: []
        headers: []
        jsonPayloadSchema:
          properties: {}
          additionalProperties: false
          x-parser-schema-id: <anonymous-schema-300>
        title: Subscription Request
        description: >-
          Client sends subscription request to subscribe to notification
          channel. Please refer to [Notification
          page](https://deribit.mintlify.app/articles/notifications) for more
          information.
        example: |-
          {
            "jsonrpc": "2.0",
            "method": "public/subscribe",
            "id": 42,
            "params": {
              "channels": [
                "user.mmp_trigger.(index_name)"
              ]
            }
          }
        bindings: []
        extensions:
          - id: x-parser-unique-object-id
            value: subscribe_request
    bindings: []
    extensions: *ref_0
sendOperations:
  - *ref_1
receiveOperations:
  - *ref_2
sendMessages:
  - *ref_3
receiveMessages:
  - *ref_4
extensions:
  - id: x-parser-unique-object-id
    value: user.mmp_trigger.(index_name)
securitySchemes: []

````


> ## Documentation Index
> Fetch the complete documentation index at: https://docs.deribit.com/llms.txt
> Use this file to discover all available pages before exploring further.

<AgentInstructions>

## Submitting Feedback

If you encounter incorrect, outdated, or confusing documentation on this page, submit feedback:

POST https://docs.deribit.com/feedback

```json
{
  "path": "/subscriptions/user/userportfoliocurrency",
  "feedback": "Description of the issue"
}
```

Only submit feedback when you have something specific and actionable to report.

</AgentInstructions>

# user.portfolio.(currency) 

> Real-time notifications for user portfolio information. This subscription provides comprehensive account and portfolio data for the specified currency, including balances, margins, profit and loss, and Greeks.

Each notification includes:

- **Account balances:** Current balance, equity, margin balance, available funds, and available withdrawal funds
- **Margin information:** Initial margin, maintenance margin, and projected margins
- **Profit and Loss:** Total P&L, session unrealized P&L (UPL), session realized P&L (RPL), and separate P&L for options and futures
- **Options Greeks:** Delta, gamma, theta, vega, and options value, with per-index mappings
- **Position data:** Delta total, projected delta total, and delta total map per index
- **Account settings:** Portfolio margining status, cross collateral status, and margin model
- **Cross collateral data:** Total equity, margins, and delta in USD (when cross collateral is enabled)
- **Additional reserves:** Fee balance and additional reserve information

When cross collateral is enabled, aggregated values are calculated by converting the sum of each cross collateral currency's value to the given currency, using each cross collateral currency's index.

Subscribe to a specific currency (BTC, ETH, USDC, USDT, etc.) or use `any` to receive portfolio updates for all currencies.




## AsyncAPI

````yaml specifications/deribit_asyncapi.json user.portfolio.(currency)
id: user.portfolio.(currency)
title: 'user.portfolio.(currency) '
description: >
  Real-time notifications for user portfolio information. This subscription
  provides comprehensive account and portfolio data for the specified currency,
  including balances, margins, profit and loss, and Greeks.


  Each notification includes:


  - **Account balances:** Current balance, equity, margin balance, available
  funds, and available withdrawal funds

  - **Margin information:** Initial margin, maintenance margin, and projected
  margins

  - **Profit and Loss:** Total P&L, session unrealized P&L (UPL), session
  realized P&L (RPL), and separate P&L for options and futures

  - **Options Greeks:** Delta, gamma, theta, vega, and options value, with
  per-index mappings

  - **Position data:** Delta total, projected delta total, and delta total map
  per index

  - **Account settings:** Portfolio margining status, cross collateral status,
  and margin model

  - **Cross collateral data:** Total equity, margins, and delta in USD (when
  cross collateral is enabled)

  - **Additional reserves:** Fee balance and additional reserve information


  When cross collateral is enabled, aggregated values are calculated by
  converting the sum of each cross collateral currency's value to the given
  currency, using each cross collateral currency's index.


  Subscribe to a specific currency (BTC, ETH, USDC, USDT, etc.) or use `any` to
  receive portfolio updates for all currencies.
servers:
  - id: production
    protocol: wss
    host: deribit.com/ws/api/v2
    bindings: []
    variables: []
  - id: testnet
    protocol: wss
    host: test.deribit.com/ws/api/v2
    bindings: []
    variables: []
address: user.portfolio.(currency)
parameters:
  - id: currency
    jsonSchema:
      type: string
      description: |-
        Currency code or `any` for all

        **Allowed values:** `BTC`, `ETH`, `USDC`, `USDT`, `EURR`, `any`
      enum:
        - BTC
        - ETH
        - USDC
        - USDT
        - EURR
        - any
    description: |-
      Currency code or `any` for all

      **Allowed values:** `BTC`, `ETH`, `USDC`, `USDT`, `EURR`, `any`
    type: string
    required: true
    deprecated: false
bindings: []
operations:
  - &ref_2
    id: send_subscribe_user_portfolio_currency
    title: Send subscribe request for user
    description: Client sends subscription request for user updates
    type: send
    messages:
      - &ref_4
        id: subscription_message
        contentType: application/json
        payload:
          - name: Subscription Notification Data
            description: Server sends subscription notification data
            type: object
            properties:
              - name: data
                type: object
                required: true
                properties:
                  - name: currency
                    type: string
                    description: The selected currency
                    required: false
                  - name: equity
                    type: number
                    description: The account's current equity
                    required: false
                  - name: maintenance_margin
                    type: number
                    description: >-
                      The maintenance margin. When cross collateral is enabled,
                      this aggregated value is calculated by converting the sum
                      of each cross collateral currency's value to the given
                      currency, using each cross collateral currency's index.
                    required: false
                  - name: initial_margin
                    type: number
                    description: >-
                      The account's initial margin. When cross collateral is
                      enabled, this aggregated value is calculated by converting
                      the sum of each cross collateral currency's value to the
                      given currency, using each cross collateral currency's
                      index.
                    required: false
                  - name: available_funds
                    type: number
                    description: >-
                      The account's available funds. When cross collateral is
                      enabled, this aggregated value is calculated by converting
                      the sum of each cross collateral currency's value to the
                      given currency, using each cross collateral currency's
                      index.
                    required: false
                  - name: available_withdrawal_funds
                    type: number
                    description: The account's available to withdrawal funds
                    required: false
                  - name: balance
                    type: number
                    description: The account's balance
                    required: false
                  - name: fee_balance
                    type: number
                    description: The account's fee balance (it can be used to pay for fees)
                    required: false
                  - name: margin_balance
                    type: number
                    description: >-
                      The account's margin balance. When cross collateral is
                      enabled, this aggregated value is calculated by converting
                      the sum of each cross collateral currency's value to the
                      given currency, using each cross collateral currency's
                      index.
                    required: false
                  - name: session_upl
                    type: number
                    description: Session unrealized profit and loss
                    required: false
                  - name: session_rpl
                    type: number
                    description: Session realized profit and loss
                    required: false
                  - name: total_pl
                    type: number
                    description: Profit and loss
                    required: false
                  - name: options_pl
                    type: number
                    description: Options profit and Loss
                    required: false
                  - name: options_session_rpl
                    type: number
                    description: Options session realized profit and Loss
                    required: false
                  - name: options_session_upl
                    type: number
                    description: Options session unrealized profit and Loss
                    required: false
                  - name: options_delta
                    type: number
                    description: Options summary delta
                    required: false
                  - name: options_gamma
                    type: number
                    description: Options summary gamma
                    required: false
                  - name: options_theta
                    type: number
                    description: Options summary theta
                    required: false
                  - name: options_value
                    type: number
                    description: Options value
                    required: false
                  - name: options_vega
                    type: number
                    description: Options summary vega
                    required: false
                  - name: futures_pl
                    type: number
                    description: Futures profit and Loss
                    required: false
                  - name: futures_session_rpl
                    type: number
                    description: Futures session realized profit and Loss
                    required: false
                  - name: futures_session_upl
                    type: number
                    description: Futures session unrealized profit and Loss
                    required: false
                  - name: delta_total
                    type: number
                    description: >
                      The sum of position deltas. 


                      **DeltaTotal = Net Transaction Delta of options + BTC
                      Position of Futures**


                      The DeltaTotal uses the Net Transaction Delta (or price
                      adjusted Delta) of the options, where Net Transaction
                      Delta = Black Scholes Delta - Mark Price of Options.


                      This is because, from a risk perspective, we are
                      interested in the change in Bitcoin price as the
                      underlying changes.


                      You should actually treat your delta as **Equity + Delta
                      Total** if you want to have less risk for your USD PnL.


                      ⚠️ **During the 30 minute settlement period we decay your
                      Delta.** See [Delta decay during
                      settlement](https://support.deribit.com/hc/en-us/articles/25944751433757-Delta-decay-during-settlement)
                      for more details.
                    required: false
                  - name: delta_total_map
                    type: object
                    description: Map of position sum's per index
                    required: false
                  - name: options_gamma_map
                    type: object
                    description: Map of options' gammas per index
                    required: false
                  - name: options_theta_map
                    type: object
                    description: Map of options' thetas per index
                    required: false
                  - name: options_vega_map
                    type: object
                    description: Map of options' vegas per index
                    required: false
                  - name: projected_delta_total
                    type: number
                    description: >-
                      The sum of position deltas without positions that will
                      expire during closest expiration
                    required: false
                  - name: portfolio_margining_enabled
                    type: boolean
                    description: When `true` portfolio margining is enabled for user
                    required: false
                  - name: cross_collateral_enabled
                    type: boolean
                    description: When `true` cross collateral is enabled for user
                    required: false
                  - name: margin_model
                    type: string
                    description: Name of user's currently enabled margin model
                    required: false
                  - name: total_equity_usd
                    type: number
                    description: >-
                      Optional (only for users using cross margin). The
                      account's total equity in all cross collateral currencies,
                      expressed in USD
                    required: false
                  - name: total_initial_margin_usd
                    type: number
                    description: >-
                      Optional (only for users using cross margin). The
                      account's total initial margin in all cross collateral
                      currencies, expressed in USD
                    required: false
                  - name: total_maintenance_margin_usd
                    type: number
                    description: >-
                      Optional (only for users using cross margin). The
                      account's total maintenance margin in all cross collateral
                      currencies, expressed in USD
                    required: false
                  - name: total_margin_balance_usd
                    type: number
                    description: >-
                      Optional (only for users using cross margin). The
                      account's total margin balance in all cross collateral
                      currencies, expressed in USD
                    required: false
                  - name: total_delta_total_usd
                    type: number
                    description: >-
                      Optional (only for users using cross margin). The
                      account's total delta total in all cross collateral
                      currencies, expressed in USD
                    required: false
                  - name: projected_initial_margin
                    type: number
                    description: >-
                      Projected initial margin. When cross collateral is
                      enabled, this aggregated value is calculated by converting
                      the sum of each cross collateral currency's value to the
                      given currency, using each cross collateral currency's
                      index.
                    required: false
                  - name: projected_maintenance_margin
                    type: number
                    description: >-
                      Projected maintenance margin. When cross collateral is
                      enabled, this aggregated value is calculated by converting
                      the sum of each cross collateral currency's value to the
                      given currency, using each cross collateral currency's
                      index.
                    required: false
                  - name: estimated_liquidation_ratio
                    type: number
                    description: >-
                      [DEPRECATED] Estimated Liquidation Ratio is returned only
                      for users with `segregated_sm` margin model. Multiplying
                      it by future position's market price returns its estimated
                      liquidation price. Use estimated_liquidation_ratio_map
                      instead.
                    required: false
                  - name: estimated_liquidation_ratio_map
                    type: object
                    description: >-
                      Map of Estimated Liquidation Ratio per index, it is
                      returned only for users with `segregated_sm` margin model.
                      Multiplying it by future position's market price returns
                      its estimated liquidation price.
                    required: false
                  - name: additional_reserve
                    type: number
                    description: The account's balance reserved in other orders
                    required: false
        headers: []
        jsonPayloadSchema:
          type: object
          description: Response containing notification data
          properties:
            data:
              type: object
              properties:
                currency:
                  type: string
                  description: The selected currency
                  example: ETH
                  x-parser-schema-id: <anonymous-schema-311>
                equity:
                  type: number
                  description: The account's current equity
                  example: 2.6437733
                  x-parser-schema-id: <anonymous-schema-312>
                maintenance_margin:
                  type: number
                  description: >-
                    The maintenance margin. When cross collateral is enabled,
                    this aggregated value is calculated by converting the sum of
                    each cross collateral currency's value to the given
                    currency, using each cross collateral currency's index.
                  example: 0.1334519
                  x-parser-schema-id: <anonymous-schema-313>
                initial_margin:
                  type: number
                  description: >-
                    The account's initial margin. When cross collateral is
                    enabled, this aggregated value is calculated by converting
                    the sum of each cross collateral currency's value to the
                    given currency, using each cross collateral currency's
                    index.
                  example: 0.379882
                  x-parser-schema-id: <anonymous-schema-314>
                available_funds:
                  type: number
                  description: >-
                    The account's available funds. When cross collateral is
                    enabled, this aggregated value is calculated by converting
                    the sum of each cross collateral currency's value to the
                    given currency, using each cross collateral currency's
                    index.
                  example: 2.2638913
                  x-parser-schema-id: <anonymous-schema-315>
                available_withdrawal_funds:
                  type: number
                  description: The account's available to withdrawal funds
                  example: 2.26
                  x-parser-schema-id: <anonymous-schema-316>
                balance:
                  type: number
                  description: The account's balance
                  example: 3.4906363
                  x-parser-schema-id: <anonymous-schema-317>
                fee_balance:
                  description: The account's fee balance (it can be used to pay for fees)
                  type: number
                  x-parser-schema-id: <anonymous-schema-318>
                margin_balance:
                  type: number
                  description: >-
                    The account's margin balance. When cross collateral is
                    enabled, this aggregated value is calculated by converting
                    the sum of each cross collateral currency's value to the
                    given currency, using each cross collateral currency's
                    index.
                  example: 2.25
                  x-parser-schema-id: <anonymous-schema-319>
                session_upl:
                  description: Session unrealized profit and loss
                  type: number
                  example: 0.846863
                  x-parser-schema-id: <anonymous-schema-320>
                session_rpl:
                  description: Session realized profit and loss
                  type: number
                  example: 0.1
                  x-parser-schema-id: <anonymous-schema-321>
                total_pl:
                  type: number
                  description: Profit and loss
                  example: 0.02032221
                  x-parser-schema-id: <anonymous-schema-322>
                options_pl:
                  type: number
                  description: Options profit and Loss
                  example: 0
                  x-parser-schema-id: <anonymous-schema-323>
                options_session_rpl:
                  type: number
                  description: Options session realized profit and Loss
                  example: 0
                  x-parser-schema-id: <anonymous-schema-324>
                options_session_upl:
                  type: number
                  description: Options session unrealized profit and Loss
                  example: 0
                  x-parser-schema-id: <anonymous-schema-325>
                options_delta:
                  type: number
                  description: Options summary delta
                  example: 0
                  x-parser-schema-id: <anonymous-schema-326>
                options_gamma:
                  type: number
                  description: Options summary gamma
                  example: 0
                  x-parser-schema-id: <anonymous-schema-327>
                options_theta:
                  type: number
                  description: Options summary theta
                  example: 0
                  x-parser-schema-id: <anonymous-schema-328>
                options_value:
                  type: number
                  description: Options value
                  example: 0
                  x-parser-schema-id: <anonymous-schema-329>
                options_vega:
                  type: number
                  description: Options summary vega
                  example: 0
                  x-parser-schema-id: <anonymous-schema-330>
                futures_pl:
                  type: number
                  description: Futures profit and Loss
                  example: 0
                  x-parser-schema-id: <anonymous-schema-331>
                futures_session_rpl:
                  type: number
                  description: Futures session realized profit and Loss
                  example: 0
                  x-parser-schema-id: <anonymous-schema-332>
                futures_session_upl:
                  type: number
                  description: Futures session unrealized profit and Loss
                  example: 0
                  x-parser-schema-id: <anonymous-schema-333>
                delta_total:
                  description: >
                    The sum of position deltas. 


                    **DeltaTotal = Net Transaction Delta of options + BTC
                    Position of Futures**


                    The DeltaTotal uses the Net Transaction Delta (or price
                    adjusted Delta) of the options, where Net Transaction Delta
                    = Black Scholes Delta - Mark Price of Options.


                    This is because, from a risk perspective, we are interested
                    in the change in Bitcoin price as the underlying changes.


                    You should actually treat your delta as **Equity + Delta
                    Total** if you want to have less risk for your USD PnL.


                    ⚠️ **During the 30 minute settlement period we decay your
                    Delta.** See [Delta decay during
                    settlement](https://support.deribit.com/hc/en-us/articles/25944751433757-Delta-decay-during-settlement)
                    for more details.
                  example: 0.1334
                  type: number
                  x-parser-schema-id: <anonymous-schema-334>
                delta_total_map:
                  type: object
                  description: Map of position sum's per index
                  x-parser-schema-id: <anonymous-schema-335>
                options_gamma_map:
                  type: object
                  description: Map of options' gammas per index
                  x-parser-schema-id: <anonymous-schema-336>
                options_theta_map:
                  type: object
                  description: Map of options' thetas per index
                  x-parser-schema-id: <anonymous-schema-337>
                options_vega_map:
                  type: object
                  description: Map of options' vegas per index
                  x-parser-schema-id: <anonymous-schema-338>
                projected_delta_total:
                  description: >-
                    The sum of position deltas without positions that will
                    expire during closest expiration
                  example: 0.1334
                  type: number
                  x-parser-schema-id: <anonymous-schema-339>
                portfolio_margining_enabled:
                  type: boolean
                  description: When `true` portfolio margining is enabled for user
                  example: true
                  x-parser-schema-id: <anonymous-schema-340>
                cross_collateral_enabled:
                  type: boolean
                  description: When `true` cross collateral is enabled for user
                  example: true
                  x-parser-schema-id: <anonymous-schema-341>
                margin_model:
                  type: string
                  description: Name of user's currently enabled margin model
                  example: segregated_sm
                  x-parser-schema-id: <anonymous-schema-342>
                total_equity_usd:
                  type: number
                  description: >-
                    Optional (only for users using cross margin). The account's
                    total equity in all cross collateral currencies, expressed
                    in USD
                  example: 2.6437733
                  x-parser-schema-id: <anonymous-schema-343>
                total_initial_margin_usd:
                  type: number
                  description: >-
                    Optional (only for users using cross margin). The account's
                    total initial margin in all cross collateral currencies,
                    expressed in USD
                  example: 0.379882
                  x-parser-schema-id: <anonymous-schema-344>
                total_maintenance_margin_usd:
                  type: number
                  description: >-
                    Optional (only for users using cross margin). The account's
                    total maintenance margin in all cross collateral currencies,
                    expressed in USD
                  example: 0.1334519
                  x-parser-schema-id: <anonymous-schema-345>
                total_margin_balance_usd:
                  type: number
                  description: >-
                    Optional (only for users using cross margin). The account's
                    total margin balance in all cross collateral currencies,
                    expressed in USD
                  example: 2.25
                  x-parser-schema-id: <anonymous-schema-346>
                total_delta_total_usd:
                  type: number
                  description: >-
                    Optional (only for users using cross margin). The account's
                    total delta total in all cross collateral currencies,
                    expressed in USD
                  example: 1.8
                  x-parser-schema-id: <anonymous-schema-347>
                projected_initial_margin:
                  description: >-
                    Projected initial margin. When cross collateral is enabled,
                    this aggregated value is calculated by converting the sum of
                    each cross collateral currency's value to the given
                    currency, using each cross collateral currency's index.
                  example: 1
                  type: number
                  x-parser-schema-id: <anonymous-schema-348>
                projected_maintenance_margin:
                  description: >-
                    Projected maintenance margin. When cross collateral is
                    enabled, this aggregated value is calculated by converting
                    the sum of each cross collateral currency's value to the
                    given currency, using each cross collateral currency's
                    index.
                  example: 1
                  type: number
                  x-parser-schema-id: <anonymous-schema-349>
                estimated_liquidation_ratio:
                  type: number
                  description: >-
                    [DEPRECATED] Estimated Liquidation Ratio is returned only
                    for users with `segregated_sm` margin model. Multiplying it
                    by future position's market price returns its estimated
                    liquidation price. Use estimated_liquidation_ratio_map
                    instead.
                  example: 0.0000234
                  x-parser-schema-id: <anonymous-schema-350>
                estimated_liquidation_ratio_map:
                  type: object
                  description: >-
                    Map of Estimated Liquidation Ratio per index, it is returned
                    only for users with `segregated_sm` margin model.
                    Multiplying it by future position's market price returns its
                    estimated liquidation price.
                  x-parser-schema-id: <anonymous-schema-351>
                additional_reserve:
                  description: The account's balance reserved in other orders
                  example: 0.3
                  type: number
                  x-parser-schema-id: <anonymous-schema-352>
              required:
                - currency
                - equity
                - maintenance_margin
                - initial_margin
                - available_funds
                - available_withdrawal_funds
                - balance
                - margin_balance
                - session_upl
                - session_rpl
                - total_pl
                - options_pl
                - options_session_upl
                - options_session_rpl
                - options_delta
                - options_gamma
                - options_value
                - options_vega
                - options_theta
                - options_gamma_map
                - options_vega_map
                - options_theta_map
                - futures_pl
                - futures_session_upl
                - futures_session_rpl
                - delta_total_map
                - projected_delta_total
                - portfolio_margining_enabled
                - cross_collateral_enabled
                - margin_model
                - projected_maintenance_margin
              additionalProperties: false
              x-parser-schema-id: <anonymous-schema-310>
          required:
            - data
          additionalProperties: false
          x-parser-schema-id: <anonymous-schema-309>
        title: Subscription Notification Data
        description: Server sends subscription notification data
        example: |-
          {
            "data": {
              "delta_total_map": {
                "btc_usd": 31.594397699
              },
              "margin_balance": 302.62675921,
              "futures_session_rpl": -0.03311399,
              "options_session_rpl": 0,
              "estimated_liquidation_ratio_map": {
                "btc_usd": 0.10098729140701267
              },
              "session_upl": 0.05341555,
              "estimated_liquidation_ratio": 0.10098729,
              "options_gamma_map": {
                "btc_usd": 0.00001
              },
              "options_vega": 0.07976,
              "options_value": -0.0079,
              "available_withdrawal_funds": 301.35426172,
              "projected_delta_total": 32.613978,
              "maintenance_margin": 0.8854841,
              "total_pl": -0.33014225,
              "options_theta_map": {
                "btc_usd": 16.13825
              },
              "projected_maintenance_margin": 0.7543841,
              "available_funds": 301.38036328,
              "options_delta": -1.01958,
              "balance": 302.60065765,
              "equity": 302.6188592,
              "futures_session_upl": 0.05921555,
              "fee_balance": 0,
              "currency": "BTC",
              "options_session_upl": -0.0058,
              "projected_initial_margin": 1.01529592,
              "options_theta": 16.13825,
              "portfolio_margining_enabled": false,
              "cross_collateral_enabled": false,
              "margin_model": "segregated_sm",
              "options_vega_map": {
                "btc_usd": 0.07976
              },
              "futures_pl": -0.32434225,
              "options_pl": -0.0058,
              "initial_margin": 1.24639592,
              "spot_reserve": 0,
              "delta_total": 31.602298,
              "options_gamma": 0.00001,
              "session_rpl": -0.03311399,
              "additional_reserve": 0
            }
          }
        bindings: []
        extensions:
          - id: x-parser-unique-object-id
            value: subscription_message
    bindings: []
    extensions: &ref_0
      - id: x-parser-unique-object-id
        value: user.portfolio.(currency)
  - &ref_1
    id: receive_user_portfolio_currency_updates
    title: Receive user updates
    description: Client receives user update notifications
    type: receive
    messages:
      - &ref_3
        id: subscribe_request
        contentType: application/json
        payload:
          - name: Subscription Request
            description: >-
              Client sends subscription request to subscribe to notification
              channel. Please refer to [Notification
              page](https://deribit.mintlify.app/articles/notifications) for
              more information.
            type: object
            properties: []
        headers: []
        jsonPayloadSchema:
          properties: {}
          additionalProperties: false
          x-parser-schema-id: <anonymous-schema-308>
        title: Subscription Request
        description: >-
          Client sends subscription request to subscribe to notification
          channel. Please refer to [Notification
          page](https://deribit.mintlify.app/articles/notifications) for more
          information.
        example: |-
          {
            "jsonrpc": "2.0",
            "method": "public/subscribe",
            "id": 42,
            "params": {
              "channels": [
                "user.portfolio.(currency)"
              ]
            }
          }
        bindings: []
        extensions:
          - id: x-parser-unique-object-id
            value: subscribe_request
    bindings: []
    extensions: *ref_0
sendOperations:
  - *ref_1
receiveOperations:
  - *ref_2
sendMessages:
  - *ref_3
receiveMessages:
  - *ref_4
extensions:
  - id: x-parser-unique-object-id
    value: user.portfolio.(currency)
securitySchemes: []

````


> ## Documentation Index
> Fetch the complete documentation index at: https://docs.deribit.com/llms.txt
> Use this file to discover all available pages before exploring further.

<AgentInstructions>

## Submitting Feedback

If you encounter incorrect, outdated, or confusing documentation on this page, submit feedback:

POST https://docs.deribit.com/feedback

```json
{
  "path": "/subscriptions/user/usertradesinstrument_nameinterval",
  "feedback": "Description of the issue"
}
```

Only submit feedback when you have something specific and actionable to report.

</AgentInstructions>

# user.trades.(instrument_name).(interval) 

> User trade notifications for a specific instrument.

Receive private trade events for your account for the given instrument. The `interval` controls how frequently events are aggregated.




## AsyncAPI

````yaml specifications/deribit_asyncapi.json user.trades.(instrument_name).(interval)
id: user.trades.(instrument_name).(interval)
title: 'user.trades.(instrument_name).(interval) '
description: >
  User trade notifications for a specific instrument.


  Receive private trade events for your account for the given instrument. The
  `interval` controls how frequently events are aggregated.
servers:
  - id: production
    protocol: wss
    host: deribit.com/ws/api/v2
    bindings: []
    variables: []
  - id: testnet
    protocol: wss
    host: test.deribit.com/ws/api/v2
    bindings: []
    variables: []
address: user.trades.(instrument_name).(interval)
parameters:
  - id: instrument_name
    jsonSchema:
      type: string
      description: The name of the instrument
    description: The name of the instrument
    type: string
    required: true
    deprecated: false
  - id: interval
    jsonSchema:
      type: string
      description: >-
        Frequency of notifications. Events will be aggregated over this
        interval. The value `raw` means no aggregation will be applied **(Please
        note that `raw` interval is only available to authorized users)**


        **Allowed values:** `raw`, `100ms`, `agg2`
      enum:
        - raw
        - 100ms
        - agg2
    description: >-
      Frequency of notifications. Events will be aggregated over this interval.
      The value `raw` means no aggregation will be applied **(Please note that
      `raw` interval is only available to authorized users)**


      **Allowed values:** `raw`, `100ms`, `agg2`
    type: string
    required: true
    deprecated: false
bindings: []
operations:
  - &ref_2
    id: send_subscribe_user_trades_instrument_name_interval
    title: Send subscribe request for user
    description: Client sends subscription request for user updates
    type: send
    messages:
      - &ref_4
        id: subscription_message
        contentType: application/json
        payload:
          - name: Subscription Notification Data
            description: Server sends subscription notification data
            type: object
            properties:
              - name: data
                type: object
                required: true
                properties:
                  - name: trade_id
                    type: string
                    description: Unique (per currency) trade identifier
                    required: false
                  - name: trade_seq
                    type: integer
                    description: The sequence number of the trade within instrument
                    required: false
                  - name: instrument_name
                    type: string
                    description: Unique instrument identifier
                    required: false
                  - name: timestamp
                    type: integer
                    description: >-
                      The timestamp of the trade (milliseconds since the UNIX
                      epoch)
                    required: false
                  - name: order_type
                    type: string
                    description: 'Order type: `"limit`, `"market"`, or `"liquidation"`'
                    enumValues:
                      - limit
                      - market
                      - liquidation
                    required: false
                  - name: advanced
                    type: string
                    description: >-
                      Advanced type of user order: `"usd"` or `"implv"` (only
                      for options; omitted if not applicable)
                    enumValues:
                      - usd
                      - implv
                    required: false
                  - name: order_id
                    type: string
                    description: >-
                      Id of the user order (maker or taker), i.e. subscriber's
                      order id that took part in the trade
                    required: false
                  - name: matching_id
                    type: string
                    description: Always `null`
                    required: false
                  - name: direction
                    type: string
                    description: 'Direction: `buy`, or `sell`'
                    enumValues:
                      - buy
                      - sell
                    required: false
                  - name: tick_direction
                    type: integer
                    description: >-
                      Direction of the "tick" (`0` = Plus Tick, `1` = Zero-Plus
                      Tick, `2` = Minus Tick, `3` = Zero-Minus Tick).
                    enumValues:
                      - 0
                      - 1
                      - 2
                      - 3
                    required: false
                  - name: index_price
                    type: number
                    description: Index Price at the moment of trade
                    required: false
                  - name: price
                    type: number
                    description: Price in base currency
                    required: false
                  - name: amount
                    type: number
                    description: >-
                      Trade amount. For perpetual and inverse futures the amount
                      is in USD units. For options and linear futures it is the
                      underlying base currency coin.
                    required: false
                  - name: contracts
                    type: number
                    description: >-
                      Trade size in contract units (optional, may be absent in
                      historical trades)
                    required: false
                  - name: iv
                    type: number
                    description: Option implied volatility for the price (Option only)
                    required: false
                  - name: underlying_price
                    type: number
                    description: >-
                      Underlying price for implied volatility calculations
                      (Options only)
                    required: false
                  - name: liquidation
                    type: string
                    description: >-
                      Optional field (only for trades caused by liquidation):
                      `"M"` when maker side of trade was under liquidation,
                      `"T"` when taker side was under liquidation, `"MT"` when
                      both sides of trade were under liquidation
                    enumValues:
                      - M
                      - T
                      - MT
                    required: false
                  - name: liquidity
                    type: string
                    description: >-
                      Describes what was role of users order: `"M"` when it was
                      maker order, `"T"` when it was taker order
                    enumValues:
                      - M
                      - T
                    required: false
                  - name: fee
                    type: number
                    description: User's fee in units of the specified `fee_currency`
                    required: false
                  - name: fee_currency
                    type: string
                    description: Currency, i.e `"BTC"`, `"ETH"`, `"USDC"`
                    enumValues:
                      - BTC
                      - ETH
                      - USDC
                      - USDT
                      - EURR
                    required: false
                  - name: label
                    type: string
                    description: >-
                      User defined label (presented only when previously set for
                      order by user)
                    required: false
                  - name: state
                    type: string
                    description: >-
                      Order state: `"open"`, `"filled"`, `"rejected"`,
                      `"cancelled"`, `"untriggered"` or `"archive"` (if order
                      was archived)
                    enumValues:
                      - open
                      - filled
                      - rejected
                      - cancelled
                      - untriggered
                      - archive
                    required: false
                  - name: block_trade_id
                    type: string
                    description: Block trade id - when trade was part of a block trade
                    required: false
                  - name: block_rfq_id
                    type: integer
                    description: ID of the Block RFQ - when trade was part of the Block RFQ
                    required: false
                  - name: block_rfq_quote_id
                    type: integer
                    description: >-
                      ID of the Block RFQ quote - when trade was part of the
                      Block RFQ
                    required: false
                  - name: reduce_only
                    type: string
                    description: '`true` if user order is reduce-only'
                    required: false
                  - name: post_only
                    type: string
                    description: '`true` if user order is post-only'
                    required: false
                  - name: mmp
                    type: boolean
                    description: '`true` if user order is MMP'
                    required: false
                  - name: risk_reducing
                    type: boolean
                    description: >-
                      `true` if user order is marked by the platform as a risk
                      reducing order (can apply only to orders placed by PM
                      users)
                    required: false
                  - name: api
                    type: boolean
                    description: '`true` if user order was created with API'
                    required: false
                  - name: profit_loss
                    type: number
                    description: Profit and loss in base currency.
                    required: false
                  - name: mark_price
                    type: number
                    description: Mark Price at the moment of trade
                    required: false
                  - name: legs
                    type: array
                    description: >-
                      Optional field containing leg trades if trade is a combo
                      trade (present when querying for **only** combo trades and
                      in `combo_trades` events)
                    required: false
                  - name: combo_id
                    type: string
                    description: >-
                      Optional field containing combo instrument name if the
                      trade is a combo trade
                    required: false
                  - name: combo_trade_id
                    type: number
                    description: >-
                      Optional field containing combo trade identifier if the
                      trade is a combo trade
                    required: false
                  - name: quote_set_id
                    type: string
                    description: >-
                      QuoteSet of the user order (optional, present only for
                      orders placed with `private/mass_quote`)
                    required: false
                  - name: quote_id
                    type: string
                    description: >-
                      QuoteID of the user order (optional, present only for
                      orders placed with `private/mass_quote`)
                    required: false
                  - name: trade_allocations
                    type: object
                    description: >-
                      List of allocations for Block RFQ pre-allocation. Each
                      allocation specifies `user_id`, `amount`, and `fee` for
                      the allocated part of the trade. For broker client
                      allocations, a `client_info` object will be included.
                    required: false
                    properties:
                      - name: user_id
                        type: integer
                        description: >-
                          User ID to which part of the trade is allocated. For
                          brokers the User ID is obstructed.
                        required: false
                      - name: amount
                        type: number
                        description: Amount allocated to this user.
                        required: false
                      - name: fee
                        type: number
                        description: Fee for the allocated part of the trade.
                        required: false
                      - name: client_info
                        type: object
                        description: Optional client allocation info for brokers.
                        required: false
                        properties:
                          - name: client_id
                            type: integer
                            description: >-
                              ID of a client; available to broker. Represents a
                              group of users under a common name.
                            required: false
                          - name: client_link_id
                            type: integer
                            description: >-
                              ID assigned to a single user in a client;
                              available to broker.
                            required: false
                          - name: name
                            type: string
                            description: >-
                              Name of the linked user within the client;
                              available to broker.
                            required: false
        headers: []
        jsonPayloadSchema:
          type: object
          description: Response containing notification data
          properties:
            data:
              type: object
              description: ''
              properties:
                trade_id:
                  type: string
                  description: Unique (per currency) trade identifier
                  x-parser-schema-id: <anonymous-schema-358>
                trade_seq:
                  description: The sequence number of the trade within instrument
                  type: integer
                  x-parser-schema-id: <anonymous-schema-359>
                instrument_name:
                  type: string
                  description: Unique instrument identifier
                  example: BTC-PERPETUAL
                  x-parser-schema-id: <anonymous-schema-360>
                timestamp:
                  description: >-
                    The timestamp of the trade (milliseconds since the UNIX
                    epoch)
                  example: 1517329113791
                  type: integer
                  x-parser-schema-id: <anonymous-schema-361>
                order_type:
                  type: string
                  description: 'Order type: `"limit`, `"market"`, or `"liquidation"`'
                  enum:
                    - limit
                    - market
                    - liquidation
                  x-parser-schema-id: <anonymous-schema-362>
                advanced:
                  type: string
                  description: >-
                    Advanced type of user order: `"usd"` or `"implv"` (only for
                    options; omitted if not applicable)
                  enum:
                    - usd
                    - implv
                  x-parser-schema-id: <anonymous-schema-363>
                order_id:
                  type: string
                  description: >-
                    Id of the user order (maker or taker), i.e. subscriber's
                    order id that took part in the trade
                  x-parser-schema-id: <anonymous-schema-364>
                matching_id:
                  type: string
                  description: Always `null`
                  x-parser-schema-id: <anonymous-schema-365>
                direction:
                  type: string
                  description: 'Direction: `buy`, or `sell`'
                  enum:
                    - buy
                    - sell
                  x-parser-schema-id: <anonymous-schema-366>
                tick_direction:
                  type: integer
                  enum:
                    - 0
                    - 1
                    - 2
                    - 3
                  description: >-
                    Direction of the "tick" (`0` = Plus Tick, `1` = Zero-Plus
                    Tick, `2` = Minus Tick, `3` = Zero-Minus Tick).
                  x-parser-schema-id: <anonymous-schema-367>
                index_price:
                  type: number
                  description: Index Price at the moment of trade
                  x-parser-schema-id: <anonymous-schema-368>
                price:
                  description: Price in base currency
                  type: number
                  x-parser-schema-id: <anonymous-schema-369>
                amount:
                  type: number
                  description: >-
                    Trade amount. For perpetual and inverse futures the amount
                    is in USD units. For options and linear futures it is the
                    underlying base currency coin.
                  x-parser-schema-id: <anonymous-schema-370>
                contracts:
                  type: number
                  description: >-
                    Trade size in contract units (optional, may be absent in
                    historical trades)
                  x-parser-schema-id: <anonymous-schema-371>
                iv:
                  type: number
                  description: Option implied volatility for the price (Option only)
                  x-parser-schema-id: <anonymous-schema-372>
                underlying_price:
                  type: number
                  description: >-
                    Underlying price for implied volatility calculations
                    (Options only)
                  x-parser-schema-id: <anonymous-schema-373>
                liquidation:
                  type: string
                  description: >-
                    Optional field (only for trades caused by liquidation):
                    `"M"` when maker side of trade was under liquidation, `"T"`
                    when taker side was under liquidation, `"MT"` when both
                    sides of trade were under liquidation
                  enum:
                    - M
                    - T
                    - MT
                  x-parser-schema-id: <anonymous-schema-374>
                liquidity:
                  type: string
                  description: >-
                    Describes what was role of users order: `"M"` when it was
                    maker order, `"T"` when it was taker order
                  enum:
                    - M
                    - T
                  x-parser-schema-id: <anonymous-schema-375>
                fee:
                  type: number
                  description: User's fee in units of the specified `fee_currency`
                  x-parser-schema-id: <anonymous-schema-376>
                fee_currency:
                  type: string
                  description: Currency, i.e `"BTC"`, `"ETH"`, `"USDC"`
                  enum:
                    - BTC
                    - ETH
                    - USDC
                    - USDT
                    - EURR
                  x-parser-schema-id: <anonymous-schema-377>
                label:
                  type: string
                  description: >-
                    User defined label (presented only when previously set for
                    order by user)
                  x-parser-schema-id: <anonymous-schema-378>
                state:
                  type: string
                  description: >-
                    Order state: `"open"`, `"filled"`, `"rejected"`,
                    `"cancelled"`, `"untriggered"` or `"archive"` (if order was
                    archived)
                  enum:
                    - open
                    - filled
                    - rejected
                    - cancelled
                    - untriggered
                    - archive
                  x-parser-schema-id: <anonymous-schema-379>
                block_trade_id:
                  description: Block trade id - when trade was part of a block trade
                  type: string
                  example: '154'
                  x-parser-schema-id: <anonymous-schema-380>
                block_rfq_id:
                  type: integer
                  description: ID of the Block RFQ - when trade was part of the Block RFQ
                  x-parser-schema-id: <anonymous-schema-381>
                block_rfq_quote_id:
                  type: integer
                  description: >-
                    ID of the Block RFQ quote - when trade was part of the Block
                    RFQ
                  x-parser-schema-id: <anonymous-schema-382>
                reduce_only:
                  type: string
                  description: '`true` if user order is reduce-only'
                  x-parser-schema-id: <anonymous-schema-383>
                post_only:
                  type: string
                  description: '`true` if user order is post-only'
                  x-parser-schema-id: <anonymous-schema-384>
                mmp:
                  type: boolean
                  description: '`true` if user order is MMP'
                  x-parser-schema-id: <anonymous-schema-385>
                risk_reducing:
                  type: boolean
                  description: >-
                    `true` if user order is marked by the platform as a risk
                    reducing order (can apply only to orders placed by PM users)
                  x-parser-schema-id: <anonymous-schema-386>
                api:
                  type: boolean
                  description: '`true` if user order was created with API'
                  x-parser-schema-id: <anonymous-schema-387>
                profit_loss:
                  type: number
                  description: Profit and loss in base currency.
                  x-parser-schema-id: <anonymous-schema-388>
                mark_price:
                  type: number
                  description: Mark Price at the moment of trade
                  x-parser-schema-id: <anonymous-schema-389>
                legs:
                  type: array
                  description: >-
                    Optional field containing leg trades if trade is a combo
                    trade (present when querying for **only** combo trades and
                    in `combo_trades` events)
                  x-parser-schema-id: <anonymous-schema-390>
                combo_id:
                  type: string
                  description: >-
                    Optional field containing combo instrument name if the trade
                    is a combo trade
                  x-parser-schema-id: <anonymous-schema-391>
                combo_trade_id:
                  type: number
                  description: >-
                    Optional field containing combo trade identifier if the
                    trade is a combo trade
                  x-parser-schema-id: <anonymous-schema-392>
                quote_set_id:
                  type: string
                  description: >-
                    QuoteSet of the user order (optional, present only for
                    orders placed with `private/mass_quote`)
                  x-parser-schema-id: <anonymous-schema-393>
                quote_id:
                  type: string
                  description: >-
                    QuoteID of the user order (optional, present only for orders
                    placed with `private/mass_quote`)
                  x-parser-schema-id: <anonymous-schema-394>
                trade_allocations:
                  type: object
                  description: >-
                    List of allocations for Block RFQ pre-allocation. Each
                    allocation specifies `user_id`, `amount`, and `fee` for the
                    allocated part of the trade. For broker client allocations,
                    a `client_info` object will be included.
                  properties:
                    user_id:
                      description: >-
                        User ID to which part of the trade is allocated. For
                        brokers the User ID is obstructed.
                      type: integer
                      x-parser-schema-id: <anonymous-schema-396>
                    amount:
                      description: Amount allocated to this user.
                      type: number
                      x-parser-schema-id: <anonymous-schema-397>
                    fee:
                      description: Fee for the allocated part of the trade.
                      type: number
                      x-parser-schema-id: <anonymous-schema-398>
                    client_info:
                      description: Optional client allocation info for brokers.
                      type: object
                      properties:
                        client_id:
                          description: >-
                            ID of a client; available to broker. Represents a
                            group of users under a common name.
                          type: integer
                          x-parser-schema-id: <anonymous-schema-400>
                        client_link_id:
                          description: >-
                            ID assigned to a single user in a client; available
                            to broker.
                          type: integer
                          x-parser-schema-id: <anonymous-schema-401>
                        name:
                          description: >-
                            Name of the linked user within the client; available
                            to broker.
                          type: string
                          x-parser-schema-id: <anonymous-schema-402>
                      x-parser-schema-id: <anonymous-schema-399>
                  required:
                    - amount
                    - fee
                  additionalProperties: false
                  x-parser-schema-id: <anonymous-schema-395>
              required:
                - trade_id
                - trade_seq
                - instrument_name
                - timestamp
                - order_id
                - matching_id
                - direction
                - tick_direction
                - index_price
                - price
                - amount
                - fee
                - fee_currency
                - state
                - mark_price
              additionalProperties: false
              x-parser-schema-id: <anonymous-schema-357>
          required:
            - data
          additionalProperties: false
          x-parser-schema-id: <anonymous-schema-356>
        title: Subscription Notification Data
        description: Server sends subscription notification data
        example: |-
          {
            "data": [
              {
                "trade_seq": 30289432,
                "trade_id": "48079254",
                "timestamp": 1590484156350,
                "tick_direction": 0,
                "state": "filled",
                "reduce_only": false,
                "price": 8954,
                "post_only": false,
                "order_type": "market",
                "order_id": "4008965646",
                "matching_id": null,
                "mark_price": 8952.86,
                "liquidity": "T",
                "instrument_name": "BTC-PERPETUAL",
                "index_price": 8956.73,
                "fee_currency": "BTC",
                "fee": 0.00000168,
                "direction": "sell",
                "amount": 20
              },
              {
                "trade_seq": 30289433,
                "trade_id": "48079255",
                "timestamp": 1590484156350,
                "tick_direction": 1,
                "state": "filled",
                "reduce_only": false,
                "price": 8954,
                "post_only": false,
                "order_type": "market",
                "order_id": "4008965646",
                "matching_id": null,
                "mark_price": 8952.86,
                "liquidity": "T",
                "instrument_name": "BTC-PERPETUAL",
                "index_price": 8956.73,
                "fee_currency": "BTC",
                "fee": 0.00000168,
                "direction": "sell",
                "amount": 20
              }
            ]
          }
        bindings: []
        extensions:
          - id: x-parser-unique-object-id
            value: subscription_message
    bindings: []
    extensions: &ref_0
      - id: x-parser-unique-object-id
        value: user.trades.(instrument_name).(interval)
  - &ref_1
    id: receive_user_trades_instrument_name_interval_updates
    title: Receive user updates
    description: Client receives user update notifications
    type: receive
    messages:
      - &ref_3
        id: subscribe_request
        contentType: application/json
        payload:
          - name: Subscription Request
            description: >-
              Client sends subscription request to subscribe to notification
              channel. Please refer to [Notification
              page](https://deribit.mintlify.app/articles/notifications) for
              more information.
            type: object
            properties: []
        headers: []
        jsonPayloadSchema:
          properties: {}
          additionalProperties: false
          x-parser-schema-id: <anonymous-schema-355>
        title: Subscription Request
        description: >-
          Client sends subscription request to subscribe to notification
          channel. Please refer to [Notification
          page](https://deribit.mintlify.app/articles/notifications) for more
          information.
        example: |-
          {
            "jsonrpc": "2.0",
            "method": "public/subscribe",
            "id": 42,
            "params": {
              "channels": [
                "user.trades.BTC-PERPETUAL.100ms"
              ]
            }
          }
        bindings: []
        extensions:
          - id: x-parser-unique-object-id
            value: subscribe_request
    bindings: []
    extensions: *ref_0
sendOperations:
  - *ref_1
receiveOperations:
  - *ref_2
sendMessages:
  - *ref_3
receiveMessages:
  - *ref_4
extensions:
  - id: x-parser-unique-object-id
    value: user.trades.(instrument_name).(interval)
securitySchemes: []

````

> ## Documentation Index
> Fetch the complete documentation index at: https://docs.deribit.com/llms.txt
> Use this file to discover all available pages before exploring further.

<AgentInstructions>

## Submitting Feedback

If you encounter incorrect, outdated, or confusing documentation on this page, submit feedback:

POST https://docs.deribit.com/feedback

```json
{
  "path": "/subscriptions/user/usertradeskindcurrencyinterval",
  "feedback": "Description of the issue"
}
```

Only submit feedback when you have something specific and actionable to report.

</AgentInstructions>

# user.trades.(kind).(currency).(interval) 

> User trade notifications across all instruments for a given kind and currency.

Receive a consolidated stream of your private trades across all instruments matching the specified `kind` and `currency`. The `interval` controls aggregation frequency.




## AsyncAPI

````yaml specifications/deribit_asyncapi.json user.trades.(kind).(currency).(interval)
id: user.trades.(kind).(currency).(interval)
title: 'user.trades.(kind).(currency).(interval) '
description: >
  User trade notifications across all instruments for a given kind and currency.


  Receive a consolidated stream of your private trades across all instruments
  matching the specified `kind` and `currency`. The `interval` controls
  aggregation frequency.
servers:
  - id: production
    protocol: wss
    host: deribit.com/ws/api/v2
    bindings: []
    variables: []
  - id: testnet
    protocol: wss
    host: test.deribit.com/ws/api/v2
    bindings: []
    variables: []
address: user.trades.(kind).(currency).(interval)
parameters:
  - id: kind
    jsonSchema:
      type: string
      description: >-
        Instrument kind


        **Allowed values:** `future`, `option`, `spot`, `future_combo`,
        `option_combo`
      enum:
        - future
        - option
        - spot
        - future_combo
        - option_combo
    description: >-
      Instrument kind


      **Allowed values:** `future`, `option`, `spot`, `future_combo`,
      `option_combo`
    type: string
    required: true
    deprecated: false
  - id: currency
    jsonSchema:
      type: string
      description: |-
        Currency code or `any` for all

        **Allowed values:** `BTC`, `ETH`, `USDC`, `USDT`, `EURR`, `any`
      enum:
        - BTC
        - ETH
        - USDC
        - USDT
        - EURR
        - any
    description: |-
      Currency code or `any` for all

      **Allowed values:** `BTC`, `ETH`, `USDC`, `USDT`, `EURR`, `any`
    type: string
    required: true
    deprecated: false
  - id: interval
    jsonSchema:
      type: string
      description: >-
        Frequency of notifications. Events will be aggregated over this
        interval. The value `raw` means no aggregation will be applied **(Please
        note that `raw` interval is only available to authorized users)**


        **Allowed values:** `raw`, `100ms`, `agg2`
      enum:
        - raw
        - 100ms
        - agg2
    description: >-
      Frequency of notifications. Events will be aggregated over this interval.
      The value `raw` means no aggregation will be applied **(Please note that
      `raw` interval is only available to authorized users)**


      **Allowed values:** `raw`, `100ms`, `agg2`
    type: string
    required: true
    deprecated: false
bindings: []
operations:
  - &ref_2
    id: send_subscribe_user_trades_kind_currency_interval
    title: Send subscribe request for user
    description: Client sends subscription request for user updates
    type: send
    messages:
      - &ref_4
        id: subscription_message
        contentType: application/json
        payload:
          - name: Subscription Notification Data
            description: Server sends subscription notification data
            type: object
            properties:
              - name: data
                type: object
                required: true
                properties:
                  - name: trade_id
                    type: string
                    description: Unique (per currency) trade identifier
                    required: false
                  - name: trade_seq
                    type: integer
                    description: The sequence number of the trade within instrument
                    required: false
                  - name: instrument_name
                    type: string
                    description: Unique instrument identifier
                    required: false
                  - name: timestamp
                    type: integer
                    description: >-
                      The timestamp of the trade (milliseconds since the UNIX
                      epoch)
                    required: false
                  - name: order_type
                    type: string
                    description: 'Order type: `"limit`, `"market"`, or `"liquidation"`'
                    enumValues:
                      - limit
                      - market
                      - liquidation
                    required: false
                  - name: advanced
                    type: string
                    description: >-
                      Advanced type of user order: `"usd"` or `"implv"` (only
                      for options; omitted if not applicable)
                    enumValues:
                      - usd
                      - implv
                    required: false
                  - name: order_id
                    type: string
                    description: >-
                      Id of the user order (maker or taker), i.e. subscriber's
                      order id that took part in the trade
                    required: false
                  - name: matching_id
                    type: string
                    description: Always `null`
                    required: false
                  - name: direction
                    type: string
                    description: 'Direction: `buy`, or `sell`'
                    enumValues:
                      - buy
                      - sell
                    required: false
                  - name: tick_direction
                    type: integer
                    description: >-
                      Direction of the "tick" (`0` = Plus Tick, `1` = Zero-Plus
                      Tick, `2` = Minus Tick, `3` = Zero-Minus Tick).
                    enumValues:
                      - 0
                      - 1
                      - 2
                      - 3
                    required: false
                  - name: index_price
                    type: number
                    description: Index Price at the moment of trade
                    required: false
                  - name: price
                    type: number
                    description: Price in base currency
                    required: false
                  - name: amount
                    type: number
                    description: >-
                      Trade amount. For perpetual and inverse futures the amount
                      is in USD units. For options and linear futures it is the
                      underlying base currency coin.
                    required: false
                  - name: contracts
                    type: number
                    description: >-
                      Trade size in contract units (optional, may be absent in
                      historical trades)
                    required: false
                  - name: iv
                    type: number
                    description: Option implied volatility for the price (Option only)
                    required: false
                  - name: underlying_price
                    type: number
                    description: >-
                      Underlying price for implied volatility calculations
                      (Options only)
                    required: false
                  - name: liquidation
                    type: string
                    description: >-
                      Optional field (only for trades caused by liquidation):
                      `"M"` when maker side of trade was under liquidation,
                      `"T"` when taker side was under liquidation, `"MT"` when
                      both sides of trade were under liquidation
                    enumValues:
                      - M
                      - T
                      - MT
                    required: false
                  - name: liquidity
                    type: string
                    description: >-
                      Describes what was role of users order: `"M"` when it was
                      maker order, `"T"` when it was taker order
                    enumValues:
                      - M
                      - T
                    required: false
                  - name: fee
                    type: number
                    description: User's fee in units of the specified `fee_currency`
                    required: false
                  - name: fee_currency
                    type: string
                    description: Currency, i.e `"BTC"`, `"ETH"`, `"USDC"`
                    enumValues:
                      - BTC
                      - ETH
                      - USDC
                      - USDT
                      - EURR
                    required: false
                  - name: label
                    type: string
                    description: >-
                      User defined label (presented only when previously set for
                      order by user)
                    required: false
                  - name: state
                    type: string
                    description: >-
                      Order state: `"open"`, `"filled"`, `"rejected"`,
                      `"cancelled"`, `"untriggered"` or `"archive"` (if order
                      was archived)
                    enumValues:
                      - open
                      - filled
                      - rejected
                      - cancelled
                      - untriggered
                      - archive
                    required: false
                  - name: block_trade_id
                    type: string
                    description: Block trade id - when trade was part of a block trade
                    required: false
                  - name: block_rfq_id
                    type: integer
                    description: ID of the Block RFQ - when trade was part of the Block RFQ
                    required: false
                  - name: block_rfq_quote_id
                    type: integer
                    description: >-
                      ID of the Block RFQ quote - when trade was part of the
                      Block RFQ
                    required: false
                  - name: reduce_only
                    type: string
                    description: '`true` if user order is reduce-only'
                    required: false
                  - name: post_only
                    type: string
                    description: '`true` if user order is post-only'
                    required: false
                  - name: mmp
                    type: boolean
                    description: '`true` if user order is MMP'
                    required: false
                  - name: risk_reducing
                    type: boolean
                    description: >-
                      `true` if user order is marked by the platform as a risk
                      reducing order (can apply only to orders placed by PM
                      users)
                    required: false
                  - name: api
                    type: boolean
                    description: '`true` if user order was created with API'
                    required: false
                  - name: profit_loss
                    type: number
                    description: Profit and loss in base currency.
                    required: false
                  - name: mark_price
                    type: number
                    description: Mark Price at the moment of trade
                    required: false
                  - name: legs
                    type: array
                    description: >-
                      Optional field containing leg trades if trade is a combo
                      trade (present when querying for **only** combo trades and
                      in `combo_trades` events)
                    required: false
                  - name: combo_id
                    type: string
                    description: >-
                      Optional field containing combo instrument name if the
                      trade is a combo trade
                    required: false
                  - name: combo_trade_id
                    type: number
                    description: >-
                      Optional field containing combo trade identifier if the
                      trade is a combo trade
                    required: false
                  - name: quote_set_id
                    type: string
                    description: >-
                      QuoteSet of the user order (optional, present only for
                      orders placed with `private/mass_quote`)
                    required: false
                  - name: quote_id
                    type: string
                    description: >-
                      QuoteID of the user order (optional, present only for
                      orders placed with `private/mass_quote`)
                    required: false
                  - name: trade_allocations
                    type: object
                    description: >-
                      List of allocations for Block RFQ pre-allocation. Each
                      allocation specifies `user_id`, `amount`, and `fee` for
                      the allocated part of the trade. For broker client
                      allocations, a `client_info` object will be included.
                    required: false
                    properties:
                      - name: user_id
                        type: integer
                        description: >-
                          User ID to which part of the trade is allocated. For
                          brokers the User ID is obstructed.
                        required: false
                      - name: amount
                        type: number
                        description: Amount allocated to this user.
                        required: false
                      - name: fee
                        type: number
                        description: Fee for the allocated part of the trade.
                        required: false
                      - name: client_info
                        type: object
                        description: Optional client allocation info for brokers.
                        required: false
                        properties:
                          - name: client_id
                            type: integer
                            description: >-
                              ID of a client; available to broker. Represents a
                              group of users under a common name.
                            required: false
                          - name: client_link_id
                            type: integer
                            description: >-
                              ID assigned to a single user in a client;
                              available to broker.
                            required: false
                          - name: name
                            type: string
                            description: >-
                              Name of the linked user within the client;
                              available to broker.
                            required: false
        headers: []
        jsonPayloadSchema:
          type: object
          description: Response containing notification data
          properties:
            data:
              type: object
              description: ''
              properties:
                trade_id:
                  type: string
                  description: Unique (per currency) trade identifier
                  x-parser-schema-id: <anonymous-schema-409>
                trade_seq:
                  description: The sequence number of the trade within instrument
                  type: integer
                  x-parser-schema-id: <anonymous-schema-410>
                instrument_name:
                  type: string
                  description: Unique instrument identifier
                  example: BTC-PERPETUAL
                  x-parser-schema-id: <anonymous-schema-411>
                timestamp:
                  description: >-
                    The timestamp of the trade (milliseconds since the UNIX
                    epoch)
                  example: 1517329113791
                  type: integer
                  x-parser-schema-id: <anonymous-schema-412>
                order_type:
                  type: string
                  description: 'Order type: `"limit`, `"market"`, or `"liquidation"`'
                  enum:
                    - limit
                    - market
                    - liquidation
                  x-parser-schema-id: <anonymous-schema-413>
                advanced:
                  type: string
                  description: >-
                    Advanced type of user order: `"usd"` or `"implv"` (only for
                    options; omitted if not applicable)
                  enum:
                    - usd
                    - implv
                  x-parser-schema-id: <anonymous-schema-414>
                order_id:
                  type: string
                  description: >-
                    Id of the user order (maker or taker), i.e. subscriber's
                    order id that took part in the trade
                  x-parser-schema-id: <anonymous-schema-415>
                matching_id:
                  type: string
                  description: Always `null`
                  x-parser-schema-id: <anonymous-schema-416>
                direction:
                  type: string
                  description: 'Direction: `buy`, or `sell`'
                  enum:
                    - buy
                    - sell
                  x-parser-schema-id: <anonymous-schema-417>
                tick_direction:
                  type: integer
                  enum:
                    - 0
                    - 1
                    - 2
                    - 3
                  description: >-
                    Direction of the "tick" (`0` = Plus Tick, `1` = Zero-Plus
                    Tick, `2` = Minus Tick, `3` = Zero-Minus Tick).
                  x-parser-schema-id: <anonymous-schema-418>
                index_price:
                  type: number
                  description: Index Price at the moment of trade
                  x-parser-schema-id: <anonymous-schema-419>
                price:
                  description: Price in base currency
                  type: number
                  x-parser-schema-id: <anonymous-schema-420>
                amount:
                  type: number
                  description: >-
                    Trade amount. For perpetual and inverse futures the amount
                    is in USD units. For options and linear futures it is the
                    underlying base currency coin.
                  x-parser-schema-id: <anonymous-schema-421>
                contracts:
                  type: number
                  description: >-
                    Trade size in contract units (optional, may be absent in
                    historical trades)
                  x-parser-schema-id: <anonymous-schema-422>
                iv:
                  type: number
                  description: Option implied volatility for the price (Option only)
                  x-parser-schema-id: <anonymous-schema-423>
                underlying_price:
                  type: number
                  description: >-
                    Underlying price for implied volatility calculations
                    (Options only)
                  x-parser-schema-id: <anonymous-schema-424>
                liquidation:
                  type: string
                  description: >-
                    Optional field (only for trades caused by liquidation):
                    `"M"` when maker side of trade was under liquidation, `"T"`
                    when taker side was under liquidation, `"MT"` when both
                    sides of trade were under liquidation
                  enum:
                    - M
                    - T
                    - MT
                  x-parser-schema-id: <anonymous-schema-425>
                liquidity:
                  type: string
                  description: >-
                    Describes what was role of users order: `"M"` when it was
                    maker order, `"T"` when it was taker order
                  enum:
                    - M
                    - T
                  x-parser-schema-id: <anonymous-schema-426>
                fee:
                  type: number
                  description: User's fee in units of the specified `fee_currency`
                  x-parser-schema-id: <anonymous-schema-427>
                fee_currency:
                  type: string
                  description: Currency, i.e `"BTC"`, `"ETH"`, `"USDC"`
                  enum:
                    - BTC
                    - ETH
                    - USDC
                    - USDT
                    - EURR
                  x-parser-schema-id: <anonymous-schema-428>
                label:
                  type: string
                  description: >-
                    User defined label (presented only when previously set for
                    order by user)
                  x-parser-schema-id: <anonymous-schema-429>
                state:
                  type: string
                  description: >-
                    Order state: `"open"`, `"filled"`, `"rejected"`,
                    `"cancelled"`, `"untriggered"` or `"archive"` (if order was
                    archived)
                  enum:
                    - open
                    - filled
                    - rejected
                    - cancelled
                    - untriggered
                    - archive
                  x-parser-schema-id: <anonymous-schema-430>
                block_trade_id:
                  description: Block trade id - when trade was part of a block trade
                  type: string
                  example: '154'
                  x-parser-schema-id: <anonymous-schema-431>
                block_rfq_id:
                  type: integer
                  description: ID of the Block RFQ - when trade was part of the Block RFQ
                  x-parser-schema-id: <anonymous-schema-432>
                block_rfq_quote_id:
                  type: integer
                  description: >-
                    ID of the Block RFQ quote - when trade was part of the Block
                    RFQ
                  x-parser-schema-id: <anonymous-schema-433>
                reduce_only:
                  type: string
                  description: '`true` if user order is reduce-only'
                  x-parser-schema-id: <anonymous-schema-434>
                post_only:
                  type: string
                  description: '`true` if user order is post-only'
                  x-parser-schema-id: <anonymous-schema-435>
                mmp:
                  type: boolean
                  description: '`true` if user order is MMP'
                  x-parser-schema-id: <anonymous-schema-436>
                risk_reducing:
                  type: boolean
                  description: >-
                    `true` if user order is marked by the platform as a risk
                    reducing order (can apply only to orders placed by PM users)
                  x-parser-schema-id: <anonymous-schema-437>
                api:
                  type: boolean
                  description: '`true` if user order was created with API'
                  x-parser-schema-id: <anonymous-schema-438>
                profit_loss:
                  type: number
                  description: Profit and loss in base currency.
                  x-parser-schema-id: <anonymous-schema-439>
                mark_price:
                  type: number
                  description: Mark Price at the moment of trade
                  x-parser-schema-id: <anonymous-schema-440>
                legs:
                  type: array
                  description: >-
                    Optional field containing leg trades if trade is a combo
                    trade (present when querying for **only** combo trades and
                    in `combo_trades` events)
                  x-parser-schema-id: <anonymous-schema-441>
                combo_id:
                  type: string
                  description: >-
                    Optional field containing combo instrument name if the trade
                    is a combo trade
                  x-parser-schema-id: <anonymous-schema-442>
                combo_trade_id:
                  type: number
                  description: >-
                    Optional field containing combo trade identifier if the
                    trade is a combo trade
                  x-parser-schema-id: <anonymous-schema-443>
                quote_set_id:
                  type: string
                  description: >-
                    QuoteSet of the user order (optional, present only for
                    orders placed with `private/mass_quote`)
                  x-parser-schema-id: <anonymous-schema-444>
                quote_id:
                  type: string
                  description: >-
                    QuoteID of the user order (optional, present only for orders
                    placed with `private/mass_quote`)
                  x-parser-schema-id: <anonymous-schema-445>
                trade_allocations:
                  type: object
                  description: >-
                    List of allocations for Block RFQ pre-allocation. Each
                    allocation specifies `user_id`, `amount`, and `fee` for the
                    allocated part of the trade. For broker client allocations,
                    a `client_info` object will be included.
                  properties:
                    user_id:
                      description: >-
                        User ID to which part of the trade is allocated. For
                        brokers the User ID is obstructed.
                      type: integer
                      x-parser-schema-id: <anonymous-schema-447>
                    amount:
                      description: Amount allocated to this user.
                      type: number
                      x-parser-schema-id: <anonymous-schema-448>
                    fee:
                      description: Fee for the allocated part of the trade.
                      type: number
                      x-parser-schema-id: <anonymous-schema-449>
                    client_info:
                      description: Optional client allocation info for brokers.
                      type: object
                      properties:
                        client_id:
                          description: >-
                            ID of a client; available to broker. Represents a
                            group of users under a common name.
                          type: integer
                          x-parser-schema-id: <anonymous-schema-451>
                        client_link_id:
                          description: >-
                            ID assigned to a single user in a client; available
                            to broker.
                          type: integer
                          x-parser-schema-id: <anonymous-schema-452>
                        name:
                          description: >-
                            Name of the linked user within the client; available
                            to broker.
                          type: string
                          x-parser-schema-id: <anonymous-schema-453>
                      x-parser-schema-id: <anonymous-schema-450>
                  required:
                    - amount
                    - fee
                  additionalProperties: false
                  x-parser-schema-id: <anonymous-schema-446>
              required:
                - trade_id
                - trade_seq
                - instrument_name
                - timestamp
                - order_id
                - matching_id
                - direction
                - tick_direction
                - index_price
                - price
                - amount
                - fee
                - fee_currency
                - state
                - mark_price
              additionalProperties: false
              x-parser-schema-id: <anonymous-schema-408>
          required:
            - data
          additionalProperties: false
          x-parser-schema-id: <anonymous-schema-407>
        title: Subscription Notification Data
        description: Server sends subscription notification data
        example: |-
          {
            "data": [
              {
                "trade_seq": 74405,
                "trade_id": "48079262",
                "timestamp": 1590484255886,
                "tick_direction": 2,
                "state": "filled",
                "reduce_only": false,
                "price": 8947,
                "post_only": false,
                "order_type": "limit",
                "order_id": "4008978075",
                "matching_id": null,
                "mark_price": 8970.03,
                "liquidity": "T",
                "instrument_name": "BTC-25SEP20",
                "index_price": 8953.53,
                "fee_currency": "BTC",
                "fee": 0.00049961,
                "direction": "sell",
                "amount": 8940
              }
            ]
          }
        bindings: []
        extensions:
          - id: x-parser-unique-object-id
            value: subscription_message
    bindings: []
    extensions: &ref_0
      - id: x-parser-unique-object-id
        value: user.trades.(kind).(currency).(interval)
  - &ref_1
    id: receive_user_trades_kind_currency_interval_updates
    title: Receive user updates
    description: Client receives user update notifications
    type: receive
    messages:
      - &ref_3
        id: subscribe_request
        contentType: application/json
        payload:
          - name: Subscription Request
            description: >-
              Client sends subscription request to subscribe to notification
              channel. Please refer to [Notification
              page](https://deribit.mintlify.app/articles/notifications) for
              more information.
            type: object
            properties: []
        headers: []
        jsonPayloadSchema:
          properties: {}
          additionalProperties: false
          x-parser-schema-id: <anonymous-schema-406>
        title: Subscription Request
        description: >-
          Client sends subscription request to subscribe to notification
          channel. Please refer to [Notification
          page](https://deribit.mintlify.app/articles/notifications) for more
          information.
        example: |-
          {
            "jsonrpc": "2.0",
            "method": "public/subscribe",
            "id": 42,
            "params": {
              "channels": [
                "user.trades.(kind).(currency).100ms"
              ]
            }
          }
        bindings: []
        extensions:
          - id: x-parser-unique-object-id
            value: subscribe_request
    bindings: []
    extensions: *ref_0
sendOperations:
  - *ref_1
receiveOperations:
  - *ref_2
sendMessages:
  - *ref_3
receiveMessages:
  - *ref_4
extensions:
  - id: x-parser-unique-object-id
    value: user.trades.(kind).(currency).(interval)
securitySchemes: []

````


> ## Documentation Index
> Fetch the complete documentation index at: https://docs.deribit.com/llms.txt
> Use this file to discover all available pages before exploring further.

<AgentInstructions>

## Submitting Feedback

If you encounter incorrect, outdated, or confusing documentation on this page, submit feedback:

POST https://docs.deribit.com/feedback

```json
{
  "path": "/subscriptions/user/usercombo_tradesinstrument_nameinterval",
  "feedback": "Description of the issue"
}
```

Only submit feedback when you have something specific and actionable to report.

</AgentInstructions>

# user.combo_trades.(instrument_name).(interval) 

> User trade notifications for a specific combo instrument.

Trades include a `legs` field describing the underlying legs of the combo. The `interval` controls aggregation frequency.




## AsyncAPI

````yaml specifications/deribit_asyncapi.json user.combo_trades.(instrument_name).(interval)
id: user.combo_trades.(instrument_name).(interval)
title: 'user.combo_trades.(instrument_name).(interval) '
description: >
  User trade notifications for a specific combo instrument.


  Trades include a `legs` field describing the underlying legs of the combo. The
  `interval` controls aggregation frequency.
servers:
  - id: production
    protocol: wss
    host: deribit.com/ws/api/v2
    bindings: []
    variables: []
  - id: testnet
    protocol: wss
    host: test.deribit.com/ws/api/v2
    bindings: []
    variables: []
address: user.combo_trades.(instrument_name).(interval)
parameters:
  - id: instrument_name
    jsonSchema:
      type: string
      description: The name of the instrument
    description: The name of the instrument
    type: string
    required: true
    deprecated: false
  - id: interval
    jsonSchema:
      type: string
      description: >-
        Frequency of notifications. Events will be aggregated over this
        interval. The value `raw` means no aggregation will be applied **(Please
        note that `raw` interval is only available to authorized users)**


        **Allowed values:** `raw`, `100ms`, `agg2`
      enum:
        - raw
        - 100ms
        - agg2
    description: >-
      Frequency of notifications. Events will be aggregated over this interval.
      The value `raw` means no aggregation will be applied **(Please note that
      `raw` interval is only available to authorized users)**


      **Allowed values:** `raw`, `100ms`, `agg2`
    type: string
    required: true
    deprecated: false
bindings: []
operations:
  - &ref_2
    id: send_subscribe_user_combo_trades_instrument_name_interval
    title: Send subscribe request for user
    description: Client sends subscription request for user updates
    type: send
    messages:
      - &ref_4
        id: subscription_message
        contentType: application/json
        payload:
          - name: Subscription Notification Data
            description: Server sends subscription notification data
            type: object
            properties:
              - name: data
                type: object
                required: true
                properties:
                  - name: trade_id
                    type: string
                    description: Unique (per currency) trade identifier
                    required: false
                  - name: trade_seq
                    type: integer
                    description: The sequence number of the trade within instrument
                    required: false
                  - name: instrument_name
                    type: string
                    description: Unique instrument identifier
                    required: false
                  - name: timestamp
                    type: integer
                    description: >-
                      The timestamp of the trade (milliseconds since the UNIX
                      epoch)
                    required: false
                  - name: order_type
                    type: string
                    description: 'Order type: `"limit`, `"market"`, or `"liquidation"`'
                    enumValues:
                      - limit
                      - market
                      - liquidation
                    required: false
                  - name: advanced
                    type: string
                    description: >-
                      Advanced type of user order: `"usd"` or `"implv"` (only
                      for options; omitted if not applicable)
                    enumValues:
                      - usd
                      - implv
                    required: false
                  - name: order_id
                    type: string
                    description: >-
                      Id of the user order (maker or taker), i.e. subscriber's
                      order id that took part in the trade
                    required: false
                  - name: matching_id
                    type: string
                    description: Always `null`
                    required: false
                  - name: direction
                    type: string
                    description: 'Direction: `buy`, or `sell`'
                    enumValues:
                      - buy
                      - sell
                    required: false
                  - name: tick_direction
                    type: integer
                    description: >-
                      Direction of the "tick" (`0` = Plus Tick, `1` = Zero-Plus
                      Tick, `2` = Minus Tick, `3` = Zero-Minus Tick).
                    enumValues:
                      - 0
                      - 1
                      - 2
                      - 3
                    required: false
                  - name: index_price
                    type: number
                    description: Index Price at the moment of trade
                    required: false
                  - name: price
                    type: number
                    description: Price in base currency
                    required: false
                  - name: amount
                    type: number
                    description: >-
                      Trade amount. For perpetual and inverse futures the amount
                      is in USD units. For options and linear futures it is the
                      underlying base currency coin.
                    required: false
                  - name: contracts
                    type: number
                    description: >-
                      Trade size in contract units (optional, may be absent in
                      historical trades)
                    required: false
                  - name: iv
                    type: number
                    description: Option implied volatility for the price (Option only)
                    required: false
                  - name: underlying_price
                    type: number
                    description: >-
                      Underlying price for implied volatility calculations
                      (Options only)
                    required: false
                  - name: liquidation
                    type: string
                    description: >-
                      Optional field (only for trades caused by liquidation):
                      `"M"` when maker side of trade was under liquidation,
                      `"T"` when taker side was under liquidation, `"MT"` when
                      both sides of trade were under liquidation
                    enumValues:
                      - M
                      - T
                      - MT
                    required: false
                  - name: liquidity
                    type: string
                    description: >-
                      Describes what was role of users order: `"M"` when it was
                      maker order, `"T"` when it was taker order
                    enumValues:
                      - M
                      - T
                    required: false
                  - name: fee
                    type: number
                    description: User's fee in units of the specified `fee_currency`
                    required: false
                  - name: fee_currency
                    type: string
                    description: Currency, i.e `"BTC"`, `"ETH"`, `"USDC"`
                    enumValues:
                      - BTC
                      - ETH
                      - USDC
                      - USDT
                      - EURR
                    required: false
                  - name: label
                    type: string
                    description: >-
                      User defined label (presented only when previously set for
                      order by user)
                    required: false
                  - name: state
                    type: string
                    description: >-
                      Order state: `"open"`, `"filled"`, `"rejected"`,
                      `"cancelled"`, `"untriggered"` or `"archive"` (if order
                      was archived)
                    enumValues:
                      - open
                      - filled
                      - rejected
                      - cancelled
                      - untriggered
                      - archive
                    required: false
                  - name: block_trade_id
                    type: string
                    description: Block trade id - when trade was part of a block trade
                    required: false
                  - name: block_rfq_id
                    type: integer
                    description: ID of the Block RFQ - when trade was part of the Block RFQ
                    required: false
                  - name: block_rfq_quote_id
                    type: integer
                    description: >-
                      ID of the Block RFQ quote - when trade was part of the
                      Block RFQ
                    required: false
                  - name: reduce_only
                    type: string
                    description: '`true` if user order is reduce-only'
                    required: false
                  - name: post_only
                    type: string
                    description: '`true` if user order is post-only'
                    required: false
                  - name: mmp
                    type: boolean
                    description: '`true` if user order is MMP'
                    required: false
                  - name: risk_reducing
                    type: boolean
                    description: >-
                      `true` if user order is marked by the platform as a risk
                      reducing order (can apply only to orders placed by PM
                      users)
                    required: false
                  - name: api
                    type: boolean
                    description: '`true` if user order was created with API'
                    required: false
                  - name: profit_loss
                    type: number
                    description: Profit and loss in base currency.
                    required: false
                  - name: mark_price
                    type: number
                    description: Mark Price at the moment of trade
                    required: false
                  - name: legs
                    type: array
                    description: >-
                      Optional field containing leg trades if trade is a combo
                      trade (present when querying for **only** combo trades and
                      in `combo_trades` events)
                    required: false
                  - name: combo_id
                    type: string
                    description: >-
                      Optional field containing combo instrument name if the
                      trade is a combo trade
                    required: false
                  - name: combo_trade_id
                    type: number
                    description: >-
                      Optional field containing combo trade identifier if the
                      trade is a combo trade
                    required: false
                  - name: quote_set_id
                    type: string
                    description: >-
                      QuoteSet of the user order (optional, present only for
                      orders placed with `private/mass_quote`)
                    required: false
                  - name: quote_id
                    type: string
                    description: >-
                      QuoteID of the user order (optional, present only for
                      orders placed with `private/mass_quote`)
                    required: false
                  - name: trade_allocations
                    type: object
                    description: >-
                      List of allocations for Block RFQ pre-allocation. Each
                      allocation specifies `user_id`, `amount`, and `fee` for
                      the allocated part of the trade. For broker client
                      allocations, a `client_info` object will be included.
                    required: false
                    properties:
                      - name: user_id
                        type: integer
                        description: >-
                          User ID to which part of the trade is allocated. For
                          brokers the User ID is obstructed.
                        required: false
                      - name: amount
                        type: number
                        description: Amount allocated to this user.
                        required: false
                      - name: fee
                        type: number
                        description: Fee for the allocated part of the trade.
                        required: false
                      - name: client_info
                        type: object
                        description: Optional client allocation info for brokers.
                        required: false
                        properties:
                          - name: client_id
                            type: integer
                            description: >-
                              ID of a client; available to broker. Represents a
                              group of users under a common name.
                            required: false
                          - name: client_link_id
                            type: integer
                            description: >-
                              ID assigned to a single user in a client;
                              available to broker.
                            required: false
                          - name: name
                            type: string
                            description: >-
                              Name of the linked user within the client;
                              available to broker.
                            required: false
        headers: []
        jsonPayloadSchema:
          type: object
          description: Response containing notification data
          properties:
            data:
              type: object
              description: ''
              properties:
                trade_id:
                  type: string
                  description: Unique (per currency) trade identifier
                  x-parser-schema-id: <anonymous-schema-459>
                trade_seq:
                  description: The sequence number of the trade within instrument
                  type: integer
                  x-parser-schema-id: <anonymous-schema-460>
                instrument_name:
                  type: string
                  description: Unique instrument identifier
                  example: BTC-PERPETUAL
                  x-parser-schema-id: <anonymous-schema-461>
                timestamp:
                  description: >-
                    The timestamp of the trade (milliseconds since the UNIX
                    epoch)
                  example: 1517329113791
                  type: integer
                  x-parser-schema-id: <anonymous-schema-462>
                order_type:
                  type: string
                  description: 'Order type: `"limit`, `"market"`, or `"liquidation"`'
                  enum:
                    - limit
                    - market
                    - liquidation
                  x-parser-schema-id: <anonymous-schema-463>
                advanced:
                  type: string
                  description: >-
                    Advanced type of user order: `"usd"` or `"implv"` (only for
                    options; omitted if not applicable)
                  enum:
                    - usd
                    - implv
                  x-parser-schema-id: <anonymous-schema-464>
                order_id:
                  type: string
                  description: >-
                    Id of the user order (maker or taker), i.e. subscriber's
                    order id that took part in the trade
                  x-parser-schema-id: <anonymous-schema-465>
                matching_id:
                  type: string
                  description: Always `null`
                  x-parser-schema-id: <anonymous-schema-466>
                direction:
                  type: string
                  description: 'Direction: `buy`, or `sell`'
                  enum:
                    - buy
                    - sell
                  x-parser-schema-id: <anonymous-schema-467>
                tick_direction:
                  type: integer
                  enum:
                    - 0
                    - 1
                    - 2
                    - 3
                  description: >-
                    Direction of the "tick" (`0` = Plus Tick, `1` = Zero-Plus
                    Tick, `2` = Minus Tick, `3` = Zero-Minus Tick).
                  x-parser-schema-id: <anonymous-schema-468>
                index_price:
                  type: number
                  description: Index Price at the moment of trade
                  x-parser-schema-id: <anonymous-schema-469>
                price:
                  description: Price in base currency
                  type: number
                  x-parser-schema-id: <anonymous-schema-470>
                amount:
                  type: number
                  description: >-
                    Trade amount. For perpetual and inverse futures the amount
                    is in USD units. For options and linear futures it is the
                    underlying base currency coin.
                  x-parser-schema-id: <anonymous-schema-471>
                contracts:
                  type: number
                  description: >-
                    Trade size in contract units (optional, may be absent in
                    historical trades)
                  x-parser-schema-id: <anonymous-schema-472>
                iv:
                  type: number
                  description: Option implied volatility for the price (Option only)
                  x-parser-schema-id: <anonymous-schema-473>
                underlying_price:
                  type: number
                  description: >-
                    Underlying price for implied volatility calculations
                    (Options only)
                  x-parser-schema-id: <anonymous-schema-474>
                liquidation:
                  type: string
                  description: >-
                    Optional field (only for trades caused by liquidation):
                    `"M"` when maker side of trade was under liquidation, `"T"`
                    when taker side was under liquidation, `"MT"` when both
                    sides of trade were under liquidation
                  enum:
                    - M
                    - T
                    - MT
                  x-parser-schema-id: <anonymous-schema-475>
                liquidity:
                  type: string
                  description: >-
                    Describes what was role of users order: `"M"` when it was
                    maker order, `"T"` when it was taker order
                  enum:
                    - M
                    - T
                  x-parser-schema-id: <anonymous-schema-476>
                fee:
                  type: number
                  description: User's fee in units of the specified `fee_currency`
                  x-parser-schema-id: <anonymous-schema-477>
                fee_currency:
                  type: string
                  description: Currency, i.e `"BTC"`, `"ETH"`, `"USDC"`
                  enum:
                    - BTC
                    - ETH
                    - USDC
                    - USDT
                    - EURR
                  x-parser-schema-id: <anonymous-schema-478>
                label:
                  type: string
                  description: >-
                    User defined label (presented only when previously set for
                    order by user)
                  x-parser-schema-id: <anonymous-schema-479>
                state:
                  type: string
                  description: >-
                    Order state: `"open"`, `"filled"`, `"rejected"`,
                    `"cancelled"`, `"untriggered"` or `"archive"` (if order was
                    archived)
                  enum:
                    - open
                    - filled
                    - rejected
                    - cancelled
                    - untriggered
                    - archive
                  x-parser-schema-id: <anonymous-schema-480>
                block_trade_id:
                  description: Block trade id - when trade was part of a block trade
                  type: string
                  example: '154'
                  x-parser-schema-id: <anonymous-schema-481>
                block_rfq_id:
                  type: integer
                  description: ID of the Block RFQ - when trade was part of the Block RFQ
                  x-parser-schema-id: <anonymous-schema-482>
                block_rfq_quote_id:
                  type: integer
                  description: >-
                    ID of the Block RFQ quote - when trade was part of the Block
                    RFQ
                  x-parser-schema-id: <anonymous-schema-483>
                reduce_only:
                  type: string
                  description: '`true` if user order is reduce-only'
                  x-parser-schema-id: <anonymous-schema-484>
                post_only:
                  type: string
                  description: '`true` if user order is post-only'
                  x-parser-schema-id: <anonymous-schema-485>
                mmp:
                  type: boolean
                  description: '`true` if user order is MMP'
                  x-parser-schema-id: <anonymous-schema-486>
                risk_reducing:
                  type: boolean
                  description: >-
                    `true` if user order is marked by the platform as a risk
                    reducing order (can apply only to orders placed by PM users)
                  x-parser-schema-id: <anonymous-schema-487>
                api:
                  type: boolean
                  description: '`true` if user order was created with API'
                  x-parser-schema-id: <anonymous-schema-488>
                profit_loss:
                  type: number
                  description: Profit and loss in base currency.
                  x-parser-schema-id: <anonymous-schema-489>
                mark_price:
                  type: number
                  description: Mark Price at the moment of trade
                  x-parser-schema-id: <anonymous-schema-490>
                legs:
                  type: array
                  description: >-
                    Optional field containing leg trades if trade is a combo
                    trade (present when querying for **only** combo trades and
                    in `combo_trades` events)
                  x-parser-schema-id: <anonymous-schema-491>
                combo_id:
                  type: string
                  description: >-
                    Optional field containing combo instrument name if the trade
                    is a combo trade
                  x-parser-schema-id: <anonymous-schema-492>
                combo_trade_id:
                  type: number
                  description: >-
                    Optional field containing combo trade identifier if the
                    trade is a combo trade
                  x-parser-schema-id: <anonymous-schema-493>
                quote_set_id:
                  type: string
                  description: >-
                    QuoteSet of the user order (optional, present only for
                    orders placed with `private/mass_quote`)
                  x-parser-schema-id: <anonymous-schema-494>
                quote_id:
                  type: string
                  description: >-
                    QuoteID of the user order (optional, present only for orders
                    placed with `private/mass_quote`)
                  x-parser-schema-id: <anonymous-schema-495>
                trade_allocations:
                  type: object
                  description: >-
                    List of allocations for Block RFQ pre-allocation. Each
                    allocation specifies `user_id`, `amount`, and `fee` for the
                    allocated part of the trade. For broker client allocations,
                    a `client_info` object will be included.
                  properties:
                    user_id:
                      description: >-
                        User ID to which part of the trade is allocated. For
                        brokers the User ID is obstructed.
                      type: integer
                      x-parser-schema-id: <anonymous-schema-497>
                    amount:
                      description: Amount allocated to this user.
                      type: number
                      x-parser-schema-id: <anonymous-schema-498>
                    fee:
                      description: Fee for the allocated part of the trade.
                      type: number
                      x-parser-schema-id: <anonymous-schema-499>
                    client_info:
                      description: Optional client allocation info for brokers.
                      type: object
                      properties:
                        client_id:
                          description: >-
                            ID of a client; available to broker. Represents a
                            group of users under a common name.
                          type: integer
                          x-parser-schema-id: <anonymous-schema-501>
                        client_link_id:
                          description: >-
                            ID assigned to a single user in a client; available
                            to broker.
                          type: integer
                          x-parser-schema-id: <anonymous-schema-502>
                        name:
                          description: >-
                            Name of the linked user within the client; available
                            to broker.
                          type: string
                          x-parser-schema-id: <anonymous-schema-503>
                      x-parser-schema-id: <anonymous-schema-500>
                  required:
                    - amount
                    - fee
                  additionalProperties: false
                  x-parser-schema-id: <anonymous-schema-496>
              required:
                - trade_id
                - trade_seq
                - instrument_name
                - timestamp
                - order_id
                - matching_id
                - direction
                - tick_direction
                - index_price
                - price
                - amount
                - fee
                - fee_currency
                - state
                - mark_price
              additionalProperties: false
              x-parser-schema-id: <anonymous-schema-458>
          required:
            - data
          additionalProperties: false
          x-parser-schema-id: <anonymous-schema-457>
        title: Subscription Notification Data
        description: Server sends subscription notification data
        example: |-
          {
            "data": [
              {
                "trade_seq": 39,
                "trade_id": "1154",
                "timestamp": 1661867454334,
                "tick_direction": 2,
                "state": "filled",
                "risk_reducing": false,
                "reduce_only": false,
                "profit_loss": null,
                "price": 1191.82,
                "post_only": false,
                "order_type": "limit",
                "order_id": "720074",
                "mmp": false,
                "matching_id": null,
                "mark_price": 767.6,
                "liquidity": "T",
                "legs": [
                  {
                    "trade_seq": 179,
                    "trade_id": "1156",
                    "timestamp": 1661867454335,
                    "tick_direction": 2,
                    "state": "filled",
                    "risk_reducing": false,
                    "reduce_only": false,
                    "profit_loss": 0,
                    "price": 20008.5,
                    "post_only": false,
                    "order_type": "limit",
                    "order_id": "720078",
                    "mmp": false,
                    "matching_id": null,
                    "mark_price": 20220.61,
                    "liquidity": "T",
                    "instrument_name": "BTC-PERPETUAL",
                    "index_price": 20332.44,
                    "fee_currency": "BTC",
                    "fee": 5e-8,
                    "direction": "buy",
                    "combo_trade_id": "1154",
                    "combo_id": "BTC-FS-2SEP22_PERP",
                    "api": false,
                    "amount": 10
                  },
                  {
                    "trade_seq": 159,
                    "trade_id": "1155",
                    "timestamp": 1661867454335,
                    "tick_direction": 0,
                    "state": "filled",
                    "risk_reducing": false,
                    "reduce_only": false,
                    "profit_loss": 0,
                    "price": 21200.32,
                    "post_only": false,
                    "order_type": "limit",
                    "order_id": "720077",
                    "mmp": false,
                    "matching_id": null,
                    "mark_price": 20988.21,
                    "liquidity": "T",
                    "instrument_name": "BTC-2SEP22",
                    "index_price": 20332.44,
                    "fee_currency": "BTC",
                    "fee": 5e-8,
                    "direction": "sell",
                    "combo_trade_id": "1154",
                    "combo_id": "BTC-FS-2SEP22_PERP",
                    "api": false,
                    "amount": 10
                  }
                ],
                "instrument_name": "BTC-FS-2SEP22_PERP",
                "index_price": 20332.44,
                "fee_currency": "BTC",
                "fee": 0,
                "direction": "sell",
                "api": false,
                "amount": 10
              }
            ]
          }
        bindings: []
        extensions:
          - id: x-parser-unique-object-id
            value: subscription_message
    bindings: []
    extensions: &ref_0
      - id: x-parser-unique-object-id
        value: user.combo_trades.(instrument_name).(interval)
  - &ref_1
    id: receive_user_combo_trades_instrument_name_interval_updates
    title: Receive user updates
    description: Client receives user update notifications
    type: receive
    messages:
      - &ref_3
        id: subscribe_request
        contentType: application/json
        payload:
          - name: Subscription Request
            description: >-
              Client sends subscription request to subscribe to notification
              channel. Please refer to [Notification
              page](https://deribit.mintlify.app/articles/notifications) for
              more information.
            type: object
            properties: []
        headers: []
        jsonPayloadSchema:
          properties: {}
          additionalProperties: false
          x-parser-schema-id: <anonymous-schema-456>
        title: Subscription Request
        description: >-
          Client sends subscription request to subscribe to notification
          channel. Please refer to [Notification
          page](https://deribit.mintlify.app/articles/notifications) for more
          information.
        example: |-
          {
            "jsonrpc": "2.0",
            "method": "public/subscribe",
            "id": 42,
            "params": {
              "channels": [
                "user.combo_trades.BTC-PERPETUAL.100ms"
              ]
            }
          }
        bindings: []
        extensions:
          - id: x-parser-unique-object-id
            value: subscribe_request
    bindings: []
    extensions: *ref_0
sendOperations:
  - *ref_1
receiveOperations:
  - *ref_2
sendMessages:
  - *ref_3
receiveMessages:
  - *ref_4
extensions:
  - id: x-parser-unique-object-id
    value: user.combo_trades.(instrument_name).(interval)
securitySchemes: []

````


> ## Documentation Index
> Fetch the complete documentation index at: https://docs.deribit.com/llms.txt
> Use this file to discover all available pages before exploring further.

<AgentInstructions>

## Submitting Feedback

If you encounter incorrect, outdated, or confusing documentation on this page, submit feedback:

POST https://docs.deribit.com/feedback

```json
{
  "path": "/subscriptions/user/usercombo_tradeskindcurrencyinterval",
  "feedback": "Description of the issue"
}
```

Only submit feedback when you have something specific and actionable to report.

</AgentInstructions>

# user.combo_trades.(kind).(currency).(interval) 

> User trade notifications across all combo instruments for a given kind and currency.

Trades include a `legs` field describing the underlying legs. The `interval` controls aggregation frequency.




## AsyncAPI

````yaml specifications/deribit_asyncapi.json user.combo_trades.(kind).(currency).(interval)
id: user.combo_trades.(kind).(currency).(interval)
title: 'user.combo_trades.(kind).(currency).(interval) '
description: >
  User trade notifications across all combo instruments for a given kind and
  currency.


  Trades include a `legs` field describing the underlying legs. The `interval`
  controls aggregation frequency.
servers:
  - id: production
    protocol: wss
    host: deribit.com/ws/api/v2
    bindings: []
    variables: []
  - id: testnet
    protocol: wss
    host: test.deribit.com/ws/api/v2
    bindings: []
    variables: []
address: user.combo_trades.(kind).(currency).(interval)
parameters:
  - id: kind
    jsonSchema:
      type: string
      description: >-
        Instrument kind


        **Allowed values:** `future`, `option`, `spot`, `future_combo`,
        `option_combo`
      enum:
        - future
        - option
        - spot
        - future_combo
        - option_combo
    description: >-
      Instrument kind


      **Allowed values:** `future`, `option`, `spot`, `future_combo`,
      `option_combo`
    type: string
    required: true
    deprecated: false
  - id: currency
    jsonSchema:
      type: string
      description: |-
        Currency code or `any` for all

        **Allowed values:** `BTC`, `ETH`, `USDC`, `USDT`, `EURR`, `any`
      enum:
        - BTC
        - ETH
        - USDC
        - USDT
        - EURR
        - any
    description: |-
      Currency code or `any` for all

      **Allowed values:** `BTC`, `ETH`, `USDC`, `USDT`, `EURR`, `any`
    type: string
    required: true
    deprecated: false
  - id: interval
    jsonSchema:
      type: string
      description: >-
        Frequency of notifications. Events will be aggregated over this
        interval. The value `raw` means no aggregation will be applied **(Please
        note that `raw` interval is only available to authorized users)**


        **Allowed values:** `raw`, `100ms`, `agg2`
      enum:
        - raw
        - 100ms
        - agg2
    description: >-
      Frequency of notifications. Events will be aggregated over this interval.
      The value `raw` means no aggregation will be applied **(Please note that
      `raw` interval is only available to authorized users)**


      **Allowed values:** `raw`, `100ms`, `agg2`
    type: string
    required: true
    deprecated: false
bindings: []
operations:
  - &ref_2
    id: send_subscribe_user_combo_trades_kind_currency_interval
    title: Send subscribe request for user
    description: Client sends subscription request for user updates
    type: send
    messages:
      - &ref_4
        id: subscription_message
        contentType: application/json
        payload:
          - name: Subscription Notification Data
            description: Server sends subscription notification data
            type: object
            properties:
              - name: data
                type: object
                required: true
                properties:
                  - name: trade_id
                    type: string
                    description: Unique (per currency) trade identifier
                    required: false
                  - name: trade_seq
                    type: integer
                    description: The sequence number of the trade within instrument
                    required: false
                  - name: instrument_name
                    type: string
                    description: Unique instrument identifier
                    required: false
                  - name: timestamp
                    type: integer
                    description: >-
                      The timestamp of the trade (milliseconds since the UNIX
                      epoch)
                    required: false
                  - name: order_type
                    type: string
                    description: 'Order type: `"limit`, `"market"`, or `"liquidation"`'
                    enumValues:
                      - limit
                      - market
                      - liquidation
                    required: false
                  - name: advanced
                    type: string
                    description: >-
                      Advanced type of user order: `"usd"` or `"implv"` (only
                      for options; omitted if not applicable)
                    enumValues:
                      - usd
                      - implv
                    required: false
                  - name: order_id
                    type: string
                    description: >-
                      Id of the user order (maker or taker), i.e. subscriber's
                      order id that took part in the trade
                    required: false
                  - name: matching_id
                    type: string
                    description: Always `null`
                    required: false
                  - name: direction
                    type: string
                    description: 'Direction: `buy`, or `sell`'
                    enumValues:
                      - buy
                      - sell
                    required: false
                  - name: tick_direction
                    type: integer
                    description: >-
                      Direction of the "tick" (`0` = Plus Tick, `1` = Zero-Plus
                      Tick, `2` = Minus Tick, `3` = Zero-Minus Tick).
                    enumValues:
                      - 0
                      - 1
                      - 2
                      - 3
                    required: false
                  - name: index_price
                    type: number
                    description: Index Price at the moment of trade
                    required: false
                  - name: price
                    type: number
                    description: Price in base currency
                    required: false
                  - name: amount
                    type: number
                    description: >-
                      Trade amount. For perpetual and inverse futures the amount
                      is in USD units. For options and linear futures it is the
                      underlying base currency coin.
                    required: false
                  - name: contracts
                    type: number
                    description: >-
                      Trade size in contract units (optional, may be absent in
                      historical trades)
                    required: false
                  - name: iv
                    type: number
                    description: Option implied volatility for the price (Option only)
                    required: false
                  - name: underlying_price
                    type: number
                    description: >-
                      Underlying price for implied volatility calculations
                      (Options only)
                    required: false
                  - name: liquidation
                    type: string
                    description: >-
                      Optional field (only for trades caused by liquidation):
                      `"M"` when maker side of trade was under liquidation,
                      `"T"` when taker side was under liquidation, `"MT"` when
                      both sides of trade were under liquidation
                    enumValues:
                      - M
                      - T
                      - MT
                    required: false
                  - name: liquidity
                    type: string
                    description: >-
                      Describes what was role of users order: `"M"` when it was
                      maker order, `"T"` when it was taker order
                    enumValues:
                      - M
                      - T
                    required: false
                  - name: fee
                    type: number
                    description: User's fee in units of the specified `fee_currency`
                    required: false
                  - name: fee_currency
                    type: string
                    description: Currency, i.e `"BTC"`, `"ETH"`, `"USDC"`
                    enumValues:
                      - BTC
                      - ETH
                      - USDC
                      - USDT
                      - EURR
                    required: false
                  - name: label
                    type: string
                    description: >-
                      User defined label (presented only when previously set for
                      order by user)
                    required: false
                  - name: state
                    type: string
                    description: >-
                      Order state: `"open"`, `"filled"`, `"rejected"`,
                      `"cancelled"`, `"untriggered"` or `"archive"` (if order
                      was archived)
                    enumValues:
                      - open
                      - filled
                      - rejected
                      - cancelled
                      - untriggered
                      - archive
                    required: false
                  - name: block_trade_id
                    type: string
                    description: Block trade id - when trade was part of a block trade
                    required: false
                  - name: block_rfq_id
                    type: integer
                    description: ID of the Block RFQ - when trade was part of the Block RFQ
                    required: false
                  - name: block_rfq_quote_id
                    type: integer
                    description: >-
                      ID of the Block RFQ quote - when trade was part of the
                      Block RFQ
                    required: false
                  - name: reduce_only
                    type: string
                    description: '`true` if user order is reduce-only'
                    required: false
                  - name: post_only
                    type: string
                    description: '`true` if user order is post-only'
                    required: false
                  - name: mmp
                    type: boolean
                    description: '`true` if user order is MMP'
                    required: false
                  - name: risk_reducing
                    type: boolean
                    description: >-
                      `true` if user order is marked by the platform as a risk
                      reducing order (can apply only to orders placed by PM
                      users)
                    required: false
                  - name: api
                    type: boolean
                    description: '`true` if user order was created with API'
                    required: false
                  - name: profit_loss
                    type: number
                    description: Profit and loss in base currency.
                    required: false
                  - name: mark_price
                    type: number
                    description: Mark Price at the moment of trade
                    required: false
                  - name: legs
                    type: array
                    description: >-
                      Optional field containing leg trades if trade is a combo
                      trade (present when querying for **only** combo trades and
                      in `combo_trades` events)
                    required: false
                  - name: combo_id
                    type: string
                    description: >-
                      Optional field containing combo instrument name if the
                      trade is a combo trade
                    required: false
                  - name: combo_trade_id
                    type: number
                    description: >-
                      Optional field containing combo trade identifier if the
                      trade is a combo trade
                    required: false
                  - name: quote_set_id
                    type: string
                    description: >-
                      QuoteSet of the user order (optional, present only for
                      orders placed with `private/mass_quote`)
                    required: false
                  - name: quote_id
                    type: string
                    description: >-
                      QuoteID of the user order (optional, present only for
                      orders placed with `private/mass_quote`)
                    required: false
                  - name: trade_allocations
                    type: object
                    description: >-
                      List of allocations for Block RFQ pre-allocation. Each
                      allocation specifies `user_id`, `amount`, and `fee` for
                      the allocated part of the trade. For broker client
                      allocations, a `client_info` object will be included.
                    required: false
                    properties:
                      - name: user_id
                        type: integer
                        description: >-
                          User ID to which part of the trade is allocated. For
                          brokers the User ID is obstructed.
                        required: false
                      - name: amount
                        type: number
                        description: Amount allocated to this user.
                        required: false
                      - name: fee
                        type: number
                        description: Fee for the allocated part of the trade.
                        required: false
                      - name: client_info
                        type: object
                        description: Optional client allocation info for brokers.
                        required: false
                        properties:
                          - name: client_id
                            type: integer
                            description: >-
                              ID of a client; available to broker. Represents a
                              group of users under a common name.
                            required: false
                          - name: client_link_id
                            type: integer
                            description: >-
                              ID assigned to a single user in a client;
                              available to broker.
                            required: false
                          - name: name
                            type: string
                            description: >-
                              Name of the linked user within the client;
                              available to broker.
                            required: false
        headers: []
        jsonPayloadSchema:
          type: object
          description: Response containing notification data
          properties:
            data:
              type: object
              description: ''
              properties:
                trade_id:
                  type: string
                  description: Unique (per currency) trade identifier
                  x-parser-schema-id: <anonymous-schema-510>
                trade_seq:
                  description: The sequence number of the trade within instrument
                  type: integer
                  x-parser-schema-id: <anonymous-schema-511>
                instrument_name:
                  type: string
                  description: Unique instrument identifier
                  example: BTC-PERPETUAL
                  x-parser-schema-id: <anonymous-schema-512>
                timestamp:
                  description: >-
                    The timestamp of the trade (milliseconds since the UNIX
                    epoch)
                  example: 1517329113791
                  type: integer
                  x-parser-schema-id: <anonymous-schema-513>
                order_type:
                  type: string
                  description: 'Order type: `"limit`, `"market"`, or `"liquidation"`'
                  enum:
                    - limit
                    - market
                    - liquidation
                  x-parser-schema-id: <anonymous-schema-514>
                advanced:
                  type: string
                  description: >-
                    Advanced type of user order: `"usd"` or `"implv"` (only for
                    options; omitted if not applicable)
                  enum:
                    - usd
                    - implv
                  x-parser-schema-id: <anonymous-schema-515>
                order_id:
                  type: string
                  description: >-
                    Id of the user order (maker or taker), i.e. subscriber's
                    order id that took part in the trade
                  x-parser-schema-id: <anonymous-schema-516>
                matching_id:
                  type: string
                  description: Always `null`
                  x-parser-schema-id: <anonymous-schema-517>
                direction:
                  type: string
                  description: 'Direction: `buy`, or `sell`'
                  enum:
                    - buy
                    - sell
                  x-parser-schema-id: <anonymous-schema-518>
                tick_direction:
                  type: integer
                  enum:
                    - 0
                    - 1
                    - 2
                    - 3
                  description: >-
                    Direction of the "tick" (`0` = Plus Tick, `1` = Zero-Plus
                    Tick, `2` = Minus Tick, `3` = Zero-Minus Tick).
                  x-parser-schema-id: <anonymous-schema-519>
                index_price:
                  type: number
                  description: Index Price at the moment of trade
                  x-parser-schema-id: <anonymous-schema-520>
                price:
                  description: Price in base currency
                  type: number
                  x-parser-schema-id: <anonymous-schema-521>
                amount:
                  type: number
                  description: >-
                    Trade amount. For perpetual and inverse futures the amount
                    is in USD units. For options and linear futures it is the
                    underlying base currency coin.
                  x-parser-schema-id: <anonymous-schema-522>
                contracts:
                  type: number
                  description: >-
                    Trade size in contract units (optional, may be absent in
                    historical trades)
                  x-parser-schema-id: <anonymous-schema-523>
                iv:
                  type: number
                  description: Option implied volatility for the price (Option only)
                  x-parser-schema-id: <anonymous-schema-524>
                underlying_price:
                  type: number
                  description: >-
                    Underlying price for implied volatility calculations
                    (Options only)
                  x-parser-schema-id: <anonymous-schema-525>
                liquidation:
                  type: string
                  description: >-
                    Optional field (only for trades caused by liquidation):
                    `"M"` when maker side of trade was under liquidation, `"T"`
                    when taker side was under liquidation, `"MT"` when both
                    sides of trade were under liquidation
                  enum:
                    - M
                    - T
                    - MT
                  x-parser-schema-id: <anonymous-schema-526>
                liquidity:
                  type: string
                  description: >-
                    Describes what was role of users order: `"M"` when it was
                    maker order, `"T"` when it was taker order
                  enum:
                    - M
                    - T
                  x-parser-schema-id: <anonymous-schema-527>
                fee:
                  type: number
                  description: User's fee in units of the specified `fee_currency`
                  x-parser-schema-id: <anonymous-schema-528>
                fee_currency:
                  type: string
                  description: Currency, i.e `"BTC"`, `"ETH"`, `"USDC"`
                  enum:
                    - BTC
                    - ETH
                    - USDC
                    - USDT
                    - EURR
                  x-parser-schema-id: <anonymous-schema-529>
                label:
                  type: string
                  description: >-
                    User defined label (presented only when previously set for
                    order by user)
                  x-parser-schema-id: <anonymous-schema-530>
                state:
                  type: string
                  description: >-
                    Order state: `"open"`, `"filled"`, `"rejected"`,
                    `"cancelled"`, `"untriggered"` or `"archive"` (if order was
                    archived)
                  enum:
                    - open
                    - filled
                    - rejected
                    - cancelled
                    - untriggered
                    - archive
                  x-parser-schema-id: <anonymous-schema-531>
                block_trade_id:
                  description: Block trade id - when trade was part of a block trade
                  type: string
                  example: '154'
                  x-parser-schema-id: <anonymous-schema-532>
                block_rfq_id:
                  type: integer
                  description: ID of the Block RFQ - when trade was part of the Block RFQ
                  x-parser-schema-id: <anonymous-schema-533>
                block_rfq_quote_id:
                  type: integer
                  description: >-
                    ID of the Block RFQ quote - when trade was part of the Block
                    RFQ
                  x-parser-schema-id: <anonymous-schema-534>
                reduce_only:
                  type: string
                  description: '`true` if user order is reduce-only'
                  x-parser-schema-id: <anonymous-schema-535>
                post_only:
                  type: string
                  description: '`true` if user order is post-only'
                  x-parser-schema-id: <anonymous-schema-536>
                mmp:
                  type: boolean
                  description: '`true` if user order is MMP'
                  x-parser-schema-id: <anonymous-schema-537>
                risk_reducing:
                  type: boolean
                  description: >-
                    `true` if user order is marked by the platform as a risk
                    reducing order (can apply only to orders placed by PM users)
                  x-parser-schema-id: <anonymous-schema-538>
                api:
                  type: boolean
                  description: '`true` if user order was created with API'
                  x-parser-schema-id: <anonymous-schema-539>
                profit_loss:
                  type: number
                  description: Profit and loss in base currency.
                  x-parser-schema-id: <anonymous-schema-540>
                mark_price:
                  type: number
                  description: Mark Price at the moment of trade
                  x-parser-schema-id: <anonymous-schema-541>
                legs:
                  type: array
                  description: >-
                    Optional field containing leg trades if trade is a combo
                    trade (present when querying for **only** combo trades and
                    in `combo_trades` events)
                  x-parser-schema-id: <anonymous-schema-542>
                combo_id:
                  type: string
                  description: >-
                    Optional field containing combo instrument name if the trade
                    is a combo trade
                  x-parser-schema-id: <anonymous-schema-543>
                combo_trade_id:
                  type: number
                  description: >-
                    Optional field containing combo trade identifier if the
                    trade is a combo trade
                  x-parser-schema-id: <anonymous-schema-544>
                quote_set_id:
                  type: string
                  description: >-
                    QuoteSet of the user order (optional, present only for
                    orders placed with `private/mass_quote`)
                  x-parser-schema-id: <anonymous-schema-545>
                quote_id:
                  type: string
                  description: >-
                    QuoteID of the user order (optional, present only for orders
                    placed with `private/mass_quote`)
                  x-parser-schema-id: <anonymous-schema-546>
                trade_allocations:
                  type: object
                  description: >-
                    List of allocations for Block RFQ pre-allocation. Each
                    allocation specifies `user_id`, `amount`, and `fee` for the
                    allocated part of the trade. For broker client allocations,
                    a `client_info` object will be included.
                  properties:
                    user_id:
                      description: >-
                        User ID to which part of the trade is allocated. For
                        brokers the User ID is obstructed.
                      type: integer
                      x-parser-schema-id: <anonymous-schema-548>
                    amount:
                      description: Amount allocated to this user.
                      type: number
                      x-parser-schema-id: <anonymous-schema-549>
                    fee:
                      description: Fee for the allocated part of the trade.
                      type: number
                      x-parser-schema-id: <anonymous-schema-550>
                    client_info:
                      description: Optional client allocation info for brokers.
                      type: object
                      properties:
                        client_id:
                          description: >-
                            ID of a client; available to broker. Represents a
                            group of users under a common name.
                          type: integer
                          x-parser-schema-id: <anonymous-schema-552>
                        client_link_id:
                          description: >-
                            ID assigned to a single user in a client; available
                            to broker.
                          type: integer
                          x-parser-schema-id: <anonymous-schema-553>
                        name:
                          description: >-
                            Name of the linked user within the client; available
                            to broker.
                          type: string
                          x-parser-schema-id: <anonymous-schema-554>
                      x-parser-schema-id: <anonymous-schema-551>
                  required:
                    - amount
                    - fee
                  additionalProperties: false
                  x-parser-schema-id: <anonymous-schema-547>
              required:
                - trade_id
                - trade_seq
                - instrument_name
                - timestamp
                - order_id
                - matching_id
                - direction
                - tick_direction
                - index_price
                - price
                - amount
                - fee
                - fee_currency
                - state
                - mark_price
              additionalProperties: false
              x-parser-schema-id: <anonymous-schema-509>
          required:
            - data
          additionalProperties: false
          x-parser-schema-id: <anonymous-schema-508>
        title: Subscription Notification Data
        description: Server sends subscription notification data
        example: |-
          {
            "data": [
              {
                "trade_seq": 39,
                "trade_id": "1154",
                "timestamp": 1661867454334,
                "tick_direction": 2,
                "state": "filled",
                "risk_reducing": false,
                "reduce_only": false,
                "profit_loss": null,
                "price": 1191.82,
                "post_only": false,
                "order_type": "limit",
                "order_id": "720074",
                "mmp": false,
                "matching_id": null,
                "mark_price": 767.6,
                "liquidity": "T",
                "legs": [
                  {
                    "trade_seq": 179,
                    "trade_id": "1156",
                    "timestamp": 1661867454335,
                    "tick_direction": 2,
                    "state": "filled",
                    "risk_reducing": false,
                    "reduce_only": false,
                    "profit_loss": 0,
                    "price": 20008.5,
                    "post_only": false,
                    "order_type": "limit",
                    "order_id": "720078",
                    "mmp": false,
                    "matching_id": null,
                    "mark_price": 20220.61,
                    "liquidity": "T",
                    "instrument_name": "BTC-PERPETUAL",
                    "index_price": 20332.44,
                    "fee_currency": "BTC",
                    "fee": 5e-8,
                    "direction": "buy",
                    "combo_trade_id": "1154",
                    "combo_id": "BTC-FS-2SEP22_PERP",
                    "api": false,
                    "amount": 10
                  },
                  {
                    "trade_seq": 159,
                    "trade_id": "1155",
                    "timestamp": 1661867454335,
                    "tick_direction": 0,
                    "state": "filled",
                    "risk_reducing": false,
                    "reduce_only": false,
                    "profit_loss": 0,
                    "price": 21200.32,
                    "post_only": false,
                    "order_type": "limit",
                    "order_id": "720077",
                    "mmp": false,
                    "matching_id": null,
                    "mark_price": 20988.21,
                    "liquidity": "T",
                    "instrument_name": "BTC-2SEP22",
                    "index_price": 20332.44,
                    "fee_currency": "BTC",
                    "fee": 5e-8,
                    "direction": "sell",
                    "combo_trade_id": "1154",
                    "combo_id": "BTC-FS-2SEP22_PERP",
                    "api": false,
                    "amount": 10
                  }
                ],
                "instrument_name": "BTC-FS-2SEP22_PERP",
                "index_price": 20332.44,
                "fee_currency": "BTC",
                "fee": 0,
                "direction": "sell",
                "api": false,
                "amount": 10
              }
            ]
          }
        bindings: []
        extensions:
          - id: x-parser-unique-object-id
            value: subscription_message
    bindings: []
    extensions: &ref_0
      - id: x-parser-unique-object-id
        value: user.combo_trades.(kind).(currency).(interval)
  - &ref_1
    id: receive_user_combo_trades_kind_currency_interval_updates
    title: Receive user updates
    description: Client receives user update notifications
    type: receive
    messages:
      - &ref_3
        id: subscribe_request
        contentType: application/json
        payload:
          - name: Subscription Request
            description: >-
              Client sends subscription request to subscribe to notification
              channel. Please refer to [Notification
              page](https://deribit.mintlify.app/articles/notifications) for
              more information.
            type: object
            properties: []
        headers: []
        jsonPayloadSchema:
          properties: {}
          additionalProperties: false
          x-parser-schema-id: <anonymous-schema-507>
        title: Subscription Request
        description: >-
          Client sends subscription request to subscribe to notification
          channel. Please refer to [Notification
          page](https://deribit.mintlify.app/articles/notifications) for more
          information.
        example: |-
          {
            "jsonrpc": "2.0",
            "method": "public/subscribe",
            "id": 42,
            "params": {
              "channels": [
                "user.combo_trades.(kind).(currency).100ms"
              ]
            }
          }
        bindings: []
        extensions:
          - id: x-parser-unique-object-id
            value: subscribe_request
    bindings: []
    extensions: *ref_0
sendOperations:
  - *ref_1
receiveOperations:
  - *ref_2
sendMessages:
  - *ref_3
receiveMessages:
  - *ref_4
extensions:
  - id: x-parser-unique-object-id
    value: user.combo_trades.(kind).(currency).(interval)
securitySchemes: []

````

> ## Documentation Index
> Fetch the complete documentation index at: https://docs.deribit.com/llms.txt
> Use this file to discover all available pages before exploring further.

<AgentInstructions>

## Submitting Feedback

If you encounter incorrect, outdated, or confusing documentation on this page, submit feedback:

POST https://docs.deribit.com/feedback

```json
{
  "path": "/subscriptions/user/userordersinstrument_nameraw",
  "feedback": "Description of the issue"
}
```

Only submit feedback when you have something specific and actionable to report.

</AgentInstructions>

# user.orders.(instrument_name).raw 

> User order updates for a specific instrument (raw stream).

Use this channel to receive private order updates for the given instrument with the highest granularity (raw). Prefer this for real-time order state tracking.




## AsyncAPI

````yaml specifications/deribit_asyncapi.json user.orders.(instrument_name).raw
id: user.orders.(instrument_name).raw
title: 'user.orders.(instrument_name).raw '
description: >
  User order updates for a specific instrument (raw stream).


  Use this channel to receive private order updates for the given instrument
  with the highest granularity (raw). Prefer this for real-time order state
  tracking.
servers:
  - id: production
    protocol: wss
    host: deribit.com/ws/api/v2
    bindings: []
    variables: []
  - id: testnet
    protocol: wss
    host: test.deribit.com/ws/api/v2
    bindings: []
    variables: []
address: user.orders.(instrument_name).raw
parameters:
  - id: instrument_name
    jsonSchema:
      type: string
      description: The name of the instrument
    description: The name of the instrument
    type: string
    required: true
    deprecated: false
bindings: []
operations:
  - &ref_2
    id: send_subscribe_user_orders_instrument_name_raw
    title: Send subscribe request for user
    description: Client sends subscription request for user updates
    type: send
    messages:
      - &ref_4
        id: subscription_message
        contentType: application/json
        payload:
          - name: Subscription Notification Data
            description: Server sends subscription notification data
            type: object
            properties:
              - name: data
                type: object
                required: true
                properties:
                  - name: order_id
                    type: string
                    description: Unique order identifier
                    required: false
                  - name: order_state
                    type: string
                    description: >-
                      Order state: `"open"`, `"filled"`, `"rejected"`,
                      `"cancelled"`, `"untriggered"`
                    enumValues:
                      - open
                      - filled
                      - rejected
                      - cancelled
                      - untriggered
                      - triggered
                    required: false
                  - name: order_type
                    type: string
                    description: >-
                      Order type: `"limit"`, `"market"`, `"stop_limit"`,
                      `"stop_market"`, `"take_limit"`, `"take_market"`,
                      `"trailing_stop"`
                    enumValues:
                      - market
                      - limit
                      - stop_market
                      - stop_limit
                      - take_market
                      - take_limit
                      - trailing_stop
                    required: false
                  - name: original_order_type
                    type: string
                    description: Original order type. Optional field
                    enumValues:
                      - market
                      - market_limit
                    required: false
                  - name: time_in_force
                    type: string
                    description: >-
                      Order time in force: `"good_til_cancelled"`,
                      `"good_til_day"`, `"fill_or_kill"` or
                      `"immediate_or_cancel"`
                    enumValues:
                      - good_til_cancelled
                      - good_til_day
                      - fill_or_kill
                      - immediate_or_cancel
                    required: false
                  - name: is_rebalance
                    type: boolean
                    description: >-
                      Optional (only for spot). `true` if order was
                      automatically created during cross-collateral balance
                      restoration
                    required: false
                  - name: is_liquidation
                    type: boolean
                    description: >-
                      Optional (not added for spot). `true` if order was
                      automatically created during liquidation
                    required: false
                  - name: instrument_name
                    type: string
                    description: Unique instrument identifier
                    required: false
                  - name: creation_timestamp
                    type: integer
                    description: The timestamp (milliseconds since the Unix epoch)
                    required: false
                  - name: last_update_timestamp
                    type: integer
                    description: The timestamp (milliseconds since the Unix epoch)
                    required: false
                  - name: direction
                    type: string
                    description: 'Direction: `buy`, or `sell`'
                    enumValues:
                      - buy
                      - sell
                    required: false
                  - name: description
                    type: string
                    description: >-
                      Price in base currency or "market_price" in case of open
                      trigger market orders
                    required: false
                  - name: label
                    type: string
                    description: User defined label (up to 64 characters)
                    required: false
                  - name: post_only
                    type: boolean
                    description: '`true` for post-only orders only'
                    required: false
                  - name: reject_post_only
                    type: boolean
                    description: >-
                      `true` if order has `reject_post_only` flag (field is
                      present only when `post_only` is `true`)
                    required: false
                  - name: reduce_only
                    type: boolean
                    description: >-
                      Optional (not added for spot). '`true` for reduce-only
                      orders only'
                    required: false
                  - name: api
                    type: boolean
                    description: '`true` if created with API'
                    required: false
                  - name: web
                    type: boolean
                    description: '`true` if created via Deribit frontend (optional)'
                    required: false
                  - name: mobile
                    type: boolean
                    description: >-
                      Optional field with value `true` added only when created
                      with Mobile Application
                    required: false
                  - name: refresh_amount
                    type: number
                    description: >-
                      The initial display amount of iceberg order. Iceberg order
                      display amount will be refreshed to that value after match
                      consuming actual display amount. Absent for other types of
                      orders
                    required: false
                  - name: display_amount
                    type: number
                    description: >-
                      The actual display amount of iceberg order. Absent for
                      other types of orders.
                    required: false
                  - name: amount
                    type: number
                    description: >-
                      It represents the requested order size. For perpetual and
                      inverse futures the amount is in USD units. For options
                      and linear futures it is the underlying base currency
                      coin.
                    required: false
                  - name: contracts
                    type: number
                    description: >-
                      It represents the order size in contract units. (Optional,
                      may be absent in historical data).
                    required: false
                  - name: filled_amount
                    type: number
                    description: >-
                      Filled amount of the order. For perpetual and futures the
                      filled_amount is in USD units, for options - in units or
                      corresponding cryptocurrency contracts, e.g., BTC or ETH.
                    required: false
                  - name: average_price
                    type: number
                    description: Average fill price of the order
                    required: false
                  - name: advanced
                    type: string
                    description: >
                      advanced type: `"usd"` or `"implv"` (Only for options;
                      field is omitted if not applicable).
                    enumValues:
                      - usd
                      - implv
                    required: false
                  - name: implv
                    type: number
                    description: >-
                      Implied volatility in percent. (Only if
                      `advanced="implv"`)
                    required: false
                  - name: usd
                    type: number
                    description: Option price in USD (Only if `advanced="usd"`)
                    required: false
                  - name: triggered
                    type: boolean
                    description: Whether the trigger order has been triggered
                    required: false
                  - name: trigger
                    type: string
                    description: >-
                      Trigger type (only for trigger orders). Allowed values:
                      `"index_price"`, `"mark_price"`, `"last_price"`.
                    enumValues:
                      - index_price
                      - mark_price
                      - last_price
                    required: false
                  - name: trigger_price
                    type: number
                    description: Trigger price (Only for future trigger orders)
                    required: false
                  - name: trigger_offset
                    type: number
                    description: >-
                      The maximum deviation from the price peak beyond which the
                      order will be triggered (Only for trailing trigger orders)
                    required: false
                  - name: trigger_reference_price
                    type: number
                    description: >-
                      The price of the given trigger at the time when the order
                      was placed (Only for trailing trigger orders)
                    required: false
                  - name: block_trade
                    type: boolean
                    description: >-
                      `true` if order made from block_trade trade, added only in
                      that case.
                    required: false
                  - name: mmp
                    type: boolean
                    description: '`true` if the order is a MMP order, otherwise `false`.'
                    required: false
                  - name: risk_reducing
                    type: boolean
                    description: >-
                      `true` if the order is marked by the platform as a risk
                      reducing order (can apply only to orders placed by PM
                      users), otherwise `false`.
                    required: false
                  - name: replaced
                    type: boolean
                    description: >-
                      `true` if the order was edited (by user or - in case of
                      advanced options orders - by pricing engine), otherwise
                      `false`.
                    required: false
                  - name: auto_replaced
                    type: boolean
                    description: >-
                      Options, advanced orders only - `true` if last
                      modification of the order was performed by the pricing
                      engine, otherwise `false`.
                    required: false
                  - name: quote
                    type: boolean
                    description: If order is a quote. Present only if true.
                    required: false
                  - name: mmp_group
                    type: string
                    description: >-
                      Name of the MMP group supplied in the `private/mass_quote`
                      request. Only present for quote orders.
                    required: false
                  - name: quote_set_id
                    type: string
                    description: >-
                      Identifier of the QuoteSet supplied in the
                      `private/mass_quote` request. Only present for quote
                      orders.
                    required: false
                  - name: quote_id
                    type: string
                    description: >-
                      The same QuoteID as supplied in the `private/mass_quote`
                      request. Only present for quote orders.
                    required: false
                  - name: trigger_order_id
                    type: string
                    description: >-
                      Id of the trigger order that created the order (Only for
                      orders that were created by triggered orders).
                    required: false
                  - name: app_name
                    type: string
                    description: >-
                      The name of the application that placed the order on
                      behalf of the user (optional).
                    required: false
                  - name: mmp_cancelled
                    type: boolean
                    description: '`true` if order was cancelled by mmp trigger (optional)'
                    required: false
                  - name: cancel_reason
                    type: string
                    description: >-
                      Enumerated reason behind cancel `"user_request"`,
                      `"autoliquidation"`, `"cancel_on_disconnect"`,
                      `"risk_mitigation"`, `"pme_risk_reduction"` (portfolio
                      margining risk reduction), `"pme_account_locked"`
                      (portfolio margining account locked per currency),
                      `"position_locked"`, `"mmp_trigger"` (market maker
                      protection), `"mmp_config_curtailment"` (market maker
                      configured quantity decreased), `"edit_post_only_reject"`
                      (cancelled on edit because of `reject_post_only` setting),
                      `"oco_other_closed"` (the oco order linked to this order
                      was closed), `"oto_primary_closed"` (the oto primary order
                      that was going to trigger this order was cancelled),
                      `"settlement"` (closed because of a settlement)
                    enumValues:
                      - user_request
                      - autoliquidation
                      - cancel_on_disconnect
                      - risk_mitigation
                      - pme_risk_reduction
                      - pme_account_locked
                      - position_locked
                      - mmp_trigger
                      - mmp_config_curtailment
                      - edit_post_only_reject
                      - oco_other_closed
                      - oto_primary_closed
                      - settlement
                    required: false
                  - name: oto_order_ids
                    type: object
                    description: >-
                      The Ids of the orders that will be triggered if the order
                      is filled
                    required: false
                    properties: []
                  - name: trigger_fill_condition
                    type: string
                    description: >-
                      <p>The fill condition of the linked order (Only for linked
                      order types), default: `first_hit`.</p> <ul>
                      <li>`"first_hit"` - any execution of the primary order
                      will fully cancel/place all secondary orders.</li>
                      <li>`"complete_fill"` - a complete execution (meaning the
                      primary order no longer exists) will cancel/place the
                      secondary orders.</li> <li>`"incremental"` - any fill of
                      the primary order will cause proportional partial
                      cancellation/placement of the secondary order. The amount
                      that will be subtracted/added to the secondary order will
                      be rounded down to the contract size.</li> </ul>
                    enumValues:
                      - first_hit
                      - complete_fill
                      - incremental
                    required: false
                  - name: oco_ref
                    type: string
                    description: >-
                      Unique reference that identifies a one_cancels_others
                      (OCO) pair.
                    required: false
                  - name: primary_order_id
                    type: string
                    description: Unique order identifier
                    required: false
                  - name: is_secondary_oto
                    type: boolean
                    description: >-
                      `true` if the order is an order that can be triggered by
                      another order, otherwise not present.
                    required: false
                  - name: is_primary_otoco
                    type: boolean
                    description: >-
                      `true` if the order is an order that can trigger an OCO
                      pair, otherwise not present.
                    required: false
        headers: []
        jsonPayloadSchema:
          type: object
          description: Response containing notification data
          properties:
            data:
              type: object
              properties:
                order_id:
                  description: Unique order identifier
                  type: string
                  example: ETH-100234
                  x-parser-schema-id: <anonymous-schema-567>
                order_state:
                  type: string
                  description: >-
                    Order state: `"open"`, `"filled"`, `"rejected"`,
                    `"cancelled"`, `"untriggered"`
                  enum:
                    - open
                    - filled
                    - rejected
                    - cancelled
                    - untriggered
                    - triggered
                  x-parser-schema-id: <anonymous-schema-568>
                order_type:
                  type: string
                  description: >-
                    Order type: `"limit"`, `"market"`, `"stop_limit"`,
                    `"stop_market"`, `"take_limit"`, `"take_market"`,
                    `"trailing_stop"`
                  enum:
                    - market
                    - limit
                    - stop_market
                    - stop_limit
                    - take_market
                    - take_limit
                    - trailing_stop
                  x-parser-schema-id: <anonymous-schema-569>
                original_order_type:
                  type: string
                  description: Original order type. Optional field
                  enum:
                    - market
                    - market_limit
                  x-parser-schema-id: <anonymous-schema-570>
                time_in_force:
                  type: string
                  description: >-
                    Order time in force: `"good_til_cancelled"`,
                    `"good_til_day"`, `"fill_or_kill"` or
                    `"immediate_or_cancel"`
                  enum:
                    - good_til_cancelled
                    - good_til_day
                    - fill_or_kill
                    - immediate_or_cancel
                  x-parser-schema-id: <anonymous-schema-571>
                is_rebalance:
                  type: boolean
                  description: >-
                    Optional (only for spot). `true` if order was automatically
                    created during cross-collateral balance restoration
                  x-parser-schema-id: <anonymous-schema-572>
                is_liquidation:
                  type: boolean
                  description: >-
                    Optional (not added for spot). `true` if order was
                    automatically created during liquidation
                  x-parser-schema-id: <anonymous-schema-573>
                instrument_name:
                  type: string
                  description: Unique instrument identifier
                  example: BTC-PERPETUAL
                  x-parser-schema-id: <anonymous-schema-574>
                creation_timestamp:
                  type: integer
                  example: 1536569522277
                  description: The timestamp (milliseconds since the Unix epoch)
                  x-parser-schema-id: <anonymous-schema-575>
                last_update_timestamp:
                  type: integer
                  example: 1536569522277
                  description: The timestamp (milliseconds since the Unix epoch)
                  x-parser-schema-id: <anonymous-schema-576>
                direction:
                  type: string
                  description: 'Direction: `buy`, or `sell`'
                  enum:
                    - buy
                    - sell
                  x-parser-schema-id: <anonymous-schema-577>
                price:
                  description: >-
                    Price in base currency or "market_price" in case of open
                    trigger market orders
                  x-parser-schema-id: <anonymous-schema-578>
                label:
                  type: string
                  description: User defined label (up to 64 characters)
                  x-parser-schema-id: <anonymous-schema-579>
                post_only:
                  type: boolean
                  description: '`true` for post-only orders only'
                  x-parser-schema-id: <anonymous-schema-580>
                reject_post_only:
                  description: >-
                    `true` if order has `reject_post_only` flag (field is
                    present only when `post_only` is `true`)
                  type: boolean
                  x-parser-schema-id: <anonymous-schema-581>
                reduce_only:
                  type: boolean
                  description: >-
                    Optional (not added for spot). '`true` for reduce-only
                    orders only'
                  x-parser-schema-id: <anonymous-schema-582>
                api:
                  type: boolean
                  description: '`true` if created with API'
                  x-parser-schema-id: <anonymous-schema-583>
                web:
                  type: boolean
                  description: '`true` if created via Deribit frontend (optional)'
                  x-parser-schema-id: <anonymous-schema-584>
                mobile:
                  type: boolean
                  description: >-
                    Optional field with value `true` added only when created
                    with Mobile Application
                  x-parser-schema-id: <anonymous-schema-585>
                refresh_amount:
                  type: number
                  description: >-
                    The initial display amount of iceberg order. Iceberg order
                    display amount will be refreshed to that value after match
                    consuming actual display amount. Absent for other types of
                    orders
                  x-parser-schema-id: <anonymous-schema-586>
                display_amount:
                  type: number
                  description: >-
                    The actual display amount of iceberg order. Absent for other
                    types of orders.
                  x-parser-schema-id: <anonymous-schema-587>
                amount:
                  type: number
                  description: >-
                    It represents the requested order size. For perpetual and
                    inverse futures the amount is in USD units. For options and
                    linear futures it is the underlying base currency coin.
                  x-parser-schema-id: <anonymous-schema-588>
                contracts:
                  type: number
                  description: >-
                    It represents the order size in contract units. (Optional,
                    may be absent in historical data).
                  x-parser-schema-id: <anonymous-schema-589>
                filled_amount:
                  type: number
                  description: >-
                    Filled amount of the order. For perpetual and futures the
                    filled_amount is in USD units, for options - in units or
                    corresponding cryptocurrency contracts, e.g., BTC or ETH.
                  x-parser-schema-id: <anonymous-schema-590>
                average_price:
                  type: number
                  description: Average fill price of the order
                  x-parser-schema-id: <anonymous-schema-591>
                advanced:
                  type: string
                  description: >
                    advanced type: `"usd"` or `"implv"` (Only for options; field
                    is omitted if not applicable).
                  enum:
                    - usd
                    - implv
                  x-parser-schema-id: <anonymous-schema-592>
                implv:
                  type: number
                  description: Implied volatility in percent. (Only if `advanced="implv"`)
                  x-parser-schema-id: <anonymous-schema-593>
                usd:
                  type: number
                  description: Option price in USD (Only if `advanced="usd"`)
                  x-parser-schema-id: <anonymous-schema-594>
                triggered:
                  type: boolean
                  description: Whether the trigger order has been triggered
                  x-parser-schema-id: <anonymous-schema-595>
                trigger:
                  type: string
                  description: >-
                    Trigger type (only for trigger orders). Allowed values:
                    `"index_price"`, `"mark_price"`, `"last_price"`.
                  enum:
                    - index_price
                    - mark_price
                    - last_price
                  x-parser-schema-id: <anonymous-schema-596>
                trigger_price:
                  type: number
                  description: Trigger price (Only for future trigger orders)
                  x-parser-schema-id: <anonymous-schema-597>
                trigger_offset:
                  type: number
                  description: >-
                    The maximum deviation from the price peak beyond which the
                    order will be triggered (Only for trailing trigger orders)
                  x-parser-schema-id: <anonymous-schema-598>
                trigger_reference_price:
                  type: number
                  description: >-
                    The price of the given trigger at the time when the order
                    was placed (Only for trailing trigger orders)
                  x-parser-schema-id: <anonymous-schema-599>
                block_trade:
                  description: >-
                    `true` if order made from block_trade trade, added only in
                    that case.
                  type: boolean
                  example: true
                  x-parser-schema-id: <anonymous-schema-600>
                mmp:
                  type: boolean
                  description: '`true` if the order is a MMP order, otherwise `false`.'
                  x-parser-schema-id: <anonymous-schema-601>
                risk_reducing:
                  type: boolean
                  description: >-
                    `true` if the order is marked by the platform as a risk
                    reducing order (can apply only to orders placed by PM
                    users), otherwise `false`.
                  x-parser-schema-id: <anonymous-schema-602>
                replaced:
                  type: boolean
                  description: >-
                    `true` if the order was edited (by user or - in case of
                    advanced options orders - by pricing engine), otherwise
                    `false`.
                  x-parser-schema-id: <anonymous-schema-603>
                auto_replaced:
                  type: boolean
                  description: >-
                    Options, advanced orders only - `true` if last modification
                    of the order was performed by the pricing engine, otherwise
                    `false`.
                  x-parser-schema-id: <anonymous-schema-604>
                quote:
                  type: boolean
                  description: If order is a quote. Present only if true.
                  x-parser-schema-id: <anonymous-schema-605>
                mmp_group:
                  type: string
                  description: >-
                    Name of the MMP group supplied in the `private/mass_quote`
                    request. Only present for quote orders.
                  x-parser-schema-id: <anonymous-schema-606>
                quote_set_id:
                  type: string
                  description: >-
                    Identifier of the QuoteSet supplied in the
                    `private/mass_quote` request. Only present for quote orders.
                  x-parser-schema-id: <anonymous-schema-607>
                quote_id:
                  type: string
                  description: >-
                    The same QuoteID as supplied in the `private/mass_quote`
                    request. Only present for quote orders.
                  x-parser-schema-id: <anonymous-schema-608>
                trigger_order_id:
                  type: string
                  description: >-
                    Id of the trigger order that created the order (Only for
                    orders that were created by triggered orders).
                  example: SLIB-370
                  x-parser-schema-id: <anonymous-schema-609>
                app_name:
                  type: string
                  description: >-
                    The name of the application that placed the order on behalf
                    of the user (optional).
                  example: Example Application
                  x-parser-schema-id: <anonymous-schema-610>
                mmp_cancelled:
                  type: boolean
                  description: '`true` if order was cancelled by mmp trigger (optional)'
                  example: true
                  x-parser-schema-id: <anonymous-schema-611>
                cancel_reason:
                  type: string
                  description: >-
                    Enumerated reason behind cancel `"user_request"`,
                    `"autoliquidation"`, `"cancel_on_disconnect"`,
                    `"risk_mitigation"`, `"pme_risk_reduction"` (portfolio
                    margining risk reduction), `"pme_account_locked"` (portfolio
                    margining account locked per currency), `"position_locked"`,
                    `"mmp_trigger"` (market maker protection),
                    `"mmp_config_curtailment"` (market maker configured quantity
                    decreased), `"edit_post_only_reject"` (cancelled on edit
                    because of `reject_post_only` setting), `"oco_other_closed"`
                    (the oco order linked to this order was closed),
                    `"oto_primary_closed"` (the oto primary order that was going
                    to trigger this order was cancelled), `"settlement"` (closed
                    because of a settlement)
                  enum:
                    - user_request
                    - autoliquidation
                    - cancel_on_disconnect
                    - risk_mitigation
                    - pme_risk_reduction
                    - pme_account_locked
                    - position_locked
                    - mmp_trigger
                    - mmp_config_curtailment
                    - edit_post_only_reject
                    - oco_other_closed
                    - oto_primary_closed
                    - settlement
                  x-parser-schema-id: <anonymous-schema-612>
                oto_order_ids:
                  type: object
                  description: >-
                    The Ids of the orders that will be triggered if the order is
                    filled
                  properties: {}
                  additionalProperties: true
                  x-parser-schema-id: <anonymous-schema-613>
                trigger_fill_condition:
                  description: >-
                    <p>The fill condition of the linked order (Only for linked
                    order types), default: `first_hit`.</p> <ul>
                    <li>`"first_hit"` - any execution of the primary order will
                    fully cancel/place all secondary orders.</li>
                    <li>`"complete_fill"` - a complete execution (meaning the
                    primary order no longer exists) will cancel/place the
                    secondary orders.</li> <li>`"incremental"` - any fill of the
                    primary order will cause proportional partial
                    cancellation/placement of the secondary order. The amount
                    that will be subtracted/added to the secondary order will be
                    rounded down to the contract size.</li> </ul>
                  type: string
                  enum:
                    - first_hit
                    - complete_fill
                    - incremental
                  x-parser-schema-id: <anonymous-schema-614>
                oco_ref:
                  type: string
                  description: >-
                    Unique reference that identifies a one_cancels_others (OCO)
                    pair.
                  x-parser-schema-id: <anonymous-schema-615>
                primary_order_id:
                  description: Unique order identifier
                  type: string
                  example: ETH-100234
                  x-parser-schema-id: <anonymous-schema-616>
                is_secondary_oto:
                  type: boolean
                  description: >-
                    `true` if the order is an order that can be triggered by
                    another order, otherwise not present.
                  x-parser-schema-id: <anonymous-schema-617>
                is_primary_otoco:
                  type: boolean
                  description: >-
                    `true` if the order is an order that can trigger an OCO
                    pair, otherwise not present.
                  x-parser-schema-id: <anonymous-schema-618>
              required:
                - order_id
                - order_state
                - order_type
                - time_in_force
                - instrument_name
                - creation_timestamp
                - last_update_timestamp
                - direction
                - price
                - label
                - post_only
                - api
              additionalProperties: false
              x-parser-schema-id: <anonymous-schema-566>
          required:
            - data
          additionalProperties: false
          x-parser-schema-id: <anonymous-schema-565>
        title: Subscription Notification Data
        description: Server sends subscription notification data
        example: |-
          {
            "data": {
              "time_in_force": "good_til_cancelled",
              "replaced": false,
              "reduce_only": false,
              "price": 10502.52,
              "post_only": false,
              "original_order_type": "market",
              "order_type": "limit",
              "order_state": "open",
              "order_id": "5",
              "max_show": 200,
              "last_update_timestamp": 1581507423789,
              "label": "",
              "is_rebalance": false,
              "is_liquidation": false,
              "instrument_name": "BTC-PERPETUAL",
              "filled_amount": 0,
              "direction": "buy",
              "creation_timestamp": 1581507423789,
              "average_price": 0,
              "api": false,
              "amount": 200
            }
          }
        bindings: []
        extensions:
          - id: x-parser-unique-object-id
            value: subscription_message
    bindings: []
    extensions: &ref_0
      - id: x-parser-unique-object-id
        value: user.orders.(instrument_name).raw
  - &ref_1
    id: receive_user_orders_instrument_name_raw_updates
    title: Receive user updates
    description: Client receives user update notifications
    type: receive
    messages:
      - &ref_3
        id: subscribe_request
        contentType: application/json
        payload:
          - name: Subscription Request
            description: >-
              Client sends subscription request to subscribe to notification
              channel. Please refer to [Notification
              page](https://deribit.mintlify.app/articles/notifications) for
              more information.
            type: object
            properties: []
        headers: []
        jsonPayloadSchema:
          properties: {}
          additionalProperties: false
          x-parser-schema-id: <anonymous-schema-564>
        title: Subscription Request
        description: >-
          Client sends subscription request to subscribe to notification
          channel. Please refer to [Notification
          page](https://deribit.mintlify.app/articles/notifications) for more
          information.
        example: |-
          {
            "jsonrpc": "2.0",
            "method": "public/subscribe",
            "id": 42,
            "params": {
              "channels": [
                "user.orders.BTC-PERPETUAL.raw"
              ]
            }
          }
        bindings: []
        extensions:
          - id: x-parser-unique-object-id
            value: subscribe_request
    bindings: []
    extensions: *ref_0
sendOperations:
  - *ref_1
receiveOperations:
  - *ref_2
sendMessages:
  - *ref_3
receiveMessages:
  - *ref_4
extensions:
  - id: x-parser-unique-object-id
    value: user.orders.(instrument_name).raw
securitySchemes: []

````


> ## Documentation Index
> Fetch the complete documentation index at: https://docs.deribit.com/llms.txt
> Use this file to discover all available pages before exploring further.

<AgentInstructions>

## Submitting Feedback

If you encounter incorrect, outdated, or confusing documentation on this page, submit feedback:

POST https://docs.deribit.com/feedback

```json
{
  "path": "/subscriptions/user/userordersinstrument_nameinterval",
  "feedback": "Description of the issue"
}
```

Only submit feedback when you have something specific and actionable to report.

</AgentInstructions>

# user.orders.(instrument_name).(interval) 

> User order updates for a specific instrument (aggregated).

Use this channel to receive private order updates for the given instrument, aggregated according to `interval`.




## AsyncAPI

````yaml specifications/deribit_asyncapi.json user.orders.(instrument_name).(interval)
id: user.orders.(instrument_name).(interval)
title: 'user.orders.(instrument_name).(interval) '
description: >
  User order updates for a specific instrument (aggregated).


  Use this channel to receive private order updates for the given instrument,
  aggregated according to `interval`.
servers:
  - id: production
    protocol: wss
    host: deribit.com/ws/api/v2
    bindings: []
    variables: []
  - id: testnet
    protocol: wss
    host: test.deribit.com/ws/api/v2
    bindings: []
    variables: []
address: user.orders.(instrument_name).(interval)
parameters:
  - id: instrument_name
    jsonSchema:
      type: string
      description: The name of the instrument
    description: The name of the instrument
    type: string
    required: true
    deprecated: false
  - id: interval
    jsonSchema:
      type: string
      description: >-
        Frequency of notifications. Events will be aggregated over this
        interval. The value `raw` means no aggregation will be applied **(Please
        note that `raw` interval is only available to authorized users)**


        **Allowed values:** `raw`, `100ms`, `agg2`
      enum:
        - raw
        - 100ms
        - agg2
    description: >-
      Frequency of notifications. Events will be aggregated over this interval.
      The value `raw` means no aggregation will be applied **(Please note that
      `raw` interval is only available to authorized users)**


      **Allowed values:** `raw`, `100ms`, `agg2`
    type: string
    required: true
    deprecated: false
bindings: []
operations:
  - &ref_2
    id: send_subscribe_user_orders_instrument_name_interval
    title: Send subscribe request for user
    description: Client sends subscription request for user updates
    type: send
    messages:
      - &ref_4
        id: subscription_message
        contentType: application/json
        payload:
          - name: Subscription Notification Data
            description: Server sends subscription notification data
            type: object
            properties:
              - name: data
                type: object
                required: true
                properties:
                  - name: order_id
                    type: string
                    description: Unique order identifier
                    required: false
                  - name: order_state
                    type: string
                    description: >-
                      Order state: `"open"`, `"filled"`, `"rejected"`,
                      `"cancelled"`, `"untriggered"`
                    enumValues:
                      - open
                      - filled
                      - rejected
                      - cancelled
                      - untriggered
                      - triggered
                    required: false
                  - name: order_type
                    type: string
                    description: >-
                      Order type: `"limit"`, `"market"`, `"stop_limit"`,
                      `"stop_market"`, `"take_limit"`, `"take_market"`,
                      `"trailing_stop"`
                    enumValues:
                      - market
                      - limit
                      - stop_market
                      - stop_limit
                      - take_market
                      - take_limit
                      - trailing_stop
                    required: false
                  - name: original_order_type
                    type: string
                    description: Original order type. Optional field
                    enumValues:
                      - market
                      - market_limit
                    required: false
                  - name: time_in_force
                    type: string
                    description: >-
                      Order time in force: `"good_til_cancelled"`,
                      `"good_til_day"`, `"fill_or_kill"` or
                      `"immediate_or_cancel"`
                    enumValues:
                      - good_til_cancelled
                      - good_til_day
                      - fill_or_kill
                      - immediate_or_cancel
                    required: false
                  - name: is_rebalance
                    type: boolean
                    description: >-
                      Optional (only for spot). `true` if order was
                      automatically created during cross-collateral balance
                      restoration
                    required: false
                  - name: is_liquidation
                    type: boolean
                    description: >-
                      Optional (not added for spot). `true` if order was
                      automatically created during liquidation
                    required: false
                  - name: instrument_name
                    type: string
                    description: Unique instrument identifier
                    required: false
                  - name: creation_timestamp
                    type: integer
                    description: The timestamp (milliseconds since the Unix epoch)
                    required: false
                  - name: last_update_timestamp
                    type: integer
                    description: The timestamp (milliseconds since the Unix epoch)
                    required: false
                  - name: direction
                    type: string
                    description: 'Direction: `buy`, or `sell`'
                    enumValues:
                      - buy
                      - sell
                    required: false
                  - name: description
                    type: string
                    description: >-
                      Price in base currency or "market_price" in case of open
                      trigger market orders
                    required: false
                  - name: label
                    type: string
                    description: User defined label (up to 64 characters)
                    required: false
                  - name: post_only
                    type: boolean
                    description: '`true` for post-only orders only'
                    required: false
                  - name: reject_post_only
                    type: boolean
                    description: >-
                      `true` if order has `reject_post_only` flag (field is
                      present only when `post_only` is `true`)
                    required: false
                  - name: reduce_only
                    type: boolean
                    description: >-
                      Optional (not added for spot). '`true` for reduce-only
                      orders only'
                    required: false
                  - name: api
                    type: boolean
                    description: '`true` if created with API'
                    required: false
                  - name: web
                    type: boolean
                    description: '`true` if created via Deribit frontend (optional)'
                    required: false
                  - name: mobile
                    type: boolean
                    description: >-
                      Optional field with value `true` added only when created
                      with Mobile Application
                    required: false
                  - name: refresh_amount
                    type: number
                    description: >-
                      The initial display amount of iceberg order. Iceberg order
                      display amount will be refreshed to that value after match
                      consuming actual display amount. Absent for other types of
                      orders
                    required: false
                  - name: display_amount
                    type: number
                    description: >-
                      The actual display amount of iceberg order. Absent for
                      other types of orders.
                    required: false
                  - name: amount
                    type: number
                    description: >-
                      It represents the requested order size. For perpetual and
                      inverse futures the amount is in USD units. For options
                      and linear futures it is the underlying base currency
                      coin.
                    required: false
                  - name: contracts
                    type: number
                    description: >-
                      It represents the order size in contract units. (Optional,
                      may be absent in historical data).
                    required: false
                  - name: filled_amount
                    type: number
                    description: >-
                      Filled amount of the order. For perpetual and futures the
                      filled_amount is in USD units, for options - in units or
                      corresponding cryptocurrency contracts, e.g., BTC or ETH.
                    required: false
                  - name: average_price
                    type: number
                    description: Average fill price of the order
                    required: false
                  - name: advanced
                    type: string
                    description: >
                      advanced type: `"usd"` or `"implv"` (Only for options;
                      field is omitted if not applicable).
                    enumValues:
                      - usd
                      - implv
                    required: false
                  - name: implv
                    type: number
                    description: >-
                      Implied volatility in percent. (Only if
                      `advanced="implv"`)
                    required: false
                  - name: usd
                    type: number
                    description: Option price in USD (Only if `advanced="usd"`)
                    required: false
                  - name: triggered
                    type: boolean
                    description: Whether the trigger order has been triggered
                    required: false
                  - name: trigger
                    type: string
                    description: >-
                      Trigger type (only for trigger orders). Allowed values:
                      `"index_price"`, `"mark_price"`, `"last_price"`.
                    enumValues:
                      - index_price
                      - mark_price
                      - last_price
                    required: false
                  - name: trigger_price
                    type: number
                    description: Trigger price (Only for future trigger orders)
                    required: false
                  - name: trigger_offset
                    type: number
                    description: >-
                      The maximum deviation from the price peak beyond which the
                      order will be triggered (Only for trailing trigger orders)
                    required: false
                  - name: trigger_reference_price
                    type: number
                    description: >-
                      The price of the given trigger at the time when the order
                      was placed (Only for trailing trigger orders)
                    required: false
                  - name: block_trade
                    type: boolean
                    description: >-
                      `true` if order made from block_trade trade, added only in
                      that case.
                    required: false
                  - name: mmp
                    type: boolean
                    description: '`true` if the order is a MMP order, otherwise `false`.'
                    required: false
                  - name: risk_reducing
                    type: boolean
                    description: >-
                      `true` if the order is marked by the platform as a risk
                      reducing order (can apply only to orders placed by PM
                      users), otherwise `false`.
                    required: false
                  - name: replaced
                    type: boolean
                    description: >-
                      `true` if the order was edited (by user or - in case of
                      advanced options orders - by pricing engine), otherwise
                      `false`.
                    required: false
                  - name: auto_replaced
                    type: boolean
                    description: >-
                      Options, advanced orders only - `true` if last
                      modification of the order was performed by the pricing
                      engine, otherwise `false`.
                    required: false
                  - name: quote
                    type: boolean
                    description: If order is a quote. Present only if true.
                    required: false
                  - name: mmp_group
                    type: string
                    description: >-
                      Name of the MMP group supplied in the `private/mass_quote`
                      request. Only present for quote orders.
                    required: false
                  - name: quote_set_id
                    type: string
                    description: >-
                      Identifier of the QuoteSet supplied in the
                      `private/mass_quote` request. Only present for quote
                      orders.
                    required: false
                  - name: quote_id
                    type: string
                    description: >-
                      The same QuoteID as supplied in the `private/mass_quote`
                      request. Only present for quote orders.
                    required: false
                  - name: trigger_order_id
                    type: string
                    description: >-
                      Id of the trigger order that created the order (Only for
                      orders that were created by triggered orders).
                    required: false
                  - name: app_name
                    type: string
                    description: >-
                      The name of the application that placed the order on
                      behalf of the user (optional).
                    required: false
                  - name: mmp_cancelled
                    type: boolean
                    description: '`true` if order was cancelled by mmp trigger (optional)'
                    required: false
                  - name: cancel_reason
                    type: string
                    description: >-
                      Enumerated reason behind cancel `"user_request"`,
                      `"autoliquidation"`, `"cancel_on_disconnect"`,
                      `"risk_mitigation"`, `"pme_risk_reduction"` (portfolio
                      margining risk reduction), `"pme_account_locked"`
                      (portfolio margining account locked per currency),
                      `"position_locked"`, `"mmp_trigger"` (market maker
                      protection), `"mmp_config_curtailment"` (market maker
                      configured quantity decreased), `"edit_post_only_reject"`
                      (cancelled on edit because of `reject_post_only` setting),
                      `"oco_other_closed"` (the oco order linked to this order
                      was closed), `"oto_primary_closed"` (the oto primary order
                      that was going to trigger this order was cancelled),
                      `"settlement"` (closed because of a settlement)
                    enumValues:
                      - user_request
                      - autoliquidation
                      - cancel_on_disconnect
                      - risk_mitigation
                      - pme_risk_reduction
                      - pme_account_locked
                      - position_locked
                      - mmp_trigger
                      - mmp_config_curtailment
                      - edit_post_only_reject
                      - oco_other_closed
                      - oto_primary_closed
                      - settlement
                    required: false
                  - name: oto_order_ids
                    type: object
                    description: >-
                      The Ids of the orders that will be triggered if the order
                      is filled
                    required: false
                    properties: []
                  - name: trigger_fill_condition
                    type: string
                    description: >-
                      <p>The fill condition of the linked order (Only for linked
                      order types), default: `first_hit`.</p> <ul>
                      <li>`"first_hit"` - any execution of the primary order
                      will fully cancel/place all secondary orders.</li>
                      <li>`"complete_fill"` - a complete execution (meaning the
                      primary order no longer exists) will cancel/place the
                      secondary orders.</li> <li>`"incremental"` - any fill of
                      the primary order will cause proportional partial
                      cancellation/placement of the secondary order. The amount
                      that will be subtracted/added to the secondary order will
                      be rounded down to the contract size.</li> </ul>
                    enumValues:
                      - first_hit
                      - complete_fill
                      - incremental
                    required: false
                  - name: oco_ref
                    type: string
                    description: >-
                      Unique reference that identifies a one_cancels_others
                      (OCO) pair.
                    required: false
                  - name: primary_order_id
                    type: string
                    description: Unique order identifier
                    required: false
                  - name: is_secondary_oto
                    type: boolean
                    description: >-
                      `true` if the order is an order that can be triggered by
                      another order, otherwise not present.
                    required: false
                  - name: is_primary_otoco
                    type: boolean
                    description: >-
                      `true` if the order is an order that can trigger an OCO
                      pair, otherwise not present.
                    required: false
        headers: []
        jsonPayloadSchema:
          type: object
          description: Response containing notification data
          properties:
            data:
              type: object
              description: ''
              properties:
                order_id:
                  description: Unique order identifier
                  type: string
                  example: ETH-100234
                  x-parser-schema-id: <anonymous-schema-624>
                order_state:
                  type: string
                  description: >-
                    Order state: `"open"`, `"filled"`, `"rejected"`,
                    `"cancelled"`, `"untriggered"`
                  enum:
                    - open
                    - filled
                    - rejected
                    - cancelled
                    - untriggered
                    - triggered
                  x-parser-schema-id: <anonymous-schema-625>
                order_type:
                  type: string
                  description: >-
                    Order type: `"limit"`, `"market"`, `"stop_limit"`,
                    `"stop_market"`, `"take_limit"`, `"take_market"`,
                    `"trailing_stop"`
                  enum:
                    - market
                    - limit
                    - stop_market
                    - stop_limit
                    - take_market
                    - take_limit
                    - trailing_stop
                  x-parser-schema-id: <anonymous-schema-626>
                original_order_type:
                  type: string
                  description: Original order type. Optional field
                  enum:
                    - market
                    - market_limit
                  x-parser-schema-id: <anonymous-schema-627>
                time_in_force:
                  type: string
                  description: >-
                    Order time in force: `"good_til_cancelled"`,
                    `"good_til_day"`, `"fill_or_kill"` or
                    `"immediate_or_cancel"`
                  enum:
                    - good_til_cancelled
                    - good_til_day
                    - fill_or_kill
                    - immediate_or_cancel
                  x-parser-schema-id: <anonymous-schema-628>
                is_rebalance:
                  type: boolean
                  description: >-
                    Optional (only for spot). `true` if order was automatically
                    created during cross-collateral balance restoration
                  x-parser-schema-id: <anonymous-schema-629>
                is_liquidation:
                  type: boolean
                  description: >-
                    Optional (not added for spot). `true` if order was
                    automatically created during liquidation
                  x-parser-schema-id: <anonymous-schema-630>
                instrument_name:
                  type: string
                  description: Unique instrument identifier
                  example: BTC-PERPETUAL
                  x-parser-schema-id: <anonymous-schema-631>
                creation_timestamp:
                  type: integer
                  example: 1536569522277
                  description: The timestamp (milliseconds since the Unix epoch)
                  x-parser-schema-id: <anonymous-schema-632>
                last_update_timestamp:
                  type: integer
                  example: 1536569522277
                  description: The timestamp (milliseconds since the Unix epoch)
                  x-parser-schema-id: <anonymous-schema-633>
                direction:
                  type: string
                  description: 'Direction: `buy`, or `sell`'
                  enum:
                    - buy
                    - sell
                  x-parser-schema-id: <anonymous-schema-634>
                price:
                  description: >-
                    Price in base currency or "market_price" in case of open
                    trigger market orders
                  x-parser-schema-id: <anonymous-schema-635>
                label:
                  type: string
                  description: User defined label (up to 64 characters)
                  x-parser-schema-id: <anonymous-schema-636>
                post_only:
                  type: boolean
                  description: '`true` for post-only orders only'
                  x-parser-schema-id: <anonymous-schema-637>
                reject_post_only:
                  description: >-
                    `true` if order has `reject_post_only` flag (field is
                    present only when `post_only` is `true`)
                  type: boolean
                  x-parser-schema-id: <anonymous-schema-638>
                reduce_only:
                  type: boolean
                  description: >-
                    Optional (not added for spot). '`true` for reduce-only
                    orders only'
                  x-parser-schema-id: <anonymous-schema-639>
                api:
                  type: boolean
                  description: '`true` if created with API'
                  x-parser-schema-id: <anonymous-schema-640>
                web:
                  type: boolean
                  description: '`true` if created via Deribit frontend (optional)'
                  x-parser-schema-id: <anonymous-schema-641>
                mobile:
                  type: boolean
                  description: >-
                    Optional field with value `true` added only when created
                    with Mobile Application
                  x-parser-schema-id: <anonymous-schema-642>
                refresh_amount:
                  type: number
                  description: >-
                    The initial display amount of iceberg order. Iceberg order
                    display amount will be refreshed to that value after match
                    consuming actual display amount. Absent for other types of
                    orders
                  x-parser-schema-id: <anonymous-schema-643>
                display_amount:
                  type: number
                  description: >-
                    The actual display amount of iceberg order. Absent for other
                    types of orders.
                  x-parser-schema-id: <anonymous-schema-644>
                amount:
                  type: number
                  description: >-
                    It represents the requested order size. For perpetual and
                    inverse futures the amount is in USD units. For options and
                    linear futures it is the underlying base currency coin.
                  x-parser-schema-id: <anonymous-schema-645>
                contracts:
                  type: number
                  description: >-
                    It represents the order size in contract units. (Optional,
                    may be absent in historical data).
                  x-parser-schema-id: <anonymous-schema-646>
                filled_amount:
                  type: number
                  description: >-
                    Filled amount of the order. For perpetual and futures the
                    filled_amount is in USD units, for options - in units or
                    corresponding cryptocurrency contracts, e.g., BTC or ETH.
                  x-parser-schema-id: <anonymous-schema-647>
                average_price:
                  type: number
                  description: Average fill price of the order
                  x-parser-schema-id: <anonymous-schema-648>
                advanced:
                  type: string
                  description: >
                    advanced type: `"usd"` or `"implv"` (Only for options; field
                    is omitted if not applicable).
                  enum:
                    - usd
                    - implv
                  x-parser-schema-id: <anonymous-schema-649>
                implv:
                  type: number
                  description: Implied volatility in percent. (Only if `advanced="implv"`)
                  x-parser-schema-id: <anonymous-schema-650>
                usd:
                  type: number
                  description: Option price in USD (Only if `advanced="usd"`)
                  x-parser-schema-id: <anonymous-schema-651>
                triggered:
                  type: boolean
                  description: Whether the trigger order has been triggered
                  x-parser-schema-id: <anonymous-schema-652>
                trigger:
                  type: string
                  description: >-
                    Trigger type (only for trigger orders). Allowed values:
                    `"index_price"`, `"mark_price"`, `"last_price"`.
                  enum:
                    - index_price
                    - mark_price
                    - last_price
                  x-parser-schema-id: <anonymous-schema-653>
                trigger_price:
                  type: number
                  description: Trigger price (Only for future trigger orders)
                  x-parser-schema-id: <anonymous-schema-654>
                trigger_offset:
                  type: number
                  description: >-
                    The maximum deviation from the price peak beyond which the
                    order will be triggered (Only for trailing trigger orders)
                  x-parser-schema-id: <anonymous-schema-655>
                trigger_reference_price:
                  type: number
                  description: >-
                    The price of the given trigger at the time when the order
                    was placed (Only for trailing trigger orders)
                  x-parser-schema-id: <anonymous-schema-656>
                block_trade:
                  description: >-
                    `true` if order made from block_trade trade, added only in
                    that case.
                  type: boolean
                  example: true
                  x-parser-schema-id: <anonymous-schema-657>
                mmp:
                  type: boolean
                  description: '`true` if the order is a MMP order, otherwise `false`.'
                  x-parser-schema-id: <anonymous-schema-658>
                risk_reducing:
                  type: boolean
                  description: >-
                    `true` if the order is marked by the platform as a risk
                    reducing order (can apply only to orders placed by PM
                    users), otherwise `false`.
                  x-parser-schema-id: <anonymous-schema-659>
                replaced:
                  type: boolean
                  description: >-
                    `true` if the order was edited (by user or - in case of
                    advanced options orders - by pricing engine), otherwise
                    `false`.
                  x-parser-schema-id: <anonymous-schema-660>
                auto_replaced:
                  type: boolean
                  description: >-
                    Options, advanced orders only - `true` if last modification
                    of the order was performed by the pricing engine, otherwise
                    `false`.
                  x-parser-schema-id: <anonymous-schema-661>
                quote:
                  type: boolean
                  description: If order is a quote. Present only if true.
                  x-parser-schema-id: <anonymous-schema-662>
                mmp_group:
                  type: string
                  description: >-
                    Name of the MMP group supplied in the `private/mass_quote`
                    request. Only present for quote orders.
                  x-parser-schema-id: <anonymous-schema-663>
                quote_set_id:
                  type: string
                  description: >-
                    Identifier of the QuoteSet supplied in the
                    `private/mass_quote` request. Only present for quote orders.
                  x-parser-schema-id: <anonymous-schema-664>
                quote_id:
                  type: string
                  description: >-
                    The same QuoteID as supplied in the `private/mass_quote`
                    request. Only present for quote orders.
                  x-parser-schema-id: <anonymous-schema-665>
                trigger_order_id:
                  type: string
                  description: >-
                    Id of the trigger order that created the order (Only for
                    orders that were created by triggered orders).
                  example: SLIB-370
                  x-parser-schema-id: <anonymous-schema-666>
                app_name:
                  type: string
                  description: >-
                    The name of the application that placed the order on behalf
                    of the user (optional).
                  example: Example Application
                  x-parser-schema-id: <anonymous-schema-667>
                mmp_cancelled:
                  type: boolean
                  description: '`true` if order was cancelled by mmp trigger (optional)'
                  example: true
                  x-parser-schema-id: <anonymous-schema-668>
                cancel_reason:
                  type: string
                  description: >-
                    Enumerated reason behind cancel `"user_request"`,
                    `"autoliquidation"`, `"cancel_on_disconnect"`,
                    `"risk_mitigation"`, `"pme_risk_reduction"` (portfolio
                    margining risk reduction), `"pme_account_locked"` (portfolio
                    margining account locked per currency), `"position_locked"`,
                    `"mmp_trigger"` (market maker protection),
                    `"mmp_config_curtailment"` (market maker configured quantity
                    decreased), `"edit_post_only_reject"` (cancelled on edit
                    because of `reject_post_only` setting), `"oco_other_closed"`
                    (the oco order linked to this order was closed),
                    `"oto_primary_closed"` (the oto primary order that was going
                    to trigger this order was cancelled), `"settlement"` (closed
                    because of a settlement)
                  enum:
                    - user_request
                    - autoliquidation
                    - cancel_on_disconnect
                    - risk_mitigation
                    - pme_risk_reduction
                    - pme_account_locked
                    - position_locked
                    - mmp_trigger
                    - mmp_config_curtailment
                    - edit_post_only_reject
                    - oco_other_closed
                    - oto_primary_closed
                    - settlement
                  x-parser-schema-id: <anonymous-schema-669>
                oto_order_ids:
                  type: object
                  description: >-
                    The Ids of the orders that will be triggered if the order is
                    filled
                  properties: {}
                  additionalProperties: true
                  x-parser-schema-id: <anonymous-schema-670>
                trigger_fill_condition:
                  description: >-
                    <p>The fill condition of the linked order (Only for linked
                    order types), default: `first_hit`.</p> <ul>
                    <li>`"first_hit"` - any execution of the primary order will
                    fully cancel/place all secondary orders.</li>
                    <li>`"complete_fill"` - a complete execution (meaning the
                    primary order no longer exists) will cancel/place the
                    secondary orders.</li> <li>`"incremental"` - any fill of the
                    primary order will cause proportional partial
                    cancellation/placement of the secondary order. The amount
                    that will be subtracted/added to the secondary order will be
                    rounded down to the contract size.</li> </ul>
                  type: string
                  enum:
                    - first_hit
                    - complete_fill
                    - incremental
                  x-parser-schema-id: <anonymous-schema-671>
                oco_ref:
                  type: string
                  description: >-
                    Unique reference that identifies a one_cancels_others (OCO)
                    pair.
                  x-parser-schema-id: <anonymous-schema-672>
                primary_order_id:
                  description: Unique order identifier
                  type: string
                  example: ETH-100234
                  x-parser-schema-id: <anonymous-schema-673>
                is_secondary_oto:
                  type: boolean
                  description: >-
                    `true` if the order is an order that can be triggered by
                    another order, otherwise not present.
                  x-parser-schema-id: <anonymous-schema-674>
                is_primary_otoco:
                  type: boolean
                  description: >-
                    `true` if the order is an order that can trigger an OCO
                    pair, otherwise not present.
                  x-parser-schema-id: <anonymous-schema-675>
              required:
                - order_id
                - order_state
                - order_type
                - time_in_force
                - instrument_name
                - creation_timestamp
                - last_update_timestamp
                - direction
                - price
                - label
                - post_only
                - api
              additionalProperties: false
              x-parser-schema-id: <anonymous-schema-623>
          required:
            - data
          additionalProperties: false
          x-parser-schema-id: <anonymous-schema-622>
        title: Subscription Notification Data
        description: Server sends subscription notification data
        example: |-
          {
            "data": [
              {
                "time_in_force": "good_til_cancelled",
                "replaced": false,
                "reduce_only": false,
                "price": 10460.43,
                "post_only": false,
                "original_order_type": "market",
                "order_type": "limit",
                "order_state": "open",
                "order_id": "4",
                "max_show": 200,
                "last_update_timestamp": 1581507159533,
                "label": "",
                "is_rebalance": false,
                "is_liquidation": false,
                "instrument_name": "BTC-PERPETUAL",
                "filled_amount": 0,
                "direction": "buy",
                "creation_timestamp": 1581507159533,
                "average_price": 0,
                "api": false,
                "amount": 200
              }
            ]
          }
        bindings: []
        extensions:
          - id: x-parser-unique-object-id
            value: subscription_message
    bindings: []
    extensions: &ref_0
      - id: x-parser-unique-object-id
        value: user.orders.(instrument_name).(interval)
  - &ref_1
    id: receive_user_orders_instrument_name_interval_updates
    title: Receive user updates
    description: Client receives user update notifications
    type: receive
    messages:
      - &ref_3
        id: subscribe_request
        contentType: application/json
        payload:
          - name: Subscription Request
            description: >-
              Client sends subscription request to subscribe to notification
              channel. Please refer to [Notification
              page](https://deribit.mintlify.app/articles/notifications) for
              more information.
            type: object
            properties: []
        headers: []
        jsonPayloadSchema:
          properties: {}
          additionalProperties: false
          x-parser-schema-id: <anonymous-schema-621>
        title: Subscription Request
        description: >-
          Client sends subscription request to subscribe to notification
          channel. Please refer to [Notification
          page](https://deribit.mintlify.app/articles/notifications) for more
          information.
        example: |-
          {
            "jsonrpc": "2.0",
            "method": "public/subscribe",
            "id": 42,
            "params": {
              "channels": [
                "user.orders.BTC-PERPETUAL.100ms"
              ]
            }
          }
        bindings: []
        extensions:
          - id: x-parser-unique-object-id
            value: subscribe_request
    bindings: []
    extensions: *ref_0
sendOperations:
  - *ref_1
receiveOperations:
  - *ref_2
sendMessages:
  - *ref_3
receiveMessages:
  - *ref_4
extensions:
  - id: x-parser-unique-object-id
    value: user.orders.(instrument_name).(interval)
securitySchemes: []

````


> ## Documentation Index
> Fetch the complete documentation index at: https://docs.deribit.com/llms.txt
> Use this file to discover all available pages before exploring further.

<AgentInstructions>

## Submitting Feedback

If you encounter incorrect, outdated, or confusing documentation on this page, submit feedback:

POST https://docs.deribit.com/feedback

```json
{
  "path": "/subscriptions/user/userorderskindcurrencyraw",
  "feedback": "Description of the issue"
}
```

Only submit feedback when you have something specific and actionable to report.

</AgentInstructions>

# user.orders.(kind).(currency).raw 

> User order updates across all instruments for a given kind and currency (raw stream).

Use this channel to receive private order updates across all matching instruments with the highest granularity (raw).




## AsyncAPI

````yaml specifications/deribit_asyncapi.json user.orders.(kind).(currency).raw
id: user.orders.(kind).(currency).raw
title: 'user.orders.(kind).(currency).raw '
description: >
  User order updates across all instruments for a given kind and currency (raw
  stream).


  Use this channel to receive private order updates across all matching
  instruments with the highest granularity (raw).
servers:
  - id: production
    protocol: wss
    host: deribit.com/ws/api/v2
    bindings: []
    variables: []
  - id: testnet
    protocol: wss
    host: test.deribit.com/ws/api/v2
    bindings: []
    variables: []
address: user.orders.(kind).(currency).raw
parameters:
  - id: kind
    jsonSchema:
      type: string
      description: >-
        Instrument kind


        **Allowed values:** `future`, `option`, `spot`, `future_combo`,
        `option_combo`
      enum:
        - future
        - option
        - spot
        - future_combo
        - option_combo
    description: >-
      Instrument kind


      **Allowed values:** `future`, `option`, `spot`, `future_combo`,
      `option_combo`
    type: string
    required: true
    deprecated: false
  - id: currency
    jsonSchema:
      type: string
      description: |-
        Currency code or `any` for all

        **Allowed values:** `BTC`, `ETH`, `USDC`, `USDT`, `EURR`, `any`
      enum:
        - BTC
        - ETH
        - USDC
        - USDT
        - EURR
        - any
    description: |-
      Currency code or `any` for all

      **Allowed values:** `BTC`, `ETH`, `USDC`, `USDT`, `EURR`, `any`
    type: string
    required: true
    deprecated: false
bindings: []
operations:
  - &ref_2
    id: send_subscribe_user_orders_kind_currency_raw
    title: Send subscribe request for user
    description: Client sends subscription request for user updates
    type: send
    messages:
      - &ref_4
        id: subscription_message
        contentType: application/json
        payload:
          - name: Subscription Notification Data
            description: Server sends subscription notification data
            type: object
            properties:
              - name: data
                type: object
                required: true
                properties:
                  - name: order_id
                    type: string
                    description: Unique order identifier
                    required: false
                  - name: order_state
                    type: string
                    description: >-
                      Order state: `"open"`, `"filled"`, `"rejected"`,
                      `"cancelled"`, `"untriggered"`
                    enumValues:
                      - open
                      - filled
                      - rejected
                      - cancelled
                      - untriggered
                      - triggered
                    required: false
                  - name: order_type
                    type: string
                    description: >-
                      Order type: `"limit"`, `"market"`, `"stop_limit"`,
                      `"stop_market"`, `"take_limit"`, `"take_market"`,
                      `"trailing_stop"`
                    enumValues:
                      - market
                      - limit
                      - stop_market
                      - stop_limit
                      - take_market
                      - take_limit
                      - trailing_stop
                    required: false
                  - name: original_order_type
                    type: string
                    description: Original order type. Optional field
                    enumValues:
                      - market
                      - market_limit
                    required: false
                  - name: time_in_force
                    type: string
                    description: >-
                      Order time in force: `"good_til_cancelled"`,
                      `"good_til_day"`, `"fill_or_kill"` or
                      `"immediate_or_cancel"`
                    enumValues:
                      - good_til_cancelled
                      - good_til_day
                      - fill_or_kill
                      - immediate_or_cancel
                    required: false
                  - name: is_rebalance
                    type: boolean
                    description: >-
                      Optional (only for spot). `true` if order was
                      automatically created during cross-collateral balance
                      restoration
                    required: false
                  - name: is_liquidation
                    type: boolean
                    description: >-
                      Optional (not added for spot). `true` if order was
                      automatically created during liquidation
                    required: false
                  - name: instrument_name
                    type: string
                    description: Unique instrument identifier
                    required: false
                  - name: creation_timestamp
                    type: integer
                    description: The timestamp (milliseconds since the Unix epoch)
                    required: false
                  - name: last_update_timestamp
                    type: integer
                    description: The timestamp (milliseconds since the Unix epoch)
                    required: false
                  - name: direction
                    type: string
                    description: 'Direction: `buy`, or `sell`'
                    enumValues:
                      - buy
                      - sell
                    required: false
                  - name: description
                    type: string
                    description: >-
                      Price in base currency or "market_price" in case of open
                      trigger market orders
                    required: false
                  - name: label
                    type: string
                    description: User defined label (up to 64 characters)
                    required: false
                  - name: post_only
                    type: boolean
                    description: '`true` for post-only orders only'
                    required: false
                  - name: reject_post_only
                    type: boolean
                    description: >-
                      `true` if order has `reject_post_only` flag (field is
                      present only when `post_only` is `true`)
                    required: false
                  - name: reduce_only
                    type: boolean
                    description: >-
                      Optional (not added for spot). '`true` for reduce-only
                      orders only'
                    required: false
                  - name: api
                    type: boolean
                    description: '`true` if created with API'
                    required: false
                  - name: web
                    type: boolean
                    description: '`true` if created via Deribit frontend (optional)'
                    required: false
                  - name: mobile
                    type: boolean
                    description: >-
                      Optional field with value `true` added only when created
                      with Mobile Application
                    required: false
                  - name: refresh_amount
                    type: number
                    description: >-
                      The initial display amount of iceberg order. Iceberg order
                      display amount will be refreshed to that value after match
                      consuming actual display amount. Absent for other types of
                      orders
                    required: false
                  - name: display_amount
                    type: number
                    description: >-
                      The actual display amount of iceberg order. Absent for
                      other types of orders.
                    required: false
                  - name: amount
                    type: number
                    description: >-
                      It represents the requested order size. For perpetual and
                      inverse futures the amount is in USD units. For options
                      and linear futures it is the underlying base currency
                      coin.
                    required: false
                  - name: contracts
                    type: number
                    description: >-
                      It represents the order size in contract units. (Optional,
                      may be absent in historical data).
                    required: false
                  - name: filled_amount
                    type: number
                    description: >-
                      Filled amount of the order. For perpetual and futures the
                      filled_amount is in USD units, for options - in units or
                      corresponding cryptocurrency contracts, e.g., BTC or ETH.
                    required: false
                  - name: average_price
                    type: number
                    description: Average fill price of the order
                    required: false
                  - name: advanced
                    type: string
                    description: >
                      advanced type: `"usd"` or `"implv"` (Only for options;
                      field is omitted if not applicable).
                    enumValues:
                      - usd
                      - implv
                    required: false
                  - name: implv
                    type: number
                    description: >-
                      Implied volatility in percent. (Only if
                      `advanced="implv"`)
                    required: false
                  - name: usd
                    type: number
                    description: Option price in USD (Only if `advanced="usd"`)
                    required: false
                  - name: triggered
                    type: boolean
                    description: Whether the trigger order has been triggered
                    required: false
                  - name: trigger
                    type: string
                    description: >-
                      Trigger type (only for trigger orders). Allowed values:
                      `"index_price"`, `"mark_price"`, `"last_price"`.
                    enumValues:
                      - index_price
                      - mark_price
                      - last_price
                    required: false
                  - name: trigger_price
                    type: number
                    description: Trigger price (Only for future trigger orders)
                    required: false
                  - name: trigger_offset
                    type: number
                    description: >-
                      The maximum deviation from the price peak beyond which the
                      order will be triggered (Only for trailing trigger orders)
                    required: false
                  - name: trigger_reference_price
                    type: number
                    description: >-
                      The price of the given trigger at the time when the order
                      was placed (Only for trailing trigger orders)
                    required: false
                  - name: block_trade
                    type: boolean
                    description: >-
                      `true` if order made from block_trade trade, added only in
                      that case.
                    required: false
                  - name: mmp
                    type: boolean
                    description: '`true` if the order is a MMP order, otherwise `false`.'
                    required: false
                  - name: risk_reducing
                    type: boolean
                    description: >-
                      `true` if the order is marked by the platform as a risk
                      reducing order (can apply only to orders placed by PM
                      users), otherwise `false`.
                    required: false
                  - name: replaced
                    type: boolean
                    description: >-
                      `true` if the order was edited (by user or - in case of
                      advanced options orders - by pricing engine), otherwise
                      `false`.
                    required: false
                  - name: auto_replaced
                    type: boolean
                    description: >-
                      Options, advanced orders only - `true` if last
                      modification of the order was performed by the pricing
                      engine, otherwise `false`.
                    required: false
                  - name: quote
                    type: boolean
                    description: If order is a quote. Present only if true.
                    required: false
                  - name: mmp_group
                    type: string
                    description: >-
                      Name of the MMP group supplied in the `private/mass_quote`
                      request. Only present for quote orders.
                    required: false
                  - name: quote_set_id
                    type: string
                    description: >-
                      Identifier of the QuoteSet supplied in the
                      `private/mass_quote` request. Only present for quote
                      orders.
                    required: false
                  - name: quote_id
                    type: string
                    description: >-
                      The same QuoteID as supplied in the `private/mass_quote`
                      request. Only present for quote orders.
                    required: false
                  - name: trigger_order_id
                    type: string
                    description: >-
                      Id of the trigger order that created the order (Only for
                      orders that were created by triggered orders).
                    required: false
                  - name: app_name
                    type: string
                    description: >-
                      The name of the application that placed the order on
                      behalf of the user (optional).
                    required: false
                  - name: mmp_cancelled
                    type: boolean
                    description: '`true` if order was cancelled by mmp trigger (optional)'
                    required: false
                  - name: cancel_reason
                    type: string
                    description: >-
                      Enumerated reason behind cancel `"user_request"`,
                      `"autoliquidation"`, `"cancel_on_disconnect"`,
                      `"risk_mitigation"`, `"pme_risk_reduction"` (portfolio
                      margining risk reduction), `"pme_account_locked"`
                      (portfolio margining account locked per currency),
                      `"position_locked"`, `"mmp_trigger"` (market maker
                      protection), `"mmp_config_curtailment"` (market maker
                      configured quantity decreased), `"edit_post_only_reject"`
                      (cancelled on edit because of `reject_post_only` setting),
                      `"oco_other_closed"` (the oco order linked to this order
                      was closed), `"oto_primary_closed"` (the oto primary order
                      that was going to trigger this order was cancelled),
                      `"settlement"` (closed because of a settlement)
                    enumValues:
                      - user_request
                      - autoliquidation
                      - cancel_on_disconnect
                      - risk_mitigation
                      - pme_risk_reduction
                      - pme_account_locked
                      - position_locked
                      - mmp_trigger
                      - mmp_config_curtailment
                      - edit_post_only_reject
                      - oco_other_closed
                      - oto_primary_closed
                      - settlement
                    required: false
                  - name: oto_order_ids
                    type: object
                    description: >-
                      The Ids of the orders that will be triggered if the order
                      is filled
                    required: false
                    properties: []
                  - name: trigger_fill_condition
                    type: string
                    description: >-
                      <p>The fill condition of the linked order (Only for linked
                      order types), default: `first_hit`.</p> <ul>
                      <li>`"first_hit"` - any execution of the primary order
                      will fully cancel/place all secondary orders.</li>
                      <li>`"complete_fill"` - a complete execution (meaning the
                      primary order no longer exists) will cancel/place the
                      secondary orders.</li> <li>`"incremental"` - any fill of
                      the primary order will cause proportional partial
                      cancellation/placement of the secondary order. The amount
                      that will be subtracted/added to the secondary order will
                      be rounded down to the contract size.</li> </ul>
                    enumValues:
                      - first_hit
                      - complete_fill
                      - incremental
                    required: false
                  - name: oco_ref
                    type: string
                    description: >-
                      Unique reference that identifies a one_cancels_others
                      (OCO) pair.
                    required: false
                  - name: primary_order_id
                    type: string
                    description: Unique order identifier
                    required: false
                  - name: is_secondary_oto
                    type: boolean
                    description: >-
                      `true` if the order is an order that can be triggered by
                      another order, otherwise not present.
                    required: false
                  - name: is_primary_otoco
                    type: boolean
                    description: >-
                      `true` if the order is an order that can trigger an OCO
                      pair, otherwise not present.
                    required: false
        headers: []
        jsonPayloadSchema:
          type: object
          description: Response containing notification data
          properties:
            data:
              type: object
              properties:
                order_id:
                  description: Unique order identifier
                  type: string
                  example: ETH-100234
                  x-parser-schema-id: <anonymous-schema-681>
                order_state:
                  type: string
                  description: >-
                    Order state: `"open"`, `"filled"`, `"rejected"`,
                    `"cancelled"`, `"untriggered"`
                  enum:
                    - open
                    - filled
                    - rejected
                    - cancelled
                    - untriggered
                    - triggered
                  x-parser-schema-id: <anonymous-schema-682>
                order_type:
                  type: string
                  description: >-
                    Order type: `"limit"`, `"market"`, `"stop_limit"`,
                    `"stop_market"`, `"take_limit"`, `"take_market"`,
                    `"trailing_stop"`
                  enum:
                    - market
                    - limit
                    - stop_market
                    - stop_limit
                    - take_market
                    - take_limit
                    - trailing_stop
                  x-parser-schema-id: <anonymous-schema-683>
                original_order_type:
                  type: string
                  description: Original order type. Optional field
                  enum:
                    - market
                    - market_limit
                  x-parser-schema-id: <anonymous-schema-684>
                time_in_force:
                  type: string
                  description: >-
                    Order time in force: `"good_til_cancelled"`,
                    `"good_til_day"`, `"fill_or_kill"` or
                    `"immediate_or_cancel"`
                  enum:
                    - good_til_cancelled
                    - good_til_day
                    - fill_or_kill
                    - immediate_or_cancel
                  x-parser-schema-id: <anonymous-schema-685>
                is_rebalance:
                  type: boolean
                  description: >-
                    Optional (only for spot). `true` if order was automatically
                    created during cross-collateral balance restoration
                  x-parser-schema-id: <anonymous-schema-686>
                is_liquidation:
                  type: boolean
                  description: >-
                    Optional (not added for spot). `true` if order was
                    automatically created during liquidation
                  x-parser-schema-id: <anonymous-schema-687>
                instrument_name:
                  type: string
                  description: Unique instrument identifier
                  example: BTC-PERPETUAL
                  x-parser-schema-id: <anonymous-schema-688>
                creation_timestamp:
                  type: integer
                  example: 1536569522277
                  description: The timestamp (milliseconds since the Unix epoch)
                  x-parser-schema-id: <anonymous-schema-689>
                last_update_timestamp:
                  type: integer
                  example: 1536569522277
                  description: The timestamp (milliseconds since the Unix epoch)
                  x-parser-schema-id: <anonymous-schema-690>
                direction:
                  type: string
                  description: 'Direction: `buy`, or `sell`'
                  enum:
                    - buy
                    - sell
                  x-parser-schema-id: <anonymous-schema-691>
                price:
                  description: >-
                    Price in base currency or "market_price" in case of open
                    trigger market orders
                  x-parser-schema-id: <anonymous-schema-692>
                label:
                  type: string
                  description: User defined label (up to 64 characters)
                  x-parser-schema-id: <anonymous-schema-693>
                post_only:
                  type: boolean
                  description: '`true` for post-only orders only'
                  x-parser-schema-id: <anonymous-schema-694>
                reject_post_only:
                  description: >-
                    `true` if order has `reject_post_only` flag (field is
                    present only when `post_only` is `true`)
                  type: boolean
                  x-parser-schema-id: <anonymous-schema-695>
                reduce_only:
                  type: boolean
                  description: >-
                    Optional (not added for spot). '`true` for reduce-only
                    orders only'
                  x-parser-schema-id: <anonymous-schema-696>
                api:
                  type: boolean
                  description: '`true` if created with API'
                  x-parser-schema-id: <anonymous-schema-697>
                web:
                  type: boolean
                  description: '`true` if created via Deribit frontend (optional)'
                  x-parser-schema-id: <anonymous-schema-698>
                mobile:
                  type: boolean
                  description: >-
                    Optional field with value `true` added only when created
                    with Mobile Application
                  x-parser-schema-id: <anonymous-schema-699>
                refresh_amount:
                  type: number
                  description: >-
                    The initial display amount of iceberg order. Iceberg order
                    display amount will be refreshed to that value after match
                    consuming actual display amount. Absent for other types of
                    orders
                  x-parser-schema-id: <anonymous-schema-700>
                display_amount:
                  type: number
                  description: >-
                    The actual display amount of iceberg order. Absent for other
                    types of orders.
                  x-parser-schema-id: <anonymous-schema-701>
                amount:
                  type: number
                  description: >-
                    It represents the requested order size. For perpetual and
                    inverse futures the amount is in USD units. For options and
                    linear futures it is the underlying base currency coin.
                  x-parser-schema-id: <anonymous-schema-702>
                contracts:
                  type: number
                  description: >-
                    It represents the order size in contract units. (Optional,
                    may be absent in historical data).
                  x-parser-schema-id: <anonymous-schema-703>
                filled_amount:
                  type: number
                  description: >-
                    Filled amount of the order. For perpetual and futures the
                    filled_amount is in USD units, for options - in units or
                    corresponding cryptocurrency contracts, e.g., BTC or ETH.
                  x-parser-schema-id: <anonymous-schema-704>
                average_price:
                  type: number
                  description: Average fill price of the order
                  x-parser-schema-id: <anonymous-schema-705>
                advanced:
                  type: string
                  description: >
                    advanced type: `"usd"` or `"implv"` (Only for options; field
                    is omitted if not applicable).
                  enum:
                    - usd
                    - implv
                  x-parser-schema-id: <anonymous-schema-706>
                implv:
                  type: number
                  description: Implied volatility in percent. (Only if `advanced="implv"`)
                  x-parser-schema-id: <anonymous-schema-707>
                usd:
                  type: number
                  description: Option price in USD (Only if `advanced="usd"`)
                  x-parser-schema-id: <anonymous-schema-708>
                triggered:
                  type: boolean
                  description: Whether the trigger order has been triggered
                  x-parser-schema-id: <anonymous-schema-709>
                trigger:
                  type: string
                  description: >-
                    Trigger type (only for trigger orders). Allowed values:
                    `"index_price"`, `"mark_price"`, `"last_price"`.
                  enum:
                    - index_price
                    - mark_price
                    - last_price
                  x-parser-schema-id: <anonymous-schema-710>
                trigger_price:
                  type: number
                  description: Trigger price (Only for future trigger orders)
                  x-parser-schema-id: <anonymous-schema-711>
                trigger_offset:
                  type: number
                  description: >-
                    The maximum deviation from the price peak beyond which the
                    order will be triggered (Only for trailing trigger orders)
                  x-parser-schema-id: <anonymous-schema-712>
                trigger_reference_price:
                  type: number
                  description: >-
                    The price of the given trigger at the time when the order
                    was placed (Only for trailing trigger orders)
                  x-parser-schema-id: <anonymous-schema-713>
                block_trade:
                  description: >-
                    `true` if order made from block_trade trade, added only in
                    that case.
                  type: boolean
                  example: true
                  x-parser-schema-id: <anonymous-schema-714>
                mmp:
                  type: boolean
                  description: '`true` if the order is a MMP order, otherwise `false`.'
                  x-parser-schema-id: <anonymous-schema-715>
                risk_reducing:
                  type: boolean
                  description: >-
                    `true` if the order is marked by the platform as a risk
                    reducing order (can apply only to orders placed by PM
                    users), otherwise `false`.
                  x-parser-schema-id: <anonymous-schema-716>
                replaced:
                  type: boolean
                  description: >-
                    `true` if the order was edited (by user or - in case of
                    advanced options orders - by pricing engine), otherwise
                    `false`.
                  x-parser-schema-id: <anonymous-schema-717>
                auto_replaced:
                  type: boolean
                  description: >-
                    Options, advanced orders only - `true` if last modification
                    of the order was performed by the pricing engine, otherwise
                    `false`.
                  x-parser-schema-id: <anonymous-schema-718>
                quote:
                  type: boolean
                  description: If order is a quote. Present only if true.
                  x-parser-schema-id: <anonymous-schema-719>
                mmp_group:
                  type: string
                  description: >-
                    Name of the MMP group supplied in the `private/mass_quote`
                    request. Only present for quote orders.
                  x-parser-schema-id: <anonymous-schema-720>
                quote_set_id:
                  type: string
                  description: >-
                    Identifier of the QuoteSet supplied in the
                    `private/mass_quote` request. Only present for quote orders.
                  x-parser-schema-id: <anonymous-schema-721>
                quote_id:
                  type: string
                  description: >-
                    The same QuoteID as supplied in the `private/mass_quote`
                    request. Only present for quote orders.
                  x-parser-schema-id: <anonymous-schema-722>
                trigger_order_id:
                  type: string
                  description: >-
                    Id of the trigger order that created the order (Only for
                    orders that were created by triggered orders).
                  example: SLIB-370
                  x-parser-schema-id: <anonymous-schema-723>
                app_name:
                  type: string
                  description: >-
                    The name of the application that placed the order on behalf
                    of the user (optional).
                  example: Example Application
                  x-parser-schema-id: <anonymous-schema-724>
                mmp_cancelled:
                  type: boolean
                  description: '`true` if order was cancelled by mmp trigger (optional)'
                  example: true
                  x-parser-schema-id: <anonymous-schema-725>
                cancel_reason:
                  type: string
                  description: >-
                    Enumerated reason behind cancel `"user_request"`,
                    `"autoliquidation"`, `"cancel_on_disconnect"`,
                    `"risk_mitigation"`, `"pme_risk_reduction"` (portfolio
                    margining risk reduction), `"pme_account_locked"` (portfolio
                    margining account locked per currency), `"position_locked"`,
                    `"mmp_trigger"` (market maker protection),
                    `"mmp_config_curtailment"` (market maker configured quantity
                    decreased), `"edit_post_only_reject"` (cancelled on edit
                    because of `reject_post_only` setting), `"oco_other_closed"`
                    (the oco order linked to this order was closed),
                    `"oto_primary_closed"` (the oto primary order that was going
                    to trigger this order was cancelled), `"settlement"` (closed
                    because of a settlement)
                  enum:
                    - user_request
                    - autoliquidation
                    - cancel_on_disconnect
                    - risk_mitigation
                    - pme_risk_reduction
                    - pme_account_locked
                    - position_locked
                    - mmp_trigger
                    - mmp_config_curtailment
                    - edit_post_only_reject
                    - oco_other_closed
                    - oto_primary_closed
                    - settlement
                  x-parser-schema-id: <anonymous-schema-726>
                oto_order_ids:
                  type: object
                  description: >-
                    The Ids of the orders that will be triggered if the order is
                    filled
                  properties: {}
                  additionalProperties: true
                  x-parser-schema-id: <anonymous-schema-727>
                trigger_fill_condition:
                  description: >-
                    <p>The fill condition of the linked order (Only for linked
                    order types), default: `first_hit`.</p> <ul>
                    <li>`"first_hit"` - any execution of the primary order will
                    fully cancel/place all secondary orders.</li>
                    <li>`"complete_fill"` - a complete execution (meaning the
                    primary order no longer exists) will cancel/place the
                    secondary orders.</li> <li>`"incremental"` - any fill of the
                    primary order will cause proportional partial
                    cancellation/placement of the secondary order. The amount
                    that will be subtracted/added to the secondary order will be
                    rounded down to the contract size.</li> </ul>
                  type: string
                  enum:
                    - first_hit
                    - complete_fill
                    - incremental
                  x-parser-schema-id: <anonymous-schema-728>
                oco_ref:
                  type: string
                  description: >-
                    Unique reference that identifies a one_cancels_others (OCO)
                    pair.
                  x-parser-schema-id: <anonymous-schema-729>
                primary_order_id:
                  description: Unique order identifier
                  type: string
                  example: ETH-100234
                  x-parser-schema-id: <anonymous-schema-730>
                is_secondary_oto:
                  type: boolean
                  description: >-
                    `true` if the order is an order that can be triggered by
                    another order, otherwise not present.
                  x-parser-schema-id: <anonymous-schema-731>
                is_primary_otoco:
                  type: boolean
                  description: >-
                    `true` if the order is an order that can trigger an OCO
                    pair, otherwise not present.
                  x-parser-schema-id: <anonymous-schema-732>
              required:
                - order_id
                - order_state
                - order_type
                - time_in_force
                - instrument_name
                - creation_timestamp
                - last_update_timestamp
                - direction
                - price
                - label
                - post_only
                - api
              additionalProperties: false
              x-parser-schema-id: <anonymous-schema-680>
          required:
            - data
          additionalProperties: false
          x-parser-schema-id: <anonymous-schema-679>
        title: Subscription Notification Data
        description: Server sends subscription notification data
        example: |-
          {
            "data": {
              "time_in_force": "good_til_cancelled",
              "replaced": false,
              "reduce_only": false,
              "price": 10542.68,
              "post_only": false,
              "original_order_type": "market",
              "order_type": "limit",
              "order_state": "open",
              "order_id": "6",
              "max_show": 200,
              "last_update_timestamp": 1581507583024,
              "label": "",
              "is_rebalance": false,
              "is_liquidation": false,
              "instrument_name": "BTC-PERPETUAL",
              "filled_amount": 0,
              "direction": "buy",
              "creation_timestamp": 1581507583024,
              "average_price": 0,
              "api": false,
              "amount": 200
            }
          }
        bindings: []
        extensions:
          - id: x-parser-unique-object-id
            value: subscription_message
    bindings: []
    extensions: &ref_0
      - id: x-parser-unique-object-id
        value: user.orders.(kind).(currency).raw
  - &ref_1
    id: receive_user_orders_kind_currency_raw_updates
    title: Receive user updates
    description: Client receives user update notifications
    type: receive
    messages:
      - &ref_3
        id: subscribe_request
        contentType: application/json
        payload:
          - name: Subscription Request
            description: >-
              Client sends subscription request to subscribe to notification
              channel. Please refer to [Notification
              page](https://deribit.mintlify.app/articles/notifications) for
              more information.
            type: object
            properties: []
        headers: []
        jsonPayloadSchema:
          properties: {}
          additionalProperties: false
          x-parser-schema-id: <anonymous-schema-678>
        title: Subscription Request
        description: >-
          Client sends subscription request to subscribe to notification
          channel. Please refer to [Notification
          page](https://deribit.mintlify.app/articles/notifications) for more
          information.
        example: |-
          {
            "jsonrpc": "2.0",
            "method": "public/subscribe",
            "id": 42,
            "params": {
              "channels": [
                "user.orders.(kind).(currency).raw"
              ]
            }
          }
        bindings: []
        extensions:
          - id: x-parser-unique-object-id
            value: subscribe_request
    bindings: []
    extensions: *ref_0
sendOperations:
  - *ref_1
receiveOperations:
  - *ref_2
sendMessages:
  - *ref_3
receiveMessages:
  - *ref_4
extensions:
  - id: x-parser-unique-object-id
    value: user.orders.(kind).(currency).raw
securitySchemes: []

````


> ## Documentation Index
> Fetch the complete documentation index at: https://docs.deribit.com/llms.txt
> Use this file to discover all available pages before exploring further.

<AgentInstructions>

## Submitting Feedback

If you encounter incorrect, outdated, or confusing documentation on this page, submit feedback:

POST https://docs.deribit.com/feedback

```json
{
  "path": "/subscriptions/user/userorderskindcurrencyinterval",
  "feedback": "Description of the issue"
}
```

Only submit feedback when you have something specific and actionable to report.

</AgentInstructions>

# user.orders.(kind).(currency).(interval) 

> User order updates across all instruments for a given kind and currency (aggregated).

Use this channel to receive private order updates across all matching instruments, aggregated according to `interval`.




## AsyncAPI

````yaml specifications/deribit_asyncapi.json user.orders.(kind).(currency).(interval)
id: user.orders.(kind).(currency).(interval)
title: 'user.orders.(kind).(currency).(interval) '
description: >
  User order updates across all instruments for a given kind and currency
  (aggregated).


  Use this channel to receive private order updates across all matching
  instruments, aggregated according to `interval`.
servers:
  - id: production
    protocol: wss
    host: deribit.com/ws/api/v2
    bindings: []
    variables: []
  - id: testnet
    protocol: wss
    host: test.deribit.com/ws/api/v2
    bindings: []
    variables: []
address: user.orders.(kind).(currency).(interval)
parameters:
  - id: kind
    jsonSchema:
      type: string
      description: >-
        Instrument kind


        **Allowed values:** `future`, `option`, `spot`, `future_combo`,
        `option_combo`
      enum:
        - future
        - option
        - spot
        - future_combo
        - option_combo
    description: >-
      Instrument kind


      **Allowed values:** `future`, `option`, `spot`, `future_combo`,
      `option_combo`
    type: string
    required: true
    deprecated: false
  - id: currency
    jsonSchema:
      type: string
      description: |-
        Currency code or `any` for all

        **Allowed values:** `BTC`, `ETH`, `USDC`, `USDT`, `EURR`, `any`
      enum:
        - BTC
        - ETH
        - USDC
        - USDT
        - EURR
        - any
    description: |-
      Currency code or `any` for all

      **Allowed values:** `BTC`, `ETH`, `USDC`, `USDT`, `EURR`, `any`
    type: string
    required: true
    deprecated: false
  - id: interval
    jsonSchema:
      type: string
      description: >-
        Frequency of notifications. Events will be aggregated over this
        interval. The value `raw` means no aggregation will be applied **(Please
        note that `raw` interval is only available to authorized users)**


        **Allowed values:** `raw`, `100ms`, `agg2`
      enum:
        - raw
        - 100ms
        - agg2
    description: >-
      Frequency of notifications. Events will be aggregated over this interval.
      The value `raw` means no aggregation will be applied **(Please note that
      `raw` interval is only available to authorized users)**


      **Allowed values:** `raw`, `100ms`, `agg2`
    type: string
    required: true
    deprecated: false
bindings: []
operations:
  - &ref_2
    id: send_subscribe_user_orders_kind_currency_interval
    title: Send subscribe request for user
    description: Client sends subscription request for user updates
    type: send
    messages:
      - &ref_4
        id: subscription_message
        contentType: application/json
        payload:
          - name: Subscription Notification Data
            description: Server sends subscription notification data
            type: object
            properties:
              - name: data
                type: object
                required: true
                properties:
                  - name: order_id
                    type: string
                    description: Unique order identifier
                    required: false
                  - name: order_state
                    type: string
                    description: >-
                      Order state: `"open"`, `"filled"`, `"rejected"`,
                      `"cancelled"`, `"untriggered"`
                    enumValues:
                      - open
                      - filled
                      - rejected
                      - cancelled
                      - untriggered
                      - triggered
                    required: false
                  - name: order_type
                    type: string
                    description: >-
                      Order type: `"limit"`, `"market"`, `"stop_limit"`,
                      `"stop_market"`, `"take_limit"`, `"take_market"`,
                      `"trailing_stop"`
                    enumValues:
                      - market
                      - limit
                      - stop_market
                      - stop_limit
                      - take_market
                      - take_limit
                      - trailing_stop
                    required: false
                  - name: original_order_type
                    type: string
                    description: Original order type. Optional field
                    enumValues:
                      - market
                      - market_limit
                    required: false
                  - name: time_in_force
                    type: string
                    description: >-
                      Order time in force: `"good_til_cancelled"`,
                      `"good_til_day"`, `"fill_or_kill"` or
                      `"immediate_or_cancel"`
                    enumValues:
                      - good_til_cancelled
                      - good_til_day
                      - fill_or_kill
                      - immediate_or_cancel
                    required: false
                  - name: is_rebalance
                    type: boolean
                    description: >-
                      Optional (only for spot). `true` if order was
                      automatically created during cross-collateral balance
                      restoration
                    required: false
                  - name: is_liquidation
                    type: boolean
                    description: >-
                      Optional (not added for spot). `true` if order was
                      automatically created during liquidation
                    required: false
                  - name: instrument_name
                    type: string
                    description: Unique instrument identifier
                    required: false
                  - name: creation_timestamp
                    type: integer
                    description: The timestamp (milliseconds since the Unix epoch)
                    required: false
                  - name: last_update_timestamp
                    type: integer
                    description: The timestamp (milliseconds since the Unix epoch)
                    required: false
                  - name: direction
                    type: string
                    description: 'Direction: `buy`, or `sell`'
                    enumValues:
                      - buy
                      - sell
                    required: false
                  - name: description
                    type: string
                    description: >-
                      Price in base currency or "market_price" in case of open
                      trigger market orders
                    required: false
                  - name: label
                    type: string
                    description: User defined label (up to 64 characters)
                    required: false
                  - name: post_only
                    type: boolean
                    description: '`true` for post-only orders only'
                    required: false
                  - name: reject_post_only
                    type: boolean
                    description: >-
                      `true` if order has `reject_post_only` flag (field is
                      present only when `post_only` is `true`)
                    required: false
                  - name: reduce_only
                    type: boolean
                    description: >-
                      Optional (not added for spot). '`true` for reduce-only
                      orders only'
                    required: false
                  - name: api
                    type: boolean
                    description: '`true` if created with API'
                    required: false
                  - name: web
                    type: boolean
                    description: '`true` if created via Deribit frontend (optional)'
                    required: false
                  - name: mobile
                    type: boolean
                    description: >-
                      Optional field with value `true` added only when created
                      with Mobile Application
                    required: false
                  - name: refresh_amount
                    type: number
                    description: >-
                      The initial display amount of iceberg order. Iceberg order
                      display amount will be refreshed to that value after match
                      consuming actual display amount. Absent for other types of
                      orders
                    required: false
                  - name: display_amount
                    type: number
                    description: >-
                      The actual display amount of iceberg order. Absent for
                      other types of orders.
                    required: false
                  - name: amount
                    type: number
                    description: >-
                      It represents the requested order size. For perpetual and
                      inverse futures the amount is in USD units. For options
                      and linear futures it is the underlying base currency
                      coin.
                    required: false
                  - name: contracts
                    type: number
                    description: >-
                      It represents the order size in contract units. (Optional,
                      may be absent in historical data).
                    required: false
                  - name: filled_amount
                    type: number
                    description: >-
                      Filled amount of the order. For perpetual and futures the
                      filled_amount is in USD units, for options - in units or
                      corresponding cryptocurrency contracts, e.g., BTC or ETH.
                    required: false
                  - name: average_price
                    type: number
                    description: Average fill price of the order
                    required: false
                  - name: advanced
                    type: string
                    description: >
                      advanced type: `"usd"` or `"implv"` (Only for options;
                      field is omitted if not applicable).
                    enumValues:
                      - usd
                      - implv
                    required: false
                  - name: implv
                    type: number
                    description: >-
                      Implied volatility in percent. (Only if
                      `advanced="implv"`)
                    required: false
                  - name: usd
                    type: number
                    description: Option price in USD (Only if `advanced="usd"`)
                    required: false
                  - name: triggered
                    type: boolean
                    description: Whether the trigger order has been triggered
                    required: false
                  - name: trigger
                    type: string
                    description: >-
                      Trigger type (only for trigger orders). Allowed values:
                      `"index_price"`, `"mark_price"`, `"last_price"`.
                    enumValues:
                      - index_price
                      - mark_price
                      - last_price
                    required: false
                  - name: trigger_price
                    type: number
                    description: Trigger price (Only for future trigger orders)
                    required: false
                  - name: trigger_offset
                    type: number
                    description: >-
                      The maximum deviation from the price peak beyond which the
                      order will be triggered (Only for trailing trigger orders)
                    required: false
                  - name: trigger_reference_price
                    type: number
                    description: >-
                      The price of the given trigger at the time when the order
                      was placed (Only for trailing trigger orders)
                    required: false
                  - name: block_trade
                    type: boolean
                    description: >-
                      `true` if order made from block_trade trade, added only in
                      that case.
                    required: false
                  - name: mmp
                    type: boolean
                    description: '`true` if the order is a MMP order, otherwise `false`.'
                    required: false
                  - name: risk_reducing
                    type: boolean
                    description: >-
                      `true` if the order is marked by the platform as a risk
                      reducing order (can apply only to orders placed by PM
                      users), otherwise `false`.
                    required: false
                  - name: replaced
                    type: boolean
                    description: >-
                      `true` if the order was edited (by user or - in case of
                      advanced options orders - by pricing engine), otherwise
                      `false`.
                    required: false
                  - name: auto_replaced
                    type: boolean
                    description: >-
                      Options, advanced orders only - `true` if last
                      modification of the order was performed by the pricing
                      engine, otherwise `false`.
                    required: false
                  - name: quote
                    type: boolean
                    description: If order is a quote. Present only if true.
                    required: false
                  - name: mmp_group
                    type: string
                    description: >-
                      Name of the MMP group supplied in the `private/mass_quote`
                      request. Only present for quote orders.
                    required: false
                  - name: quote_set_id
                    type: string
                    description: >-
                      Identifier of the QuoteSet supplied in the
                      `private/mass_quote` request. Only present for quote
                      orders.
                    required: false
                  - name: quote_id
                    type: string
                    description: >-
                      The same QuoteID as supplied in the `private/mass_quote`
                      request. Only present for quote orders.
                    required: false
                  - name: trigger_order_id
                    type: string
                    description: >-
                      Id of the trigger order that created the order (Only for
                      orders that were created by triggered orders).
                    required: false
                  - name: app_name
                    type: string
                    description: >-
                      The name of the application that placed the order on
                      behalf of the user (optional).
                    required: false
                  - name: mmp_cancelled
                    type: boolean
                    description: '`true` if order was cancelled by mmp trigger (optional)'
                    required: false
                  - name: cancel_reason
                    type: string
                    description: >-
                      Enumerated reason behind cancel `"user_request"`,
                      `"autoliquidation"`, `"cancel_on_disconnect"`,
                      `"risk_mitigation"`, `"pme_risk_reduction"` (portfolio
                      margining risk reduction), `"pme_account_locked"`
                      (portfolio margining account locked per currency),
                      `"position_locked"`, `"mmp_trigger"` (market maker
                      protection), `"mmp_config_curtailment"` (market maker
                      configured quantity decreased), `"edit_post_only_reject"`
                      (cancelled on edit because of `reject_post_only` setting),
                      `"oco_other_closed"` (the oco order linked to this order
                      was closed), `"oto_primary_closed"` (the oto primary order
                      that was going to trigger this order was cancelled),
                      `"settlement"` (closed because of a settlement)
                    enumValues:
                      - user_request
                      - autoliquidation
                      - cancel_on_disconnect
                      - risk_mitigation
                      - pme_risk_reduction
                      - pme_account_locked
                      - position_locked
                      - mmp_trigger
                      - mmp_config_curtailment
                      - edit_post_only_reject
                      - oco_other_closed
                      - oto_primary_closed
                      - settlement
                    required: false
                  - name: oto_order_ids
                    type: object
                    description: >-
                      The Ids of the orders that will be triggered if the order
                      is filled
                    required: false
                    properties: []
                  - name: trigger_fill_condition
                    type: string
                    description: >-
                      <p>The fill condition of the linked order (Only for linked
                      order types), default: `first_hit`.</p> <ul>
                      <li>`"first_hit"` - any execution of the primary order
                      will fully cancel/place all secondary orders.</li>
                      <li>`"complete_fill"` - a complete execution (meaning the
                      primary order no longer exists) will cancel/place the
                      secondary orders.</li> <li>`"incremental"` - any fill of
                      the primary order will cause proportional partial
                      cancellation/placement of the secondary order. The amount
                      that will be subtracted/added to the secondary order will
                      be rounded down to the contract size.</li> </ul>
                    enumValues:
                      - first_hit
                      - complete_fill
                      - incremental
                    required: false
                  - name: oco_ref
                    type: string
                    description: >-
                      Unique reference that identifies a one_cancels_others
                      (OCO) pair.
                    required: false
                  - name: primary_order_id
                    type: string
                    description: Unique order identifier
                    required: false
                  - name: is_secondary_oto
                    type: boolean
                    description: >-
                      `true` if the order is an order that can be triggered by
                      another order, otherwise not present.
                    required: false
                  - name: is_primary_otoco
                    type: boolean
                    description: >-
                      `true` if the order is an order that can trigger an OCO
                      pair, otherwise not present.
                    required: false
        headers: []
        jsonPayloadSchema:
          type: object
          description: Response containing notification data
          properties:
            data:
              type: object
              description: ''
              properties:
                order_id:
                  description: Unique order identifier
                  type: string
                  example: ETH-100234
                  x-parser-schema-id: <anonymous-schema-739>
                order_state:
                  type: string
                  description: >-
                    Order state: `"open"`, `"filled"`, `"rejected"`,
                    `"cancelled"`, `"untriggered"`
                  enum:
                    - open
                    - filled
                    - rejected
                    - cancelled
                    - untriggered
                    - triggered
                  x-parser-schema-id: <anonymous-schema-740>
                order_type:
                  type: string
                  description: >-
                    Order type: `"limit"`, `"market"`, `"stop_limit"`,
                    `"stop_market"`, `"take_limit"`, `"take_market"`,
                    `"trailing_stop"`
                  enum:
                    - market
                    - limit
                    - stop_market
                    - stop_limit
                    - take_market
                    - take_limit
                    - trailing_stop
                  x-parser-schema-id: <anonymous-schema-741>
                original_order_type:
                  type: string
                  description: Original order type. Optional field
                  enum:
                    - market
                    - market_limit
                  x-parser-schema-id: <anonymous-schema-742>
                time_in_force:
                  type: string
                  description: >-
                    Order time in force: `"good_til_cancelled"`,
                    `"good_til_day"`, `"fill_or_kill"` or
                    `"immediate_or_cancel"`
                  enum:
                    - good_til_cancelled
                    - good_til_day
                    - fill_or_kill
                    - immediate_or_cancel
                  x-parser-schema-id: <anonymous-schema-743>
                is_rebalance:
                  type: boolean
                  description: >-
                    Optional (only for spot). `true` if order was automatically
                    created during cross-collateral balance restoration
                  x-parser-schema-id: <anonymous-schema-744>
                is_liquidation:
                  type: boolean
                  description: >-
                    Optional (not added for spot). `true` if order was
                    automatically created during liquidation
                  x-parser-schema-id: <anonymous-schema-745>
                instrument_name:
                  type: string
                  description: Unique instrument identifier
                  example: BTC-PERPETUAL
                  x-parser-schema-id: <anonymous-schema-746>
                creation_timestamp:
                  type: integer
                  example: 1536569522277
                  description: The timestamp (milliseconds since the Unix epoch)
                  x-parser-schema-id: <anonymous-schema-747>
                last_update_timestamp:
                  type: integer
                  example: 1536569522277
                  description: The timestamp (milliseconds since the Unix epoch)
                  x-parser-schema-id: <anonymous-schema-748>
                direction:
                  type: string
                  description: 'Direction: `buy`, or `sell`'
                  enum:
                    - buy
                    - sell
                  x-parser-schema-id: <anonymous-schema-749>
                price:
                  description: >-
                    Price in base currency or "market_price" in case of open
                    trigger market orders
                  x-parser-schema-id: <anonymous-schema-750>
                label:
                  type: string
                  description: User defined label (up to 64 characters)
                  x-parser-schema-id: <anonymous-schema-751>
                post_only:
                  type: boolean
                  description: '`true` for post-only orders only'
                  x-parser-schema-id: <anonymous-schema-752>
                reject_post_only:
                  description: >-
                    `true` if order has `reject_post_only` flag (field is
                    present only when `post_only` is `true`)
                  type: boolean
                  x-parser-schema-id: <anonymous-schema-753>
                reduce_only:
                  type: boolean
                  description: >-
                    Optional (not added for spot). '`true` for reduce-only
                    orders only'
                  x-parser-schema-id: <anonymous-schema-754>
                api:
                  type: boolean
                  description: '`true` if created with API'
                  x-parser-schema-id: <anonymous-schema-755>
                web:
                  type: boolean
                  description: '`true` if created via Deribit frontend (optional)'
                  x-parser-schema-id: <anonymous-schema-756>
                mobile:
                  type: boolean
                  description: >-
                    Optional field with value `true` added only when created
                    with Mobile Application
                  x-parser-schema-id: <anonymous-schema-757>
                refresh_amount:
                  type: number
                  description: >-
                    The initial display amount of iceberg order. Iceberg order
                    display amount will be refreshed to that value after match
                    consuming actual display amount. Absent for other types of
                    orders
                  x-parser-schema-id: <anonymous-schema-758>
                display_amount:
                  type: number
                  description: >-
                    The actual display amount of iceberg order. Absent for other
                    types of orders.
                  x-parser-schema-id: <anonymous-schema-759>
                amount:
                  type: number
                  description: >-
                    It represents the requested order size. For perpetual and
                    inverse futures the amount is in USD units. For options and
                    linear futures it is the underlying base currency coin.
                  x-parser-schema-id: <anonymous-schema-760>
                contracts:
                  type: number
                  description: >-
                    It represents the order size in contract units. (Optional,
                    may be absent in historical data).
                  x-parser-schema-id: <anonymous-schema-761>
                filled_amount:
                  type: number
                  description: >-
                    Filled amount of the order. For perpetual and futures the
                    filled_amount is in USD units, for options - in units or
                    corresponding cryptocurrency contracts, e.g., BTC or ETH.
                  x-parser-schema-id: <anonymous-schema-762>
                average_price:
                  type: number
                  description: Average fill price of the order
                  x-parser-schema-id: <anonymous-schema-763>
                advanced:
                  type: string
                  description: >
                    advanced type: `"usd"` or `"implv"` (Only for options; field
                    is omitted if not applicable).
                  enum:
                    - usd
                    - implv
                  x-parser-schema-id: <anonymous-schema-764>
                implv:
                  type: number
                  description: Implied volatility in percent. (Only if `advanced="implv"`)
                  x-parser-schema-id: <anonymous-schema-765>
                usd:
                  type: number
                  description: Option price in USD (Only if `advanced="usd"`)
                  x-parser-schema-id: <anonymous-schema-766>
                triggered:
                  type: boolean
                  description: Whether the trigger order has been triggered
                  x-parser-schema-id: <anonymous-schema-767>
                trigger:
                  type: string
                  description: >-
                    Trigger type (only for trigger orders). Allowed values:
                    `"index_price"`, `"mark_price"`, `"last_price"`.
                  enum:
                    - index_price
                    - mark_price
                    - last_price
                  x-parser-schema-id: <anonymous-schema-768>
                trigger_price:
                  type: number
                  description: Trigger price (Only for future trigger orders)
                  x-parser-schema-id: <anonymous-schema-769>
                trigger_offset:
                  type: number
                  description: >-
                    The maximum deviation from the price peak beyond which the
                    order will be triggered (Only for trailing trigger orders)
                  x-parser-schema-id: <anonymous-schema-770>
                trigger_reference_price:
                  type: number
                  description: >-
                    The price of the given trigger at the time when the order
                    was placed (Only for trailing trigger orders)
                  x-parser-schema-id: <anonymous-schema-771>
                block_trade:
                  description: >-
                    `true` if order made from block_trade trade, added only in
                    that case.
                  type: boolean
                  example: true
                  x-parser-schema-id: <anonymous-schema-772>
                mmp:
                  type: boolean
                  description: '`true` if the order is a MMP order, otherwise `false`.'
                  x-parser-schema-id: <anonymous-schema-773>
                risk_reducing:
                  type: boolean
                  description: >-
                    `true` if the order is marked by the platform as a risk
                    reducing order (can apply only to orders placed by PM
                    users), otherwise `false`.
                  x-parser-schema-id: <anonymous-schema-774>
                replaced:
                  type: boolean
                  description: >-
                    `true` if the order was edited (by user or - in case of
                    advanced options orders - by pricing engine), otherwise
                    `false`.
                  x-parser-schema-id: <anonymous-schema-775>
                auto_replaced:
                  type: boolean
                  description: >-
                    Options, advanced orders only - `true` if last modification
                    of the order was performed by the pricing engine, otherwise
                    `false`.
                  x-parser-schema-id: <anonymous-schema-776>
                quote:
                  type: boolean
                  description: If order is a quote. Present only if true.
                  x-parser-schema-id: <anonymous-schema-777>
                mmp_group:
                  type: string
                  description: >-
                    Name of the MMP group supplied in the `private/mass_quote`
                    request. Only present for quote orders.
                  x-parser-schema-id: <anonymous-schema-778>
                quote_set_id:
                  type: string
                  description: >-
                    Identifier of the QuoteSet supplied in the
                    `private/mass_quote` request. Only present for quote orders.
                  x-parser-schema-id: <anonymous-schema-779>
                quote_id:
                  type: string
                  description: >-
                    The same QuoteID as supplied in the `private/mass_quote`
                    request. Only present for quote orders.
                  x-parser-schema-id: <anonymous-schema-780>
                trigger_order_id:
                  type: string
                  description: >-
                    Id of the trigger order that created the order (Only for
                    orders that were created by triggered orders).
                  example: SLIB-370
                  x-parser-schema-id: <anonymous-schema-781>
                app_name:
                  type: string
                  description: >-
                    The name of the application that placed the order on behalf
                    of the user (optional).
                  example: Example Application
                  x-parser-schema-id: <anonymous-schema-782>
                mmp_cancelled:
                  type: boolean
                  description: '`true` if order was cancelled by mmp trigger (optional)'
                  example: true
                  x-parser-schema-id: <anonymous-schema-783>
                cancel_reason:
                  type: string
                  description: >-
                    Enumerated reason behind cancel `"user_request"`,
                    `"autoliquidation"`, `"cancel_on_disconnect"`,
                    `"risk_mitigation"`, `"pme_risk_reduction"` (portfolio
                    margining risk reduction), `"pme_account_locked"` (portfolio
                    margining account locked per currency), `"position_locked"`,
                    `"mmp_trigger"` (market maker protection),
                    `"mmp_config_curtailment"` (market maker configured quantity
                    decreased), `"edit_post_only_reject"` (cancelled on edit
                    because of `reject_post_only` setting), `"oco_other_closed"`
                    (the oco order linked to this order was closed),
                    `"oto_primary_closed"` (the oto primary order that was going
                    to trigger this order was cancelled), `"settlement"` (closed
                    because of a settlement)
                  enum:
                    - user_request
                    - autoliquidation
                    - cancel_on_disconnect
                    - risk_mitigation
                    - pme_risk_reduction
                    - pme_account_locked
                    - position_locked
                    - mmp_trigger
                    - mmp_config_curtailment
                    - edit_post_only_reject
                    - oco_other_closed
                    - oto_primary_closed
                    - settlement
                  x-parser-schema-id: <anonymous-schema-784>
                oto_order_ids:
                  type: object
                  description: >-
                    The Ids of the orders that will be triggered if the order is
                    filled
                  properties: {}
                  additionalProperties: true
                  x-parser-schema-id: <anonymous-schema-785>
                trigger_fill_condition:
                  description: >-
                    <p>The fill condition of the linked order (Only for linked
                    order types), default: `first_hit`.</p> <ul>
                    <li>`"first_hit"` - any execution of the primary order will
                    fully cancel/place all secondary orders.</li>
                    <li>`"complete_fill"` - a complete execution (meaning the
                    primary order no longer exists) will cancel/place the
                    secondary orders.</li> <li>`"incremental"` - any fill of the
                    primary order will cause proportional partial
                    cancellation/placement of the secondary order. The amount
                    that will be subtracted/added to the secondary order will be
                    rounded down to the contract size.</li> </ul>
                  type: string
                  enum:
                    - first_hit
                    - complete_fill
                    - incremental
                  x-parser-schema-id: <anonymous-schema-786>
                oco_ref:
                  type: string
                  description: >-
                    Unique reference that identifies a one_cancels_others (OCO)
                    pair.
                  x-parser-schema-id: <anonymous-schema-787>
                primary_order_id:
                  description: Unique order identifier
                  type: string
                  example: ETH-100234
                  x-parser-schema-id: <anonymous-schema-788>
                is_secondary_oto:
                  type: boolean
                  description: >-
                    `true` if the order is an order that can be triggered by
                    another order, otherwise not present.
                  x-parser-schema-id: <anonymous-schema-789>
                is_primary_otoco:
                  type: boolean
                  description: >-
                    `true` if the order is an order that can trigger an OCO
                    pair, otherwise not present.
                  x-parser-schema-id: <anonymous-schema-790>
              required:
                - order_id
                - order_state
                - order_type
                - time_in_force
                - instrument_name
                - creation_timestamp
                - last_update_timestamp
                - direction
                - price
                - label
                - post_only
                - api
              additionalProperties: false
              x-parser-schema-id: <anonymous-schema-738>
          required:
            - data
          additionalProperties: false
          x-parser-schema-id: <anonymous-schema-737>
        title: Subscription Notification Data
        description: Server sends subscription notification data
        example: |-
          {
            "data": [
              {
                "time_in_force": "good_til_cancelled",
                "reduce_only": false,
                "price": 3928.5,
                "post_only": false,
                "order_type": "limit",
                "order_state": "open",
                "order_id": "476137",
                "max_show": 120,
                "last_update_timestamp": 1550826337209,
                "label": "",
                "is_rebalance": false,
                "is_liquidation": false,
                "instrument_name": "BTC-PERPETUAL",
                "filled_amount": 0,
                "direction": "buy",
                "creation_timestamp": 1550826337209,
                "average_price": 0,
                "api": false,
                "amount": 120
              }
            ]
          }
        bindings: []
        extensions:
          - id: x-parser-unique-object-id
            value: subscription_message
    bindings: []
    extensions: &ref_0
      - id: x-parser-unique-object-id
        value: user.orders.(kind).(currency).(interval)
  - &ref_1
    id: receive_user_orders_kind_currency_interval_updates
    title: Receive user updates
    description: Client receives user update notifications
    type: receive
    messages:
      - &ref_3
        id: subscribe_request
        contentType: application/json
        payload:
          - name: Subscription Request
            description: >-
              Client sends subscription request to subscribe to notification
              channel. Please refer to [Notification
              page](https://deribit.mintlify.app/articles/notifications) for
              more information.
            type: object
            properties: []
        headers: []
        jsonPayloadSchema:
          properties: {}
          additionalProperties: false
          x-parser-schema-id: <anonymous-schema-736>
        title: Subscription Request
        description: >-
          Client sends subscription request to subscribe to notification
          channel. Please refer to [Notification
          page](https://deribit.mintlify.app/articles/notifications) for more
          information.
        example: |-
          {
            "jsonrpc": "2.0",
            "method": "public/subscribe",
            "id": 42,
            "params": {
              "channels": [
                "user.orders.(kind).(currency).100ms"
              ]
            }
          }
        bindings: []
        extensions:
          - id: x-parser-unique-object-id
            value: subscribe_request
    bindings: []
    extensions: *ref_0
sendOperations:
  - *ref_1
receiveOperations:
  - *ref_2
sendMessages:
  - *ref_3
receiveMessages:
  - *ref_4
extensions:
  - id: x-parser-unique-object-id
    value: user.orders.(kind).(currency).(interval)
securitySchemes: []

````

> ## Documentation Index
> Fetch the complete documentation index at: https://docs.deribit.com/llms.txt
> Use this file to discover all available pages before exploring further.

<AgentInstructions>

## Submitting Feedback

If you encounter incorrect, outdated, or confusing documentation on this page, submit feedback:

POST https://docs.deribit.com/feedback

```json
{
  "path": "/subscriptions/user/userchangesinstrument_nameinterval",
  "feedback": "Description of the issue"
}
```

Only submit feedback when you have something specific and actionable to report.

</AgentInstructions>

# user.changes.(instrument_name).(interval) 

> User change stream (orders, trades, and related updates) for a specific instrument.

This channel provides a consolidated private update stream for your account for the given instrument. Use it when you want a single feed instead of subscribing to orders and trades separately.




## AsyncAPI

````yaml specifications/deribit_asyncapi.json user.changes.(instrument_name).(interval)
id: user.changes.(instrument_name).(interval)
title: 'user.changes.(instrument_name).(interval) '
description: >
  User change stream (orders, trades, and related updates) for a specific
  instrument.


  This channel provides a consolidated private update stream for your account
  for the given instrument. Use it when you want a single feed instead of
  subscribing to orders and trades separately.
servers:
  - id: production
    protocol: wss
    host: deribit.com/ws/api/v2
    bindings: []
    variables: []
  - id: testnet
    protocol: wss
    host: test.deribit.com/ws/api/v2
    bindings: []
    variables: []
address: user.changes.(instrument_name).(interval)
parameters:
  - id: instrument_name
    jsonSchema:
      type: string
      description: The name of the instrument
    description: The name of the instrument
    type: string
    required: true
    deprecated: false
  - id: interval
    jsonSchema:
      type: string
      description: >-
        Frequency of notifications. Events will be aggregated over this
        interval. The value `raw` means no aggregation will be applied **(Please
        note that `raw` interval is only available to authorized users)**


        **Allowed values:** `raw`, `100ms`, `agg2`
      enum:
        - raw
        - 100ms
        - agg2
    description: >-
      Frequency of notifications. Events will be aggregated over this interval.
      The value `raw` means no aggregation will be applied **(Please note that
      `raw` interval is only available to authorized users)**


      **Allowed values:** `raw`, `100ms`, `agg2`
    type: string
    required: true
    deprecated: false
bindings: []
operations:
  - &ref_2
    id: send_subscribe_user_changes_instrument_name_interval
    title: Send subscribe request for user
    description: Client sends subscription request for user updates
    type: send
    messages:
      - &ref_4
        id: subscription_message
        contentType: application/json
        payload:
          - name: Subscription Notification Data
            description: Server sends subscription notification data
            type: object
            properties:
              - name: data
                type: object
                required: true
                properties:
                  - name: instrument_name
                    type: string
                    description: Unique instrument identifier
                    required: false
                  - name: trades
                    type: object
                    required: false
                    properties:
                      - name: trade_id
                        type: string
                        description: Unique (per currency) trade identifier
                        required: false
                      - name: trade_seq
                        type: integer
                        description: The sequence number of the trade within instrument
                        required: false
                      - name: instrument_name
                        type: string
                        description: Unique instrument identifier
                        required: false
                      - name: timestamp
                        type: integer
                        description: >-
                          The timestamp of the trade (milliseconds since the
                          UNIX epoch)
                        required: false
                      - name: order_type
                        type: string
                        description: 'Order type: `"limit`, `"market"`, or `"liquidation"`'
                        enumValues:
                          - limit
                          - market
                          - liquidation
                        required: false
                      - name: advanced
                        type: string
                        description: >-
                          Advanced type of user order: `"usd"` or `"implv"`
                          (only for options; omitted if not applicable)
                        enumValues:
                          - usd
                          - implv
                        required: false
                      - name: order_id
                        type: string
                        description: >-
                          Id of the user order (maker or taker), i.e.
                          subscriber's order id that took part in the trade
                        required: false
                      - name: matching_id
                        type: string
                        description: Always `null`
                        required: false
                      - name: direction
                        type: string
                        description: 'Direction: `buy`, or `sell`'
                        enumValues:
                          - buy
                          - sell
                        required: false
                      - name: tick_direction
                        type: integer
                        description: >-
                          Direction of the "tick" (`0` = Plus Tick, `1` =
                          Zero-Plus Tick, `2` = Minus Tick, `3` = Zero-Minus
                          Tick).
                        enumValues:
                          - 0
                          - 1
                          - 2
                          - 3
                        required: false
                      - name: index_price
                        type: number
                        description: Index Price at the moment of trade
                        required: false
                      - name: price
                        type: number
                        description: Price in base currency
                        required: false
                      - name: amount
                        type: number
                        description: >-
                          Trade amount. For perpetual and inverse futures the
                          amount is in USD units. For options and linear futures
                          it is the underlying base currency coin.
                        required: false
                      - name: contracts
                        type: number
                        description: >-
                          Trade size in contract units (optional, may be absent
                          in historical trades)
                        required: false
                      - name: iv
                        type: number
                        description: Option implied volatility for the price (Option only)
                        required: false
                      - name: underlying_price
                        type: number
                        description: >-
                          Underlying price for implied volatility calculations
                          (Options only)
                        required: false
                      - name: liquidation
                        type: string
                        description: >-
                          Optional field (only for trades caused by
                          liquidation): `"M"` when maker side of trade was under
                          liquidation, `"T"` when taker side was under
                          liquidation, `"MT"` when both sides of trade were
                          under liquidation
                        enumValues:
                          - M
                          - T
                          - MT
                        required: false
                      - name: liquidity
                        type: string
                        description: >-
                          Describes what was role of users order: `"M"` when it
                          was maker order, `"T"` when it was taker order
                        enumValues:
                          - M
                          - T
                        required: false
                      - name: fee
                        type: number
                        description: User's fee in units of the specified `fee_currency`
                        required: false
                      - name: fee_currency
                        type: string
                        description: Currency, i.e `"BTC"`, `"ETH"`, `"USDC"`
                        enumValues:
                          - BTC
                          - ETH
                          - USDC
                          - USDT
                          - EURR
                        required: false
                      - name: label
                        type: string
                        description: >-
                          User defined label (presented only when previously set
                          for order by user)
                        required: false
                      - name: state
                        type: string
                        description: >-
                          Order state: `"open"`, `"filled"`, `"rejected"`,
                          `"cancelled"`, `"untriggered"` or `"archive"` (if
                          order was archived)
                        enumValues:
                          - open
                          - filled
                          - rejected
                          - cancelled
                          - untriggered
                          - archive
                        required: false
                      - name: block_trade_id
                        type: string
                        description: Block trade id - when trade was part of a block trade
                        required: false
                      - name: block_rfq_id
                        type: integer
                        description: >-
                          ID of the Block RFQ - when trade was part of the Block
                          RFQ
                        required: false
                      - name: block_rfq_quote_id
                        type: integer
                        description: >-
                          ID of the Block RFQ quote - when trade was part of the
                          Block RFQ
                        required: false
                      - name: reduce_only
                        type: string
                        description: '`true` if user order is reduce-only'
                        required: false
                      - name: post_only
                        type: string
                        description: '`true` if user order is post-only'
                        required: false
                      - name: mmp
                        type: boolean
                        description: '`true` if user order is MMP'
                        required: false
                      - name: risk_reducing
                        type: boolean
                        description: >-
                          `true` if user order is marked by the platform as a
                          risk reducing order (can apply only to orders placed
                          by PM users)
                        required: false
                      - name: api
                        type: boolean
                        description: '`true` if user order was created with API'
                        required: false
                      - name: profit_loss
                        type: number
                        description: Profit and loss in base currency.
                        required: false
                      - name: mark_price
                        type: number
                        description: Mark Price at the moment of trade
                        required: false
                      - name: legs
                        type: array
                        description: >-
                          Optional field containing leg trades if trade is a
                          combo trade (present when querying for **only** combo
                          trades and in `combo_trades` events)
                        required: false
                      - name: combo_id
                        type: string
                        description: >-
                          Optional field containing combo instrument name if the
                          trade is a combo trade
                        required: false
                      - name: combo_trade_id
                        type: number
                        description: >-
                          Optional field containing combo trade identifier if
                          the trade is a combo trade
                        required: false
                      - name: quote_set_id
                        type: string
                        description: >-
                          QuoteSet of the user order (optional, present only for
                          orders placed with `private/mass_quote`)
                        required: false
                      - name: quote_id
                        type: string
                        description: >-
                          QuoteID of the user order (optional, present only for
                          orders placed with `private/mass_quote`)
                        required: false
                      - name: trade_allocations
                        type: object
                        description: >-
                          List of allocations for Block RFQ pre-allocation. Each
                          allocation specifies `user_id`, `amount`, and `fee`
                          for the allocated part of the trade. For broker client
                          allocations, a `client_info` object will be included.
                        required: false
                        properties:
                          - name: user_id
                            type: integer
                            description: >-
                              User ID to which part of the trade is allocated.
                              For brokers the User ID is obstructed.
                            required: false
                          - name: amount
                            type: number
                            description: Amount allocated to this user.
                            required: false
                          - name: fee
                            type: number
                            description: Fee for the allocated part of the trade.
                            required: false
                          - name: client_info
                            type: object
                            description: Optional client allocation info for brokers.
                            required: false
                            properties:
                              - name: client_id
                                type: integer
                                description: >-
                                  ID of a client; available to broker.
                                  Represents a group of users under a common
                                  name.
                                required: false
                              - name: client_link_id
                                type: integer
                                description: >-
                                  ID assigned to a single user in a client;
                                  available to broker.
                                required: false
                              - name: name
                                type: string
                                description: >-
                                  Name of the linked user within the client;
                                  available to broker.
                                required: false
                  - name: orders
                    type: object
                    required: false
                    properties:
                      - name: order_id
                        type: string
                        description: Unique order identifier
                        required: false
                      - name: order_state
                        type: string
                        description: >-
                          Order state: `"open"`, `"filled"`, `"rejected"`,
                          `"cancelled"`, `"untriggered"`
                        enumValues:
                          - open
                          - filled
                          - rejected
                          - cancelled
                          - untriggered
                          - triggered
                        required: false
                      - name: order_type
                        type: string
                        description: >-
                          Order type: `"limit"`, `"market"`, `"stop_limit"`,
                          `"stop_market"`, `"take_limit"`, `"take_market"`,
                          `"trailing_stop"`
                        enumValues:
                          - market
                          - limit
                          - stop_market
                          - stop_limit
                          - take_market
                          - take_limit
                          - trailing_stop
                        required: false
                      - name: original_order_type
                        type: string
                        description: Original order type. Optional field
                        enumValues:
                          - market
                          - market_limit
                        required: false
                      - name: time_in_force
                        type: string
                        description: >-
                          Order time in force: `"good_til_cancelled"`,
                          `"good_til_day"`, `"fill_or_kill"` or
                          `"immediate_or_cancel"`
                        enumValues:
                          - good_til_cancelled
                          - good_til_day
                          - fill_or_kill
                          - immediate_or_cancel
                        required: false
                      - name: is_rebalance
                        type: boolean
                        description: >-
                          Optional (only for spot). `true` if order was
                          automatically created during cross-collateral balance
                          restoration
                        required: false
                      - name: is_liquidation
                        type: boolean
                        description: >-
                          Optional (not added for spot). `true` if order was
                          automatically created during liquidation
                        required: false
                      - name: instrument_name
                        type: string
                        description: Unique instrument identifier
                        required: false
                      - name: creation_timestamp
                        type: integer
                        description: The timestamp (milliseconds since the Unix epoch)
                        required: false
                      - name: last_update_timestamp
                        type: integer
                        description: The timestamp (milliseconds since the Unix epoch)
                        required: false
                      - name: direction
                        type: string
                        description: 'Direction: `buy`, or `sell`'
                        enumValues:
                          - buy
                          - sell
                        required: false
                      - name: description
                        type: string
                        description: >-
                          Price in base currency or "market_price" in case of
                          open trigger market orders
                        required: false
                      - name: label
                        type: string
                        description: User defined label (up to 64 characters)
                        required: false
                      - name: post_only
                        type: boolean
                        description: '`true` for post-only orders only'
                        required: false
                      - name: reject_post_only
                        type: boolean
                        description: >-
                          `true` if order has `reject_post_only` flag (field is
                          present only when `post_only` is `true`)
                        required: false
                      - name: reduce_only
                        type: boolean
                        description: >-
                          Optional (not added for spot). '`true` for reduce-only
                          orders only'
                        required: false
                      - name: api
                        type: boolean
                        description: '`true` if created with API'
                        required: false
                      - name: web
                        type: boolean
                        description: '`true` if created via Deribit frontend (optional)'
                        required: false
                      - name: mobile
                        type: boolean
                        description: >-
                          Optional field with value `true` added only when
                          created with Mobile Application
                        required: false
                      - name: refresh_amount
                        type: number
                        description: >-
                          The initial display amount of iceberg order. Iceberg
                          order display amount will be refreshed to that value
                          after match consuming actual display amount. Absent
                          for other types of orders
                        required: false
                      - name: display_amount
                        type: number
                        description: >-
                          The actual display amount of iceberg order. Absent for
                          other types of orders.
                        required: false
                      - name: amount
                        type: number
                        description: >-
                          It represents the requested order size. For perpetual
                          and inverse futures the amount is in USD units. For
                          options and linear futures it is the underlying base
                          currency coin.
                        required: false
                      - name: contracts
                        type: number
                        description: >-
                          It represents the order size in contract units.
                          (Optional, may be absent in historical data).
                        required: false
                      - name: filled_amount
                        type: number
                        description: >-
                          Filled amount of the order. For perpetual and futures
                          the filled_amount is in USD units, for options - in
                          units or corresponding cryptocurrency contracts, e.g.,
                          BTC or ETH.
                        required: false
                      - name: average_price
                        type: number
                        description: Average fill price of the order
                        required: false
                      - name: advanced
                        type: string
                        description: >
                          advanced type: `"usd"` or `"implv"` (Only for options;
                          field is omitted if not applicable).
                        enumValues:
                          - usd
                          - implv
                        required: false
                      - name: implv
                        type: number
                        description: >-
                          Implied volatility in percent. (Only if
                          `advanced="implv"`)
                        required: false
                      - name: usd
                        type: number
                        description: Option price in USD (Only if `advanced="usd"`)
                        required: false
                      - name: triggered
                        type: boolean
                        description: Whether the trigger order has been triggered
                        required: false
                      - name: trigger
                        type: string
                        description: >-
                          Trigger type (only for trigger orders). Allowed
                          values: `"index_price"`, `"mark_price"`,
                          `"last_price"`.
                        enumValues:
                          - index_price
                          - mark_price
                          - last_price
                        required: false
                      - name: trigger_price
                        type: number
                        description: Trigger price (Only for future trigger orders)
                        required: false
                      - name: trigger_offset
                        type: number
                        description: >-
                          The maximum deviation from the price peak beyond which
                          the order will be triggered (Only for trailing trigger
                          orders)
                        required: false
                      - name: trigger_reference_price
                        type: number
                        description: >-
                          The price of the given trigger at the time when the
                          order was placed (Only for trailing trigger orders)
                        required: false
                      - name: block_trade
                        type: boolean
                        description: >-
                          `true` if order made from block_trade trade, added
                          only in that case.
                        required: false
                      - name: mmp
                        type: boolean
                        description: '`true` if the order is a MMP order, otherwise `false`.'
                        required: false
                      - name: risk_reducing
                        type: boolean
                        description: >-
                          `true` if the order is marked by the platform as a
                          risk reducing order (can apply only to orders placed
                          by PM users), otherwise `false`.
                        required: false
                      - name: replaced
                        type: boolean
                        description: >-
                          `true` if the order was edited (by user or - in case
                          of advanced options orders - by pricing engine),
                          otherwise `false`.
                        required: false
                      - name: auto_replaced
                        type: boolean
                        description: >-
                          Options, advanced orders only - `true` if last
                          modification of the order was performed by the pricing
                          engine, otherwise `false`.
                        required: false
                      - name: quote
                        type: boolean
                        description: If order is a quote. Present only if true.
                        required: false
                      - name: mmp_group
                        type: string
                        description: >-
                          Name of the MMP group supplied in the
                          `private/mass_quote` request. Only present for quote
                          orders.
                        required: false
                      - name: quote_set_id
                        type: string
                        description: >-
                          Identifier of the QuoteSet supplied in the
                          `private/mass_quote` request. Only present for quote
                          orders.
                        required: false
                      - name: quote_id
                        type: string
                        description: >-
                          The same QuoteID as supplied in the
                          `private/mass_quote` request. Only present for quote
                          orders.
                        required: false
                      - name: trigger_order_id
                        type: string
                        description: >-
                          Id of the trigger order that created the order (Only
                          for orders that were created by triggered orders).
                        required: false
                      - name: app_name
                        type: string
                        description: >-
                          The name of the application that placed the order on
                          behalf of the user (optional).
                        required: false
                      - name: mmp_cancelled
                        type: boolean
                        description: >-
                          `true` if order was cancelled by mmp trigger
                          (optional)
                        required: false
                      - name: cancel_reason
                        type: string
                        description: >-
                          Enumerated reason behind cancel `"user_request"`,
                          `"autoliquidation"`, `"cancel_on_disconnect"`,
                          `"risk_mitigation"`, `"pme_risk_reduction"` (portfolio
                          margining risk reduction), `"pme_account_locked"`
                          (portfolio margining account locked per currency),
                          `"position_locked"`, `"mmp_trigger"` (market maker
                          protection), `"mmp_config_curtailment"` (market maker
                          configured quantity decreased),
                          `"edit_post_only_reject"` (cancelled on edit because
                          of `reject_post_only` setting), `"oco_other_closed"`
                          (the oco order linked to this order was closed),
                          `"oto_primary_closed"` (the oto primary order that was
                          going to trigger this order was cancelled),
                          `"settlement"` (closed because of a settlement)
                        enumValues:
                          - user_request
                          - autoliquidation
                          - cancel_on_disconnect
                          - risk_mitigation
                          - pme_risk_reduction
                          - pme_account_locked
                          - position_locked
                          - mmp_trigger
                          - mmp_config_curtailment
                          - edit_post_only_reject
                          - oco_other_closed
                          - oto_primary_closed
                          - settlement
                        required: false
                      - name: oto_order_ids
                        type: object
                        description: >-
                          The Ids of the orders that will be triggered if the
                          order is filled
                        required: false
                        properties: []
                      - name: trigger_fill_condition
                        type: string
                        description: >-
                          <p>The fill condition of the linked order (Only for
                          linked order types), default: `first_hit`.</p> <ul>
                          <li>`"first_hit"` - any execution of the primary order
                          will fully cancel/place all secondary orders.</li>
                          <li>`"complete_fill"` - a complete execution (meaning
                          the primary order no longer exists) will cancel/place
                          the secondary orders.</li> <li>`"incremental"` - any
                          fill of the primary order will cause proportional
                          partial cancellation/placement of the secondary order.
                          The amount that will be subtracted/added to the
                          secondary order will be rounded down to the contract
                          size.</li> </ul>
                        enumValues:
                          - first_hit
                          - complete_fill
                          - incremental
                        required: false
                      - name: oco_ref
                        type: string
                        description: >-
                          Unique reference that identifies a one_cancels_others
                          (OCO) pair.
                        required: false
                      - name: primary_order_id
                        type: string
                        description: Unique order identifier
                        required: false
                      - name: is_secondary_oto
                        type: boolean
                        description: >-
                          `true` if the order is an order that can be triggered
                          by another order, otherwise not present.
                        required: false
                      - name: is_primary_otoco
                        type: boolean
                        description: >-
                          `true` if the order is an order that can trigger an
                          OCO pair, otherwise not present.
                        required: false
                  - name: position
                    type: object
                    required: false
                    properties:
                      - name: instrument_name
                        type: string
                        description: Unique instrument identifier
                        required: false
                      - name: kind
                        type: string
                        description: >-
                          Instrument kind: `"future"`, `"option"`, `"spot"`,
                          `"future_combo"`, `"option_combo"`
                        enumValues:
                          - future
                          - option
                          - spot
                          - future_combo
                          - option_combo
                        required: false
                      - name: average_price
                        type: number
                        description: Average price of trades that built this position
                        required: false
                      - name: direction
                        type: string
                        description: 'Direction: `buy`, `sell` or `zero`'
                        enumValues:
                          - buy
                          - sell
                          - zero
                        required: false
                      - name: mark_price
                        type: number
                        description: Current mark price for position's instrument
                        required: false
                      - name: delta
                        type: number
                        description: Delta parameter
                        required: false
                      - name: gamma
                        type: number
                        description: Only for options, Gamma parameter
                        required: false
                      - name: vega
                        type: number
                        description: Only for options, Vega parameter
                        required: false
                      - name: theta
                        type: number
                        description: Only for options, Theta parameter
                        required: false
                      - name: index_price
                        type: number
                        description: Current index price
                        required: false
                      - name: initial_margin
                        type: number
                        description: Initial margin
                        required: false
                      - name: maintenance_margin
                        type: number
                        description: Maintenance margin
                        required: false
                      - name: settlement_price
                        type: number
                        description: >-
                          Optional (not added for spot). Last settlement price
                          for position's instrument 0 if instrument wasn't
                          settled yet
                        required: false
                      - name: total_profit_loss
                        type: number
                        description: Profit or loss from position
                        required: false
                      - name: floating_profit_loss
                        type: number
                        description: Floating profit or loss
                        required: false
                      - name: realized_profit_loss
                        type: number
                        description: Realized profit or loss
                        required: false
                      - name: size
                        type: number
                        description: >-
                          Position size for futures size in quote currency (e.g.
                          USD), for options size is in base currency (e.g. BTC)
                        required: false
                      - name: size_currency
                        type: number
                        description: Only for futures, position size in base currency
                        required: false
                      - name: average_price_usd
                        type: number
                        description: Only for options, average price in USD
                        required: false
                      - name: floating_profit_loss_usd
                        type: number
                        description: Only for options, floating profit or loss in USD
                        required: false
                      - name: leverage
                        type: integer
                        description: Current available leverage for future position
                        required: false
                      - name: realized_funding
                        type: number
                        description: >-
                          Realized Funding in current session included in
                          session realized profit or loss, only for positions of
                          perpetual instruments
                        required: false
                      - name: interest_value
                        type: number
                        description: >-
                          Value used to calculate `realized_funding` (perpetual
                          only)
                        required: false
        headers: []
        jsonPayloadSchema:
          type: object
          description: Response containing notification data
          properties:
            data:
              type: object
              properties:
                instrument_name:
                  type: string
                  description: Unique instrument identifier
                  example: BTC-PERPETUAL
                  x-parser-schema-id: <anonymous-schema-796>
                trades:
                  type: object
                  description: ''
                  properties:
                    trade_id:
                      type: string
                      description: Unique (per currency) trade identifier
                      x-parser-schema-id: <anonymous-schema-798>
                    trade_seq:
                      description: The sequence number of the trade within instrument
                      type: integer
                      x-parser-schema-id: <anonymous-schema-799>
                    instrument_name:
                      type: string
                      description: Unique instrument identifier
                      example: BTC-PERPETUAL
                      x-parser-schema-id: <anonymous-schema-800>
                    timestamp:
                      description: >-
                        The timestamp of the trade (milliseconds since the UNIX
                        epoch)
                      example: 1517329113791
                      type: integer
                      x-parser-schema-id: <anonymous-schema-801>
                    order_type:
                      type: string
                      description: 'Order type: `"limit`, `"market"`, or `"liquidation"`'
                      enum:
                        - limit
                        - market
                        - liquidation
                      x-parser-schema-id: <anonymous-schema-802>
                    advanced:
                      type: string
                      description: >-
                        Advanced type of user order: `"usd"` or `"implv"` (only
                        for options; omitted if not applicable)
                      enum:
                        - usd
                        - implv
                      x-parser-schema-id: <anonymous-schema-803>
                    order_id:
                      type: string
                      description: >-
                        Id of the user order (maker or taker), i.e. subscriber's
                        order id that took part in the trade
                      x-parser-schema-id: <anonymous-schema-804>
                    matching_id:
                      type: string
                      description: Always `null`
                      x-parser-schema-id: <anonymous-schema-805>
                    direction:
                      type: string
                      description: 'Direction: `buy`, or `sell`'
                      enum:
                        - buy
                        - sell
                      x-parser-schema-id: <anonymous-schema-806>
                    tick_direction:
                      type: integer
                      enum:
                        - 0
                        - 1
                        - 2
                        - 3
                      description: >-
                        Direction of the "tick" (`0` = Plus Tick, `1` =
                        Zero-Plus Tick, `2` = Minus Tick, `3` = Zero-Minus
                        Tick).
                      x-parser-schema-id: <anonymous-schema-807>
                    index_price:
                      type: number
                      description: Index Price at the moment of trade
                      x-parser-schema-id: <anonymous-schema-808>
                    price:
                      description: Price in base currency
                      type: number
                      x-parser-schema-id: <anonymous-schema-809>
                    amount:
                      type: number
                      description: >-
                        Trade amount. For perpetual and inverse futures the
                        amount is in USD units. For options and linear futures
                        it is the underlying base currency coin.
                      x-parser-schema-id: <anonymous-schema-810>
                    contracts:
                      type: number
                      description: >-
                        Trade size in contract units (optional, may be absent in
                        historical trades)
                      x-parser-schema-id: <anonymous-schema-811>
                    iv:
                      type: number
                      description: Option implied volatility for the price (Option only)
                      x-parser-schema-id: <anonymous-schema-812>
                    underlying_price:
                      type: number
                      description: >-
                        Underlying price for implied volatility calculations
                        (Options only)
                      x-parser-schema-id: <anonymous-schema-813>
                    liquidation:
                      type: string
                      description: >-
                        Optional field (only for trades caused by liquidation):
                        `"M"` when maker side of trade was under liquidation,
                        `"T"` when taker side was under liquidation, `"MT"` when
                        both sides of trade were under liquidation
                      enum:
                        - M
                        - T
                        - MT
                      x-parser-schema-id: <anonymous-schema-814>
                    liquidity:
                      type: string
                      description: >-
                        Describes what was role of users order: `"M"` when it
                        was maker order, `"T"` when it was taker order
                      enum:
                        - M
                        - T
                      x-parser-schema-id: <anonymous-schema-815>
                    fee:
                      type: number
                      description: User's fee in units of the specified `fee_currency`
                      x-parser-schema-id: <anonymous-schema-816>
                    fee_currency:
                      type: string
                      description: Currency, i.e `"BTC"`, `"ETH"`, `"USDC"`
                      enum:
                        - BTC
                        - ETH
                        - USDC
                        - USDT
                        - EURR
                      x-parser-schema-id: <anonymous-schema-817>
                    label:
                      type: string
                      description: >-
                        User defined label (presented only when previously set
                        for order by user)
                      x-parser-schema-id: <anonymous-schema-818>
                    state:
                      type: string
                      description: >-
                        Order state: `"open"`, `"filled"`, `"rejected"`,
                        `"cancelled"`, `"untriggered"` or `"archive"` (if order
                        was archived)
                      enum:
                        - open
                        - filled
                        - rejected
                        - cancelled
                        - untriggered
                        - archive
                      x-parser-schema-id: <anonymous-schema-819>
                    block_trade_id:
                      description: Block trade id - when trade was part of a block trade
                      type: string
                      example: '154'
                      x-parser-schema-id: <anonymous-schema-820>
                    block_rfq_id:
                      type: integer
                      description: >-
                        ID of the Block RFQ - when trade was part of the Block
                        RFQ
                      x-parser-schema-id: <anonymous-schema-821>
                    block_rfq_quote_id:
                      type: integer
                      description: >-
                        ID of the Block RFQ quote - when trade was part of the
                        Block RFQ
                      x-parser-schema-id: <anonymous-schema-822>
                    reduce_only:
                      type: string
                      description: '`true` if user order is reduce-only'
                      x-parser-schema-id: <anonymous-schema-823>
                    post_only:
                      type: string
                      description: '`true` if user order is post-only'
                      x-parser-schema-id: <anonymous-schema-824>
                    mmp:
                      type: boolean
                      description: '`true` if user order is MMP'
                      x-parser-schema-id: <anonymous-schema-825>
                    risk_reducing:
                      type: boolean
                      description: >-
                        `true` if user order is marked by the platform as a risk
                        reducing order (can apply only to orders placed by PM
                        users)
                      x-parser-schema-id: <anonymous-schema-826>
                    api:
                      type: boolean
                      description: '`true` if user order was created with API'
                      x-parser-schema-id: <anonymous-schema-827>
                    profit_loss:
                      type: number
                      description: Profit and loss in base currency.
                      x-parser-schema-id: <anonymous-schema-828>
                    mark_price:
                      type: number
                      description: Mark Price at the moment of trade
                      x-parser-schema-id: <anonymous-schema-829>
                    legs:
                      type: array
                      description: >-
                        Optional field containing leg trades if trade is a combo
                        trade (present when querying for **only** combo trades
                        and in `combo_trades` events)
                      x-parser-schema-id: <anonymous-schema-830>
                    combo_id:
                      type: string
                      description: >-
                        Optional field containing combo instrument name if the
                        trade is a combo trade
                      x-parser-schema-id: <anonymous-schema-831>
                    combo_trade_id:
                      type: number
                      description: >-
                        Optional field containing combo trade identifier if the
                        trade is a combo trade
                      x-parser-schema-id: <anonymous-schema-832>
                    quote_set_id:
                      type: string
                      description: >-
                        QuoteSet of the user order (optional, present only for
                        orders placed with `private/mass_quote`)
                      x-parser-schema-id: <anonymous-schema-833>
                    quote_id:
                      type: string
                      description: >-
                        QuoteID of the user order (optional, present only for
                        orders placed with `private/mass_quote`)
                      x-parser-schema-id: <anonymous-schema-834>
                    trade_allocations:
                      type: object
                      description: >-
                        List of allocations for Block RFQ pre-allocation. Each
                        allocation specifies `user_id`, `amount`, and `fee` for
                        the allocated part of the trade. For broker client
                        allocations, a `client_info` object will be included.
                      properties:
                        user_id:
                          description: >-
                            User ID to which part of the trade is allocated. For
                            brokers the User ID is obstructed.
                          type: integer
                          x-parser-schema-id: <anonymous-schema-836>
                        amount:
                          description: Amount allocated to this user.
                          type: number
                          x-parser-schema-id: <anonymous-schema-837>
                        fee:
                          description: Fee for the allocated part of the trade.
                          type: number
                          x-parser-schema-id: <anonymous-schema-838>
                        client_info:
                          description: Optional client allocation info for brokers.
                          type: object
                          properties:
                            client_id:
                              description: >-
                                ID of a client; available to broker. Represents
                                a group of users under a common name.
                              type: integer
                              x-parser-schema-id: <anonymous-schema-840>
                            client_link_id:
                              description: >-
                                ID assigned to a single user in a client;
                                available to broker.
                              type: integer
                              x-parser-schema-id: <anonymous-schema-841>
                            name:
                              description: >-
                                Name of the linked user within the client;
                                available to broker.
                              type: string
                              x-parser-schema-id: <anonymous-schema-842>
                          x-parser-schema-id: <anonymous-schema-839>
                      required:
                        - amount
                        - fee
                      additionalProperties: false
                      x-parser-schema-id: <anonymous-schema-835>
                  required:
                    - trade_id
                    - trade_seq
                    - instrument_name
                    - timestamp
                    - order_id
                    - matching_id
                    - direction
                    - tick_direction
                    - index_price
                    - price
                    - amount
                    - fee
                    - fee_currency
                    - state
                    - mark_price
                  additionalProperties: false
                  x-parser-schema-id: <anonymous-schema-797>
                orders:
                  type: object
                  description: ''
                  properties:
                    order_id:
                      description: Unique order identifier
                      type: string
                      example: ETH-100234
                      x-parser-schema-id: <anonymous-schema-844>
                    order_state:
                      type: string
                      description: >-
                        Order state: `"open"`, `"filled"`, `"rejected"`,
                        `"cancelled"`, `"untriggered"`
                      enum:
                        - open
                        - filled
                        - rejected
                        - cancelled
                        - untriggered
                        - triggered
                      x-parser-schema-id: <anonymous-schema-845>
                    order_type:
                      type: string
                      description: >-
                        Order type: `"limit"`, `"market"`, `"stop_limit"`,
                        `"stop_market"`, `"take_limit"`, `"take_market"`,
                        `"trailing_stop"`
                      enum:
                        - market
                        - limit
                        - stop_market
                        - stop_limit
                        - take_market
                        - take_limit
                        - trailing_stop
                      x-parser-schema-id: <anonymous-schema-846>
                    original_order_type:
                      type: string
                      description: Original order type. Optional field
                      enum:
                        - market
                        - market_limit
                      x-parser-schema-id: <anonymous-schema-847>
                    time_in_force:
                      type: string
                      description: >-
                        Order time in force: `"good_til_cancelled"`,
                        `"good_til_day"`, `"fill_or_kill"` or
                        `"immediate_or_cancel"`
                      enum:
                        - good_til_cancelled
                        - good_til_day
                        - fill_or_kill
                        - immediate_or_cancel
                      x-parser-schema-id: <anonymous-schema-848>
                    is_rebalance:
                      type: boolean
                      description: >-
                        Optional (only for spot). `true` if order was
                        automatically created during cross-collateral balance
                        restoration
                      x-parser-schema-id: <anonymous-schema-849>
                    is_liquidation:
                      type: boolean
                      description: >-
                        Optional (not added for spot). `true` if order was
                        automatically created during liquidation
                      x-parser-schema-id: <anonymous-schema-850>
                    instrument_name:
                      type: string
                      description: Unique instrument identifier
                      example: BTC-PERPETUAL
                      x-parser-schema-id: <anonymous-schema-851>
                    creation_timestamp:
                      type: integer
                      example: 1536569522277
                      description: The timestamp (milliseconds since the Unix epoch)
                      x-parser-schema-id: <anonymous-schema-852>
                    last_update_timestamp:
                      type: integer
                      example: 1536569522277
                      description: The timestamp (milliseconds since the Unix epoch)
                      x-parser-schema-id: <anonymous-schema-853>
                    direction:
                      type: string
                      description: 'Direction: `buy`, or `sell`'
                      enum:
                        - buy
                        - sell
                      x-parser-schema-id: <anonymous-schema-854>
                    price:
                      description: >-
                        Price in base currency or "market_price" in case of open
                        trigger market orders
                      x-parser-schema-id: <anonymous-schema-855>
                    label:
                      type: string
                      description: User defined label (up to 64 characters)
                      x-parser-schema-id: <anonymous-schema-856>
                    post_only:
                      type: boolean
                      description: '`true` for post-only orders only'
                      x-parser-schema-id: <anonymous-schema-857>
                    reject_post_only:
                      description: >-
                        `true` if order has `reject_post_only` flag (field is
                        present only when `post_only` is `true`)
                      type: boolean
                      x-parser-schema-id: <anonymous-schema-858>
                    reduce_only:
                      type: boolean
                      description: >-
                        Optional (not added for spot). '`true` for reduce-only
                        orders only'
                      x-parser-schema-id: <anonymous-schema-859>
                    api:
                      type: boolean
                      description: '`true` if created with API'
                      x-parser-schema-id: <anonymous-schema-860>
                    web:
                      type: boolean
                      description: '`true` if created via Deribit frontend (optional)'
                      x-parser-schema-id: <anonymous-schema-861>
                    mobile:
                      type: boolean
                      description: >-
                        Optional field with value `true` added only when created
                        with Mobile Application
                      x-parser-schema-id: <anonymous-schema-862>
                    refresh_amount:
                      type: number
                      description: >-
                        The initial display amount of iceberg order. Iceberg
                        order display amount will be refreshed to that value
                        after match consuming actual display amount. Absent for
                        other types of orders
                      x-parser-schema-id: <anonymous-schema-863>
                    display_amount:
                      type: number
                      description: >-
                        The actual display amount of iceberg order. Absent for
                        other types of orders.
                      x-parser-schema-id: <anonymous-schema-864>
                    amount:
                      type: number
                      description: >-
                        It represents the requested order size. For perpetual
                        and inverse futures the amount is in USD units. For
                        options and linear futures it is the underlying base
                        currency coin.
                      x-parser-schema-id: <anonymous-schema-865>
                    contracts:
                      type: number
                      description: >-
                        It represents the order size in contract units.
                        (Optional, may be absent in historical data).
                      x-parser-schema-id: <anonymous-schema-866>
                    filled_amount:
                      type: number
                      description: >-
                        Filled amount of the order. For perpetual and futures
                        the filled_amount is in USD units, for options - in
                        units or corresponding cryptocurrency contracts, e.g.,
                        BTC or ETH.
                      x-parser-schema-id: <anonymous-schema-867>
                    average_price:
                      type: number
                      description: Average fill price of the order
                      x-parser-schema-id: <anonymous-schema-868>
                    advanced:
                      type: string
                      description: >
                        advanced type: `"usd"` or `"implv"` (Only for options;
                        field is omitted if not applicable).
                      enum:
                        - usd
                        - implv
                      x-parser-schema-id: <anonymous-schema-869>
                    implv:
                      type: number
                      description: >-
                        Implied volatility in percent. (Only if
                        `advanced="implv"`)
                      x-parser-schema-id: <anonymous-schema-870>
                    usd:
                      type: number
                      description: Option price in USD (Only if `advanced="usd"`)
                      x-parser-schema-id: <anonymous-schema-871>
                    triggered:
                      type: boolean
                      description: Whether the trigger order has been triggered
                      x-parser-schema-id: <anonymous-schema-872>
                    trigger:
                      type: string
                      description: >-
                        Trigger type (only for trigger orders). Allowed values:
                        `"index_price"`, `"mark_price"`, `"last_price"`.
                      enum:
                        - index_price
                        - mark_price
                        - last_price
                      x-parser-schema-id: <anonymous-schema-873>
                    trigger_price:
                      type: number
                      description: Trigger price (Only for future trigger orders)
                      x-parser-schema-id: <anonymous-schema-874>
                    trigger_offset:
                      type: number
                      description: >-
                        The maximum deviation from the price peak beyond which
                        the order will be triggered (Only for trailing trigger
                        orders)
                      x-parser-schema-id: <anonymous-schema-875>
                    trigger_reference_price:
                      type: number
                      description: >-
                        The price of the given trigger at the time when the
                        order was placed (Only for trailing trigger orders)
                      x-parser-schema-id: <anonymous-schema-876>
                    block_trade:
                      description: >-
                        `true` if order made from block_trade trade, added only
                        in that case.
                      type: boolean
                      example: true
                      x-parser-schema-id: <anonymous-schema-877>
                    mmp:
                      type: boolean
                      description: '`true` if the order is a MMP order, otherwise `false`.'
                      x-parser-schema-id: <anonymous-schema-878>
                    risk_reducing:
                      type: boolean
                      description: >-
                        `true` if the order is marked by the platform as a risk
                        reducing order (can apply only to orders placed by PM
                        users), otherwise `false`.
                      x-parser-schema-id: <anonymous-schema-879>
                    replaced:
                      type: boolean
                      description: >-
                        `true` if the order was edited (by user or - in case of
                        advanced options orders - by pricing engine), otherwise
                        `false`.
                      x-parser-schema-id: <anonymous-schema-880>
                    auto_replaced:
                      type: boolean
                      description: >-
                        Options, advanced orders only - `true` if last
                        modification of the order was performed by the pricing
                        engine, otherwise `false`.
                      x-parser-schema-id: <anonymous-schema-881>
                    quote:
                      type: boolean
                      description: If order is a quote. Present only if true.
                      x-parser-schema-id: <anonymous-schema-882>
                    mmp_group:
                      type: string
                      description: >-
                        Name of the MMP group supplied in the
                        `private/mass_quote` request. Only present for quote
                        orders.
                      x-parser-schema-id: <anonymous-schema-883>
                    quote_set_id:
                      type: string
                      description: >-
                        Identifier of the QuoteSet supplied in the
                        `private/mass_quote` request. Only present for quote
                        orders.
                      x-parser-schema-id: <anonymous-schema-884>
                    quote_id:
                      type: string
                      description: >-
                        The same QuoteID as supplied in the `private/mass_quote`
                        request. Only present for quote orders.
                      x-parser-schema-id: <anonymous-schema-885>
                    trigger_order_id:
                      type: string
                      description: >-
                        Id of the trigger order that created the order (Only for
                        orders that were created by triggered orders).
                      example: SLIB-370
                      x-parser-schema-id: <anonymous-schema-886>
                    app_name:
                      type: string
                      description: >-
                        The name of the application that placed the order on
                        behalf of the user (optional).
                      example: Example Application
                      x-parser-schema-id: <anonymous-schema-887>
                    mmp_cancelled:
                      type: boolean
                      description: '`true` if order was cancelled by mmp trigger (optional)'
                      example: true
                      x-parser-schema-id: <anonymous-schema-888>
                    cancel_reason:
                      type: string
                      description: >-
                        Enumerated reason behind cancel `"user_request"`,
                        `"autoliquidation"`, `"cancel_on_disconnect"`,
                        `"risk_mitigation"`, `"pme_risk_reduction"` (portfolio
                        margining risk reduction), `"pme_account_locked"`
                        (portfolio margining account locked per currency),
                        `"position_locked"`, `"mmp_trigger"` (market maker
                        protection), `"mmp_config_curtailment"` (market maker
                        configured quantity decreased),
                        `"edit_post_only_reject"` (cancelled on edit because of
                        `reject_post_only` setting), `"oco_other_closed"` (the
                        oco order linked to this order was closed),
                        `"oto_primary_closed"` (the oto primary order that was
                        going to trigger this order was cancelled),
                        `"settlement"` (closed because of a settlement)
                      enum:
                        - user_request
                        - autoliquidation
                        - cancel_on_disconnect
                        - risk_mitigation
                        - pme_risk_reduction
                        - pme_account_locked
                        - position_locked
                        - mmp_trigger
                        - mmp_config_curtailment
                        - edit_post_only_reject
                        - oco_other_closed
                        - oto_primary_closed
                        - settlement
                      x-parser-schema-id: <anonymous-schema-889>
                    oto_order_ids:
                      type: object
                      description: >-
                        The Ids of the orders that will be triggered if the
                        order is filled
                      properties: {}
                      additionalProperties: true
                      x-parser-schema-id: <anonymous-schema-890>
                    trigger_fill_condition:
                      description: >-
                        <p>The fill condition of the linked order (Only for
                        linked order types), default: `first_hit`.</p> <ul>
                        <li>`"first_hit"` - any execution of the primary order
                        will fully cancel/place all secondary orders.</li>
                        <li>`"complete_fill"` - a complete execution (meaning
                        the primary order no longer exists) will cancel/place
                        the secondary orders.</li> <li>`"incremental"` - any
                        fill of the primary order will cause proportional
                        partial cancellation/placement of the secondary order.
                        The amount that will be subtracted/added to the
                        secondary order will be rounded down to the contract
                        size.</li> </ul>
                      type: string
                      enum:
                        - first_hit
                        - complete_fill
                        - incremental
                      x-parser-schema-id: <anonymous-schema-891>
                    oco_ref:
                      type: string
                      description: >-
                        Unique reference that identifies a one_cancels_others
                        (OCO) pair.
                      x-parser-schema-id: <anonymous-schema-892>
                    primary_order_id:
                      description: Unique order identifier
                      type: string
                      example: ETH-100234
                      x-parser-schema-id: <anonymous-schema-893>
                    is_secondary_oto:
                      type: boolean
                      description: >-
                        `true` if the order is an order that can be triggered by
                        another order, otherwise not present.
                      x-parser-schema-id: <anonymous-schema-894>
                    is_primary_otoco:
                      type: boolean
                      description: >-
                        `true` if the order is an order that can trigger an OCO
                        pair, otherwise not present.
                      x-parser-schema-id: <anonymous-schema-895>
                  required:
                    - order_id
                    - order_state
                    - order_type
                    - time_in_force
                    - instrument_name
                    - creation_timestamp
                    - last_update_timestamp
                    - direction
                    - price
                    - label
                    - post_only
                    - api
                  additionalProperties: false
                  x-parser-schema-id: <anonymous-schema-843>
                position:
                  type: object
                  description: ''
                  properties:
                    instrument_name:
                      type: string
                      description: Unique instrument identifier
                      example: BTC-PERPETUAL
                      x-parser-schema-id: <anonymous-schema-897>
                    kind:
                      type: string
                      description: >-
                        Instrument kind: `"future"`, `"option"`, `"spot"`,
                        `"future_combo"`, `"option_combo"`
                      enum:
                        - future
                        - option
                        - spot
                        - future_combo
                        - option_combo
                      x-parser-schema-id: <anonymous-schema-898>
                    average_price:
                      type: number
                      description: Average price of trades that built this position
                      x-parser-schema-id: <anonymous-schema-899>
                    direction:
                      type: string
                      description: 'Direction: `buy`, `sell` or `zero`'
                      enum:
                        - buy
                        - sell
                        - zero
                      x-parser-schema-id: <anonymous-schema-900>
                    mark_price:
                      type: number
                      description: Current mark price for position's instrument
                      x-parser-schema-id: <anonymous-schema-901>
                    delta:
                      type: number
                      description: Delta parameter
                      x-parser-schema-id: <anonymous-schema-902>
                    gamma:
                      type: number
                      description: Only for options, Gamma parameter
                      x-parser-schema-id: <anonymous-schema-903>
                    vega:
                      type: number
                      description: Only for options, Vega parameter
                      x-parser-schema-id: <anonymous-schema-904>
                    theta:
                      type: number
                      description: Only for options, Theta parameter
                      x-parser-schema-id: <anonymous-schema-905>
                    index_price:
                      type: number
                      description: Current index price
                      x-parser-schema-id: <anonymous-schema-906>
                    initial_margin:
                      type: number
                      description: Initial margin
                      x-parser-schema-id: <anonymous-schema-907>
                    maintenance_margin:
                      type: number
                      description: Maintenance margin
                      x-parser-schema-id: <anonymous-schema-908>
                    settlement_price:
                      type: number
                      description: >-
                        Optional (not added for spot). Last settlement price for
                        position's instrument 0 if instrument wasn't settled yet
                      x-parser-schema-id: <anonymous-schema-909>
                    total_profit_loss:
                      type: number
                      description: Profit or loss from position
                      x-parser-schema-id: <anonymous-schema-910>
                    floating_profit_loss:
                      type: number
                      description: Floating profit or loss
                      x-parser-schema-id: <anonymous-schema-911>
                    realized_profit_loss:
                      type: number
                      description: Realized profit or loss
                      x-parser-schema-id: <anonymous-schema-912>
                    size:
                      type: number
                      description: >-
                        Position size for futures size in quote currency (e.g.
                        USD), for options size is in base currency (e.g. BTC)
                      x-parser-schema-id: <anonymous-schema-913>
                    size_currency:
                      type: number
                      description: Only for futures, position size in base currency
                      x-parser-schema-id: <anonymous-schema-914>
                    average_price_usd:
                      type: number
                      description: Only for options, average price in USD
                      x-parser-schema-id: <anonymous-schema-915>
                    floating_profit_loss_usd:
                      type: number
                      description: Only for options, floating profit or loss in USD
                      x-parser-schema-id: <anonymous-schema-916>
                    leverage:
                      type: integer
                      description: Current available leverage for future position
                      x-parser-schema-id: <anonymous-schema-917>
                    realized_funding:
                      type: number
                      description: >-
                        Realized Funding in current session included in session
                        realized profit or loss, only for positions of perpetual
                        instruments
                      x-parser-schema-id: <anonymous-schema-918>
                    interest_value:
                      type: number
                      description: >-
                        Value used to calculate `realized_funding` (perpetual
                        only)
                      x-parser-schema-id: <anonymous-schema-919>
                  required:
                    - instrument_name
                    - kind
                    - average_price
                    - direction
                    - mark_price
                    - delta
                    - index_price
                    - initial_margin
                    - maintenance_margin
                    - settlement_price
                    - total_profit_loss
                    - floating_profit_loss
                    - realized_profit_loss
                    - size
                  additionalProperties: false
                  x-parser-schema-id: <anonymous-schema-896>
              required: []
              additionalProperties: false
              x-parser-schema-id: <anonymous-schema-795>
          required:
            - data
          additionalProperties: false
          x-parser-schema-id: <anonymous-schema-794>
        title: Subscription Notification Data
        description: Server sends subscription notification data
        example: |-
          {
            "data": {
              "trades": [
                {
                  "trade_seq": 866638,
                  "trade_id": "1430914",
                  "timestamp": 1605780344032,
                  "tick_direction": 1,
                  "state": "filled",
                  "reduce_only": false,
                  "profit_loss": 0.00004898,
                  "price": 17391,
                  "post_only": false,
                  "order_type": "market",
                  "order_id": "3398016",
                  "matching_id": null,
                  "mark_price": 17391,
                  "liquidity": "T",
                  "instrument_name": "BTC-PERPETUAL",
                  "index_price": 17501.88,
                  "fee_currency": "BTC",
                  "fee": 1.6e-7,
                  "direction": "sell",
                  "amount": 10
                }
              ],
              "positions": [
                {
                  "total_profit_loss": 1.69711368,
                  "size_currency": 10.646886321,
                  "size": 185160,
                  "settlement_price": 16025.83,
                  "realized_profit_loss": 0.012454598,
                  "realized_funding": 0.01235663,
                  "mark_price": 17391,
                  "maintenance_margin": 0.234575865,
                  "leverage": 33,
                  "kind": "future",
                  "interest_value": 1.7362511643080387,
                  "instrument_name": "BTC-PERPETUAL",
                  "initial_margin": 0.319750953,
                  "index_price": 17501.88,
                  "floating_profit_loss": 0.906961435,
                  "direction": "buy",
                  "delta": 10.646886321,
                  "average_price": 15000
                }
              ],
              "orders": [
                {
                  "web": true,
                  "time_in_force": "good_til_cancelled",
                  "replaced": false,
                  "reduce_only": false,
                  "price": 15665.5,
                  "post_only": false,
                  "order_type": "market",
                  "order_state": "filled",
                  "order_id": "3398016",
                  "max_show": 10,
                  "last_update_timestamp": 1605780344032,
                  "label": "",
                  "is_rebalance": false,
                  "is_liquidation": false,
                  "instrument_name": "BTC-PERPETUAL",
                  "filled_amount": 10,
                  "direction": "sell",
                  "creation_timestamp": 1605780344032,
                  "average_price": 17391,
                  "api": false,
                  "amount": 10
                }
              ],
              "instrument_name": "BTC-PERPETUAL"
            }
          }
        bindings: []
        extensions:
          - id: x-parser-unique-object-id
            value: subscription_message
    bindings: []
    extensions: &ref_0
      - id: x-parser-unique-object-id
        value: user.changes.(instrument_name).(interval)
  - &ref_1
    id: receive_user_changes_instrument_name_interval_updates
    title: Receive user updates
    description: Client receives user update notifications
    type: receive
    messages:
      - &ref_3
        id: subscribe_request
        contentType: application/json
        payload:
          - name: Subscription Request
            description: >-
              Client sends subscription request to subscribe to notification
              channel. Please refer to [Notification
              page](https://deribit.mintlify.app/articles/notifications) for
              more information.
            type: object
            properties: []
        headers: []
        jsonPayloadSchema:
          properties: {}
          additionalProperties: false
          x-parser-schema-id: <anonymous-schema-793>
        title: Subscription Request
        description: >-
          Client sends subscription request to subscribe to notification
          channel. Please refer to [Notification
          page](https://deribit.mintlify.app/articles/notifications) for more
          information.
        example: |-
          {
            "jsonrpc": "2.0",
            "method": "public/subscribe",
            "id": 42,
            "params": {
              "channels": [
                "user.changes.BTC-PERPETUAL.100ms"
              ]
            }
          }
        bindings: []
        extensions:
          - id: x-parser-unique-object-id
            value: subscribe_request
    bindings: []
    extensions: *ref_0
sendOperations:
  - *ref_1
receiveOperations:
  - *ref_2
sendMessages:
  - *ref_3
receiveMessages:
  - *ref_4
extensions:
  - id: x-parser-unique-object-id
    value: user.changes.(instrument_name).(interval)
securitySchemes: []

````

> ## Documentation Index
> Fetch the complete documentation index at: https://docs.deribit.com/llms.txt
> Use this file to discover all available pages before exploring further.

<AgentInstructions>

## Submitting Feedback

If you encounter incorrect, outdated, or confusing documentation on this page, submit feedback:

POST https://docs.deribit.com/feedback

```json
{
  "path": "/subscriptions/user/userchangeskindcurrencyinterval",
  "feedback": "Description of the issue"
}
```

Only submit feedback when you have something specific and actionable to report.

</AgentInstructions>

# user.changes.(kind).(currency).(interval) 

> User change stream (orders, trades, and related updates) across all instruments for a given kind and currency.

This channel provides a consolidated private update stream for your account across all matching instruments. Use it when you want a single feed instead of subscribing to orders and trades separately.




## AsyncAPI

````yaml specifications/deribit_asyncapi.json user.changes.(kind).(currency).(interval)
id: user.changes.(kind).(currency).(interval)
title: 'user.changes.(kind).(currency).(interval) '
description: >
  User change stream (orders, trades, and related updates) across all
  instruments for a given kind and currency.


  This channel provides a consolidated private update stream for your account
  across all matching instruments. Use it when you want a single feed instead of
  subscribing to orders and trades separately.
servers:
  - id: production
    protocol: wss
    host: deribit.com/ws/api/v2
    bindings: []
    variables: []
  - id: testnet
    protocol: wss
    host: test.deribit.com/ws/api/v2
    bindings: []
    variables: []
address: user.changes.(kind).(currency).(interval)
parameters:
  - id: kind
    jsonSchema:
      type: string
      description: >-
        Instrument kind


        **Allowed values:** `future`, `option`, `spot`, `future_combo`,
        `option_combo`
      enum:
        - future
        - option
        - spot
        - future_combo
        - option_combo
    description: >-
      Instrument kind


      **Allowed values:** `future`, `option`, `spot`, `future_combo`,
      `option_combo`
    type: string
    required: true
    deprecated: false
  - id: currency
    jsonSchema:
      type: string
      description: |-
        Currency code or `any` for all

        **Allowed values:** `BTC`, `ETH`, `USDC`, `USDT`, `EURR`, `any`
      enum:
        - BTC
        - ETH
        - USDC
        - USDT
        - EURR
        - any
    description: |-
      Currency code or `any` for all

      **Allowed values:** `BTC`, `ETH`, `USDC`, `USDT`, `EURR`, `any`
    type: string
    required: true
    deprecated: false
  - id: interval
    jsonSchema:
      type: string
      description: >-
        Frequency of notifications. Events will be aggregated over this
        interval. The value `raw` means no aggregation will be applied **(Please
        note that `raw` interval is only available to authorized users)**


        **Allowed values:** `raw`, `100ms`, `agg2`
      enum:
        - raw
        - 100ms
        - agg2
    description: >-
      Frequency of notifications. Events will be aggregated over this interval.
      The value `raw` means no aggregation will be applied **(Please note that
      `raw` interval is only available to authorized users)**


      **Allowed values:** `raw`, `100ms`, `agg2`
    type: string
    required: true
    deprecated: false
bindings: []
operations:
  - &ref_2
    id: send_subscribe_user_changes_kind_currency_interval
    title: Send subscribe request for user
    description: Client sends subscription request for user updates
    type: send
    messages:
      - &ref_4
        id: subscription_message
        contentType: application/json
        payload:
          - name: Subscription Notification Data
            description: Server sends subscription notification data
            type: object
            properties:
              - name: data
                type: object
                required: true
                properties:
                  - name: instrument_name
                    type: string
                    description: Unique instrument identifier
                    required: false
                  - name: trades
                    type: object
                    required: false
                    properties:
                      - name: trade_id
                        type: string
                        description: Unique (per currency) trade identifier
                        required: false
                      - name: trade_seq
                        type: integer
                        description: The sequence number of the trade within instrument
                        required: false
                      - name: instrument_name
                        type: string
                        description: Unique instrument identifier
                        required: false
                      - name: timestamp
                        type: integer
                        description: >-
                          The timestamp of the trade (milliseconds since the
                          UNIX epoch)
                        required: false
                      - name: order_type
                        type: string
                        description: 'Order type: `"limit`, `"market"`, or `"liquidation"`'
                        enumValues:
                          - limit
                          - market
                          - liquidation
                        required: false
                      - name: advanced
                        type: string
                        description: >-
                          Advanced type of user order: `"usd"` or `"implv"`
                          (only for options; omitted if not applicable)
                        enumValues:
                          - usd
                          - implv
                        required: false
                      - name: order_id
                        type: string
                        description: >-
                          Id of the user order (maker or taker), i.e.
                          subscriber's order id that took part in the trade
                        required: false
                      - name: matching_id
                        type: string
                        description: Always `null`
                        required: false
                      - name: direction
                        type: string
                        description: 'Direction: `buy`, or `sell`'
                        enumValues:
                          - buy
                          - sell
                        required: false
                      - name: tick_direction
                        type: integer
                        description: >-
                          Direction of the "tick" (`0` = Plus Tick, `1` =
                          Zero-Plus Tick, `2` = Minus Tick, `3` = Zero-Minus
                          Tick).
                        enumValues:
                          - 0
                          - 1
                          - 2
                          - 3
                        required: false
                      - name: index_price
                        type: number
                        description: Index Price at the moment of trade
                        required: false
                      - name: price
                        type: number
                        description: Price in base currency
                        required: false
                      - name: amount
                        type: number
                        description: >-
                          Trade amount. For perpetual and inverse futures the
                          amount is in USD units. For options and linear futures
                          it is the underlying base currency coin.
                        required: false
                      - name: contracts
                        type: number
                        description: >-
                          Trade size in contract units (optional, may be absent
                          in historical trades)
                        required: false
                      - name: iv
                        type: number
                        description: Option implied volatility for the price (Option only)
                        required: false
                      - name: underlying_price
                        type: number
                        description: >-
                          Underlying price for implied volatility calculations
                          (Options only)
                        required: false
                      - name: liquidation
                        type: string
                        description: >-
                          Optional field (only for trades caused by
                          liquidation): `"M"` when maker side of trade was under
                          liquidation, `"T"` when taker side was under
                          liquidation, `"MT"` when both sides of trade were
                          under liquidation
                        enumValues:
                          - M
                          - T
                          - MT
                        required: false
                      - name: liquidity
                        type: string
                        description: >-
                          Describes what was role of users order: `"M"` when it
                          was maker order, `"T"` when it was taker order
                        enumValues:
                          - M
                          - T
                        required: false
                      - name: fee
                        type: number
                        description: User's fee in units of the specified `fee_currency`
                        required: false
                      - name: fee_currency
                        type: string
                        description: Currency, i.e `"BTC"`, `"ETH"`, `"USDC"`
                        enumValues:
                          - BTC
                          - ETH
                          - USDC
                          - USDT
                          - EURR
                        required: false
                      - name: label
                        type: string
                        description: >-
                          User defined label (presented only when previously set
                          for order by user)
                        required: false
                      - name: state
                        type: string
                        description: >-
                          Order state: `"open"`, `"filled"`, `"rejected"`,
                          `"cancelled"`, `"untriggered"` or `"archive"` (if
                          order was archived)
                        enumValues:
                          - open
                          - filled
                          - rejected
                          - cancelled
                          - untriggered
                          - archive
                        required: false
                      - name: block_trade_id
                        type: string
                        description: Block trade id - when trade was part of a block trade
                        required: false
                      - name: block_rfq_id
                        type: integer
                        description: >-
                          ID of the Block RFQ - when trade was part of the Block
                          RFQ
                        required: false
                      - name: block_rfq_quote_id
                        type: integer
                        description: >-
                          ID of the Block RFQ quote - when trade was part of the
                          Block RFQ
                        required: false
                      - name: reduce_only
                        type: string
                        description: '`true` if user order is reduce-only'
                        required: false
                      - name: post_only
                        type: string
                        description: '`true` if user order is post-only'
                        required: false
                      - name: mmp
                        type: boolean
                        description: '`true` if user order is MMP'
                        required: false
                      - name: risk_reducing
                        type: boolean
                        description: >-
                          `true` if user order is marked by the platform as a
                          risk reducing order (can apply only to orders placed
                          by PM users)
                        required: false
                      - name: api
                        type: boolean
                        description: '`true` if user order was created with API'
                        required: false
                      - name: profit_loss
                        type: number
                        description: Profit and loss in base currency.
                        required: false
                      - name: mark_price
                        type: number
                        description: Mark Price at the moment of trade
                        required: false
                      - name: legs
                        type: array
                        description: >-
                          Optional field containing leg trades if trade is a
                          combo trade (present when querying for **only** combo
                          trades and in `combo_trades` events)
                        required: false
                      - name: combo_id
                        type: string
                        description: >-
                          Optional field containing combo instrument name if the
                          trade is a combo trade
                        required: false
                      - name: combo_trade_id
                        type: number
                        description: >-
                          Optional field containing combo trade identifier if
                          the trade is a combo trade
                        required: false
                      - name: quote_set_id
                        type: string
                        description: >-
                          QuoteSet of the user order (optional, present only for
                          orders placed with `private/mass_quote`)
                        required: false
                      - name: quote_id
                        type: string
                        description: >-
                          QuoteID of the user order (optional, present only for
                          orders placed with `private/mass_quote`)
                        required: false
                      - name: trade_allocations
                        type: object
                        description: >-
                          List of allocations for Block RFQ pre-allocation. Each
                          allocation specifies `user_id`, `amount`, and `fee`
                          for the allocated part of the trade. For broker client
                          allocations, a `client_info` object will be included.
                        required: false
                        properties:
                          - name: user_id
                            type: integer
                            description: >-
                              User ID to which part of the trade is allocated.
                              For brokers the User ID is obstructed.
                            required: false
                          - name: amount
                            type: number
                            description: Amount allocated to this user.
                            required: false
                          - name: fee
                            type: number
                            description: Fee for the allocated part of the trade.
                            required: false
                          - name: client_info
                            type: object
                            description: Optional client allocation info for brokers.
                            required: false
                            properties:
                              - name: client_id
                                type: integer
                                description: >-
                                  ID of a client; available to broker.
                                  Represents a group of users under a common
                                  name.
                                required: false
                              - name: client_link_id
                                type: integer
                                description: >-
                                  ID assigned to a single user in a client;
                                  available to broker.
                                required: false
                              - name: name
                                type: string
                                description: >-
                                  Name of the linked user within the client;
                                  available to broker.
                                required: false
                  - name: orders
                    type: object
                    required: false
                    properties:
                      - name: order_id
                        type: string
                        description: Unique order identifier
                        required: false
                      - name: order_state
                        type: string
                        description: >-
                          Order state: `"open"`, `"filled"`, `"rejected"`,
                          `"cancelled"`, `"untriggered"`
                        enumValues:
                          - open
                          - filled
                          - rejected
                          - cancelled
                          - untriggered
                          - triggered
                        required: false
                      - name: order_type
                        type: string
                        description: >-
                          Order type: `"limit"`, `"market"`, `"stop_limit"`,
                          `"stop_market"`, `"take_limit"`, `"take_market"`,
                          `"trailing_stop"`
                        enumValues:
                          - market
                          - limit
                          - stop_market
                          - stop_limit
                          - take_market
                          - take_limit
                          - trailing_stop
                        required: false
                      - name: original_order_type
                        type: string
                        description: Original order type. Optional field
                        enumValues:
                          - market
                          - market_limit
                        required: false
                      - name: time_in_force
                        type: string
                        description: >-
                          Order time in force: `"good_til_cancelled"`,
                          `"good_til_day"`, `"fill_or_kill"` or
                          `"immediate_or_cancel"`
                        enumValues:
                          - good_til_cancelled
                          - good_til_day
                          - fill_or_kill
                          - immediate_or_cancel
                        required: false
                      - name: is_rebalance
                        type: boolean
                        description: >-
                          Optional (only for spot). `true` if order was
                          automatically created during cross-collateral balance
                          restoration
                        required: false
                      - name: is_liquidation
                        type: boolean
                        description: >-
                          Optional (not added for spot). `true` if order was
                          automatically created during liquidation
                        required: false
                      - name: instrument_name
                        type: string
                        description: Unique instrument identifier
                        required: false
                      - name: creation_timestamp
                        type: integer
                        description: The timestamp (milliseconds since the Unix epoch)
                        required: false
                      - name: last_update_timestamp
                        type: integer
                        description: The timestamp (milliseconds since the Unix epoch)
                        required: false
                      - name: direction
                        type: string
                        description: 'Direction: `buy`, or `sell`'
                        enumValues:
                          - buy
                          - sell
                        required: false
                      - name: description
                        type: string
                        description: >-
                          Price in base currency or "market_price" in case of
                          open trigger market orders
                        required: false
                      - name: label
                        type: string
                        description: User defined label (up to 64 characters)
                        required: false
                      - name: post_only
                        type: boolean
                        description: '`true` for post-only orders only'
                        required: false
                      - name: reject_post_only
                        type: boolean
                        description: >-
                          `true` if order has `reject_post_only` flag (field is
                          present only when `post_only` is `true`)
                        required: false
                      - name: reduce_only
                        type: boolean
                        description: >-
                          Optional (not added for spot). '`true` for reduce-only
                          orders only'
                        required: false
                      - name: api
                        type: boolean
                        description: '`true` if created with API'
                        required: false
                      - name: web
                        type: boolean
                        description: '`true` if created via Deribit frontend (optional)'
                        required: false
                      - name: mobile
                        type: boolean
                        description: >-
                          Optional field with value `true` added only when
                          created with Mobile Application
                        required: false
                      - name: refresh_amount
                        type: number
                        description: >-
                          The initial display amount of iceberg order. Iceberg
                          order display amount will be refreshed to that value
                          after match consuming actual display amount. Absent
                          for other types of orders
                        required: false
                      - name: display_amount
                        type: number
                        description: >-
                          The actual display amount of iceberg order. Absent for
                          other types of orders.
                        required: false
                      - name: amount
                        type: number
                        description: >-
                          It represents the requested order size. For perpetual
                          and inverse futures the amount is in USD units. For
                          options and linear futures it is the underlying base
                          currency coin.
                        required: false
                      - name: contracts
                        type: number
                        description: >-
                          It represents the order size in contract units.
                          (Optional, may be absent in historical data).
                        required: false
                      - name: filled_amount
                        type: number
                        description: >-
                          Filled amount of the order. For perpetual and futures
                          the filled_amount is in USD units, for options - in
                          units or corresponding cryptocurrency contracts, e.g.,
                          BTC or ETH.
                        required: false
                      - name: average_price
                        type: number
                        description: Average fill price of the order
                        required: false
                      - name: advanced
                        type: string
                        description: >
                          advanced type: `"usd"` or `"implv"` (Only for options;
                          field is omitted if not applicable).
                        enumValues:
                          - usd
                          - implv
                        required: false
                      - name: implv
                        type: number
                        description: >-
                          Implied volatility in percent. (Only if
                          `advanced="implv"`)
                        required: false
                      - name: usd
                        type: number
                        description: Option price in USD (Only if `advanced="usd"`)
                        required: false
                      - name: triggered
                        type: boolean
                        description: Whether the trigger order has been triggered
                        required: false
                      - name: trigger
                        type: string
                        description: >-
                          Trigger type (only for trigger orders). Allowed
                          values: `"index_price"`, `"mark_price"`,
                          `"last_price"`.
                        enumValues:
                          - index_price
                          - mark_price
                          - last_price
                        required: false
                      - name: trigger_price
                        type: number
                        description: Trigger price (Only for future trigger orders)
                        required: false
                      - name: trigger_offset
                        type: number
                        description: >-
                          The maximum deviation from the price peak beyond which
                          the order will be triggered (Only for trailing trigger
                          orders)
                        required: false
                      - name: trigger_reference_price
                        type: number
                        description: >-
                          The price of the given trigger at the time when the
                          order was placed (Only for trailing trigger orders)
                        required: false
                      - name: block_trade
                        type: boolean
                        description: >-
                          `true` if order made from block_trade trade, added
                          only in that case.
                        required: false
                      - name: mmp
                        type: boolean
                        description: '`true` if the order is a MMP order, otherwise `false`.'
                        required: false
                      - name: risk_reducing
                        type: boolean
                        description: >-
                          `true` if the order is marked by the platform as a
                          risk reducing order (can apply only to orders placed
                          by PM users), otherwise `false`.
                        required: false
                      - name: replaced
                        type: boolean
                        description: >-
                          `true` if the order was edited (by user or - in case
                          of advanced options orders - by pricing engine),
                          otherwise `false`.
                        required: false
                      - name: auto_replaced
                        type: boolean
                        description: >-
                          Options, advanced orders only - `true` if last
                          modification of the order was performed by the pricing
                          engine, otherwise `false`.
                        required: false
                      - name: quote
                        type: boolean
                        description: If order is a quote. Present only if true.
                        required: false
                      - name: mmp_group
                        type: string
                        description: >-
                          Name of the MMP group supplied in the
                          `private/mass_quote` request. Only present for quote
                          orders.
                        required: false
                      - name: quote_set_id
                        type: string
                        description: >-
                          Identifier of the QuoteSet supplied in the
                          `private/mass_quote` request. Only present for quote
                          orders.
                        required: false
                      - name: quote_id
                        type: string
                        description: >-
                          The same QuoteID as supplied in the
                          `private/mass_quote` request. Only present for quote
                          orders.
                        required: false
                      - name: trigger_order_id
                        type: string
                        description: >-
                          Id of the trigger order that created the order (Only
                          for orders that were created by triggered orders).
                        required: false
                      - name: app_name
                        type: string
                        description: >-
                          The name of the application that placed the order on
                          behalf of the user (optional).
                        required: false
                      - name: mmp_cancelled
                        type: boolean
                        description: >-
                          `true` if order was cancelled by mmp trigger
                          (optional)
                        required: false
                      - name: cancel_reason
                        type: string
                        description: >-
                          Enumerated reason behind cancel `"user_request"`,
                          `"autoliquidation"`, `"cancel_on_disconnect"`,
                          `"risk_mitigation"`, `"pme_risk_reduction"` (portfolio
                          margining risk reduction), `"pme_account_locked"`
                          (portfolio margining account locked per currency),
                          `"position_locked"`, `"mmp_trigger"` (market maker
                          protection), `"mmp_config_curtailment"` (market maker
                          configured quantity decreased),
                          `"edit_post_only_reject"` (cancelled on edit because
                          of `reject_post_only` setting), `"oco_other_closed"`
                          (the oco order linked to this order was closed),
                          `"oto_primary_closed"` (the oto primary order that was
                          going to trigger this order was cancelled),
                          `"settlement"` (closed because of a settlement)
                        enumValues:
                          - user_request
                          - autoliquidation
                          - cancel_on_disconnect
                          - risk_mitigation
                          - pme_risk_reduction
                          - pme_account_locked
                          - position_locked
                          - mmp_trigger
                          - mmp_config_curtailment
                          - edit_post_only_reject
                          - oco_other_closed
                          - oto_primary_closed
                          - settlement
                        required: false
                      - name: oto_order_ids
                        type: object
                        description: >-
                          The Ids of the orders that will be triggered if the
                          order is filled
                        required: false
                        properties: []
                      - name: trigger_fill_condition
                        type: string
                        description: >-
                          <p>The fill condition of the linked order (Only for
                          linked order types), default: `first_hit`.</p> <ul>
                          <li>`"first_hit"` - any execution of the primary order
                          will fully cancel/place all secondary orders.</li>
                          <li>`"complete_fill"` - a complete execution (meaning
                          the primary order no longer exists) will cancel/place
                          the secondary orders.</li> <li>`"incremental"` - any
                          fill of the primary order will cause proportional
                          partial cancellation/placement of the secondary order.
                          The amount that will be subtracted/added to the
                          secondary order will be rounded down to the contract
                          size.</li> </ul>
                        enumValues:
                          - first_hit
                          - complete_fill
                          - incremental
                        required: false
                      - name: oco_ref
                        type: string
                        description: >-
                          Unique reference that identifies a one_cancels_others
                          (OCO) pair.
                        required: false
                      - name: primary_order_id
                        type: string
                        description: Unique order identifier
                        required: false
                      - name: is_secondary_oto
                        type: boolean
                        description: >-
                          `true` if the order is an order that can be triggered
                          by another order, otherwise not present.
                        required: false
                      - name: is_primary_otoco
                        type: boolean
                        description: >-
                          `true` if the order is an order that can trigger an
                          OCO pair, otherwise not present.
                        required: false
                  - name: position
                    type: object
                    required: false
                    properties:
                      - name: instrument_name
                        type: string
                        description: Unique instrument identifier
                        required: false
                      - name: kind
                        type: string
                        description: >-
                          Instrument kind: `"future"`, `"option"`, `"spot"`,
                          `"future_combo"`, `"option_combo"`
                        enumValues:
                          - future
                          - option
                          - spot
                          - future_combo
                          - option_combo
                        required: false
                      - name: average_price
                        type: number
                        description: Average price of trades that built this position
                        required: false
                      - name: direction
                        type: string
                        description: 'Direction: `buy`, `sell` or `zero`'
                        enumValues:
                          - buy
                          - sell
                          - zero
                        required: false
                      - name: mark_price
                        type: number
                        description: Current mark price for position's instrument
                        required: false
                      - name: delta
                        type: number
                        description: Delta parameter
                        required: false
                      - name: gamma
                        type: number
                        description: Only for options, Gamma parameter
                        required: false
                      - name: vega
                        type: number
                        description: Only for options, Vega parameter
                        required: false
                      - name: theta
                        type: number
                        description: Only for options, Theta parameter
                        required: false
                      - name: index_price
                        type: number
                        description: Current index price
                        required: false
                      - name: initial_margin
                        type: number
                        description: Initial margin
                        required: false
                      - name: maintenance_margin
                        type: number
                        description: Maintenance margin
                        required: false
                      - name: settlement_price
                        type: number
                        description: >-
                          Optional (not added for spot). Last settlement price
                          for position's instrument 0 if instrument wasn't
                          settled yet
                        required: false
                      - name: total_profit_loss
                        type: number
                        description: Profit or loss from position
                        required: false
                      - name: floating_profit_loss
                        type: number
                        description: Floating profit or loss
                        required: false
                      - name: realized_profit_loss
                        type: number
                        description: Realized profit or loss
                        required: false
                      - name: size
                        type: number
                        description: >-
                          Position size for futures size in quote currency (e.g.
                          USD), for options size is in base currency (e.g. BTC)
                        required: false
                      - name: size_currency
                        type: number
                        description: Only for futures, position size in base currency
                        required: false
                      - name: average_price_usd
                        type: number
                        description: Only for options, average price in USD
                        required: false
                      - name: floating_profit_loss_usd
                        type: number
                        description: Only for options, floating profit or loss in USD
                        required: false
                      - name: leverage
                        type: integer
                        description: Current available leverage for future position
                        required: false
                      - name: realized_funding
                        type: number
                        description: >-
                          Realized Funding in current session included in
                          session realized profit or loss, only for positions of
                          perpetual instruments
                        required: false
                      - name: interest_value
                        type: number
                        description: >-
                          Value used to calculate `realized_funding` (perpetual
                          only)
                        required: false
        headers: []
        jsonPayloadSchema:
          type: object
          description: Response containing notification data
          properties:
            data:
              type: object
              properties:
                instrument_name:
                  type: string
                  description: Unique instrument identifier
                  example: BTC-PERPETUAL
                  x-parser-schema-id: <anonymous-schema-926>
                trades:
                  type: object
                  description: ''
                  properties:
                    trade_id:
                      type: string
                      description: Unique (per currency) trade identifier
                      x-parser-schema-id: <anonymous-schema-928>
                    trade_seq:
                      description: The sequence number of the trade within instrument
                      type: integer
                      x-parser-schema-id: <anonymous-schema-929>
                    instrument_name:
                      type: string
                      description: Unique instrument identifier
                      example: BTC-PERPETUAL
                      x-parser-schema-id: <anonymous-schema-930>
                    timestamp:
                      description: >-
                        The timestamp of the trade (milliseconds since the UNIX
                        epoch)
                      example: 1517329113791
                      type: integer
                      x-parser-schema-id: <anonymous-schema-931>
                    order_type:
                      type: string
                      description: 'Order type: `"limit`, `"market"`, or `"liquidation"`'
                      enum:
                        - limit
                        - market
                        - liquidation
                      x-parser-schema-id: <anonymous-schema-932>
                    advanced:
                      type: string
                      description: >-
                        Advanced type of user order: `"usd"` or `"implv"` (only
                        for options; omitted if not applicable)
                      enum:
                        - usd
                        - implv
                      x-parser-schema-id: <anonymous-schema-933>
                    order_id:
                      type: string
                      description: >-
                        Id of the user order (maker or taker), i.e. subscriber's
                        order id that took part in the trade
                      x-parser-schema-id: <anonymous-schema-934>
                    matching_id:
                      type: string
                      description: Always `null`
                      x-parser-schema-id: <anonymous-schema-935>
                    direction:
                      type: string
                      description: 'Direction: `buy`, or `sell`'
                      enum:
                        - buy
                        - sell
                      x-parser-schema-id: <anonymous-schema-936>
                    tick_direction:
                      type: integer
                      enum:
                        - 0
                        - 1
                        - 2
                        - 3
                      description: >-
                        Direction of the "tick" (`0` = Plus Tick, `1` =
                        Zero-Plus Tick, `2` = Minus Tick, `3` = Zero-Minus
                        Tick).
                      x-parser-schema-id: <anonymous-schema-937>
                    index_price:
                      type: number
                      description: Index Price at the moment of trade
                      x-parser-schema-id: <anonymous-schema-938>
                    price:
                      description: Price in base currency
                      type: number
                      x-parser-schema-id: <anonymous-schema-939>
                    amount:
                      type: number
                      description: >-
                        Trade amount. For perpetual and inverse futures the
                        amount is in USD units. For options and linear futures
                        it is the underlying base currency coin.
                      x-parser-schema-id: <anonymous-schema-940>
                    contracts:
                      type: number
                      description: >-
                        Trade size in contract units (optional, may be absent in
                        historical trades)
                      x-parser-schema-id: <anonymous-schema-941>
                    iv:
                      type: number
                      description: Option implied volatility for the price (Option only)
                      x-parser-schema-id: <anonymous-schema-942>
                    underlying_price:
                      type: number
                      description: >-
                        Underlying price for implied volatility calculations
                        (Options only)
                      x-parser-schema-id: <anonymous-schema-943>
                    liquidation:
                      type: string
                      description: >-
                        Optional field (only for trades caused by liquidation):
                        `"M"` when maker side of trade was under liquidation,
                        `"T"` when taker side was under liquidation, `"MT"` when
                        both sides of trade were under liquidation
                      enum:
                        - M
                        - T
                        - MT
                      x-parser-schema-id: <anonymous-schema-944>
                    liquidity:
                      type: string
                      description: >-
                        Describes what was role of users order: `"M"` when it
                        was maker order, `"T"` when it was taker order
                      enum:
                        - M
                        - T
                      x-parser-schema-id: <anonymous-schema-945>
                    fee:
                      type: number
                      description: User's fee in units of the specified `fee_currency`
                      x-parser-schema-id: <anonymous-schema-946>
                    fee_currency:
                      type: string
                      description: Currency, i.e `"BTC"`, `"ETH"`, `"USDC"`
                      enum:
                        - BTC
                        - ETH
                        - USDC
                        - USDT
                        - EURR
                      x-parser-schema-id: <anonymous-schema-947>
                    label:
                      type: string
                      description: >-
                        User defined label (presented only when previously set
                        for order by user)
                      x-parser-schema-id: <anonymous-schema-948>
                    state:
                      type: string
                      description: >-
                        Order state: `"open"`, `"filled"`, `"rejected"`,
                        `"cancelled"`, `"untriggered"` or `"archive"` (if order
                        was archived)
                      enum:
                        - open
                        - filled
                        - rejected
                        - cancelled
                        - untriggered
                        - archive
                      x-parser-schema-id: <anonymous-schema-949>
                    block_trade_id:
                      description: Block trade id - when trade was part of a block trade
                      type: string
                      example: '154'
                      x-parser-schema-id: <anonymous-schema-950>
                    block_rfq_id:
                      type: integer
                      description: >-
                        ID of the Block RFQ - when trade was part of the Block
                        RFQ
                      x-parser-schema-id: <anonymous-schema-951>
                    block_rfq_quote_id:
                      type: integer
                      description: >-
                        ID of the Block RFQ quote - when trade was part of the
                        Block RFQ
                      x-parser-schema-id: <anonymous-schema-952>
                    reduce_only:
                      type: string
                      description: '`true` if user order is reduce-only'
                      x-parser-schema-id: <anonymous-schema-953>
                    post_only:
                      type: string
                      description: '`true` if user order is post-only'
                      x-parser-schema-id: <anonymous-schema-954>
                    mmp:
                      type: boolean
                      description: '`true` if user order is MMP'
                      x-parser-schema-id: <anonymous-schema-955>
                    risk_reducing:
                      type: boolean
                      description: >-
                        `true` if user order is marked by the platform as a risk
                        reducing order (can apply only to orders placed by PM
                        users)
                      x-parser-schema-id: <anonymous-schema-956>
                    api:
                      type: boolean
                      description: '`true` if user order was created with API'
                      x-parser-schema-id: <anonymous-schema-957>
                    profit_loss:
                      type: number
                      description: Profit and loss in base currency.
                      x-parser-schema-id: <anonymous-schema-958>
                    mark_price:
                      type: number
                      description: Mark Price at the moment of trade
                      x-parser-schema-id: <anonymous-schema-959>
                    legs:
                      type: array
                      description: >-
                        Optional field containing leg trades if trade is a combo
                        trade (present when querying for **only** combo trades
                        and in `combo_trades` events)
                      x-parser-schema-id: <anonymous-schema-960>
                    combo_id:
                      type: string
                      description: >-
                        Optional field containing combo instrument name if the
                        trade is a combo trade
                      x-parser-schema-id: <anonymous-schema-961>
                    combo_trade_id:
                      type: number
                      description: >-
                        Optional field containing combo trade identifier if the
                        trade is a combo trade
                      x-parser-schema-id: <anonymous-schema-962>
                    quote_set_id:
                      type: string
                      description: >-
                        QuoteSet of the user order (optional, present only for
                        orders placed with `private/mass_quote`)
                      x-parser-schema-id: <anonymous-schema-963>
                    quote_id:
                      type: string
                      description: >-
                        QuoteID of the user order (optional, present only for
                        orders placed with `private/mass_quote`)
                      x-parser-schema-id: <anonymous-schema-964>
                    trade_allocations:
                      type: object
                      description: >-
                        List of allocations for Block RFQ pre-allocation. Each
                        allocation specifies `user_id`, `amount`, and `fee` for
                        the allocated part of the trade. For broker client
                        allocations, a `client_info` object will be included.
                      properties:
                        user_id:
                          description: >-
                            User ID to which part of the trade is allocated. For
                            brokers the User ID is obstructed.
                          type: integer
                          x-parser-schema-id: <anonymous-schema-966>
                        amount:
                          description: Amount allocated to this user.
                          type: number
                          x-parser-schema-id: <anonymous-schema-967>
                        fee:
                          description: Fee for the allocated part of the trade.
                          type: number
                          x-parser-schema-id: <anonymous-schema-968>
                        client_info:
                          description: Optional client allocation info for brokers.
                          type: object
                          properties:
                            client_id:
                              description: >-
                                ID of a client; available to broker. Represents
                                a group of users under a common name.
                              type: integer
                              x-parser-schema-id: <anonymous-schema-970>
                            client_link_id:
                              description: >-
                                ID assigned to a single user in a client;
                                available to broker.
                              type: integer
                              x-parser-schema-id: <anonymous-schema-971>
                            name:
                              description: >-
                                Name of the linked user within the client;
                                available to broker.
                              type: string
                              x-parser-schema-id: <anonymous-schema-972>
                          x-parser-schema-id: <anonymous-schema-969>
                      required:
                        - amount
                        - fee
                      additionalProperties: false
                      x-parser-schema-id: <anonymous-schema-965>
                  required:
                    - trade_id
                    - trade_seq
                    - instrument_name
                    - timestamp
                    - order_id
                    - matching_id
                    - direction
                    - tick_direction
                    - index_price
                    - price
                    - amount
                    - fee
                    - fee_currency
                    - state
                    - mark_price
                  additionalProperties: false
                  x-parser-schema-id: <anonymous-schema-927>
                orders:
                  type: object
                  description: ''
                  properties:
                    order_id:
                      description: Unique order identifier
                      type: string
                      example: ETH-100234
                      x-parser-schema-id: <anonymous-schema-974>
                    order_state:
                      type: string
                      description: >-
                        Order state: `"open"`, `"filled"`, `"rejected"`,
                        `"cancelled"`, `"untriggered"`
                      enum:
                        - open
                        - filled
                        - rejected
                        - cancelled
                        - untriggered
                        - triggered
                      x-parser-schema-id: <anonymous-schema-975>
                    order_type:
                      type: string
                      description: >-
                        Order type: `"limit"`, `"market"`, `"stop_limit"`,
                        `"stop_market"`, `"take_limit"`, `"take_market"`,
                        `"trailing_stop"`
                      enum:
                        - market
                        - limit
                        - stop_market
                        - stop_limit
                        - take_market
                        - take_limit
                        - trailing_stop
                      x-parser-schema-id: <anonymous-schema-976>
                    original_order_type:
                      type: string
                      description: Original order type. Optional field
                      enum:
                        - market
                        - market_limit
                      x-parser-schema-id: <anonymous-schema-977>
                    time_in_force:
                      type: string
                      description: >-
                        Order time in force: `"good_til_cancelled"`,
                        `"good_til_day"`, `"fill_or_kill"` or
                        `"immediate_or_cancel"`
                      enum:
                        - good_til_cancelled
                        - good_til_day
                        - fill_or_kill
                        - immediate_or_cancel
                      x-parser-schema-id: <anonymous-schema-978>
                    is_rebalance:
                      type: boolean
                      description: >-
                        Optional (only for spot). `true` if order was
                        automatically created during cross-collateral balance
                        restoration
                      x-parser-schema-id: <anonymous-schema-979>
                    is_liquidation:
                      type: boolean
                      description: >-
                        Optional (not added for spot). `true` if order was
                        automatically created during liquidation
                      x-parser-schema-id: <anonymous-schema-980>
                    instrument_name:
                      type: string
                      description: Unique instrument identifier
                      example: BTC-PERPETUAL
                      x-parser-schema-id: <anonymous-schema-981>
                    creation_timestamp:
                      type: integer
                      example: 1536569522277
                      description: The timestamp (milliseconds since the Unix epoch)
                      x-parser-schema-id: <anonymous-schema-982>
                    last_update_timestamp:
                      type: integer
                      example: 1536569522277
                      description: The timestamp (milliseconds since the Unix epoch)
                      x-parser-schema-id: <anonymous-schema-983>
                    direction:
                      type: string
                      description: 'Direction: `buy`, or `sell`'
                      enum:
                        - buy
                        - sell
                      x-parser-schema-id: <anonymous-schema-984>
                    price:
                      description: >-
                        Price in base currency or "market_price" in case of open
                        trigger market orders
                      x-parser-schema-id: <anonymous-schema-985>
                    label:
                      type: string
                      description: User defined label (up to 64 characters)
                      x-parser-schema-id: <anonymous-schema-986>
                    post_only:
                      type: boolean
                      description: '`true` for post-only orders only'
                      x-parser-schema-id: <anonymous-schema-987>
                    reject_post_only:
                      description: >-
                        `true` if order has `reject_post_only` flag (field is
                        present only when `post_only` is `true`)
                      type: boolean
                      x-parser-schema-id: <anonymous-schema-988>
                    reduce_only:
                      type: boolean
                      description: >-
                        Optional (not added for spot). '`true` for reduce-only
                        orders only'
                      x-parser-schema-id: <anonymous-schema-989>
                    api:
                      type: boolean
                      description: '`true` if created with API'
                      x-parser-schema-id: <anonymous-schema-990>
                    web:
                      type: boolean
                      description: '`true` if created via Deribit frontend (optional)'
                      x-parser-schema-id: <anonymous-schema-991>
                    mobile:
                      type: boolean
                      description: >-
                        Optional field with value `true` added only when created
                        with Mobile Application
                      x-parser-schema-id: <anonymous-schema-992>
                    refresh_amount:
                      type: number
                      description: >-
                        The initial display amount of iceberg order. Iceberg
                        order display amount will be refreshed to that value
                        after match consuming actual display amount. Absent for
                        other types of orders
                      x-parser-schema-id: <anonymous-schema-993>
                    display_amount:
                      type: number
                      description: >-
                        The actual display amount of iceberg order. Absent for
                        other types of orders.
                      x-parser-schema-id: <anonymous-schema-994>
                    amount:
                      type: number
                      description: >-
                        It represents the requested order size. For perpetual
                        and inverse futures the amount is in USD units. For
                        options and linear futures it is the underlying base
                        currency coin.
                      x-parser-schema-id: <anonymous-schema-995>
                    contracts:
                      type: number
                      description: >-
                        It represents the order size in contract units.
                        (Optional, may be absent in historical data).
                      x-parser-schema-id: <anonymous-schema-996>
                    filled_amount:
                      type: number
                      description: >-
                        Filled amount of the order. For perpetual and futures
                        the filled_amount is in USD units, for options - in
                        units or corresponding cryptocurrency contracts, e.g.,
                        BTC or ETH.
                      x-parser-schema-id: <anonymous-schema-997>
                    average_price:
                      type: number
                      description: Average fill price of the order
                      x-parser-schema-id: <anonymous-schema-998>
                    advanced:
                      type: string
                      description: >
                        advanced type: `"usd"` or `"implv"` (Only for options;
                        field is omitted if not applicable).
                      enum:
                        - usd
                        - implv
                      x-parser-schema-id: <anonymous-schema-999>
                    implv:
                      type: number
                      description: >-
                        Implied volatility in percent. (Only if
                        `advanced="implv"`)
                      x-parser-schema-id: <anonymous-schema-1000>
                    usd:
                      type: number
                      description: Option price in USD (Only if `advanced="usd"`)
                      x-parser-schema-id: <anonymous-schema-1001>
                    triggered:
                      type: boolean
                      description: Whether the trigger order has been triggered
                      x-parser-schema-id: <anonymous-schema-1002>
                    trigger:
                      type: string
                      description: >-
                        Trigger type (only for trigger orders). Allowed values:
                        `"index_price"`, `"mark_price"`, `"last_price"`.
                      enum:
                        - index_price
                        - mark_price
                        - last_price
                      x-parser-schema-id: <anonymous-schema-1003>
                    trigger_price:
                      type: number
                      description: Trigger price (Only for future trigger orders)
                      x-parser-schema-id: <anonymous-schema-1004>
                    trigger_offset:
                      type: number
                      description: >-
                        The maximum deviation from the price peak beyond which
                        the order will be triggered (Only for trailing trigger
                        orders)
                      x-parser-schema-id: <anonymous-schema-1005>
                    trigger_reference_price:
                      type: number
                      description: >-
                        The price of the given trigger at the time when the
                        order was placed (Only for trailing trigger orders)
                      x-parser-schema-id: <anonymous-schema-1006>
                    block_trade:
                      description: >-
                        `true` if order made from block_trade trade, added only
                        in that case.
                      type: boolean
                      example: true
                      x-parser-schema-id: <anonymous-schema-1007>
                    mmp:
                      type: boolean
                      description: '`true` if the order is a MMP order, otherwise `false`.'
                      x-parser-schema-id: <anonymous-schema-1008>
                    risk_reducing:
                      type: boolean
                      description: >-
                        `true` if the order is marked by the platform as a risk
                        reducing order (can apply only to orders placed by PM
                        users), otherwise `false`.
                      x-parser-schema-id: <anonymous-schema-1009>
                    replaced:
                      type: boolean
                      description: >-
                        `true` if the order was edited (by user or - in case of
                        advanced options orders - by pricing engine), otherwise
                        `false`.
                      x-parser-schema-id: <anonymous-schema-1010>
                    auto_replaced:
                      type: boolean
                      description: >-
                        Options, advanced orders only - `true` if last
                        modification of the order was performed by the pricing
                        engine, otherwise `false`.
                      x-parser-schema-id: <anonymous-schema-1011>
                    quote:
                      type: boolean
                      description: If order is a quote. Present only if true.
                      x-parser-schema-id: <anonymous-schema-1012>
                    mmp_group:
                      type: string
                      description: >-
                        Name of the MMP group supplied in the
                        `private/mass_quote` request. Only present for quote
                        orders.
                      x-parser-schema-id: <anonymous-schema-1013>
                    quote_set_id:
                      type: string
                      description: >-
                        Identifier of the QuoteSet supplied in the
                        `private/mass_quote` request. Only present for quote
                        orders.
                      x-parser-schema-id: <anonymous-schema-1014>
                    quote_id:
                      type: string
                      description: >-
                        The same QuoteID as supplied in the `private/mass_quote`
                        request. Only present for quote orders.
                      x-parser-schema-id: <anonymous-schema-1015>
                    trigger_order_id:
                      type: string
                      description: >-
                        Id of the trigger order that created the order (Only for
                        orders that were created by triggered orders).
                      example: SLIB-370
                      x-parser-schema-id: <anonymous-schema-1016>
                    app_name:
                      type: string
                      description: >-
                        The name of the application that placed the order on
                        behalf of the user (optional).
                      example: Example Application
                      x-parser-schema-id: <anonymous-schema-1017>
                    mmp_cancelled:
                      type: boolean
                      description: '`true` if order was cancelled by mmp trigger (optional)'
                      example: true
                      x-parser-schema-id: <anonymous-schema-1018>
                    cancel_reason:
                      type: string
                      description: >-
                        Enumerated reason behind cancel `"user_request"`,
                        `"autoliquidation"`, `"cancel_on_disconnect"`,
                        `"risk_mitigation"`, `"pme_risk_reduction"` (portfolio
                        margining risk reduction), `"pme_account_locked"`
                        (portfolio margining account locked per currency),
                        `"position_locked"`, `"mmp_trigger"` (market maker
                        protection), `"mmp_config_curtailment"` (market maker
                        configured quantity decreased),
                        `"edit_post_only_reject"` (cancelled on edit because of
                        `reject_post_only` setting), `"oco_other_closed"` (the
                        oco order linked to this order was closed),
                        `"oto_primary_closed"` (the oto primary order that was
                        going to trigger this order was cancelled),
                        `"settlement"` (closed because of a settlement)
                      enum:
                        - user_request
                        - autoliquidation
                        - cancel_on_disconnect
                        - risk_mitigation
                        - pme_risk_reduction
                        - pme_account_locked
                        - position_locked
                        - mmp_trigger
                        - mmp_config_curtailment
                        - edit_post_only_reject
                        - oco_other_closed
                        - oto_primary_closed
                        - settlement
                      x-parser-schema-id: <anonymous-schema-1019>
                    oto_order_ids:
                      type: object
                      description: >-
                        The Ids of the orders that will be triggered if the
                        order is filled
                      properties: {}
                      additionalProperties: true
                      x-parser-schema-id: <anonymous-schema-1020>
                    trigger_fill_condition:
                      description: >-
                        <p>The fill condition of the linked order (Only for
                        linked order types), default: `first_hit`.</p> <ul>
                        <li>`"first_hit"` - any execution of the primary order
                        will fully cancel/place all secondary orders.</li>
                        <li>`"complete_fill"` - a complete execution (meaning
                        the primary order no longer exists) will cancel/place
                        the secondary orders.</li> <li>`"incremental"` - any
                        fill of the primary order will cause proportional
                        partial cancellation/placement of the secondary order.
                        The amount that will be subtracted/added to the
                        secondary order will be rounded down to the contract
                        size.</li> </ul>
                      type: string
                      enum:
                        - first_hit
                        - complete_fill
                        - incremental
                      x-parser-schema-id: <anonymous-schema-1021>
                    oco_ref:
                      type: string
                      description: >-
                        Unique reference that identifies a one_cancels_others
                        (OCO) pair.
                      x-parser-schema-id: <anonymous-schema-1022>
                    primary_order_id:
                      description: Unique order identifier
                      type: string
                      example: ETH-100234
                      x-parser-schema-id: <anonymous-schema-1023>
                    is_secondary_oto:
                      type: boolean
                      description: >-
                        `true` if the order is an order that can be triggered by
                        another order, otherwise not present.
                      x-parser-schema-id: <anonymous-schema-1024>
                    is_primary_otoco:
                      type: boolean
                      description: >-
                        `true` if the order is an order that can trigger an OCO
                        pair, otherwise not present.
                      x-parser-schema-id: <anonymous-schema-1025>
                  required:
                    - order_id
                    - order_state
                    - order_type
                    - time_in_force
                    - instrument_name
                    - creation_timestamp
                    - last_update_timestamp
                    - direction
                    - price
                    - label
                    - post_only
                    - api
                  additionalProperties: false
                  x-parser-schema-id: <anonymous-schema-973>
                position:
                  type: object
                  description: ''
                  properties:
                    instrument_name:
                      type: string
                      description: Unique instrument identifier
                      example: BTC-PERPETUAL
                      x-parser-schema-id: <anonymous-schema-1027>
                    kind:
                      type: string
                      description: >-
                        Instrument kind: `"future"`, `"option"`, `"spot"`,
                        `"future_combo"`, `"option_combo"`
                      enum:
                        - future
                        - option
                        - spot
                        - future_combo
                        - option_combo
                      x-parser-schema-id: <anonymous-schema-1028>
                    average_price:
                      type: number
                      description: Average price of trades that built this position
                      x-parser-schema-id: <anonymous-schema-1029>
                    direction:
                      type: string
                      description: 'Direction: `buy`, `sell` or `zero`'
                      enum:
                        - buy
                        - sell
                        - zero
                      x-parser-schema-id: <anonymous-schema-1030>
                    mark_price:
                      type: number
                      description: Current mark price for position's instrument
                      x-parser-schema-id: <anonymous-schema-1031>
                    delta:
                      type: number
                      description: Delta parameter
                      x-parser-schema-id: <anonymous-schema-1032>
                    gamma:
                      type: number
                      description: Only for options, Gamma parameter
                      x-parser-schema-id: <anonymous-schema-1033>
                    vega:
                      type: number
                      description: Only for options, Vega parameter
                      x-parser-schema-id: <anonymous-schema-1034>
                    theta:
                      type: number
                      description: Only for options, Theta parameter
                      x-parser-schema-id: <anonymous-schema-1035>
                    index_price:
                      type: number
                      description: Current index price
                      x-parser-schema-id: <anonymous-schema-1036>
                    initial_margin:
                      type: number
                      description: Initial margin
                      x-parser-schema-id: <anonymous-schema-1037>
                    maintenance_margin:
                      type: number
                      description: Maintenance margin
                      x-parser-schema-id: <anonymous-schema-1038>
                    settlement_price:
                      type: number
                      description: >-
                        Optional (not added for spot). Last settlement price for
                        position's instrument 0 if instrument wasn't settled yet
                      x-parser-schema-id: <anonymous-schema-1039>
                    total_profit_loss:
                      type: number
                      description: Profit or loss from position
                      x-parser-schema-id: <anonymous-schema-1040>
                    floating_profit_loss:
                      type: number
                      description: Floating profit or loss
                      x-parser-schema-id: <anonymous-schema-1041>
                    realized_profit_loss:
                      type: number
                      description: Realized profit or loss
                      x-parser-schema-id: <anonymous-schema-1042>
                    size:
                      type: number
                      description: >-
                        Position size for futures size in quote currency (e.g.
                        USD), for options size is in base currency (e.g. BTC)
                      x-parser-schema-id: <anonymous-schema-1043>
                    size_currency:
                      type: number
                      description: Only for futures, position size in base currency
                      x-parser-schema-id: <anonymous-schema-1044>
                    average_price_usd:
                      type: number
                      description: Only for options, average price in USD
                      x-parser-schema-id: <anonymous-schema-1045>
                    floating_profit_loss_usd:
                      type: number
                      description: Only for options, floating profit or loss in USD
                      x-parser-schema-id: <anonymous-schema-1046>
                    leverage:
                      type: integer
                      description: Current available leverage for future position
                      x-parser-schema-id: <anonymous-schema-1047>
                    realized_funding:
                      type: number
                      description: >-
                        Realized Funding in current session included in session
                        realized profit or loss, only for positions of perpetual
                        instruments
                      x-parser-schema-id: <anonymous-schema-1048>
                    interest_value:
                      type: number
                      description: >-
                        Value used to calculate `realized_funding` (perpetual
                        only)
                      x-parser-schema-id: <anonymous-schema-1049>
                  required:
                    - instrument_name
                    - kind
                    - average_price
                    - direction
                    - mark_price
                    - delta
                    - index_price
                    - initial_margin
                    - maintenance_margin
                    - settlement_price
                    - total_profit_loss
                    - floating_profit_loss
                    - realized_profit_loss
                    - size
                  additionalProperties: false
                  x-parser-schema-id: <anonymous-schema-1026>
              required: []
              additionalProperties: false
              x-parser-schema-id: <anonymous-schema-925>
          required:
            - data
          additionalProperties: false
          x-parser-schema-id: <anonymous-schema-924>
        title: Subscription Notification Data
        description: Server sends subscription notification data
        example: |-
          {
            "data": {
              "trades": [
                {
                  "trade_seq": 866638,
                  "trade_id": "1430914",
                  "timestamp": 1605780344032,
                  "tick_direction": 1,
                  "state": "filled",
                  "reduce_only": false,
                  "profit_loss": 0.00004898,
                  "price": 17391,
                  "post_only": false,
                  "order_type": "market",
                  "order_id": "3398016",
                  "matching_id": null,
                  "mark_price": 17391,
                  "liquidity": "T",
                  "instrument_name": "BTC-PERPETUAL",
                  "index_price": 17501.88,
                  "fee_currency": "BTC",
                  "fee": 1.6e-7,
                  "direction": "sell",
                  "amount": 10
                }
              ],
              "positions": [
                {
                  "total_profit_loss": 1.69711368,
                  "size_currency": 10.646886321,
                  "size": 185160,
                  "settlement_price": 16025.83,
                  "realized_profit_loss": 0.012454598,
                  "realized_funding": 0.01235663,
                  "mark_price": 17391,
                  "maintenance_margin": 0.234575865,
                  "leverage": 33,
                  "kind": "future",
                  "interest_value": 1.7362511643080387,
                  "instrument_name": "BTC-PERPETUAL",
                  "initial_margin": 0.319750953,
                  "index_price": 17501.88,
                  "floating_profit_loss": 0.906961435,
                  "direction": "buy",
                  "delta": 10.646886321,
                  "average_price": 15000
                }
              ],
              "orders": [
                {
                  "web": true,
                  "time_in_force": "good_til_cancelled",
                  "replaced": false,
                  "reduce_only": false,
                  "price": 15665.5,
                  "post_only": false,
                  "order_type": "market",
                  "order_state": "filled",
                  "order_id": "3398016",
                  "max_show": 10,
                  "last_update_timestamp": 1605780344032,
                  "label": "",
                  "is_rebalance": false,
                  "is_liquidation": false,
                  "instrument_name": "BTC-PERPETUAL",
                  "filled_amount": 10,
                  "direction": "sell",
                  "creation_timestamp": 1605780344032,
                  "average_price": 17391,
                  "api": false,
                  "amount": 10
                }
              ],
              "instrument_name": "BTC-PERPETUAL"
            }
          }
        bindings: []
        extensions:
          - id: x-parser-unique-object-id
            value: subscription_message
    bindings: []
    extensions: &ref_0
      - id: x-parser-unique-object-id
        value: user.changes.(kind).(currency).(interval)
  - &ref_1
    id: receive_user_changes_kind_currency_interval_updates
    title: Receive user updates
    description: Client receives user update notifications
    type: receive
    messages:
      - &ref_3
        id: subscribe_request
        contentType: application/json
        payload:
          - name: Subscription Request
            description: >-
              Client sends subscription request to subscribe to notification
              channel. Please refer to [Notification
              page](https://deribit.mintlify.app/articles/notifications) for
              more information.
            type: object
            properties: []
        headers: []
        jsonPayloadSchema:
          properties: {}
          additionalProperties: false
          x-parser-schema-id: <anonymous-schema-923>
        title: Subscription Request
        description: >-
          Client sends subscription request to subscribe to notification
          channel. Please refer to [Notification
          page](https://deribit.mintlify.app/articles/notifications) for more
          information.
        example: |-
          {
            "jsonrpc": "2.0",
            "method": "public/subscribe",
            "id": 42,
            "params": {
              "channels": [
                "user.changes.(kind).(currency).100ms"
              ]
            }
          }
        bindings: []
        extensions:
          - id: x-parser-unique-object-id
            value: subscribe_request
    bindings: []
    extensions: *ref_0
sendOperations:
  - *ref_1
receiveOperations:
  - *ref_2
sendMessages:
  - *ref_3
receiveMessages:
  - *ref_4
extensions:
  - id: x-parser-unique-object-id
    value: user.changes.(kind).(currency).(interval)
securitySchemes: []

````

> ## Documentation Index
> Fetch the complete documentation index at: https://docs.deribit.com/llms.txt
> Use this file to discover all available pages before exploring further.

<AgentInstructions>

## Submitting Feedback

If you encounter incorrect, outdated, or confusing documentation on this page, submit feedback:

POST https://docs.deribit.com/feedback

```json
{
  "path": "/subscriptions/user/useraccess_log",
  "feedback": "Description of the issue"
}
```

Only submit feedback when you have something specific and actionable to report.

</AgentInstructions>

# user.access_log 

> Security event notifications for the account.

Use this channel to monitor account-related security events (e.g., access log entries) and build alerting around suspicious activity.




## AsyncAPI

````yaml specifications/deribit_asyncapi.json user.access_log
id: user.access_log
title: 'user.access_log '
description: >
  Security event notifications for the account.


  Use this channel to monitor account-related security events (e.g., access log
  entries) and build alerting around suspicious activity.
servers:
  - id: production
    protocol: wss
    host: deribit.com/ws/api/v2
    bindings: []
    variables: []
  - id: testnet
    protocol: wss
    host: test.deribit.com/ws/api/v2
    bindings: []
    variables: []
address: user.access_log
parameters: []
bindings: []
operations:
  - &ref_2
    id: send_subscribe_user_access_log
    title: Send subscribe request
    description: Client sends subscription request for user
    type: send
    messages:
      - &ref_4
        id: subscription_message
        contentType: application/json
        payload:
          - name: Subscription Notification Data
            description: Server sends subscription notification data
            type: object
            properties:
              - name: data
                type: object
                required: true
                properties:
                  - name: id
                    type: integer
                    description: Unique identifier
                    required: false
                  - name: ip
                    type: string
                    description: IP address of source that generated action
                    required: false
                  - name: timestamp
                    type: integer
                    description: The timestamp (milliseconds since the Unix epoch)
                    required: false
                  - name: country
                    type: string
                    description: Country where the IP address is registered (estimated)
                    required: false
                  - name: city
                    type: string
                    description: City where the IP address is registered (estimated)
                    required: false
                  - name: log
                    type: string
                    description: >
                      Action description. Possible values:


                      - ``changed_email`` - email was changed

                      - ``changed_password`` - password was changed

                      - ``disabled_tfa`` - TFA was disabled

                      - ``enabled_tfa`` - TFA was enabled

                      - ``success`` - successful login

                      - ``failure`` - login failure

                      - ``enabled_subaccount_login`` - login was enabled for
                      subaccount (in `data` - subaccount uid)

                      - ``disabled_subaccount_login`` - login was disabled for
                      subaccount (in `data` - subaccount uid)

                      - ``new_api_key`` - API key was created (in `data` key
                      client id)

                      - ``removed_api_key`` - API key was removed (in `data` key
                      client id)

                      - ``changed_scope`` - scope of API key was changed (in
                      `data` key client id)

                      - ``changed_whitelist`` - whitelist of API key was edited
                      (in `data` key client id)

                      - ``disabled_api_key`` - API key was disabled (in `data`
                      key client id)

                      - ``enabled_api_key`` - API key was enabled (in `data` key
                      client id)

                      - ``reset_api_key`` - API key was reset (in `data` key
                      client id)
                    required: false
                  - name: oneOf
                    type: oneOf
                    description: Must be one of these types
                    properties:
                      - name: type
                        type: string
                        description: object
                        required: false
                      - name: type
                        type: string
                        description: string
                        required: false
                  - name: description
                    type: string
                    description: >-
                      Optional, additional information about action, type
                      depends on `log` value
                    required: false
        headers: []
        jsonPayloadSchema:
          type: object
          description: Response containing notification data
          properties:
            data:
              type: object
              properties:
                id:
                  description: Unique identifier
                  type: integer
                  example: 5967413
                  x-parser-schema-id: <anonymous-schema-1053>
                ip:
                  type: string
                  description: IP address of source that generated action
                  x-parser-schema-id: <anonymous-schema-1054>
                timestamp:
                  type: integer
                  example: 1536569522277
                  description: The timestamp (milliseconds since the Unix epoch)
                  x-parser-schema-id: <anonymous-schema-1055>
                country:
                  type: string
                  description: Country where the IP address is registered (estimated)
                  x-parser-schema-id: <anonymous-schema-1056>
                city:
                  type: string
                  description: City where the IP address is registered (estimated)
                  x-parser-schema-id: <anonymous-schema-1057>
                log:
                  type: string
                  description: >
                    Action description. Possible values:


                    - ``changed_email`` - email was changed

                    - ``changed_password`` - password was changed

                    - ``disabled_tfa`` - TFA was disabled

                    - ``enabled_tfa`` - TFA was enabled

                    - ``success`` - successful login

                    - ``failure`` - login failure

                    - ``enabled_subaccount_login`` - login was enabled for
                    subaccount (in `data` - subaccount uid)

                    - ``disabled_subaccount_login`` - login was disabled for
                    subaccount (in `data` - subaccount uid)

                    - ``new_api_key`` - API key was created (in `data` key
                    client id)

                    - ``removed_api_key`` - API key was removed (in `data` key
                    client id)

                    - ``changed_scope`` - scope of API key was changed (in
                    `data` key client id)

                    - ``changed_whitelist`` - whitelist of API key was edited
                    (in `data` key client id)

                    - ``disabled_api_key`` - API key was disabled (in `data` key
                    client id)

                    - ``enabled_api_key`` - API key was enabled (in `data` key
                    client id)

                    - ``reset_api_key`` - API key was reset (in `data` key
                    client id)
                  x-parser-schema-id: <anonymous-schema-1058>
                data:
                  oneOf:
                    - type: object
                      x-parser-schema-id: <anonymous-schema-1060>
                    - type: string
                      x-parser-schema-id: <anonymous-schema-1061>
                  description: >-
                    Optional, additional information about action, type depends
                    on `log` value
                  x-parser-schema-id: <anonymous-schema-1059>
              required:
                - id
                - ip
                - timestamp
                - country
                - city
                - log
              additionalProperties: false
              x-parser-schema-id: <anonymous-schema-1052>
          required:
            - data
          additionalProperties: false
          x-parser-schema-id: <anonymous-schema-1051>
        title: Subscription Notification Data
        description: Server sends subscription notification data
        example: |-
          {
            "data": {
              "timestamp": 1632488963633,
              "log": "success",
              "ip": "8.9.10.11",
              "id": 243343,
              "country": "China",
              "city": "Pekin"
            }
          }
        bindings: []
        extensions:
          - id: x-parser-unique-object-id
            value: subscription_message
    bindings: []
    extensions: &ref_0
      - id: x-parser-unique-object-id
        value: user.access_log
  - &ref_1
    id: receive_user_access_log
    title: Receive user
    description: Client receives user notifications
    type: receive
    messages:
      - &ref_3
        id: subscribe_request
        contentType: application/json
        payload:
          - name: Subscription Request
            description: >-
              Client sends subscription request to subscribe to notification
              channel. Please refer to [Notification
              page](https://deribit.mintlify.app/articles/notifications) for
              more information.
            type: object
            properties: []
        headers: []
        jsonPayloadSchema:
          properties: {}
          additionalProperties: false
          x-parser-schema-id: <anonymous-schema-1050>
        title: Subscription Request
        description: >-
          Client sends subscription request to subscribe to notification
          channel. Please refer to [Notification
          page](https://deribit.mintlify.app/articles/notifications) for more
          information.
        example: |-
          {
            "jsonrpc": "2.0",
            "method": "public/subscribe",
            "id": 42,
            "params": {
              "channels": [
                "user.access_log"
              ]
            }
          }
        bindings: []
        extensions:
          - id: x-parser-unique-object-id
            value: subscribe_request
    bindings: []
    extensions: *ref_0
sendOperations:
  - *ref_1
receiveOperations:
  - *ref_2
sendMessages:
  - *ref_3
receiveMessages:
  - *ref_4
extensions:
  - id: x-parser-unique-object-id
    value: user.access_log
securitySchemes: []

````

> ## Documentation Index
> Fetch the complete documentation index at: https://docs.deribit.com/llms.txt
> Use this file to discover all available pages before exploring further.

<AgentInstructions>

## Submitting Feedback

If you encounter incorrect, outdated, or confusing documentation on this page, submit feedback:

POST https://docs.deribit.com/feedback

```json
{
  "path": "/subscriptions/user/userlock",
  "feedback": "Description of the issue"
}
```

Only submit feedback when you have something specific and actionable to report.

</AgentInstructions>

# user.lock 

> Notifications when the account is locked or unlocked.

Use this channel to react to account lock events (e.g., pause trading workflows) and to detect when access is restored.




## AsyncAPI

````yaml specifications/deribit_asyncapi.json user.lock
id: user.lock
title: 'user.lock '
description: >
  Notifications when the account is locked or unlocked.


  Use this channel to react to account lock events (e.g., pause trading
  workflows) and to detect when access is restored.
servers:
  - id: production
    protocol: wss
    host: deribit.com/ws/api/v2
    bindings: []
    variables: []
  - id: testnet
    protocol: wss
    host: test.deribit.com/ws/api/v2
    bindings: []
    variables: []
address: user.lock
parameters: []
bindings: []
operations:
  - &ref_2
    id: send_subscribe_user_lock
    title: Send subscribe request
    description: Client sends subscription request for user
    type: send
    messages:
      - &ref_4
        id: subscription_message
        contentType: application/json
        payload:
          - name: Subscription Notification Data
            description: Server sends subscription notification data
            type: object
            properties:
              - name: data
                type: object
                required: true
                properties:
                  - name: currency
                    type: string
                    description: >-
                      Currency on which account lock has changed, `ALL` if
                      changed for all currencies
                    required: false
                  - name: locked
                    type: boolean
                    description: >-
                      Value is set to 'true' when user account is locked in
                      currency
                    required: false
        headers: []
        jsonPayloadSchema:
          type: object
          description: Response containing notification data
          properties:
            data:
              type: object
              properties:
                currency:
                  type: string
                  description: >-
                    Currency on which account lock has changed, `ALL` if changed
                    for all currencies
                  example: BTC, ALL
                  x-parser-schema-id: <anonymous-schema-1065>
                locked:
                  type: boolean
                  description: >-
                    Value is set to 'true' when user account is locked in
                    currency
                  example: false
                  x-parser-schema-id: <anonymous-schema-1066>
              required:
                - currency
                - locked
              additionalProperties: false
              x-parser-schema-id: <anonymous-schema-1064>
          required:
            - data
          additionalProperties: false
          x-parser-schema-id: <anonymous-schema-1063>
        title: Subscription Notification Data
        description: Server sends subscription notification data
        example: |-
          {
            "data": {
              "locked": true,
              "currency": "ALL"
            }
          }
        bindings: []
        extensions:
          - id: x-parser-unique-object-id
            value: subscription_message
    bindings: []
    extensions: &ref_0
      - id: x-parser-unique-object-id
        value: user.lock
  - &ref_1
    id: receive_user_lock
    title: Receive user
    description: Client receives user notifications
    type: receive
    messages:
      - &ref_3
        id: subscribe_request
        contentType: application/json
        payload:
          - name: Subscription Request
            description: >-
              Client sends subscription request to subscribe to notification
              channel. Please refer to [Notification
              page](https://deribit.mintlify.app/articles/notifications) for
              more information.
            type: object
            properties: []
        headers: []
        jsonPayloadSchema:
          properties: {}
          additionalProperties: false
          x-parser-schema-id: <anonymous-schema-1062>
        title: Subscription Request
        description: >-
          Client sends subscription request to subscribe to notification
          channel. Please refer to [Notification
          page](https://deribit.mintlify.app/articles/notifications) for more
          information.
        example: |-
          {
            "jsonrpc": "2.0",
            "method": "public/subscribe",
            "id": 42,
            "params": {
              "channels": [
                "user.lock"
              ]
            }
          }
        bindings: []
        extensions:
          - id: x-parser-unique-object-id
            value: subscribe_request
    bindings: []
    extensions: *ref_0
sendOperations:
  - *ref_1
receiveOperations:
  - *ref_2
sendMessages:
  - *ref_3
receiveMessages:
  - *ref_4
extensions:
  - id: x-parser-unique-object-id
    value: user.lock
securitySchemes: []

````



