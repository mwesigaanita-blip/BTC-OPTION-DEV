> ## Documentation Index
> Fetch the complete documentation index at: https://docs.deribit.com/llms.txt
> Use this file to discover all available pages before exploring further.

<AgentInstructions>

## Submitting Feedback

If you encounter incorrect, outdated, or confusing documentation on this page, submit feedback:

POST https://docs.deribit.com/feedback

```json
{
  "path": "/subscriptions/market-data/tickerinstrument_nameinterval",
  "feedback": "Description of the issue"
}
```

Only submit feedback when you have something specific and actionable to report.

</AgentInstructions>

# ticker.(instrument_name).(interval) 

> Real-time ticker data providing comprehensive market information for the specified instrument.

This subscription delivers key market metrics including:

- **Price data:** Best bid/ask prices and amounts, last trade price, mark price, index price, settlement price, and estimated delivery price
- **Market statistics:** 24-hour volume (in base currency and USD for futures), high/low prices, price change percentage, and open interest
- **Order book state:** Current state of the instrument (open, settlement, delivered, inactive, locked, halted, or archivized)
- **Price limits:** Minimum and maximum price constraints for order placement
- **Options-specific data:** Implied volatility (bid/ask/mark IV), Greeks (delta, gamma, theta, vega, rho), underlying price, and interest rate
- **Perpetual-specific data:** Current funding rate and 8-hour funding rate
- **Futures-specific data:** Interest value and delivery price

The `interval` parameter controls the frequency of updates: `raw` (no aggregation, authorized users only), `100ms` (aggregated every 100 milliseconds), or `agg2` (aggregated every 2 seconds).

This is the recommended method for real-time market data updates, as it provides efficient push-based notifications instead of requiring polling.




## AsyncAPI

````yaml specifications/deribit_asyncapi.json ticker.(instrument_name).(interval)
id: ticker.(instrument_name).(interval)
title: 'ticker.(instrument_name).(interval) '
description: >
  Real-time ticker data providing comprehensive market information for the
  specified instrument.


  This subscription delivers key market metrics including:


  - **Price data:** Best bid/ask prices and amounts, last trade price, mark
  price, index price, settlement price, and estimated delivery price

  - **Market statistics:** 24-hour volume (in base currency and USD for
  futures), high/low prices, price change percentage, and open interest

  - **Order book state:** Current state of the instrument (open, settlement,
  delivered, inactive, locked, halted, or archivized)

  - **Price limits:** Minimum and maximum price constraints for order placement

  - **Options-specific data:** Implied volatility (bid/ask/mark IV), Greeks
  (delta, gamma, theta, vega, rho), underlying price, and interest rate

  - **Perpetual-specific data:** Current funding rate and 8-hour funding rate

  - **Futures-specific data:** Interest value and delivery price


  The `interval` parameter controls the frequency of updates: `raw` (no
  aggregation, authorized users only), `100ms` (aggregated every 100
  milliseconds), or `agg2` (aggregated every 2 seconds).


  This is the recommended method for real-time market data updates, as it
  provides efficient push-based notifications instead of requiring polling.
servers:
  - id: production
    protocol: wss
    host: deribit.com/ws/api/v2
    bindings: []
    variables: []
  - id: testnet
    protocol: wss
    host: test.deribit.com/ws/api/v2
    bindings: []
    variables: []
address: ticker.(instrument_name).(interval)
parameters:
  - id: instrument_name
    jsonSchema:
      type: string
      description: The name of the instrument
    description: The name of the instrument
    type: string
    required: true
    deprecated: false
  - id: interval
    jsonSchema:
      type: string
      description: >-
        Frequency of notifications. Events will be aggregated over this
        interval. The value `raw` means no aggregation will be applied **(Please
        note that `raw` interval is only available to authorized users)**


        **Allowed values:** `raw`, `100ms`, `agg2`
      enum:
        - raw
        - 100ms
        - agg2
    description: >-
      Frequency of notifications. Events will be aggregated over this interval.
      The value `raw` means no aggregation will be applied **(Please note that
      `raw` interval is only available to authorized users)**


      **Allowed values:** `raw`, `100ms`, `agg2`
    type: string
    required: true
    deprecated: false
bindings: []
operations:
  - &ref_2
    id: send_subscribe_ticker_instrument_name_interval
    title: Send subscribe request for ticker
    description: Client sends subscription request for ticker updates
    type: send
    messages:
      - &ref_4
        id: subscription_message
        contentType: application/json
        payload:
          - name: Subscription Notification Data
            description: Server sends subscription notification data
            type: object
            properties:
              - name: data
                type: object
                required: true
                properties:
                  - name: instrument_name
                    type: string
                    description: Unique instrument identifier
                    required: false
                  - name: timestamp
                    type: integer
                    description: The timestamp (milliseconds since the Unix epoch)
                    required: false
                  - name: state
                    type: string
                    description: >
                      The state of the order book. Represents the current
                      lifecycle stage of the instrument.


                      **State Lifecycle and Meanings:**


                      - `open`: Default state for running books. In this state
                      book is accepting new orders, edits, cancels; prices
                      should be updated, trading is live.

                      - `settlement`: Books enters to this state during
                      settlement/delivery. New orders, edits, cancels are not
                      accepted. After this state normally next state should be
                      `open` if it was settlement, or `delivered` if it was
                      delivery. On enter to this state good till day orders in
                      book are canceled.

                      - `delivered`: Final state of book that has been
                      delivered. New orders, edits, cancels are not accepted.
                      After some time book process will be terminated and,
                      instrument moved to `expired_instruments` and its
                      `instrument_state` will become archivized. On enter to
                      this all open orders in book are canceled.

                      - `inactive`: After a book is deactivated, this state is
                      set on book. New orders, edits, cancels are not accepted.
                      On enter to this all open orders in book are canceled.
                      Book in this state is not considered as open. This can be
                      also final state for book.

                      - `locked`: New orders, edits, are not accepted, only
                      cancels ARE accepted. In some cases when configured books
                      can start as locked or it may become locked on admin
                      request. Settlement is possible on locked books.

                      - `halted`: The state that books enter as a result of an
                      error. Settlement is not possible when there is at least
                      one book in this state.

                      - `archivized`: Set when instrument is moved to
                      `expired_instruments` table, final state.
                    enumValues:
                      - open
                      - settlement
                      - delivered
                      - inactive
                      - locked
                      - halted
                      - archivized
                    required: false
                  - name: stats
                    type: object
                    required: false
                    properties:
                      - name: volume
                        type: number
                        description: Volume during last 24h in base currency
                        required: false
                      - name: low
                        type: number
                        description: Lowest price during 24h
                        required: false
                      - name: high
                        type: number
                        description: Highest price during 24h
                        required: false
                      - name: price_change
                        type: number
                        description: >-
                          24-hour price change expressed as a percentage, `null`
                          if there weren't any trades
                        required: false
                      - name: volume_usd
                        type: number
                        description: Volume in usd (futures only)
                        required: false
                  - name: open_interest
                    type: number
                    description: >-
                      The total amount of outstanding contracts in the
                      corresponding amount units. For perpetual and inverse
                      futures the amount is in USD units. For options and linear
                      futures it is the underlying base currency coin.
                    required: false
                  - name: best_bid_price
                    type: number
                    description: >-
                      The current best bid price, `null` if there aren't any
                      bids
                    required: false
                  - name: best_bid_amount
                    type: number
                    description: It represents the requested order size of all best bids
                    required: false
                  - name: best_ask_price
                    type: number
                    description: >-
                      The current best ask price, `null` if there aren't any
                      asks
                    required: false
                  - name: best_ask_amount
                    type: number
                    description: It represents the requested order size of all best asks
                    required: false
                  - name: index_price
                    type: number
                    description: Current index price
                    required: false
                  - name: min_price
                    type: number
                    description: >-
                      The minimum price for the future. Any sell orders you
                      submit lower than this price will be clamped to this
                      minimum.
                    required: false
                  - name: max_price
                    type: number
                    description: >-
                      The maximum price for the future. Any buy orders you
                      submit higher than this price, will be clamped to this
                      maximum.
                    required: false
                  - name: mark_price
                    type: number
                    description: The mark price for the instrument
                    required: false
                  - name: last_price
                    type: number
                    description: The price for the last trade
                    required: false
                  - name: underlying_price
                    type: number
                    description: >-
                      Underlying price for implied volatility calculations
                      (options only)
                    required: false
                  - name: underlying_index
                    type: number
                    description: >-
                      Name of the underlying future, or `index_price` (options
                      only)
                    required: false
                  - name: interest_rate
                    type: number
                    description: >-
                      Interest rate used in implied volatility calculations
                      (options only)
                    required: false
                  - name: bid_iv
                    type: number
                    description: (Only for option) implied volatility for best bid
                    required: false
                  - name: ask_iv
                    type: number
                    description: (Only for option) implied volatility for best ask
                    required: false
                  - name: mark_iv
                    type: number
                    description: (Only for option) implied volatility for mark price
                    required: false
                  - name: greeks
                    type: object
                    description: >
                      Only for options. Greeks are risk measures that describe
                      how the option's price changes with respect to various
                      factors.


                      **Delta (Δ)**


                      Deribit uses two different Deltas:

                      - **DeltaTotal** in the account summary uses the **Net
                      Transaction Delta (NTD)**

                      - **Delta** for individual option expiries is the **Black
                      Scholes Delta**


                      In the settings section you can toggle Net Transaction
                      Delta instead.


                      **What is DeltaTotal in the account summary?**

                      `DeltaTotal = Net Transaction Delta of options + BTC
                      Position of Futures`


                      **What is Net Transaction Delta?**

                      `Net Transaction Delta = Black Scholes Delta - Mark Price
                      of Options`


                      **Why do we use a Net Transaction Delta?**

                      The Delta Total uses the Net Transaction Delta (or price
                      adjusted Delta) of the options. This is because, from a
                      risk perspective, we are interested in the change in
                      Bitcoin price as the underlying changes.


                      You should actually treat your delta as **Equity + Delta
                      Total** if you want to have less risk for your USD PnL.


                      **Example:** Consider a call option with strike 0, which
                      has a Black Scholes Delta of 1 and Net Transaction Delta =
                      0.


                      Imagine you have 2 BTC equity and no positions and BTC
                      price is at USD 60k. In that case you would short 2
                      Futures contracts to hedge your USD exposure to BTC.


                      Now let's say you buy one call with strike 0. The question
                      is if you should sell another future?


                      The call will always have a price of 1 BTC. So you buy it
                      at 1 BTC which equates to USD 60k. Let's say the price
                      increases to USD 70k. The value of the call is still 1
                      BTC. At settlement you receive 1 BTC for the call. So you
                      paid 1 BTC and then receive 1 BTC which means your USD PnL
                      on buying the call is 0. If you sold a future on it, then
                      you would actually lose on the future.


                      ⚠️ **During the 30 minute settlement period we decay your
                      Delta.** See [Delta decay during
                      settlement](https://support.deribit.com/hc/en-us/articles/25944751433757-Delta-decay-during-settlement)
                      for more details.


                      **Theta (Θ)**


                      The Theta that Deribit uses is the **minimum of (1 day
                      Theta, lifetime theta of the option)**. So if you take an
                      option with 1 hour to expire for example, generally Black
                      Scholes Theta will give you the equivalent 1 day Theta.
                      Whereas we show the 1 hour Theta, so our Theta would
                      differ from Black Scholes Theta when time to expiry is
                      less than 1 day.


                      **Vega, Gamma, and Rho**


                      Vega (not actually a Greek symbol), Gamma, Theta and Rho
                      values shown on Deribit are calculated using **standard
                      Black Scholes without adjustments**.
                    required: false
                    properties:
                      - name: delta
                        type: number
                        description: >
                          (Only for option) The delta value for the option. This
                          is the **Black Scholes Delta** for individual option
                          expiries. 


                          Note that DeltaTotal in account summary uses Net
                          Transaction Delta instead. See the greeks object
                          description for more details.
                        required: false
                      - name: gamma
                        type: number
                        description: >
                          (Only for option) The gamma value for the option.
                          Calculated using standard Black Scholes without
                          adjustments.


                          Gamma measures the rate of change of delta with
                          respect to changes in the underlying asset price.
                        required: false
                      - name: rho
                        type: number
                        description: >
                          (Only for option) The rho value for the option.
                          Calculated using standard Black Scholes without
                          adjustments.


                          Rho measures the sensitivity of the option price to
                          changes in the risk-free interest rate.
                        required: false
                      - name: theta
                        type: number
                        description: >
                          (Only for option) The theta value for the option.
                          Deribit uses the **minimum of (1 day Theta, lifetime
                          theta of the option)**.


                          So if you take an option with 1 hour to expire for
                          example, generally Black Scholes Theta will give you
                          the equivalent 1 day Theta. Whereas we show the 1 hour
                          Theta, so our Theta would differ from Black Scholes
                          Theta when time to expiry is less than 1 day.


                          Theta measures the rate of change of the option price
                          with respect to time decay.
                        required: false
                      - name: vega
                        type: number
                        description: >
                          (Only for option) The vega value for the option.
                          Calculated using standard Black Scholes without
                          adjustments.


                          Vega (not actually a Greek symbol) measures the
                          sensitivity of the option price to changes in implied
                          volatility.
                        required: false
                  - name: funding_8h
                    type: number
                    description: Funding 8h (perpetual only)
                    required: false
                  - name: current_funding
                    type: number
                    description: Current funding (perpetual only)
                    required: false
                  - name: interest_value
                    type: number
                    description: >-
                      Value used to calculate `realized_funding` in positions
                      (perpetual only)
                    required: false
                  - name: delivery_price
                    type: number
                    description: >-
                      The settlement price for the instrument. Only when `state
                      = closed`
                    required: false
                  - name: settlement_price
                    type: number
                    description: >-
                      Optional (not added for spot). The settlement price for
                      the instrument. Only when `state = open`
                    required: false
                  - name: estimated_delivery_price
                    type: number
                    description: >-
                      Estimated delivery price for the market. For more details,
                      see Contract Specification > General Documentation >
                      Expiration Price
                    required: false
        headers: []
        jsonPayloadSchema:
          type: object
          description: Response containing notification data
          properties:
            data:
              type: object
              properties:
                instrument_name:
                  type: string
                  description: Unique instrument identifier
                  example: BTC-PERPETUAL
                  x-parser-schema-id: <anonymous-schema-55>
                timestamp:
                  type: integer
                  example: 1536569522277
                  description: The timestamp (milliseconds since the Unix epoch)
                  x-parser-schema-id: <anonymous-schema-56>
                state:
                  description: >
                    The state of the order book. Represents the current
                    lifecycle stage of the instrument.


                    **State Lifecycle and Meanings:**


                    - `open`: Default state for running books. In this state
                    book is accepting new orders, edits, cancels; prices should
                    be updated, trading is live.

                    - `settlement`: Books enters to this state during
                    settlement/delivery. New orders, edits, cancels are not
                    accepted. After this state normally next state should be
                    `open` if it was settlement, or `delivered` if it was
                    delivery. On enter to this state good till day orders in
                    book are canceled.

                    - `delivered`: Final state of book that has been delivered.
                    New orders, edits, cancels are not accepted. After some time
                    book process will be terminated and, instrument moved to
                    `expired_instruments` and its `instrument_state` will become
                    archivized. On enter to this all open orders in book are
                    canceled.

                    - `inactive`: After a book is deactivated, this state is set
                    on book. New orders, edits, cancels are not accepted. On
                    enter to this all open orders in book are canceled. Book in
                    this state is not considered as open. This can be also final
                    state for book.

                    - `locked`: New orders, edits, are not accepted, only
                    cancels ARE accepted. In some cases when configured books
                    can start as locked or it may become locked on admin
                    request. Settlement is possible on locked books.

                    - `halted`: The state that books enter as a result of an
                    error. Settlement is not possible when there is at least one
                    book in this state.

                    - `archivized`: Set when instrument is moved to
                    `expired_instruments` table, final state.
                  type: string
                  enum:
                    - open
                    - settlement
                    - delivered
                    - inactive
                    - locked
                    - halted
                    - archivized
                  x-parser-schema-id: <anonymous-schema-57>
                stats:
                  type: object
                  required:
                    - volume
                    - high
                    - low
                  properties:
                    volume:
                      description: Volume during last 24h in base currency
                      type: number
                      x-parser-schema-id: <anonymous-schema-59>
                    low:
                      description: Lowest price during 24h
                      type: number
                      x-parser-schema-id: <anonymous-schema-60>
                    high:
                      description: Highest price during 24h
                      type: number
                      x-parser-schema-id: <anonymous-schema-61>
                    price_change:
                      description: >-
                        24-hour price change expressed as a percentage, `null`
                        if there weren't any trades
                      example: 10.23
                      type: number
                      x-parser-schema-id: <anonymous-schema-62>
                    volume_usd:
                      description: Volume in usd (futures only)
                      type: number
                      x-parser-schema-id: <anonymous-schema-63>
                  x-parser-schema-id: <anonymous-schema-58>
                open_interest:
                  description: >-
                    The total amount of outstanding contracts in the
                    corresponding amount units. For perpetual and inverse
                    futures the amount is in USD units. For options and linear
                    futures it is the underlying base currency coin.
                  type: number
                  x-parser-schema-id: <anonymous-schema-64>
                best_bid_price:
                  description: The current best bid price, `null` if there aren't any bids
                  type: number
                  x-parser-schema-id: <anonymous-schema-65>
                best_bid_amount:
                  description: It represents the requested order size of all best bids
                  type: number
                  x-parser-schema-id: <anonymous-schema-66>
                best_ask_price:
                  description: The current best ask price, `null` if there aren't any asks
                  type: number
                  x-parser-schema-id: <anonymous-schema-67>
                best_ask_amount:
                  description: It represents the requested order size of all best asks
                  type: number
                  x-parser-schema-id: <anonymous-schema-68>
                index_price:
                  description: Current index price
                  type: number
                  example: 8247.27
                  x-parser-schema-id: <anonymous-schema-69>
                min_price:
                  description: >-
                    The minimum price for the future. Any sell orders you submit
                    lower than this price will be clamped to this minimum.
                  type: number
                  x-parser-schema-id: <anonymous-schema-70>
                max_price:
                  description: >-
                    The maximum price for the future. Any buy orders you submit
                    higher than this price, will be clamped to this maximum.
                  type: number
                  x-parser-schema-id: <anonymous-schema-71>
                mark_price:
                  description: The mark price for the instrument
                  type: number
                  x-parser-schema-id: <anonymous-schema-72>
                last_price:
                  description: The price for the last trade
                  type: number
                  x-parser-schema-id: <anonymous-schema-73>
                underlying_price:
                  description: >-
                    Underlying price for implied volatility calculations
                    (options only)
                  type: number
                  x-parser-schema-id: <anonymous-schema-74>
                underlying_index:
                  description: >-
                    Name of the underlying future, or `index_price` (options
                    only)
                  type: number
                  x-parser-schema-id: <anonymous-schema-75>
                interest_rate:
                  description: >-
                    Interest rate used in implied volatility calculations
                    (options only)
                  type: number
                  x-parser-schema-id: <anonymous-schema-76>
                bid_iv:
                  description: (Only for option) implied volatility for best bid
                  type: number
                  x-parser-schema-id: <anonymous-schema-77>
                ask_iv:
                  description: (Only for option) implied volatility for best ask
                  type: number
                  x-parser-schema-id: <anonymous-schema-78>
                mark_iv:
                  description: (Only for option) implied volatility for mark price
                  type: number
                  x-parser-schema-id: <anonymous-schema-79>
                greeks:
                  description: >
                    Only for options. Greeks are risk measures that describe how
                    the option's price changes with respect to various factors.


                    **Delta (Δ)**


                    Deribit uses two different Deltas:

                    - **DeltaTotal** in the account summary uses the **Net
                    Transaction Delta (NTD)**

                    - **Delta** for individual option expiries is the **Black
                    Scholes Delta**


                    In the settings section you can toggle Net Transaction Delta
                    instead.


                    **What is DeltaTotal in the account summary?**

                    `DeltaTotal = Net Transaction Delta of options + BTC
                    Position of Futures`


                    **What is Net Transaction Delta?**

                    `Net Transaction Delta = Black Scholes Delta - Mark Price of
                    Options`


                    **Why do we use a Net Transaction Delta?**

                    The Delta Total uses the Net Transaction Delta (or price
                    adjusted Delta) of the options. This is because, from a risk
                    perspective, we are interested in the change in Bitcoin
                    price as the underlying changes.


                    You should actually treat your delta as **Equity + Delta
                    Total** if you want to have less risk for your USD PnL.


                    **Example:** Consider a call option with strike 0, which has
                    a Black Scholes Delta of 1 and Net Transaction Delta = 0.


                    Imagine you have 2 BTC equity and no positions and BTC price
                    is at USD 60k. In that case you would short 2 Futures
                    contracts to hedge your USD exposure to BTC.


                    Now let's say you buy one call with strike 0. The question
                    is if you should sell another future?


                    The call will always have a price of 1 BTC. So you buy it at
                    1 BTC which equates to USD 60k. Let's say the price
                    increases to USD 70k. The value of the call is still 1 BTC.
                    At settlement you receive 1 BTC for the call. So you paid 1
                    BTC and then receive 1 BTC which means your USD PnL on
                    buying the call is 0. If you sold a future on it, then you
                    would actually lose on the future.


                    ⚠️ **During the 30 minute settlement period we decay your
                    Delta.** See [Delta decay during
                    settlement](https://support.deribit.com/hc/en-us/articles/25944751433757-Delta-decay-during-settlement)
                    for more details.


                    **Theta (Θ)**


                    The Theta that Deribit uses is the **minimum of (1 day
                    Theta, lifetime theta of the option)**. So if you take an
                    option with 1 hour to expire for example, generally Black
                    Scholes Theta will give you the equivalent 1 day Theta.
                    Whereas we show the 1 hour Theta, so our Theta would differ
                    from Black Scholes Theta when time to expiry is less than 1
                    day.


                    **Vega, Gamma, and Rho**


                    Vega (not actually a Greek symbol), Gamma, Theta and Rho
                    values shown on Deribit are calculated using **standard
                    Black Scholes without adjustments**.
                  type: object
                  required:
                    - delta
                    - gamma
                    - rho
                    - theta
                    - vega
                  properties:
                    delta:
                      description: >
                        (Only for option) The delta value for the option. This
                        is the **Black Scholes Delta** for individual option
                        expiries. 


                        Note that DeltaTotal in account summary uses Net
                        Transaction Delta instead. See the greeks object
                        description for more details.
                      type: number
                      x-parser-schema-id: <anonymous-schema-81>
                    gamma:
                      description: >
                        (Only for option) The gamma value for the option.
                        Calculated using standard Black Scholes without
                        adjustments.


                        Gamma measures the rate of change of delta with respect
                        to changes in the underlying asset price.
                      type: number
                      x-parser-schema-id: <anonymous-schema-82>
                    rho:
                      description: >
                        (Only for option) The rho value for the option.
                        Calculated using standard Black Scholes without
                        adjustments.


                        Rho measures the sensitivity of the option price to
                        changes in the risk-free interest rate.
                      type: number
                      x-parser-schema-id: <anonymous-schema-83>
                    theta:
                      description: >
                        (Only for option) The theta value for the option.
                        Deribit uses the **minimum of (1 day Theta, lifetime
                        theta of the option)**.


                        So if you take an option with 1 hour to expire for
                        example, generally Black Scholes Theta will give you the
                        equivalent 1 day Theta. Whereas we show the 1 hour
                        Theta, so our Theta would differ from Black Scholes
                        Theta when time to expiry is less than 1 day.


                        Theta measures the rate of change of the option price
                        with respect to time decay.
                      type: number
                      x-parser-schema-id: <anonymous-schema-84>
                    vega:
                      description: >
                        (Only for option) The vega value for the option.
                        Calculated using standard Black Scholes without
                        adjustments.


                        Vega (not actually a Greek symbol) measures the
                        sensitivity of the option price to changes in implied
                        volatility.
                      type: number
                      x-parser-schema-id: <anonymous-schema-85>
                  x-parser-schema-id: <anonymous-schema-80>
                funding_8h:
                  description: Funding 8h (perpetual only)
                  type: number
                  x-parser-schema-id: <anonymous-schema-86>
                current_funding:
                  description: Current funding (perpetual only)
                  type: number
                  x-parser-schema-id: <anonymous-schema-87>
                interest_value:
                  description: >-
                    Value used to calculate `realized_funding` in positions
                    (perpetual only)
                  type: number
                  x-parser-schema-id: <anonymous-schema-88>
                delivery_price:
                  description: >-
                    The settlement price for the instrument. Only when `state =
                    closed`
                  type: number
                  x-parser-schema-id: <anonymous-schema-89>
                settlement_price:
                  description: >-
                    Optional (not added for spot). The settlement price for the
                    instrument. Only when `state = open`
                  type: number
                  x-parser-schema-id: <anonymous-schema-90>
                estimated_delivery_price:
                  description: >-
                    Estimated delivery price for the market. For more details,
                    see Contract Specification > General Documentation >
                    Expiration Price
                  example: 11628.81
                  type: number
                  x-parser-schema-id: <anonymous-schema-91>
              required:
                - instrument_name
                - timestamp
                - state
                - stats
                - open_interest
                - index_price
                - best_bid_price
                - best_bid_amount
                - best_ask_price
                - best_ask_amount
                - min_price
                - max_price
                - mark_price
                - last_price
                - estimated_delivery_price
              additionalProperties: false
              x-parser-schema-id: <anonymous-schema-54>
          required:
            - data
          additionalProperties: false
          x-parser-schema-id: <anonymous-schema-53>
        title: Subscription Notification Data
        description: Server sends subscription notification data
        example: |-
          {
            "data": {
              "best_ask_amount": 100,
              "best_ask_price": 36443,
              "best_bid_amount": 5000,
              "best_bid_price": 36442.5,
              "current_funding": 0,
              "estimated_delivery_price": 36441.64,
              "funding_8h": 0.0000211,
              "index_price": 36441.64,
              "instrument_name": "BTC-PERPETUAL",
              "interest_value": 1.7362511643080387,
              "last_price": 36457.5,
              "mark_price": 36446.51,
              "max_price": 36991.72,
              "min_price": 35898.37,
              "open_interest": 502097590,
              "settlement_price": 36169.49,
              "state": "open",
              "stats": {
                "high": 36824.5,
                "low": 35213.5,
                "price_change": 0.7229,
                "volume": 7871.02139035,
                "volume_usd": 284061480
              },
              "timestamp": 1623060194301
            }
          }
        bindings: []
        extensions:
          - id: x-parser-unique-object-id
            value: subscription_message
    bindings: []
    extensions: &ref_0
      - id: x-parser-unique-object-id
        value: ticker.(instrument_name).(interval)
  - &ref_1
    id: receive_ticker_instrument_name_interval_updates
    title: Receive ticker updates
    description: Client receives ticker update notifications
    type: receive
    messages:
      - &ref_3
        id: subscribe_request
        contentType: application/json
        payload:
          - name: Subscription Request
            description: >-
              Client sends subscription request to subscribe to notification
              channel. Please refer to [Notification
              page](https://deribit.mintlify.app/articles/notifications) for
              more information.
            type: object
            properties: []
        headers: []
        jsonPayloadSchema:
          properties: {}
          additionalProperties: false
          x-parser-schema-id: <anonymous-schema-52>
        title: Subscription Request
        description: >-
          Client sends subscription request to subscribe to notification
          channel. Please refer to [Notification
          page](https://deribit.mintlify.app/articles/notifications) for more
          information.
        example: |-
          {
            "jsonrpc": "2.0",
            "method": "public/subscribe",
            "id": 42,
            "params": {
              "channels": [
                "ticker.BTC-PERPETUAL.100ms"
              ]
            }
          }
        bindings: []
        extensions:
          - id: x-parser-unique-object-id
            value: subscribe_request
    bindings: []
    extensions: *ref_0
sendOperations:
  - *ref_1
receiveOperations:
  - *ref_2
sendMessages:
  - *ref_3
receiveMessages:
  - *ref_4
extensions:
  - id: x-parser-unique-object-id
    value: ticker.(instrument_name).(interval)
securitySchemes: []

````

> ## Documentation Index
> Fetch the complete documentation index at: https://docs.deribit.com/llms.txt
> Use this file to discover all available pages before exploring further.

<AgentInstructions>

## Submitting Feedback

If you encounter incorrect, outdated, or confusing documentation on this page, submit feedback:

POST https://docs.deribit.com/feedback

```json
{
  "path": "/subscriptions/market-data/incremental_tickerinstrument_name",
  "feedback": "Description of the issue"
}
```

Only submit feedback when you have something specific and actionable to report.

</AgentInstructions>

# incremental_ticker.(instrument_name) 

> Real-time ticker updates for an instrument, delivered as a snapshot followed by incremental updates.

- The first notification contains the full ticker snapshot.
- Subsequent notifications contain only fields that changed since the previous update.

This event is sent at most once per second.




## AsyncAPI

````yaml specifications/deribit_asyncapi.json incremental_ticker.(instrument_name)
id: incremental_ticker.(instrument_name)
title: 'incremental_ticker.(instrument_name) '
description: >
  Real-time ticker updates for an instrument, delivered as a snapshot followed
  by incremental updates.


  - The first notification contains the full ticker snapshot.

  - Subsequent notifications contain only fields that changed since the previous
  update.


  This event is sent at most once per second.
servers:
  - id: production
    protocol: wss
    host: deribit.com/ws/api/v2
    bindings: []
    variables: []
  - id: testnet
    protocol: wss
    host: test.deribit.com/ws/api/v2
    bindings: []
    variables: []
address: incremental_ticker.(instrument_name)
parameters:
  - id: instrument_name
    jsonSchema:
      type: string
      description: The name of the instrument
    description: The name of the instrument
    type: string
    required: true
    deprecated: false
bindings: []
operations:
  - &ref_2
    id: send_subscribe_incremental_ticker_instrument_name
    title: Send subscribe request for incremental_ticker
    description: Client sends subscription request for incremental_ticker updates
    type: send
    messages:
      - &ref_4
        id: subscription_message
        contentType: application/json
        payload:
          - name: Subscription Notification Data
            description: Server sends subscription notification data
            type: object
            properties:
              - name: data
                type: object
                required: true
                properties:
                  - name: type
                    type: string
                    description: >-
                      Type of notification: `snapshot` for initial, `change` for
                      others.
                    enumValues:
                      - snapshot
                      - change
                    required: false
                  - name: instrument_name
                    type: string
                    description: Unique instrument identifier
                    required: false
                  - name: timestamp
                    type: integer
                    description: The timestamp (milliseconds since the Unix epoch)
                    required: false
                  - name: state
                    type: string
                    description: >
                      The state of the order book. Represents the current
                      lifecycle stage of the instrument.


                      **State Lifecycle and Meanings:**


                      - `open`: Default state for running books. In this state
                      book is accepting new orders, edits, cancels; prices
                      should be updated, trading is live.

                      - `settlement`: Books enters to this state during
                      settlement/delivery. New orders, edits, cancels are not
                      accepted. After this state normally next state should be
                      `open` if it was settlement, or `delivered` if it was
                      delivery. On enter to this state good till day orders in
                      book are canceled.

                      - `delivered`: Final state of book that has been
                      delivered. New orders, edits, cancels are not accepted.
                      After some time book process will be terminated and,
                      instrument moved to `expired_instruments` and its
                      `instrument_state` will become archivized. On enter to
                      this all open orders in book are canceled.

                      - `inactive`: After a book is deactivated, this state is
                      set on book. New orders, edits, cancels are not accepted.
                      On enter to this all open orders in book are canceled.
                      Book in this state is not considered as open. This can be
                      also final state for book.

                      - `locked`: New orders, edits, are not accepted, only
                      cancels ARE accepted. In some cases when configured books
                      can start as locked or it may become locked on admin
                      request. Settlement is possible on locked books.

                      - `halted`: The state that books enter as a result of an
                      error. Settlement is not possible when there is at least
                      one book in this state.

                      - `archivized`: Set when instrument is moved to
                      `expired_instruments` table, final state.
                    enumValues:
                      - open
                      - settlement
                      - delivered
                      - inactive
                      - locked
                      - halted
                      - archivized
                    required: false
                  - name: stats
                    type: object
                    required: false
                    properties:
                      - name: volume
                        type: number
                        description: Volume during last 24h in base currency
                        required: false
                      - name: low
                        type: number
                        description: Lowest price during 24h
                        required: false
                      - name: high
                        type: number
                        description: Highest price during 24h
                        required: false
                      - name: price_change
                        type: number
                        description: >-
                          24-hour price change expressed as a percentage, `null`
                          if there weren't any trades
                        required: false
                      - name: volume_usd
                        type: number
                        description: Volume in usd (futures only)
                        required: false
                  - name: open_interest
                    type: number
                    description: >-
                      The total amount of outstanding contracts in the
                      corresponding amount units. For perpetual and inverse
                      futures the amount is in USD units. For options and linear
                      futures it is the underlying base currency coin.
                    required: false
                  - name: best_bid_price
                    type: number
                    description: >-
                      The current best bid price, `null` if there aren't any
                      bids
                    required: false
                  - name: best_bid_amount
                    type: number
                    description: It represents the requested order size of all best bids
                    required: false
                  - name: best_ask_price
                    type: number
                    description: >-
                      The current best ask price, `null` if there aren't any
                      asks
                    required: false
                  - name: best_ask_amount
                    type: number
                    description: It represents the requested order size of all best asks
                    required: false
                  - name: index_price
                    type: number
                    description: Current index price
                    required: false
                  - name: min_price
                    type: number
                    description: >-
                      The minimum price for the future. Any sell orders you
                      submit lower than this price will be clamped to this
                      minimum.
                    required: false
                  - name: max_price
                    type: number
                    description: >-
                      The maximum price for the future. Any buy orders you
                      submit higher than this price, will be clamped to this
                      maximum.
                    required: false
                  - name: mark_price
                    type: number
                    description: The mark price for the instrument
                    required: false
                  - name: last_price
                    type: number
                    description: The price for the last trade
                    required: false
                  - name: underlying_price
                    type: number
                    description: >-
                      Underlying price for implied volatility calculations
                      (options only)
                    required: false
                  - name: underlying_index
                    type: number
                    description: >-
                      Name of the underlying future, or `index_price` (options
                      only)
                    required: false
                  - name: interest_rate
                    type: number
                    description: >-
                      Interest rate used in implied volatility calculations
                      (options only)
                    required: false
                  - name: bid_iv
                    type: number
                    description: (Only for option) implied volatility for best bid
                    required: false
                  - name: ask_iv
                    type: number
                    description: (Only for option) implied volatility for best ask
                    required: false
                  - name: mark_iv
                    type: number
                    description: (Only for option) implied volatility for mark price
                    required: false
                  - name: greeks
                    type: object
                    description: >
                      Only for options. Greeks are risk measures that describe
                      how the option's price changes with respect to various
                      factors.


                      **Delta (Δ)**


                      Deribit uses two different Deltas:

                      - **DeltaTotal** in the account summary uses the **Net
                      Transaction Delta (NTD)**

                      - **Delta** for individual option expiries is the **Black
                      Scholes Delta**


                      In the settings section you can toggle Net Transaction
                      Delta instead.


                      **What is DeltaTotal in the account summary?**

                      `DeltaTotal = Net Transaction Delta of options + BTC
                      Position of Futures`


                      **What is Net Transaction Delta?**

                      `Net Transaction Delta = Black Scholes Delta - Mark Price
                      of Options`


                      **Why do we use a Net Transaction Delta?**

                      The Delta Total uses the Net Transaction Delta (or price
                      adjusted Delta) of the options. This is because, from a
                      risk perspective, we are interested in the change in
                      Bitcoin price as the underlying changes.


                      You should actually treat your delta as **Equity + Delta
                      Total** if you want to have less risk for your USD PnL.


                      **Example:** Consider a call option with strike 0, which
                      has a Black Scholes Delta of 1 and Net Transaction Delta =
                      0.


                      Imagine you have 2 BTC equity and no positions and BTC
                      price is at USD 60k. In that case you would short 2
                      Futures contracts to hedge your USD exposure to BTC.


                      Now let's say you buy one call with strike 0. The question
                      is if you should sell another future?


                      The call will always have a price of 1 BTC. So you buy it
                      at 1 BTC which equates to USD 60k. Let's say the price
                      increases to USD 70k. The value of the call is still 1
                      BTC. At settlement you receive 1 BTC for the call. So you
                      paid 1 BTC and then receive 1 BTC which means your USD PnL
                      on buying the call is 0. If you sold a future on it, then
                      you would actually lose on the future.


                      ⚠️ **During the 30 minute settlement period we decay your
                      Delta.** See [Delta decay during
                      settlement](https://support.deribit.com/hc/en-us/articles/25944751433757-Delta-decay-during-settlement)
                      for more details.


                      **Theta (Θ)**


                      The Theta that Deribit uses is the **minimum of (1 day
                      Theta, lifetime theta of the option)**. So if you take an
                      option with 1 hour to expire for example, generally Black
                      Scholes Theta will give you the equivalent 1 day Theta.
                      Whereas we show the 1 hour Theta, so our Theta would
                      differ from Black Scholes Theta when time to expiry is
                      less than 1 day.


                      **Vega, Gamma, and Rho**


                      Vega (not actually a Greek symbol), Gamma, Theta and Rho
                      values shown on Deribit are calculated using **standard
                      Black Scholes without adjustments**.
                    required: false
                    properties:
                      - name: delta
                        type: number
                        description: >
                          (Only for option) The delta value for the option. This
                          is the **Black Scholes Delta** for individual option
                          expiries. 


                          Note that DeltaTotal in account summary uses Net
                          Transaction Delta instead. See the greeks object
                          description for more details.
                        required: false
                      - name: gamma
                        type: number
                        description: >
                          (Only for option) The gamma value for the option.
                          Calculated using standard Black Scholes without
                          adjustments.


                          Gamma measures the rate of change of delta with
                          respect to changes in the underlying asset price.
                        required: false
                      - name: rho
                        type: number
                        description: >
                          (Only for option) The rho value for the option.
                          Calculated using standard Black Scholes without
                          adjustments.


                          Rho measures the sensitivity of the option price to
                          changes in the risk-free interest rate.
                        required: false
                      - name: theta
                        type: number
                        description: >
                          (Only for option) The theta value for the option.
                          Deribit uses the **minimum of (1 day Theta, lifetime
                          theta of the option)**.


                          So if you take an option with 1 hour to expire for
                          example, generally Black Scholes Theta will give you
                          the equivalent 1 day Theta. Whereas we show the 1 hour
                          Theta, so our Theta would differ from Black Scholes
                          Theta when time to expiry is less than 1 day.


                          Theta measures the rate of change of the option price
                          with respect to time decay.
                        required: false
                      - name: vega
                        type: number
                        description: >
                          (Only for option) The vega value for the option.
                          Calculated using standard Black Scholes without
                          adjustments.


                          Vega (not actually a Greek symbol) measures the
                          sensitivity of the option price to changes in implied
                          volatility.
                        required: false
                  - name: funding_8h
                    type: number
                    description: Funding 8h (perpetual only)
                    required: false
                  - name: current_funding
                    type: number
                    description: Current funding (perpetual only)
                    required: false
                  - name: delivery_price
                    type: number
                    description: >-
                      The settlement price for the instrument. Only when `state
                      = closed`
                    required: false
                  - name: settlement_price
                    type: number
                    description: >-
                      Optional (not added for spot). The settlement price for
                      the instrument. Only when `state = open`
                    required: false
                  - name: estimated_delivery_price
                    type: number
                    description: >-
                      Estimated delivery price for the market. For more details,
                      see Contract Specification > General Documentation >
                      Expiration Price
                    required: false
        headers: []
        jsonPayloadSchema:
          type: object
          description: Response containing notification data
          properties:
            data:
              type: object
              properties:
                type:
                  type: string
                  description: >-
                    Type of notification: `snapshot` for initial, `change` for
                    others.
                  enum:
                    - snapshot
                    - change
                  x-parser-schema-id: <anonymous-schema-96>
                instrument_name:
                  type: string
                  description: Unique instrument identifier
                  example: BTC-PERPETUAL
                  x-parser-schema-id: <anonymous-schema-97>
                timestamp:
                  type: integer
                  example: 1536569522277
                  description: The timestamp (milliseconds since the Unix epoch)
                  x-parser-schema-id: <anonymous-schema-98>
                state:
                  description: >
                    The state of the order book. Represents the current
                    lifecycle stage of the instrument.


                    **State Lifecycle and Meanings:**


                    - `open`: Default state for running books. In this state
                    book is accepting new orders, edits, cancels; prices should
                    be updated, trading is live.

                    - `settlement`: Books enters to this state during
                    settlement/delivery. New orders, edits, cancels are not
                    accepted. After this state normally next state should be
                    `open` if it was settlement, or `delivered` if it was
                    delivery. On enter to this state good till day orders in
                    book are canceled.

                    - `delivered`: Final state of book that has been delivered.
                    New orders, edits, cancels are not accepted. After some time
                    book process will be terminated and, instrument moved to
                    `expired_instruments` and its `instrument_state` will become
                    archivized. On enter to this all open orders in book are
                    canceled.

                    - `inactive`: After a book is deactivated, this state is set
                    on book. New orders, edits, cancels are not accepted. On
                    enter to this all open orders in book are canceled. Book in
                    this state is not considered as open. This can be also final
                    state for book.

                    - `locked`: New orders, edits, are not accepted, only
                    cancels ARE accepted. In some cases when configured books
                    can start as locked or it may become locked on admin
                    request. Settlement is possible on locked books.

                    - `halted`: The state that books enter as a result of an
                    error. Settlement is not possible when there is at least one
                    book in this state.

                    - `archivized`: Set when instrument is moved to
                    `expired_instruments` table, final state.
                  type: string
                  enum:
                    - open
                    - settlement
                    - delivered
                    - inactive
                    - locked
                    - halted
                    - archivized
                  x-parser-schema-id: <anonymous-schema-99>
                stats:
                  type: object
                  required:
                    - volume
                    - high
                    - low
                  properties:
                    volume:
                      description: Volume during last 24h in base currency
                      type: number
                      x-parser-schema-id: <anonymous-schema-101>
                    low:
                      description: Lowest price during 24h
                      type: number
                      x-parser-schema-id: <anonymous-schema-102>
                    high:
                      description: Highest price during 24h
                      type: number
                      x-parser-schema-id: <anonymous-schema-103>
                    price_change:
                      description: >-
                        24-hour price change expressed as a percentage, `null`
                        if there weren't any trades
                      example: 10.23
                      type: number
                      x-parser-schema-id: <anonymous-schema-104>
                    volume_usd:
                      description: Volume in usd (futures only)
                      type: number
                      x-parser-schema-id: <anonymous-schema-105>
                  x-parser-schema-id: <anonymous-schema-100>
                open_interest:
                  description: >-
                    The total amount of outstanding contracts in the
                    corresponding amount units. For perpetual and inverse
                    futures the amount is in USD units. For options and linear
                    futures it is the underlying base currency coin.
                  type: number
                  x-parser-schema-id: <anonymous-schema-106>
                best_bid_price:
                  description: The current best bid price, `null` if there aren't any bids
                  type: number
                  x-parser-schema-id: <anonymous-schema-107>
                best_bid_amount:
                  description: It represents the requested order size of all best bids
                  type: number
                  x-parser-schema-id: <anonymous-schema-108>
                best_ask_price:
                  description: The current best ask price, `null` if there aren't any asks
                  type: number
                  x-parser-schema-id: <anonymous-schema-109>
                best_ask_amount:
                  description: It represents the requested order size of all best asks
                  type: number
                  x-parser-schema-id: <anonymous-schema-110>
                index_price:
                  description: Current index price
                  type: number
                  example: 8247.27
                  x-parser-schema-id: <anonymous-schema-111>
                min_price:
                  description: >-
                    The minimum price for the future. Any sell orders you submit
                    lower than this price will be clamped to this minimum.
                  type: number
                  x-parser-schema-id: <anonymous-schema-112>
                max_price:
                  description: >-
                    The maximum price for the future. Any buy orders you submit
                    higher than this price, will be clamped to this maximum.
                  type: number
                  x-parser-schema-id: <anonymous-schema-113>
                mark_price:
                  description: The mark price for the instrument
                  type: number
                  x-parser-schema-id: <anonymous-schema-114>
                last_price:
                  description: The price for the last trade
                  type: number
                  x-parser-schema-id: <anonymous-schema-115>
                underlying_price:
                  description: >-
                    Underlying price for implied volatility calculations
                    (options only)
                  type: number
                  x-parser-schema-id: <anonymous-schema-116>
                underlying_index:
                  description: >-
                    Name of the underlying future, or `index_price` (options
                    only)
                  type: number
                  x-parser-schema-id: <anonymous-schema-117>
                interest_rate:
                  description: >-
                    Interest rate used in implied volatility calculations
                    (options only)
                  type: number
                  x-parser-schema-id: <anonymous-schema-118>
                bid_iv:
                  description: (Only for option) implied volatility for best bid
                  type: number
                  x-parser-schema-id: <anonymous-schema-119>
                ask_iv:
                  description: (Only for option) implied volatility for best ask
                  type: number
                  x-parser-schema-id: <anonymous-schema-120>
                mark_iv:
                  description: (Only for option) implied volatility for mark price
                  type: number
                  x-parser-schema-id: <anonymous-schema-121>
                greeks:
                  description: >
                    Only for options. Greeks are risk measures that describe how
                    the option's price changes with respect to various factors.


                    **Delta (Δ)**


                    Deribit uses two different Deltas:

                    - **DeltaTotal** in the account summary uses the **Net
                    Transaction Delta (NTD)**

                    - **Delta** for individual option expiries is the **Black
                    Scholes Delta**


                    In the settings section you can toggle Net Transaction Delta
                    instead.


                    **What is DeltaTotal in the account summary?**

                    `DeltaTotal = Net Transaction Delta of options + BTC
                    Position of Futures`


                    **What is Net Transaction Delta?**

                    `Net Transaction Delta = Black Scholes Delta - Mark Price of
                    Options`


                    **Why do we use a Net Transaction Delta?**

                    The Delta Total uses the Net Transaction Delta (or price
                    adjusted Delta) of the options. This is because, from a risk
                    perspective, we are interested in the change in Bitcoin
                    price as the underlying changes.


                    You should actually treat your delta as **Equity + Delta
                    Total** if you want to have less risk for your USD PnL.


                    **Example:** Consider a call option with strike 0, which has
                    a Black Scholes Delta of 1 and Net Transaction Delta = 0.


                    Imagine you have 2 BTC equity and no positions and BTC price
                    is at USD 60k. In that case you would short 2 Futures
                    contracts to hedge your USD exposure to BTC.


                    Now let's say you buy one call with strike 0. The question
                    is if you should sell another future?


                    The call will always have a price of 1 BTC. So you buy it at
                    1 BTC which equates to USD 60k. Let's say the price
                    increases to USD 70k. The value of the call is still 1 BTC.
                    At settlement you receive 1 BTC for the call. So you paid 1
                    BTC and then receive 1 BTC which means your USD PnL on
                    buying the call is 0. If you sold a future on it, then you
                    would actually lose on the future.


                    ⚠️ **During the 30 minute settlement period we decay your
                    Delta.** See [Delta decay during
                    settlement](https://support.deribit.com/hc/en-us/articles/25944751433757-Delta-decay-during-settlement)
                    for more details.


                    **Theta (Θ)**


                    The Theta that Deribit uses is the **minimum of (1 day
                    Theta, lifetime theta of the option)**. So if you take an
                    option with 1 hour to expire for example, generally Black
                    Scholes Theta will give you the equivalent 1 day Theta.
                    Whereas we show the 1 hour Theta, so our Theta would differ
                    from Black Scholes Theta when time to expiry is less than 1
                    day.


                    **Vega, Gamma, and Rho**


                    Vega (not actually a Greek symbol), Gamma, Theta and Rho
                    values shown on Deribit are calculated using **standard
                    Black Scholes without adjustments**.
                  type: object
                  required:
                    - delta
                    - gamma
                    - rho
                    - theta
                    - vega
                  properties:
                    delta:
                      description: >
                        (Only for option) The delta value for the option. This
                        is the **Black Scholes Delta** for individual option
                        expiries. 


                        Note that DeltaTotal in account summary uses Net
                        Transaction Delta instead. See the greeks object
                        description for more details.
                      type: number
                      x-parser-schema-id: <anonymous-schema-123>
                    gamma:
                      description: >
                        (Only for option) The gamma value for the option.
                        Calculated using standard Black Scholes without
                        adjustments.


                        Gamma measures the rate of change of delta with respect
                        to changes in the underlying asset price.
                      type: number
                      x-parser-schema-id: <anonymous-schema-124>
                    rho:
                      description: >
                        (Only for option) The rho value for the option.
                        Calculated using standard Black Scholes without
                        adjustments.


                        Rho measures the sensitivity of the option price to
                        changes in the risk-free interest rate.
                      type: number
                      x-parser-schema-id: <anonymous-schema-125>
                    theta:
                      description: >
                        (Only for option) The theta value for the option.
                        Deribit uses the **minimum of (1 day Theta, lifetime
                        theta of the option)**.


                        So if you take an option with 1 hour to expire for
                        example, generally Black Scholes Theta will give you the
                        equivalent 1 day Theta. Whereas we show the 1 hour
                        Theta, so our Theta would differ from Black Scholes
                        Theta when time to expiry is less than 1 day.


                        Theta measures the rate of change of the option price
                        with respect to time decay.
                      type: number
                      x-parser-schema-id: <anonymous-schema-126>
                    vega:
                      description: >
                        (Only for option) The vega value for the option.
                        Calculated using standard Black Scholes without
                        adjustments.


                        Vega (not actually a Greek symbol) measures the
                        sensitivity of the option price to changes in implied
                        volatility.
                      type: number
                      x-parser-schema-id: <anonymous-schema-127>
                  x-parser-schema-id: <anonymous-schema-122>
                funding_8h:
                  description: Funding 8h (perpetual only)
                  type: number
                  x-parser-schema-id: <anonymous-schema-128>
                current_funding:
                  description: Current funding (perpetual only)
                  type: number
                  x-parser-schema-id: <anonymous-schema-129>
                delivery_price:
                  description: >-
                    The settlement price for the instrument. Only when `state =
                    closed`
                  type: number
                  x-parser-schema-id: <anonymous-schema-130>
                settlement_price:
                  description: >-
                    Optional (not added for spot). The settlement price for the
                    instrument. Only when `state = open`
                  type: number
                  x-parser-schema-id: <anonymous-schema-131>
                estimated_delivery_price:
                  description: >-
                    Estimated delivery price for the market. For more details,
                    see Contract Specification > General Documentation >
                    Expiration Price
                  example: 11628.81
                  type: number
                  x-parser-schema-id: <anonymous-schema-132>
              required:
                - instrument_name
                - timestamp
              additionalProperties: false
              x-parser-schema-id: <anonymous-schema-95>
          required:
            - data
          additionalProperties: false
          x-parser-schema-id: <anonymous-schema-94>
        title: Subscription Notification Data
        description: Server sends subscription notification data
        example: |-
          {
            "data": {
              "type": "snapshot",
              "best_ask_amount": 100,
              "best_ask_price": 36443,
              "best_bid_amount": 5000,
              "best_bid_price": 36442.5,
              "current_funding": 0,
              "estimated_delivery_price": 36441.64,
              "funding_8h": 0.0000211,
              "index_price": 36441.64,
              "instrument_name": "BTC-PERPETUAL",
              "last_price": 36457.5,
              "mark_price": 36446.51,
              "max_price": 36991.72,
              "min_price": 35898.37,
              "open_interest": 502097590,
              "settlement_price": 36169.49,
              "state": "open",
              "stats": {
                "high": 36824.5,
                "low": 35213.5,
                "price_change": 0.7229,
                "volume": 7871.02139035,
                "volume_usd": 284061480
              },
              "timestamp": 1623060194301
            }
          }
        bindings: []
        extensions:
          - id: x-parser-unique-object-id
            value: subscription_message
    bindings: []
    extensions: &ref_0
      - id: x-parser-unique-object-id
        value: incremental_ticker.(instrument_name)
  - &ref_1
    id: receive_incremental_ticker_instrument_name_updates
    title: Receive incremental_ticker updates
    description: Client receives incremental_ticker update notifications
    type: receive
    messages:
      - &ref_3
        id: subscribe_request
        contentType: application/json
        payload:
          - name: Subscription Request
            description: >-
              Client sends subscription request to subscribe to notification
              channel. Please refer to [Notification
              page](https://deribit.mintlify.app/articles/notifications) for
              more information.
            type: object
            properties: []
        headers: []
        jsonPayloadSchema:
          properties: {}
          additionalProperties: false
          x-parser-schema-id: <anonymous-schema-93>
        title: Subscription Request
        description: >-
          Client sends subscription request to subscribe to notification
          channel. Please refer to [Notification
          page](https://deribit.mintlify.app/articles/notifications) for more
          information.
        example: |-
          {
            "jsonrpc": "2.0",
            "method": "public/subscribe",
            "id": 42,
            "params": {
              "channels": [
                "incremental_ticker.BTC-PERPETUAL"
              ]
            }
          }
        bindings: []
        extensions:
          - id: x-parser-unique-object-id
            value: subscribe_request
    bindings: []
    extensions: *ref_0
sendOperations:
  - *ref_1
receiveOperations:
  - *ref_2
sendMessages:
  - *ref_3
receiveMessages:
  - *ref_4
extensions:
  - id: x-parser-unique-object-id
    value: incremental_ticker.(instrument_name)
securitySchemes: []

````

> ## Documentation Index
> Fetch the complete documentation index at: https://docs.deribit.com/llms.txt
> Use this file to discover all available pages before exploring further.

<AgentInstructions>

## Submitting Feedback

If you encounter incorrect, outdated, or confusing documentation on this page, submit feedback:

POST https://docs.deribit.com/feedback

```json
{
  "path": "/subscriptions/market-data/perpetualinstrument_nameinterval",
  "feedback": "Description of the issue"
}
```

Only submit feedback when you have something specific and actionable to report.

</AgentInstructions>

# perpetual.(instrument_name).(interval) 

> Provide current interest rate - but only for **perpetual** instruments. Other types won't generate any notification.



## AsyncAPI

````yaml specifications/deribit_asyncapi.json perpetual.(instrument_name).(interval)
id: perpetual.(instrument_name).(interval)
title: 'perpetual.(instrument_name).(interval) '
description: >-
  Provide current interest rate - but only for **perpetual** instruments. Other
  types won't generate any notification.
servers:
  - id: production
    protocol: wss
    host: deribit.com/ws/api/v2
    bindings: []
    variables: []
  - id: testnet
    protocol: wss
    host: test.deribit.com/ws/api/v2
    bindings: []
    variables: []
address: perpetual.(instrument_name).(interval)
parameters:
  - id: instrument_name
    jsonSchema:
      type: string
      description: The name of the instrument
    description: The name of the instrument
    type: string
    required: true
    deprecated: false
  - id: interval
    jsonSchema:
      type: string
      description: >-
        Frequency of notifications. Events will be aggregated over this
        interval. The value `raw` means no aggregation will be applied **(Please
        note that `raw` interval is only available to authorized users)**


        **Allowed values:** `raw`, `100ms`, `agg2`
      enum:
        - raw
        - 100ms
        - agg2
    description: >-
      Frequency of notifications. Events will be aggregated over this interval.
      The value `raw` means no aggregation will be applied **(Please note that
      `raw` interval is only available to authorized users)**


      **Allowed values:** `raw`, `100ms`, `agg2`
    type: string
    required: true
    deprecated: false
bindings: []
operations:
  - &ref_2
    id: send_subscribe_perpetual_instrument_name_interval
    title: Send subscribe request for perpetual
    description: Client sends subscription request for perpetual updates
    type: send
    messages:
      - &ref_4
        id: subscription_message
        contentType: application/json
        payload:
          - name: Subscription Notification Data
            description: Server sends subscription notification data
            type: object
            properties:
              - name: data
                type: object
                required: true
                properties:
                  - name: interest
                    type: number
                    description: Current interest
                    required: false
                  - name: timestamp
                    type: integer
                    description: The timestamp (milliseconds since the Unix epoch)
                    required: false
                  - name: index_price
                    type: number
                    description: Current index price
                    required: false
        headers: []
        jsonPayloadSchema:
          type: object
          description: Response containing notification data
          properties:
            data:
              type: object
              properties:
                interest:
                  type: number
                  description: Current interest
                  x-parser-schema-id: <anonymous-schema-138>
                timestamp:
                  type: integer
                  example: 1536569522277
                  description: The timestamp (milliseconds since the Unix epoch)
                  x-parser-schema-id: <anonymous-schema-139>
                index_price:
                  description: Current index price
                  type: number
                  example: 8247.27
                  x-parser-schema-id: <anonymous-schema-140>
              required:
                - interest
                - timestamp
                - index_price
              additionalProperties: false
              x-parser-schema-id: <anonymous-schema-137>
          required:
            - data
          additionalProperties: false
          x-parser-schema-id: <anonymous-schema-136>
        title: Subscription Notification Data
        description: Server sends subscription notification data
        example: |-
          {
            "data": {
              "interest": 0.004999511380756577,
              "timestamp": 1571386349530,
              "index_price": 7872.88
            }
          }
        bindings: []
        extensions:
          - id: x-parser-unique-object-id
            value: subscription_message
    bindings: []
    extensions: &ref_0
      - id: x-parser-unique-object-id
        value: perpetual.(instrument_name).(interval)
  - &ref_1
    id: receive_perpetual_instrument_name_interval_updates
    title: Receive perpetual updates
    description: Client receives perpetual update notifications
    type: receive
    messages:
      - &ref_3
        id: subscribe_request
        contentType: application/json
        payload:
          - name: Subscription Request
            description: >-
              Client sends subscription request to subscribe to notification
              channel. Please refer to [Notification
              page](https://deribit.mintlify.app/articles/notifications) for
              more information.
            type: object
            properties: []
        headers: []
        jsonPayloadSchema:
          properties: {}
          additionalProperties: false
          x-parser-schema-id: <anonymous-schema-135>
        title: Subscription Request
        description: >-
          Client sends subscription request to subscribe to notification
          channel. Please refer to [Notification
          page](https://deribit.mintlify.app/articles/notifications) for more
          information.
        example: |-
          {
            "jsonrpc": "2.0",
            "method": "public/subscribe",
            "id": 42,
            "params": {
              "channels": [
                "perpetual.BTC-PERPETUAL.100ms"
              ]
            }
          }
        bindings: []
        extensions:
          - id: x-parser-unique-object-id
            value: subscribe_request
    bindings: []
    extensions: *ref_0
sendOperations:
  - *ref_1
receiveOperations:
  - *ref_2
sendMessages:
  - *ref_3
receiveMessages:
  - *ref_4
extensions:
  - id: x-parser-unique-object-id
    value: perpetual.(instrument_name).(interval)
securitySchemes: []

````
> ## Documentation Index
> Fetch the complete documentation index at: https://docs.deribit.com/llms.txt
> Use this file to discover all available pages before exploring further.

<AgentInstructions>

## Submitting Feedback

If you encounter incorrect, outdated, or confusing documentation on this page, submit feedback:

POST https://docs.deribit.com/feedback

```json
{
  "path": "/subscriptions/market-data/perpetualinstrument_nameinterval",
  "feedback": "Description of the issue"
}
```

Only submit feedback when you have something specific and actionable to report.

</AgentInstructions>

# perpetual.(instrument_name).(interval) 

> Provide current interest rate - but only for **perpetual** instruments. Other types won't generate any notification.



## AsyncAPI

````yaml specifications/deribit_asyncapi.json perpetual.(instrument_name).(interval)
id: perpetual.(instrument_name).(interval)
title: 'perpetual.(instrument_name).(interval) '
description: >-
  Provide current interest rate - but only for **perpetual** instruments. Other
  types won't generate any notification.
servers:
  - id: production
    protocol: wss
    host: deribit.com/ws/api/v2
    bindings: []
    variables: []
  - id: testnet
    protocol: wss
    host: test.deribit.com/ws/api/v2
    bindings: []
    variables: []
address: perpetual.(instrument_name).(interval)
parameters:
  - id: instrument_name
    jsonSchema:
      type: string
      description: The name of the instrument
    description: The name of the instrument
    type: string
    required: true
    deprecated: false
  - id: interval
    jsonSchema:
      type: string
      description: >-
        Frequency of notifications. Events will be aggregated over this
        interval. The value `raw` means no aggregation will be applied **(Please
        note that `raw` interval is only available to authorized users)**


        **Allowed values:** `raw`, `100ms`, `agg2`
      enum:
        - raw
        - 100ms
        - agg2
    description: >-
      Frequency of notifications. Events will be aggregated over this interval.
      The value `raw` means no aggregation will be applied **(Please note that
      `raw` interval is only available to authorized users)**


      **Allowed values:** `raw`, `100ms`, `agg2`
    type: string
    required: true
    deprecated: false
bindings: []
operations:
  - &ref_2
    id: send_subscribe_perpetual_instrument_name_interval
    title: Send subscribe request for perpetual
    description: Client sends subscription request for perpetual updates
    type: send
    messages:
      - &ref_4
        id: subscription_message
        contentType: application/json
        payload:
          - name: Subscription Notification Data
            description: Server sends subscription notification data
            type: object
            properties:
              - name: data
                type: object
                required: true
                properties:
                  - name: interest
                    type: number
                    description: Current interest
                    required: false
                  - name: timestamp
                    type: integer
                    description: The timestamp (milliseconds since the Unix epoch)
                    required: false
                  - name: index_price
                    type: number
                    description: Current index price
                    required: false
        headers: []
        jsonPayloadSchema:
          type: object
          description: Response containing notification data
          properties:
            data:
              type: object
              properties:
                interest:
                  type: number
                  description: Current interest
                  x-parser-schema-id: <anonymous-schema-138>
                timestamp:
                  type: integer
                  example: 1536569522277
                  description: The timestamp (milliseconds since the Unix epoch)
                  x-parser-schema-id: <anonymous-schema-139>
                index_price:
                  description: Current index price
                  type: number
                  example: 8247.27
                  x-parser-schema-id: <anonymous-schema-140>
              required:
                - interest
                - timestamp
                - index_price
              additionalProperties: false
              x-parser-schema-id: <anonymous-schema-137>
          required:
            - data
          additionalProperties: false
          x-parser-schema-id: <anonymous-schema-136>
        title: Subscription Notification Data
        description: Server sends subscription notification data
        example: |-
          {
            "data": {
              "interest": 0.004999511380756577,
              "timestamp": 1571386349530,
              "index_price": 7872.88
            }
          }
        bindings: []
        extensions:
          - id: x-parser-unique-object-id
            value: subscription_message
    bindings: []
    extensions: &ref_0
      - id: x-parser-unique-object-id
        value: perpetual.(instrument_name).(interval)
  - &ref_1
    id: receive_perpetual_instrument_name_interval_updates
    title: Receive perpetual updates
    description: Client receives perpetual update notifications
    type: receive
    messages:
      - &ref_3
        id: subscribe_request
        contentType: application/json
        payload:
          - name: Subscription Request
            description: >-
              Client sends subscription request to subscribe to notification
              channel. Please refer to [Notification
              page](https://deribit.mintlify.app/articles/notifications) for
              more information.
            type: object
            properties: []
        headers: []
        jsonPayloadSchema:
          properties: {}
          additionalProperties: false
          x-parser-schema-id: <anonymous-schema-135>
        title: Subscription Request
        description: >-
          Client sends subscription request to subscribe to notification
          channel. Please refer to [Notification
          page](https://deribit.mintlify.app/articles/notifications) for more
          information.
        example: |-
          {
            "jsonrpc": "2.0",
            "method": "public/subscribe",
            "id": 42,
            "params": {
              "channels": [
                "perpetual.BTC-PERPETUAL.100ms"
              ]
            }
          }
        bindings: []
        extensions:
          - id: x-parser-unique-object-id
            value: subscribe_request
    bindings: []
    extensions: *ref_0
sendOperations:
  - *ref_1
receiveOperations:
  - *ref_2
sendMessages:
  - *ref_3
receiveMessages:
  - *ref_4
extensions:
  - id: x-parser-unique-object-id
    value: perpetual.(instrument_name).(interval)
securitySchemes: []

````

> ## Documentation Index
> Fetch the complete documentation index at: https://docs.deribit.com/llms.txt
> Use this file to discover all available pages before exploring further.

<AgentInstructions>

## Submitting Feedback

If you encounter incorrect, outdated, or confusing documentation on this page, submit feedback:

POST https://docs.deribit.com/feedback

```json
{
  "path": "/subscriptions/market-data/quoteinstrument_name",
  "feedback": "Description of the issue"
}
```

Only submit feedback when you have something specific and actionable to report.

</AgentInstructions>

# quote.(instrument_name) 

> Best bid/ask price and size for a specific instrument.

This subscription provides top-of-book updates (best bid and best ask) without the full depth of the order book. Use it when you only need the current spread and top sizes.




## AsyncAPI

````yaml specifications/deribit_asyncapi.json quote.(instrument_name)
id: quote.(instrument_name)
title: 'quote.(instrument_name) '
description: >
  Best bid/ask price and size for a specific instrument.


  This subscription provides top-of-book updates (best bid and best ask) without
  the full depth of the order book. Use it when you only need the current spread
  and top sizes.
servers:
  - id: production
    protocol: wss
    host: deribit.com/ws/api/v2
    bindings: []
    variables: []
  - id: testnet
    protocol: wss
    host: test.deribit.com/ws/api/v2
    bindings: []
    variables: []
address: quote.(instrument_name)
parameters:
  - id: instrument_name
    jsonSchema:
      type: string
      description: The name of the instrument
    description: The name of the instrument
    type: string
    required: true
    deprecated: false
bindings: []
operations:
  - &ref_2
    id: send_subscribe_quote_instrument_name
    title: Send subscribe request for quote
    description: Client sends subscription request for quote updates
    type: send
    messages:
      - &ref_4
        id: subscription_message
        contentType: application/json
        payload:
          - name: Subscription Notification Data
            description: Server sends subscription notification data
            type: object
            properties:
              - name: data
                type: object
                required: true
                properties:
                  - name: timestamp
                    type: integer
                    description: The timestamp (milliseconds since the Unix epoch)
                    required: false
                  - name: instrument_name
                    type: string
                    description: Unique instrument identifier
                    required: false
                  - name: best_bid_price
                    type: number
                    description: >-
                      The current best bid price, `null` if there aren't any
                      bids
                    required: false
                  - name: best_bid_amount
                    type: number
                    description: It represents the requested order size of all best bids
                    required: false
                  - name: best_ask_price
                    type: number
                    description: >-
                      The current best ask price, `null` if there aren't any
                      asks
                    required: false
                  - name: best_ask_amount
                    type: number
                    description: It represents the requested order size of all best asks
                    required: false
        headers: []
        jsonPayloadSchema:
          type: object
          description: Response containing notification data
          properties:
            data:
              type: object
              properties:
                timestamp:
                  type: integer
                  example: 1536569522277
                  description: The timestamp (milliseconds since the Unix epoch)
                  x-parser-schema-id: <anonymous-schema-145>
                instrument_name:
                  type: string
                  description: Unique instrument identifier
                  example: BTC-PERPETUAL
                  x-parser-schema-id: <anonymous-schema-146>
                best_bid_price:
                  description: The current best bid price, `null` if there aren't any bids
                  type: number
                  x-parser-schema-id: <anonymous-schema-147>
                best_bid_amount:
                  description: It represents the requested order size of all best bids
                  type: number
                  x-parser-schema-id: <anonymous-schema-148>
                best_ask_price:
                  description: The current best ask price, `null` if there aren't any asks
                  type: number
                  x-parser-schema-id: <anonymous-schema-149>
                best_ask_amount:
                  description: It represents the requested order size of all best asks
                  type: number
                  x-parser-schema-id: <anonymous-schema-150>
              required:
                - timestamp
                - instrument_name
                - best_bid_amount
                - best_bid_price
                - best_add_amount
                - best_add_price
              additionalProperties: false
              x-parser-schema-id: <anonymous-schema-144>
          required:
            - data
          additionalProperties: false
          x-parser-schema-id: <anonymous-schema-143>
        title: Subscription Notification Data
        description: Server sends subscription notification data
        example: |-
          {
            "data": {
              "best_ask_amount": 50,
              "best_ask_price": 3996.61,
              "best_bid_amount": 40,
              "best_bid_price": 3914.97,
              "instrument_name": "BTC-PERPETUAL",
              "timestamp": 1550658624149
            }
          }
        bindings: []
        extensions:
          - id: x-parser-unique-object-id
            value: subscription_message
    bindings: []
    extensions: &ref_0
      - id: x-parser-unique-object-id
        value: quote.(instrument_name)
  - &ref_1
    id: receive_quote_instrument_name_updates
    title: Receive quote updates
    description: Client receives quote update notifications
    type: receive
    messages:
      - &ref_3
        id: subscribe_request
        contentType: application/json
        payload:
          - name: Subscription Request
            description: >-
              Client sends subscription request to subscribe to notification
              channel. Please refer to [Notification
              page](https://deribit.mintlify.app/articles/notifications) for
              more information.
            type: object
            properties: []
        headers: []
        jsonPayloadSchema:
          properties: {}
          additionalProperties: false
          x-parser-schema-id: <anonymous-schema-142>
        title: Subscription Request
        description: >-
          Client sends subscription request to subscribe to notification
          channel. Please refer to [Notification
          page](https://deribit.mintlify.app/articles/notifications) for more
          information.
        example: |-
          {
            "jsonrpc": "2.0",
            "method": "public/subscribe",
            "id": 42,
            "params": {
              "channels": [
                "quote.BTC-PERPETUAL"
              ]
            }
          }
        bindings: []
        extensions:
          - id: x-parser-unique-object-id
            value: subscribe_request
    bindings: []
    extensions: *ref_0
sendOperations:
  - *ref_1
receiveOperations:
  - *ref_2
sendMessages:
  - *ref_3
receiveMessages:
  - *ref_4
extensions:
  - id: x-parser-unique-object-id
    value: quote.(instrument_name)
securitySchemes: []

````

> ## Documentation Index
> Fetch the complete documentation index at: https://docs.deribit.com/llms.txt
> Use this file to discover all available pages before exploring further.

<AgentInstructions>

## Submitting Feedback

If you encounter incorrect, outdated, or confusing documentation on this page, submit feedback:

POST https://docs.deribit.com/feedback

```json
{
  "path": "/subscriptions/market-data/deribit_price_indexindex_name",
  "feedback": "Description of the issue"
}
```

Only submit feedback when you have something specific and actionable to report.

</AgentInstructions>

# deribit_price_index.(index_name) 

> Deribit index price updates for the given `index_name` (current index value).

Use this channel to track the real-time value of a Deribit index (e.g., `btc_usd`), which is used across pricing, margining, and settlement-related calculations.




## AsyncAPI

````yaml specifications/deribit_asyncapi.json deribit_price_index.(index_name)
id: deribit_price_index.(index_name)
title: 'deribit_price_index.(index_name) '
description: >
  Deribit index price updates for the given `index_name` (current index value).


  Use this channel to track the real-time value of a Deribit index (e.g.,
  `btc_usd`), which is used across pricing, margining, and settlement-related
  calculations.
servers:
  - id: production
    protocol: wss
    host: deribit.com/ws/api/v2
    bindings: []
    variables: []
  - id: testnet
    protocol: wss
    host: test.deribit.com/ws/api/v2
    bindings: []
    variables: []
address: deribit_price_index.(index_name)
parameters:
  - id: index_name
    jsonSchema:
      type: string
      description: >-
        Index identifier, matches (base) cryptocurrency with quote currency


        **Allowed values:** `btc_usd`, `eth_usd`, `ada_usdc`, `algo_usdc`,
        `avax_usdc`, ... (total 47 values)
      enum:
        - btc_usd
        - eth_usd
        - ada_usdc
        - algo_usdc
        - avax_usdc
        - bch_usdc
        - bnb_usdc
        - btc_usdc
        - btcdvol_usdc
        - buidl_usdc
        - doge_usdc
        - dot_usdc
        - eurr_usdc
        - eth_usdc
        - ethdvol_usdc
        - link_usdc
        - ltc_usdc
        - near_usdc
        - paxg_usdc
        - shib_usdc
        - sol_usdc
        - steth_usdc
        - ton_usdc
        - trump_usdc
        - trx_usdc
        - uni_usdc
        - usde_usdc
        - usyc_usdc
        - xrp_usdc
        - btc_usdt
        - eth_usdt
        - eurr_usdt
        - sol_usdt
        - steth_usdt
        - usdc_usdt
        - usde_usdt
        - btc_eurr
        - btc_usde
        - btc_usyc
        - eth_btc
        - eth_eurr
        - eth_usde
        - eth_usyc
        - steth_eth
        - paxg_btc
        - drbfix-btc_usdc
        - drbfix-eth_usdc
    description: >-
      Index identifier, matches (base) cryptocurrency with quote currency


      **Allowed values:** `btc_usd`, `eth_usd`, `ada_usdc`, `algo_usdc`,
      `avax_usdc`, ... (total 47 values)
    type: string
    required: true
    deprecated: false
bindings: []
operations:
  - &ref_2
    id: send_subscribe_deribit_price_index_index_name
    title: Send subscribe request for deribit_price_index
    description: Client sends subscription request for deribit_price_index updates
    type: send
    messages:
      - &ref_4
        id: subscription_message
        contentType: application/json
        payload:
          - name: Subscription Notification Data
            description: Server sends subscription notification data
            type: object
            properties:
              - name: data
                type: object
                required: true
                properties:
                  - name: timestamp
                    type: integer
                    description: The timestamp (milliseconds since the Unix epoch)
                    required: false
                  - name: price
                    type: number
                    description: Current index price
                    required: false
                  - name: index_name
                    type: string
                    description: >-
                      Index identifier, matches (base) cryptocurrency with quote
                      currency
                    enumValues:
                      - btc_usd
                      - eth_usd
                      - ada_usdc
                      - algo_usdc
                      - avax_usdc
                      - bch_usdc
                      - bnb_usdc
                      - btc_usdc
                      - btcdvol_usdc
                      - buidl_usdc
                      - doge_usdc
                      - dot_usdc
                      - eurr_usdc
                      - eth_usdc
                      - ethdvol_usdc
                      - link_usdc
                      - ltc_usdc
                      - near_usdc
                      - paxg_usdc
                      - shib_usdc
                      - sol_usdc
                      - steth_usdc
                      - ton_usdc
                      - trump_usdc
                      - trx_usdc
                      - uni_usdc
                      - usde_usdc
                      - usyc_usdc
                      - xrp_usdc
                      - btc_usdt
                      - eth_usdt
                      - eurr_usdt
                      - sol_usdt
                      - steth_usdt
                      - usdc_usdt
                      - usde_usdt
                      - btc_eurr
                      - btc_usde
                      - btc_usyc
                      - eth_btc
                      - eth_eurr
                      - eth_usde
                      - eth_usyc
                      - steth_eth
                      - paxg_btc
                      - drbfix-btc_usdc
                      - drbfix-eth_usdc
                    required: false
        headers: []
        jsonPayloadSchema:
          type: object
          description: Response containing notification data
          properties:
            data:
              type: object
              properties:
                timestamp:
                  type: integer
                  example: 1536569522277
                  description: The timestamp (milliseconds since the Unix epoch)
                  x-parser-schema-id: <anonymous-schema-241>
                price:
                  description: Current index price
                  type: number
                  example: 8247.27
                  x-parser-schema-id: <anonymous-schema-242>
                index_name:
                  description: >-
                    Index identifier, matches (base) cryptocurrency with quote
                    currency
                  type: string
                  enum:
                    - btc_usd
                    - eth_usd
                    - ada_usdc
                    - algo_usdc
                    - avax_usdc
                    - bch_usdc
                    - bnb_usdc
                    - btc_usdc
                    - btcdvol_usdc
                    - buidl_usdc
                    - doge_usdc
                    - dot_usdc
                    - eurr_usdc
                    - eth_usdc
                    - ethdvol_usdc
                    - link_usdc
                    - ltc_usdc
                    - near_usdc
                    - paxg_usdc
                    - shib_usdc
                    - sol_usdc
                    - steth_usdc
                    - ton_usdc
                    - trump_usdc
                    - trx_usdc
                    - uni_usdc
                    - usde_usdc
                    - usyc_usdc
                    - xrp_usdc
                    - btc_usdt
                    - eth_usdt
                    - eurr_usdt
                    - sol_usdt
                    - steth_usdt
                    - usdc_usdt
                    - usde_usdt
                    - btc_eurr
                    - btc_usde
                    - btc_usyc
                    - eth_btc
                    - eth_eurr
                    - eth_usde
                    - eth_usyc
                    - steth_eth
                    - paxg_btc
                    - drbfix-btc_usdc
                    - drbfix-eth_usdc
                  x-parser-schema-id: <anonymous-schema-243>
              required:
                - timestamp
                - price
                - index_name
              additionalProperties: false
              x-parser-schema-id: <anonymous-schema-240>
          required:
            - data
          additionalProperties: false
          x-parser-schema-id: <anonymous-schema-239>
        title: Subscription Notification Data
        description: Server sends subscription notification data
        example: |-
          {
            "data": {
              "index_name": "btc_usd",
              "price": 3937.89,
              "timestamp": 1550588002899
            }
          }
        bindings: []
        extensions:
          - id: x-parser-unique-object-id
            value: subscription_message
    bindings: []
    extensions: &ref_0
      - id: x-parser-unique-object-id
        value: deribit_price_index.(index_name)
  - &ref_1
    id: receive_deribit_price_index_index_name_updates
    title: Receive deribit_price_index updates
    description: Client receives deribit_price_index update notifications
    type: receive
    messages:
      - &ref_3
        id: subscribe_request
        contentType: application/json
        payload:
          - name: Subscription Request
            description: >-
              Client sends subscription request to subscribe to notification
              channel. Please refer to [Notification
              page](https://deribit.mintlify.app/articles/notifications) for
              more information.
            type: object
            properties: []
        headers: []
        jsonPayloadSchema:
          properties: {}
          additionalProperties: false
          x-parser-schema-id: <anonymous-schema-238>
        title: Subscription Request
        description: >-
          Client sends subscription request to subscribe to notification
          channel. Please refer to [Notification
          page](https://deribit.mintlify.app/articles/notifications) for more
          information.
        example: |-
          {
            "jsonrpc": "2.0",
            "method": "public/subscribe",
            "id": 42,
            "params": {
              "channels": [
                "deribit_price_index.(index_name)"
              ]
            }
          }
        bindings: []
        extensions:
          - id: x-parser-unique-object-id
            value: subscribe_request
    bindings: []
    extensions: *ref_0
sendOperations:
  - *ref_1
receiveOperations:
  - *ref_2
sendMessages:
  - *ref_3
receiveMessages:
  - *ref_4
extensions:
  - id: x-parser-unique-object-id
    value: deribit_price_index.(index_name)
securitySchemes: []

````

> ## Documentation Index
> Fetch the complete documentation index at: https://docs.deribit.com/llms.txt
> Use this file to discover all available pages before exploring further.

<AgentInstructions>

## Submitting Feedback

If you encounter incorrect, outdated, or confusing documentation on this page, submit feedback:

POST https://docs.deribit.com/feedback

```json
{
  "path": "/subscriptions/market-data/deribit_price_rankingindex_name",
  "feedback": "Description of the issue"
}
```

Only submit feedback when you have something specific and actionable to report.

</AgentInstructions>

# deribit_price_ranking.(index_name) 

> Price ranking updates for the component exchanges used to calculate the Deribit index.

Use this channel to see per-exchange price contributions that feed into the index calculation for the given `index_name`.




## AsyncAPI

````yaml specifications/deribit_asyncapi.json deribit_price_ranking.(index_name)
id: deribit_price_ranking.(index_name)
title: 'deribit_price_ranking.(index_name) '
description: >
  Price ranking updates for the component exchanges used to calculate the
  Deribit index.


  Use this channel to see per-exchange price contributions that feed into the
  index calculation for the given `index_name`.
servers:
  - id: production
    protocol: wss
    host: deribit.com/ws/api/v2
    bindings: []
    variables: []
  - id: testnet
    protocol: wss
    host: test.deribit.com/ws/api/v2
    bindings: []
    variables: []
address: deribit_price_ranking.(index_name)
parameters:
  - id: index_name
    jsonSchema:
      type: string
      description: >-
        Index identifier, matches (base) cryptocurrency with quote currency


        **Allowed values:** `btc_usd`, `eth_usd`, `ada_usdc`, `algo_usdc`,
        `avax_usdc`, ... (total 47 values)
      enum:
        - btc_usd
        - eth_usd
        - ada_usdc
        - algo_usdc
        - avax_usdc
        - bch_usdc
        - bnb_usdc
        - btc_usdc
        - btcdvol_usdc
        - buidl_usdc
        - doge_usdc
        - dot_usdc
        - eurr_usdc
        - eth_usdc
        - ethdvol_usdc
        - link_usdc
        - ltc_usdc
        - near_usdc
        - paxg_usdc
        - shib_usdc
        - sol_usdc
        - steth_usdc
        - ton_usdc
        - trump_usdc
        - trx_usdc
        - uni_usdc
        - usde_usdc
        - usyc_usdc
        - xrp_usdc
        - btc_usdt
        - eth_usdt
        - eurr_usdt
        - sol_usdt
        - steth_usdt
        - usdc_usdt
        - usde_usdt
        - btc_eurr
        - btc_usde
        - btc_usyc
        - eth_btc
        - eth_eurr
        - eth_usde
        - eth_usyc
        - steth_eth
        - paxg_btc
        - drbfix-btc_usdc
        - drbfix-eth_usdc
    description: >-
      Index identifier, matches (base) cryptocurrency with quote currency


      **Allowed values:** `btc_usd`, `eth_usd`, `ada_usdc`, `algo_usdc`,
      `avax_usdc`, ... (total 47 values)
    type: string
    required: true
    deprecated: false
bindings: []
operations:
  - &ref_2
    id: send_subscribe_deribit_price_ranking_index_name
    title: Send subscribe request for deribit_price_ranking
    description: Client sends subscription request for deribit_price_ranking updates
    type: send
    messages:
      - &ref_4
        id: subscription_message
        contentType: application/json
        payload:
          - name: Subscription Notification Data
            description: Server sends subscription notification data
            type: object
            properties:
              - name: data
                type: object
                required: true
                properties:
                  - name: identifier
                    type: string
                    description: Stock exchange identifier
                    required: false
                  - name: enabled
                    type: boolean
                    description: Stock exchange status
                    required: false
                  - name: original_price
                    type: number
                    description: Index price retrieved from stock's data
                    required: false
                  - name: price
                    type: number
                    description: >-
                      Adjusted stock exchange index price, used for Deribit
                      price index calculations
                    required: false
                  - name: timestamp
                    type: integer
                    description: >-
                      The timestamp of the last update from stock exchange
                      (milliseconds since the UNIX epoch)
                    required: false
                  - name: weight
                    type: number
                    description: The weight of the ranking given in percent
                    required: false
        headers: []
        jsonPayloadSchema:
          type: object
          description: Response containing notification data
          properties:
            data:
              type: object
              properties:
                identifier:
                  type: string
                  description: Stock exchange identifier
                  example: binance
                  x-parser-schema-id: <anonymous-schema-248>
                enabled:
                  type: boolean
                  description: Stock exchange status
                  x-parser-schema-id: <anonymous-schema-249>
                original_price:
                  type: number
                  description: Index price retrieved from stock's data
                  x-parser-schema-id: <anonymous-schema-250>
                price:
                  type: number
                  description: >-
                    Adjusted stock exchange index price, used for Deribit price
                    index calculations
                  x-parser-schema-id: <anonymous-schema-251>
                timestamp:
                  type: integer
                  description: >-
                    The timestamp of the last update from stock exchange
                    (milliseconds since the UNIX epoch)
                  example: 1536569522277
                  x-parser-schema-id: <anonymous-schema-252>
                weight:
                  type: number
                  description: The weight of the ranking given in percent
                  x-parser-schema-id: <anonymous-schema-253>
              required: []
              additionalProperties: false
              x-parser-schema-id: <anonymous-schema-247>
          required:
            - data
          additionalProperties: false
          x-parser-schema-id: <anonymous-schema-246>
        title: Subscription Notification Data
        description: Server sends subscription notification data
        example: |-
          {
            "data": [
              {
                "weight": 16.666667,
                "original_price": 41160.5,
                "price": 41160.5,
                "identifier": "bitfinex",
                "timestamp": 1702465142997,
                "enabled": true
              },
              {
                "weight": 16.666667,
                "original_price": 41119,
                "price": 41119,
                "identifier": "binance",
                "timestamp": 1702465143045,
                "enabled": true
              },
              {
                "weight": 16.666667,
                "original_price": 41115.53,
                "price": 41115.53,
                "identifier": "coinbase",
                "timestamp": 1702465139000,
                "enabled": true
              },
              {
                "weight": 16.666667,
                "original_price": 41116.42,
                "price": 41116.42,
                "identifier": "gemini",
                "timestamp": 1702465142921,
                "enabled": true
              },
              {
                "weight": 16.666667,
                "original_price": 41108.88,
                "price": 41108.88,
                "identifier": "itbit",
                "timestamp": 1702465141954,
                "enabled": true
              },
              {
                "weight": 16.666667,
                "original_price": 41108.35,
                "price": 41108.35,
                "identifier": "kraken",
                "timestamp": 1702465142906,
                "enabled": true
              }
            ]
          }
        bindings: []
        extensions:
          - id: x-parser-unique-object-id
            value: subscription_message
    bindings: []
    extensions: &ref_0
      - id: x-parser-unique-object-id
        value: deribit_price_ranking.(index_name)
  - &ref_1
    id: receive_deribit_price_ranking_index_name_updates
    title: Receive deribit_price_ranking updates
    description: Client receives deribit_price_ranking update notifications
    type: receive
    messages:
      - &ref_3
        id: subscribe_request
        contentType: application/json
        payload:
          - name: Subscription Request
            description: >-
              Client sends subscription request to subscribe to notification
              channel. Please refer to [Notification
              page](https://deribit.mintlify.app/articles/notifications) for
              more information.
            type: object
            properties: []
        headers: []
        jsonPayloadSchema:
          properties: {}
          additionalProperties: false
          x-parser-schema-id: <anonymous-schema-245>
        title: Subscription Request
        description: >-
          Client sends subscription request to subscribe to notification
          channel. Please refer to [Notification
          page](https://deribit.mintlify.app/articles/notifications) for more
          information.
        example: |-
          {
            "jsonrpc": "2.0",
            "method": "public/subscribe",
            "id": 42,
            "params": {
              "channels": [
                "deribit_price_ranking.(index_name)"
              ]
            }
          }
        bindings: []
        extensions:
          - id: x-parser-unique-object-id
            value: subscribe_request
    bindings: []
    extensions: *ref_0
sendOperations:
  - *ref_1
receiveOperations:
  - *ref_2
sendMessages:
  - *ref_3
receiveMessages:
  - *ref_4
extensions:
  - id: x-parser-unique-object-id
    value: deribit_price_ranking.(index_name)
securitySchemes: []

````

> ## Documentation Index
> Fetch the complete documentation index at: https://docs.deribit.com/llms.txt
> Use this file to discover all available pages before exploring further.

<AgentInstructions>

## Submitting Feedback

If you encounter incorrect, outdated, or confusing documentation on this page, submit feedback:

POST https://docs.deribit.com/feedback

```json
{
  "path": "/subscriptions/market-data/deribit_price_statisticsindex_name",
  "feedback": "Description of the issue"
}
```

Only submit feedback when you have something specific and actionable to report.

</AgentInstructions>

# deribit_price_statistics.(index_name) 

> Basic statistics for the Deribit index.

Provides statistical information related to the given `index_name` (e.g., aggregated stats derived from index updates). Useful for monitoring index behavior over time.




## AsyncAPI

````yaml specifications/deribit_asyncapi.json deribit_price_statistics.(index_name)
id: deribit_price_statistics.(index_name)
title: 'deribit_price_statistics.(index_name) '
description: >
  Basic statistics for the Deribit index.


  Provides statistical information related to the given `index_name` (e.g.,
  aggregated stats derived from index updates). Useful for monitoring index
  behavior over time.
servers:
  - id: production
    protocol: wss
    host: deribit.com/ws/api/v2
    bindings: []
    variables: []
  - id: testnet
    protocol: wss
    host: test.deribit.com/ws/api/v2
    bindings: []
    variables: []
address: deribit_price_statistics.(index_name)
parameters:
  - id: index_name
    jsonSchema:
      type: string
      description: >-
        Index identifier, matches (base) cryptocurrency with quote currency


        **Allowed values:** `btc_usd`, `eth_usd`, `ada_usdc`, `algo_usdc`,
        `avax_usdc`, ... (total 47 values)
      enum:
        - btc_usd
        - eth_usd
        - ada_usdc
        - algo_usdc
        - avax_usdc
        - bch_usdc
        - bnb_usdc
        - btc_usdc
        - btcdvol_usdc
        - buidl_usdc
        - doge_usdc
        - dot_usdc
        - eurr_usdc
        - eth_usdc
        - ethdvol_usdc
        - link_usdc
        - ltc_usdc
        - near_usdc
        - paxg_usdc
        - shib_usdc
        - sol_usdc
        - steth_usdc
        - ton_usdc
        - trump_usdc
        - trx_usdc
        - uni_usdc
        - usde_usdc
        - usyc_usdc
        - xrp_usdc
        - btc_usdt
        - eth_usdt
        - eurr_usdt
        - sol_usdt
        - steth_usdt
        - usdc_usdt
        - usde_usdt
        - btc_eurr
        - btc_usde
        - btc_usyc
        - eth_btc
        - eth_eurr
        - eth_usde
        - eth_usyc
        - steth_eth
        - paxg_btc
        - drbfix-btc_usdc
        - drbfix-eth_usdc
    description: >-
      Index identifier, matches (base) cryptocurrency with quote currency


      **Allowed values:** `btc_usd`, `eth_usd`, `ada_usdc`, `algo_usdc`,
      `avax_usdc`, ... (total 47 values)
    type: string
    required: true
    deprecated: false
bindings: []
operations:
  - &ref_2
    id: send_subscribe_deribit_price_statistics_index_name
    title: Send subscribe request for deribit_price_statistics
    description: Client sends subscription request for deribit_price_statistics updates
    type: send
    messages:
      - &ref_4
        id: subscription_message
        contentType: application/json
        payload:
          - name: Subscription Notification Data
            description: Server sends subscription notification data
            type: object
            properties:
              - name: data
                type: object
                required: true
                properties:
                  - name: index_name
                    type: string
                    description: >-
                      Index identifier, matches (base) cryptocurrency with quote
                      currency
                    enumValues:
                      - btc_usd
                      - eth_usd
                      - ada_usdc
                      - algo_usdc
                      - avax_usdc
                      - bch_usdc
                      - bnb_usdc
                      - btc_usdc
                      - btcdvol_usdc
                      - buidl_usdc
                      - doge_usdc
                      - dot_usdc
                      - eurr_usdc
                      - eth_usdc
                      - ethdvol_usdc
                      - link_usdc
                      - ltc_usdc
                      - near_usdc
                      - paxg_usdc
                      - shib_usdc
                      - sol_usdc
                      - steth_usdc
                      - ton_usdc
                      - trump_usdc
                      - trx_usdc
                      - uni_usdc
                      - usde_usdc
                      - usyc_usdc
                      - xrp_usdc
                      - btc_usdt
                      - eth_usdt
                      - eurr_usdt
                      - sol_usdt
                      - steth_usdt
                      - usdc_usdt
                      - usde_usdt
                      - btc_eurr
                      - btc_usde
                      - btc_usyc
                      - eth_btc
                      - eth_eurr
                      - eth_usde
                      - eth_usyc
                      - steth_eth
                      - paxg_btc
                      - drbfix-btc_usdc
                      - drbfix-eth_usdc
                    required: false
                  - name: low24h
                    type: number
                    description: The lowest recorded price within the last 24 hours
                    required: false
                  - name: high24h
                    type: number
                    description: The highest recorded price within the last 24 hours
                    required: false
                  - name: change24h
                    type: number
                    description: >-
                      The price index change calculated between the first and
                      last point within most recent 24 hours window
                    required: false
                  - name: fast_market
                    type: boolean
                    description: >-
                      Indicates the fast moving prices period on the market. The
                      value `true` is set when the price index value drastically
                      changed within the last 1 hour. This indicator remains
                      active even for 2 more hours after the prices calm down
                    required: false
        headers: []
        jsonPayloadSchema:
          type: object
          description: Response containing notification data
          properties:
            data:
              type: object
              properties:
                index_name:
                  description: >-
                    Index identifier, matches (base) cryptocurrency with quote
                    currency
                  type: string
                  enum:
                    - btc_usd
                    - eth_usd
                    - ada_usdc
                    - algo_usdc
                    - avax_usdc
                    - bch_usdc
                    - bnb_usdc
                    - btc_usdc
                    - btcdvol_usdc
                    - buidl_usdc
                    - doge_usdc
                    - dot_usdc
                    - eurr_usdc
                    - eth_usdc
                    - ethdvol_usdc
                    - link_usdc
                    - ltc_usdc
                    - near_usdc
                    - paxg_usdc
                    - shib_usdc
                    - sol_usdc
                    - steth_usdc
                    - ton_usdc
                    - trump_usdc
                    - trx_usdc
                    - uni_usdc
                    - usde_usdc
                    - usyc_usdc
                    - xrp_usdc
                    - btc_usdt
                    - eth_usdt
                    - eurr_usdt
                    - sol_usdt
                    - steth_usdt
                    - usdc_usdt
                    - usde_usdt
                    - btc_eurr
                    - btc_usde
                    - btc_usyc
                    - eth_btc
                    - eth_eurr
                    - eth_usde
                    - eth_usyc
                    - steth_eth
                    - paxg_btc
                    - drbfix-btc_usdc
                    - drbfix-eth_usdc
                  x-parser-schema-id: <anonymous-schema-258>
                low24h:
                  type: number
                  description: The lowest recorded price within the last 24 hours
                  x-parser-schema-id: <anonymous-schema-259>
                high24h:
                  type: number
                  description: The highest recorded price within the last 24 hours
                  x-parser-schema-id: <anonymous-schema-260>
                change24h:
                  type: number
                  description: >-
                    The price index change calculated between the first and last
                    point within most recent 24 hours window
                  x-parser-schema-id: <anonymous-schema-261>
                fast_market:
                  type: boolean
                  description: >-
                    Indicates the fast moving prices period on the market. The
                    value `true` is set when the price index value drastically
                    changed within the last 1 hour. This indicator remains
                    active even for 2 more hours after the prices calm down
                  x-parser-schema-id: <anonymous-schema-262>
              required:
                - index_name
                - low24h
                - high24h
                - change24h
              additionalProperties: false
              x-parser-schema-id: <anonymous-schema-257>
          required:
            - data
          additionalProperties: false
          x-parser-schema-id: <anonymous-schema-256>
        title: Subscription Notification Data
        description: Server sends subscription notification data
        example: |-
          {
            "data": {
              "low24h": 58012.08,
              "index_name": "btc_usd",
              "high24h": 59311.42,
              "change24h": 1009.61,
              "high_volatility": false
            }
          }
        bindings: []
        extensions:
          - id: x-parser-unique-object-id
            value: subscription_message
    bindings: []
    extensions: &ref_0
      - id: x-parser-unique-object-id
        value: deribit_price_statistics.(index_name)
  - &ref_1
    id: receive_deribit_price_statistics_index_name_updates
    title: Receive deribit_price_statistics updates
    description: Client receives deribit_price_statistics update notifications
    type: receive
    messages:
      - &ref_3
        id: subscribe_request
        contentType: application/json
        payload:
          - name: Subscription Request
            description: >-
              Client sends subscription request to subscribe to notification
              channel. Please refer to [Notification
              page](https://deribit.mintlify.app/articles/notifications) for
              more information.
            type: object
            properties: []
        headers: []
        jsonPayloadSchema:
          properties: {}
          additionalProperties: false
          x-parser-schema-id: <anonymous-schema-255>
        title: Subscription Request
        description: >-
          Client sends subscription request to subscribe to notification
          channel. Please refer to [Notification
          page](https://deribit.mintlify.app/articles/notifications) for more
          information.
        example: |-
          {
            "jsonrpc": "2.0",
            "method": "public/subscribe",
            "id": 42,
            "params": {
              "channels": [
                "deribit_price_statistics.(index_name)"
              ]
            }
          }
        bindings: []
        extensions:
          - id: x-parser-unique-object-id
            value: subscribe_request
    bindings: []
    extensions: *ref_0
sendOperations:
  - *ref_1
receiveOperations:
  - *ref_2
sendMessages:
  - *ref_3
receiveMessages:
  - *ref_4
extensions:
  - id: x-parser-unique-object-id
    value: deribit_price_statistics.(index_name)
securitySchemes: []

````


> ## Documentation Index
> Fetch the complete documentation index at: https://docs.deribit.com/llms.txt
> Use this file to discover all available pages before exploring further.

<AgentInstructions>

## Submitting Feedback

If you encounter incorrect, outdated, or confusing documentation on this page, submit feedback:

POST https://docs.deribit.com/feedback

```json
{
  "path": "/subscriptions/market-data/deribit_volatility_indexindex_name",
  "feedback": "Description of the issue"
}
```

Only submit feedback when you have something specific and actionable to report.

</AgentInstructions>

# deribit_volatility_index.(index_name) 

> Volatility index updates for the given `index_name`.

Use this channel to receive volatility index values (e.g., DVOL-like measures) as they update.




## AsyncAPI

````yaml specifications/deribit_asyncapi.json deribit_volatility_index.(index_name)
id: deribit_volatility_index.(index_name)
title: 'deribit_volatility_index.(index_name) '
description: >
  Volatility index updates for the given `index_name`.


  Use this channel to receive volatility index values (e.g., DVOL-like measures)
  as they update.
servers:
  - id: production
    protocol: wss
    host: deribit.com/ws/api/v2
    bindings: []
    variables: []
  - id: testnet
    protocol: wss
    host: test.deribit.com/ws/api/v2
    bindings: []
    variables: []
address: deribit_volatility_index.(index_name)
parameters:
  - id: index_name
    jsonSchema:
      type: string
      description: >-
        Index identifier, matches (base) cryptocurrency with quote currency


        **Allowed values:** `btc_usd`, `eth_usd`, `ada_usdc`, `algo_usdc`,
        `avax_usdc`, ... (total 47 values)
      enum:
        - btc_usd
        - eth_usd
        - ada_usdc
        - algo_usdc
        - avax_usdc
        - bch_usdc
        - bnb_usdc
        - btc_usdc
        - btcdvol_usdc
        - buidl_usdc
        - doge_usdc
        - dot_usdc
        - eurr_usdc
        - eth_usdc
        - ethdvol_usdc
        - link_usdc
        - ltc_usdc
        - near_usdc
        - paxg_usdc
        - shib_usdc
        - sol_usdc
        - steth_usdc
        - ton_usdc
        - trump_usdc
        - trx_usdc
        - uni_usdc
        - usde_usdc
        - usyc_usdc
        - xrp_usdc
        - btc_usdt
        - eth_usdt
        - eurr_usdt
        - sol_usdt
        - steth_usdt
        - usdc_usdt
        - usde_usdt
        - btc_eurr
        - btc_usde
        - btc_usyc
        - eth_btc
        - eth_eurr
        - eth_usde
        - eth_usyc
        - steth_eth
        - paxg_btc
        - drbfix-btc_usdc
        - drbfix-eth_usdc
    description: >-
      Index identifier, matches (base) cryptocurrency with quote currency


      **Allowed values:** `btc_usd`, `eth_usd`, `ada_usdc`, `algo_usdc`,
      `avax_usdc`, ... (total 47 values)
    type: string
    required: true
    deprecated: false
bindings: []
operations:
  - &ref_2
    id: send_subscribe_deribit_volatility_index_index_name
    title: Send subscribe request for deribit_volatility_index
    description: Client sends subscription request for deribit_volatility_index updates
    type: send
    messages:
      - &ref_4
        id: subscription_message
        contentType: application/json
        payload:
          - name: Subscription Notification Data
            description: Server sends subscription notification data
            type: object
            properties:
              - name: data
                type: object
                required: true
                properties:
                  - name: timestamp
                    type: integer
                    description: The timestamp (milliseconds since the Unix epoch)
                    required: false
                  - name: volatility
                    type: number
                    description: Value of the corresponding volatility
                    required: false
                  - name: index_name
                    type: string
                    description: Index identifier supported for DVOL
                    enumValues:
                      - btc_usd
                      - eth_usd
                    required: false
        headers: []
        jsonPayloadSchema:
          type: object
          description: Response containing notification data
          properties:
            data:
              type: object
              properties:
                timestamp:
                  type: integer
                  example: 1536569522277
                  description: The timestamp (milliseconds since the Unix epoch)
                  x-parser-schema-id: <anonymous-schema-267>
                volatility:
                  description: Value of the corresponding volatility
                  type: number
                  x-parser-schema-id: <anonymous-schema-268>
                index_name:
                  description: Index identifier supported for DVOL
                  type: string
                  enum:
                    - btc_usd
                    - eth_usd
                  x-parser-schema-id: <anonymous-schema-269>
              required:
                - timestamp
                - volatility
                - index_name
              additionalProperties: false
              x-parser-schema-id: <anonymous-schema-266>
          required:
            - data
          additionalProperties: false
          x-parser-schema-id: <anonymous-schema-265>
        title: Subscription Notification Data
        description: Server sends subscription notification data
        example: |-
          {
            "data": {
              "volatility": 129.36,
              "timestamp": 1619777946007,
              "index_name": "btc_usd"
            }
          }
        bindings: []
        extensions:
          - id: x-parser-unique-object-id
            value: subscription_message
    bindings: []
    extensions: &ref_0
      - id: x-parser-unique-object-id
        value: deribit_volatility_index.(index_name)
  - &ref_1
    id: receive_deribit_volatility_index_index_name_updates
    title: Receive deribit_volatility_index updates
    description: Client receives deribit_volatility_index update notifications
    type: receive
    messages:
      - &ref_3
        id: subscribe_request
        contentType: application/json
        payload:
          - name: Subscription Request
            description: >-
              Client sends subscription request to subscribe to notification
              channel. Please refer to [Notification
              page](https://deribit.mintlify.app/articles/notifications) for
              more information.
            type: object
            properties: []
        headers: []
        jsonPayloadSchema:
          properties: {}
          additionalProperties: false
          x-parser-schema-id: <anonymous-schema-264>
        title: Subscription Request
        description: >-
          Client sends subscription request to subscribe to notification
          channel. Please refer to [Notification
          page](https://deribit.mintlify.app/articles/notifications) for more
          information.
        example: |-
          {
            "jsonrpc": "2.0",
            "method": "public/subscribe",
            "id": 42,
            "params": {
              "channels": [
                "deribit_volatility_index.(index_name)"
              ]
            }
          }
        bindings: []
        extensions:
          - id: x-parser-unique-object-id
            value: subscribe_request
    bindings: []
    extensions: *ref_0
sendOperations:
  - *ref_1
receiveOperations:
  - *ref_2
sendMessages:
  - *ref_3
receiveMessages:
  - *ref_4
extensions:
  - id: x-parser-unique-object-id
    value: deribit_volatility_index.(index_name)
securitySchemes: []

````

> ## Documentation Index
> Fetch the complete documentation index at: https://docs.deribit.com/llms.txt
> Use this file to discover all available pages before exploring further.

<AgentInstructions>

## Submitting Feedback

If you encounter incorrect, outdated, or confusing documentation on this page, submit feedback:

POST https://docs.deribit.com/feedback

```json
{
  "path": "/subscriptions/market-data/markpriceoptionsindex_name",
  "feedback": "Description of the issue"
}
```

Only submit feedback when you have something specific and actionable to report.

</AgentInstructions>

# markprice.options.(index_name) 

> Options mark price updates for the given `index_name`.

Use this channel to receive mark prices for options under the given index, useful for valuation, risk monitoring, and P&L calculations.




## AsyncAPI

````yaml specifications/deribit_asyncapi.json markprice.options.(index_name)
id: markprice.options.(index_name)
title: 'markprice.options.(index_name) '
description: >
  Options mark price updates for the given `index_name`.


  Use this channel to receive mark prices for options under the given index,
  useful for valuation, risk monitoring, and P&L calculations.
servers:
  - id: production
    protocol: wss
    host: deribit.com/ws/api/v2
    bindings: []
    variables: []
  - id: testnet
    protocol: wss
    host: test.deribit.com/ws/api/v2
    bindings: []
    variables: []
address: markprice.options.(index_name)
parameters:
  - id: index_name
    jsonSchema:
      type: string
      description: >-
        Index identifier, matches (base) cryptocurrency with quote currency


        **Allowed values:** `btc_usd`, `eth_usd`, `ada_usdc`, `algo_usdc`,
        `avax_usdc`, ... (total 47 values)
      enum:
        - btc_usd
        - eth_usd
        - ada_usdc
        - algo_usdc
        - avax_usdc
        - bch_usdc
        - bnb_usdc
        - btc_usdc
        - btcdvol_usdc
        - buidl_usdc
        - doge_usdc
        - dot_usdc
        - eurr_usdc
        - eth_usdc
        - ethdvol_usdc
        - link_usdc
        - ltc_usdc
        - near_usdc
        - paxg_usdc
        - shib_usdc
        - sol_usdc
        - steth_usdc
        - ton_usdc
        - trump_usdc
        - trx_usdc
        - uni_usdc
        - usde_usdc
        - usyc_usdc
        - xrp_usdc
        - btc_usdt
        - eth_usdt
        - eurr_usdt
        - sol_usdt
        - steth_usdt
        - usdc_usdt
        - usde_usdt
        - btc_eurr
        - btc_usde
        - btc_usyc
        - eth_btc
        - eth_eurr
        - eth_usde
        - eth_usyc
        - steth_eth
        - paxg_btc
        - drbfix-btc_usdc
        - drbfix-eth_usdc
    description: >-
      Index identifier, matches (base) cryptocurrency with quote currency


      **Allowed values:** `btc_usd`, `eth_usd`, `ada_usdc`, `algo_usdc`,
      `avax_usdc`, ... (total 47 values)
    type: string
    required: true
    deprecated: false
bindings: []
operations:
  - &ref_2
    id: send_subscribe_markprice_options_index_name
    title: Send subscribe request for markprice
    description: Client sends subscription request for markprice updates
    type: send
    messages:
      - &ref_4
        id: subscription_message
        contentType: application/json
        payload:
          - name: Subscription Notification Data
            description: Server sends subscription notification data
            type: object
            properties:
              - name: data
                type: object
                required: true
                properties:
                  - name: instrument_name
                    type: string
                    description: Unique instrument identifier
                    required: false
                  - name: mark_price
                    type: number
                    description: The mark price for the instrument
                    required: false
                  - name: iv
                    type: number
                    description: Value of the volatility of the underlying instrument
                    required: false
                  - name: timestamp
                    type: integer
                    description: The timestamp (milliseconds since the Unix epoch)
                    required: false
        headers: []
        jsonPayloadSchema:
          type: object
          description: Response containing notification data
          properties:
            data:
              type: object
              description: ''
              properties:
                instrument_name:
                  type: string
                  description: Unique instrument identifier
                  example: BTC-PERPETUAL
                  x-parser-schema-id: <anonymous-schema-274>
                mark_price:
                  description: The mark price for the instrument
                  type: number
                  x-parser-schema-id: <anonymous-schema-275>
                iv:
                  description: Value of the volatility of the underlying instrument
                  type: number
                  x-parser-schema-id: <anonymous-schema-276>
                timestamp:
                  type: integer
                  example: 1536569522277
                  description: The timestamp (milliseconds since the Unix epoch)
                  x-parser-schema-id: <anonymous-schema-277>
              required: []
              additionalProperties: false
              x-parser-schema-id: <anonymous-schema-273>
          required:
            - data
          additionalProperties: false
          x-parser-schema-id: <anonymous-schema-272>
        title: Subscription Notification Data
        description: Server sends subscription notification data
        example: |-
          {
            "data": [
              {
                "timestamp": 1622470378005,
                "mark_price": 0.0333,
                "iv": 0.9,
                "instrument_name": "BTC-2JUN21-37000-P"
              },
              {
                "timestamp": 1622470378005,
                "mark_price": 0.117,
                "iv": 0.9,
                "instrument_name": "BTC-4JUN21-40500-P"
              },
              {
                "timestamp": 1622470378005,
                "mark_price": 0.0177,
                "iv": 0.9,
                "instrument_name": "BTC-4JUN21-38250-C"
              },
              {
                "timestamp": 1622470378005,
                "mark_price": 0.0098,
                "iv": 0.9,
                "instrument_name": "BTC-1JUN21-37000-C"
              },
              {
                "timestamp": 1622470378005,
                "mark_price": 0.0371,
                "iv": 0.9,
                "instrument_name": "BTC-4JUN21-36500-P"
              }
            ]
          }
        bindings: []
        extensions:
          - id: x-parser-unique-object-id
            value: subscription_message
    bindings: []
    extensions: &ref_0
      - id: x-parser-unique-object-id
        value: markprice.options.(index_name)
  - &ref_1
    id: receive_markprice_options_index_name_updates
    title: Receive markprice updates
    description: Client receives markprice update notifications
    type: receive
    messages:
      - &ref_3
        id: subscribe_request
        contentType: application/json
        payload:
          - name: Subscription Request
            description: >-
              Client sends subscription request to subscribe to notification
              channel. Please refer to [Notification
              page](https://deribit.mintlify.app/articles/notifications) for
              more information.
            type: object
            properties: []
        headers: []
        jsonPayloadSchema:
          properties: {}
          additionalProperties: false
          x-parser-schema-id: <anonymous-schema-271>
        title: Subscription Request
        description: >-
          Client sends subscription request to subscribe to notification
          channel. Please refer to [Notification
          page](https://deribit.mintlify.app/articles/notifications) for more
          information.
        example: |-
          {
            "jsonrpc": "2.0",
            "method": "public/subscribe",
            "id": 42,
            "params": {
              "channels": [
                "markprice.options.(index_name)"
              ]
            }
          }
        bindings: []
        extensions:
          - id: x-parser-unique-object-id
            value: subscribe_request
    bindings: []
    extensions: *ref_0
sendOperations:
  - *ref_1
receiveOperations:
  - *ref_2
sendMessages:
  - *ref_3
receiveMessages:
  - *ref_4
extensions:
  - id: x-parser-unique-object-id
    value: markprice.options.(index_name)
securitySchemes: []

````

> ## Documentation Index
> Fetch the complete documentation index at: https://docs.deribit.com/llms.txt
> Use this file to discover all available pages before exploring further.

<AgentInstructions>

## Submitting Feedback

If you encounter incorrect, outdated, or confusing documentation on this page, submit feedback:

POST https://docs.deribit.com/feedback

```json
{
  "path": "/subscriptions/market-data/estimated_expiration_priceindex_name",
  "feedback": "Description of the issue"
}
```

Only submit feedback when you have something specific and actionable to report.

</AgentInstructions>

# estimated_expiration_price.(index_name) 

> Estimated expiration (delivery) price updates for the given `index_name`.

Provides calculated estimates of the ending price used around expirations/settlement. Useful for monitoring expected settlement levels.




## AsyncAPI

````yaml specifications/deribit_asyncapi.json estimated_expiration_price.(index_name)
id: estimated_expiration_price.(index_name)
title: 'estimated_expiration_price.(index_name) '
description: >
  Estimated expiration (delivery) price updates for the given `index_name`.


  Provides calculated estimates of the ending price used around
  expirations/settlement. Useful for monitoring expected settlement levels.
servers:
  - id: production
    protocol: wss
    host: deribit.com/ws/api/v2
    bindings: []
    variables: []
  - id: testnet
    protocol: wss
    host: test.deribit.com/ws/api/v2
    bindings: []
    variables: []
address: estimated_expiration_price.(index_name)
parameters:
  - id: index_name
    jsonSchema:
      type: string
      description: >-
        Index identifier, matches (base) cryptocurrency with quote currency


        **Allowed values:** `btc_usd`, `eth_usd`, `ada_usdc`, `algo_usdc`,
        `avax_usdc`, ... (total 47 values)
      enum:
        - btc_usd
        - eth_usd
        - ada_usdc
        - algo_usdc
        - avax_usdc
        - bch_usdc
        - bnb_usdc
        - btc_usdc
        - btcdvol_usdc
        - buidl_usdc
        - doge_usdc
        - dot_usdc
        - eurr_usdc
        - eth_usdc
        - ethdvol_usdc
        - link_usdc
        - ltc_usdc
        - near_usdc
        - paxg_usdc
        - shib_usdc
        - sol_usdc
        - steth_usdc
        - ton_usdc
        - trump_usdc
        - trx_usdc
        - uni_usdc
        - usde_usdc
        - usyc_usdc
        - xrp_usdc
        - btc_usdt
        - eth_usdt
        - eurr_usdt
        - sol_usdt
        - steth_usdt
        - usdc_usdt
        - usde_usdt
        - btc_eurr
        - btc_usde
        - btc_usyc
        - eth_btc
        - eth_eurr
        - eth_usde
        - eth_usyc
        - steth_eth
        - paxg_btc
        - drbfix-btc_usdc
        - drbfix-eth_usdc
    description: >-
      Index identifier, matches (base) cryptocurrency with quote currency


      **Allowed values:** `btc_usd`, `eth_usd`, `ada_usdc`, `algo_usdc`,
      `avax_usdc`, ... (total 47 values)
    type: string
    required: true
    deprecated: false
bindings: []
operations:
  - &ref_2
    id: send_subscribe_estimated_expiration_price_index_name
    title: Send subscribe request for estimated_expiration_price
    description: Client sends subscription request for estimated_expiration_price updates
    type: send
    messages:
      - &ref_4
        id: subscription_message
        contentType: application/json
        payload:
          - name: Subscription Notification Data
            description: Server sends subscription notification data
            type: object
            properties:
              - name: data
                type: object
                required: true
                properties:
                  - name: seconds
                    type: integer
                    description: >-
                      Number of seconds remaining until the expiration of the
                      nearest expiring instrument
                    required: false
                  - name: price
                    type: number
                    description: >-
                      The current index price or the estimated expiration price
                      for the index. When `is_estimated` is `true`, this
                      represents the calculated estimated ending price;
                      otherwise, it is the current index price.
                    required: false
                  - name: is_estimated
                    type: boolean
                    description: >-
                      Indicates whether the price is an estimated value. When
                      `true`, the price represents a calculated estimated ending
                      price for expiration. When `false`, the price is the
                      current index price.
                    required: false
                  - name: left_ticks
                    type: number
                    description: >-
                      Number of time ticks remaining until expiration. This
                      field is only present when `is_estimated` is `true`.
                    required: false
                  - name: total_ticks
                    type: number
                    description: >-
                      Total number of time ticks for the expiration period. This
                      field is only present when `is_estimated` is `true`.
                    required: false
        headers: []
        jsonPayloadSchema:
          type: object
          description: Response containing notification data
          properties:
            data:
              type: object
              properties:
                seconds:
                  type: integer
                  description: >-
                    Number of seconds remaining until the expiration of the
                    nearest expiring instrument
                  x-parser-schema-id: <anonymous-schema-282>
                price:
                  type: number
                  description: >-
                    The current index price or the estimated expiration price
                    for the index. When `is_estimated` is `true`, this
                    represents the calculated estimated ending price; otherwise,
                    it is the current index price.
                  example: 8247.27
                  x-parser-schema-id: <anonymous-schema-283>
                is_estimated:
                  type: boolean
                  description: >-
                    Indicates whether the price is an estimated value. When
                    `true`, the price represents a calculated estimated ending
                    price for expiration. When `false`, the price is the current
                    index price.
                  x-parser-schema-id: <anonymous-schema-284>
                left_ticks:
                  type: number
                  description: >-
                    Number of time ticks remaining until expiration. This field
                    is only present when `is_estimated` is `true`.
                  x-parser-schema-id: <anonymous-schema-285>
                total_ticks:
                  type: number
                  description: >-
                    Total number of time ticks for the expiration period. This
                    field is only present when `is_estimated` is `true`.
                  x-parser-schema-id: <anonymous-schema-286>
              required:
                - seconds
                - price
                - is_estimated
              additionalProperties: false
              x-parser-schema-id: <anonymous-schema-281>
          required:
            - data
          additionalProperties: false
          x-parser-schema-id: <anonymous-schema-280>
        title: Subscription Notification Data
        description: Server sends subscription notification data
        example: |-
          {
            "data": {
              "is_estimated": false,
              "price": 3939.73,
              "seconds": 180929
            }
          }
        bindings: []
        extensions:
          - id: x-parser-unique-object-id
            value: subscription_message
    bindings: []
    extensions: &ref_0
      - id: x-parser-unique-object-id
        value: estimated_expiration_price.(index_name)
  - &ref_1
    id: receive_estimated_expiration_price_index_name_updates
    title: Receive estimated_expiration_price updates
    description: Client receives estimated_expiration_price update notifications
    type: receive
    messages:
      - &ref_3
        id: subscribe_request
        contentType: application/json
        payload:
          - name: Subscription Request
            description: >-
              Client sends subscription request to subscribe to notification
              channel. Please refer to [Notification
              page](https://deribit.mintlify.app/articles/notifications) for
              more information.
            type: object
            properties: []
        headers: []
        jsonPayloadSchema:
          properties: {}
          additionalProperties: false
          x-parser-schema-id: <anonymous-schema-279>
        title: Subscription Request
        description: >-
          Client sends subscription request to subscribe to notification
          channel. Please refer to [Notification
          page](https://deribit.mintlify.app/articles/notifications) for more
          information.
        example: |-
          {
            "jsonrpc": "2.0",
            "method": "public/subscribe",
            "id": 42,
            "params": {
              "channels": [
                "estimated_expiration_price.(index_name)"
              ]
            }
          }
        bindings: []
        extensions:
          - id: x-parser-unique-object-id
            value: subscribe_request
    bindings: []
    extensions: *ref_0
sendOperations:
  - *ref_1
receiveOperations:
  - *ref_2
sendMessages:
  - *ref_3
receiveMessages:
  - *ref_4
extensions:
  - id: x-parser-unique-object-id
    value: estimated_expiration_price.(index_name)
securitySchemes: []

````

> ## Documentation Index
> Fetch the complete documentation index at: https://docs.deribit.com/llms.txt
> Use this file to discover all available pages before exploring further.

<AgentInstructions>

## Submitting Feedback

If you encounter incorrect, outdated, or confusing documentation on this page, submit feedback:

POST https://docs.deribit.com/feedback

```json
{
  "path": "/subscriptions/market-data/charttradesinstrument_nameresolution",
  "feedback": "Description of the issue"
}
```

Only submit feedback when you have something specific and actionable to report.

</AgentInstructions>

# chart.trades.(instrument_name).(resolution) 

> Publicly available market data used to generate a TradingView trade candle chart.

During a single resolution period, many events can be sent, each with updated values for the recent period.

**Notice:** When there is no trade during the requested resolution period (e.g. 1 minute), a filling sample is generated which uses data from the last available trade candle (open and close values).




## AsyncAPI

````yaml specifications/deribit_asyncapi.json chart.trades.(instrument_name).(resolution)
id: chart.trades.(instrument_name).(resolution)
title: 'chart.trades.(instrument_name).(resolution) '
description: >
  Publicly available market data used to generate a TradingView trade candle
  chart.


  During a single resolution period, many events can be sent, each with updated
  values for the recent period.


  **Notice:** When there is no trade during the requested resolution period
  (e.g. 1 minute), a filling sample is generated which uses data from the last
  available trade candle (open and close values).
servers:
  - id: production
    protocol: wss
    host: deribit.com/ws/api/v2
    bindings: []
    variables: []
  - id: testnet
    protocol: wss
    host: test.deribit.com/ws/api/v2
    bindings: []
    variables: []
address: chart.trades.(instrument_name).(resolution)
parameters:
  - id: instrument_name
    jsonSchema:
      type: string
      description: The name of the instrument
    description: The name of the instrument
    type: string
    required: true
    deprecated: false
  - id: resolution
    jsonSchema:
      type: string
      description: >-
        Chart bars resolution given in full minutes or keyword `1D` (only some
        specific resolutions are supported)


        **Allowed values:** `1`, `3`, `5`, `10`, `15`, ... (total 12 values)
      enum:
        - '1'
        - '3'
        - '5'
        - '10'
        - '15'
        - '30'
        - '60'
        - '120'
        - '180'
        - '360'
        - '720'
        - 1D
    description: >-
      Chart bars resolution given in full minutes or keyword `1D` (only some
      specific resolutions are supported)


      **Allowed values:** `1`, `3`, `5`, `10`, `15`, ... (total 12 values)
    type: string
    required: true
    deprecated: false
bindings: []
operations:
  - &ref_2
    id: send_subscribe_chart_trades_instrument_name_resolution
    title: Send subscribe request for chart
    description: Client sends subscription request for chart updates
    type: send
    messages:
      - &ref_4
        id: subscription_message
        contentType: application/json
        payload:
          - name: Subscription Notification Data
            description: Server sends subscription notification data
            type: object
            properties:
              - name: data
                type: object
                required: true
                properties:
                  - name: tick
                    type: integer
                    description: The timestamp (milliseconds since the Unix epoch)
                    required: false
                  - name: volume
                    type: number
                    description: Volume data for the candle
                    required: false
                  - name: cost
                    type: number
                    description: Cost data for the candle
                    required: false
                  - name: open
                    type: number
                    description: The open price for the candle'
                    required: false
                  - name: close
                    type: number
                    description: The close price for the candle
                    required: false
                  - name: high
                    type: number
                    description: The highest price level for the candle
                    required: false
                  - name: low
                    type: number
                    description: The lowest price level for the candle
                    required: false
        headers: []
        jsonPayloadSchema:
          type: object
          description: Response containing notification data
          properties:
            data:
              type: object
              properties:
                tick:
                  type: integer
                  example: 1536569522277
                  description: The timestamp (milliseconds since the Unix epoch)
                  x-parser-schema-id: <anonymous-schema-292>
                volume:
                  type: number
                  description: Volume data for the candle
                  x-parser-schema-id: <anonymous-schema-293>
                cost:
                  type: number
                  description: Cost data for the candle
                  x-parser-schema-id: <anonymous-schema-294>
                open:
                  type: number
                  description: The open price for the candle'
                  x-parser-schema-id: <anonymous-schema-295>
                close:
                  type: number
                  description: The close price for the candle
                  x-parser-schema-id: <anonymous-schema-296>
                high:
                  type: number
                  description: The highest price level for the candle
                  x-parser-schema-id: <anonymous-schema-297>
                low:
                  type: number
                  description: The lowest price level for the candle
                  x-parser-schema-id: <anonymous-schema-298>
              required:
                - tick
                - volume
                - cost
                - open
                - close
                - high
                - low
              additionalProperties: false
              x-parser-schema-id: <anonymous-schema-291>
          required:
            - data
          additionalProperties: false
          x-parser-schema-id: <anonymous-schema-290>
        title: Subscription Notification Data
        description: Server sends subscription notification data
        example: |-
          {
            "data": {
              "volume": 0.05219351,
              "tick": 1573645080000,
              "open": 8869.79,
              "low": 8788.25,
              "high": 8870.31,
              "cost": 460,
              "close": 8791.25
            }
          }
        bindings: []
        extensions:
          - id: x-parser-unique-object-id
            value: subscription_message
    bindings: []
    extensions: &ref_0
      - id: x-parser-unique-object-id
        value: chart.trades.(instrument_name).(resolution)
  - &ref_1
    id: receive_chart_trades_instrument_name_resolution_updates
    title: Receive chart updates
    description: Client receives chart update notifications
    type: receive
    messages:
      - &ref_3
        id: subscribe_request
        contentType: application/json
        payload:
          - name: Subscription Request
            description: >-
              Client sends subscription request to subscribe to notification
              channel. Please refer to [Notification
              page](https://deribit.mintlify.app/articles/notifications) for
              more information.
            type: object
            properties: []
        headers: []
        jsonPayloadSchema:
          properties: {}
          additionalProperties: false
          x-parser-schema-id: <anonymous-schema-289>
        title: Subscription Request
        description: >-
          Client sends subscription request to subscribe to notification
          channel. Please refer to [Notification
          page](https://deribit.mintlify.app/articles/notifications) for more
          information.
        example: |-
          {
            "jsonrpc": "2.0",
            "method": "public/subscribe",
            "id": 42,
            "params": {
              "channels": [
                "chart.trades.BTC-PERPETUAL.(resolution)"
              ]
            }
          }
        bindings: []
        extensions:
          - id: x-parser-unique-object-id
            value: subscribe_request
    bindings: []
    extensions: *ref_0
sendOperations:
  - *ref_1
receiveOperations:
  - *ref_2
sendMessages:
  - *ref_3
receiveMessages:
  - *ref_4
extensions:
  - id: x-parser-unique-object-id
    value: chart.trades.(instrument_name).(resolution)
securitySchemes: []

````

> ## Documentation Index
> Fetch the complete documentation index at: https://docs.deribit.com/llms.txt
> Use this file to discover all available pages before exploring further.

<AgentInstructions>

## Submitting Feedback

If you encounter incorrect, outdated, or confusing documentation on this page, submit feedback:

POST https://docs.deribit.com/feedback

```json
{
  "path": "/subscriptions/market-data/instrumentstatekindcurrency",
  "feedback": "Description of the issue"
}
```

Only submit feedback when you have something specific and actionable to report.

</AgentInstructions>

# instrument.state.(kind).(currency) 

> Notifications about new or terminated instruments of a given kind in a given currency.

Use this channel to track instrument lifecycle events (new listings, expirations/terminations) without polling.

**Note:** Our system does not send notifications when currencies are locked. Users are advised to subscribe to the [platform_state](https://docs.deribit.com/subscriptions/platform/platform_state) channel to monitor the state of currencies actively.




## AsyncAPI

````yaml specifications/deribit_asyncapi.json instrument.state.(kind).(currency)
id: instrument.state.(kind).(currency)
title: 'instrument.state.(kind).(currency) '
description: >
  Notifications about new or terminated instruments of a given kind in a given
  currency.


  Use this channel to track instrument lifecycle events (new listings,
  expirations/terminations) without polling.


  **Note:** Our system does not send notifications when currencies are locked.
  Users are advised to subscribe to the
  [platform_state](https://docs.deribit.com/subscriptions/platform/platform_state)
  channel to monitor the state of currencies actively.
servers:
  - id: production
    protocol: wss
    host: deribit.com/ws/api/v2
    bindings: []
    variables: []
  - id: testnet
    protocol: wss
    host: test.deribit.com/ws/api/v2
    bindings: []
    variables: []
address: instrument.state.(kind).(currency)
parameters:
  - id: kind
    jsonSchema:
      type: string
      description: >-
        Instrument kind


        **Allowed values:** `future`, `option`, `spot`, `future_combo`,
        `option_combo`
      enum:
        - future
        - option
        - spot
        - future_combo
        - option_combo
    description: >-
      Instrument kind


      **Allowed values:** `future`, `option`, `spot`, `future_combo`,
      `option_combo`
    type: string
    required: true
    deprecated: false
  - id: currency
    jsonSchema:
      type: string
      description: |-
        Currency code or `any` for all

        **Allowed values:** `BTC`, `ETH`, `USDC`, `USDT`, `EURR`, `any`
      enum:
        - BTC
        - ETH
        - USDC
        - USDT
        - EURR
        - any
    description: |-
      Currency code or `any` for all

      **Allowed values:** `BTC`, `ETH`, `USDC`, `USDT`, `EURR`, `any`
    type: string
    required: true
    deprecated: false
bindings: []
operations:
  - &ref_2
    id: send_subscribe_instrument_state_kind_currency
    title: Send subscribe request for instrument
    description: Client sends subscription request for instrument updates
    type: send
    messages:
      - &ref_4
        id: subscription_message
        contentType: application/json
        payload:
          - name: Subscription Notification Data
            description: Server sends subscription notification data
            type: object
            properties:
              - name: data
                type: object
                required: true
                properties:
                  - name: timestamp
                    type: integer
                    description: The timestamp (milliseconds since the Unix epoch)
                    required: false
                  - name: state
                    type: string
                    description: >
                      The state of the order book. Represents the current
                      lifecycle stage of the instrument.


                      **State Lifecycle and Meanings:**


                      - `open`: Default state for running books. In this state
                      book is accepting new orders, edits, cancels; prices
                      should be updated, trading is live.

                      - `settlement`: Books enters to this state during
                      settlement/delivery. New orders, edits, cancels are not
                      accepted. After this state normally next state should be
                      `open` if it was settlement, or `delivered` if it was
                      delivery. On enter to this state good till day orders in
                      book are canceled.

                      - `delivered`: Final state of book that has been
                      delivered. New orders, edits, cancels are not accepted.
                      After some time book process will be terminated and,
                      instrument moved to `expired_instruments` and its
                      `instrument_state` will become archivized. On enter to
                      this all open orders in book are canceled.

                      - `inactive`: After a book is deactivated, this state is
                      set on book. New orders, edits, cancels are not accepted.
                      On enter to this all open orders in book are canceled.
                      Book in this state is not considered as open. This can be
                      also final state for book.

                      - `locked`: New orders, edits, are not accepted, only
                      cancels ARE accepted. In some cases when configured books
                      can start as locked or it may become locked on admin
                      request. Settlement is possible on locked books.

                      - `halted`: The state that books enter as a result of an
                      error. Settlement is not possible when there is at least
                      one book in this state.

                      - `archivized`: Set when instrument is moved to
                      `expired_instruments` table, final state.
                    enumValues:
                      - open
                      - settlement
                      - delivered
                      - inactive
                      - locked
                      - halted
                      - archivized
                    required: false
                  - name: instrument_name
                    type: string
                    description: Unique instrument identifier
                    required: false
        headers: []
        jsonPayloadSchema:
          type: object
          description: Response containing notification data
          properties:
            data:
              type: object
              properties:
                timestamp:
                  type: integer
                  example: 1536569522277
                  description: The timestamp (milliseconds since the Unix epoch)
                  x-parser-schema-id: <anonymous-schema-560>
                state:
                  description: >
                    The state of the order book. Represents the current
                    lifecycle stage of the instrument.


                    **State Lifecycle and Meanings:**


                    - `open`: Default state for running books. In this state
                    book is accepting new orders, edits, cancels; prices should
                    be updated, trading is live.

                    - `settlement`: Books enters to this state during
                    settlement/delivery. New orders, edits, cancels are not
                    accepted. After this state normally next state should be
                    `open` if it was settlement, or `delivered` if it was
                    delivery. On enter to this state good till day orders in
                    book are canceled.

                    - `delivered`: Final state of book that has been delivered.
                    New orders, edits, cancels are not accepted. After some time
                    book process will be terminated and, instrument moved to
                    `expired_instruments` and its `instrument_state` will become
                    archivized. On enter to this all open orders in book are
                    canceled.

                    - `inactive`: After a book is deactivated, this state is set
                    on book. New orders, edits, cancels are not accepted. On
                    enter to this all open orders in book are canceled. Book in
                    this state is not considered as open. This can be also final
                    state for book.

                    - `locked`: New orders, edits, are not accepted, only
                    cancels ARE accepted. In some cases when configured books
                    can start as locked or it may become locked on admin
                    request. Settlement is possible on locked books.

                    - `halted`: The state that books enter as a result of an
                    error. Settlement is not possible when there is at least one
                    book in this state.

                    - `archivized`: Set when instrument is moved to
                    `expired_instruments` table, final state.
                  type: string
                  enum:
                    - open
                    - settlement
                    - delivered
                    - inactive
                    - locked
                    - halted
                    - archivized
                  x-parser-schema-id: <anonymous-schema-561>
                instrument_name:
                  type: string
                  description: Unique instrument identifier
                  example: BTC-PERPETUAL
                  x-parser-schema-id: <anonymous-schema-562>
              required: []
              additionalProperties: false
              x-parser-schema-id: <anonymous-schema-559>
          required:
            - data
          additionalProperties: false
          x-parser-schema-id: <anonymous-schema-558>
        title: Subscription Notification Data
        description: Server sends subscription notification data
        example: |-
          {
            "data": {
              "timestamp": 1553080940000,
              "state": "open",
              "instrument_name": "BTC-22MAR19"
            }
          }
        bindings: []
        extensions:
          - id: x-parser-unique-object-id
            value: subscription_message
    bindings: []
    extensions: &ref_0
      - id: x-parser-unique-object-id
        value: instrument.state.(kind).(currency)
  - &ref_1
    id: receive_instrument_state_kind_currency_updates
    title: Receive instrument updates
    description: Client receives instrument update notifications
    type: receive
    messages:
      - &ref_3
        id: subscribe_request
        contentType: application/json
        payload:
          - name: Subscription Request
            description: >-
              Client sends subscription request to subscribe to notification
              channel. Please refer to [Notification
              page](https://deribit.mintlify.app/articles/notifications) for
              more information.
            type: object
            properties: []
        headers: []
        jsonPayloadSchema:
          properties: {}
          additionalProperties: false
          x-parser-schema-id: <anonymous-schema-557>
        title: Subscription Request
        description: >-
          Client sends subscription request to subscribe to notification
          channel. Please refer to [Notification
          page](https://deribit.mintlify.app/articles/notifications) for more
          information.
        example: |-
          {
            "jsonrpc": "2.0",
            "method": "public/subscribe",
            "id": 42,
            "params": {
              "channels": [
                "instrument.state.(kind).(currency)"
              ]
            }
          }
        bindings: []
        extensions:
          - id: x-parser-unique-object-id
            value: subscribe_request
    bindings: []
    extensions: *ref_0
sendOperations:
  - *ref_1
receiveOperations:
  - *ref_2
sendMessages:
  - *ref_3
receiveMessages:
  - *ref_4
extensions:
  - id: x-parser-unique-object-id
    value: instrument.state.(kind).(currency)
securitySchemes: []

````

