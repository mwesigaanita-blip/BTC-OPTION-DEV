# Portfolio Intelligence Engine - Concept and Design

## Purpose

The engine produces a structured interpretation of the market and the portfolio together. For every analysis run it answers four questions:

- What is the **current market state** (bullish, bearish, or neutral)?
- What has happened in the **last 48 hours**?
- How do current market conditions **affect the portfolio**?
- What **risks or opportunities** are present right now?

The engine is a decision-support layer on top of raw data. It does not place orders. It produces interpretations a human or a downstream system can act on.

---

## Core design decision: deterministic core plus AI reasoning layer

The most important design choice is **where the LLM is used and where it is not**.

The engine is split into two layers:

- **Deterministic core (no LLM).** Everything that is numeric, repeatable, and auditable: data ingestion, feature math, market-state scoring, threshold detection, warning flags, and Greek-based PnL impact. The same inputs always produce the same outputs. This layer is fast, cheap, and unit-testable.
- **AI reasoning layer (LLM, called once per run).** Takes the structured output of the deterministic core (the "state pack") and produces the narrative, the ranked explanation of warnings, and the human-readable summary. The LLM does not classify market state, does not invent numbers, and does not create new warnings.

This is the inverse of asking the LLM "what is happening?" with raw data. The LLM receives a finished, structured picture and is asked to explain it well. Synthesis and narration are what LLMs do well. Classification from raw indicators is where they are unreliable.

---

## Pipeline overview

The engine runs through seven stages. Stages 1, 2, 3 and 6 are fully deterministic. Stage 4 and stage 5 have a deterministic part and an AI part. Stage 7 is the AI synthesis.

---

### 1. Data ingestion (deterministic)

The engine reads from upstream collectors that already maintain fresh copies of the data:

**From Deribit:**

- BTC index price and perpetual price
- Funding rates
- Open interest
- Options data (implied volatility, skew)
- **DVOL** (Deribit BTC volatility index) and its term-structure slope. Cleaner regime signal than ATM IV alone; backwardation prices imminent risk, contango means calm. Endpoint: `public/get_volatility_index_data`.
- **Liquidation tape**, derived from the public trades feed. Trades carry a `liquidation` flag (`M` / `T` / `MT`); direction (`buy` / `sell`) identifies which side was force-closed.
- Portfolio data: positions, Greeks (delta, gamma, vega), margin metrics (MM%, equity)

**External sources.** Where Deribit alone is not enough, named third-party feeds add context the engine cannot derive on its own:

- **10x Research**: macro and crypto-specific research notes, narrative shifts, positioning calls.
- **Glassnode**: on-chain analytics (supply distribution, holder cohorts, realized cap, MVRV).
- **CryptoQuant**: exchange flows, miner activity, stablecoin supply on exchanges.
- **CoinGlass**: cross-exchange open interest, funding, and liquidation maps.
- **Laevitas / Amberdata**: institutional-grade options analytics (skew, term structure, dealer gamma).
- **Binance**: spot and futures volume, the largest non-Deribit liquidity reference.
- Market-wide sentiment indicators (Fear & Greed, social signals, derivatives positioning surveys).

Each external source is wrapped behind its own thin adapter so it can be added or removed without touching feature extraction. Features sourced externally carry a provenance tag (for example `source=glassnode`) so the audit trail records where every number came from.

This stage only reads. Data acquisition is owned by the existing snapshot builder and the realtime poller, so the engine never blocks waiting for a network call.

#### Liquidation tracking

Liquidations explain whether a move was forced or organic, and let the AI layer cite numbers ("$340M of long liquidations") instead of inferring from price.

A collector streams the Deribit trade tape, keeps tagged rows, and writes them to `liquidation_ticks(ts_utc, trade_id PK, instrument_name, kind, side, liq_tag, price, size_btc, notional_usd)`. `trade_id` as the primary key makes the writer idempotent. Storage mirrors the realtime poller's WAL pattern.

Scope: Deribit alone is roughly 5 to 15 percent of total crypto liquidations. Enough for *position-quality* signal (forced vs. organic). For a full *market-wide* heatmap, CoinGlass is layered in later through the adapter pattern.

---

### 2. Feature extraction (deterministic)

Raw rows are converted into interpretable, named features.

**Market features:**

- Price returns over multiple horizons (1h, 4h, 48h)
- Realized volatility over the 48h window, plus its percentile against the trailing 90 days (the "RV cone")
- Funding rate trend (positive, negative, increasing)
- Open interest change (rising, falling)
- DVOL level and DVOL term-structure slope (front month vs. longer dated)
- IV-vs-DVOL gap, replacing or augmenting the existing `iv_minus_hv_30d_pp`

**Liquidation features (from the Deribit liquidation tape, computed over 1h / 4h / 24h windows):**

- `liq_long_usd`, `liq_short_usd`, `liq_total_usd`, `liq_count`: pace and direction
- `liq_long_short_ratio`: how lopsided the wipeout is
- `liq_zscore`: current window vs. trailing 24h mean and stdev, the cascade signal
- `liq_kind_split`: share by perp / future / option

**Portfolio features:**

- Net delta exposure (BTC and USD)
- Vega exposure (long or short volatility)
- Gamma sensitivity
- Margin maintenance percentage (MM%)
- Drawdown from the high-water mark (HWM)

Every feature has a stable key, for example `btc_ret_4h_pct`, `mm_pct`, `iv_minus_hv_30d_pp`. Stable keys matter. Later stages cite features by name, and the AI layer can only refer to values that already exist in the feature set.

---

### 3. Market state classification (deterministic)

The engine combines features into a single market state (bullish, bearish, or neutral) using a transparent rule engine, not the LLM.

Multiple signals contribute:

- Trend across 1h / 4h / 48h horizons
- Volatility regime (IV vs. HV gap, realized vs. implied)
- Derivatives positioning (funding plus open interest)

Each signal contributes a signed, weighted, saturated value to a single score. The score is mapped into:

- **Bullish** when the score is above a positive threshold
- **Bearish** when the score is below a negative threshold
- **Neutral** when the score is inside the deadband

A confidence value is produced from signal *agreement*: how many of the directional signals point the same way.

State classification is deterministic by design. It must be reproducible and explainable, and the contribution of each feature must be visible.

---

### 4. Last 48 hours analysis (deterministic plus AI)

The engine builds a short-term narrative from recent behavior.

**Deterministic part.** Concrete numbers describing the window: total price move, volatility expansion or contraction, the largest absolute movers in the feature set (the "narrative kernel").

**AI part.** The narrative kernel is turned into prose. Patterns such as long build-up, short covering, or liquidation-driven moves can be named by the LLM, but only on top of features it can cite.

This stage provides context, not just a static state.

---

### 5. Portfolio impact mapping (deterministic plus AI)

The most critical stage, and the most natural place for the AI layer.

**Deterministic part: Greeks to PnL sensitivities.** Computed mechanically:

- PnL per ±1% spot move (delta plus half-gamma curvature)
- PnL per ±1pp IV move (vega)
- Delta alignment vs. market state: aligned, misaligned, or neutral
- Vega alignment vs. IV regime: aligned, misaligned, or neutral

**AI part: impact narrative.** The LLM connects market behavior to portfolio exposure in plain English:

- A bullish market with long-delta exposure is a positive impact.
- An expanding volatility regime against a short-vega position is a negative impact.
- A fast spot move with material gamma raises gamma risk.

The LLM evaluates whether the portfolio benefits from the current market, where the risks are coming from, and whether exposure is aligned with conditions. Every quantitative claim must reference a feature key. The LLM is not free to invent or estimate numbers.

---

### 6. Risk and warning detection (deterministic)

Beyond describing the situation, the engine identifies dangers, but not via LLM judgement.

The flags include:

- `MM_PRESSURE`: maintenance margin crossing risk bands
- `DRAWDOWN`: equity slippage versus the high-water mark
- `DELTA_MISALIGNED`: directional exposure against the current state
- `SHORT_VEGA_RISK`: short vega into an expanding volatility regime
- `GAMMA_RISK`: material gamma during a fast spot move
- `OVERHEATED`: multi-timeframe rally past mean-reversion thresholds
- `LIQUIDATION_CASCADE`: `liq_zscore_1h ≥ 3` together with `|btc_ret_1h_pct| ≥ 2%`. Severity `URGENT`.
- `LIQUIDATION_IMBALANCE`: long/short split more lopsided than ~85/15 with non-trivial notional. Severity `WARNING`.
- `LIQUIDATION_EXHAUSTION`: prior-bucket liq notional collapses while price keeps moving. Often marks the local turn. Severity `INFO`.

Each flag carries:

| Field | Purpose |
|---|---|
| `flag` | Stable name |
| `severity` | `INFO`, `WARNING`, `URGENT`, or `EMERGENCY` |
| `message` | Plain-English description |
| `cited_features` | Feature keys that triggered the flag |
| `feature_values` | Actual values at trigger time |

This is the audit surface. The LLM may rank these flags and explain them. It cannot invent a new flag, change its severity, or remove its citations.

---

### 7. Output generation (AI synthesis and structured persistence)

The LLM is called **once** per analysis run with the full state pack (features, state, narrative kernel, impact, warnings) together with a **diff against the previous run** so the model can produce a real "what changed" narrative instead of a cold-start summary.

Output is constrained to a strict schema:

```text
AnalysisOutput {
  market_state            : "bullish" | "bearish" | "neutral"   // echoed from state pack
  confidence              : 0..1                                // echoed from state pack
  narrative_48h           : 2-4 sentences, grounded in narrative kernel
  portfolio_impact_summary: 2-4 sentences, grounded in impact and Greeks
  ranked_warnings         : reordered subset of state-pack warnings
  human_summary           : one-paragraph plain-English readout
}
```

Two formats are produced from this output:

**1. Structured output (JSON).** Validated against the schema above. Persisted to SQLite alongside the state pack and LLM token usage. This is the audit trail.

**2. Human-readable summary.** A concise paragraph such as:

> "The market is currently bullish with strong upward momentum supported by increasing open interest and positive funding rates. Over the last 48 hours, BTC has rallied significantly with elevated volume, indicating aggressive long positioning. The portfolio benefits from positive delta exposure, but short volatility positions may be at risk if volatility continues to expand."

---

## When the engine runs: threshold triggers

The engine does **not** run on a fixed clock. Continuous LLM calls would burn cost producing identical analyses when nothing has changed.

Instead, a lightweight watcher checks the deterministic state every ~30 seconds and fires the engine only when a meaningful threshold is crossed:

| Trigger family    | Source                                 | Default threshold |
|---|---|---|
| Margin pressure   | `MM% = maintenance / margin balance`   | crosses 30% / 40% / 50% bands (either direction) |
| Equity move       | account equity, drawdown vs. HWM       | ±2% versus last run, or drawdown deepens by ≥1pp |
| BTC price         | realtime BTC tick feed                 | ±2% over 1h or ±5% over 4h |
| IV regime         | ATM IV 30d / DVOL, IV vs. HV gap       | IV ±10% relative, or gap shifts ≥3pp |
| Liquidation surge | Deribit liquidation tape               | `liq_zscore_1h ≥ 3` or `liq_total_usd_1h ≥ $200M` |

Each trigger family has a per-family debounce (default 5 minutes) so a feature oscillating around a threshold cannot fire repeatedly. A manual trigger is available for on-demand runs.

---

## Memory: diff against the previous run

A 48-hour narrative is meaningless without memory. Every analysis run is persisted: state pack, LLM output, warnings, token usage. When the next run starts, the engine computes a diff against the previous run for every feature and includes it in the LLM prompt.

This gives the AI layer real temporal awareness:

- "MM% moved from 28% to 41%, two bands crossed."
- "The IV vs. HV gap was -2pp last hour and is now +4pp, vol regime flipped."
- "Net delta moved from +0.1 BTC to +1.2 BTC, exposure increased materially."

Without persisted state and diffing, every LLM call starts cold and produces generic prose.

---

## Output destinations

The same analysis is delivered to three surfaces:

- **SQLite** (`portfolio_analysis.sqlite`): full structured history. Powers the audit trail and the diff-against-previous-run memory.
- **Streamlit panel**: operator-facing dashboard with the latest run, ranked warnings (with cited feature values shown inline), and recent history.
- **Telegram**: push notification when a warning of severity `WARNING` or higher fires. The existing urgency-based cooldowns are reused (EMERGENCY 60s, URGENT 3m, WARNING 10m, INFO 24h) so the channel is never spammy.

---

## Constraints on the AI layer

A loose LLM compromises this kind of system. Five rules pin it down:

1. **State is echoed, not classified.** The LLM copies `state` and `confidence` from the deterministic state pack. It cannot override the rule engine.
2. **No invented numbers.** Every quantitative claim must reference a feature key from the state pack (for example `mm_pct=42.0`).
3. **No invented warnings.** `ranked_warnings` is a re-ordering of the deterministic warning list. New flags are silently dropped.
4. **Strict JSON schema.** Output is validated through a Pydantic model. Validation failure falls back to a deterministic stub so the engine never returns garbage.
5. **One call per run.** No tool-use loops, no agent recursion. Predictable cost per trigger.

These constraints are what make the AI layer trustworthy enough to drive alerts.

---

## Design principles

- **Abstraction over raw data.** The system outputs states and insights, not indicators.
- **Portfolio-aware analysis.** Market analysis alone is not enough. Everything is mapped to the portfolio.
- **Multi-signal confirmation.** No single metric determines the state.
- **Right tool for the right job.** Deterministic code where reproducibility and auditability matter. LLM where language and synthesis matter.
- **Explainability by citation.** Every claim is traceable to a specific feature value.
- **Iterative improvement.** Start with a thin slice, then refine signals and prompts.

---

## Expected outcome

When fully implemented, the engine behaves like a real-time analyst that:

- Understands what the market is doing (deterministically scored)
- Explains why it is happening (LLM, grounded in cited features)
- Evaluates how it affects the portfolio (Greeks-derived plus LLM-narrated)
- Highlights risks and opportunities (deterministic flags, LLM-ranked)
- Notices what has changed since the last run (diff against previous run)

The result is faster, better-informed decisions without manually correlating multiple data sources.

---

## Summary

This engine is not a data processor. It is a context builder and risk interpreter that bridges:

> Market behavior -> Portfolio exposure -> Actionable insight

The bridge has a clear seam: a deterministic core that produces the facts, and an AI reasoning layer that explains them under strict constraints.
