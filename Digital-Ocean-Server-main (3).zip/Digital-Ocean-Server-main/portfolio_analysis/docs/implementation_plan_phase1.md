# Portfolio Co-Pilot - Detailed Code Implementation Plan

This document is the **execution playbook** for building the system specified in [plan.md](plan.md). Each phase produces something runnable and testable. Do not start a new phase until the previous one is fully verified.

---

## Iron rule - Test after every phase

**You must verify every phase before moving to the next one.**

For each phase:

1. Implement everything in the phase scope.
2. Run all tests listed in that phase's "Tests" section.
3. Run the manual verification steps in that phase's "Manual checks" section.
4. Only when **all** tests pass and **all** manual checks succeed → proceed to the next phase.
5. If anything fails → fix it inside that phase. Do **not** push the issue forward.

This rule exists because each later phase assumes the previous one is correct. A bug introduced in Phase 2 that surfaces in Phase 9 will cost ten times more to debug than catching it in Phase 2.

---

## Phase 0 - Project scaffolding & DB registration

**Goal:** establish the package skeleton and reserve the SQLite path. Nothing functional yet.

### Tasks

* Create directory `portfolio_analysis/` with empty `__init__.py`.
* Create empty subpackages: `features/`, `rules/`, `bot/`, `tests/` (each with `__init__.py`).
* Create `portfolio_analysis/config.py` with all default threshold constants (matching the master list in `plan.md`).
* Add `PORTFOLIO_ANALYSIS_DB` entry to `shared/db_paths.py` pointing to `<DATA_DIR>/portfolio_analysis.sqlite`.
* Add a one-line `README.md` in `portfolio_analysis/` pointing back to `docs/plan.md`.

### Tests

* `tests/test_config.py` - assert every threshold in the master list is defined and has the expected default value (numeric type + correct number).
* Import test: `python -c "import portfolio_analysis, portfolio_analysis.config"` exits 0.

### Manual checks

* `shared/db_paths.py` resolves `PORTFOLIO_ANALYSIS_DB` to the right location for both local and droplet environments.
* `tree portfolio_analysis/` shows the expected layout.

**Stop. Verify. Then proceed.**

---

## Phase 1 - Storage layer

**Goal:** create all SQLite tables in `portfolio_analysis.sqlite` with WAL mode and idempotent writers.

### Tasks

* `portfolio_analysis/storage.py` with:
  * `init_db(path)` - creates tables: `alerts`, `state_history`, `threshold_overrides`, `suppressions`, `audit_log`, `returns_history` (schemas in `plan.md` §1).
  * Enables WAL mode and sets `PRAGMA foreign_keys = ON`.
  * Idempotent writers: `insert_alert`, `insert_state`, `insert_override`, `insert_suppression`, `clear_suppression`, `insert_audit`, `insert_return`.
  * Readers: `latest_state`, `unresolved_alerts`, `active_suppressions`, `active_overrides_for(name)`, `recent_audit(n)`.
* Mirror the WAL/idempotency pattern of `realtime/storage.py`.

### Tests

* `tests/test_storage.py`:
  * `init_db` is idempotent (run twice → no error, no duplicate tables).
  * Insert + read round-trip for every writer.
  * `UNIQUE(dedup_key, ts_utc)` on `alerts` rejects duplicate inserts.
  * `UNIQUE(dedup_key, cleared_at_utc)` on `suppressions` allows multiple historical rows but only one active per key.
  * `unresolved_alerts()` returns only rows with `resolved_at_utc IS NULL`.

### Manual checks

* `sqlite3 portfolio_analysis.sqlite ".schema"` lists all six tables and indexes.
* `PRAGMA journal_mode;` returns `wal`.

**Stop. Verify. Then proceed.**

---

## Phase 2 - Dynamic threshold resolver

**Goal:** single source of truth for every threshold value, with override + expiry behaviour.

### Tasks

* `portfolio_analysis/thresholds.py`:
  * `get(name) -> float|int` - returns active override (latest non-expired) or default from `config.py`.
  * `set_override(name, value, duration_s, user_id, user_name)` - writes `threshold_overrides` row, appends `audit_log` row. (Broadcast hook is wired in Phase 8 - leave a TODO comment.)
  * `list_active() -> list[dict]` - for `/thresholds` command, joins active overrides with defaults.
  * In-process cache (60s TTL or invalidated on write).
  * `parse_duration(s)` helper accepting `30m`, `4h`, `7d`.

### Tests

* `tests/test_thresholds.py`:
  * `get(name)` returns config default when no override exists.
  * After `set_override`, `get(name)` returns the override value.
  * After `expires_at_utc` passes, `get(name)` reverts to the default.
  * `parse_duration("7d") == 7*86400`, `"30m" == 1800`, `"4h" == 14400`, invalid input raises.
  * `list_active()` correctly reports overridden vs default values.
  * Two overlapping overrides → the most recent one wins.

### Manual checks

* From a Python REPL: set an override with `duration_s=2`, sleep 3 seconds, confirm `get()` returns the default again.

**Stop. Verify. Then proceed.**

---

## Phase 3 - Feature derivation

**Goal:** compute the inputs every rule needs, from the existing realtime tables.

### Tasks

* `portfolio_analysis/features/market.py`:
  * `compute_returns(now_utc) -> dict` for timeframes `{1h, 4h, 24h}` from `realtime.sqlite::market_ticks`.
  * `compute_sigma(timeframe) -> float` from `returns_history` over the last 90 days.
* `portfolio_analysis/features/price_change.py`:
  * `compute_returns(now_utc) -> dict` for timeframes `{1h, 4h, 1d, 7d, 15d, 30d}`.
  * `compute_quantiles(timeframe) -> (q1, median, q3)` from 90-day buffer.
* `portfolio_analysis/features/positions.py`:
  * `compute_position_features(spot) -> list[PositionFeature]` reading latest `positions_ticks` JSON payload, returning `{instrument_name, strike, expiry, dte_days, distance_to_strike_pct, side}`.
* `FeatureBundle` dataclass that aggregates all of the above for a given evaluation cycle.

### Tests

* `tests/test_features_market.py` - synthetic `market_ticks` fixture; assert returns and σ match hand-computed values within float tolerance.
* `tests/test_features_price_change.py` - synthetic `returns_history` fixture; assert Q1/median/Q3 match `numpy.percentile`.
* `tests/test_features_positions.py` - synthetic `positions_ticks` JSON fixture covering both call and put, ITM and OTM; assert `dte_days` and `distance_to_strike_pct` are correct.
* Edge case: empty `market_ticks` → returns `None` for all timeframes (does not crash).

### Manual checks

* Run features against the live `realtime.sqlite` on the droplet; spot-check that 1h return matches what's visible in the live view.

**Stop. Verify. Then proceed.**

---

## Phase 4 - Rules engine (Rules 1–5)

**Goal:** implement all five active rules and the dedup machinery.

### Tasks

* `portfolio_analysis/rules/base.py`:
  * `Rule` Protocol with `name` + `evaluate(fb, t) -> list[Alert]`.
  * `Alert` frozen dataclass.
* One module per rule:
  * `rules/mm_pressure.py` - Rule 1
  * `rules/delta_drift.py` - Rule 2
  * `rules/dte_risk.py` - Rule 3
  * `rules/vol_sigma.py` - Rule 4
  * `rules/price_quantile.py` - Rule 5
* Each rule returns 0..N `Alert` objects with the dedup keys defined in `plan.md` §4.
* `rules/__init__.py` exposes `ALL_RULES` registry. Rule 6 module exists but raises `NotImplementedError` and is **not** in the registry.
* Dedup function in storage layer: given a candidate alert, suppress if (a) unresolved row exists for the same dedup_key, OR (b) active suppression exists for that key.
* Resolution function: stamp `resolved_at_utc` on open alerts whose conditions no longer hold; clear matching suppressions.

### Tests

* `tests/test_rule_mm.py` - feed `mm_pct` values 25, 30, 40, 50, 55 → expect alerts at the right severity tiers and correct dedup keys.
* `tests/test_rule_delta.py` - feed deltas across all bands incl. negative; verify sign in dedup key.
* `tests/test_rule_dte.py` - multiple positions at different DTE → one alert per position at the correct tier.
* `tests/test_rule_vol.py` - synthetic returns + σ → assert correct band classification incl. extreme.
* `tests/test_rule_quantile.py` - returns inside vs outside IQR → expected alerts.
* `tests/test_dedup.py`:
  * Fire a rule twice in the same band → only one row in `alerts`.
  * Fire, resolve (condition clears), fire again → two rows.
  * Suppression active → no insert.
  * Suppression cleared after resolution → next fire inserts again.
* `tests/test_rule6_stub.py` - importing the module is fine; loading into registry raises `NotImplementedError`.

### Manual checks

* In a REPL with a synthetic `FeatureBundle`, run every rule and inspect the returned `Alert` objects' `cited_features` and `feature_values` for completeness.

**Stop. Verify. Then proceed.**

---

## Phase 5 - Calm Score classifier

**Goal:** map a set of active alerts to a Calm Score state with deterministic reasoning text.

### Tasks

* `portfolio_analysis/state.py`:
  * `CalmState` enum: `RELAX`, `TAKE_A_LOOK`, `ACTIVE_MONITORING`, `URGENT_ACTION`.
  * `classify(active_alerts) -> (CalmState, reasoning_text)` per the table in `plan.md`.
  * Reasoning text is deterministic and human-readable.

### Tests

* `tests/test_state.py` - one fixture per tier:
  * `[]` → `RELAX`
  * `[INFO]`, `[WARNING]`, `[INFO, WARNING]` → `TAKE_A_LOOK`
  * `[URGENT]` → `ACTIVE_MONITORING`
  * `[WARNING] * 3` → `ACTIVE_MONITORING`
  * `[WARNING] * 2 + [URGENT]` → `ACTIVE_MONITORING`
  * `[EMERGENCY]` → `URGENT_ACTION`
* Reasoning text contains a count + each rule name + each severity → snapshot test.

### Manual checks

* None - pure function, fully covered by tests.

**Stop. Verify. Then proceed.**

---

## Phase 6 - AlertWorker (30 s evaluation loop)

**Goal:** end-to-end deterministic loop, no Telegram yet.

### Tasks

* `portfolio_analysis/worker.py::AlertWorker` - daemon thread mirroring `realtime/scheduler.py`'s pattern (try/except per cycle, shared `stop_event`).
* Each cycle:
  1. Read latest `hedge_engine_aggregated_metrics` row.
  2. Append latest returns to `returns_history` (one row per timeframe).
  3. Compute features.
  4. Resolve previously-open alerts whose conditions cleared; clear matching suppressions.
  5. Run rules → dedup → insert new alerts.
  6. Classify Calm Score → persist `state_history` row.
* Cycle target < 1 s; warn-log if exceeded.
* Use `realtime._logging.get_logger("portfolio_analysis.worker")`.

### Tests

* `tests/test_worker_cycle.py`:
  * Seed a synthetic agg-metrics row that triggers MM warning → run one cycle → assert `alerts` has the row, `state_history` shows `TAKE_A_LOOK`.
  * Run a second cycle with same row → assert no duplicate alert (dedup works).
  * Run a third cycle with mm_pct back to normal → assert original alert is `resolved_at_utc != NULL`, state is `RELAX`.
* Performance test: synthetic cycle completes in < 100 ms.

### Manual checks

* Run the worker as a thread for 60 s against `realtime.sqlite`; tail the log; confirm cycles fire every 30 s and never throw.

**Stop. Verify. Then proceed.**

---

## Phase 7 - Notifier adapter (Telegram, dry-run first)

**Goal:** wire the alert pipeline to Telegram with HTML formatting, but default to `DRY_RUN=1`.

### Tasks

* Modify `hedge_engine/notifications/notifier.py` to accept `cooldown_s=0` (or add `send_no_cooldown()`).
* `portfolio_analysis/notifier.py`:
  * `notify_alert(alert)` formats the HTML template from `plan.md` §7 and calls the underlying notifier.
  * Reads `TELEGRAM_PORTFOLIO_BOT_TOKEN` and `TELEGRAM_PORTFOLIO_CHAT_IDS` env vars.
  * Honours `DRY_RUN=1` → log payload, do not hit API.
* Wire into `AlertWorker`: after inserting a new alert, call `notify_alert`.

### Tests

* `tests/test_notifier_format.py` - given a synthetic `Alert`, assert the rendered HTML matches an expected snapshot.
* `tests/test_notifier_dry_run.py` - set `DRY_RUN=1`, fire `notify_alert`, assert no HTTP call (mock `requests`) and the payload was logged.
* `tests/test_notifier_disable_cooldown.py` - confirm two consecutive `notify_alert` calls with the same severity do not get blocked by `_COOLDOWNS`.

### Manual checks

* With `DRY_RUN=1`, run the worker, force a synthetic alert, confirm the would-send payload is logged correctly.
* With real token + a test chat, send one synthetic alert and verify it arrives with correct formatting.

**Stop. Verify. Then proceed.**

---

## Phase 8 - Telegram bot (control plane)

**Goal:** authorized users can send `/set`, `/stop`, `/resume`, `/status`, `/thresholds`, `/audit`, `/help` and trigger broadcasts.

### Tasks

* `portfolio_analysis/bot/auth.py` - `is_authorized(user_id) -> bool` against `AUTHORIZED_TELEGRAM_USER_IDS` env var.
* `portfolio_analysis/bot/broadcast.py::broadcast(text)` - sends to every chat in `TELEGRAM_PORTFOLIO_CHAT_IDS`.
* Wire `broadcast` into `thresholds.set_override` (the TODO from Phase 2).
* `portfolio_analysis/bot/commands.py` - one handler per command, each:
  * Checks auth.
  * Validates args.
  * Performs the action (override / suppress / read).
  * Broadcasts where applicable.
  * Appends `audit_log`.
  * Replies to the user.
* `portfolio_analysis/bot/server.py` - long-poll loop using `python-telegram-bot` (or raw `requests` if dependency-light is preferred); dispatches to handlers.
* Entry point: `python -m portfolio_analysis.bot.server`.

### Tests

* `tests/test_bot_auth.py` - authorized vs unauthorized user IDs.
* `tests/test_bot_set.py` - `/set MM_WARN_PCT 25 1h` → override row written, audit row appended, broadcast called (mocked), reply correct.
* `tests/test_bot_stop.py` - `/stop MM:band=warning` → suppression row written, audit row appended, broadcast called.
* `tests/test_bot_resume.py` - clears suppression, broadcasts, audits.
* `tests/test_bot_status.py` - returns current state + active alerts + active suppressions.
* `tests/test_bot_thresholds.py` - returns table including overridden values and expiry.
* `tests/test_bot_audit.py` - returns last N rows in correct order.
* `tests/test_bot_invalid.py` - bad args, bad threshold name, unknown command → friendly error replies, no DB writes.

### Manual checks

* In `DRY_RUN=1`, start scheduler + bot. From an authorized account:
  * `/set MM_WARN_PCT 25 1h` → next worker cycle uses 25.
  * `/thresholds` shows the override.
  * `/stop MM:band=warning` → next cycle does not re-notify.
  * `/audit` shows both actions.
* Repeat from an unauthorized account → `Not authorized.`

**Stop. Verify. Then proceed.**

---

## Phase 9 - HeartbeatWorker

**Goal:** per-state cadence "system alive" digest, separate from per-alert sends.

### Tasks

* `portfolio_analysis/heartbeat.py::HeartbeatWorker` - daemon thread.
* Each tick:
  1. Read latest `state_history` row.
  2. If `now - last_notified_utc >= HEARTBEAT_<state>_S` (resolved via `thresholds.get`), send digest.
  3. Update `last_notified_utc`.
* Digest format from `plan.md` §6b including suppressed-by-user line.

### Tests

* `tests/test_heartbeat_cadence.py`:
  * Mock time, set state to `RELAX`, advance 6 h → one heartbeat fires.
  * Set state to `URGENT_ACTION`, advance 1 min → fires every minute.
* `tests/test_heartbeat_format.py` - snapshot test of the rendered digest.
* `tests/test_heartbeat_threshold_override.py` - override `HEARTBEAT_RELAX_S` to 60 → next heartbeat fires after 60 s.

### Manual checks

* Run scheduler with `DRY_RUN=1`, accelerate intervals via overrides (`/set HEARTBEAT_RELAX_S 30 10m`), verify digests fire on schedule and contain the expected content.

**Stop. Verify. Then proceed.**

---

## Phase 10 - Daily PDF report

**Goal:** ship a polished daily PDF to every Telegram chat **in all cases** (regardless of state, regardless of activity), plus an on-demand `/report` command.

### Tasks

* Add the `report_runs` table to `storage.py` (schema in `plan.md` §1) plus a writer/reader.
* Add `PORTFOLIO_REPORT_DIR` (default `<DATA_DIR>/reports/`) to `config.py`; ensure the directory exists.
* Pick a PDF library: **`reportlab`** (recommended - small, no system deps). Add to `requirements.txt`.
* `portfolio_analysis/report_daily.py`:
  * `build_report(window_start, window_end) -> Path` - assembles the PDF:
    1. **Cover** - header bar + footer (page #, generated-at), color-coded **Calm Score badge**, 5-card KPI summary strip (alerts open/resolved, state changes, active stops, overrides, audit events).
    2. **Account snapshot** - 2-column metric grid with proper units & precision (mm_pct as `42.00 %`, delta as `+0.5421 BTC`, **gamma as a plain decimal - `0.00003`, never scientific notation, never rounded to misleading 0**, vega as `+12,345.67 USD`, btc_price as `$78,251.44`).
    3. **BTC rate-of-change strip** - 6-card row with ROC over 1h / 4h / 24h / 72h / 7d / 1m. Sub-day windows pull from realtime `market_ticks`; ≥24h windows pull from `market_data.sqlite::btc_prices.close`. Color-coded: green for +, red for −, grey for 0/no-data.
    4. **Calm Score timeline** - every state transition during the window, with colored "calm pills" inline.
    5. **Alerts table** - ts, rule, severity (color-coded badge), dedup, status (`open`/`resolved` plus `stopped` if user suppressed), the user who stopped it, message.
    6. **Threshold overrides table** - set_at, name, value, set_by, expires_at, `✅ active` / `⌛ expired` badge.
  * Audit log section is intentionally NOT in the PDF (per user preference) - the bot's `/audit` command remains the way to inspect it.
  * Charts (matplotlib PNG embeds) are deferred until the user requests them.
  * `send_report(pdf_path, caption)` - uses Telegram `sendDocument`; honours `DRY_RUN=1` (write to disk + log path, do not call API).
  * `DailyReportWorker` daemon thread:
    * Computes next fire time from `REPORT_DAILY_UTC_HOUR` (default 0) and `REPORT_DAILY_UTC_MINUTE` (default 5).
    * On each tick, fires if now ≥ next_fire_time, then advances by 24 h.
    * Persists `last_report_sent_utc` via `report_runs` so a restart does not double-send (skip if today's row exists) and does not skip a missed window (if no row exists for the most recent expected fire time, fire it once on startup).
    * On send failure: retry once after 60 s; then log ERROR with traceback and continue. Independent of the next day.
* Wire `/report` into the bot (Section 8) - calls `build_report(now-24h, now)` and `send_report` to the requesting chat. Audited.
* `notifier.py` gets a `send_document(path, caption, chat_ids=None)` helper used by both the daily worker and the `/report` command.

### Tests

* `tests/test_report_build.py`:
  * Seed synthetic `alerts`, `state_history`, `threshold_overrides`, `audit_log`, `market_ticks` rows for a 24h window.
  * Build the report → assert PDF file exists, > 0 bytes.
  * Parse the PDF with `pypdf` (or `pdfplumber`) → assert key strings present (current Calm Score, each alert's rule name, each threshold override name, every audit line).
* `tests/test_report_empty_window.py` - no activity in window → PDF still generated, contains "No alerts in this window" placeholder rows. Confirms the "in all cases" rule.
* `tests/test_report_dry_run.py` - `DRY_RUN=1` → file written to `PORTFOLIO_REPORT_DIR`, no HTTP call (mock `requests`), `report_runs` row inserted with `sent_chat_ids='[]'`.
* `tests/test_report_send.py` - mock the Telegram API → assert `sendDocument` called with the right `chat_id` and file payload; `report_runs.sent_chat_ids` JSON contains the chat IDs.
* `tests/test_report_worker_cadence.py`:
  * Mock time, set `REPORT_DAILY_UTC_HOUR=0`, `REPORT_DAILY_UTC_MINUTE=5`, advance to 00:05 → exactly one fire.
  * Advance another 23h59m → no fire.
  * Advance another minute → second fire, `report_runs` has 2 rows.
* `tests/test_report_worker_restart_safety.py`:
  * Pre-seed a `report_runs` row for today's window → start worker at the same instant → no duplicate fire.
  * Pre-seed nothing and start worker 1 h after the daily trigger → fires once for the missed window.
* `tests/test_report_worker_send_failure.py` - first `sendDocument` raises, second succeeds → worker retries after 60 s (mock sleep), `report_runs` row records success on the retry.
* `tests/test_bot_report_command.py` - `/report` from authorized user → PDF built for last-24h window, `sendDocument` called to the requesting chat, audit row appended; unauthorized user → `Not authorized.`

### Manual checks

* With `DRY_RUN=1`: invoke `python -m portfolio_analysis.report_daily --once` → a PDF appears in `data/reports/`, opens correctly, contains all six sections.
* Start the worker with an override to fire in 2 minutes → wait → verify a PDF is written and `report_runs` is updated.
* From an authorized Telegram account, send `/report` (against a real test bot) → confirm the PDF arrives in the chat with the correct caption and renders cleanly on mobile.

**Stop. Verify. Then proceed.**

---

## Phase 11 - Scheduler (process supervisor)

**Goal:** single entry point owns all three workers' lifecycles.

### Tasks

* `portfolio_analysis/scheduler.py` - mirrors `realtime/scheduler.py::RealtimeScheduler`.
  * Starts `AlertWorker`, `HeartbeatWorker`, **and `DailyReportWorker`** as daemon threads.
  * Shared `stop_event`, signal handling for SIGTERM / SIGINT.
  * `--health` flag: runs full stack 12 s, prints health snapshot (one line per worker), exits 0.
* Entry point: `python -m portfolio_analysis.scheduler`.

### Tests

* `tests/test_scheduler_lifecycle.py` - start scheduler in a thread, assert all three workers running, send stop event, assert clean shutdown within 5 s.
* `tests/test_scheduler_health.py` - `--health` exits 0 and prints a parseable health JSON line covering all three workers.

### Manual checks

* `python -m portfolio_analysis.scheduler --health` runs cleanly.
* Start the scheduler manually, watch logs for ~2 minutes, confirm all three workers tick on schedule and there are no exceptions.

**Stop. Verify. Then proceed.**

---

## Phase 12 - Replay tool

**Goal:** offline historical replay for sanity-checking alert volume.

### Tasks

* `portfolio_analysis/replay.py`:
  * CLI: `python -m portfolio_analysis.replay --hours 24`.
  * Iterates historical `hedge_engine_aggregated_metrics` rows in time order.
  * For each row, computes features (using the historical `market_ticks`), runs rules, prints `(ts, alert, severity)` stream.
  * Asserts ≤ 6 alerts/hour averaged over the window; exits non-zero if violated.

### Tests

* `tests/test_replay_smoke.py` - synthetic 24h dataset crafted to produce a controlled alert volume; replay returns the expected count.
* `tests/test_replay_ceiling.py` - synthetic dataset that exceeds the ceiling; replay exits non-zero.

### Manual checks

* Run replay against the last 24 h of real droplet data; alert volume is sane; spot-check a few alerts against the live view.

**Stop. Verify. Then proceed.**

---

## Phase 13 - End-to-end integration test (DRY_RUN)

**Goal:** prove the whole system works together before going live.

### Tasks

* `tests/test_e2e_dry_run.py`:
  * Spin up scheduler + bot in subprocesses with `DRY_RUN=1`.
  * Seed `hedge_engine_aggregated_metrics` with a row that triggers MM warning.
  * Wait one cycle → assert alert was logged for would-send.
  * Send `/stop MM:band=warning` from an authorized test user → assert broadcast logged, audit row appended.
  * Wait next cycle → assert no re-send.
  * Seed mm_pct back to normal → assert alert resolved, suppression cleared.
  * Seed mm_pct above threshold again → assert new alert fires.
  * Send `/report` from authorized test user → assert PDF written under `data/reports/` and audit row appended.

### Manual checks

* All E2E test steps pass cleanly.
* Inspect the resulting `portfolio_analysis.sqlite` - row counts in `alerts`, `suppressions`, `audit_log` match the script's expectations.

**Stop. Verify. Then proceed.**

---

## Phase 14 - Live deployment (droplet)

**Goal:** run for real with the production Telegram bot.

### Tasks

* Add `portfolio_analysis_scheduler` and `portfolio_analysis_bot` services to `docker-compose.yml` (mirror existing realtime services).
* Set `TELEGRAM_PORTFOLIO_BOT_TOKEN`, `TELEGRAM_PORTFOLIO_CHAT_IDS`, `AUTHORIZED_TELEGRAM_USER_IDS` in the droplet env.
* Unset `DRY_RUN` (or set to `0`).
* Deploy and tail logs.

### Tests

* No new unit tests - existing suite must still pass against the production env config.

### Manual checks

* Both services come up healthy.
* Within 30 s, a heartbeat or alert appears in the Telegram chat (depending on current state).
* From an authorized account: `/status`, `/thresholds`, `/audit` all reply correctly.
* `/set MM_WARN_PCT 25 5m` → broadcast appears, expires after 5 min, broadcast does not re-fire on expiry (silent revert per spec).
* Watch for 24 h: alert volume is acceptable, no crash loops, no duplicate alerts. Confirm the daily PDF report arrives in the chat at the configured UTC time and renders correctly on mobile.

**Stop. Verify. Done.**

---

## Cross-cutting requirements (apply to every phase)

* **Logging.** Every module uses `realtime._logging.get_logger("portfolio_analysis.<sub>")`. Levels per `plan.md` §9.
* **No hard-coded thresholds outside `config.py`.** Every comparison goes through `thresholds.get(name)`.
* **Idempotency.** Every DB writer must be safe to call twice with the same input.
* **Type hints.** All public functions are fully typed.
* **No silent exceptions.** Catching is fine inside worker cycles, but every catch must log at WARNING or ERROR with context.
* **Tests live in `portfolio_analysis/tests/`** and run via `pytest portfolio_analysis/tests/`.

---

## Summary checklist (pin this somewhere visible while building)

- [x] Phase 0 - scaffolding & DB registration → tests pass → manual checks pass ✅
- [x] Phase 1 - storage → tests pass → manual checks pass ✅
- [x] Phase 2 - threshold resolver → tests pass → manual checks pass ✅
- [x] Phase 3 - feature derivation → tests pass → manual checks pass ✅
- [x] Phase 4 - rules engine → tests pass → manual checks pass ✅
- [x] Phase 5 - Calm Score → tests pass → manual checks pass ✅
- [x] Phase 6 - AlertWorker → tests pass → manual checks pass ✅
- [x] Phase 7 - notifier (DRY_RUN) → tests pass → manual checks pass ✅
- [x] Phase 8 - Telegram bot → tests pass → manual checks pass ✅
- [x] Phase 9 - HeartbeatWorker → tests pass → manual checks pass ✅
- [x] Phase 10 - Daily PDF report → tests pass → manual checks pass ✅
- [x] Phase 11 - scheduler → tests pass → manual checks pass ✅
- [x] Phase 12 - replay tool → tests pass → manual checks pass ✅
- [x] Phase 13 - E2E integration (DRY_RUN) → tests pass → manual checks pass ✅
- [x] Phase 14 - live deployment → 24 h soak passes ✅

**Reminder: do not check a box until both the tests and the manual checks for that phase have actually passed.**
