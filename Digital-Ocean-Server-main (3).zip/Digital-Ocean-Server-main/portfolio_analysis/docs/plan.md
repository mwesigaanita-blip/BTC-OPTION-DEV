# Portfolio Co-Pilot - Implementation Plan (v2)

## Context

The realtime data pipeline (poller → storage → aggregator) already produces a 60-second `hedge_engine_aggregated_metrics` row containing `delta`, `gamma`, `vega`, `mm_pct`, `btc_price`, `btc_roc`, `sample_n`, plus raw `account_ticks`, `positions_ticks`, `market_ticks` in `realtime.sqlite`. A Telegram notifier with urgency cooldowns lives in `hedge_engine/notifications/notifier.py`.

What's missing is a **deterministic alert engine + interactive Telegram control plane** that consumes that data, classifies risk into a four-tier "Calm Score", sends structured alerts, and lets authorized users dynamically retune thresholds, stop alerts they're handling, and audit who did what - all from inside Telegram.

This document supersedes the previous plan and the parallel `plan.docx`. Only `basic_ideas.md` (intent doc) is unchanged.

**Phase 1 - $0/month, ~5 working days** (single engineer): uses existing Digital Ocean droplet, free Deribit + Telegram APIs, SQLite. Delivers the deterministic alert engine + interactive Telegram control plane end-to-end (storage, dynamic-threshold resolver, features, 5 rules, Calm Score, scheduler, heartbeat, notifier, bot commands, audit log, replay test).

**Phase 2 - ~$20/month, ~4 working days** (single engineer, deferred): LLM reasoning layer with threshold-triggered calls + prompt caching (LLM is the only paid component). Delivers state pack, diff, Pydantic schema with deterministic fallback, and a conversational "why?" Telegram thread. Out of scope for this rewrite - see Section 12.

---

## Global rule - Dynamic thresholds via Telegram

Every numeric threshold defined in this plan **must** be overridable at runtime via the Telegram bot for a user-supplied duration. This is load-bearing: the system has one source of truth (`threshold_overrides` table) and resolves every comparison through it.

### Behaviour

1. Authorized user issues `/set <threshold_name> <value> <duration>` (e.g., `/set MM_WARN_PCT 35 7d`).
2. Engine writes a row to the `threshold_overrides` table with `expires_at_utc = now + duration`.
3. Every rule evaluation calls `thresholds.get(name)`, which returns the latest non-expired override or falls back to the default in `portfolio_analysis/config.py`.
4. When the override expires (lazy check on next read), the value silently reverts to default.
5. **Every change broadcasts** to all subscribed Telegram chats: `User <name> changed <threshold_name> to <value> for <duration>`.
6. All changes are appended to the `audit_log` table (Section 8).

### Overrideable thresholds (master list)

| Name | Default |
|---|---|
| `MM_WARN_PCT` | 30 |
| `MM_URGENT_PCT` | 40 |
| `MM_CRITICAL_PCT` | 50 |
| `DELTA_GOOD_BTC` | 0.50 |
| `DELTA_WARN_BTC` | 1.00 |
| `DELTA_CRITICAL_BTC` | 2.00 |
| `DTE_WARN_DAYS` | 30 |
| `DTE_CRITICAL_DAYS` | 15 |
| `HEARTBEAT_RELAX_S` | 21600 |
| `HEARTBEAT_TAKE_A_LOOK_S` | 7200 |
| `HEARTBEAT_ACTIVE_MONITORING_S` | 1800 |
| `HEARTBEAT_URGENT_ACTION_S` | 60 |

The σ-multipliers (1/2/3) and 90-day lookback for the volatility rule, and the quantile cuts (25/50/75) for the price-change rule, are **fixed in code** and not overrideable.

---

## Rules and classifications (final)

### Rule 1 - Maintenance margin (MM%)

| Tier | Condition | Severity |
|---|---|---|
| Normal | mm_pct < `MM_WARN_PCT` | - |
| Attention | mm_pct ≥ `MM_WARN_PCT` (30) | INFO |
| Warning | mm_pct ≥ `MM_URGENT_PCT` (40) | WARNING |
| Critical | mm_pct ≥ `MM_CRITICAL_PCT` (50) | URGENT |

### Rule 2 - Delta drift (absolute, BTC)

| Tier | Condition | Severity |
|---|---|---|
| Good | abs(delta) ≤ `DELTA_GOOD_BTC` (±0.50) | - |
| Warning | abs(delta) ≤ `DELTA_WARN_BTC` (±1.00) | WARNING |
| Critical | abs(delta) > `DELTA_WARN_BTC`, ≤ `DELTA_CRITICAL_BTC` (±2.00) | URGENT |
| Beyond critical | abs(delta) > `DELTA_CRITICAL_BTC` | URGENT (re-fires on band cross) |

### Rule 3 - Time to expiry (DTE) per option position

| Tier | Condition | Severity |
|---|---|---|
| Good | dte > `DTE_WARN_DAYS` (30) | - |
| Warning | dte ≤ `DTE_WARN_DAYS` (30) | WARNING |
| Critical | dte ≤ `DTE_CRITICAL_DAYS` (15) | URGENT |

### Rule 4 - Volatility / movement (σ-based)

For each timeframe in {1h, 4h, 24h}:

1. Compute realized BTC return for the timeframe.
2. From a rolling 90-day historical buffer of returns at the same timeframe, compute σ.
3. Classify the **current** return against the live σ:

| Tier | Condition | Severity |
|---|---|---|
| Normal | within ±1σ | - |
| Warning | between ±1σ and ±2σ | WARNING |
| Critical | beyond ±2σ | URGENT |
| Extreme | beyond ±3σ | URGENT (separate dedup bucket) |

σ-multipliers (1/2/3) and lookback (90d) are not overrideable.

### Rule 5 - BTC price change (quantile-based)

For each timeframe in {1h, 4h, 1d, 7d, 15d, 30d}:

1. Compute current return for the timeframe.
2. From rolling 90-day buffer, compute Q1 (25%), median (50%), Q3 (75%).
3. Classify:

| Tier | Condition | Severity |
|---|---|---|
| Normal | Q1 ≤ ret ≤ Q3 | - |
| Outside-IQR | ret < Q1 or ret > Q3 | WARNING |

Cross-timeframe combinations are surfaced in the alert message body (e.g., "1h outside-IQR while 30d normal → short-term anomaly"), not as a separate rule. The 5%/95% extreme tails are deferred.

### Rule 6 - PENDING

No implementation in this iteration. Reserved as a placeholder in `config.py` and the rules registry; the rule module raises `NotImplementedError` if loaded.

### Calm Score classification

| Tier | Trigger |
|---|---|
| `RELAX` | no alerts active |
| `TAKE_A_LOOK` | ≥ 1 INFO or WARNING active |
| `ACTIVE_MONITORING` | ≥ 1 URGENT, OR ≥ 3 WARNING active |
| `URGENT_ACTION` | ≥ 1 EMERGENCY active |

EMERGENCY is reserved (not currently emitted by Rules 1–5) and remains in the schema for future high-severity rules.

### Heartbeat intervals per state

| State | Heartbeat cadence |
|---|---|
| `RELAX` | every 6 h |
| `TAKE_A_LOOK` | every 2 h |
| `ACTIVE_MONITORING` | every 30 min |
| `URGENT_ACTION` | every 1 min |

Heartbeat = "system alive" digest with current state, active alerts summary, and reasoning. Separate from per-alert sends.

---

## System layout

```
portfolio_analysis/
├── __init__.py
├── config.py                # default thresholds, env, constants
├── thresholds.py            # dynamic threshold resolver (overrides + defaults)
├── storage.py               # WAL sqlite: alerts, state_history, threshold_overrides,
│                            #   suppressions, audit_log, returns_history, report_runs
├── features/
│   ├── market.py            # 1h/4h/24h returns + rolling σ buffers
│   ├── price_change.py      # 1h/4h/1d/7d/15d/30d returns + quantile buffers
│   └── positions.py         # per-position dte, distance_to_strike, side
├── rules/
│   ├── base.py              # Rule protocol, Alert dataclass
│   ├── mm_pressure.py       # Rule 1
│   ├── delta_drift.py       # Rule 2
│   ├── dte_risk.py          # Rule 3
│   ├── vol_sigma.py         # Rule 4
│   ├── price_quantile.py    # Rule 5
│   └── __init__.py          # ALL_RULES registry (Rule 6 stub omitted)
├── state.py                 # Calm Score classifier
├── worker.py                # AlertWorker (30s loop)
├── heartbeat.py             # HeartbeatWorker (per-state cadence)
├── report_daily.py          # DailyReportWorker - builds + sends a daily PDF
├── notifier.py              # adapter over hedge_engine TelegramNotifier
├── bot/
│   ├── __init__.py
│   ├── server.py            # long-poll Telegram bot (separate process)
│   ├── commands.py          # /set, /stop, /resume, /status, /thresholds, /audit
│   ├── auth.py              # AUTHORIZED_TELEGRAM_USER_IDS allowlist
│   └── broadcast.py         # broadcast() helper used by commands + threshold writes
├── scheduler.py             # owns AlertWorker + HeartbeatWorker lifecycle
├── replay.py                # offline historical replay tool
└── tests/
```

Two long-running processes in production:

1. `python -m portfolio_analysis.scheduler` - alert worker + heartbeat worker + daily-report worker.
2. `python -m portfolio_analysis.bot.server` - Telegram command bot.

Both share `portfolio_analysis.sqlite`. Either can restart independently.

---

## 1. Storage

Add `PORTFOLIO_ANALYSIS_DB` to `shared/db_paths.py`.

```sql
-- Alert events emitted by the rules engine.
CREATE TABLE alerts (
    id INTEGER PRIMARY KEY,
    ts_utc TEXT NOT NULL,
    rule TEXT NOT NULL,
    severity TEXT NOT NULL,            -- INFO | WARNING | URGENT | EMERGENCY
    dedup_key TEXT NOT NULL,
    cited_features TEXT NOT NULL,      -- JSON array
    feature_values TEXT NOT NULL,      -- JSON object
    message TEXT,
    notified_at_utc TEXT,
    resolved_at_utc TEXT,              -- set when condition no longer true
    UNIQUE(dedup_key, ts_utc)
);
CREATE INDEX idx_alerts_ts ON alerts(ts_utc);
CREATE INDEX idx_alerts_dedup ON alerts(dedup_key);
CREATE INDEX idx_alerts_unresolved ON alerts(resolved_at_utc) WHERE resolved_at_utc IS NULL;

-- Calm-score history.
CREATE TABLE state_history (
    ts_utc TEXT PRIMARY KEY,
    calm_score TEXT NOT NULL,
    active_alert_ids TEXT,             -- JSON array
    reasoning TEXT,
    last_notified_utc TEXT
);

-- Dynamic threshold overrides.
CREATE TABLE threshold_overrides (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    value REAL NOT NULL,
    set_by_user_id INTEGER NOT NULL,
    set_by_user_name TEXT NOT NULL,
    set_at_utc TEXT NOT NULL,
    expires_at_utc TEXT NOT NULL
);
CREATE INDEX idx_overrides_active ON threshold_overrides(name, expires_at_utc);

-- Per-alert suppressions ("user is handling this"). Auto-clears when
-- the underlying alert resolves.
CREATE TABLE suppressions (
    id INTEGER PRIMARY KEY,
    dedup_key TEXT NOT NULL,
    set_by_user_id INTEGER NOT NULL,
    set_by_user_name TEXT NOT NULL,
    set_at_utc TEXT NOT NULL,
    cleared_at_utc TEXT                -- set when alert resolves
);
-- Partial unique index - SQLite treats NULLs in UNIQUE() as distinct,
-- so this is the correct way to enforce "only one active suppression
-- per dedup_key".
CREATE UNIQUE INDEX uniq_suppressions_active
    ON suppressions(dedup_key) WHERE cleared_at_utc IS NULL;

-- Audit log of every authorized user action.
CREATE TABLE audit_log (
    id INTEGER PRIMARY KEY,
    ts_utc TEXT NOT NULL,
    user_id INTEGER NOT NULL,
    user_name TEXT NOT NULL,
    action TEXT NOT NULL,              -- set_threshold | stop_alert | resume_alert | broadcast
    payload_json TEXT NOT NULL
);

-- Rolling per-timeframe return history (for σ and quantile buffers).
CREATE TABLE returns_history (
    ts_utc TEXT NOT NULL,
    timeframe TEXT NOT NULL,           -- 1h|4h|24h|1d|7d|15d|30d
    return_pct REAL NOT NULL,
    PRIMARY KEY (ts_utc, timeframe)
);
CREATE INDEX idx_returns_tf_ts ON returns_history(timeframe, ts_utc);

-- Daily-report send history (Section 6c).
CREATE TABLE report_runs (
    id INTEGER PRIMARY KEY,
    ts_utc TEXT NOT NULL,
    window_start_utc TEXT NOT NULL,
    window_end_utc TEXT NOT NULL,
    pdf_path TEXT,
    sent_chat_ids TEXT,                -- JSON array
    error TEXT
);
CREATE INDEX idx_report_runs_ts ON report_runs(ts_utc);
```

WAL mode and idempotent writers - mirror `realtime/storage.py`.

---

## 2. Threshold resolver

`portfolio_analysis/thresholds.py`:

```python
def get(name: str) -> float | int:
    """Return active override value, or default from config.py."""

def set_override(name, value, duration_s, user_id, user_name) -> None:
    """Insert override row; emit broadcast; append audit_log."""

def list_active() -> list[dict]:
    """For /thresholds command."""
```

Lookup is in-process cache invalidated on write or every 60s.

---

## 3. Feature derivation

| Module | Output | Source |
|---|---|---|
| `features/market.py` | `btc_ret_1h`, `btc_ret_4h`, `btc_ret_24h` + σ from `returns_history` | `realtime.sqlite::market_ticks` |
| `features/price_change.py` | `btc_ret_{1h,4h,1d,7d,15d,30d}` + quantiles | `realtime.sqlite::market_ticks` |
| `features/positions.py` | per-position `{instrument_name, strike, expiry, dte_days, distance_to_strike_pct, side}` | latest `positions_ticks` |

`returns_history` is appended on every worker cycle (one row per timeframe per cycle). A periodic vacuum keeps only the last 90 days.

---

## 4. Rules engine

```python
class Rule(Protocol):
    name: str
    def evaluate(self, fb: FeatureBundle, t: ThresholdResolver) -> list[Alert]: ...

@dataclass(frozen=True)
class Alert:
    rule: str
    severity: str              # INFO | WARNING | URGENT | EMERGENCY
    dedup_key: str
    cited_features: list[str]
    feature_values: dict[str, Any]
    message: str
```

Five active rules (Rules 1–5). Rule 6 = stub.

Dedup keys (re-fire only on band cross):

| Rule | Dedup key |
|---|---|
| MM | `MM:band={attention,warning,critical}` |
| Delta | `DELTA:sign=±:band={warning,critical,beyond}` |
| DTE | `DTE:{instrument_name}:band={warning,critical}` |
| σ vol | `VOL:{tf}:dir=±:band={warning,critical,extreme}` |
| Quantile | `QUANTILE:{tf}:dir={low,high}` |

A new alert is suppressed if (a) its `dedup_key` already has an unresolved row in `alerts`, OR (b) an active row exists in `suppressions` for that key. When a rule no longer triggers, the worker stamps `resolved_at_utc` on the open alert AND clears any matching suppression (`cleared_at_utc = now`).

---

## 5. Calm Score

`state.py::classify(active_alerts) -> CalmState` implements the Calm Score classification table above. Reasoning text is deterministic, e.g.:

`ACTIVE_MONITORING - 1 URGENT (MM critical 52%), 2 WARNING (delta 1.1 BTC, vol 1h 2.1σ)`

Persist to `state_history` on state change OR on heartbeat tick.

---

## 6. Workers

### 6a. AlertWorker (30 s loop)

In `worker.py`. Each cycle:

1. Read latest `hedge_engine_aggregated_metrics` row.
2. Append latest returns to `returns_history`.
3. Compute features (market σ buffers, quantile buffers, positions).
4. Resolve previously-open alerts whose conditions no longer hold; clear matching suppressions.
5. Run rules → candidate alerts → dedup → insert.
6. Classify Calm Score → persist `state_history`.
7. Hand new alerts to notifier (Section 7).

Cycle target < 1 s; warn-log if exceeded.

### 6b. HeartbeatWorker

In `heartbeat.py`. Reads latest `state_history`; if `now - last_notified_utc ≥ HEARTBEAT_<state>_S`, sends digest:

```
[HEARTBEAT] State: ACTIVE_MONITORING
Active alerts (3): MM 41%, DELTA 1.1 BTC, VOL_1h 2.3σ
Suppressed by user: DELTA (Andres)
2026-05-02T14:00:00Z
```

### 6c. DailyReportWorker

In `report_daily.py`. Builds and sends a **daily PDF report** to every chat in `TELEGRAM_PORTFOLIO_CHAT_IDS`, **in all cases** - regardless of Calm Score state, regardless of whether anything noteworthy happened. The report is the system's daily proof-of-life and audit trail.

* **Trigger.** Once per day at a fixed UTC time (default `00:05 UTC`, configurable via `REPORT_DAILY_UTC_HOUR` / `REPORT_DAILY_UTC_MINUTE` env). On worker start, computes the next fire time; on each tick, fires if now ≥ next fire time, then advances by 24 h. Survives restarts: persists `last_report_sent_utc` in a small `report_runs` table to avoid double-sending after a crash.
* **Coverage window.** The previous 24 hours, ending at the trigger time.

#### Report contents

1. **Cover** - date range, current Calm Score, account snapshot (mm_pct, delta, gamma, vega, btc_price).
2. **Calm Score timeline** - every state transition during the window (ts, from → to, reasoning).
3. **Alerts** - table of every alert fired in the window: ts, rule, severity, message, resolved (Y/N), suppressed-by-user (name).
4. **Threshold overrides** - every override that was active at any point in the window: name, value, set_by, duration, expired (Y/N).
5. **Audit log** - full `audit_log` slice for the window (commands issued by users).
6. **Charts** (optional but recommended) - small line plots of `btc_price`, `mm_pct`, `delta` over the window.

#### Delivery

* PDF rendered to a temp file, then sent via Telegram `sendDocument` (caption: `📄 Portfolio daily report - YYYY-MM-DD`).
* Honours `DRY_RUN=1` → write the PDF to `data/reports/` and log the path; do not call the API.
* On send failure: retry once after 60 s, then log ERROR and continue. The next day's report is independent.

#### On-demand variant

Authorized users can also request the report at any time via `/report` (Section 8). Same builder, same template, but the window ends at "now" instead of the daily trigger.

#### Storage addition

```sql
CREATE TABLE report_runs (
    id INTEGER PRIMARY KEY,
    ts_utc TEXT NOT NULL,
    window_start_utc TEXT NOT NULL,
    window_end_utc TEXT NOT NULL,
    pdf_path TEXT,
    sent_chat_ids TEXT,           -- JSON array of chat IDs we successfully sent to
    error TEXT
);
CREATE INDEX idx_report_runs_ts ON report_runs(ts_utc);
```

All three workers (`AlertWorker`, `HeartbeatWorker`, `DailyReportWorker`) live under `portfolio_analysis/scheduler.py`, mirroring the daemon-thread pattern of `realtime/scheduler.py`. Entry point: `python -m portfolio_analysis.scheduler`.

---

## 7. Notifier (adapter)

`portfolio_analysis/notifier.py` is a thin wrapper over `hedge_engine/notifications/notifier.py::TelegramNotifier`. It does NOT use the legacy `_COOLDOWNS` map - cooldowns are now expressed via dedup keys + per-state heartbeat cadence. It passes `urgency=alert.severity` purely for formatting and disables the notifier's internal cooldown via `cooldown_s=0` (or calls a no-cooldown send method to be added).

### Alert message template (HTML)

```
<b>[{severity}] {rule_name}</b>
{message}

<b>Cited features:</b>
• {key} = {value}
...

<i>{ts_utc}</i>
```

`DRY_RUN=1` env var → log payload, do not hit API (used in replay tests).

Telegram destination: dedicated `TELEGRAM_PORTFOLIO_BOT_TOKEN` + `TELEGRAM_PORTFOLIO_CHAT_IDS` (comma-separated) so portfolio-analysis traffic is isolated from hedge_engine traffic.

---

## 8. Telegram bot (control plane)

`python -m portfolio_analysis.bot.server` - long-poll bot, separate process from the scheduler.

### Authorization

Static allowlist `AUTHORIZED_TELEGRAM_USER_IDS` (env, comma-separated). Unauthorized users receive: `Not authorized.` Every command checks auth first.

### Commands

| Command | Effect |
|---|---|
| `/set <name> <value> <duration>` | Override threshold. `duration` accepts `30m`, `4h`, `7d`. Writes `threshold_overrides`, broadcasts, audits. |
| `/stop <dedup_key_or_rule>` | Insert `suppressions` row for that dedup_key (or all keys of a rule). Suppression auto-clears when alert resolves. Broadcasts `User <name> stopped notifications and will handle it`. Audits. |
| `/resume <dedup_key_or_rule>` | Manually clear suppression early. Broadcasts + audits. |
| `/status` | Reply with current Calm Score, active alerts, active suppressions. |
| `/thresholds` | Reply with table: name, default, current value, expires_at (if overridden). |
| `/audit [N]` | Last N audit_log rows (default 20). |
| `/report` | Generate the daily PDF report on demand (window = last 24 h ending now) and send it to the requesting chat. |
| `/help` | List commands. |

### Broadcast helper

`bot/broadcast.py::broadcast(text)` sends to every chat in `TELEGRAM_PORTFOLIO_CHAT_IDS`. Used by:

* threshold writes → `User <name> changed <name> to <value> for <duration>`
* stop alert → `User <name> stopped notifications and will handle it`
* resume alert → `User <name> resumed notifications for <key>`

### Audit log

Every command (success or rejection) appends to `audit_log`. Schema in Section 1. Surfaced via `/audit`.

---

## 9. Logging

All modules use `realtime._logging.get_logger("portfolio_analysis.<sub>")`.

* Rule evaluation → DEBUG (inputs + decision).
* State change → INFO.
* Alert insert + Telegram send (or DRY_RUN skip) → INFO with payload size.
* Bot command received → INFO with user_id, action.
* Threshold override / suppression → INFO.

---

## 10. Verification

End-to-end checks before declaring done.

* **Unit tests** (`portfolio_analysis/tests/`):
  * One fixture per Calm Score tier (RELAX / TAKE_A_LOOK / ACTIVE_MONITORING / URGENT_ACTION) producing the expected `classify()` result.
  * Per-rule tests with synthetic feature dicts.
  * Threshold resolver: override → expiry → fallback to default.
  * Suppression: insert → matching alert suppressed → underlying condition resolves → suppression cleared → alert re-fires next time.
* **Replay** - `python -m portfolio_analysis.replay --hours 24` iterates historical agg-metrics rows, runs the rules engine, prints alert/state stream. Sanity bound: ≤ 6 alerts/hour averaged.
* **Scheduler health** - `python -m portfolio_analysis.scheduler --health` runs full stack 12 s, prints health snapshot.
* **Bot integration** - `DRY_RUN=1` end-to-end: launch scheduler + bot, send `/set MM_WARN_PCT 25 1h` from an authorized account, verify (a) override row written, (b) broadcast logged, (c) audit row appended, (d) next rule evaluation uses 25.
* **Live smoke** - with real Telegram token, force a synthetic alert via test fixture, confirm message arrives in chat with correct formatting; send `/stop` and confirm next cycle does not re-send.

---

## 11. Critical files to modify / create

Modify:

* `shared/db_paths.py` - add `PORTFOLIO_ANALYSIS_DB`.
* `hedge_engine/notifications/notifier.py` - add a `cooldown_s=0` path or `send_no_cooldown()` so portfolio-analysis can manage its own dedup.

Create (all under `portfolio_analysis/`):

* `config.py`, `thresholds.py`, `storage.py`
* `features/{market,price_change,positions}.py`
* `rules/{base,mm_pressure,delta_drift,dte_risk,vol_sigma,price_quantile,__init__}.py`
* `state.py`, `worker.py`, `heartbeat.py`, `report_daily.py`, `notifier.py`, `scheduler.py`, `replay.py`
* `bot/{server,commands,auth,broadcast,__init__}.py`
* `tests/...`

---

## 12. Out of scope (deferred)

* Rule 6 - pending; placeholder only, `NotImplementedError` if loaded.
* LLM reasoning / state pack / state diff - deferred to a later iteration.
* DVOL / IV-spike rule.
* Liquidation tape, HWM/drawdown, external feeds (CoinGlass, Glassnode, etc.).
* Cross-day chat memory, conversational "why?" replies.
