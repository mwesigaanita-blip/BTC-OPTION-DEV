// Build plan.docx from plan.md with polished typography.
// Run: node _build_docx.js

const fs = require("fs");
const path = require("path");
const docx = require("docx");

const {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
  Header, Footer, AlignmentType, PageOrientation, LevelFormat,
  HeadingLevel, BorderStyle, WidthType, ShadingType, PageNumber, PageBreak,
  TabStopType, TabStopPosition,
} = docx;

const SRC = path.join(__dirname, "plan.md");
const OUT = path.join(__dirname, "plan.docx");

// ---------------------------------------------------------------------------
// Design tokens
// ---------------------------------------------------------------------------

const FONT_BODY = "Calibri";
const FONT_CODE = "Consolas";

const COL = {
  H1: "1F3A5F",
  H2: "1F3A5F",
  H3: "2E75B6",
  ACCENT: "2E75B6",
  BODY: "1A1A1A",
  MUTED: "595959",
  CODE_TEXT: "1A1A1A",
  CODE_BG: "F4F6F8",
  INLINE_CODE: "B43A4D",
  TABLE_HEADER_BG: "1F3A5F",
  TABLE_HEADER_TEXT: "FFFFFF",
  TABLE_ALT_BG: "F4F6F8",
  TABLE_BORDER: "BFC4CC",
  HR: "BFC4CC",
};

// US Letter portrait, 1" margins → content width = 12240 - 2*1440 = 9360
const PAGE_WIDTH = 12240;
const PAGE_HEIGHT = 15840;
const MARGIN = 1440;
const CONTENT_WIDTH = PAGE_WIDTH - 2 * MARGIN;

// ---------------------------------------------------------------------------
// Inline parser: handles **bold**, *italic*, `code`, and plain text.
// ---------------------------------------------------------------------------

function parseInline(text, baseProps = {}) {
  const runs = [];
  let i = 0;
  let buf = "";
  const flush = (extra = {}) => {
    if (buf) {
      runs.push(new TextRun({ text: buf, font: FONT_BODY, size: 22, color: COL.BODY, ...baseProps, ...extra }));
      buf = "";
    }
  };
  while (i < text.length) {
    const c = text[i];
    if (c === "`") {
      flush();
      const end = text.indexOf("`", i + 1);
      if (end === -1) { buf += c; i++; continue; }
      const codeText = text.slice(i + 1, end);
      runs.push(new TextRun({
        text: codeText, font: FONT_CODE, size: 20,
        color: COL.INLINE_CODE,
        shading: { type: ShadingType.CLEAR, fill: COL.CODE_BG, color: "auto" },
      }));
      i = end + 1;
    } else if (c === "*" && text[i + 1] === "*") {
      flush();
      const end = text.indexOf("**", i + 2);
      if (end === -1) { buf += c; i++; continue; }
      const inner = text.slice(i + 2, end);
      // Recurse for nested formatting
      const innerRuns = parseInline(inner, { ...baseProps, bold: true });
      runs.push(...innerRuns);
      i = end + 2;
    } else if (c === "*") {
      flush();
      const end = text.indexOf("*", i + 1);
      if (end === -1) { buf += c; i++; continue; }
      const inner = text.slice(i + 1, end);
      const innerRuns = parseInline(inner, { ...baseProps, italics: true });
      runs.push(...innerRuns);
      i = end + 1;
    } else {
      buf += c;
      i++;
    }
  }
  flush();
  return runs;
}

// ---------------------------------------------------------------------------
// Block constructors
// ---------------------------------------------------------------------------

function heading(level, text) {
  const sizes = { 1: 44, 2: 32, 3: 26 };       // half-points
  const colors = { 1: COL.H1, 2: COL.H2, 3: COL.H3 };
  const before = { 1: 480, 2: 360, 3: 240 };
  const after = { 1: 200, 2: 160, 3: 120 };
  const headingLevels = { 1: HeadingLevel.HEADING_1, 2: HeadingLevel.HEADING_2, 3: HeadingLevel.HEADING_3 };
  return new Paragraph({
    heading: headingLevels[level],
    spacing: { before: before[level], after: after[level] },
    children: [new TextRun({
      text, bold: true, font: FONT_BODY,
      size: sizes[level], color: colors[level],
    })],
  });
}

function bodyPara(inlineText, opts = {}) {
  return new Paragraph({
    spacing: { before: 60, after: 120, line: 300 },
    children: parseInline(inlineText, opts.runProps || {}),
    alignment: AlignmentType.LEFT,
    ...(opts.indent ? { indent: opts.indent } : {}),
  });
}

function bulletPara(inlineText, level = 0) {
  return new Paragraph({
    numbering: { reference: "bullets", level },
    spacing: { before: 40, after: 60, line: 280 },
    children: parseInline(inlineText),
  });
}

function numberedPara(inlineText, level = 0) {
  return new Paragraph({
    numbering: { reference: "numbers", level },
    spacing: { before: 40, after: 60, line: 280 },
    children: parseInline(inlineText),
  });
}

function codeLine(text) {
  return new Paragraph({
    spacing: { before: 0, after: 0, line: 240 },
    shading: { type: ShadingType.CLEAR, fill: COL.CODE_BG, color: "auto" },
    indent: { left: 240, right: 240 },
    children: [new TextRun({
      text: text || " ",
      font: FONT_CODE, size: 18, color: COL.CODE_TEXT,
    })],
  });
}

function codeBlock(lines) {
  // Wrap the code in a single-cell table so its background and border
  // form a clean visual block. Tables sidestep the brittle paragraph-
  // border element ordering rules.
  const innerParas = lines.map((ln) => new Paragraph({
    spacing: { before: 0, after: 0, line: 240 },
    children: [new TextRun({
      text: ln === "" ? " " : ln,
      font: FONT_CODE, size: 18, color: COL.CODE_TEXT,
    })],
  }));
  const border = { style: BorderStyle.SINGLE, size: 4, color: COL.TABLE_BORDER };
  const cell = new TableCell({
    width: { size: CONTENT_WIDTH, type: WidthType.DXA },
    shading: { type: ShadingType.CLEAR, fill: COL.CODE_BG, color: "auto" },
    margins: { top: 140, bottom: 140, left: 200, right: 200 },
    borders: { top: border, bottom: border, left: border, right: border },
    children: innerParas,
  });
  const tbl = new Table({
    width: { size: CONTENT_WIDTH, type: WidthType.DXA },
    columnWidths: [CONTENT_WIDTH],
    rows: [new TableRow({ children: [cell] })],
  });
  // Spacer paragraphs around the code block for breathing room.
  return [
    new Paragraph({ spacing: { before: 80, after: 0 }, children: [] }),
    tbl,
    new Paragraph({ spacing: { before: 0, after: 120 }, children: [] }),
  ];
}

function hrPara() {
  return new Paragraph({
    spacing: { before: 240, after: 240 },
    border: { bottom: { style: BorderStyle.SINGLE, size: 6, color: COL.HR, space: 1 } },
    children: [new TextRun({ text: "" })],
  });
}

function makeCell(text, opts = {}) {
  const {
    header = false, alt = false, widthDxa, isInline = true,
  } = opts;
  const fill = header ? COL.TABLE_HEADER_BG : (alt ? COL.TABLE_ALT_BG : "FFFFFF");
  const textColor = header ? COL.TABLE_HEADER_TEXT : COL.BODY;
  const border = { style: BorderStyle.SINGLE, size: 4, color: COL.TABLE_BORDER };
  const para = new Paragraph({
    spacing: { before: 40, after: 40, line: 260 },
    children: isInline
      ? parseInline(text, { color: textColor, bold: header, size: 20 })
      : [new TextRun({ text, color: textColor, bold: header, size: 20, font: FONT_BODY })],
  });
  return new TableCell({
    width: { size: widthDxa, type: WidthType.DXA },
    shading: { type: ShadingType.CLEAR, fill, color: "auto" },
    margins: { top: 100, bottom: 100, left: 140, right: 140 },
    borders: { top: border, bottom: border, left: border, right: border },
    children: [para],
  });
}

function makeTable(rows, columnWidths) {
  // rows: 2D array. First row = header. Cells are inline-parsed.
  const total = columnWidths.reduce((a, b) => a + b, 0);
  return new Table({
    width: { size: total, type: WidthType.DXA },
    columnWidths,
    rows: rows.map((cells, ri) => new TableRow({
      tableHeader: ri === 0,
      children: cells.map((c, ci) => makeCell(c, {
        header: ri === 0,
        alt: ri > 0 && ri % 2 === 0,
        widthDxa: columnWidths[ci],
      })),
    })),
  });
}

// ---------------------------------------------------------------------------
// Markdown parser (line-based, sufficient for this document)
// ---------------------------------------------------------------------------

function tokenize(md) {
  const lines = md.split(/\r?\n/);
  const blocks = [];
  let i = 0;
  while (i < lines.length) {
    const line = lines[i];

    // Code fence
    if (/^\s*```/.test(line)) {
      const fence = line.match(/^(\s*)```/)[0];
      const indent = fence.replace(/```$/, "").length;
      const codeLines = [];
      i++;
      while (i < lines.length && !/^\s*```/.test(lines[i])) {
        // Strip leading indent equal to fence indent if present.
        let l = lines[i];
        if (l.startsWith(" ".repeat(indent))) l = l.slice(indent);
        codeLines.push(l);
        i++;
      }
      i++; // closing fence
      blocks.push({ type: "code", lines: codeLines });
      continue;
    }

    // HR
    if (/^\s*---\s*$/.test(line)) {
      blocks.push({ type: "hr" });
      i++;
      continue;
    }

    // Heading
    const h = line.match(/^(#{1,3})\s+(.*)$/);
    if (h) {
      blocks.push({ type: "heading", level: h[1].length, text: h[2].trim() });
      i++;
      continue;
    }

    // Table: a header row that contains "|" followed by a separator line
    if (line.includes("|") && i + 1 < lines.length && /^[\s\|:\-]+$/.test(lines[i + 1]) && lines[i + 1].includes("|")) {
      const rows = [];
      const splitRow = (s) => {
        const trimmed = s.replace(/^\s*\|/, "").replace(/\|\s*$/, "");
        const cells = [];
        let cur = "";
        let inCode = false;
        for (const ch of trimmed) {
          if (ch === "`") inCode = !inCode;
          if (ch === "|" && !inCode) { cells.push(cur.trim()); cur = ""; }
          else cur += ch;
        }
        cells.push(cur.trim());
        return cells;
      };
      rows.push(splitRow(line));
      i += 2; // skip header + separator
      while (i < lines.length && lines[i].includes("|") && lines[i].trim() !== "") {
        rows.push(splitRow(lines[i]));
        i++;
      }
      blocks.push({ type: "table", rows });
      continue;
    }

    // Bullet list (with nested sub-bullets via 2-space indent)
    const bulletMatch = line.match(/^(\s*)\*\s+(.*)$/);
    if (bulletMatch) {
      const items = [];
      while (i < lines.length) {
        const m = lines[i].match(/^(\s*)\*\s+(.*)$/);
        if (m) {
          const level = Math.floor(m[1].length / 2);
          let text = m[2];
          let j = i + 1;
          // Absorb continuation lines that are NOT another bullet, NOT a
          // nested numbered item, NOT a heading/code/table.
          while (j < lines.length && lines[j].trim() !== ""
                 && !/^\s*\*\s+/.test(lines[j])
                 && !/^\s+\d+\.\s+/.test(lines[j])
                 && !/^(#{1,3})\s+/.test(lines[j])
                 && !/^\s*```/.test(lines[j])) {
            if (lines[j].includes("|") && j + 1 < lines.length && /^[\s\|:\-]+$/.test(lines[j + 1])) break;
            text += "\n" + lines[j].trim();
            j++;
          }
          items.push({ level, text });
          i = j;
          // Nested numbered sub-items belonging to this bullet
          const nested = [];
          while (i < lines.length) {
            const nm = lines[i].match(/^(\s+)(\d+)\.\s+(.*)$/);
            if (!nm) break;
            nested.push({ level: level + 1, text: nm[3] });
            i++;
          }
          if (nested.length) items[items.length - 1].nestedNumbered = nested;
        } else if (lines[i].trim() === "") {
          // Lookahead: is the next non-empty line still a bullet?
          let k = i + 1;
          while (k < lines.length && lines[k].trim() === "") k++;
          if (k < lines.length && /^(\s*)\*\s+/.test(lines[k])) {
            i = k;
            continue;
          }
          break;
        } else if (/^\s{2,}/.test(lines[i])) {
          // Indented continuation: code block belonging to last bullet
          if (/^\s*```/.test(lines[i].trim())) {
            const fence = lines[i].trim();
            const codeLines = [];
            i++;
            while (i < lines.length && lines[i].trim() !== "```") {
              codeLines.push(lines[i].replace(/^\s{0,4}/, ""));
              i++;
            }
            i++;
            if (items.length) items[items.length - 1].afterCode = codeLines;
            continue;
          }
          // Non-code continuation (e.g. indented sub-paragraph)
          break;
        } else {
          break;
        }
      }
      blocks.push({ type: "bullets", items });
      continue;
    }

    // Numbered list
    const numMatch = line.match(/^(\s*)(\d+)\.\s+(.*)$/);
    if (numMatch) {
      const items = [];
      while (i < lines.length) {
        const m = lines[i].match(/^(\s*)(\d+)\.\s+(.*)$/);
        if (m) {
          const level = Math.floor(m[1].length / 3);
          items.push({ level, text: m[3] });
          i++;
        } else if (lines[i].trim() === "") {
          let k = i + 1;
          while (k < lines.length && lines[k].trim() === "") k++;
          if (k < lines.length && /^(\s*)\d+\.\s+/.test(lines[k])) { i = k; continue; }
          break;
        } else { break; }
      }
      blocks.push({ type: "numbered", items });
      continue;
    }

    // Empty line
    if (line.trim() === "") { i++; continue; }

    // Paragraph: collect until blank/heading/list/code/hr/table
    let para = line;
    i++;
    while (i < lines.length) {
      const l = lines[i];
      if (l.trim() === "") break;
      if (/^(#{1,3})\s+/.test(l)) break;
      if (/^\s*\*\s+/.test(l)) break;
      if (/^\s*\d+\.\s+/.test(l)) break;
      if (/^\s*```/.test(l)) break;
      if (/^\s*---\s*$/.test(l)) break;
      if (l.includes("|") && i + 1 < lines.length && /^[\s\|:\-]+$/.test(lines[i + 1])) break;
      para += " " + l.trim();
      i++;
    }
    blocks.push({ type: "para", text: para.trim() });
  }
  return blocks;
}

// ---------------------------------------------------------------------------
// Block → docx-js elements
// ---------------------------------------------------------------------------

function renderBullets(items) {
  const out = [];
  for (const it of items) {
    out.push(bulletPara(it.text, it.level));
    if (it.afterCode) out.push(...codeBlock(it.afterCode));
    if (it.nestedNumbered) {
      for (const ni of it.nestedNumbered) out.push(numberedPara(ni.text, ni.level));
    }
  }
  return out;
}

function renderBlocks(blocks) {
  const out = [];
  for (const b of blocks) {
    if (b.type === "heading") out.push(heading(b.level, b.text));
    else if (b.type === "para") out.push(bodyPara(b.text));
    else if (b.type === "hr") out.push(hrPara());
    else if (b.type === "code") out.push(...codeBlock(b.lines));
    else if (b.type === "bullets") out.push(...renderBullets(b.items));
    else if (b.type === "numbered") {
      for (const it of b.items) out.push(numberedPara(it.text, it.level));
    } else if (b.type === "table") {
      const ncol = b.rows[0].length;
      const w = Math.floor(CONTENT_WIDTH / ncol);
      const widths = Array(ncol).fill(w);
      // Adjust last column for rounding
      widths[ncol - 1] = CONTENT_WIDTH - w * (ncol - 1);
      out.push(makeTable(b.rows, widths));
      // Spacer paragraph after table
      out.push(new Paragraph({ spacing: { before: 0, after: 80 }, children: [] }));
    }
  }
  return out;
}

// ---------------------------------------------------------------------------
// Build document
// ---------------------------------------------------------------------------

const md = fs.readFileSync(SRC, "utf-8");
const blocks = tokenize(md);

// Promote the first H1 to a title block (cover-style heading).
let titleText = "Portfolio Co-Pilot - Phased Implementation Plan";
if (blocks.length && blocks[0].type === "heading" && blocks[0].level === 1) {
  titleText = blocks.shift().text;
}

const titleParas = [
  new Paragraph({
    spacing: { before: 0, after: 80 },
    children: [new TextRun({
      text: titleText, bold: true, font: FONT_BODY, size: 56, color: COL.H1,
    })],
  }),
  new Paragraph({
    spacing: { before: 0, after: 200 },
    children: [new TextRun({
      text: "Portfolio Analysis · Implementation Plan",
      italics: true, font: FONT_BODY, size: 22, color: COL.MUTED,
    })],
  }),
  new Paragraph({
    spacing: { before: 0, after: 240 },
    border: { bottom: { style: BorderStyle.SINGLE, size: 12, color: COL.ACCENT, space: 4 } },
    children: [new TextRun({ text: "" })],
  }),
];

const bodyChildren = renderBlocks(blocks);

const doc = new Document({
  creator: "portfolio_analysis docs build",
  title: titleText,
  styles: {
    default: { document: { run: { font: FONT_BODY, size: 22, color: COL.BODY } } },
    paragraphStyles: [
      { id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 44, bold: true, font: FONT_BODY, color: COL.H1 },
        paragraph: { spacing: { before: 480, after: 200 }, outlineLevel: 0 } },
      { id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 32, bold: true, font: FONT_BODY, color: COL.H2 },
        paragraph: { spacing: { before: 360, after: 160 }, outlineLevel: 1 } },
      { id: "Heading3", name: "Heading 3", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 26, bold: true, font: FONT_BODY, color: COL.H3 },
        paragraph: { spacing: { before: 240, after: 120 }, outlineLevel: 2 } },
    ],
  },
  numbering: {
    config: [
      { reference: "bullets", levels: [
        { level: 0, format: LevelFormat.BULLET, text: "•", alignment: AlignmentType.LEFT,
          style: { paragraph: { indent: { left: 540, hanging: 270 } } } },
        { level: 1, format: LevelFormat.BULLET, text: "◦", alignment: AlignmentType.LEFT,
          style: { paragraph: { indent: { left: 1080, hanging: 270 } } } },
        { level: 2, format: LevelFormat.BULLET, text: "▪", alignment: AlignmentType.LEFT,
          style: { paragraph: { indent: { left: 1620, hanging: 270 } } } },
      ]},
      { reference: "numbers", levels: [
        { level: 0, format: LevelFormat.DECIMAL, text: "%1.", alignment: AlignmentType.LEFT,
          style: { paragraph: { indent: { left: 540, hanging: 270 } } } },
        { level: 1, format: LevelFormat.LOWER_LETTER, text: "%2.", alignment: AlignmentType.LEFT,
          style: { paragraph: { indent: { left: 1080, hanging: 270 } } } },
      ]},
    ],
  },
  sections: [{
    properties: {
      page: {
        size: { width: PAGE_WIDTH, height: PAGE_HEIGHT },
        margin: { top: MARGIN, right: MARGIN, bottom: MARGIN, left: MARGIN },
      },
    },
    headers: {
      default: new Header({
        children: [new Paragraph({
          alignment: AlignmentType.RIGHT,
          children: [new TextRun({
            text: "Portfolio Co-Pilot - Implementation Plan",
            italics: true, color: COL.MUTED, size: 18, font: FONT_BODY,
          })],
        })],
      }),
    },
    footers: {
      default: new Footer({
        children: [new Paragraph({
          tabStops: [{ type: TabStopType.RIGHT, position: CONTENT_WIDTH }],
          children: [
            new TextRun({ text: "portfolio_analysis/docs/plan.md", italics: true, color: COL.MUTED, size: 18, font: FONT_BODY }),
            new TextRun({ text: "\t" }),
            new TextRun({ text: "Page ", color: COL.MUTED, size: 18, font: FONT_BODY }),
            new TextRun({ children: [PageNumber.CURRENT], color: COL.MUTED, size: 18, font: FONT_BODY }),
            new TextRun({ text: " of ", color: COL.MUTED, size: 18, font: FONT_BODY }),
            new TextRun({ children: [PageNumber.TOTAL_PAGES], color: COL.MUTED, size: 18, font: FONT_BODY }),
          ],
        })],
      }),
    },
    children: [...titleParas, ...bodyChildren],
  }],
});

Packer.toBuffer(doc).then((buf) => {
  fs.writeFileSync(OUT, buf);
  const stat = fs.statSync(OUT);
  console.log(`Wrote ${OUT} (${stat.size} bytes)`);
});
