"""Build ``telegram_bot_guide.pdf`` - a 2-page PDF user guide for the bot.

Run from the repo root:

    python -m portfolio_analysis.docs._build_telegram_bot_guide

The output lives next to this script:
``portfolio_analysis/docs/telegram_bot_guide.pdf``.
"""
from __future__ import annotations

from pathlib import Path

from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import LETTER
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import inch
from reportlab.platypus import (
    BaseDocTemplate, Frame, PageTemplate, Paragraph, Spacer, Table, TableStyle,
)


HERE = Path(__file__).resolve().parent
OUT = HERE / "telegram_bot_guide.pdf"

# Brand palette (matches docs/_build_docx.js for visual consistency).
COL_PRIMARY = "#1F3A5F"
COL_ACCENT  = "#2E75B6"
COL_BODY    = "#1A1A1A"
COL_MUTED   = "#595959"
COL_BORDER  = "#BFC4CC"
COL_ROW_ALT = "#F4F6F8"
COL_INLINE  = "#B43A4D"   # inline-code text colour


def _make_styles():
    base = getSampleStyleSheet()
    title = ParagraphStyle(
        "title", parent=base["Title"], fontName="Helvetica-Bold",
        fontSize=18, leading=22, textColor=colors.HexColor(COL_PRIMARY),
        alignment=TA_LEFT, spaceAfter=2,
    )
    subtitle = ParagraphStyle(
        "subtitle", parent=base["BodyText"], fontName="Helvetica-Oblique",
        fontSize=9, leading=11.5, textColor=colors.HexColor(COL_MUTED),
        spaceAfter=12,
    )
    h2 = ParagraphStyle(
        "h2", parent=base["Heading2"], fontName="Helvetica-Bold",
        fontSize=11.5, leading=14, textColor=colors.HexColor(COL_PRIMARY),
        spaceBefore=10, spaceAfter=5,
    )
    body = ParagraphStyle(
        "body", parent=base["BodyText"], fontName="Helvetica",
        fontSize=8.8, leading=12, textColor=colors.HexColor(COL_BODY),
        spaceAfter=4, alignment=TA_LEFT,
    )
    cell = ParagraphStyle(
        "cell", parent=body, fontSize=8.2, leading=11.0, spaceAfter=0,
    )
    cell_bold = ParagraphStyle(
        "cell_b", parent=cell, fontName="Helvetica-Bold",
        textColor=colors.HexColor(COL_PRIMARY),
    )
    li = ParagraphStyle(
        "li", parent=body, fontSize=8.8, leading=12,
        leftIndent=18, firstLineIndent=-12, spaceAfter=3,
    )
    small = ParagraphStyle(
        "small", parent=body, fontSize=7.8, leading=10.5,
        textColor=colors.HexColor(COL_MUTED), spaceAfter=2,
    )
    return {
        "title": title, "subtitle": subtitle, "h2": h2,
        "body": body, "cell": cell, "cell_bold": cell_bold,
        "li": li, "small": small,
    }


def _code(text: str) -> str:
    """Inline-code span. Escapes HTML special chars first so things like
    ``<dedup_key>`` render as literal angle brackets, not as broken
    pseudo-tags."""
    safe = (
        text.replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
    )
    return (
        f"<font face='Courier' size='7.4' color='{COL_INLINE}'>"
        f"{safe}</font>"
    )


def _para_table(rows, *, col_widths, styles, header=True):
    """Build a Table where every cell is a Paragraph (so HTML renders)."""
    p_cell = styles["cell"]
    p_head = ParagraphStyle(
        "th", parent=p_cell, fontName="Helvetica-Bold",
        textColor=colors.white, fontSize=8.6,
    )
    formatted: list[list] = []
    for ri, row in enumerate(rows):
        formatted.append([
            Paragraph(c, p_head if (header and ri == 0) else p_cell)
            for c in row
        ])
    t = Table(formatted, colWidths=col_widths, repeatRows=1 if header else 0)
    style = [
        ("VALIGN",       (0, 0), (-1, -1), "TOP"),
        ("LEFTPADDING",  (0, 0), (-1, -1), 6),
        ("RIGHTPADDING", (0, 0), (-1, -1), 6),
        ("TOPPADDING",   (0, 0), (-1, -1), 5),
        ("BOTTOMPADDING",(0, 0), (-1, -1), 5),
        ("BOX",          (0, 0), (-1, -1), 0.4, colors.HexColor(COL_BORDER)),
        ("INNERGRID",    (0, 0), (-1, -1), 0.25, colors.HexColor(COL_BORDER)),
    ]
    if header:
        style += [
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor(COL_PRIMARY)),
            ("ROWBACKGROUNDS", (0, 1), (-1, -1),
             [colors.white, colors.HexColor(COL_ROW_ALT)]),
        ]
    else:
        style += [
            ("ROWBACKGROUNDS", (0, 0), (-1, -1),
             [colors.white, colors.HexColor(COL_ROW_ALT)]),
        ]
    t.setStyle(TableStyle(style))
    return t


def build() -> Path:
    s = _make_styles()
    page_w, page_h = LETTER
    margin = 0.65 * inch
    content_w = page_w - 2 * margin

    doc = BaseDocTemplate(
        str(OUT), pagesize=LETTER,
        leftMargin=margin, rightMargin=margin,
        topMargin=0.55 * inch, bottomMargin=0.55 * inch,
        title="Portfolio Telegram Bot - User Guide",
        author="Portfolio Co-Pilot",
    )
    frame = Frame(margin, margin, content_w, page_h - 1.1 * inch,
                  id="main", showBoundary=0,
                  leftPadding=0, rightPadding=0,
                  topPadding=0, bottomPadding=0)

    def _furniture(canvas, _doc):
        canvas.saveState()
        canvas.setStrokeColor(colors.HexColor(COL_ACCENT))
        canvas.setLineWidth(1.5)
        canvas.line(margin, page_h - 0.45 * inch,
                    page_w - margin, page_h - 0.45 * inch)
        canvas.setFillColor(colors.HexColor(COL_MUTED))
        canvas.setFont("Helvetica-Oblique", 8)
        canvas.drawString(margin, page_h - 0.32 * inch,
                          "Portfolio Co-Pilot - Telegram Bot Guide")
        canvas.setFont("Helvetica", 7.5)
        canvas.drawString(margin, 0.32 * inch,
                          "portfolio_analysis/docs/telegram_bot_guide.pdf")
        canvas.drawRightString(page_w - margin, 0.32 * inch,
                               f"Page {_doc.page}")
        canvas.restoreState()

    doc.addPageTemplates([PageTemplate(id="main", frames=[frame],
                                       onPage=_furniture)])

    story: list = []

    # ── Title ────────────────────────────────────────────────────────────
    story.append(Paragraph("Portfolio Telegram Bot - User Guide", s["title"]))
    story.append(Paragraph(
        "Two-page reference for everyone authorized to use the bot. "
        "Covers what it does, every command, the wizard flows, and how "
        "alerts arrive.", s["subtitle"]))

    # ── 1. What it is ───────────────────────────────────────────────────
    story.append(Paragraph("1. What it is", s["h2"]))
    story.append(Paragraph(
        f"The bot is the Telegram-side control plane for the "
        f"<b>portfolio_analysis</b> alert engine. The engine watches BTC "
        f"moves, margin pressure, delta drift, option expiries, and "
        f"statistical outliers; it pushes alerts to a Telegram chat and "
        f"lets authorized users tune thresholds, pause individual "
        f"alerts, and fetch the daily report - all from inside Telegram.",
        s["body"]))
    story.append(Paragraph(
        f"The bot runs as its own process "
        f"({_code('python -m portfolio_analysis.bot.server')}), so it "
        f"can be restarted without touching the alert pipeline.",
        s["body"]))

    # ── 2. Authorization ─────────────────────────────────────────────────
    story.append(Paragraph("2. Authorization", s["h2"]))
    story.append(Paragraph("Three env vars decide who can do what:", s["body"]))
    auth_rows = [
        ["Variable", "Shape", "Purpose"],
        [_code("TELEGRAM_PORTFOLIO_BOT_TOKEN"),
         "string",
         "Bot token from @BotFather. The bot won&#x27;t start without it."],
        [_code("TELEGRAM_CHAT_IDS"),
         _code("{name: chat_id}"),
         "Where alerts, broadcasts, and the daily PDF are sent."],
        [_code("AUTHORIZED_TELEGRAM_USERS"),
         _code("{name: user_id}"),
         "Who can issue commands. The matching name shows up in audit "
         "and broadcasts as the actor."],
    ]
    story.append(_para_table(
        auth_rows, styles=s,
        col_widths=[2.30 * inch, 1.20 * inch, content_w - 3.50 * inch],
    ))
    story.append(Spacer(1, 4))
    story.append(Paragraph(
        f"Anyone whose Telegram user ID is not in "
        f"<b>AUTHORIZED_TELEGRAM_USERS</b> gets exactly one reply - "
        f"&quot;<b>Not authorized.</b>&quot; - and the rejection is "
        f"logged. Authorized commands always append a row to the "
        f"<b>audit_log</b> table.",
        s["body"]))

    # ── 3. Commands ──────────────────────────────────────────────────────
    story.append(Paragraph("3. Commands", s["h2"]))
    cmd_rows = [
        ["Command", "What it does"],
        [_code("/help"),
         "Show this guide. The bot replies with the command list and "
         "attaches this PDF to your chat."],
        [_code("/status"),
         "Current Calm Score, every active alert (severity icon + "
         "human-readable label), and any alerts already being handled."],
        [_code("/thresholds"),
         f"Every threshold&#x27;s current value vs default. Heartbeat "
         f"thresholds are shown as durations (e.g. {_code('6h')}) - "
         f"never raw seconds."],
        [_code("/set"),
         f"Interactive wizard: pick threshold → enter new value → "
         f"pick duration. Shorthand: "
         f"{_code('/set NAME VALUE DURATION')} (e.g. "
         f"{_code('/set MM_WARN_PCT 25 7d')})."],
        [_code("/stop"),
         f"Picker: tap one of the currently-active alerts to take it "
         f"over. Notifications for that alert pause until it auto-"
         f"resolves (or you /resume). Direct form: "
         f"{_code('/stop <dedup_key | RULE>')}."],
        [_code("/resume"),
         "Picker of active suppressions: tap one to start receiving "
         "its notifications again. Also auto-clears when the underlying "
         "alert resolves."],
        [_code("/audit [N]"),
         "Last N audit_log entries (default 20, max 100). Newest first. "
         "Every set / stop / resume / report shows up here."],
        [_code("/report"),
         "Build today&#x27;s daily PDF on demand and send it back to "
         "the requesting chat. Same builder the daily worker uses."],
    ]
    story.append(_para_table(
        cmd_rows, styles=s,
        col_widths=[1.2 * inch, content_w - 1.2 * inch],
    ))

    # ── 4. /set walkthrough ──────────────────────────────────────────────
    story.append(Paragraph("4. /set walkthrough (the wizard)", s["h2"]))
    set_steps = [
        f"<b>1.</b> Send {_code('/set')}. The bot replies with a list "
        f"of every overrideable threshold as inline buttons.",
        f"<b>2.</b> Tap a threshold (e.g. <i>Margin warning %</i>). "
        f"The bot shows the current default and asks for the new value. "
        f"The example matches the magnitude of the default - for "
        f"<i>Delta good (BTC)</i> with default 0.5 you&#x27;ll see "
        f"{_code('e.g. 0.6')}, not {_code('e.g. 25')}.",
        f"<b>3.</b> For heartbeat thresholds (durations) you can send "
        f"either a duration string ({_code('30m')}, {_code('4h')}, "
        f"{_code('7d')}) or raw seconds. For numeric thresholds, send "
        f"a plain number.",
        f"<b>4.</b> The bot offers quick-pick durations (5m / 30m / 1h "
        f"/ 6h / 1d / 7d) plus <i>Custom</i>. After you confirm, the "
        f"override is stored, a broadcast goes to every chat "
        f"(&quot;User {_code('<name>')} changed "
        f"{_code('<name>')} to {_code('<value>')} for "
        f"{_code('<duration>')}&quot;), and an audit row is "
        f"appended.",
    ]
    for line in set_steps:
        story.append(Paragraph(line, s["li"]))
    story.append(Paragraph(
        "When the override expires it silently reverts to the default. "
        "No broadcast on expiry - by design.", s["small"]))

    # ── 5. /stop walkthrough ─────────────────────────────────────────────
    story.append(Paragraph("5. /stop walkthrough (taking an alert over)",
                           s["h2"]))
    story.append(Paragraph(
        "When a noisy alert is firing - typically because <i>you</i> "
        "are already aware and dealing with it - use /stop to pause "
        "its notifications without resolving the underlying condition. "
        "It auto-resolves when the condition itself clears.", s["body"]))
    stop_steps = [
        f"<b>1.</b> Send {_code('/stop')}. The bot lists every "
        f"currently-active alert that is <i>not</i> already being "
        f"handled, with its severity prefix and a plain-English label "
        f"(e.g. &quot;<b>[URGENT]</b> BTC 4h up (critical)&quot;).",
        f"<b>2.</b> Tap one. A suppression row is created, every chat "
        f"sees &quot;{_code('<you>')} is now handling: "
        f"{_code('<label>')}&quot;, and an audit row is appended.",
        f"<b>3.</b> While the suppression is active the alert "
        f"won&#x27;t re-fire, even if its band changes. The next "
        f"/stop picker hides it. Once the underlying condition clears "
        f"(e.g. mm_pct drops back below the threshold) the worker "
        f"resolves the alert <i>and</i> auto-clears the suppression, "
        f"ready for next time.",
    ]
    for line in stop_steps:
        story.append(Paragraph(line, s["li"]))
    story.append(Paragraph(
        f"Use {_code('/resume')} if you want to lift a suppression "
        f"manually.", s["small"]))

    # ── 6. What lands in the chat ────────────────────────────────────────
    story.append(Paragraph(
        "6. What lands in the chat (alerts, heartbeats, reports)",
        s["h2"]))
    story.append(Paragraph(
        "<b>Alerts</b> - every threshold breach produces one Telegram "
        "message with: severity prefix (INFO / WARNING / URGENT / "
        "EMERGENCY), short headline, plain-English explanation, "
        "suggested action, the cited features, and a timestamp. The "
        "same alert won&#x27;t re-fire unless its band crosses.",
        s["body"]))
    story.append(Paragraph(
        "<b>Heartbeats</b> - a &quot;system alive&quot; digest fires at "
        "a cadence tied to the current Calm Score: RELAX every 6 h, "
        "TAKE_A_LOOK every 2 h, ACTIVE_MONITORING every 30 min, "
        "URGENT_ACTION every 1 min. Each digest lists active alerts "
        "and notes which are being handled by which user.",
        s["body"]))
    story.append(Paragraph(
        f"<b>Daily PDF</b> - once per day at the configured UTC time "
        f"(default 00:05 UTC) every chat receives a polished portfolio "
        f"report: cover with calm score and ROC strip, σ / IQR / "
        f"combined statistical analysis, calm-score timeline, alert "
        f"and override tables. {_code('/report')} rebuilds the same "
        f"PDF on demand. The daily fire also sweeps the reports folder "
        f"so only the freshest PDF per day survives - earlier on-demand "
        f"duplicates are deleted automatically.",
        s["body"]))

    doc.build(story)
    return OUT


if __name__ == "__main__":
    out = build()
    size_kb = out.stat().st_size / 1024
    print(f"wrote {out}  ({size_kb:.1f} KB)")
