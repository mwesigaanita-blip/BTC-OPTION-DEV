"""Calm Score classifier - pure function over the active-alert set.

Per plan.md §Calm Score:

    RELAX              - no alerts active
    TAKE_A_LOOK        - ≥ 1 INFO or WARNING active
    ACTIVE_MONITORING  - ≥ 1 URGENT, OR ≥ 3 WARNING active
    URGENT_ACTION      - ≥ 1 EMERGENCY active

EMERGENCY is reserved (not currently emitted by Rules 1–5) but kept in
the schema so future high-severity rules can promote the state without
a refactor.

This module produces the deterministic reasoning text used for both the
heartbeat digest and the daily PDF. It does NOT decide whether an alert
is sent - every threshold breach is sent immediately by the notifier.
"""
from __future__ import annotations

from collections import Counter
from enum import Enum
from typing import Iterable, Protocol, Tuple

from portfolio_analysis import config  # noqa: F401  (kept for future thresholds)
from portfolio_analysis.rules.base import (
    EMERGENCY,
    INFO,
    URGENT,
    WARNING,
)

__all__ = [
    "CalmState",
    "AlertLike",
    "WARNING_COUNT_FOR_ACTIVE_MONITORING",
    "classify",
]


# ---------------------------------------------------------------------------
# Tunables (kept here, NOT in config.py, because changing them would change
# the meaning of the Calm Score itself rather than a numeric threshold).
# ---------------------------------------------------------------------------

WARNING_COUNT_FOR_ACTIVE_MONITORING: int = 3


class CalmState(str, Enum):
    RELAX = "RELAX"
    TAKE_A_LOOK = "TAKE_A_LOOK"
    ACTIVE_MONITORING = "ACTIVE_MONITORING"
    URGENT_ACTION = "URGENT_ACTION"


class AlertLike(Protocol):
    rule: str
    severity: str
    dedup_key: str


# ---------------------------------------------------------------------------
# Classifier
# ---------------------------------------------------------------------------

def classify(active_alerts: Iterable[AlertLike]) -> Tuple[CalmState, str]:
    """Return ``(state, reasoning_text)`` for the given active alerts.

    The reasoning text is deterministic - same input always produces the
    exact same string - so it can be safely snapshot-tested and used in
    the heartbeat / daily report.
    """
    alerts = list(active_alerts)

    if not alerts:
        return CalmState.RELAX, "RELAX - no active alerts."

    counts = Counter(a.severity for a in alerts)
    n_emergency = counts.get(EMERGENCY, 0)
    n_urgent    = counts.get(URGENT, 0)
    n_warning   = counts.get(WARNING, 0)
    n_info      = counts.get(INFO, 0)

    if n_emergency >= 1:
        state = CalmState.URGENT_ACTION
    elif n_urgent >= 1 or n_warning >= WARNING_COUNT_FOR_ACTIVE_MONITORING:
        state = CalmState.ACTIVE_MONITORING
    else:
        state = CalmState.TAKE_A_LOOK

    return state, _build_reasoning(state, alerts, n_emergency, n_urgent, n_warning, n_info)


# ---------------------------------------------------------------------------
# Reasoning text
# ---------------------------------------------------------------------------

# Order alerts deterministically: by severity (most → least severe), then
# by rule, then by dedup_key.
_SEVERITY_ORDER = {EMERGENCY: 0, URGENT: 1, WARNING: 2, INFO: 3}


def _sort_key(a: AlertLike) -> tuple:
    return (_SEVERITY_ORDER.get(a.severity, 99), a.rule, a.dedup_key)


def _build_reasoning(
    state: CalmState,
    alerts: list[AlertLike],
    n_emergency: int,
    n_urgent: int,
    n_warning: int,
    n_info: int,
) -> str:
    counts: list[str] = []
    if n_emergency:
        counts.append(f"{n_emergency} EMERGENCY")
    if n_urgent:
        counts.append(f"{n_urgent} URGENT")
    if n_warning:
        counts.append(f"{n_warning} WARNING")
    if n_info:
        counts.append(f"{n_info} INFO")
    counts_str = ", ".join(counts) if counts else "no alerts"

    detail_alerts = sorted(alerts, key=_sort_key)
    details = "; ".join(f"{a.rule} [{a.dedup_key}]" for a in detail_alerts)
    return f"{state.value} - {counts_str} active: {details}."
