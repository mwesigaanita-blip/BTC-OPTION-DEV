"""Daily PDF report - built by the DailyReportWorker.

Combines two daily views into a single PDF:

  Market intelligence (Deribit live API):
    1. Price Index            6. IV Smile
    2. Funding Rate           7. Historical Volatility
    3. Futures Premium        8. DVOL
    4. OI by Expiry           9. Greeks (Gamma Profile + Net Delta)
    5. OI by Strike          10. Volume & Trades
                             11. Skew Analysis (25-delta RR & Fly)
                             12. Cheat Sheet

  Portfolio control plane:
    13. Calm Score timeline & account snapshot
    14. Alerts table
    15. Threshold overrides table

Fires once per day in all cases (proof-of-life). If Deribit credentials
are missing or the API is unreachable, the market sections are skipped
and a portfolio-only PDF is emitted.

Env vars:
  DERIBIT_CLIENT_ID, DERIBIT_CLIENT_SECRET - required for market sections
  REPORT_DAILY_UTC_HOUR/MINUTE             - schedule (config defaults)

Restart safety: ``report_runs`` rows track every send. On startup the
worker checks for a row in the most recent expected window - if absent,
it fires once for the missed window; if present, it waits for the next
trigger time.
"""
from __future__ import annotations

import json
import math as _math
import os
import re
import sqlite3
import threading
import time
import warnings
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Optional

import numpy as np
import pandas as pd
import requests

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import matplotlib.ticker as mticker

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_RIGHT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import mm
from reportlab.platypus import (
    HRFlowable, Image, PageBreak, Paragraph, SimpleDocTemplate,
    Spacer, Table, TableStyle,
)

from portfolio_analysis import config, storage
from portfolio_analysis import notifier as _notifier
from realtime._logging import get_logger
from shared.db_paths import HEDGE_ENGINE_DB, MARKET_DATA_DB, REALTIME_DB
from dotenv import load_dotenv

load_dotenv()
warnings.filterwarnings("ignore")

__all__ = [
    "build_report",
    "send_report",
    "cleanup_duplicate_reports",
    "DailyReportWorker",
    "next_fire_time",
    "WINDOW_HOURS",
]

log = get_logger("portfolio_analysis.report_daily")

WINDOW_HOURS = 24
RETRY_DELAY_S = 60.0
TICK_INTERVAL_S = 30.0

# ══════════════════════════════════════════════════════════════════════════════
# Deribit config
# ══════════════════════════════════════════════════════════════════════════════
BASE_URL = os.getenv("DERIBIT_BASE_URL", "https://www.deribit.com").rstrip("/") + "/api/v2"
CURRENCY = "BTC"

# ══════════════════════════════════════════════════════════════════════════════
# Colour palette (dark theme - matches daily_report_example.py)
# ══════════════════════════════════════════════════════════════════════════════
DARK = "#0D1117"; PANEL = "#161B22"; ACC = "#F7931A"
GRN = "#26A69A"; RED = "#EF5350"; BLU = "#2196F3"
PUR = "#AB47BC"; TXT = "#E6EDF3"; GRID = "#21262D"; YLW = "#FFC107"

C_BG      = colors.HexColor(DARK);       C_PANEL  = colors.HexColor(PANEL)
C_ACCENT  = colors.HexColor(ACC);        C_GREEN  = colors.HexColor(GRN)
C_RED     = colors.HexColor(RED);        C_BLUE   = colors.HexColor(BLU)
C_PURPLE  = colors.HexColor(PUR);        C_TEXT   = colors.HexColor(TXT)
C_SUBTEXT = colors.HexColor("#8B949E");  C_BORDER = colors.HexColor(GRID)
C_YELLOW  = colors.HexColor(YLW)

PAGE_W, PAGE_H = A4
MARGIN = 18 * mm
IMG_W = PAGE_W - 2 * MARGIN

# Calm Score + severity → color (badge fills)
CALM_COLORS = {
    "RELAX":             "#2E7D32",
    "TAKE_A_LOOK":       "#F9A825",
    "ACTIVE_MONITORING": "#EF6C00",
    "URGENT_ACTION":     "#C62828",
}
SEVERITY_COLORS = {
    "INFO":      "#1565C0",
    "WARNING":   "#F9A825",
    "URGENT":    "#EF6C00",
    "EMERGENCY": "#B71C1C",
}


# ---------------------------------------------------------------------------
# Time helpers
# ---------------------------------------------------------------------------

def _now() -> datetime:
    return datetime.now(timezone.utc)


def _iso(dt: datetime) -> str:
    return dt.strftime("%Y-%m-%dT%H:%M:%S.%f") + "Z"


def next_fire_time(*, after: Optional[datetime] = None) -> datetime:
    """Next UTC datetime at which the report should fire."""
    after = after or _now()
    today = after.replace(
        hour=config.REPORT_DAILY_UTC_HOUR,
        minute=config.REPORT_DAILY_UTC_MINUTE,
        second=0, microsecond=0,
    )
    return today if today > after else today + timedelta(days=1)


# ══════════════════════════════════════════════════════════════════════════════
# DERIBIT API CLIENT
# ══════════════════════════════════════════════════════════════════════════════
class DeribitClient:
    def __init__(self, client_id: str, client_secret: str):
        self.client_id = client_id
        self.client_secret = client_secret
        self.access_token: Optional[str] = None
        self.session = requests.Session()

    def authenticate(self):
        res = self._get("/public/auth", {
            "grant_type": "client_credentials",
            "client_id": self.client_id,
            "client_secret": self.client_secret,
        })
        self.access_token = res["access_token"]
        self.session.headers.update({"Authorization": f"Bearer {self.access_token}"})

    def _get(self, endpoint, params=None):
        r = self.session.get(f"{BASE_URL}{endpoint}", params=params, timeout=20)
        r.raise_for_status()
        body = r.json()
        if "error" in body:
            raise ValueError(f"API error: {body['error']}")
        return body.get("result", body)

    def get_index_price(self):
        return float(self._get("/public/get_index_price", {"index_name": "btc_usd"})["index_price"])

    def get_price_history(self, hours=168):
        now_ms = int(time.time() * 1000)
        res = self._get("/public/get_tradingview_chart_data", {
            "instrument_name": "BTC-PERPETUAL",
            "start_timestamp": now_ms - hours * 3_600_000,
            "end_timestamp":   now_ms,
            "resolution":      "60",
        })
        return pd.DataFrame({
            "DateTime": pd.to_datetime(res["ticks"], unit="ms", utc=True),
            "Price": res["close"],
        }).sort_values("DateTime").reset_index(drop=True)

    def get_perpetual_ticker(self):
        return self._get("/public/ticker", {"instrument_name": "BTC-PERPETUAL"})

    def get_funding_rate_history(self, hours=168):
        now_ms = int(time.time() * 1000)
        res = self._get("/public/get_funding_rate_history", {
            "instrument_name": "BTC-PERPETUAL",
            "start_timestamp": now_ms - hours * 3_600_000,
            "end_timestamp":   now_ms,
        })
        df = pd.DataFrame(res)
        df["DateTime"] = pd.to_datetime(df["timestamp"], unit="ms", utc=True)
        return df.rename(columns={"interest_8h": "FundingRate"})[["DateTime", "FundingRate"]] \
            .sort_values("DateTime").reset_index(drop=True)

    def get_historical_volatility(self):
        res = self._get("/public/get_historical_volatility", {"currency": CURRENCY})
        df = pd.DataFrame(res, columns=["ts", "HV"])
        df["DateTime"] = pd.to_datetime(df["ts"], unit="ms", utc=True)
        return df[["DateTime", "HV"]].sort_values("DateTime").reset_index(drop=True)

    def get_dvol_history(self, days=30):
        now_ms = int(time.time() * 1000)
        res = self._get("/public/get_volatility_index_data", {
            "currency": CURRENCY,
            "start_timestamp": now_ms - days * 86_400_000,
            "end_timestamp":   now_ms,
            "resolution":      "60",
        })
        df = pd.DataFrame(res.get("data", []), columns=["ts", "open", "high", "low", "close"])
        df["DateTime"] = pd.to_datetime(df["ts"], unit="ms", utc=True)
        return df.rename(columns={"close": "DVOL"})[["DateTime", "DVOL"]] \
            .sort_values("DateTime").reset_index(drop=True)

    def get_options_summary(self):
        return pd.DataFrame(self._get("/public/get_book_summary_by_currency",
                                      {"currency": CURRENCY, "kind": "option"}))

    def get_futures_summary(self):
        return pd.DataFrame(self._get("/public/get_book_summary_by_currency",
                                      {"currency": CURRENCY, "kind": "future"}))


# ══════════════════════════════════════════════════════════════════════════════
# Black-Scholes helpers
# ══════════════════════════════════════════════════════════════════════════════
def _ncdf(x):
    return 0.5 * (1.0 + _math.erf(x / _math.sqrt(2.0)))


def _npdf(x):
    return _math.exp(-0.5 * x * x) / _math.sqrt(2.0 * _math.pi)


_EXPIRY_MAP = {
    "JAN": "01", "FEB": "02", "MAR": "03", "APR": "04", "MAY": "05", "JUN": "06",
    "JUL": "07", "AUG": "08", "SEP": "09", "OCT": "10", "NOV": "11", "DEC": "12",
}


def _parse_expiry_date(expiry_str):
    try:
        day = int(expiry_str[:2])
        mon = _EXPIRY_MAP.get(expiry_str[2:5].upper(), "01")
        yr = int("20" + expiry_str[5:7])
        return datetime(yr, int(mon), day, 8, 0, tzinfo=timezone.utc)
    except Exception:
        return None


def _bs_greeks(spot, strike, iv_pct, expiry_str, opt_type, r=0.0):
    """Black-Scholes delta + gamma. Returns (delta, gamma) or (0.5, 0.0) on failure."""
    try:
        exp_dt = _parse_expiry_date(expiry_str)
        if exp_dt is None:
            return (0.5, 0.0)
        T = max((exp_dt - datetime.now(timezone.utc)).total_seconds() / (365.25 * 86400), 1e-6)
        sigma = iv_pct / 100.0
        d1 = (_math.log(spot / strike) + (r + 0.5 * sigma ** 2) * T) / (sigma * _math.sqrt(T))
        delta = _ncdf(d1) if opt_type == "C" else _ncdf(d1) - 1.0
        gamma = _npdf(d1) / (spot * sigma * _math.sqrt(T))
        return (delta, gamma)
    except Exception:
        return (0.5, 0.0)


def _parse_opts(df_opt):
    df = df_opt.copy()
    parts = df["instrument_name"].str.split("-", expand=True)
    df["expiry"] = parts[1]
    df["strike"] = pd.to_numeric(parts[2], errors="coerce")
    df["opt_type"] = parts[3]
    for col in ["open_interest", "mark_iv", "volume"]:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0)
    if "greeks" in df.columns:
        g = df["greeks"].apply(lambda x: x if isinstance(x, dict) else {})
        df["delta"] = g.apply(lambda x: float(x.get("delta", np.nan)))
        df["gamma"] = g.apply(lambda x: float(x.get("gamma", np.nan)))
    if "delta" not in df.columns:
        df["delta"] = np.nan
    if "gamma" not in df.columns:
        df["gamma"] = np.nan
    return df.dropna(subset=["strike", "opt_type"])


def process_options(df_opt, spot):
    df = _parse_opts(df_opt)
    calls = df[df["opt_type"] == "C"].groupby("strike")["open_interest"].sum().rename("Calls")
    puts = df[df["opt_type"] == "P"].groupby("strike")["open_interest"].sum().rename("Puts")
    oi_strike = pd.concat([calls, puts], axis=1).fillna(0).reset_index()

    ce = df[df["opt_type"] == "C"].groupby("expiry")["open_interest"].sum().rename("Total_Calls")
    pe = df[df["opt_type"] == "P"].groupby("expiry")["open_interest"].sum().rename("Total_Puts")
    oi_expiry = pd.concat([ce, pe], axis=1).fillna(0).reset_index()

    total_calls = df[df["opt_type"] == "C"]["open_interest"].sum()
    total_puts = df[df["opt_type"] == "P"]["open_interest"].sum()
    pcr = total_puts / total_calls if total_calls > 0 else 0
    return oi_strike, oi_expiry, total_calls, total_puts, pcr


def process_futures_premium(df_fut, spot):
    df = df_fut[~df_fut["instrument_name"].str.contains("PERPETUAL")].copy()
    df["premium"] = pd.to_numeric(df["mark_price"], errors="coerce") - spot
    return df[["instrument_name", "mark_price", "premium"]].dropna().sort_values("premium")


def process_greeks(df_opt, spot):
    df = _parse_opts(df_opt)
    missing = df["delta"].isna() | df["gamma"].isna()
    if missing.any():
        for idx in df[missing].index:
            row = df.loc[idx]
            d, g = _bs_greeks(
                spot=spot,
                strike=float(row["strike"]),
                iv_pct=float(row["mark_iv"]) if row["mark_iv"] > 0 else 50.0,
                expiry_str=str(row["expiry"]),
                opt_type=str(row["opt_type"]),
            )
            df.at[idx, "delta"] = d
            df.at[idx, "gamma"] = g
    df["delta"] = pd.to_numeric(df["delta"], errors="coerce").fillna(0)
    df["gamma"] = pd.to_numeric(df["gamma"], errors="coerce").fillna(0)

    df["net_delta"] = np.where(
        df["opt_type"] == "C",
        -df["delta"] * df["open_interest"],
        df["delta"].abs() * df["open_interest"],
    )
    df["net_gamma"] = -df["gamma"] * df["open_interest"]

    by_strike = df.groupby("strike").agg(
        net_delta=("net_delta", "sum"),
        net_gamma=("net_gamma", "sum"),
    ).reset_index()
    by_strike["net_gamma_scaled"] = by_strike["net_gamma"] * spot * 0.01

    by_strike_sorted = by_strike.sort_values("strike")
    cum_gamma = by_strike_sorted["net_gamma"].cumsum()
    flip_idx = (cum_gamma >= 0).idxmax() if (cum_gamma >= 0).any() else None
    gamma_flip = float(by_strike_sorted.loc[flip_idx, "strike"]) if flip_idx is not None else None
    return by_strike, gamma_flip


def process_volume(df_opt, df_fut):
    df = _parse_opts(df_opt)
    cv = df[df["opt_type"] == "C"].groupby("expiry")["volume"].sum().rename("Call_Vol")
    pv = df[df["opt_type"] == "P"].groupby("expiry")["volume"].sum().rename("Put_Vol")
    vol_expiry = pd.concat([cv, pv], axis=1).fillna(0).reset_index()
    vol_expiry["Total_Vol"] = vol_expiry["Call_Vol"] + vol_expiry["Put_Vol"]
    vol_expiry = vol_expiry.sort_values("Total_Vol", ascending=False)

    sv = df.groupby("strike")["volume"].sum().reset_index().rename(columns={"volume": "Total_Vol"})
    sv_calls = df[df["opt_type"] == "C"].groupby("strike")["volume"].sum().rename("Call_Vol")
    sv_puts = df[df["opt_type"] == "P"].groupby("strike")["volume"].sum().rename("Put_Vol")
    vol_strike = sv.join(sv_calls, on="strike").join(sv_puts, on="strike").fillna(0)
    vol_strike = vol_strike.sort_values("Total_Vol", ascending=False).head(15)

    df_f = df_fut.copy()
    df_f["volume"] = pd.to_numeric(df_f.get("volume", 0), errors="coerce").fillna(0)
    total_fut_vol = df_f["volume"].sum()

    total_opt_vol = df["volume"].sum()
    call_vol_total = df[df["opt_type"] == "C"]["volume"].sum()
    put_vol_total = df[df["opt_type"] == "P"]["volume"].sum()
    vol_pcr = put_vol_total / call_vol_total if call_vol_total > 0 else 0
    return vol_expiry, vol_strike, total_opt_vol, call_vol_total, put_vol_total, vol_pcr, total_fut_vol


def process_skew(df_opt, spot=None):
    df = _parse_opts(df_opt)
    if "delta" not in df.columns or df["delta"].isna().all():
        if spot is None:
            return pd.DataFrame()
        df["delta"] = np.nan
        df["gamma"] = np.nan
    missing = df["delta"].isna()
    if missing.any() and spot is not None:
        for idx in df[missing].index:
            row = df.loc[idx]
            d, _g = _bs_greeks(
                spot=spot,
                strike=float(row["strike"]),
                iv_pct=float(row["mark_iv"]) if row["mark_iv"] > 0 else 50.0,
                expiry_str=str(row["expiry"]),
                opt_type=str(row["opt_type"]),
            )
            df.at[idx, "delta"] = d
    df["delta"] = pd.to_numeric(df["delta"], errors="coerce").fillna(0)
    if df["delta"].abs().max() == 0:
        return pd.DataFrame()

    results = []
    for exp in df["expiry"].unique():
        sub = df[df["expiry"] == exp].copy()
        calls = sub[sub["opt_type"] == "C"]
        puts = sub[sub["opt_type"] == "P"]
        if len(calls) < 2 or len(puts) < 2:
            continue
        idx_25c = (calls["delta"] - 0.25).abs().idxmin()
        iv_25c = calls.loc[idx_25c, "mark_iv"]
        idx_25p = (puts["delta"].abs() - 0.25).abs().idxmin()
        iv_25p = puts.loc[idx_25p, "mark_iv"]
        atm_c = calls.iloc[(calls["delta"] - 0.5).abs().argsort()[:1]]
        atm_p = puts.iloc[(puts["delta"].abs() - 0.5).abs().argsort()[:1]]
        iv_atm = (atm_c["mark_iv"].mean() + atm_p["mark_iv"].mean()) / 2
        rr25 = iv_25c - iv_25p
        fly25 = (iv_25c + iv_25p) / 2 - iv_atm
        results.append({
            "expiry": exp,
            "iv_25c": round(iv_25c, 2),
            "iv_25p": round(iv_25p, 2),
            "iv_atm": round(iv_atm, 2),
            "rr25": round(rr25, 2),
            "fly25": round(fly25, 2),
        })
    return pd.DataFrame(results)


# ══════════════════════════════════════════════════════════════════════════════
# CHART GENERATORS
# ══════════════════════════════════════════════════════════════════════════════
def _style(ax, title=""):
    ax.set_facecolor(PANEL)
    ax.tick_params(colors=TXT, labelsize=8)
    for s in ["bottom", "left"]:
        ax.spines[s].set_color(GRID)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.grid(color=GRID, linestyle="--", linewidth=0.5, alpha=0.7)
    if title:
        ax.set_title(title, color=TXT, fontsize=10, fontweight="bold", pad=8)


def make_price_chart(df, path):
    fig, ax = plt.subplots(figsize=(7.5, 2.8), facecolor=DARK)
    ax.fill_between(df["DateTime"], df["Price"], alpha=0.18, color=ACC)
    ax.plot(df["DateTime"], df["Price"], color=ACC, linewidth=1.5)
    _style(ax, "BTC/USD Price - Last 7 Days (Hourly)")
    ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda x, _: f"${x:,.0f}"))
    ax.xaxis.set_major_formatter(mdates.DateFormatter("%d %b"))
    ax.xaxis.set_major_locator(mdates.DayLocator())
    plt.tight_layout(pad=0.5); plt.savefig(path, dpi=150, bbox_inches="tight", facecolor=DARK); plt.close()


def make_funding_chart(df, path):
    df = df.copy(); df["FR_ann"] = df["FundingRate"] * 3 * 365 * 100
    fig, ax = plt.subplots(figsize=(7.5, 2.8), facecolor=DARK)
    ax.bar(df["DateTime"], df["FR_ann"],
           color=[GRN if v >= 0 else RED for v in df["FR_ann"]], width=0.03, alpha=0.9)
    ax.axhline(0, color=TXT, linewidth=0.5, linestyle="--")
    _style(ax, "Funding Rate (Annualised %) - Last 7 Days")
    ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda x, _: f"{x:.1f}%"))
    ax.xaxis.set_major_formatter(mdates.DateFormatter("%d %b"))
    ax.xaxis.set_major_locator(mdates.DayLocator())
    plt.tight_layout(pad=0.5); plt.savefig(path, dpi=150, bbox_inches="tight", facecolor=DARK); plt.close()


def make_hv_chart(df, path):
    df14 = df[df["DateTime"] >= df["DateTime"].max() - pd.Timedelta(days=14)]
    fig, ax = plt.subplots(figsize=(7.5, 2.6), facecolor=DARK)
    ax.fill_between(df14["DateTime"], df14["HV"], alpha=0.18, color=PUR)
    ax.plot(df14["DateTime"], df14["HV"], color=PUR, linewidth=1.5)
    _style(ax, "Historical Volatility (%) - Last 14 Days")
    ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda x, _: f"{x:.1f}%"))
    ax.xaxis.set_major_formatter(mdates.DateFormatter("%d %b"))
    ax.xaxis.set_major_locator(mdates.DayLocator(interval=2))
    plt.tight_layout(pad=0.5); plt.savefig(path, dpi=150, bbox_inches="tight", facecolor=DARK); plt.close()


def make_dvol_chart(df, path):
    fig, ax = plt.subplots(figsize=(7.5, 2.6), facecolor=DARK)
    ax.fill_between(df["DateTime"], df["DVOL"], alpha=0.18, color=BLU)
    ax.plot(df["DateTime"], df["DVOL"], color=BLU, linewidth=1.5)
    _style(ax, "DVOL - Deribit BTC Volatility Index (30 Days)")
    ax.xaxis.set_major_formatter(mdates.DateFormatter("%d %b"))
    ax.xaxis.set_major_locator(mdates.WeekdayLocator(interval=5))
    plt.tight_layout(pad=0.5); plt.savefig(path, dpi=150, bbox_inches="tight", facecolor=DARK); plt.close()


def make_oi_expiry_chart(df, path):
    df = df.sort_values("Total_Calls", ascending=False).head(10)
    fig, ax = plt.subplots(figsize=(7.5, 3.2), facecolor=DARK)
    x, w = np.arange(len(df)), 0.35
    ax.bar(x - w / 2, df["Total_Calls"], width=w, color=GRN, alpha=0.85, label="Calls")
    ax.bar(x + w / 2, df["Total_Puts"],  width=w, color=RED, alpha=0.85, label="Puts")
    ax.set_xticks(x); ax.set_xticklabels(df["expiry"], rotation=35, ha="right", fontsize=7.5)
    _style(ax, "Open Interest by Expiration (BTC)")
    ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda x, _: f"{x:,.0f}"))
    ax.legend(facecolor=PANEL, edgecolor=GRID, labelcolor=TXT, fontsize=8)
    plt.tight_layout(pad=0.5); plt.savefig(path, dpi=150, bbox_inches="tight", facecolor=DARK); plt.close()


def make_oi_strike_chart(df, spot, path):
    df = df[(df["strike"] >= spot * 0.7) & (df["strike"] <= spot * 1.6)]
    fig, ax = plt.subplots(figsize=(7.5, 3.2), facecolor=DARK)
    w = df["strike"].diff().median() * 0.4 if len(df) > 1 else 1000
    ax.bar(df["strike"] - w / 2, df["Calls"], width=w, color=GRN, alpha=0.85, label="Calls")
    ax.bar(df["strike"] + w / 2, df["Puts"],  width=w, color=RED, alpha=0.85, label="Puts")
    ax.axvline(spot, color=ACC, linewidth=1.2, linestyle="--", label=f"Spot ~${spot:,.0f}")
    _style(ax, "Open Interest by Strike (70%–160% of Spot)")
    ax.xaxis.set_major_formatter(mticker.FuncFormatter(lambda x, _: f"${x/1000:.0f}K"))
    ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda x, _: f"{x:,.0f}"))
    ax.legend(facecolor=PANEL, edgecolor=GRID, labelcolor=TXT, fontsize=8)
    plt.tight_layout(pad=0.5); plt.savefig(path, dpi=150, bbox_inches="tight", facecolor=DARK); plt.close()


def make_futures_premium_chart(df, path):
    fig, ax = plt.subplots(figsize=(7.5, 2.8), facecolor=DARK)
    labels = df["instrument_name"].str.replace("BTC-", "", regex=False)
    ax.bar(range(len(df)), df["premium"],
           color=[GRN if v >= 0 else RED for v in df["premium"]], alpha=0.85)
    ax.set_xticks(range(len(df))); ax.set_xticklabels(labels, rotation=35, ha="right", fontsize=7.5)
    ax.axhline(0, color=TXT, linewidth=0.5, linestyle="--")
    _style(ax, "Futures Premium Above Spot (USD)")
    ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda x, _: f"${x:,.0f}"))
    plt.tight_layout(pad=0.5); plt.savefig(path, dpi=150, bbox_inches="tight", facecolor=DARK); plt.close()


def make_iv_smile_chart(df_opt, spot, path):
    df = _parse_opts(df_opt)
    df = df[(df["mark_iv"] > 0) & (df["strike"] >= spot * 0.4) & (df["strike"] <= spot * 2.0)]
    expiries = sorted(df["expiry"].unique())[:8]
    cmap = plt.cm.get_cmap("plasma", len(expiries))
    fig, ax = plt.subplots(figsize=(7.5, 3.0), facecolor=DARK)
    for i, exp in enumerate(expiries):
        sub = df[df["expiry"] == exp].sort_values("strike")
        if len(sub) < 3:
            continue
        ax.plot(sub["strike"], sub["mark_iv"], color=cmap(i), linewidth=1.4,
                label=exp, alpha=0.85, marker="o", markersize=2)
    ax.axvline(spot, color=ACC, linewidth=1, linestyle="--", label=f"Spot ~${spot:,.0f}")
    _style(ax, "Implied Volatility Smile by Expiry")
    ax.xaxis.set_major_formatter(mticker.FuncFormatter(lambda x, _: f"${x/1000:.0f}K"))
    ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda x, _: f"{x:.0f}%"))
    ax.legend(facecolor=PANEL, edgecolor=GRID, labelcolor=TXT, fontsize=7, ncol=2)
    plt.tight_layout(pad=0.5); plt.savefig(path, dpi=150, bbox_inches="tight", facecolor=DARK); plt.close()


def make_gamma_chart(df_greeks, spot, gamma_flip, path):
    df = df_greeks[(df_greeks["strike"] >= spot * 0.7) & (df_greeks["strike"] <= spot * 1.5)].copy()
    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(7.5, 5.5), facecolor=DARK,
                                   gridspec_kw={"hspace": 0.45})
    w = df["strike"].diff().median() * 0.4 if len(df) > 1 else 1000

    gcols = [GRN if v >= 0 else RED for v in df["net_gamma_scaled"]]
    ax1.bar(df["strike"], df["net_gamma_scaled"], width=w, color=gcols, alpha=0.85)
    ax1.axhline(0, color=TXT, linewidth=0.8, linestyle="--")
    ax1.axvline(spot, color=ACC, linewidth=1.2, linestyle="--", label=f"Spot ${spot:,.0f}")
    if gamma_flip:
        ax1.axvline(gamma_flip, color=YLW, linewidth=1, linestyle=":",
                    label=f"Gamma Flip ${gamma_flip:,.0f}")
    _style(ax1, "Dealer Net Gamma Exposure (BTC per 1% move)")
    ax1.xaxis.set_major_formatter(mticker.FuncFormatter(lambda x, _: f"${x/1000:.0f}K"))
    ax1.yaxis.set_major_formatter(mticker.FuncFormatter(lambda x, _: f"{x:,.0f}"))
    ax1.legend(facecolor=PANEL, edgecolor=GRID, labelcolor=TXT, fontsize=7)

    dcols = [RED if v < 0 else GRN for v in df["net_delta"]]
    ax2.bar(df["strike"], df["net_delta"], width=w, color=dcols, alpha=0.85)
    ax2.axhline(0, color=TXT, linewidth=0.8, linestyle="--")
    ax2.axvline(spot, color=ACC, linewidth=1.2, linestyle="--")
    _style(ax2, "Dealer Net Delta Exposure (BTC)")
    ax2.xaxis.set_major_formatter(mticker.FuncFormatter(lambda x, _: f"${x/1000:.0f}K"))
    ax2.yaxis.set_major_formatter(mticker.FuncFormatter(lambda x, _: f"{x:,.0f}"))

    fig.patch.set_facecolor(DARK)
    plt.savefig(path, dpi=150, bbox_inches="tight", facecolor=DARK); plt.close()


def make_volume_chart(vol_expiry, vol_strike, path):
    ve = vol_expiry.head(8)
    vs = vol_strike.head(10).sort_values("strike")
    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(7.5, 5.5), facecolor=DARK,
                                   gridspec_kw={"hspace": 0.45})
    x, w = np.arange(len(ve)), 0.35
    ax1.bar(x - w / 2, ve["Call_Vol"], width=w, color=GRN, alpha=0.85, label="Call Vol")
    ax1.bar(x + w / 2, ve["Put_Vol"],  width=w, color=RED, alpha=0.85, label="Put Vol")
    ax1.set_xticks(x); ax1.set_xticklabels(ve["expiry"], rotation=35, ha="right", fontsize=7.5)
    _style(ax1, "24h Options Volume by Expiry (BTC)")
    ax1.yaxis.set_major_formatter(mticker.FuncFormatter(lambda x, _: f"{x:,.0f}"))
    ax1.legend(facecolor=PANEL, edgecolor=GRID, labelcolor=TXT, fontsize=8)

    x2, w2 = np.arange(len(vs)), 0.35
    ax2.bar(x2 - w2 / 2, vs["Call_Vol"], width=w2, color=GRN, alpha=0.85, label="Calls")
    ax2.bar(x2 + w2 / 2, vs["Put_Vol"],  width=w2, color=RED, alpha=0.85, label="Puts")
    ax2.set_xticks(x2)
    ax2.set_xticklabels([f"${int(s/1000)}K" for s in vs["strike"]], rotation=35, ha="right", fontsize=7.5)
    _style(ax2, "24h Volume - Top Active Strikes (BTC)")
    ax2.yaxis.set_major_formatter(mticker.FuncFormatter(lambda x, _: f"{x:,.0f}"))
    ax2.legend(facecolor=PANEL, edgecolor=GRID, labelcolor=TXT, fontsize=8)

    fig.patch.set_facecolor(DARK)
    plt.savefig(path, dpi=150, bbox_inches="tight", facecolor=DARK); plt.close()


def make_skew_chart(df_skew, path):
    if df_skew is None or len(df_skew) == 0:
        fig, ax = plt.subplots(figsize=(7.5, 2), facecolor=DARK)
        ax.text(0.5, 0.5, "Insufficient data for skew calculation",
                transform=ax.transAxes, color=TXT, ha="center", va="center")
        _style(ax, "Skew Analysis")
        plt.savefig(path, dpi=150, bbox_inches="tight", facecolor=DARK); plt.close()
        return
    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(7.5, 5.5), facecolor=DARK,
                                   gridspec_kw={"hspace": 0.45})
    x = np.arange(len(df_skew))

    rr_colors = [RED if v < 0 else GRN for v in df_skew["rr25"]]
    ax1.bar(x, df_skew["rr25"], color=rr_colors, alpha=0.85)
    ax1.axhline(0, color=TXT, linewidth=0.8, linestyle="--")
    ax1.set_xticks(x); ax1.set_xticklabels(df_skew["expiry"], rotation=35, ha="right", fontsize=7.5)
    _style(ax1, "25-Delta Risk Reversal (%) - Negative = Put Skew (Fear)")
    ax1.yaxis.set_major_formatter(mticker.FuncFormatter(lambda x, _: f"{x:.1f}%"))

    fly_colors = [GRN if v >= 0 else RED for v in df_skew["fly25"]]
    ax2.bar(x, df_skew["fly25"], color=fly_colors, alpha=0.85)
    ax2.axhline(0, color=TXT, linewidth=0.8, linestyle="--")
    ax2.set_xticks(x); ax2.set_xticklabels(df_skew["expiry"], rotation=35, ha="right", fontsize=7.5)
    _style(ax2, "25-Delta Butterfly (%) - Wings vs ATM Vol Premium")
    ax2.yaxis.set_major_formatter(mticker.FuncFormatter(lambda x, _: f"{x:.1f}%"))

    fig.patch.set_facecolor(DARK)
    plt.savefig(path, dpi=150, bbox_inches="tight", facecolor=DARK); plt.close()


# ══════════════════════════════════════════════════════════════════════════════
# PDF STYLES
# ══════════════════════════════════════════════════════════════════════════════
def S(name, **kw):
    return ParagraphStyle(name, **kw)


sTitle    = S("sT",  fontSize=26, textColor=colors.white,  fontName="Helvetica-Bold", alignment=TA_CENTER, leading=32)
sSub      = S("sS",  fontSize=11, textColor=C_SUBTEXT,     fontName="Helvetica",      alignment=TA_CENTER, leading=16)
sDate     = S("sDt", fontSize=10, textColor=C_ACCENT,      fontName="Helvetica-Bold", alignment=TA_CENTER, leading=14)
sH1       = S("h1",  fontSize=13, textColor=C_ACCENT,      fontName="Helvetica-Bold", leading=18, spaceAfter=3)
sH2       = S("h2",  fontSize=10, textColor=C_YELLOW,      fontName="Helvetica-Bold", leading=13, spaceAfter=2)
sBody     = S("bd",  fontSize=8.5, textColor=C_TEXT,       fontName="Helvetica",      leading=13, spaceAfter=4)
sSmall    = S("sm",  fontSize=7.5, textColor=C_SUBTEXT,    fontName="Helvetica",      leading=11)
sCallout  = S("ca",  fontSize=9,  textColor=colors.white,  fontName="Helvetica-Bold", leading=13, alignment=TA_CENTER)
sCallSm   = S("cs",  fontSize=7.5, textColor=C_SUBTEXT,    fontName="Helvetica",      leading=10, alignment=TA_CENTER)
sMLabel   = S("ml",  fontSize=7.5, textColor=C_SUBTEXT,    fontName="Helvetica",      leading=10, alignment=TA_CENTER)
sMValue   = S("mv",  fontSize=14, textColor=colors.white,  fontName="Helvetica-Bold", leading=18, alignment=TA_CENTER)
sSumHead  = S("sh",  fontSize=8,  textColor=C_SUBTEXT,     fontName="Helvetica-Bold", leading=10, alignment=TA_CENTER)
sSumVal   = S("sv",  fontSize=11, textColor=colors.white,  fontName="Helvetica-Bold", leading=14, alignment=TA_CENTER)
sSumSub   = S("ss",  fontSize=7,  textColor=C_SUBTEXT,     fontName="Helvetica",      leading=9,  alignment=TA_CENTER)
sCell     = S("cl",  fontSize=7.5, textColor=C_TEXT,       fontName="Helvetica",      leading=10)
sCellR    = S("clr", fontSize=7.5, textColor=C_TEXT,       fontName="Helvetica",      leading=10, alignment=TA_RIGHT)


def divider():
    return HRFlowable(width="100%", thickness=0.5, color=C_BORDER, spaceAfter=5, spaceBefore=5)


def metric_card(label, val, chg=None, pos=True):
    cs = S("_c", fontSize=8, leading=10, fontName="Helvetica-Bold", alignment=TA_CENTER,
           textColor=C_GREEN if pos else C_RED)
    data = [[Paragraph(label, sMLabel)], [Paragraph(val, sMValue)]]
    if chg:
        data.append([Paragraph(chg, cs)])
    t = Table(data, colWidths=[38 * mm])
    t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), C_PANEL), ("BOX", (0, 0), (-1, -1), 0.5, C_BORDER),
        ("TOPPADDING", (0, 0), (-1, -1), 5), ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
        ("LEFTPADDING", (0, 0), (-1, -1), 4), ("RIGHTPADDING", (0, 0), (-1, -1), 4),
    ]))
    return t


def outlook_box(signal, detail, border=C_GREEN):
    inner = Table([[Paragraph(signal, sCallout)], [Paragraph(detail, sCallSm)]],
                  colWidths=[IMG_W - 8 * mm])
    inner.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#1A2A1A")),
        ("BOX", (0, 0), (-1, -1), 1, border),
        ("TOPPADDING", (0, 0), (-1, -1), 6), ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
        ("LEFTPADDING", (0, 0), (-1, -1), 8), ("RIGHTPADDING", (0, 0), (-1, -1), 8),
    ]))
    return inner


def chart_section(title, subtitle, img_path, h=68 * mm):
    items = [Paragraph(title, sH1)]
    if subtitle:
        items.append(Paragraph(subtitle, sSmall))
    if img_path and os.path.exists(img_path):
        items.append(Image(img_path, width=IMG_W, height=h))
    items.append(divider())
    return items


def build_summary_page(m, df_skew):
    items = [
        Paragraph("★  Daily Cheat Sheet - Key Levels &amp; Signals", sH1),
        Paragraph("All key metrics condensed onto one page", sSmall),
        Spacer(1, 4 * mm),
    ]

    def big_cell(label, val, sub, val_color=C_TEXT):
        vstyle = S("_v", fontSize=16, textColor=val_color, fontName="Helvetica-Bold",
                   leading=20, alignment=TA_CENTER)
        t = Table([[Paragraph(label, sSumHead)],
                   [Paragraph(val, vstyle)],
                   [Paragraph(sub, sSumSub)]], colWidths=[33 * mm])
        t.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, -1), C_PANEL),
            ("BOX", (0, 0), (-1, -1), 0.5, C_BORDER),
            ("TOPPADDING", (0, 0), (-1, -1), 5), ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
            ("LEFTPADDING", (0, 0), (-1, -1), 3), ("RIGHTPADDING", (0, 0), (-1, -1), 3),
        ]))
        return t

    chg_col = C_GREEN if m["chg_24h"] >= 0 else C_RED
    big_row = Table([[
        big_cell("BTC/USD",      f"${m['spot']:,.0f}", f"{m['chg_24h']:+.2f}% 24h", chg_col),
        big_cell("7d Return",    f"{m['chg_7d']:+.1f}%", f"${m['lo_7d']:,.0f}–${m['hi_7d']:,.0f}",
                 C_GREEN if m["chg_7d"] >= 0 else C_RED),
        big_cell("Funding Ann.", f"{m['fr_ann']:.2f}%", "8h rate × 3 × 365",
                 C_GREEN if abs(m["fr_ann"]) < 20 else C_RED),
        big_cell("Hist. Vol",    f"{m['hv']:.1f}%", f"DVOL {m['dvol']:.1f}"),
        big_cell("OI Total",     f"${m['oi_total_usd']:.1f}B", f"P/C {m['pcr']:.3f}"),
    ]], colWidths=[33 * mm] * 5)
    big_row.setStyle(TableStyle([("LEFTPADDING", (0, 0), (-1, -1), 2), ("RIGHTPADDING", (0, 0), (-1, -1), 2)]))
    items += [big_row, Spacer(1, 4 * mm)]

    items.append(Paragraph("Key Options Levels", sH2))
    lev_data = [
        ["Level", "Strike", "OI / Detail", "Role"],
        ["Call Wall #1",    f"${m['call_wall']:,}",   f"{m['call_wall_oi']:,.0f} BTC calls", "Primary Resistance"],
        ["Put Wall #1",     f"${m['put_wall']:,}",    f"{m['put_wall_oi']:,.0f} BTC puts",   "Primary Support"],
        ["Gamma Flip",      f"${m['gamma_flip']:,}" if m.get("gamma_flip") else "N/A",
                            "Dealer gamma = 0",        "Regime Change Level"],
        ["Max Vol Expiry",  m["max_call_exp"],         "Heaviest OI",          "Gamma Battleground"],
    ]
    lev_tbl = Table(lev_data, colWidths=[38 * mm, 30 * mm, 52 * mm, 47 * mm])
    lev_tbl.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1A1A2E")),
        ("TEXTCOLOR", (0, 0), (-1, 0), C_ACCENT), ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, -1), 8),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [C_PANEL, colors.HexColor("#0D1117")]),
        ("TEXTCOLOR", (0, 1), (-1, -1), C_TEXT),
        ("ALIGN", (0, 0), (-1, -1), "LEFT"), ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("TOPPADDING", (0, 0), (-1, -1), 4), ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
        ("LEFTPADDING", (0, 0), (-1, -1), 6), ("RIGHTPADDING", (0, 0), (-1, -1), 6),
        ("BOX", (0, 0), (-1, -1), 0.5, C_BORDER), ("INNERGRID", (0, 0), (-1, -1), 0.3, C_BORDER),
        ("TEXTCOLOR", (3, 1), (3, 1), C_RED), ("TEXTCOLOR", (3, 2), (3, 2), C_GREEN),
    ]))
    items += [lev_tbl, Spacer(1, 4 * mm)]

    items.append(Paragraph("Skew Snapshot - 25-Delta Risk Reversal by Expiry", sH2))
    if df_skew is not None and len(df_skew) > 0:
        skew_data = [["Expiry", "ATM IV", "25d Call IV", "25d Put IV", "RR25", "Fly25", "Skew"]]
        for _, row in df_skew.iterrows():
            skew_lbl = "Put Skew ▼" if row["rr25"] < -1 else ("Call Skew ▲" if row["rr25"] > 1 else "Neutral")
            skew_data.append([
                row["expiry"], f"{row['iv_atm']:.1f}%", f"{row['iv_25c']:.1f}%",
                f"{row['iv_25p']:.1f}%", f"{row['rr25']:+.1f}%", f"{row['fly25']:+.1f}%", skew_lbl,
            ])
        skew_tbl = Table(skew_data, colWidths=[22 * mm, 20 * mm, 22 * mm, 22 * mm, 18 * mm, 16 * mm, 27 * mm])
        sk_style = [
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1A1A2E")),
            ("TEXTCOLOR", (0, 0), (-1, 0), C_ACCENT), ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
            ("FONTSIZE", (0, 0), (-1, -1), 7.5),
            ("ROWBACKGROUNDS", (0, 1), (-1, -1), [C_PANEL, colors.HexColor("#0D1117")]),
            ("TEXTCOLOR", (0, 1), (-1, -1), C_TEXT),
            ("ALIGN", (0, 0), (-1, -1), "CENTER"), ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
            ("TOPPADDING", (0, 0), (-1, -1), 3), ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
            ("BOX", (0, 0), (-1, -1), 0.5, C_BORDER), ("INNERGRID", (0, 0), (-1, -1), 0.3, C_BORDER),
        ]
        for i, row in enumerate(skew_data[1:], 1):
            rr_val = float(row[4].replace("%", ""))
            col = C_RED if rr_val < 0 else C_GREEN
            sk_style += [("TEXTCOLOR", (4, i), (4, i), col), ("TEXTCOLOR", (6, i), (6, i), col)]
        skew_tbl.setStyle(TableStyle(sk_style))
        items += [skew_tbl, Spacer(1, 4 * mm)]
    else:
        items.append(Paragraph("Skew data unavailable.", sSmall))
        items.append(Spacer(1, 4 * mm))

    items.append(Paragraph("Signal Grid", sH2))
    vol_prem = m["dvol"] - m["hv"]

    def sig_row(label, reading, verdict, vcolor):
        vstyle = S("_vr", fontSize=8, fontName="Helvetica-Bold", textColor=vcolor, leading=10)
        return [Paragraph(label, sSmall), Paragraph(reading, sSmall), Paragraph(verdict, vstyle)]

    sig_table_data = [
        sig_row("Price Momentum (24h)",    f"{m['chg_24h']:+.2f}%",
                "Bullish" if m["chg_24h"] > 0.5 else ("Bearish" if m["chg_24h"] < -0.5 else "Neutral"),
                C_GREEN if m["chg_24h"] > 0.5 else (C_RED if m["chg_24h"] < -0.5 else C_SUBTEXT)),
        sig_row("Price Momentum (7d)",     f"{m['chg_7d']:+.1f}%",
                "Bullish" if m["chg_7d"] > 3 else ("Bearish" if m["chg_7d"] < -3 else "Neutral"),
                C_GREEN if m["chg_7d"] > 3 else (C_RED if m["chg_7d"] < -3 else C_SUBTEXT)),
        sig_row("Funding Rate",            f"{m['fr_ann']:.2f}% ann.",
                "Extreme ⚠" if m["fr_ann"] > 50 else ("Bullish" if 0 < m["fr_ann"] <= 50 else ("Neutral" if abs(m["fr_ann"]) <= 5 else "Bearish")),
                C_RED if m["fr_ann"] > 50 else (C_GREEN if m["fr_ann"] > 0 else C_SUBTEXT)),
        sig_row("Put/Call Ratio (OI)",     f"{m['pcr']:.3f}",
                "Bullish" if m["pcr"] < 0.7 else ("Neutral" if m["pcr"] < 1.0 else "Bearish"),
                C_GREEN if m["pcr"] < 0.7 else (C_SUBTEXT if m["pcr"] < 1.0 else C_RED)),
        sig_row("Vol/Trades PCR",          f"{m['vol_pcr']:.3f}",
                "Bullish" if m["vol_pcr"] < 0.7 else ("Neutral" if m["vol_pcr"] < 1.0 else "Bearish"),
                C_GREEN if m["vol_pcr"] < 0.7 else (C_SUBTEXT if m["vol_pcr"] < 1.0 else C_RED)),
        sig_row("HV vs DVOL",              f"HV {m['hv']:.1f}% / DVOL {m['dvol']:.1f}",
                "IV Fair" if abs(vol_prem) <= 3 else ("IV Rich" if vol_prem > 3 else "IV Cheap"),
                C_SUBTEXT if abs(vol_prem) <= 3 else C_RED),
        sig_row("Term Structure",          "Contango" if m["contango"] else "Backwardation",
                "Bullish" if m["contango"] else "Bearish",
                C_GREEN if m["contango"] else C_RED),
        sig_row("Gamma Flip",
                f"${m['gamma_flip']:,}" if m.get("gamma_flip") else "N/A",
                "Above Spot - Bullish" if m.get("gamma_flip") and m["gamma_flip"] > m["spot"] else "Below Spot - Bearish",
                C_GREEN if m.get("gamma_flip") and m["gamma_flip"] > m["spot"] else C_SUBTEXT),
    ]
    sig_t = Table(sig_table_data, colWidths=[52 * mm, 52 * mm, 63 * mm])
    sig_t.setStyle(TableStyle([
        ("FONTSIZE", (0, 0), (-1, -1), 8),
        ("ROWBACKGROUNDS", (0, 0), (-1, -1), [C_PANEL, colors.HexColor("#0D1117")]),
        ("TOPPADDING", (0, 0), (-1, -1), 4), ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
        ("LEFTPADDING", (0, 0), (-1, -1), 6), ("RIGHTPADDING", (0, 0), (-1, -1), 6),
        ("BOX", (0, 0), (-1, -1), 0.5, C_BORDER), ("INNERGRID", (0, 0), (-1, -1), 0.3, C_BORDER),
    ]))
    items += [sig_t, Spacer(1, 3 * mm), divider()]
    items.append(Paragraph(
        "DISCLAIMER: For informational purposes only. Not financial advice. Data from Deribit API.", sSmall))
    return items


# ══════════════════════════════════════════════════════════════════════════════
# Page furniture (dark theme)
# ══════════════════════════════════════════════════════════════════════════════
def _page_furniture(report_date_str: str):
    def on_page(canvas, doc):
        canvas.saveState()
        canvas.setFillColor(C_BG); canvas.rect(0, 0, PAGE_W, PAGE_H, fill=1, stroke=0)
        canvas.setFillColor(C_PANEL); canvas.rect(0, PAGE_H - 14 * mm, PAGE_W, 14 * mm, fill=1, stroke=0)
        canvas.setFillColor(C_ACCENT); canvas.rect(0, PAGE_H - 14.6 * mm, PAGE_W, 0.6 * mm, fill=1, stroke=0)
        canvas.setFillColor(C_PANEL); canvas.rect(0, 0, PAGE_W, 10 * mm, fill=1, stroke=0)
        canvas.setFont("Helvetica", 7); canvas.setFillColor(C_SUBTEXT)
        canvas.drawString(MARGIN, 3.5 * mm, "Portfolio Co-Pilot Daily Report  |  Deribit API")
        canvas.drawRightString(PAGE_W - MARGIN, 3.5 * mm,
                               f"Generated {datetime.now(timezone.utc).strftime('%d %b %Y %H:%M UTC')}  |  Page {doc.page}")
        canvas.setFont("Helvetica-Bold", 9); canvas.setFillColor(C_ACCENT)
        canvas.drawString(MARGIN, PAGE_H - 9 * mm, "PORTFOLIO")
        canvas.setFont("Helvetica", 9); canvas.setFillColor(C_SUBTEXT)
        canvas.drawString(MARGIN + 53, PAGE_H - 9 * mm, "BTC OPTIONS & FUTURES - DAILY")
        canvas.drawRightString(PAGE_W - MARGIN, PAGE_H - 9 * mm, report_date_str)
        canvas.restoreState()
    return on_page


# ══════════════════════════════════════════════════════════════════════════════
# Latest account snapshot (best-effort read of agg-metrics)
# ══════════════════════════════════════════════════════════════════════════════
def _latest_agg_metrics() -> Optional[sqlite3.Row]:
    try:
        conn = sqlite3.connect(
            f"file:{HEDGE_ENGINE_DB}?mode=ro", uri=True, timeout=2.0,
        )
    except sqlite3.OperationalError:
        return None
    conn.row_factory = sqlite3.Row
    try:
        return conn.execute(
            "SELECT * FROM hedge_engine_aggregated_metrics "
            "ORDER BY ts_utc DESC LIMIT 1"
        ).fetchone()
    except sqlite3.OperationalError:
        return None
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# BTC ROC over multiple timeframes
# ---------------------------------------------------------------------------
# Source per horizon is decided by ``btc_returns.is_long_term`` -
# < 24 h reads realtime ticks, ≥ 24 h reads market_data.btc_prices.close.
ROC_TIMEFRAMES: list[tuple[str, int]] = [
    ("1h",   1 * 3600),
    ("4h",   4 * 3600),
    ("24h",  24 * 3600),
    ("72h",  72 * 3600),
    ("7d",   7 * 86400),
    ("1m",   30 * 86400),
]


def _compute_btc_rocs(now: datetime) -> list[dict]:
    """Return per-timeframe ROC info: ``[{label, pct, ref_price, current, src}]``.

    The ``current`` and ``ref_price`` legs are pulled by
    :mod:`portfolio_analysis.features.btc_returns`, which auto-picks the
    data source (realtime vs daily-close) by horizon.
    """
    from portfolio_analysis.features import btc_returns
    now_iso = _iso(now)
    current = btc_returns.current_price()
    out: list[dict] = []
    for label, seconds in ROC_TIMEFRAMES:
        past_dt = now - timedelta(seconds=seconds)
        if btc_returns.is_long_term(seconds):
            past_price = btc_returns.daily_close_at_or_before(past_dt.strftime("%Y-%m-%d"))
            src = "daily"
        else:
            past_price = btc_returns.intraday_price_at(_iso(past_dt))
            src = "intraday"
            # If realtime can't reach back that far yet, fall back to daily.
            if past_price is None:
                past_price = btc_returns.daily_close_at_or_before(past_dt.strftime("%Y-%m-%d"))
                if past_price is not None:
                    src = "daily (fallback)"
        pct: Optional[float] = None
        if current is not None and past_price not in (None, 0):
            pct = (current - past_price) / past_price * 100.0
        out.append({
            "label": label, "pct": pct, "current": current,
            "ref_price": past_price, "src": src,
        })
    return out


# ---------------------------------------------------------------------------
# Window queries against portfolio_analysis.sqlite
# ---------------------------------------------------------------------------
@dataclass
class WindowData:
    state_history: list
    alerts: list
    overrides: list
    audit: list


def _window_data(start_iso: str, end_iso: str) -> WindowData:
    conn = storage.get_conn()
    return WindowData(
        state_history=list(conn.execute(
            "SELECT * FROM state_history WHERE ts_utc >= ? AND ts_utc <= ? "
            "ORDER BY ts_utc ASC", (start_iso, end_iso),
        )),
        alerts=list(conn.execute(
            "SELECT * FROM alerts WHERE ts_utc >= ? AND ts_utc <= ? "
            "ORDER BY ts_utc ASC", (start_iso, end_iso),
        )),
        overrides=list(conn.execute(
            "SELECT * FROM threshold_overrides "
            "WHERE (set_at_utc >= ? AND set_at_utc <= ?) "
            "   OR (expires_at_utc >= ? AND expires_at_utc <= ?) "
            "ORDER BY set_at_utc ASC",
            (start_iso, end_iso, start_iso, end_iso),
        )),
        audit=list(conn.execute(
            "SELECT * FROM audit_log WHERE ts_utc >= ? AND ts_utc <= ? "
            "ORDER BY ts_utc DESC", (start_iso, end_iso),
        )),
    )


# ---------------------------------------------------------------------------
# Number / date formatters
# ---------------------------------------------------------------------------
def _fmt(v) -> str:
    if v is None:
        return "-"
    if isinstance(v, float):
        return f"{v:.4f}".rstrip("0").rstrip(".") or "0"
    return str(v)


def _fmt_gamma(v) -> str:
    if v is None:
        return "-"
    try:
        x = float(v)
    except (TypeError, ValueError):
        return str(v)
    if x == 0:
        return "0"
    s = f"{x:.12f}".rstrip("0").rstrip(".")
    return s or "0"


def _fmt_delta(v) -> str:
    if v is None:
        return "-"
    try:
        x = float(v)
    except (TypeError, ValueError):
        return str(v)
    return f"{x:+.4f} BTC"


def _fmt_vega(v) -> str:
    if v is None:
        return "-"
    try:
        x = float(v)
    except (TypeError, ValueError):
        return str(v)
    return f"{x:+,.2f} USD"


def _fmt_pct(v, *, signed: bool = False) -> str:
    if v is None:
        return "-"
    try:
        x = float(v)
    except (TypeError, ValueError):
        return str(v)
    return (f"{x:+.2f} %" if signed else f"{x:.2f} %")


def _fmt_money(v) -> str:
    if v is None:
        return "-"
    try:
        x = float(v)
    except (TypeError, ValueError):
        return str(v)
    return f"${x:,.2f}"


def _fmt_ts(s: Optional[str]) -> str:
    if not s:
        return "-"
    s = str(s).rstrip("Z")
    if "." in s:
        s = s.split(".")[0]
    s = s.replace("T", " ")
    return f"{s} UTC"


def _truncate(s: str, n: int) -> str:
    s = str(s)
    return s if len(s) <= n else s[: n - 1] + "…"


def _state_transitions(rows) -> list[dict]:
    out: list[dict] = []
    prev: Optional[str] = None
    for r in rows:
        cur = r["calm_score"]
        if cur != prev:
            out.append({
                "ts_utc": r["ts_utc"],
                "from": prev,
                "to": cur,
                "reasoning": r["reasoning"],
            })
            prev = cur
    return out


def _calm_pill_text(calm: str) -> str:
    color = CALM_COLORS.get(calm, TXT)
    return f"<font color='{color}'><b>{calm}</b></font>"


def _alert_status(alert, sup_keys: set) -> str:
    parts: list[str] = []
    if alert["resolved_at_utc"]:
        parts.append("<font color='#26A69A'>resolved</font>")
    else:
        parts.append("<font color='#EF5350'>open</font>")
    if alert["dedup_key"] in sup_keys:
        parts.append("<font color='#FFC107'>stopped</font>")
    return " · ".join(parts)


def _dedup_user(alert, audit_rows) -> str:
    target = alert["dedup_key"]
    for r in audit_rows:
        if r["action"] not in ("stop", "resume"):
            continue
        try:
            payload = json.loads(r["payload_json"])
        except Exception:
            continue
        keys = payload.get("suppressed_keys") or payload.get("cleared_keys") or []
        if target in keys:
            return r["user_name"]
    return ""


# ══════════════════════════════════════════════════════════════════════════════
# Portfolio story (dark-theme flowables that get appended to the market PDF)
# ══════════════════════════════════════════════════════════════════════════════
def _calm_badge_dark(calm: str, reasoning: str):
    fill = colors.HexColor(CALM_COLORS.get(calm, ACC))
    badge_para = Paragraph(
        f"<b>CURRENT CALM SCORE&nbsp;&nbsp;·&nbsp;&nbsp;{calm}</b>", sCallout,
    )
    body_para = Paragraph(reasoning or "-", sSmall)
    t = Table([[badge_para], [body_para]], colWidths=[IMG_W])
    t.setStyle(TableStyle([
        ("BACKGROUND",   (0, 0), (-1, 0), fill),
        ("BACKGROUND",   (0, 1), (-1, 1), C_PANEL),
        ("BOX",          (0, 0), (-1, -1), 0.5, C_BORDER),
        ("LEFTPADDING",  (0, 0), (-1, -1), 10),
        ("RIGHTPADDING", (0, 0), (-1, -1), 10),
        ("TOPPADDING",   (0, 0), (-1, 0), 8),
        ("BOTTOMPADDING",(0, 0), (-1, 0), 8),
        ("TOPPADDING",   (0, 1), (-1, 1), 6),
        ("BOTTOMPADDING",(0, 1), (-1, 1), 6),
    ]))
    return t


def _summary_strip_dark(*, alerts_total, alerts_open, alerts_resolved,
                        suppressions_active, state_changes, overrides, audit):
    cards = [
        (str(alerts_total), "ALERTS", f"{alerts_open} open · {alerts_resolved} resolved"),
        (str(state_changes), "STATE CHANGES", "in window"),
        (str(suppressions_active), "ACTIVE STOPS", "by users"),
        (str(overrides), "OVERRIDES", "set or expired"),
        (str(audit), "AUDIT EVENTS", "recorded"),
    ]
    big_row = [Paragraph(c[0], sSumVal) for c in cards]
    lbl_row = [Paragraph(c[1], sSumHead) for c in cards]
    sub_row = [Paragraph(c[2], sSumSub) for c in cards]
    col_w = IMG_W / len(cards)
    t = Table([big_row, lbl_row, sub_row], colWidths=[col_w] * len(cards))
    t.setStyle(TableStyle([
        ("BACKGROUND",   (0, 0), (-1, -1), C_PANEL),
        ("BOX",          (0, 0), (-1, -1), 0.5, C_BORDER),
        ("INNERGRID",    (0, 0), (-1, -1), 0.25, C_BORDER),
        ("TOPPADDING",   (0, 0), (-1, 0), 6),
        ("BOTTOMPADDING",(0, -1), (-1, -1), 6),
        ("LEFTPADDING",  (0, 0), (-1, -1), 4),
        ("RIGHTPADDING", (0, 0), (-1, -1), 4),
    ]))
    return t


def _account_snapshot_dark(agg):
    rows_data = [
        ("Maintenance margin",         _fmt_pct(agg["mm_pct"])),
        ("Net delta",                  _fmt_delta(agg["delta"])),
        ("Gamma",                      _fmt_gamma(agg["gamma"])),
        ("Vega",                       _fmt_vega(agg["vega"])),
        ("BTC index price",            _fmt_money(agg["btc_price"])),
        ("Aggregator timestamp (UTC)", _fmt_ts(agg["ts_utc"])),
    ]
    label_style = S("snap_lbl", fontSize=8, textColor=C_SUBTEXT, leading=11)
    value_style = S("snap_val", fontSize=10, textColor=C_TEXT, leading=12,
                    fontName="Helvetica-Bold", alignment=TA_RIGHT)
    half = (len(rows_data) + 1) // 2
    left = rows_data[:half]
    right = rows_data[half:]
    while len(right) < len(left):
        right.append(("", ""))
    rows = []
    for l, r in zip(left, right):
        rows.append([
            Paragraph(l[0], label_style), Paragraph(l[1], value_style),
            Paragraph(r[0], label_style), Paragraph(r[1], value_style),
        ])
    col = IMG_W / 4
    t = Table(rows, colWidths=[col * 1.1, col * 0.9, col * 1.1, col * 0.9])
    t.setStyle(TableStyle([
        ("BOX", (0, 0), (-1, -1), 0.5, C_BORDER),
        ("INNERGRID", (0, 0), (-1, -1), 0.25, C_BORDER),
        ("ROWBACKGROUNDS", (0, 0), (-1, -1), [C_PANEL, colors.HexColor("#0D1117")]),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("TOPPADDING", (0, 0), (-1, -1), 6),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
        ("LEFTPADDING", (0, 0), (-1, -1), 8),
        ("RIGHTPADDING", (0, 0), (-1, -1), 8),
    ]))
    return t


def _btc_roc_strip_dark(rocs: list[dict]):
    big_pos = S("roc_pos", fontSize=12, leading=15, alignment=TA_CENTER,
                fontName="Helvetica-Bold", textColor=C_GREEN)
    big_neg = S("roc_neg", fontSize=12, leading=15, alignment=TA_CENTER,
                fontName="Helvetica-Bold", textColor=C_RED)
    big_zero = S("roc_zero", fontSize=12, leading=15, alignment=TA_CENTER,
                 fontName="Helvetica-Bold", textColor=C_SUBTEXT)
    label_style = S("roc_lbl", fontSize=8, leading=10, alignment=TA_CENTER,
                    fontName="Helvetica-Bold", textColor=C_ACCENT)
    sub_style = S("roc_sub", fontSize=7, leading=9, alignment=TA_CENTER,
                  textColor=C_SUBTEXT)
    big_row, lbl_row, sub_row = [], [], []
    for r in rocs:
        pct = r["pct"]
        if pct is None:
            big_row.append(Paragraph("-", big_zero))
        elif pct > 0:
            big_row.append(Paragraph(f"+{pct:.2f}%", big_pos))
        elif pct < 0:
            big_row.append(Paragraph(f"{pct:.2f}%", big_neg))
        else:
            big_row.append(Paragraph("0.00%", big_zero))
        lbl_row.append(Paragraph(r["label"].upper(), label_style))
        if r["ref_price"] is not None:
            sub_row.append(Paragraph(f"vs ${r['ref_price']:,.0f}", sub_style))
        else:
            sub_row.append(Paragraph("(no ref data)", sub_style))
    n = len(rocs) or 1
    col_w = IMG_W / n
    t = Table([big_row, lbl_row, sub_row], colWidths=[col_w] * n)
    t.setStyle(TableStyle([
        ("BACKGROUND",    (0, 0), (-1, -1), C_PANEL),
        ("BOX",           (0, 0), (-1, -1), 0.5, C_BORDER),
        ("INNERGRID",     (0, 0), (-1, -1), 0.25, C_BORDER),
        ("TOPPADDING",    (0, 0), (-1, 0), 6),
        ("BOTTOMPADDING", (0, -1), (-1, -1), 6),
        ("LEFTPADDING",   (0, 0), (-1, -1), 3),
        ("RIGHTPADDING",  (0, 0), (-1, -1), 3),
    ]))
    return t


# ---------------------------------------------------------------------------
# Statistical-analysis block (σ + IQR + combined classifier)
# ---------------------------------------------------------------------------

def _compute_statistical_analysis(now: datetime) -> dict:
    """Snapshot every σ / IQR / combined signal for the daily report.

    Returns three lists of dicts ready to be rendered into tables:

      * ``sigma``    - one row per σ-rule timeframe (1h, 4h, 24h)
      * ``iqr``      - one row per IQR-rule timeframe (1h, 4h, 1d, 7d, 15d, 30d)
      * ``combined`` - one row per combined-signal timeframe (1h, 4h, 24h)
    """
    from portfolio_analysis import config
    from portfolio_analysis.combined_signal import classify_combined_signal
    from portfolio_analysis.features import market, price_change

    now_iso = _iso(now)

    # Compute returns once and reuse - the helpers each open a SQLite
    # connection per call so calling them in a loop would be wasteful.
    market_returns = market.compute_returns(now_iso)
    pc_returns = price_change.compute_returns(now_iso)

    # ── σ rows ───────────────────────────────────────────────────────────
    sigma_rows: list[dict] = []
    for tf in market.MARKET_TIMEFRAMES:
        ret = market_returns.get(tf)
        sigma = market.compute_sigma(tf, now_utc=now_iso)
        z, band = None, None
        if ret is not None and sigma is not None and sigma > 0:
            z = ret / sigma
            az = abs(z)
            if az > config.SIGMA_EXTREME_MULT:
                band = "extreme"
            elif az > config.SIGMA_CRITICAL_MULT:
                band = "critical"
            elif az > config.SIGMA_WARNING_MULT:
                band = "warning"
            else:
                band = "normal"
        sigma_rows.append({
            "tf": tf, "ret": ret, "sigma": sigma, "z": z, "band": band,
        })

    # ── IQR rows ─────────────────────────────────────────────────────────
    iqr_rows: list[dict] = []
    for tf in price_change.PRICE_CHANGE_TIMEFRAMES:
        ret = pc_returns.get(tf)
        qs = price_change.compute_quantiles(tf)
        q1 = med = q3 = pos = None
        if qs is not None:
            q1, med, q3 = qs
            if ret is not None:
                if ret > q3:
                    pos = "high"
                elif ret < q1:
                    pos = "low"
                else:
                    pos = "normal"
        iqr_rows.append({
            "tf": tf, "ret": ret, "q1": q1, "med": med, "q3": q3, "pos": pos,
        })

    # ── Combined rows ────────────────────────────────────────────────────
    combined_rows: list[dict] = []
    iqr_key_for = {"1h": "1h", "4h": "4h", "24h": "1d"}
    for tf in ("1h", "4h", "24h"):
        sr = next((r for r in sigma_rows if r["tf"] == tf), None)
        ir = next((r for r in iqr_rows if r["tf"] == iqr_key_for[tf]), None)
        if sr is None or ir is None or sr["z"] is None:
            combined_rows.append({"tf": tf, "z": None, "iqr": None, "level": None})
            continue
        iqr_pos = ir["pos"] if ir["pos"] in ("low", "normal", "high") else "normal"
        sig = classify_combined_signal(sr["z"], iqr_pos)
        combined_rows.append({
            "tf": tf, "z": sr["z"], "iqr": iqr_pos, "level": sig["level"],
        })

    return {"sigma": sigma_rows, "iqr": iqr_rows, "combined": combined_rows}


def _statistical_analysis_dark(stats: dict):
    """Render σ / IQR / combined snapshots as three stacked tables."""
    # σ band → display color (matches the alert severity palette).
    band_color = {
        "normal":   "#3FB950",
        "warning":  "#F9A825",
        "critical": "#EF6C00",
        "extreme":  "#C62828",
    }
    level_color = {
        "NORMAL": "#3FB950",
        "WEAK":   "#1565C0",
        "MEDIUM": "#F9A825",
        "STRONG": "#C62828",
    }
    iqr_color = {"normal": "#3FB950", "high": "#F9A825", "low": "#F9A825"}

    def _fmt_pct(v, *, signed=True):
        if v is None:
            return "-"
        return (f"{v:+.3f} %" if signed else f"{v:.3f} %")

    def _fmt_z(v):
        if v is None:
            return "-"
        return f"{v:+.2f}σ"

    def _color_pill(text, color_hex):
        return f"<font color='{color_hex}'><b>{text}</b></font>"

    flowables = []

    # 1) σ table
    sigma_header = [[
        Paragraph("<b>TF</b>", sCell), Paragraph("<b>Return</b>", sCell),
        Paragraph("<b>σ (rolling)</b>", sCell), Paragraph("<b>z-score</b>", sCell),
        Paragraph("<b>σ band</b>", sCell),
    ]]
    sigma_body = []
    for r in stats["sigma"]:
        band = r["band"] or "-"
        band_html = (
            _color_pill(band.upper(), band_color.get(band, "#888888"))
            if r["band"] else "-"
        )
        sigma_body.append([
            Paragraph(f"<b>{r['tf']}</b>", sCell),
            Paragraph(_fmt_pct(r["ret"]), sCell),
            Paragraph(_fmt_pct(r["sigma"], signed=False), sCell),
            Paragraph(_fmt_z(r["z"]), sCell),
            Paragraph(band_html, sCell),
        ])
    sigma_tbl = _portfolio_table_dark(
        sigma_header + sigma_body,
        col_widths=[15 * mm, 28 * mm, 28 * mm, 22 * mm, IMG_W - 93 * mm],
    )
    flowables.append(Paragraph("σ-based volatility analysis", sH2))
    flowables.append(sigma_tbl)

    # 2) IQR table
    flowables.append(Spacer(1, 4 * mm))
    iqr_header = [[
        Paragraph("<b>TF</b>", sCell), Paragraph("<b>Return</b>", sCell),
        Paragraph("<b>Q1 (25%)</b>", sCell), Paragraph("<b>Median</b>", sCell),
        Paragraph("<b>Q3 (75%)</b>", sCell), Paragraph("<b>Position</b>", sCell),
    ]]
    iqr_body = []
    for r in stats["iqr"]:
        pos = r["pos"]
        pos_label = pos.upper() if pos else "-"
        if pos:
            pos_html = _color_pill(
                {"normal": "INSIDE IQR",
                 "high":   "ABOVE Q3",
                 "low":    "BELOW Q1"}.get(pos, pos_label),
                iqr_color.get(pos, "#888888"),
            )
        else:
            pos_html = "-"
        iqr_body.append([
            Paragraph(f"<b>{r['tf']}</b>", sCell),
            Paragraph(_fmt_pct(r["ret"]), sCell),
            Paragraph(_fmt_pct(r["q1"]), sCell),
            Paragraph(_fmt_pct(r["med"]), sCell),
            Paragraph(_fmt_pct(r["q3"]), sCell),
            Paragraph(pos_html, sCell),
        ])
    iqr_tbl = _portfolio_table_dark(
        iqr_header + iqr_body,
        col_widths=[15 * mm, 24 * mm, 24 * mm, 24 * mm, 24 * mm, IMG_W - 111 * mm],
    )
    flowables.append(Paragraph("IQR / quantile analysis", sH2))
    flowables.append(iqr_tbl)

    # 3) Combined classifier
    flowables.append(Spacer(1, 4 * mm))
    combined_header = [[
        Paragraph("<b>TF</b>", sCell), Paragraph("<b>z-score</b>", sCell),
        Paragraph("<b>IQR position</b>", sCell), Paragraph("<b>Combined level</b>", sCell),
    ]]
    combined_body = []
    for r in stats["combined"]:
        level = r["level"]
        level_html = (
            _color_pill(level, level_color.get(level, "#888888")) if level else "-"
        )
        iqr_pos = r["iqr"] or "-"
        combined_body.append([
            Paragraph(f"<b>{r['tf']}</b>", sCell),
            Paragraph(_fmt_z(r["z"]), sCell),
            Paragraph(iqr_pos, sCell),
            Paragraph(level_html, sCell),
        ])
    combined_tbl = _portfolio_table_dark(
        combined_header + combined_body,
        col_widths=[15 * mm, 25 * mm, 35 * mm, IMG_W - 75 * mm],
    )
    flowables.append(Paragraph("Combined σ + IQR classifier", sH2))
    flowables.append(combined_tbl)

    return flowables


def _portfolio_table_dark(rows: list[list], col_widths=None):
    """Table styled to match the dark theme."""
    t = Table(rows, colWidths=col_widths, repeatRows=1)
    t.setStyle(TableStyle([
        ("BACKGROUND",     (0, 0), (-1, 0), colors.HexColor("#1A1A2E")),
        ("TEXTCOLOR",      (0, 0), (-1, 0), C_ACCENT),
        ("FONTNAME",       (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTSIZE",       (0, 0), (-1, 0), 8),
        ("FONTSIZE",       (0, 1), (-1, -1), 7.5),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [C_PANEL, colors.HexColor("#0D1117")]),
        ("TEXTCOLOR",      (0, 1), (-1, -1), C_TEXT),
        ("VALIGN",         (0, 0), (-1, -1), "TOP"),
        ("BOX",            (0, 0), (-1, -1), 0.5, C_BORDER),
        ("INNERGRID",      (0, 0), (-1, -1), 0.25, C_BORDER),
        ("TOPPADDING",     (0, 0), (-1, 0), 5),
        ("BOTTOMPADDING",  (0, 0), (-1, 0), 5),
        ("TOPPADDING",     (0, 1), (-1, -1), 3),
        ("BOTTOMPADDING",  (0, 1), (-1, -1), 3),
        ("LEFTPADDING",    (0, 0), (-1, -1), 5),
        ("RIGHTPADDING",   (0, 0), (-1, -1), 5),
    ]))
    return t


def _portfolio_story(window_start: datetime, window_end: datetime) -> list:
    """Build the portfolio control-plane flowables (dark theme).

    Returns a list of ReportLab flowables - caller is expected to prepend a
    PageBreak before adding them to the document story.
    """
    data = _window_data(_iso(window_start), _iso(window_end))
    agg = _latest_agg_metrics()
    sup_keys = {s["dedup_key"] for s in storage.active_suppressions()}
    open_alerts = [a for a in data.alerts if not a["resolved_at_utc"]]
    resolved_alerts = [a for a in data.alerts if a["resolved_at_utc"]]

    items: list = []
    items.append(Paragraph("★  Portfolio Control Plane", sH1))
    items.append(Paragraph(
        f"Window: {_fmt_ts(_iso(window_start))} → {_fmt_ts(_iso(window_end))} "
        f"&nbsp;·&nbsp; {WINDOW_HOURS}h coverage",
        sSmall,
    ))
    items.append(Spacer(1, 3 * mm))

    last_state = storage.latest_state()
    calm = last_state["calm_score"] if last_state else "RELAX"
    reasoning = (last_state["reasoning"] or "") if last_state else "No state recorded yet."
    items.append(_calm_badge_dark(calm, reasoning))

    items.append(Spacer(1, 4 * mm))
    items.append(_summary_strip_dark(
        alerts_total=len(data.alerts),
        alerts_open=len(open_alerts),
        alerts_resolved=len(resolved_alerts),
        suppressions_active=len(sup_keys),
        state_changes=len(_state_transitions(data.state_history)),
        overrides=len(data.overrides),
        audit=len(data.audit),
    ))

    items.append(Spacer(1, 5 * mm))
    items.append(Paragraph("Account snapshot", sH2))
    if agg is not None:
        items.append(_account_snapshot_dark(agg))
    else:
        items.append(Paragraph("Account snapshot: (hedge_engine DB unavailable)", sSmall))

    items.append(Spacer(1, 5 * mm))
    items.append(Paragraph("BTC rate-of-change", sH2))
    items.append(_btc_roc_strip_dark(_compute_btc_rocs(window_end)))

    # ── Statistical analysis (σ + IQR + combined classifier) ────────────────
    items.append(Spacer(1, 6 * mm))
    items.append(Paragraph("Statistical analysis", sH2))
    items.append(Paragraph(
        "Snapshot of the alert engine's two statistical views and their "
        "combined classification.",
        sSmall,
    ))
    items.append(Spacer(1, 3 * mm))
    items.extend(_statistical_analysis_dark(_compute_statistical_analysis(window_end)))

    # NOTE: Calm Score timeline, Alerts table, and Threshold-overrides
    # table were intentionally removed from the daily PDF - the daily
    # report is portfolio-state focused (calm badge + KPI strip +
    # account snapshot + BTC ROC). Per-event history lives in
    # ``portfolio_analysis.sqlite`` and is reachable via ``/audit`` and
    # ``/status`` from the bot, or the Streamlit page.

    return items


# ══════════════════════════════════════════════════════════════════════════════
# Market data builder - runs the full Deribit pipeline
# ══════════════════════════════════════════════════════════════════════════════
def _build_market_data(tmp_dir: Path) -> tuple[Optional[dict], dict]:
    """Authenticate + fetch + render charts. Returns (metrics, chart_paths)
    or (None, {}) on failure (missing creds, API down, etc.)."""
    cid = os.getenv("DERIBIT_CLIENT_ID", "").strip()
    csec = os.getenv("DERIBIT_CLIENT_SECRET", "").strip()
    if not cid or not csec:
        log.warning("DERIBIT_CLIENT_ID / DERIBIT_CLIENT_SECRET not set - "
                    "market sections will be skipped")
        return None, {}

    try:
        client = DeribitClient(cid, csec)
        client.authenticate()

        df_price = client.get_price_history(hours=168)
        perp = client.get_perpetual_ticker()
        df_fr = client.get_funding_rate_history(hours=168)
        df_hv = client.get_historical_volatility()
        df_dvol = client.get_dvol_history(days=30)
        df_opt = client.get_options_summary()
        df_fut = client.get_futures_summary()

        spot = float(perp["index_price"])
        now_ts = df_price["DateTime"].max()
        p_24h = df_price[df_price["DateTime"] <= now_ts - pd.Timedelta(hours=24)]["Price"].iloc[-1]
        p_7d = df_price[df_price["DateTime"] <= now_ts - pd.Timedelta(days=7)]["Price"].iloc[-1]

        fr_latest = float(perp.get("current_funding", df_fr["FundingRate"].iloc[-1]))
        fr_ann = fr_latest * 3 * 365 * 100
        fr_7d_avg_ann = df_fr["FundingRate"].mean() * 3 * 365 * 100

        oi_strike, oi_expiry, total_calls, total_puts, pcr = process_options(df_opt, spot)
        df_fp = process_futures_premium(df_fut, spot)
        df_greeks, gamma_flip = process_greeks(df_opt, spot)
        vol_expiry, vol_strike, total_opt_vol, call_vol, put_vol, vol_pcr, total_fut_vol = \
            process_volume(df_opt, df_fut)
        df_skew = process_skew(df_opt, spot=spot)

        calls_above = oi_strike[oi_strike["strike"] > spot].nlargest(1, "Calls")
        puts_below = oi_strike[oi_strike["strike"] < spot].nlargest(1, "Puts")
        call_wall = int(calls_above["strike"].iloc[0]) if len(calls_above) else 0
        call_wall_oi = calls_above["Calls"].iloc[0] if len(calls_above) else 0
        put_wall = int(puts_below["strike"].iloc[0]) if len(puts_below) else 0
        put_wall_oi = puts_below["Puts"].iloc[0] if len(puts_below) else 0
        max_call_exp = oi_expiry.loc[oi_expiry["Total_Calls"].idxmax(), "expiry"]

        metrics = dict(
            spot=spot, chg_24h=(spot / p_24h - 1) * 100, chg_7d=(spot / p_7d - 1) * 100,
            hi_7d=df_price["Price"].max(), lo_7d=df_price["Price"].min(),
            fr_latest=fr_latest, fr_ann=fr_ann, fr_7d_avg_ann=fr_7d_avg_ann,
            hv=float(df_hv["HV"].iloc[-1]), dvol=float(df_dvol["DVOL"].iloc[-1]),
            total_calls=total_calls, total_puts=total_puts, pcr=pcr,
            call_wall=call_wall, call_wall_oi=call_wall_oi,
            put_wall=put_wall, put_wall_oi=put_wall_oi,
            max_call_exp=max_call_exp, contango=df_fp["premium"].mean() > 0,
            oi_total_usd=(total_calls + total_puts) * spot / 1e9,
            gamma_flip=int(gamma_flip) if gamma_flip else None,
            total_opt_vol=total_opt_vol, call_vol=call_vol, put_vol=put_vol,
            vol_pcr=vol_pcr, total_fut_vol=total_fut_vol, df_skew=df_skew,
        )

        cp = {
            "price":           str(tmp_dir / "price.png"),
            "funding":         str(tmp_dir / "funding.png"),
            "hv":              str(tmp_dir / "hv.png"),
            "dvol":            str(tmp_dir / "dvol.png"),
            "oi_expiry":       str(tmp_dir / "oi_expiry.png"),
            "oi_strike":       str(tmp_dir / "oi_strike.png"),
            "futures_premium": str(tmp_dir / "futures_premium.png"),
            "iv_smile":        str(tmp_dir / "iv_smile.png"),
            "greeks":          str(tmp_dir / "greeks.png"),
            "volume":          str(tmp_dir / "volume.png"),
            "skew":            str(tmp_dir / "skew.png"),
        }
        make_price_chart(df_price, cp["price"])
        make_funding_chart(df_fr, cp["funding"])
        make_hv_chart(df_hv, cp["hv"])
        make_dvol_chart(df_dvol, cp["dvol"])
        make_oi_expiry_chart(oi_expiry, cp["oi_expiry"])
        make_oi_strike_chart(oi_strike, spot, cp["oi_strike"])
        make_futures_premium_chart(df_fp, cp["futures_premium"])
        make_iv_smile_chart(df_opt, spot, cp["iv_smile"])
        make_gamma_chart(df_greeks, spot, gamma_flip, cp["greeks"])
        make_volume_chart(vol_expiry, vol_strike, cp["volume"])
        make_skew_chart(df_skew, cp["skew"])
        return metrics, cp
    except Exception:
        log.exception("Deribit market-data fetch failed; emitting portfolio-only PDF")
        return None, {}


# ══════════════════════════════════════════════════════════════════════════════
# Combined PDF builder
# ══════════════════════════════════════════════════════════════════════════════
def _build_combined_pdf(metrics: dict, chart_paths: dict, out_path: str,
                        portfolio_story_extra: list, report_date: str):
    m = metrics
    story: list = []

    # ── Cover & KPI ─────────────────────────────────────────────────────────
    story += [Spacer(1, 22 * mm), Paragraph("BTC Options &amp; Futures", sTitle),
              Paragraph("Daily Market Intelligence Report", sSub), Spacer(1, 4 * mm),
              Paragraph(report_date, sDate), Spacer(1, 6 * mm), divider(), Spacer(1, 3 * mm)]

    chg_pos = m["chg_24h"] >= 0
    kpi = Table([[
        metric_card("BTC/USD Price",  f"${m['spot']:,.0f}",        f"{'▲' if chg_pos else '▼'} {m['chg_24h']:+.2f}% (24h)", chg_pos),
        metric_card("7-Day Return",   f"{m['chg_7d']:+.1f}%",      f"${m['lo_7d']:,.0f}–${m['hi_7d']:,.0f}", m["chg_7d"] >= 0),
        metric_card("Funding (8h)",   f"{m['fr_latest']*100:.4f}%", f"Ann. {m['fr_ann']:.2f}%", m["fr_latest"] >= 0),
        metric_card("Open Interest",  f"${m['oi_total_usd']:.2f}B", f"P/C {m['pcr']:.3f}", m["pcr"] < 1),
        metric_card("HV / DVOL",      f"{m['hv']:.1f}% / {m['dvol']:.0f}", f"Vol premium {m['dvol']-m['hv']:+.1f}pp", True),
    ]], colWidths=[38 * mm] * 5)
    kpi.setStyle(TableStyle([("ALIGN", (0, 0), (-1, -1), "CENTER"),
                             ("LEFTPADDING", (0, 0), (-1, -1), 2), ("RIGHTPADDING", (0, 0), (-1, -1), 2)]))
    story += [kpi, Spacer(1, 6 * mm)]

    # ── Outlook ─────────────────────────────────────────────────────────────
    story += [Paragraph("★  Market Outlook &amp; Interpretation", sH1),
              Paragraph(f"Live data as of {datetime.now(timezone.utc).strftime('%d %b %Y %H:%M UTC')}", sSmall),
              Spacer(1, 2 * mm)]

    bias = "CAUTIOUSLY BULLISH" if m["chg_7d"] > 0 else "CAUTIOUSLY BEARISH"
    brd = C_GREEN if m["chg_7d"] > 0 else C_RED
    gf_str = f"${m['gamma_flip']:,}" if m.get("gamma_flip") else "N/A"
    ts_str = "Contango term structure supports bull thesis." if m["contango"] else "Backwardation - near-term caution."
    story.append(outlook_box(
        f"NEAR-TERM BIAS: {bias}  |  CALL WALL: ${m['call_wall']:,}  |  PUT WALL: ${m['put_wall']:,}",
        f"BTC {m['chg_7d']:+.1f}% (7d). Funding {m['fr_ann']:.2f}% ann. OI ${m['oi_total_usd']:.2f}B. "
        f"P/C {m['pcr']:.3f}. Gamma flip {gf_str}. {ts_str}",
        border=brd))
    story.append(Spacer(1, 4 * mm))

    story.append(Paragraph("Price &amp; Momentum", sH2))
    story.append(Paragraph(
        f"BTC at <b>${m['spot']:,.2f}</b>. 24h: <b>{m['chg_24h']:+.2f}%</b>. 7d: <b>{m['chg_7d']:+.1f}%</b>. "
        f"7-day range ${m['lo_7d']:,.0f}–${m['hi_7d']:,.0f} "
        f"({'above' if m['spot'] > (m['hi_7d']+m['lo_7d'])/2 else 'below'} the midpoint - "
        f"{'bullish structure' if m['spot'] > (m['hi_7d']+m['lo_7d'])/2 else 'softening bias'}).", sBody))

    story.append(Paragraph("Funding &amp; Leverage", sH2))
    fr_desc = f"Funding at <b>{m['fr_ann']:.2f}% annualised</b>. "
    fr_desc += ("Extreme - overleveraged longs, squeeze risk. " if m["fr_ann"] > 50 else
                "Moderate positive - bulls paying, watch for squeeze. " if m["fr_ann"] > 10 else
                "Near neutral - healthy base for next move. " if abs(m["fr_ann"]) <= 5 else
                "Negative - shorts paying longs, contrarian bullish signal. ")
    story.append(Paragraph(fr_desc, sBody))

    story.append(Paragraph("Greeks &amp; Dealer Positioning", sH2))
    gf = m.get("gamma_flip")
    story.append(Paragraph(
        f"Dealer gamma flips from negative to positive at <b>${gf:,}</b>. " if gf else "Gamma flip not computed. ",
        sBody))
    story.append(Paragraph(
        f"Above the gamma flip, dealers are <b>long gamma</b> - they buy dips and sell rips, dampening moves. "
        f"Below it, dealers are <b>short gamma</b> - they chase price, amplifying moves. "
        f"Current spot {'is above' if gf and m['spot'] > gf else 'is below'} the gamma flip "
        f"({'stabilising' if gf and m['spot'] > gf else 'volatile'} regime).", sBody))

    story.append(Paragraph("Skew &amp; Sentiment", sH2))
    story.append(Paragraph(
        f"24h volume put/call ratio: <b>{m['vol_pcr']:.3f}</b> "
        f"({'bullish flow - call-dominated' if m['vol_pcr'] < 0.8 else 'elevated put buying - hedging demand'}). "
        f"Vol risk premium (DVOL–HV): <b>{m['dvol']-m['hv']:+.1f}pp</b> "
        f"({'fairly priced' if abs(m['dvol']-m['hv']) <= 3 else 'options rich vs. realised' if m['dvol'] > m['hv']+3 else 'options cheap vs. realised'}). "
        f"Term structure: <b>{'Contango' if m['contango'] else 'Backwardation'}</b> - "
        f"{'bullish consensus, healthy carry' if m['contango'] else 'near-term selling pressure'}.", sBody))

    # ── Signal table ────────────────────────────────────────────────────────
    story.append(Paragraph("Signal Summary", sH2))
    vol_prem = m["dvol"] - m["hv"]
    rows = [
        ["Signal", "Reading", "Implication"],
        ["Price (24h)",     f"{m['chg_24h']:+.2f}%",   "Bullish" if m["chg_24h"] > 0.5 else ("Bearish" if m["chg_24h"] < -0.5 else "Neutral")],
        ["Price (7d)",      f"{m['chg_7d']:+.1f}%",    "Bullish" if m["chg_7d"] > 3 else ("Bearish" if m["chg_7d"] < -3 else "Neutral")],
        ["Funding",         f"{m['fr_ann']:.2f}% ann.", "Extreme ⚠" if m["fr_ann"] > 50 else ("Bullish" if m["fr_ann"] > 0 else "Neutral/Bearish")],
        ["OI P/C Ratio",    f"{m['pcr']:.3f}",          "Bullish" if m["pcr"] < 0.7 else ("Neutral" if m["pcr"] < 1.0 else "Bearish")],
        ["Volume P/C",      f"{m['vol_pcr']:.3f}",      "Bullish" if m["vol_pcr"] < 0.7 else ("Neutral" if m["vol_pcr"] < 1.0 else "Bearish")],
        ["HV vs DVOL",      f"{m['hv']:.1f}% / {m['dvol']:.1f}", "IV Fair" if abs(vol_prem) <= 3 else ("IV Rich" if vol_prem > 3 else "IV Cheap")],
        ["Term Structure",  "Contango" if m["contango"] else "Backwardation", "Bullish" if m["contango"] else "Bearish"],
        ["Call Wall",       f"${m['call_wall']:,} ({m['call_wall_oi']:,.0f} BTC)", "Primary Resistance"],
        ["Put Wall",        f"${m['put_wall']:,} ({m['put_wall_oi']:,.0f} BTC)",   "Primary Support"],
        ["Gamma Flip",      f"${m['gamma_flip']:,}" if m.get("gamma_flip") else "N/A",
                            ("Stabilising" if m.get("gamma_flip") and m["gamma_flip"] > m["spot"] else "Volatile Regime")],
    ]

    def sig_text_color(lbl):
        return {
            "Bullish": C_GREEN, "Bearish": C_RED, "Neutral": C_SUBTEXT,
            "IV Fair": C_SUBTEXT, "IV Rich": C_RED, "IV Cheap": C_GREEN,
            "Extreme ⚠": C_RED, "Contango": C_GREEN, "Backwardation": C_RED,
            "Primary Resistance": C_RED, "Primary Support": C_GREEN,
            "Stabilising": C_GREEN, "Volatile Regime": C_YELLOW,
            "Neutral/Bearish": C_SUBTEXT,
        }.get(lbl, C_TEXT)

    st = Table(rows, colWidths=[40 * mm, 52 * mm, 75 * mm])
    ts_style = [
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1A1A2E")),
        ("TEXTCOLOR", (0, 0), (-1, 0), C_ACCENT), ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, -1), 8),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [C_PANEL, colors.HexColor("#0D1117")]),
        ("TEXTCOLOR", (0, 1), (-1, -1), C_TEXT),
        ("FONTNAME", (0, 1), (0, -1), "Helvetica-Bold"), ("TEXTCOLOR", (0, 1), (0, -1), C_SUBTEXT),
        ("ALIGN", (0, 0), (-1, -1), "LEFT"), ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("TOPPADDING", (0, 0), (-1, -1), 4), ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
        ("LEFTPADDING", (0, 0), (-1, -1), 6), ("RIGHTPADDING", (0, 0), (-1, -1), 6),
        ("BOX", (0, 0), (-1, -1), 0.5, C_BORDER), ("INNERGRID", (0, 0), (-1, -1), 0.3, C_BORDER),
    ]
    for i, row in enumerate(rows[1:], 1):
        ts_style.append(("TEXTCOLOR", (2, i), (2, i), sig_text_color(row[2])))
    st.setStyle(TableStyle(ts_style))
    story += [st, Spacer(1, 3 * mm), divider()]

    # ── Data chart pages ────────────────────────────────────────────────────
    story.append(PageBreak())
    story += chart_section("1 · BTC/USD Price Index",    "Hourly - last 7 days",                                    chart_paths.get("price"))
    story += chart_section("2 · Perpetual Funding Rate", "Annualised 8h rate - last 7 days",                        chart_paths.get("funding"))
    story += chart_section("3 · Futures Term Structure", "USD premium above spot (contango/backwardation)",          chart_paths.get("futures_premium"))
    story += chart_section("4 · OI by Expiration",       f"Calls {m['total_calls']:,.0f} | Puts {m['total_puts']:,.0f} | P/C {m['pcr']:.3f}", chart_paths.get("oi_expiry"))

    story.append(PageBreak())
    story += chart_section("5 · OI by Strike",            f"Call wall ${m['call_wall']:,} | Put wall ${m['put_wall']:,}", chart_paths.get("oi_strike"))
    story += chart_section("6 · Implied Volatility Smile", f"ATM IV vs HV {m['hv']:.1f}% | DVOL {m['dvol']:.1f}",        chart_paths.get("iv_smile"))
    story += chart_section("7 · Historical Volatility",    "30-day rolling realised vol - last 14 days",                  chart_paths.get("hv"))
    story += chart_section("8 · DVOL Index",               "Model-free implied vol index - 30 days",                      chart_paths.get("dvol"))

    story.append(PageBreak())
    story += chart_section("9 · Greeks - Dealer Gamma &amp; Delta Exposure",
                           f"Gamma flip at ${m['gamma_flip']:,} | Above=stabilising, Below=volatile" if m.get("gamma_flip") else "Dealer Greeks by Strike",
                           chart_paths.get("greeks"), h=110 * mm)
    story += chart_section("10 · Volume &amp; Trades",
                           f"24h opt vol {m['total_opt_vol']:,.0f} BTC | Volume P/C {m['vol_pcr']:.3f} | Futures {m['total_fut_vol']:,.0f} BTC",
                           chart_paths.get("volume"), h=110 * mm)

    story.append(PageBreak())
    story += chart_section("11 · Skew Analysis - 25-Delta Risk Reversal &amp; Butterfly",
                           "Negative RR = put skew (fear) | Fly = vol premium for wings vs ATM",
                           chart_paths.get("skew"), h=110 * mm)

    # ── Cheat sheet ─────────────────────────────────────────────────────────
    story.append(PageBreak())
    story += build_summary_page(m, m.get("df_skew"))

    # ── Portfolio control plane appended ────────────────────────────────────
    if portfolio_story_extra:
        story.append(PageBreak())
        story += portfolio_story_extra

    doc = SimpleDocTemplate(out_path, pagesize=A4,
                            leftMargin=MARGIN, rightMargin=MARGIN,
                            topMargin=18 * mm, bottomMargin=14 * mm,
                            title=f"Portfolio Daily Report - {report_date}")
    on_page = _page_furniture(report_date)
    doc.build(story, onFirstPage=on_page, onLaterPages=on_page)


def _build_portfolio_only_pdf(out_path: str, portfolio_story_extra: list,
                              window_end: datetime, report_date: str) -> None:
    """Fallback PDF when Deribit data is unavailable. Keeps proof-of-life
    semantics - the report still ships every day."""
    story: list = [
        Spacer(1, 22 * mm), Paragraph("Portfolio Co-Pilot", sTitle),
        Paragraph("Daily Report - Portfolio Control Plane", sSub),
        Spacer(1, 4 * mm), Paragraph(report_date, sDate),
        Spacer(1, 6 * mm), divider(), Spacer(1, 3 * mm),
        Paragraph("Market data unavailable", sH1),
        Paragraph(
            "DERIBIT_CLIENT_ID / DERIBIT_CLIENT_SECRET not set, or the Deribit API "
            "could not be reached. The portfolio control-plane sections still follow "
            "below; market intelligence will resume on the next successful run.", sBody),
        Spacer(1, 4 * mm), divider(), PageBreak(),
    ]
    story += portfolio_story_extra
    doc = SimpleDocTemplate(out_path, pagesize=A4,
                            leftMargin=MARGIN, rightMargin=MARGIN,
                            topMargin=18 * mm, bottomMargin=14 * mm,
                            title=f"Portfolio Daily Report - {report_date}")
    on_page = _page_furniture(report_date)
    doc.build(story, onFirstPage=on_page, onLaterPages=on_page)


# ══════════════════════════════════════════════════════════════════════════════
# Public orchestrator
# ══════════════════════════════════════════════════════════════════════════════
def build_report(
    *,
    window_start: Optional[datetime] = None,
    window_end: Optional[datetime] = None,
    out_path: Optional[Path] = None,
) -> Path:
    """Build the combined daily PDF and return its path."""
    end = window_end or _now()
    start = window_start or (end - timedelta(hours=WINDOW_HOURS))
    if out_path is None:
        out_path = config.REPORT_DIR / f"portfolio_{end.strftime('%Y%m%d-%H%M%S')}.pdf"
    out_path.parent.mkdir(parents=True, exist_ok=True)

    tmp_charts = out_path.parent / "charts"
    tmp_charts.mkdir(exist_ok=True)

    metrics, chart_paths = _build_market_data(tmp_charts)
    portfolio_extra = _portfolio_story(start, end)
    report_date = end.strftime("%A, %d %B %Y")

    if metrics is None:
        _build_portfolio_only_pdf(str(out_path), portfolio_extra,
                                  window_end=end, report_date=report_date)
    else:
        _build_combined_pdf(metrics, chart_paths, str(out_path),
                            portfolio_story_extra=portfolio_extra,
                            report_date=report_date)
    log.info("built daily report path=%s window=[%s,%s] market=%s",
             out_path, _iso(start), _iso(end), metrics is not None)
    return out_path


# ---------------------------------------------------------------------------
# Send + DB record
# ---------------------------------------------------------------------------
def send_report(
    pdf_path: Path,
    *,
    caption: Optional[str] = None,
    chat_ids: Optional[list] = None,
    window_start: Optional[datetime] = None,
    window_end: Optional[datetime] = None,
) -> dict:
    """Send the PDF + record a ``report_runs`` row."""
    end = window_end or _now()
    start = window_start or (end - timedelta(hours=WINDOW_HOURS))
    sent = _notifier.send_document(str(pdf_path), caption=caption, chat_ids=chat_ids)
    rid = storage.insert_report_run(
        ts_utc=_iso(end),
        window_start_utc=_iso(start),
        window_end_utc=_iso(end),
        pdf_path=str(pdf_path),
        sent_chat_ids=[int(c) for c in sent if str(c).lstrip("-").isdigit()] or [],
    )
    return {
        "id": rid, "pdf_path": str(pdf_path), "sent_chat_ids": sent,
        "window_start_utc": _iso(start), "window_end_utc": _iso(end),
    }


# ---------------------------------------------------------------------------
# Per-day report retention - keep one PDF per calendar day
# ---------------------------------------------------------------------------

# Filename pattern produced by ``build_report`` -  portfolio_YYYYMMDD-HHMMSS.pdf
_REPORT_FILENAME_RE = re.compile(
    r"^portfolio_(?P<date>\d{8})-(?P<hms>\d{6})\.pdf$"
)


def cleanup_duplicate_reports(
    *,
    report_dir: Optional[Path] = None,
    keep_path: Optional[Path] = None,
) -> dict:
    """Keep only the most recent PDF per calendar day in ``report_dir``.

    Each on-demand ``/report`` and every fired daily run drops a
    ``portfolio_YYYYMMDD-HHMMSS.pdf`` into the reports directory. Over
    time this accumulates: e.g. five hand-built reports plus one daily
    fire on the same day = six PDFs for that day. This helper groups by
    the calendar-date prefix and deletes everything except the newest
    file per day.

    Parameters:
      * ``report_dir`` - defaults to ``config.REPORT_DIR``.
      * ``keep_path``  - if given, that exact file is always kept even
        if it isn't the newest by mtime. Used by the daily worker to
        guarantee the freshly-sent PDF is the one that survives even
        if the filesystem mtime ordering is funky.

    Returns ``{"groups_scanned", "kept", "deleted", "errors"}``.
    """
    target_dir = report_dir if report_dir is not None else config.REPORT_DIR
    summary: dict = {
        "groups_scanned": 0,
        "kept": [],
        "deleted": [],
        "errors": [],
    }
    if not target_dir.exists():
        return summary

    keep_resolved: Optional[Path] = None
    if keep_path is not None:
        try:
            keep_resolved = Path(keep_path).resolve()
        except OSError:
            keep_resolved = None

    # Group every matching PDF by its calendar-date prefix.
    by_date: dict[str, list[Path]] = {}
    for entry in target_dir.iterdir():
        if not entry.is_file():
            continue
        m = _REPORT_FILENAME_RE.match(entry.name)
        if not m:
            continue   # not one of our reports - never touch foreign files
        by_date.setdefault(m.group("date"), []).append(entry)

    summary["groups_scanned"] = len(by_date)

    for date_str, paths in by_date.items():
        if len(paths) <= 1:
            # Single file for this day - nothing to delete.
            continue

        # Pick the survivor:
        #   1. prefer the explicit keep_path if it's in this group
        #   2. otherwise the file with the most recent mtime
        survivor: Optional[Path] = None
        if keep_resolved is not None:
            for p in paths:
                try:
                    if p.resolve() == keep_resolved:
                        survivor = p
                        break
                except OSError:
                    continue
        if survivor is None:
            try:
                survivor = max(paths, key=lambda p: p.stat().st_mtime)
            except OSError as exc:
                summary["errors"].append({"date": date_str, "error": str(exc)})
                continue

        for p in paths:
            if p == survivor:
                continue
            try:
                p.unlink()
                summary["deleted"].append(str(p))
            except OSError as exc:
                summary["errors"].append({"path": str(p), "error": str(exc)})
        summary["kept"].append(str(survivor))

    if summary["deleted"] or summary["errors"]:
        log.info(
            "report cleanup: scanned %d day(s); kept %d, deleted %d, errors %d",
            summary["groups_scanned"], len(summary["kept"]),
            len(summary["deleted"]), len(summary["errors"]),
        )
    return summary


def _send_with_retry(pdf_path: Path, caption: str, **kw) -> dict:
    """Try send_report once; on no-targets-sent (and non-DRY_RUN), retry once."""
    result = send_report(pdf_path, caption=caption, **kw)
    if _notifier.is_dry_run() or result["sent_chat_ids"]:
        return result
    log.warning("send_report had zero successful chats; retrying once after %ss", RETRY_DELAY_S)
    time.sleep(RETRY_DELAY_S)
    return send_report(pdf_path, caption=caption, **kw)


# ---------------------------------------------------------------------------
# Worker
# ---------------------------------------------------------------------------
class DailyReportWorker:
    """Daemon thread that fires once per day at the configured UTC time."""

    def __init__(
        self,
        *,
        interval_s: float = TICK_INTERVAL_S,
        stop_event: Optional[threading.Event] = None,
    ) -> None:
        self.interval_s = float(interval_s)
        self.stop_event = stop_event or threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._next_fire: Optional[datetime] = None

    def start(self) -> None:
        if self._thread is not None and self._thread.is_alive():
            return
        self._thread = threading.Thread(
            target=self._loop, name="portfolio-analysis-report", daemon=True,
        )
        self._thread.start()
        log.info("DailyReportWorker started (interval=%.1fs)", self.interval_s)

    def stop(self, timeout: float = 5.0) -> None:
        self.stop_event.set()
        if self._thread is not None:
            self._thread.join(timeout=timeout)
            log.info("DailyReportWorker stopped")

    def _loop(self) -> None:
        storage.init_db()
        self._catch_up_if_needed()
        self._next_fire = next_fire_time()
        log.info("DailyReportWorker first fire scheduled %s", _iso(self._next_fire))
        while not self.stop_event.is_set():
            try:
                self._tick()
            except Exception:
                log.exception("DailyReportWorker tick failed; continuing")
            slept = 0.0
            while slept < self.interval_s and not self.stop_event.is_set():
                step = min(0.5, self.interval_s - slept)
                time.sleep(step)
                slept += step

    def _catch_up_if_needed(self) -> None:
        now = _now()
        last_expected = next_fire_time(after=now) - timedelta(days=1)
        if (now - last_expected).total_seconds() < 0:
            return
        last_run = storage.latest_report_run()
        last_run_dt = None
        if last_run is not None:
            from portfolio_analysis.features.market import _parse_iso as _p
            last_run_dt = _p(last_run["ts_utc"])
        if last_run_dt is None or last_run_dt < last_expected:
            log.info(
                "DailyReportWorker catching up missed window (last_run=%s, expected=%s)",
                last_run_dt, _iso(last_expected),
            )
            self._fire(window_end=now)

    def _tick(self) -> None:
        if self._next_fire is None:
            self._next_fire = next_fire_time()
            return
        if _now() < self._next_fire:
            return
        fire_at = self._next_fire
        self._next_fire = self._next_fire + timedelta(days=1)
        self._fire(window_end=fire_at)

    def _fire(self, *, window_end: datetime) -> None:
        try:
            pdf_path = build_report(window_end=window_end)
        except Exception:
            log.exception("build_report failed")
            return
        caption = f"📄 Portfolio daily report - {window_end.strftime('%Y-%m-%d')}"
        try:
            _send_with_retry(pdf_path, caption, window_end=window_end)
        except Exception:
            log.exception("send_report failed permanently")

        # After sending, sweep the reports directory: keep only the most
        # recent PDF per calendar day. This collapses any /report-built
        # duplicates from earlier in the day plus the freshly-fired one
        # into a single file per day. ``keep_path`` ensures the PDF we
        # just sent survives, even if mtime ordering is odd.
        try:
            cleanup_duplicate_reports(keep_path=pdf_path)
        except Exception:
            log.exception("cleanup_duplicate_reports failed (non-fatal)")


# ---------------------------------------------------------------------------
# Direct invocation: build a report now (no worker, no Telegram send)
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    storage.init_db()
    path = build_report()
    print(f"Report built: {path}")
