# portfolio_analysis

Portfolio Co-Pilot - alert engine, Telegram control bot, and daily PDF report.

See [docs/plan.md](docs/plan.md) for the design and
[docs/implementation_plan_phase1.md](docs/implementation_plan_phase1.md) for the
build steps.

---

## What's in this package

| Module | Role |
|---|---|
| [`report_daily.py`](report_daily.py) | **Combined daily PDF** - Deribit market intelligence + portfolio control plane. See [Daily report](#daily-report) below. |
| [`scheduler.py`](scheduler.py) | Boots three daemon threads: `AlertWorker`, `HeartbeatWorker`, `DailyReportWorker`. |
| [`worker.py`](worker.py) | `AlertWorker` - evaluates rules every 30 s and emits Telegram alerts. |
| [`heartbeat.py`](heartbeat.py) | Cadence-driven Telegram digest. |
| [`bot/`](bot/) | Long-poll Telegram bot - `/set`, `/stop`, `/resume`, `/status`, `/thresholds`, `/audit`, `/report`. |
| [`notifier.py`](notifier.py) | Telegram `sendMessage` / `sendDocument` wrapper. Honours `DRY_RUN=1`. |
| [`storage.py`](storage.py) | SQLite schema (`alerts`, `state_history`, `threshold_overrides`, `suppressions`, `audit_log`, `report_runs`). |
| [`state.py`](state.py) | `CalmState` enum + classifier (RELAX → URGENT_ACTION). |
| [`thresholds.py`](thresholds.py) | Threshold get / override / list with 60 s cache. |
| [`config.py`](config.py) | Default thresholds, schedule constants, paths. |
| [`features/`](features/) | Market returns, price-change quantiles, per-position DTE / distance-to-strike. |
| [`rules/`](rules/) | The 5 alert rules (margin, delta drift, DTE, σ-move, BTC ROC). |
| [`replay.py`](replay.py) | Replay historical ticks against the current rule set (for tuning). |
| [`daily_report_example.py`](daily_report_example.py) | Reference design for the market-data PDF. **Not imported** - `report_daily.py` carries its own copy of the logic. |

---

## Daily report

`report_daily.py` builds one combined PDF per day and ships it via Telegram.

### Sections

```
1.  BTC/USD Price Index             7.  Historical Volatility
2.  Perpetual Funding Rate          8.  DVOL Index
3.  Futures Term Structure          9.  Greeks - Dealer Gamma & Net Delta
4.  Open Interest by Expiration    10.  Volume & Trades
5.  Open Interest by Strike        11.  25-Delta Skew (RR & Fly)
6.  Implied Volatility Smile       12.  Daily Cheat Sheet

13.  Portfolio Control Plane
       · Calm Score badge + reasoning
       · Alert / state-change / override / audit summary strip
       · Account snapshot (mm_pct, delta, gamma, vega, btc_price)
       · BTC rate-of-change (1h / 4h / 24h / 72h / 7d / 1m)
       · Calm Score timeline (state transitions in window)
       · Alerts table (ts, rule, severity, dedup, status, user, message)
       · Threshold overrides table
```

Sections 1–12 use **live Deribit REST data**; section 13 reads
`portfolio_analysis.sqlite` + `hedge_engine.sqlite` (read-only).

### Graceful fallback

If `DERIBIT_CLIENT_ID` / `DERIBIT_CLIENT_SECRET` are missing or the API is
unreachable, the market sections are skipped and a portfolio-only PDF is
emitted with a "Market data unavailable" cover note. The daily PDF ships
**every day** regardless - that's the proof-of-life contract.

### Environment

| Variable | Required | Purpose |
|---|---|---|
| `DERIBIT_CLIENT_ID` | for sections 1–12 | Deribit OAuth client id |
| `DERIBIT_CLIENT_SECRET` | for sections 1–12 | Deribit OAuth client secret |
| `DERIBIT_BASE_URL` | optional | Override (default `https://www.deribit.com`) |
| `TELEGRAM_PORTFOLIO_BOT_TOKEN` | for sending | Bot token |
| `TELEGRAM_CHAT_IDS` | for sending | JSON dict, e.g. `{"andres":"111","remo":"222"}` |
| `DRY_RUN` | optional | `1` = log instead of posting to Telegram |
| `REPORT_DIR` | optional | PDF output directory (default `data/reports/`) |
| `REPORT_DAILY_UTC_HOUR` | optional | Schedule hour (default `0`) |
| `REPORT_DAILY_UTC_MINUTE` | optional | Schedule minute (default `5`) |

`.env` at repo root is auto-loaded by `portfolio_analysis/__init__.py`.

---

## Commands

All commands assume the working directory is the repo root
(`Digital-Ocean-Server/`).

### Build a report on demand

Builds the PDF using the configured `REPORT_DIR` and prints the path.
Does **not** send to Telegram.

```bash
python -m portfolio_analysis.report_daily
```

What it does, step by step:
1. `storage.init_db()` - ensures the SQLite schema exists.
2. Reads `DERIBIT_CLIENT_ID/SECRET` from env. If both present, authenticates
   and pulls eight Deribit endpoints (price history, perp ticker, funding
   history, HV, DVOL, options book, futures book, index price).
3. Computes Black-Scholes greeks for any options row missing them, then
   derives dealer net gamma + delta and the gamma-flip strike.
4. Renders 11 dark-theme PNG charts to `<REPORT_DIR>/charts/`.
5. Reads the last 24 h from `portfolio_analysis.sqlite` (alerts, state
   transitions, threshold overrides, audit log) and the latest row from
   `hedge_engine.sqlite::hedge_engine_aggregated_metrics`.
6. Assembles a single A4 PDF named `portfolio_<YYYYMMDD-HHMMSS>.pdf` and
   writes it to `REPORT_DIR`.

### Run the scheduler (production loop)

Boots all three workers and stays running.

```bash
python -m portfolio_analysis.scheduler
```

`DailyReportWorker` fires once per day at `REPORT_DAILY_UTC_HOUR:MINUTE` and
catches up a single missed window on startup if the latest `report_runs`
row is older than the most recent expected fire time.

### Health smoke test (12 s)

Boots the scheduler, prints a JSON status payload, exits.

```bash
python -m portfolio_analysis.scheduler --health
```

Verifies all three workers start cleanly. Prints `calm_score`,
`active_alerts`, `last_report_ts`, etc.

### Run the Telegram bot (separate process)

```bash
python -m portfolio_analysis.bot.server
```

Long-polls `getUpdates`. Only IDs in `AUTHORIZED_TELEGRAM_USER_IDS` may
issue commands. Available commands inside Telegram:

| Command | Effect |
|---|---|
| `/status` | Current Calm Score + active alert count. |
| `/thresholds` | Active threshold values + any overrides. |
| `/set <name> <value> <duration>` | Override a threshold (logged in `audit_log`). |
| `/stop <dedup_key> <duration>` | Suppress alerts matching a dedup key. |
| `/resume <dedup_key>` | Lift a suppression. |
| `/audit` | Last 20 audit-log entries. |
| `/report` | Build a fresh daily PDF and send it back to the requesting chat. |

### Build + send via DRY_RUN

Sends are logged instead of posted - useful for a smoke check before flipping
to production.

```bash
DRY_RUN=1 python -c "from portfolio_analysis import storage; storage.init_db(); from portfolio_analysis.report_daily import build_report, send_report; p=build_report(); print(send_report(p, caption='dry-run test'))"
```

### Replay historical alerts

Replays ticks from a backfill window against the current rule set. Useful
for tuning thresholds without affecting the live `alerts` table.

```bash
python -m portfolio_analysis.replay --from 2026-04-01 --to 2026-04-15
```

### Run the test suite

```bash
python -m pytest portfolio_analysis/tests/ -q
```

`test_report_daily.py` autouse-patches `_build_market_data` to return
`(None, {})`, so tests exercise the portfolio-only fallback path and never
hit the Deribit network.

---

## File outputs

| Path | What |
|---|---|
| `data/reports/portfolio_<YYYYMMDD-HHMMSS>.pdf` | Daily PDF |
| `data/reports/charts/*.png` | 11 dark-theme chart PNGs (re-generated on each run) |
| `data/portfolio_analysis.sqlite` | Alerts, state history, overrides, audit, suppressions, report_runs |

---

## Phase status

Phase 1 (storage / thresholds / features / rules / state / `AlertWorker` /
`notifier` / bot / heartbeat) and Phase 10 (daily report) are implemented.
Phase 14 is the live deploy step - see [docs/implementation_plan_phase1.md](docs/implementation_plan_phase1.md).
