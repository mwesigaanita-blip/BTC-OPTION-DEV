"""Storage layer for the portfolio_analysis package.

Schema lives in ``data/portfolio_analysis.sqlite`` (path resolved via
``shared.db_paths.PORTFOLIO_ANALYSIS_DB``). Mirrors the WAL + thread-local
connection + idempotent-writer pattern of ``realtime/storage.py``.

Tables:

* ``alerts``               - one row per alert event emitted by the rules engine
* ``state_history``        - Calm Score timeline
* ``threshold_overrides``  - dynamic threshold values with expiry
* ``suppressions``         - per-alert "user is handling this" flags
* ``audit_log``            - every authorized user action via the bot
* ``returns_history``      - rolling per-timeframe return buffer (σ + quantiles)
* ``report_runs``          - daily-PDF send history (Section 6c)
"""
from __future__ import annotations

import json
import sqlite3
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Optional

from shared.db_paths import PORTFOLIO_ANALYSIS_DB

__all__ = [
    "PORTFOLIO_ANALYSIS_DB",
    "init_db",
    "get_conn",
    "utc_now_iso",
    # writers
    "insert_alert",
    "resolve_alert",
    "insert_state",
    "insert_override",
    "insert_suppression",
    "clear_suppression",
    "insert_audit",
    "insert_return",
    "insert_report_run",
    "insert_vol_tick",
    "insert_vol_ticks_bulk",
    "count_vol_ticks",
    "read_vol_ticks_bucketed",
    # readers
    "latest_state",
    "unresolved_alerts",
    "active_suppressions",
    "active_overrides_for",
    "recent_audit",
    "returns_for",
    "latest_report_run",
]

# ---------------------------------------------------------------------------
# Schema
# ---------------------------------------------------------------------------

_SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS alerts (
    id INTEGER PRIMARY KEY,
    ts_utc TEXT NOT NULL,
    rule TEXT NOT NULL,
    severity TEXT NOT NULL,
    dedup_key TEXT NOT NULL,
    cited_features TEXT NOT NULL,
    feature_values TEXT NOT NULL,
    message TEXT,
    notified_at_utc TEXT,
    resolved_at_utc TEXT,
    -- Combined-signal level (STRONG/MEDIUM/WEAK) when the row was
    -- emitted by the COMBINED_SIGNAL rule. NULL for every other rule.
    combined_level TEXT,
    UNIQUE(dedup_key, ts_utc)
);
CREATE INDEX IF NOT EXISTS idx_alerts_ts ON alerts(ts_utc);
CREATE INDEX IF NOT EXISTS idx_alerts_dedup ON alerts(dedup_key);
CREATE INDEX IF NOT EXISTS idx_alerts_unresolved
    ON alerts(resolved_at_utc) WHERE resolved_at_utc IS NULL;

CREATE TABLE IF NOT EXISTS state_history (
    ts_utc TEXT PRIMARY KEY,
    calm_score TEXT NOT NULL,
    active_alert_ids TEXT,
    reasoning TEXT,
    last_notified_utc TEXT
);

CREATE TABLE IF NOT EXISTS threshold_overrides (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    value REAL NOT NULL,
    set_by_user_id INTEGER NOT NULL,
    set_by_user_name TEXT NOT NULL,
    set_at_utc TEXT NOT NULL,
    expires_at_utc TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_overrides_active
    ON threshold_overrides(name, expires_at_utc);

CREATE TABLE IF NOT EXISTS suppressions (
    id INTEGER PRIMARY KEY,
    dedup_key TEXT NOT NULL,
    set_by_user_id INTEGER NOT NULL,
    set_by_user_name TEXT NOT NULL,
    set_at_utc TEXT NOT NULL,
    cleared_at_utc TEXT
);
-- Partial unique index: SQLite treats NULLs in UNIQUE() as distinct, so
-- a regular UNIQUE(dedup_key, cleared_at_utc) does NOT enforce "one
-- active per key". A partial index over only-uncleared rows does.
CREATE UNIQUE INDEX IF NOT EXISTS uniq_suppressions_active
    ON suppressions(dedup_key) WHERE cleared_at_utc IS NULL;

CREATE TABLE IF NOT EXISTS audit_log (
    id INTEGER PRIMARY KEY,
    ts_utc TEXT NOT NULL,
    user_id INTEGER NOT NULL,
    user_name TEXT NOT NULL,
    action TEXT NOT NULL,
    payload_json TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_audit_ts ON audit_log(ts_utc);

CREATE TABLE IF NOT EXISTS returns_history (
    ts_utc TEXT NOT NULL,
    timeframe TEXT NOT NULL,
    return_pct REAL NOT NULL,
    PRIMARY KEY (ts_utc, timeframe)
);
CREATE INDEX IF NOT EXISTS idx_returns_tf_ts
    ON returns_history(timeframe, ts_utc);

CREATE TABLE IF NOT EXISTS report_runs (
    id INTEGER PRIMARY KEY,
    ts_utc TEXT NOT NULL,
    window_start_utc TEXT NOT NULL,
    window_end_utc TEXT NOT NULL,
    pdf_path TEXT,
    sent_chat_ids TEXT,
    error TEXT
);
CREATE INDEX IF NOT EXISTS idx_report_runs_ts ON report_runs(ts_utc);

CREATE TABLE IF NOT EXISTS vol_ticks (
    ts_utc    TEXT NOT NULL,
    hv30      REAL,
    iv30      REAL,
    btc_price REAL,
    PRIMARY KEY (ts_utc)
);
CREATE INDEX IF NOT EXISTS idx_vol_ticks_ts ON vol_ticks(ts_utc);
"""

_PRAGMAS = (
    "PRAGMA journal_mode = WAL;",
    "PRAGMA synchronous  = NORMAL;",
    "PRAGMA temp_store   = MEMORY;",
    "PRAGMA busy_timeout = 5000;",
    "PRAGMA foreign_keys = ON;",
)


# ---------------------------------------------------------------------------
# Time helper
# ---------------------------------------------------------------------------

def utc_now_iso() -> str:
    """Microsecond-precision UTC ISO-8601 (e.g. ``2026-04-25T12:34:56.789012Z``)."""
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f") + "Z"


# ---------------------------------------------------------------------------
# Connection management - thread-local, mirrors realtime/storage.py
# ---------------------------------------------------------------------------

_tls = threading.local()
_init_lock = threading.Lock()
_initialized_paths: set[str] = set()
# Override for tests; when None, use PORTFOLIO_ANALYSIS_DB.
_db_path_override: Optional[Path] = None


def _active_db_path() -> Path:
    return _db_path_override if _db_path_override is not None else PORTFOLIO_ANALYSIS_DB


def set_db_path_for_tests(path: Optional[Path]) -> None:
    """Tests use this to point at a tmp file. Pass None to reset."""
    global _db_path_override
    with _init_lock:
        _db_path_override = path
        # Drop cached per-thread conn so the next get_conn() opens against the new path.
        if hasattr(_tls, "conn"):
            try:
                _tls.conn.close()
            except Exception:
                pass
            del _tls.conn


def _new_conn(path: Path) -> sqlite3.Connection:
    path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(
        str(path),
        timeout=5.0,
        isolation_level=None,  # autocommit; we manage txns explicitly when needed
        check_same_thread=True,
    )
    conn.row_factory = sqlite3.Row
    for pragma in _PRAGMAS:
        conn.execute(pragma)
    return conn


def init_db(path: Optional[Path] = None) -> None:
    """Create file, apply pragmas, create tables. Idempotent.

    Passing ``path`` runs init against that path (used by tests). Without
    ``path`` it inits the active DB (override-aware, defaults to
    ``PORTFOLIO_ANALYSIS_DB``).
    """
    target = path if path is not None else _active_db_path()
    target_key = str(target.resolve())
    with _init_lock:
        if target_key in _initialized_paths:
            # Still safe to call again - verify schema is present.
            return
        conn = _new_conn(target)
        try:
            conn.executescript(_SCHEMA_SQL)
            _apply_migrations(conn)
        finally:
            conn.close()
        _initialized_paths.add(target_key)


def _apply_migrations(conn: sqlite3.Connection) -> None:
    """Idempotent runtime migrations for installs that pre-date current schema.

    Each block is wrapped in a try/except for "duplicate column" - SQLite
    doesn't have ``ADD COLUMN IF NOT EXISTS`` (and ``PRAGMA table_info``
    is the canonical "did this column exist?" check). We just attempt
    the ALTER and swallow the duplicate-column error.

    Also runs one-shot data migrations such as wiping pre-downsampling
    rows from ``returns_history`` so σ recomputes from clean buckets.
    """
    # Schema migration: alerts.combined_level (added 2026 - combined-signal rule).
    cols = {row[1] for row in conn.execute("PRAGMA table_info(alerts)")}
    if "combined_level" not in cols:
        try:
            conn.execute("ALTER TABLE alerts ADD COLUMN combined_level TEXT")
        except sqlite3.OperationalError as exc:
            # "duplicate column" race or a migration we can ignore.
            if "duplicate column" not in str(exc).lower():
                raise

    # One-shot data migration: wipe pre-downsampling rows for 1h / 4h.
    # Track via a tiny migrations table so this runs once per DB.
    conn.execute(
        "CREATE TABLE IF NOT EXISTS _migrations "
        "(name TEXT PRIMARY KEY, applied_at_utc TEXT NOT NULL)"
    )
    done = conn.execute(
        "SELECT 1 FROM _migrations WHERE name = ?",
        ("downsampling_v1",),
    ).fetchone()
    if done is None:
        conn.execute(
            "DELETE FROM returns_history WHERE timeframe IN ('1h', '4h', '24h')"
        )
        conn.execute(
            "INSERT INTO _migrations (name, applied_at_utc) VALUES (?, ?)",
            ("downsampling_v1", utc_now_iso()),
        )


def get_conn() -> sqlite3.Connection:
    """Return a thread-local connection to the active DB."""
    target = _active_db_path()
    init_db(target)
    conn = getattr(_tls, "conn", None)
    if conn is None:
        conn = _new_conn(target)
        _tls.conn = conn
    return conn


# ---------------------------------------------------------------------------
# JSON helper
# ---------------------------------------------------------------------------

def _dumps(payload: Any) -> str:
    return json.dumps(payload if payload is not None else {}, default=str, separators=(",", ":"))


# ---------------------------------------------------------------------------
# Writers
# ---------------------------------------------------------------------------

def insert_alert(
    *,
    ts_utc: str,
    rule: str,
    severity: str,
    dedup_key: str,
    cited_features: list[str],
    feature_values: dict[str, Any],
    message: Optional[str] = None,
    notified_at_utc: Optional[str] = None,
    combined_level: Optional[str] = None,
) -> Optional[int]:
    """Insert an alert row. UNIQUE(dedup_key, ts_utc) - duplicates are ignored.

    ``combined_level`` is set only by the COMBINED_SIGNAL rule
    (STRONG / MEDIUM / WEAK). Other rules pass ``None``.

    Returns the new row id, or ``None`` if the insert was a duplicate.
    """
    conn = get_conn()
    cur = conn.execute(
        """
        INSERT OR IGNORE INTO alerts
            (ts_utc, rule, severity, dedup_key, cited_features, feature_values,
             message, notified_at_utc, resolved_at_utc, combined_level)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, NULL, ?)
        """,
        (
            ts_utc, rule, severity, dedup_key,
            _dumps(cited_features), _dumps(feature_values),
            message, notified_at_utc, combined_level,
        ),
    )
    return cur.lastrowid if cur.rowcount > 0 else None


def resolve_alert(*, alert_id: int, resolved_at_utc: Optional[str] = None) -> None:
    """Mark an alert resolved. Idempotent (re-resolving is a no-op)."""
    ts = resolved_at_utc or utc_now_iso()
    conn = get_conn()
    conn.execute(
        "UPDATE alerts SET resolved_at_utc = ? WHERE id = ? AND resolved_at_utc IS NULL",
        (ts, alert_id),
    )


def insert_state(
    *,
    ts_utc: str,
    calm_score: str,
    active_alert_ids: Iterable[int] = (),
    reasoning: Optional[str] = None,
    last_notified_utc: Optional[str] = None,
) -> None:
    """Persist a state_history row. PK is ts_utc - INSERT OR REPLACE."""
    conn = get_conn()
    conn.execute(
        """
        INSERT OR REPLACE INTO state_history
            (ts_utc, calm_score, active_alert_ids, reasoning, last_notified_utc)
        VALUES (?, ?, ?, ?, ?)
        """,
        (ts_utc, calm_score, _dumps(list(active_alert_ids)), reasoning, last_notified_utc),
    )


def insert_override(
    *,
    name: str,
    value: float,
    set_by_user_id: int,
    set_by_user_name: str,
    set_at_utc: Optional[str] = None,
    expires_at_utc: str,
) -> int:
    """Insert a threshold override row. Returns the new row id."""
    ts = set_at_utc or utc_now_iso()
    conn = get_conn()
    cur = conn.execute(
        """
        INSERT INTO threshold_overrides
            (name, value, set_by_user_id, set_by_user_name, set_at_utc, expires_at_utc)
        VALUES (?, ?, ?, ?, ?, ?)
        """,
        (name, float(value), int(set_by_user_id), set_by_user_name, ts, expires_at_utc),
    )
    return int(cur.lastrowid)


def insert_suppression(
    *,
    dedup_key: str,
    set_by_user_id: int,
    set_by_user_name: str,
    set_at_utc: Optional[str] = None,
) -> Optional[int]:
    """Insert an active suppression for ``dedup_key``.

    Returns the new row id, or ``None`` if a suppression for this key is
    already active (UNIQUE(dedup_key, cleared_at_utc=NULL)).
    """
    ts = set_at_utc or utc_now_iso()
    conn = get_conn()
    cur = conn.execute(
        """
        INSERT OR IGNORE INTO suppressions
            (dedup_key, set_by_user_id, set_by_user_name, set_at_utc, cleared_at_utc)
        VALUES (?, ?, ?, ?, NULL)
        """,
        (dedup_key, int(set_by_user_id), set_by_user_name, ts),
    )
    return cur.lastrowid if cur.rowcount > 0 else None


def clear_suppression(*, dedup_key: str, cleared_at_utc: Optional[str] = None) -> int:
    """Mark the active suppression for ``dedup_key`` cleared. Returns the
    number of rows updated (0 if none was active, normally 1)."""
    ts = cleared_at_utc or utc_now_iso()
    conn = get_conn()
    cur = conn.execute(
        """
        UPDATE suppressions SET cleared_at_utc = ?
        WHERE dedup_key = ? AND cleared_at_utc IS NULL
        """,
        (ts, dedup_key),
    )
    return cur.rowcount


def insert_audit(
    *,
    user_id: int,
    user_name: str,
    action: str,
    payload: Any,
    ts_utc: Optional[str] = None,
) -> int:
    """Append an audit_log row. Returns the new row id."""
    ts = ts_utc or utc_now_iso()
    conn = get_conn()
    cur = conn.execute(
        """
        INSERT INTO audit_log (ts_utc, user_id, user_name, action, payload_json)
        VALUES (?, ?, ?, ?, ?)
        """,
        (ts, int(user_id), user_name, action, _dumps(payload)),
    )
    return int(cur.lastrowid)


def insert_return(*, ts_utc: str, timeframe: str, return_pct: float) -> None:
    """Append a returns_history row. PK is (ts_utc, timeframe) - INSERT OR REPLACE."""
    conn = get_conn()
    conn.execute(
        """
        INSERT OR REPLACE INTO returns_history (ts_utc, timeframe, return_pct)
        VALUES (?, ?, ?)
        """,
        (ts_utc, timeframe, float(return_pct)),
    )


def insert_report_run(
    *,
    ts_utc: Optional[str] = None,
    window_start_utc: str,
    window_end_utc: str,
    pdf_path: Optional[str] = None,
    sent_chat_ids: Optional[list[int]] = None,
    error: Optional[str] = None,
) -> int:
    """Append a report_runs row. Returns the new row id."""
    ts = ts_utc or utc_now_iso()
    conn = get_conn()
    cur = conn.execute(
        """
        INSERT INTO report_runs
            (ts_utc, window_start_utc, window_end_utc, pdf_path, sent_chat_ids, error)
        VALUES (?, ?, ?, ?, ?, ?)
        """,
        (ts, window_start_utc, window_end_utc, pdf_path, _dumps(sent_chat_ids or []), error),
    )
    return int(cur.lastrowid)


def insert_vol_tick(
    *,
    ts_utc: str,
    hv30: Optional[float],
    iv30: Optional[float],
    btc_price: Optional[float],
) -> None:
    """Append one HV/IV sample. PK is ts_utc - INSERT OR REPLACE."""
    conn = get_conn()
    conn.execute(
        """
        INSERT OR REPLACE INTO vol_ticks (ts_utc, hv30, iv30, btc_price)
        VALUES (?, ?, ?, ?)
        """,
        (ts_utc, hv30, iv30, btc_price),
    )


def insert_vol_ticks_bulk(rows: Iterable[dict]) -> int:
    """Bulk insert vol rows (used by backfill). Returns inserted count."""
    conn = get_conn()
    params = [
        (r["ts_utc"], r.get("hv30"), r.get("iv30"), r.get("btc_price"))
        for r in rows
    ]
    if not params:
        return 0
    conn.executemany(
        "INSERT OR REPLACE INTO vol_ticks (ts_utc, hv30, iv30, btc_price) VALUES (?, ?, ?, ?)",
        params,
    )
    return len(params)


def count_vol_ticks() -> int:
    """Total rows in vol_ticks (used to detect first-run + trigger backfill)."""
    conn = get_conn()
    row = conn.execute("SELECT COUNT(*) AS n FROM vol_ticks").fetchone()
    return int(row["n"]) if row else 0


def read_vol_ticks_bucketed(
    *, from_ms: int, to_ms: int, bucket_ms: int,
) -> dict[int, dict]:
    """Read vol_ticks aggregated into UTC-aligned buckets of ``bucket_ms``.

    Returns ``{bucket_start_ms: {"hv30": float|None, "iv30": float|None,
    "btc_price": float|None}}``. For each bucket, **last value wins** for
    each column independently (so a row missing one column doesn't blow
    away an earlier row that had it).

    Used by the HV/IV composite to read snapshots back from the DB
    before falling through to live Deribit fetches.
    """
    conn = get_conn()
    # ts_utc is stored as ISO-8601 'YYYY-MM-DDTHH:MM:SS.ffffffZ'. Convert to
    # epoch ms inline with strftime('%s') against a parsed datetime.
    # sqlite has no real datetime type, so we just compare ISO strings - they
    # sort the same as time when the format is fixed-width.
    from datetime import datetime, timezone

    def _iso(ms: int) -> str:
        return datetime.fromtimestamp(ms / 1000, tz=timezone.utc).strftime(
            "%Y-%m-%dT%H:%M:%S.%fZ"
        )

    cur = conn.execute(
        """
        SELECT ts_utc, hv30, iv30, btc_price
        FROM vol_ticks
        WHERE ts_utc >= ? AND ts_utc <= ?
        ORDER BY ts_utc ASC
        """,
        (_iso(from_ms), _iso(to_ms)),
    )
    buckets: dict[int, dict] = {}
    for row in cur:
        # Parse the row's ts back to ms for bucketing.
        ts = row["ts_utc"]
        # Strip the trailing 'Z' and parse with fromisoformat.
        try:
            if ts.endswith("Z"):
                ts_dt = datetime.fromisoformat(ts[:-1]).replace(tzinfo=timezone.utc)
            else:
                ts_dt = datetime.fromisoformat(ts)
            ts_ms = int(ts_dt.timestamp() * 1000)
        except ValueError:
            continue
        bucket = (ts_ms // bucket_ms) * bucket_ms
        b = buckets.get(bucket)
        if b is None:
            b = {"hv30": None, "iv30": None, "btc_price": None}
            buckets[bucket] = b
        # Last-value-wins per column (each column is independent so a NULL
        # in a later row doesn't overwrite an earlier non-NULL).
        if row["hv30"] is not None:
            b["hv30"] = float(row["hv30"])
        if row["iv30"] is not None:
            b["iv30"] = float(row["iv30"])
        if row["btc_price"] is not None:
            b["btc_price"] = float(row["btc_price"])
    return buckets


# ---------------------------------------------------------------------------
# Readers
# ---------------------------------------------------------------------------

def latest_state() -> Optional[sqlite3.Row]:
    """Most recent state_history row, or None if table is empty."""
    conn = get_conn()
    return conn.execute(
        "SELECT * FROM state_history ORDER BY ts_utc DESC LIMIT 1"
    ).fetchone()


def unresolved_alerts() -> list[sqlite3.Row]:
    """All alerts with resolved_at_utc IS NULL, oldest first."""
    conn = get_conn()
    return list(conn.execute(
        "SELECT * FROM alerts WHERE resolved_at_utc IS NULL ORDER BY ts_utc ASC"
    ))


def active_suppressions() -> list[sqlite3.Row]:
    """All suppressions with cleared_at_utc IS NULL."""
    conn = get_conn()
    return list(conn.execute(
        "SELECT * FROM suppressions WHERE cleared_at_utc IS NULL ORDER BY set_at_utc ASC"
    ))


def active_overrides_for(name: str, *, now_utc: Optional[str] = None) -> Optional[sqlite3.Row]:
    """Most recently-set non-expired override for ``name``, or None."""
    ts = now_utc or utc_now_iso()
    conn = get_conn()
    return conn.execute(
        """
        SELECT * FROM threshold_overrides
        WHERE name = ? AND expires_at_utc > ?
        ORDER BY set_at_utc DESC
        LIMIT 1
        """,
        (name, ts),
    ).fetchone()


def recent_audit(n: int = 20) -> list[sqlite3.Row]:
    """Last ``n`` audit_log rows, newest first."""
    conn = get_conn()
    return list(conn.execute(
        "SELECT * FROM audit_log ORDER BY ts_utc DESC LIMIT ?",
        (int(n),),
    ))


def returns_for(timeframe: str, *, since_utc: Optional[str] = None) -> list[sqlite3.Row]:
    """returns_history rows for one timeframe, oldest first.

    If ``since_utc`` is given, only rows with ``ts_utc >= since_utc`` are
    returned.
    """
    conn = get_conn()
    if since_utc is None:
        return list(conn.execute(
            "SELECT * FROM returns_history WHERE timeframe = ? ORDER BY ts_utc ASC",
            (timeframe,),
        ))
    return list(conn.execute(
        """
        SELECT * FROM returns_history
        WHERE timeframe = ? AND ts_utc >= ?
        ORDER BY ts_utc ASC
        """,
        (timeframe, since_utc),
    ))


def latest_report_run() -> Optional[sqlite3.Row]:
    """Most recent report_runs row, or None."""
    conn = get_conn()
    return conn.execute(
        "SELECT * FROM report_runs ORDER BY ts_utc DESC LIMIT 1"
    ).fetchone()
