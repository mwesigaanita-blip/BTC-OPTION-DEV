"""Offline replay tool - sanity-check alert volume against historical data.

Walks historical ``hedge_engine_aggregated_metrics`` rows in time order,
runs the rules engine against each, prints the alert/state stream, and
asserts the resulting alert volume stays under a configurable
``alerts/hour`` ceiling.

Replay never writes to the production ``portfolio_analysis.sqlite`` and
never calls the Telegram notifier. It allocates a fresh temp DB for its
own bookkeeping and tears it down on exit.

CLI:
    python -m portfolio_analysis.replay --hours 24
    python -m portfolio_analysis.replay --hours 168 --ceiling 4.0
    python -m portfolio_analysis.replay --hours 24 --quiet
"""
from __future__ import annotations

import argparse
import sqlite3
import sys
import tempfile
from datetime import datetime, timedelta, timezone
from pathlib import Path
from types import SimpleNamespace
from typing import Iterable, Optional

from portfolio_analysis import rules, state, storage
from portfolio_analysis.features import FeatureBundle, market, positions, price_change
from realtime._logging import get_logger
from shared.db_paths import HEDGE_ENGINE_DB

__all__ = ["run_replay", "iter_agg_rows", "main", "DEFAULT_CEILING_PER_HOUR"]

log = get_logger("portfolio_analysis.replay")

DEFAULT_CEILING_PER_HOUR = 6.0


# ---------------------------------------------------------------------------
# Source iteration
# ---------------------------------------------------------------------------

def iter_agg_rows(
    *,
    hours: float,
    he_db_path: Path = HEDGE_ENGINE_DB,
    end_iso: Optional[str] = None,
) -> Iterable[sqlite3.Row]:
    """Yield ``hedge_engine_aggregated_metrics`` rows for the last ``hours``."""
    end_dt = (
        datetime.fromisoformat(end_iso.rstrip("Z"))
        if end_iso else datetime.now(timezone.utc)
    )
    if end_dt.tzinfo is None:
        end_dt = end_dt.replace(tzinfo=timezone.utc)
    start_dt = end_dt - timedelta(hours=float(hours))
    start_iso = start_dt.strftime("%Y-%m-%dT%H:%M:%S.%f") + "Z"
    end_iso_full = end_dt.strftime("%Y-%m-%dT%H:%M:%S.%f") + "Z"
    try:
        conn = sqlite3.connect(f"file:{he_db_path}?mode=ro", uri=True, timeout=2.0)
    except sqlite3.OperationalError:
        return iter(())
    conn.row_factory = sqlite3.Row
    try:
        return list(conn.execute(
            "SELECT * FROM hedge_engine_aggregated_metrics "
            "WHERE ts_utc >= ? AND ts_utc <= ? ORDER BY ts_utc ASC",
            (start_iso, end_iso_full),
        ))
    except sqlite3.OperationalError:
        return iter(())
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# One-row evaluation (used by the loop)
# ---------------------------------------------------------------------------

def _build_bundle(agg: sqlite3.Row) -> FeatureBundle:
    ts = agg["ts_utc"]
    spot = agg["btc_price"]
    return FeatureBundle(
        ts_utc=ts,
        spot=spot,
        delta=agg["delta"],
        gamma=agg["gamma"],
        vega=agg["vega"],
        mm_pct=agg["mm_pct"],
        market=market.compute(ts),
        price_change=price_change.compute(ts),
        positions=positions.compute_position_features(spot=float(spot or 0.0), now_utc=ts),
    )


# ---------------------------------------------------------------------------
# Main replay loop
# ---------------------------------------------------------------------------

def run_replay(
    *,
    hours: float,
    ceiling_per_hour: float = DEFAULT_CEILING_PER_HOUR,
    he_db_path: Path = HEDGE_ENGINE_DB,
    end_iso: Optional[str] = None,
    quiet: bool = False,
    print_fn=print,
) -> dict:
    """Walk historical agg rows, run the rules engine, return stats.

    Returns ``{"rows", "alerts_inserted", "state_changes", "alerts_per_hour",
    "ceiling_per_hour", "exceeded", "max_state"}``.

    Allocates a fresh temp DB and rolls back to the previous override
    (if any) on exit.
    """
    rows = list(iter_agg_rows(hours=hours, he_db_path=he_db_path, end_iso=end_iso))
    if not quiet:
        print_fn(f"[replay] window={hours:g}h rows={len(rows)} src={he_db_path}")
    if not rows:
        return {
            "rows": 0,
            "alerts_inserted": 0,
            "state_changes": 0,
            "alerts_per_hour": 0.0,
            "ceiling_per_hour": float(ceiling_per_hour),
            "exceeded": False,
            "max_state": "RELAX",
        }

    # Use a fresh temp DB so replay never pollutes the production one.
    prior_path = storage._db_path_override  # may be None
    tmp_dir = Path(tempfile.mkdtemp(prefix="pa_replay_"))
    storage.set_db_path_for_tests(tmp_dir / "replay.sqlite")
    try:
        return _run_loop(rows, ceiling_per_hour, quiet, print_fn, hours)
    finally:
        # Restore prior override (None → production path).
        storage.set_db_path_for_tests(prior_path)
        # tmp_dir is left on disk - small SQLite files, easy to inspect if needed.


def _run_loop(rows, ceiling_per_hour, quiet, print_fn, hours):
    inserted_count = 0
    state_changes = 0
    severity_max_rank = 0
    max_state_seen = state.CalmState.RELAX.value
    severity_rank = {"INFO": 1, "WARNING": 2, "URGENT": 3, "EMERGENCY": 4}
    prev_state: Optional[str] = None

    for agg in rows:
        ts = agg["ts_utc"]
        try:
            fb = _build_bundle(agg)
        except Exception as exc:
            if not quiet:
                print_fn(f"[replay] {ts} build_bundle error: {exc}")
            continue

        # Persist returns so subsequent rows see σ/quantile signal.
        for tf, ret in fb.market.returns.items():
            if ret is not None:
                try:
                    storage.insert_return(ts_utc=ts, timeframe=tf, return_pct=float(ret))
                except Exception:
                    pass
        for tf, ret in fb.price_change.returns.items():
            if ret is None or tf in fb.market.returns:
                continue
            try:
                storage.insert_return(ts_utc=ts, timeframe=tf, return_pct=float(ret))
            except Exception:
                pass

        candidates = rules.evaluate_all(fb)
        active_keys = {c.dedup_key for c in candidates}
        rules.resolve_cleared(active_keys, ts_utc=ts)
        new_ids = rules.dedup_and_persist(candidates, ts_utc=ts)

        # Always count; only PRINT if not quiet.
        if new_ids:
            inserted_count += len(new_ids)
            if not quiet:
                for cid in new_ids:
                    row = storage.get_conn().execute(
                        "SELECT rule, severity, dedup_key, message FROM alerts WHERE id=?", (cid,),
                    ).fetchone()
                    print_fn(
                        f"[replay] {ts} ALERT [{row['severity']:>9s}] {row['rule']} "
                        f"({row['dedup_key']}) - {row['message']}"
                    )

        # Classify + record state change.
        active_alerts = storage.unresolved_alerts()
        active_views = [
            SimpleNamespace(
                rule=r["rule"], severity=r["severity"], dedup_key=r["dedup_key"],
            )
            for r in active_alerts
        ]
        calm, reasoning = state.classify(active_views)
        # Track max severity reached overall.
        for r in active_alerts:
            severity_max_rank = max(severity_max_rank, severity_rank.get(r["severity"], 0))
        # Track most-elevated calm state.
        if calm.value == "URGENT_ACTION" or (
            prev_state != calm.value
            and {"RELAX": 0, "TAKE_A_LOOK": 1, "ACTIVE_MONITORING": 2, "URGENT_ACTION": 3}.get(calm.value, 0)
            >  {"RELAX": 0, "TAKE_A_LOOK": 1, "ACTIVE_MONITORING": 2, "URGENT_ACTION": 3}.get(max_state_seen, 0)
        ):
            max_state_seen = calm.value
        storage.insert_state(
            ts_utc=ts, calm_score=calm.value,
            active_alert_ids=[r["id"] for r in active_alerts],
            reasoning=reasoning,
        )
        if prev_state != calm.value:
            if not quiet:
                print_fn(f"[replay] {ts} STATE {prev_state} -> {calm.value} ({reasoning})")
            prev_state = calm.value
            state_changes += 1

    alerts_per_hour = inserted_count / float(hours) if hours > 0 else 0.0
    exceeded = alerts_per_hour > ceiling_per_hour

    summary = {
        "rows": len(rows),
        "alerts_inserted": inserted_count,
        "state_changes": state_changes,
        "alerts_per_hour": round(alerts_per_hour, 3),
        "ceiling_per_hour": float(ceiling_per_hour),
        "exceeded": exceeded,
        "max_state": max_state_seen,
    }
    if not quiet:
        verdict = "OVER CEILING" if exceeded else "ok"
        print_fn(
            f"[replay] DONE rows={summary['rows']} alerts={summary['alerts_inserted']} "
            f"({summary['alerts_per_hour']}/h, ceiling {summary['ceiling_per_hour']}/h "
            f"-> {verdict}) state_changes={summary['state_changes']} "
            f"max_state={summary['max_state']}"
        )
    return summary


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main(argv: Optional[list[str]] = None) -> int:
    p = argparse.ArgumentParser(prog="portfolio_analysis.replay")
    p.add_argument("--hours", type=float, default=24.0,
                   help="how many hours of agg-metrics history to replay (default 24)")
    p.add_argument("--ceiling", type=float, default=DEFAULT_CEILING_PER_HOUR,
                   help=f"max alerts/hour before failing (default {DEFAULT_CEILING_PER_HOUR})")
    p.add_argument("--end-iso", type=str, default=None,
                   help="end of the window (UTC ISO); defaults to now")
    p.add_argument("--quiet", action="store_true",
                   help="suppress per-row output, print only the summary")
    args = p.parse_args(argv)
    summary = run_replay(
        hours=args.hours,
        ceiling_per_hour=args.ceiling,
        end_iso=args.end_iso,
        quiet=args.quiet,
        he_db_path=HEDGE_ENGINE_DB,   # read at call time so tests can monkeypatch
    )
    return 1 if summary["exceeded"] else 0


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
