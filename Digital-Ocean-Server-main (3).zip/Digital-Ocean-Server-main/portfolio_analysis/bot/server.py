"""Telegram long-poll bot loop.

Run with:  ``python -m portfolio_analysis.bot.server``

Polls ``getUpdates`` with an offset, dispatches every command via
``commands.dispatch``, and replies via ``sendMessage``. Keeps no state
beyond the offset (which lives in the running process - survives the
loop, restarts at "now" after a process restart so we don't replay old
messages).
"""
from __future__ import annotations

import os
import signal
import threading
import time
from typing import Optional

import requests

from portfolio_analysis import storage
from portfolio_analysis.bot import commands
from realtime._logging import get_logger

__all__ = ["BotServer", "run"]

log = get_logger("portfolio_analysis.bot.server")

LONG_POLL_TIMEOUT_S = 25
HTTP_TIMEOUT_S = LONG_POLL_TIMEOUT_S + 10
ERROR_BACKOFF_S = 5.0


def _token() -> str:
    return os.getenv("TELEGRAM_PORTFOLIO_BOT_TOKEN", "").strip()


def _api(method: str) -> str:
    return f"https://api.telegram.org/bot{_token()}/{method}"


def _send_reply(
    chat_id: int,
    text: str,
    *,
    keyboard: Optional[list] = None,
) -> None:
    """Send a fresh message. Optional ``keyboard`` is a list of inline-button
    rows (each row a list of ``{"text", "callback_data"}`` dicts)."""
    payload: dict = {"chat_id": chat_id, "text": text, "parse_mode": "HTML"}
    if keyboard:
        payload["reply_markup"] = {"inline_keyboard": keyboard}
    try:
        requests.post(_api("sendMessage"), json=payload, timeout=10).raise_for_status()
    except Exception as exc:
        log.warning("sendMessage to chat=%s failed: %s", chat_id, exc)


def _edit_message(
    chat_id: int,
    message_id: int,
    text: str,
    *,
    keyboard: Optional[list] = None,
) -> None:
    """Edit an existing bot message (used to advance wizard steps in place)."""
    payload: dict = {
        "chat_id": chat_id, "message_id": message_id,
        "text": text, "parse_mode": "HTML",
    }
    if keyboard:
        payload["reply_markup"] = {"inline_keyboard": keyboard}
    else:
        payload["reply_markup"] = {"inline_keyboard": []}   # remove buttons
    try:
        requests.post(_api("editMessageText"), json=payload, timeout=10).raise_for_status()
    except Exception as exc:
        log.warning("editMessageText chat=%s msg=%s failed: %s", chat_id, message_id, exc)


def _answer_callback(callback_query_id: str) -> None:
    """Acknowledge a callback_query so Telegram stops the loading spinner."""
    try:
        requests.post(
            _api("answerCallbackQuery"),
            json={"callback_query_id": callback_query_id},
            timeout=5,
        )
    except Exception as exc:
        log.debug("answerCallbackQuery failed: %s", exc)


# ---------------------------------------------------------------------------
# BotServer - long-poll loop
# ---------------------------------------------------------------------------

class BotServer:
    def __init__(self, *, stop_event: Optional[threading.Event] = None) -> None:
        self.stop_event = stop_event or threading.Event()
        self._offset: Optional[int] = None
        self._thread: Optional[threading.Thread] = None

    def start(self) -> None:
        if self._thread is not None and self._thread.is_alive():
            return
        self._thread = threading.Thread(
            target=self._loop, name="portfolio-analysis-bot", daemon=True,
        )
        self._thread.start()
        log.info("BotServer started")

    def stop(self, timeout: float = 5.0) -> None:
        self.stop_event.set()
        if self._thread is not None:
            self._thread.join(timeout=timeout)
            log.info("BotServer stopped")

    def _loop(self) -> None:
        if not _token():
            log.error("TELEGRAM_PORTFOLIO_BOT_TOKEN not set - bot will not start")
            return
        # Initialize offset = "skip everything older than process start" so a
        # restart doesn't replay every command since the bot was created.
        self._prime_offset()
        storage.init_db()
        while not self.stop_event.is_set():
            try:
                self._tick()
            except Exception:
                log.exception("BotServer tick failed; backing off %ss", ERROR_BACKOFF_S)
                self.stop_event.wait(ERROR_BACKOFF_S)

    def _prime_offset(self) -> None:
        try:
            r = requests.get(
                _api("getUpdates"),
                params={"timeout": 0, "offset": -1},
                timeout=10,
            )
            r.raise_for_status()
            data = r.json().get("result", [])
            if data:
                self._offset = data[-1]["update_id"] + 1
                log.info("primed bot offset to %s", self._offset)
        except Exception as exc:
            log.warning("could not prime bot offset: %s", exc)

    def _tick(self) -> None:
        params: dict = {"timeout": LONG_POLL_TIMEOUT_S}
        if self._offset is not None:
            params["offset"] = self._offset
        r = requests.get(_api("getUpdates"), params=params, timeout=HTTP_TIMEOUT_S)
        r.raise_for_status()
        for upd in r.json().get("result", []):
            self._offset = upd["update_id"] + 1
            self._handle_update(upd)

    def _handle_update(self, upd: dict) -> None:
        # Inline-button taps come as callback_query updates, not message ones.
        if "callback_query" in upd:
            self._handle_callback(upd["callback_query"])
            return

        msg = upd.get("message") or upd.get("edited_message")
        if not msg:
            return
        text = msg.get("text", "")
        sender = msg.get("from") or {}
        chat = msg.get("chat") or {}
        user_id = sender.get("id")
        chat_id = chat.get("id")
        if user_id is None or chat_id is None:
            return

        # If the user has an active wizard expecting plain-text input
        # (a value or a custom duration), route the message there first.
        result = commands.dispatch_text_for_wizard(
            text=text, user_id=int(user_id), chat_id=int(chat_id),
        )
        if result is None:
            result = commands.dispatch(
                text=text, user_id=int(user_id), chat_id=int(chat_id),
            )
        if result is None:
            return  # not a command - ignore silently
        self._dispatch_result(int(chat_id), result)

    def _handle_callback(self, cq: dict) -> None:
        cq_id = cq.get("id")
        data = cq.get("data") or ""
        sender = cq.get("from") or {}
        msg = cq.get("message") or {}
        chat = msg.get("chat") or {}
        user_id = sender.get("id")
        chat_id = chat.get("id")
        message_id = msg.get("message_id")
        if user_id is None or chat_id is None or message_id is None:
            if cq_id:
                _answer_callback(cq_id)
            return
        result = commands.dispatch_callback(
            data=data, user_id=int(user_id),
            chat_id=int(chat_id), message_id=int(message_id),
        )
        if cq_id:
            _answer_callback(cq_id)
        if result is None:
            return
        self._dispatch_result(int(chat_id), result)

    def _dispatch_result(self, chat_id: int, result: commands.CommandResult) -> None:
        """Send / edit the bot's reply based on flags on the result."""
        if result.edit_message_id is not None:
            _edit_message(
                chat_id, int(result.edit_message_id),
                result.reply, keyboard=result.keyboard,
            )
        else:
            _send_reply(chat_id, result.reply, keyboard=result.keyboard)
        if result.document_path:
            self._send_document(
                chat_id, result.document_path, caption=result.document_caption,
            )

    def _send_document(
        self,
        chat_id: int,
        path: str,
        *,
        caption: Optional[str] = None,
    ) -> None:
        """Upload a file to ``chat_id`` via Telegram's sendDocument."""
        try:
            with open(path, "rb") as fh:
                data: dict = {"chat_id": chat_id}
                if caption:
                    data["caption"] = caption
                requests.post(
                    _api("sendDocument"),
                    data=data,
                    files={"document": fh},
                    timeout=30,
                ).raise_for_status()
        except Exception as exc:
            log.warning(
                "sendDocument to chat=%s path=%s failed: %s",
                chat_id, path, exc,
            )


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def run() -> None:
    bot = BotServer()
    stop = bot.stop_event

    def _on_signal(_sig, _frame):
        log.info("signal received - stopping bot")
        stop.set()

    signal.signal(signal.SIGINT, _on_signal)
    try:
        signal.signal(signal.SIGTERM, _on_signal)
    except (AttributeError, ValueError):
        pass  # SIGTERM unavailable on Windows in some contexts

    bot.start()
    try:
        while not stop.is_set():
            stop.wait(timeout=1.0)
    finally:
        bot.stop(timeout=5.0)


if __name__ == "__main__":  # pragma: no cover
    run()
