"""Authorization for the portfolio_analysis Telegram bot.

Reads ``AUTHORIZED_TELEGRAM_USERS`` from .env. The value must be a JSON
object ``{"name": "user_id", ...}`` so that:

* ``is_authorized(user_id)`` cheaply checks if the sender is allowed.
* The matching ``name`` is used as ``user_name`` in audit_log + broadcast,
  so messages read "User andres ..." instead of "User 123456789 ...".

Empty values in the JSON are skipped, so you can pre-fill placeholders.
"""
from __future__ import annotations

import json
import os
from typing import Optional

from realtime._logging import get_logger

__all__ = [
    "load_authorized_users",
    "is_authorized",
    "name_for",
]

log = get_logger("portfolio_analysis.bot.auth")


def load_authorized_users() -> dict[int, str]:
    """Parse ``AUTHORIZED_TELEGRAM_USERS`` → ``{user_id: name}``."""
    raw = os.getenv("AUTHORIZED_TELEGRAM_USERS", "").strip()
    if not raw:
        return {}
    try:
        m = json.loads(raw)
    except (TypeError, ValueError) as exc:
        log.warning("AUTHORIZED_TELEGRAM_USERS is not valid JSON: %s", exc)
        return {}
    if not isinstance(m, dict):
        log.warning("AUTHORIZED_TELEGRAM_USERS must be a JSON object")
        return {}
    out: dict[int, str] = {}
    for name, uid in m.items():
        s = str(uid or "").strip()
        if not s:
            continue
        try:
            out[int(s)] = str(name)
        except (TypeError, ValueError):
            log.warning("AUTHORIZED_TELEGRAM_USERS entry %r=%r ignored (bad id)", name, uid)
    return out


def is_authorized(user_id: int) -> bool:
    return int(user_id) in load_authorized_users()


def name_for(user_id: int) -> Optional[str]:
    """Display name for an authorized user, or ``None`` if not authorized."""
    return load_authorized_users().get(int(user_id))
