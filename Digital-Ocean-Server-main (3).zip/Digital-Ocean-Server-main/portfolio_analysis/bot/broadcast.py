"""Broadcast helper - sends a plain message to every chat in TELEGRAM_CHAT_IDS.

Used by:
* ``thresholds.set_override``           → "User <name> changed <name> to <v> for <d>"
* ``/stop`` / ``/resume`` commands      → "User <name> stopped/resumed notifications ..."

Honours ``DRY_RUN=1`` (logs the payload instead of hitting Telegram), so
the rest of the package can broadcast freely without worrying about the
mode.
"""
from __future__ import annotations

import os
from typing import Optional

import requests

from portfolio_analysis import notifier as _notifier
from realtime._logging import get_logger

__all__ = ["broadcast"]

log = get_logger("portfolio_analysis.bot.broadcast")


def broadcast(text: str, *, parse_mode: Optional[str] = "HTML") -> bool:
    """Send ``text`` to every chat in ``TELEGRAM_CHAT_IDS``.

    All portfolio_analysis broadcasts use HTML markup (``<b>``, ``<i>``,
    ``<code>``) so ``parse_mode`` defaults to ``"HTML"``. Pass
    ``parse_mode=None`` for plain text.

    Returns True if at least one chat received the message (or, in DRY_RUN,
    if the payload was logged).
    """
    if _notifier.is_dry_run():
        log.info("DRY_RUN broadcast payload_size=%d\n%s", len(text), text)
        return True

    token = os.getenv("TELEGRAM_PORTFOLIO_BOT_TOKEN", "").strip()
    if not token:
        log.warning("skip broadcast (no TELEGRAM_PORTFOLIO_BOT_TOKEN)")
        return False
    chats = _notifier.load_chat_ids()
    if not chats:
        log.warning("skip broadcast (no chat_ids)")
        return False

    sent = False
    url = f"https://api.telegram.org/bot{token}/sendMessage"
    for chat_id in chats:
        payload: dict = {"chat_id": chat_id, "text": text}
        if parse_mode:
            payload["parse_mode"] = parse_mode
        try:
            r = requests.post(url, json=payload, timeout=10)
            r.raise_for_status()
            sent = True
        except Exception as exc:
            log.warning("broadcast to chat=%s failed: %s", chat_id, exc)
    if sent:
        log.info("broadcast sent payload_size=%d chats=%d", len(text), len(chats))
    return sent
