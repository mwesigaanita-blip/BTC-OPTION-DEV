"""Command handlers for the portfolio_analysis Telegram bot.

Each handler takes a parsed :class:`Command` and returns a reply string
that ``server.py`` sends back to the requester. Side effects (DB writes,
broadcasts, audit) happen inside the handler.

All authorization, validation, and audit logging happens here - the
server is a thin transport that just routes commands by name.
"""
from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Optional

from portfolio_analysis import config, storage, thresholds
from portfolio_analysis._fmt import (
    alert_button_text,
    example_for_default,
    format_threshold_value,
    format_utc_human,
    human_label_for_dedup_key,
    is_duration_threshold,
    severity_icon,
)
from portfolio_analysis.bot import auth, wizard
from portfolio_analysis.bot.broadcast import broadcast
from realtime._logging import get_logger

__all__ = [
    "Command",
    "CommandResult",
    "dispatch",
    "dispatch_text_for_wizard",
    "dispatch_callback",
    "HANDLERS",
]

log = get_logger("portfolio_analysis.bot.commands")


@dataclass(frozen=True)
class Command:
    name: str                 # e.g. "set" (no leading slash)
    args: list[str]           # whitespace-split arguments
    user_id: int
    user_name: str            # resolved from AUTHORIZED_TELEGRAM_USERS, "" if unknown
    chat_id: int = 0          # Telegram chat id (used by wizard flows)


@dataclass(frozen=True)
class CommandResult:
    reply: str                # text sent back to the requester
    ok: bool = True
    keyboard: Optional[list] = None
    """Optional Telegram inline keyboard (list of rows, each row a list of
    buttons). When set, the server attaches it as ``reply_markup``. When
    ``edit_message_id`` is also set the server edits that message in
    place instead of sending a new one."""
    edit_message_id: Optional[int] = None
    document_path: Optional[str] = None
    """Optional file path. When set, the server sends the file as a
    document attachment to the requesting chat *in addition to* the
    text reply. Used by ``/help`` to attach the bot user-guide PDF."""
    document_caption: Optional[str] = None


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _audit(cmd: Command, payload: dict) -> None:
    storage.insert_audit(
        user_id=cmd.user_id,
        user_name=cmd.user_name,
        action=cmd.name,
        payload=payload,
    )


def _parse_command(text: str) -> Optional[tuple[str, list[str]]]:
    """Split a raw message into ``(command, args)`` or return None.

    Strips a possible bot suffix (``/set@MyBot args`` → command ``set``).
    """
    text = (text or "").strip()
    if not text.startswith("/"):
        return None
    head, *rest = text.split(maxsplit=1)
    cmd = head[1:]
    if "@" in cmd:
        cmd = cmd.split("@", 1)[0]
    args = rest[0].split() if rest else []
    return cmd.lower(), args


# ---------------------------------------------------------------------------
# /set - override a threshold
#
# Two flavours:
#   • zero args  → starts an interactive wizard (buttons for threshold +
#     duration; user types the value as plain text).
#   • three args → legacy one-shot form, kept for power users / scripting.
# ---------------------------------------------------------------------------

def _threshold_keyboard() -> list:
    """Build a 1-column inline keyboard listing every overrideable threshold.

    Uses ``wizard.THRESHOLD_LABELS`` for the visible button text and keeps
    the canonical name in the callback_data so internal logic + audit log
    are unchanged.
    """
    names = list(config.DEFAULT_THRESHOLDS.keys())
    rows: list[list[dict]] = []
    for n in names:
        rows.append([{
            "text": wizard.label_for(n),
            "callback_data": f"set:thr:{n}",
        }])
    rows.append([{"text": "❌ Cancel", "callback_data": "wiz:cancel"}])
    return rows


def _duration_keyboard() -> list:
    """Build a duration-preset keyboard (3 per row) + Custom + Cancel."""
    rows: list[list[dict]] = []
    presets = wizard.DURATION_PRESETS
    for i in range(0, len(presets), 3):
        row = [
            {"text": label, "callback_data": f"set:dur:{value}"}
            for label, value in presets[i:i + 3]
        ]
        rows.append(row)
    rows.append([
        {"text": "✏️ Custom…", "callback_data": "set:dur:custom"},
        {"text": "❌ Cancel",   "callback_data": "wiz:cancel"},
    ])
    return rows


def _apply_set_override(*, cmd: Command, name: str, value: float,
                        duration_s: int) -> CommandResult:
    """Shared override-application path used by both wizard and legacy /set."""
    desc = thresholds.set_override(
        name=name, value=value, duration_s=duration_s,
        user_id=cmd.user_id, user_name=cmd.user_name,
    )
    pretty_value = format_threshold_value(name, value)
    label = wizard.label_for(name)
    return CommandResult(
        f"✅ <b>{label}</b> (<code>{name}</code>) set to "
        f"<b>{pretty_value}</b>\nuntil {format_utc_human(desc['expires_at_utc'])}"
    )


def cmd_set(cmd: Command) -> CommandResult:
    # ── Interactive flow (no args) ───────────────────────────────────────
    if len(cmd.args) == 0:
        wizard.start(wizard.WizardState(
            flow=wizard.FLOW_SET, step=wizard.STEP_PICK_THRESHOLD,
            user_id=cmd.user_id, chat_id=cmd.chat_id,
        ))
        return CommandResult(
            "🎚️ Which threshold would you like to override?",
            keyboard=_threshold_keyboard(),
        )

    # ── Legacy one-shot form ─────────────────────────────────────────────
    if len(cmd.args) != 3:
        return CommandResult(
            "Usage:\n"
            "  /set                              start interactive wizard\n"
            "  /set <NAME> <value> <duration>    one-shot form\n"
            "Example: /set MM_WARN_PCT 25 7d",
            ok=False,
        )
    name, value_s, dur_s = cmd.args
    name = name.upper()
    if name not in config.DEFAULT_THRESHOLDS:
        return CommandResult(
            f"Unknown threshold: {name}\nTry /thresholds to see the list.",
            ok=False,
        )
    try:
        value = float(value_s)
    except ValueError:
        return CommandResult(f"Invalid value: {value_s} (must be a number)", ok=False)
    try:
        duration_s = thresholds.parse_duration(dur_s)
    except thresholds.InvalidDuration as exc:
        return CommandResult(f"Invalid duration: {exc}", ok=False)
    return _apply_set_override(cmd=cmd, name=name, value=value, duration_s=duration_s)


# ---------------------------------------------------------------------------
# /stop - suppress an alert
# ---------------------------------------------------------------------------

def _resolve_keys_for_stop(arg: str) -> list[str]:
    """Resolve a /stop argument into one or more dedup_keys.

    Argument can be either:
      * an exact dedup_key (e.g. ``MM:band=warning``) - must match an
        unresolved alert.
      * a rule name (e.g. ``MM_PRESSURE``) - every unresolved alert from
        that rule.

    Either way, only currently-active dedup_keys are returned, so
    ``/stop`` can't pre-emptively suppress an alert that isn't firing.
    """
    open_keys = {r["dedup_key"] for r in storage.unresolved_alerts()
                 if True}
    open_rule_to_keys: dict[str, list[str]] = {}
    for r in storage.unresolved_alerts():
        open_rule_to_keys.setdefault(r["rule"], []).append(r["dedup_key"])
    if ":" in arg:
        return [arg] if arg in open_keys else []
    return open_rule_to_keys.get(arg.upper(), [])


def _alert_pick_keyboard(
    prefix: str,
    entries: list[tuple[str, Optional[str]]],
) -> list:
    """Build a one-button-per-row keyboard for picking an alert key.

    ``entries`` is a list of ``(dedup_key, severity_or_None)`` tuples.
    Each button shows the severity icon + a plain-English label rather
    than the raw dedup key.
    """
    rows: list[list[dict]] = []
    for key, severity in entries[:20]:
        rows.append([{
            "text": alert_button_text(key, severity),
            "callback_data": f"{prefix}:{key}",
        }])
    rows.append([{"text": "❌ Cancel", "callback_data": "wiz:cancel"}])
    return rows


def cmd_stop(cmd: Command) -> CommandResult:
    # Interactive flow: list every active alert as a button.
    if len(cmd.args) == 0:
        # Most recent severity per dedup_key (rule may emit at different
        # bands over time; we want the latest).
        latest: dict[str, str] = {}
        for r in storage.unresolved_alerts():
            latest[r["dedup_key"]] = r["severity"]
        # Hide alerts that are already being handled - /stop'ing them
        # again would just bounce. Use /resume to undo first.
        already_handled = {s["dedup_key"] for s in storage.active_suppressions()}
        latest = {k: v for k, v in latest.items() if k not in already_handled}
        if not latest:
            if already_handled:
                return CommandResult(
                    f"All {len(already_handled)} active alerts are already "
                    f"being handled. Use /resume to lift a suppression. ✅"
                )
            return CommandResult("No active alerts - nothing to stop. ✅")
        entries = sorted(latest.items())
        wizard.start(wizard.WizardState(
            flow=wizard.FLOW_STOP, step=wizard.STEP_PICK_KEY,
            user_id=cmd.user_id, chat_id=cmd.chat_id,
        ))
        word = "alert" if len(entries) == 1 else "alerts"
        skipped_note = (
            f"\n<i>({len(already_handled)} already being handled - not shown.)</i>"
            if already_handled else ""
        )
        return CommandResult(
            f"🛑 <b>Stop notifications for which alert?</b>\n"
            f"<i>{len(entries)} active {word}. Tap one to take it over - "
            f"future notifications for that alert will pause until it "
            f"auto-resolves.</i>{skipped_note}",
            keyboard=_alert_pick_keyboard("stop:key", entries),
        )

    if len(cmd.args) != 1:
        return CommandResult(
            "Usage:\n"
            "  /stop                             pick from a button list\n"
            "  /stop <dedup_key | RULE_NAME>     direct form\n"
            "Examples:\n"
            "  /stop MM:band=warning\n"
            "  /stop MM_PRESSURE",
            ok=False,
        )
    keys = _resolve_keys_for_stop(cmd.args[0])
    if not keys:
        return CommandResult(
            f"No active alerts matching {cmd.args[0]} - nothing to stop.",
            ok=False,
        )
    suppressed: list[str] = []
    for k in keys:
        new_id = storage.insert_suppression(
            dedup_key=k,
            set_by_user_id=cmd.user_id,
            set_by_user_name=cmd.user_name,
        )
        if new_id is not None:
            suppressed.append(k)
    _audit(cmd, {"argument": cmd.args[0], "suppressed_keys": suppressed})
    if not suppressed:
        return CommandResult(
            f"All matching alerts were already suppressed for "
            f"<code>{cmd.args[0]}</code>.",
            ok=False,
        )
    pretty = "\n".join(f"  • {human_label_for_dedup_key(k)}" for k in suppressed)
    word = "alert" if len(suppressed) == 1 else "alerts"
    broadcast(
        f"🛑 <b>{cmd.user_name}</b> is now handling "
        f"{len(suppressed)} {word}:\n{pretty}\n\n"
        f"<i>Auto-clears when the alert resolves.</i>"
    )
    return CommandResult(
        f"🛑 You're now handling {len(suppressed)} {word}:\n{pretty}\n\n"
        f"<i>Notifications paused until the alert auto-resolves "
        f"(or use /resume).</i>"
    )


# ---------------------------------------------------------------------------
# /resume - manually clear a suppression early
# ---------------------------------------------------------------------------

def cmd_resume(cmd: Command) -> CommandResult:
    # Interactive flow: list every active suppression as a button.
    if len(cmd.args) == 0:
        keys = sorted({r["dedup_key"] for r in storage.active_suppressions()})
        if not keys:
            return CommandResult("No active suppressions - nothing to resume. ✅")
        # Suppressions don't carry severity directly; fall back to the most
        # recent open alert with the same dedup_key for the icon.
        sev_by_key: dict[str, str] = {}
        for r in storage.unresolved_alerts():
            sev_by_key[r["dedup_key"]] = r["severity"]
        entries = [(k, sev_by_key.get(k)) for k in keys]
        wizard.start(wizard.WizardState(
            flow=wizard.FLOW_RESUME, step=wizard.STEP_PICK_KEY,
            user_id=cmd.user_id, chat_id=cmd.chat_id,
        ))
        word = "suppression" if len(entries) == 1 else "suppressions"
        return CommandResult(
            f"▶️ <b>Resume notifications for which alert?</b>\n"
            f"<i>{len(entries)} active {word}. Tap one to start "
            f"receiving its notifications again.</i>",
            keyboard=_alert_pick_keyboard("resume:key", entries),
        )

    if len(cmd.args) != 1:
        return CommandResult(
            "Usage:\n"
            "  /resume                            pick from a button list\n"
            "  /resume <dedup_key | RULE_NAME>    direct form",
            ok=False,
        )
    arg = cmd.args[0]
    if ":" in arg:
        keys = [arg]
    else:
        rule = arg.upper()
        keys = [
            r["dedup_key"] for r in storage.active_suppressions()
            if r["dedup_key"].startswith(_rule_prefix(rule))
        ]
    cleared: list[str] = []
    for k in keys:
        n = storage.clear_suppression(dedup_key=k)
        if n > 0:
            cleared.append(k)
    _audit(cmd, {"argument": arg, "cleared_keys": cleared})
    if not cleared:
        return CommandResult(
            f"No active suppressions matching {arg}.",
            ok=False,
        )
    pretty = "\n".join(f"  • {human_label_for_dedup_key(k)}" for k in cleared)
    word = "alert" if len(cleared) == 1 else "alerts"
    broadcast(
        f"▶️ <b>{cmd.user_name}</b> resumed notifications for "
        f"{len(cleared)} {word}:\n{pretty}"
    )
    return CommandResult(
        f"▶️ Resumed notifications for {len(cleared)} {word}:\n{pretty}"
    )


def _rule_prefix(rule: str) -> str:
    """Translate a rule name into the dedup_key prefix used by that rule."""
    return {
        "MM_PRESSURE":    "MM:",
        "DELTA_DRIFT":    "DELTA:",
        "DTE_RISK":       "DTE:",
        "VOL_SIGMA":      "VOL:",
        "PRICE_QUANTILE": "QUANTILE:",
    }.get(rule.upper(), rule.upper() + ":")


# ---------------------------------------------------------------------------
# /status - current Calm Score + active alerts + suppressions
# ---------------------------------------------------------------------------

def cmd_status(cmd: Command) -> CommandResult:
    last = storage.latest_state()
    if last is not None:
        state_line = (
            f"<b>Calm Score:</b> {last['calm_score']}\n"
            f"<i>{last['reasoning']}</i>"
        )
    else:
        state_line = "<b>Calm Score:</b> (no state yet - worker hasn't run)"

    alerts = storage.unresolved_alerts()
    if alerts:
        alert_lines = "\n".join(
            f"  {severity_icon(a['severity'])} "
            f"{human_label_for_dedup_key(a['dedup_key'])}"
            for a in alerts
        )
        alert_block = f"\n\n<b>Active alerts ({len(alerts)}):</b>\n{alert_lines}"
    else:
        alert_block = "\n\n<b>Active alerts:</b> none ✅"

    sups = storage.active_suppressions()
    if sups:
        sup_lines = "\n".join(
            f"  • {human_label_for_dedup_key(s['dedup_key'])} "
            f"<i>(handled by {s['set_by_user_name']})</i>"
            for s in sups
        )
        sup_block = f"\n\n<b>Being handled ({len(sups)}):</b>\n{sup_lines}"
    else:
        sup_block = ""

    return CommandResult(state_line + alert_block + sup_block)


# ---------------------------------------------------------------------------
# /thresholds - list every threshold's current value
# ---------------------------------------------------------------------------

def cmd_thresholds(cmd: Command) -> CommandResult:
    rows = thresholds.list_active()
    lines = ["📊 <b>Current thresholds</b>"]
    for r in rows:
        label = wizard.label_for(r["name"])
        cur_pretty = format_threshold_value(r["name"], r["current"])
        def_pretty = format_threshold_value(r["name"], r["default"])
        line = f"\n<b>{label}</b>  <i>({r['name']})</i>"
        if r["overridden"]:
            line += (
                f"\n  current <b>{cur_pretty}</b>  "
                f"<i>(default {def_pretty})</i> ← override"
                f"\n  until {format_utc_human(r['expires_at_utc'])}, "
                f"by {r['set_by_user_name']}"
            )
        else:
            line += f"\n  <b>{cur_pretty}</b>  <i>(default)</i>"
        lines.append(line)
    return CommandResult("\n".join(lines))


# ---------------------------------------------------------------------------
# /audit [N]
# ---------------------------------------------------------------------------

def cmd_audit(cmd: Command) -> CommandResult:
    n = 20
    if cmd.args:
        try:
            n = max(1, min(100, int(cmd.args[0])))
        except ValueError:
            return CommandResult("Usage: /audit [N]  (N = 1..100)", ok=False)
    rows = storage.recent_audit(n)
    if not rows:
        return CommandResult("(audit log empty)")
    lines = [f"📜 Last {len(rows)} audit entries (newest first):"]
    for r in rows:
        try:
            payload = json.loads(r["payload_json"])
            payload_short = ", ".join(f"{k}={v}" for k, v in list(payload.items())[:3])
        except Exception:
            payload_short = r["payload_json"]
        lines.append(
            f"  {format_utc_human(r['ts_utc'])} {r['user_name']} "
            f"{r['action']} :: {payload_short}"
        )
    return CommandResult("\n".join(lines))


# ---------------------------------------------------------------------------
# /report - Phase 10 placeholder
# ---------------------------------------------------------------------------

def cmd_report(cmd: Command) -> CommandResult:
    """Build the daily PDF on demand and ship it to the requesting chat."""
    from portfolio_analysis import report_daily
    from portfolio_analysis import notifier as _n
    _audit(cmd, {"requested": True})
    try:
        pdf_path = report_daily.build_report()
    except Exception as exc:
        log.exception("on-demand build_report failed")
        return CommandResult(f"⚠️ Failed to build report: {exc}", ok=False)
    caption = f"📄 Portfolio report - on demand by {cmd.user_name}"
    if _n.is_dry_run():
        log.info(
            "DRY_RUN /report from %s pdf=%s", cmd.user_name, pdf_path,
        )
        return CommandResult(
            f"📄 (DRY_RUN) report built at {pdf_path}.\n"
            f"Set DRY_RUN=0 to send via Telegram."
        )
    sent = _n.send_document(str(pdf_path), caption=caption)
    if not sent:
        return CommandResult(
            f"⚠️ Built {pdf_path} but failed to send. See logs.", ok=False,
        )
    return CommandResult(f"📄 Report sent to {len(sent)} chat(s).")


# ---------------------------------------------------------------------------
# /help
# ---------------------------------------------------------------------------

_HELP_PDF_PATH = (
    Path(__file__).resolve().parents[1] / "docs" / "telegram_bot_guide.pdf"
)


def cmd_help(cmd: Command) -> CommandResult:
    """Return the command list and attach the user-guide PDF if present."""
    text = (
        "Portfolio Co-Pilot - commands:\n"
        "  /set            tap-through wizard to override a threshold\n"
        "                  (or one-shot: /set MM_WARN_PCT 25 7d)\n"
        "  /stop           pick an active alert to suppress (or pass dedup_key)\n"
        "  /resume         pick a suppression to lift (or pass dedup_key)\n"
        "  /status         current Calm Score + active alerts\n"
        "  /thresholds     list every threshold's current value\n"
        "  /audit [N]      last N audit entries (default 20, max 100)\n"
        "  /report         build today's PDF on demand and send it back\n"
        "  /help           this message + the full user-guide PDF"
    )
    # Attach the PDF if the file is in place; otherwise just send the text.
    if _HELP_PDF_PATH.is_file():
        return CommandResult(
            text,
            document_path=str(_HELP_PDF_PATH),
            document_caption="📘 Portfolio bot - full user guide",
        )
    log.warning("user-guide PDF not found at %s - sending text-only /help", _HELP_PDF_PATH)
    return CommandResult(text)


# ---------------------------------------------------------------------------
# Dispatcher
# ---------------------------------------------------------------------------

HANDLERS: dict[str, Callable[[Command], CommandResult]] = {
    "set":        cmd_set,
    "stop":       cmd_stop,
    "resume":     cmd_resume,
    "status":     cmd_status,
    "thresholds": cmd_thresholds,
    "audit":      cmd_audit,
    "report":     cmd_report,
    "help":       cmd_help,
    "start":      cmd_help,    # /start = same as /help (Telegram convention)
}

UNAUTHORIZED_REPLY = "⛔ Not authorized."
UNKNOWN_REPLY = "Unknown command. Try /help."


def dispatch(*, text: str, user_id: int, chat_id: int = 0) -> Optional[CommandResult]:
    """Parse + authorize + dispatch one incoming message.

    Returns ``None`` when the message is not a command (we ignore it, no
    reply). Returns a :class:`CommandResult` for everything else.
    """
    parsed = _parse_command(text)
    if parsed is None:
        return None
    name, args = parsed
    if not auth.is_authorized(user_id):
        log.warning("rejected command %s from unauthorized user_id=%s", name, user_id)
        return CommandResult(UNAUTHORIZED_REPLY, ok=False)
    handler = HANDLERS.get(name)
    if handler is None:
        return CommandResult(UNKNOWN_REPLY, ok=False)
    user_name = auth.name_for(user_id) or str(user_id)
    cmd = Command(name=name, args=args, user_id=int(user_id),
                  user_name=user_name, chat_id=int(chat_id))
    log.info("cmd %s from %s args=%s", name, user_name, args)
    try:
        return handler(cmd)
    except Exception:
        log.exception("handler %s failed", name)
        return CommandResult("⚠️ Internal error - see logs.", ok=False)


# ---------------------------------------------------------------------------
# Wizard text dispatcher - for non-command messages while a wizard is active
# ---------------------------------------------------------------------------

def dispatch_text_for_wizard(
    *, text: str, user_id: int, chat_id: int,
) -> Optional[CommandResult]:
    """If the user has an active wizard expecting plain-text input
    (a value or a custom duration), advance it. Otherwise return None
    so the caller can fall back to slash-command parsing or ignore.
    """
    state = wizard.get(user_id)
    if state is None:
        return None
    if not auth.is_authorized(user_id):
        return None
    text = (text or "").strip()
    user_name = auth.name_for(user_id) or str(user_id)
    cmd = Command(name=state.flow, args=[], user_id=int(user_id),
                  user_name=user_name, chat_id=int(chat_id))
    state.touch()

    # /set wizard: typing the new value
    if state.flow == wizard.FLOW_SET and state.step == wizard.STEP_AWAIT_VALUE:
        threshold_name = state.threshold or ""
        is_duration = is_duration_threshold(threshold_name)
        default = config.DEFAULT_THRESHOLDS.get(threshold_name)
        example = example_for_default(threshold_name, default)
        try:
            if is_duration:
                # Accept both "6h" / "30m" / "45s" AND raw seconds.
                try:
                    value = float(thresholds.parse_duration(text))
                except thresholds.InvalidDuration:
                    value = float(text)
            else:
                value = float(text)
        except (ValueError, thresholds.InvalidDuration):
            hint = (
                f"a duration like <code>{example}</code> or raw seconds"
                if is_duration
                else f"a plain number, e.g. <code>{example}</code>"
            )
            return CommandResult(
                f"⚠️ '{text}' isn't a valid value. Send {hint} for "
                f"<b>{wizard.label_for(threshold_name)}</b>.",
                ok=False,
            )
        state.value = value
        state.step = wizard.STEP_PICK_DURATION
        return CommandResult(
            f"How long should the override last for <b>"
            f"{wizard.label_for(state.threshold)}</b> = "
            f"<b>{format_threshold_value(threshold_name, value)}</b>?",
            keyboard=_duration_keyboard(),
        )

    # /set wizard: typing a custom duration
    if state.flow == wizard.FLOW_SET and state.step == wizard.STEP_AWAIT_CUSTOM_DURATION:
        try:
            duration_s = thresholds.parse_duration(text)
        except thresholds.InvalidDuration as exc:
            return CommandResult(
                f"⚠️ Couldn't parse '{text}': {exc}\n"
                "Try formats like 30m, 4h, 7d, 14d.",
                ok=False,
            )
        result = _apply_set_override(
            cmd=cmd, name=state.threshold, value=state.value, duration_s=duration_s,
        )
        wizard.clear(user_id)
        return result

    # Anything else: not a wizard text step.
    return None


def _pretty(value) -> str:
    try:
        f = float(value)
        return str(int(f)) if f.is_integer() else str(f)
    except (TypeError, ValueError):
        return str(value)


# ---------------------------------------------------------------------------
# Callback-query dispatcher - handles inline-button taps
# ---------------------------------------------------------------------------

def dispatch_callback(
    *, data: str, user_id: int, chat_id: int, message_id: int,
) -> Optional[CommandResult]:
    """Handle an inline-button tap. ``data`` is the ``callback_data`` set
    on the button (we use ``flow:step:payload``)."""
    if not auth.is_authorized(user_id):
        return CommandResult(UNAUTHORIZED_REPLY, ok=False)
    user_name = auth.name_for(user_id) or str(user_id)

    if data == "wiz:cancel":
        wizard.clear(user_id)
        return CommandResult("❌ Cancelled.", edit_message_id=message_id)

    state = wizard.get(user_id)

    parts = data.split(":", 2)
    if len(parts) < 2:
        return CommandResult("Unknown button.", ok=False)
    flow, step, *rest = parts
    payload = rest[0] if rest else ""
    cmd = Command(name=flow, args=[], user_id=int(user_id),
                  user_name=user_name, chat_id=int(chat_id))

    # ── /set wizard ──────────────────────────────────────────────────────
    if flow == "set" and step == "thr":
        name = payload.upper()
        if name not in config.DEFAULT_THRESHOLDS:
            return CommandResult("Unknown threshold.", ok=False)
        wizard.start(wizard.WizardState(
            flow=wizard.FLOW_SET, step=wizard.STEP_AWAIT_VALUE,
            user_id=user_id, chat_id=chat_id, message_id=message_id,
            threshold=name,
        ))
        default = config.DEFAULT_THRESHOLDS[name]
        default_pretty = format_threshold_value(name, default)
        example = example_for_default(name, default)
        if is_duration_threshold(name):
            hint = (
                f"Send the new value as a duration (e.g. <code>{example}</code>) "
                f"or raw seconds:"
            )
        else:
            hint = f"Send the new value as a number (e.g. <code>{example}</code>):"
        return CommandResult(
            f"<b>{wizard.label_for(name)}</b>\n"
            f"Internal name: <code>{name}</code>\n"
            f"Default value: <code>{default_pretty}</code>\n\n"
            f"{hint}",
            edit_message_id=message_id,
        )

    if flow == "set" and step == "dur":
        if state is None or state.flow != wizard.FLOW_SET:
            return CommandResult("Wizard expired. Send /set to start again.", ok=False)
        if payload == "custom":
            state.step = wizard.STEP_AWAIT_CUSTOM_DURATION
            state.touch()
            return CommandResult(
                "✏️ Send a custom duration like <code>45m</code>, "
                "<code>3h</code>, <code>14d</code>:",
                edit_message_id=message_id,
            )
        try:
            duration_s = thresholds.parse_duration(payload)
        except thresholds.InvalidDuration as exc:
            return CommandResult(f"Invalid duration: {exc}", ok=False)
        if state.threshold is None or state.value is None:
            return CommandResult("Wizard state lost - please /set again.", ok=False)
        result = _apply_set_override(
            cmd=cmd, name=state.threshold, value=state.value,
            duration_s=duration_s,
        )
        wizard.clear(user_id)
        return CommandResult(result.reply, edit_message_id=message_id)

    # ── /stop wizard ─────────────────────────────────────────────────────
    if flow == "stop" and step == "key":
        # Apply the stop directly using the legacy code path.
        cmd2 = Command(name="stop", args=[payload], user_id=int(user_id),
                       user_name=user_name, chat_id=int(chat_id))
        out = cmd_stop(cmd2)
        wizard.clear(user_id)
        return CommandResult(out.reply, ok=out.ok, edit_message_id=message_id)

    # ── /resume wizard ───────────────────────────────────────────────────
    if flow == "resume" and step == "key":
        cmd2 = Command(name="resume", args=[payload], user_id=int(user_id),
                       user_name=user_name, chat_id=int(chat_id))
        out = cmd_resume(cmd2)
        wizard.clear(user_id)
        return CommandResult(out.reply, ok=out.ok, edit_message_id=message_id)

    return CommandResult("Unknown button.", ok=False)
