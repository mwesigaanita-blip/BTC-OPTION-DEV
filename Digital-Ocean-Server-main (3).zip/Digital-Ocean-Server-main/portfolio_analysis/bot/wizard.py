"""Per-user interactive wizard state for the Telegram bot.

Holds short-lived in-memory state for multi-step flows like ``/set``,
``/stop``, ``/resume``. State is keyed by Telegram ``user_id`` and
auto-expires after 10 minutes of idleness so a user who walks away
doesn't get stuck mid-flow.

Thread-safe - the bot's long-poll loop is single-threaded today, but
this is cheap insurance and lets tests poke at the dict directly.
"""
from __future__ import annotations

import threading
import time
from dataclasses import dataclass, field
from typing import Optional

__all__ = [
    "WizardState",
    "get",
    "start",
    "clear",
    "purge_expired",
    # step names
    "STEP_PICK_THRESHOLD",
    "STEP_AWAIT_VALUE",
    "STEP_PICK_DURATION",
    "STEP_AWAIT_CUSTOM_DURATION",
    "STEP_PICK_KEY",
    # flows
    "FLOW_SET",
    "FLOW_STOP",
    "FLOW_RESUME",
    # duration presets
    "DURATION_PRESETS",
    # human labels for thresholds
    "THRESHOLD_LABELS",
    "label_for",
]

IDLE_TTL_S = 10 * 60   # wizards auto-expire after 10 min of no input

FLOW_SET     = "set"
FLOW_STOP    = "stop"
FLOW_RESUME  = "resume"

STEP_PICK_THRESHOLD          = "pick_threshold"
STEP_AWAIT_VALUE             = "await_value"
STEP_PICK_DURATION           = "pick_duration"
STEP_AWAIT_CUSTOM_DURATION   = "await_custom_duration"
STEP_PICK_KEY                = "pick_key"

# (label shown to user, duration string parser will accept)
DURATION_PRESETS: list[tuple[str, str]] = [
    ("30 min",  "30m"),
    ("1 hour",  "1h"),
    ("7 hours", "7h"),
    ("1 day",   "1d"),
    ("2 days",  "2d"),
    ("1 week",  "7d"),
    ("1 month", "30d"),
]


# Friendly labels for each overrideable threshold. Used by:
#   • the /set wizard button keyboard (so users see "💰 Margin warning %"
#     instead of "MM_WARN_PCT")
#   • the /thresholds reply
#   • the Streamlit Portfolio Analysis Bot page
#
# Keep these short - Telegram inline buttons truncate around 32 visible
# characters depending on font / device.
THRESHOLD_LABELS: dict[str, str] = {
    "MM_WARN_PCT":     "💰 Margin warning %",
    "MM_URGENT_PCT":   "💰 Margin urgent %",
    "MM_CRITICAL_PCT": "💰 Margin critical %",

    "DELTA_GOOD_BTC":     "📐 Delta good (BTC)",
    "DELTA_WARN_BTC":     "📐 Delta warning (BTC)",
    "DELTA_CRITICAL_BTC": "📐 Delta critical (BTC)",

    "DTE_WARN_DAYS":     "⏳ Days-to-expiry warning",
    "DTE_CRITICAL_DAYS": "⏳ Days-to-expiry critical",

    "HEARTBEAT_RELAX_S":             "🔔 Heartbeat: Relax",
    "HEARTBEAT_TAKE_A_LOOK_S":       "🔔 Heartbeat: Take a look",
    "HEARTBEAT_ACTIVE_MONITORING_S": "🔔 Heartbeat: Active monitor",
    "HEARTBEAT_URGENT_ACTION_S":     "🔔 Heartbeat: Urgent action",
}


def label_for(name: str) -> str:
    """Friendly display label for ``name``, or the name itself if unknown."""
    return THRESHOLD_LABELS.get(name, name)


@dataclass
class WizardState:
    flow: str
    step: str
    user_id: int
    chat_id: int
    message_id: Optional[int] = None       # for edit-in-place
    threshold: Optional[str] = None
    value: Optional[float] = None
    last_touched: float = field(default_factory=time.time)

    def touch(self) -> None:
        self.last_touched = time.time()


_lock = threading.Lock()
_wizards: dict[int, WizardState] = {}


def get(user_id: int) -> Optional[WizardState]:
    """Return the active wizard for this user, or ``None``.

    Auto-expires + clears stale entries.
    """
    with _lock:
        s = _wizards.get(int(user_id))
        if s is None:
            return None
        if time.time() - s.last_touched > IDLE_TTL_S:
            _wizards.pop(int(user_id), None)
            return None
        return s


def start(state: WizardState) -> WizardState:
    """Replace any existing wizard for this user with ``state``."""
    with _lock:
        _wizards[int(state.user_id)] = state
    return state


def clear(user_id: int) -> None:
    with _lock:
        _wizards.pop(int(user_id), None)


def purge_expired() -> int:
    """Drop every state older than ``IDLE_TTL_S``. Returns count purged."""
    cutoff = time.time() - IDLE_TTL_S
    with _lock:
        stale = [uid for uid, s in _wizards.items() if s.last_touched < cutoff]
        for uid in stale:
            _wizards.pop(uid, None)
    return len(stale)
