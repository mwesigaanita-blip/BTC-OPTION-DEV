"""VolTickWorker - periodic HV / IV / spot recorder.

Pulls Deribit's BTC historical-volatility latest sample, DVOL latest hourly
close, and the BTC index price every ``VOL_TICK_INTERVAL_S`` seconds and
appends one row to ``vol_ticks`` in ``portfolio_analysis.sqlite``.

On first run (empty table) it backfills ``VOL_TICK_BACKFILL_DAYS`` of
hourly history before entering the live loop. Backfill failures are
logged and skipped - they never block forward collection.

Set ``VOL_TICK_ENABLED=0`` to keep the thread idle without touching code.
"""

from __future__ import annotations

import os
import threading
import time
from typing import Optional

from portfolio_analysis import storage
from portfolio_analysis_AI_Agent.tools.jobs.vol_tick import (
    backfill_vol_history,
    collect_vol_tick,
)
from realtime._logging import get_logger

__all__ = ["VolTickWorker", "TICK_INTERVAL_S"]

log = get_logger("portfolio_analysis.vol_worker")

TICK_INTERVAL_S = float(os.environ.get("VOL_TICK_INTERVAL_S", "300"))
BACKFILL_DAYS = int(os.environ.get("VOL_TICK_BACKFILL_DAYS", "90"))
ENABLED = os.environ.get("VOL_TICK_ENABLED", "1").lower() not in ("0", "false", "no")

_LOG_EVERY = 12  # ~one INFO per hour at the default 5-min cadence


class VolTickWorker:
    """Daemon thread that records one HV/IV sample per interval."""

    def __init__(
        self,
        *,
        interval_s: float = TICK_INTERVAL_S,
        backfill_days: int = BACKFILL_DAYS,
        stop_event: Optional[threading.Event] = None,
    ) -> None:
        self.interval_s = float(interval_s)
        self.backfill_days = int(backfill_days)
        self.stop_event = stop_event or threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._tick_count = 0

    # ------------------------------------------------------------------

    def start(self) -> None:
        if not ENABLED:
            log.info("VolTickWorker disabled via VOL_TICK_ENABLED=0")
            return
        if self._thread is not None and self._thread.is_alive():
            return
        self._thread = threading.Thread(
            target=self._loop, name="portfolio-analysis-vol-tick", daemon=True,
        )
        self._thread.start()
        log.info(
            "VolTickWorker started (interval=%.0fs backfill=%dd)",
            self.interval_s, self.backfill_days,
        )

    def stop(self, timeout: float = 5.0) -> None:
        self.stop_event.set()
        if self._thread is not None:
            self._thread.join(timeout=timeout)
            log.info("VolTickWorker stopped")

    # ------------------------------------------------------------------

    def _maybe_backfill(self) -> None:
        """Seed historical rows once, before the periodic loop begins."""
        if self.backfill_days <= 0:
            return
        try:
            if storage.count_vol_ticks() > 0:
                return
            log.info("vol_ticks empty - backfilling %d days from Deribit...", self.backfill_days)
            rows = backfill_vol_history(self.backfill_days)
            n = storage.insert_vol_ticks_bulk(rows)
            log.info("vol_ticks backfill complete: %d rows inserted", n)
        except Exception:
            log.exception("vol_ticks backfill failed; proceeding with live collection")

    def _loop(self) -> None:
        storage.init_db()
        self._maybe_backfill()

        while not self.stop_event.is_set():
            try:
                row = collect_vol_tick()
                if row is not None:
                    storage.insert_vol_tick(**row)
                    self._tick_count += 1
                    if self._tick_count % _LOG_EVERY == 1:
                        log.info(
                            "vol_tick #%d hv30=%s iv30=%s btc=%s",
                            self._tick_count,
                            row.get("hv30"), row.get("iv30"), row.get("btc_price"),
                        )
                else:
                    log.warning("collect_vol_tick returned None - Deribit unreachable?")
            except Exception:
                log.exception("VolTickWorker tick failed; continuing")

            # stop_event.wait() unblocks instantly on SIGTERM.
            if self.stop_event.wait(self.interval_s):
                break
