"""Rule 1 - maintenance margin (MM%) pressure."""
from __future__ import annotations

from typing import Optional

from portfolio_analysis.features import FeatureBundle
from portfolio_analysis.rules.base import Alert, INFO, URGENT, WARNING

NAME = "MM_PRESSURE"


class MMPressureRule:
    name: str = NAME

    def evaluate(self, fb: FeatureBundle, t) -> list[Alert]:
        mm = fb.mm_pct
        if mm is None:
            return []

        warn = t.get("MM_WARN_PCT")
        urg = t.get("MM_URGENT_PCT")
        crit = t.get("MM_CRITICAL_PCT")

        band: Optional[str]
        severity: Optional[str]
        if mm >= crit:
            band, severity = "critical", URGENT
        elif mm >= urg:
            band, severity = "warning", WARNING
        elif mm >= warn:
            band, severity = "attention", INFO
        else:
            return []

        floor = _band_floor(band, warn, urg, crit)
        explanation = (
            f"Maintenance margin measures how close the account is to forced "
            f"liquidation: 0% = fully collateralised, 100% = liquidated. "
            f"At {mm:.2f}% you've crossed the {band.upper()} threshold ({floor}%)."
        )
        suggestion = {
            "attention": (
                f"Routine watch. If MM% keeps climbing toward {urg}%, reduce "
                f"leverage or add collateral before it escalates."
            ),
            "warning": (
                f"Action recommended: reduce leverage or add collateral to bring "
                f"MM% back below {warn}% before it hits the URGENT band ({crit}%)."
            ),
            "critical": (
                "Imminent liquidation risk. Add collateral or close positions "
                "immediately."
            ),
        }[band]

        return [Alert(
            rule=NAME,
            severity=severity,
            dedup_key=f"MM:band={band}",
            cited_features=["mm_pct"],
            feature_values={
                "mm_pct": round(float(mm), 4),
                "thresholds": {"warn": warn, "urgent": urg, "critical": crit},
            },
            message=f"Maintenance margin {mm:.2f}% - {band} band (≥ {floor}%).",
            explanation=explanation,
            suggestion=suggestion,
        )]


def _band_floor(band: str, warn, urg, crit):
    return {"attention": warn, "warning": urg, "critical": crit}[band]
