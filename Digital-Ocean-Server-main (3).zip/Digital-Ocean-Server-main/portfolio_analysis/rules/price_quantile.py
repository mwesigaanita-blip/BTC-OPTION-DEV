"""Rule 5 - quantile-based BTC price-change classifier.

Per timeframe in {7d, 15d, 30d}: outside-IQR → WARNING.

Short-horizon timeframes (1h, 4h, 1d) are handled by the combined
σ + IQR rule (:mod:`portfolio_analysis.rules.combined`); we skip them
here to avoid double-firing.
"""
from __future__ import annotations

from portfolio_analysis.features import FeatureBundle
from portfolio_analysis.rules.base import Alert, WARNING

NAME = "PRICE_QUANTILE"

# Short-horizon timeframes are owned by the combined σ + IQR rule
# (rules/combined.py). This rule fires only on the long horizons.
_SKIP_TIMEFRAMES: frozenset[str] = frozenset({"1h", "4h", "1d"})


class PriceQuantileRule:
    name: str = NAME

    def evaluate(self, fb: FeatureBundle, t) -> list[Alert]:
        out: list[Alert] = []
        for tf, ret in fb.price_change.returns.items():
            if tf in _SKIP_TIMEFRAMES:
                continue
            qs = fb.price_change.quantiles.get(tf)
            if ret is None or qs is None:
                continue
            q1, med, q3 = qs
            if ret > q3:
                direction = "high"
            elif ret < q1:
                direction = "low"
            else:
                continue
            tf_word = {
                "1h": "hourly", "4h": "4-hour", "1d": "daily",
                "7d": "weekly", "15d": "15-day", "30d": "30-day",
            }.get(tf, tf)
            tail = "top 25%" if direction == "high" else "bottom 25%"
            explanation = (
                f"Over the last 90 days the middle 50% of BTC {tf_word} returns "
                f"have been between {q1:+.2f}% and {q3:+.2f}% (median "
                f"{med:+.2f}%). The current {tf} return of {ret:+.2f}% falls in "
                f"the {tail} of recent moves - statistically unusual but not "
                f"necessarily extreme. Treat it as a 'something's different' "
                f"signal, not a buy/sell call."
            )
            suggestion = (
                "Check whether positions are correctly hedged for this size of "
                "move. If it stretches further the σ-based VOL_SIGMA rule will "
                "escalate to URGENT. Auto-resolves once the return falls back "
                "inside the typical band."
            )
            out.append(Alert(
                rule=NAME,
                severity=WARNING,
                dedup_key=f"QUANTILE:{tf}:dir={direction}",
                cited_features=[f"btc_ret_{tf}", f"q1_{tf}", f"q3_{tf}"],
                feature_values={
                    f"btc_ret_{tf}":  round(float(ret), 4),
                    f"q1_{tf}":       round(float(q1), 4),
                    f"median_{tf}":   round(float(med), 4),
                    f"q3_{tf}":       round(float(q3), 4),
                },
                message=(
                    f"BTC {tf} return {ret:+.2f}% is outside IQR "
                    f"[{q1:.2f}%, {q3:.2f}%] (median {med:+.2f}%)."
                ),
                explanation=explanation,
                suggestion=suggestion,
            ))
        return out
