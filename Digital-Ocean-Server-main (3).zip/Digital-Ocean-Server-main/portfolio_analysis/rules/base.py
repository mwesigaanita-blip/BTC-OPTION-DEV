"""Rule contract used by every rule module."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Protocol

from portfolio_analysis.features import FeatureBundle

__all__ = [
    "Severity",
    "Alert",
    "Rule",
]

# Severity tiers - order matters for Calm Score classification (Phase 5).
INFO:      str = "INFO"
WARNING:   str = "WARNING"
URGENT:    str = "URGENT"
EMERGENCY: str = "EMERGENCY"
SEVERITIES: tuple[str, ...] = (INFO, WARNING, URGENT, EMERGENCY)


@dataclass(frozen=True)
class Alert:
    """One alert candidate emitted by a rule.

    ``message`` is the single-line headline (kept short for log lines and
    push-notification previews). ``explanation`` is a 1-3 sentence,
    plain-English description of *why* this fired. ``suggestion`` is a
    short hint at what the user might do about it. The notifier renders
    all three into the Telegram message.
    """
    rule: str
    severity: str
    dedup_key: str
    cited_features: list[str]
    feature_values: dict[str, Any]
    message: str
    explanation: str = ""
    suggestion: str = ""


# Light alias - the rules pass ``portfolio_analysis.thresholds`` directly.
class ThresholdResolver(Protocol):
    def get(self, name: str) -> float | int: ...


class Rule(Protocol):
    name: str
    def evaluate(self, fb: FeatureBundle, t: ThresholdResolver) -> list[Alert]: ...


# Convenience: a Severity type alias for callers that want a string-y enum.
@dataclass(frozen=True)
class _SeverityNS:
    INFO: str = INFO
    WARNING: str = WARNING
    URGENT: str = URGENT
    EMERGENCY: str = EMERGENCY


Severity = _SeverityNS()
