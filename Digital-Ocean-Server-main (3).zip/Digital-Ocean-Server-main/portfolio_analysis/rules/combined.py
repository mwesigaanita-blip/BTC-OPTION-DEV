"""Combined σ + IQR rule - fires one alert per timeframe per band-cross.

Runs on the timeframes where both σ and IQR have coverage:

  * 1h, 4h           - both rules use the same buffer key
  * 24h (daily)      - σ uses the ``24h`` buffer, IQR uses the ``1d`` buffer
                        (same horizon, separate keys for historical reasons)

Severity mapping (per spec):

  * STRONG → URGENT
  * MEDIUM → WARNING
  * WEAK   → INFO
  * NORMAL → no alert
"""
from __future__ import annotations

from portfolio_analysis import config
from portfolio_analysis.combined_signal import (
    CombinedLevel,
    classify_combined_signal,
    severity_for_level,
)
from portfolio_analysis.features import FeatureBundle
from portfolio_analysis.rules.base import Alert

NAME = "COMBINED_SIGNAL"

# Timeframes the combined classifier covers. For 24h the σ side reads
# the ``24h`` buffer and the IQR side reads the ``1d`` buffer (both
# stored in returns_history).
COMBINED_TIMEFRAMES: tuple[str, ...] = ("1h", "4h", "24h")
_IQR_KEY_FOR: dict[str, str] = {
    "1h":  "1h",
    "4h":  "4h",
    "24h": "1d",
}


class CombinedSignalRule:
    name: str = NAME

    def evaluate(self, fb: FeatureBundle, t) -> list[Alert]:
        out: list[Alert] = []
        for tf in COMBINED_TIMEFRAMES:
            ret = fb.market.returns.get(tf)
            sigma = fb.market.sigmas.get(tf)
            if ret is None or sigma is None or sigma <= 0:
                continue

            z = ret / sigma

            # IQR side - different buffer key for daily.
            iqr_tf = _IQR_KEY_FOR.get(tf, tf)
            iqr_ret = fb.price_change.returns.get(iqr_tf)
            qs = fb.price_change.quantiles.get(iqr_tf)

            iqr_position = "normal"
            if qs is not None and iqr_ret is not None:
                q1, _, q3 = qs
                if iqr_ret > q3:
                    iqr_position = "high"
                elif iqr_ret < q1:
                    iqr_position = "low"

            sig = classify_combined_signal(z, iqr_position)
            level: CombinedLevel = sig["level"]
            if level == "NORMAL":
                continue

            severity = severity_for_level(level)
            sign = "+" if ret > 0 else "-"
            dedup_key = f"COMBINED:{tf}:dir={sign}:level={level}"

            tf_word = {"1h": "1-hour", "4h": "4-hour", "24h": "daily"}.get(tf, tf)
            iqr_phrase = {
                "high": "in the top 25 % of recent moves",
                "low":  "in the bottom 25 % of recent moves",
                "normal": "inside the typical 25–75 % band",
            }[iqr_position]

            evidence: list[str] = []
            if abs(z) > config.SIGMA_CRITICAL_MULT:
                evidence.append(f"σ-rule: {z:+.2f}σ (> 2σ)")
            else:
                evidence.append(f"σ-rule: {z:+.2f}σ (within 2σ)")
            evidence.append(f"IQR-rule: {iqr_phrase}")

            level_blurb = {
                "STRONG": (
                    "Both σ and IQR flag this move - it is statistically large "
                    "AND in the tails of recent moves. High-confidence signal."
                ),
                "MEDIUM": (
                    "σ flags this as large in standard-deviation terms, but "
                    "the move is still inside the typical IQR. Likely a fast "
                    "spike rather than a regime change."
                ),
                "WEAK": (
                    "The move sits in the tails of the recent-90d distribution "
                    "but is not large in σ terms. A 'something's different' "
                    "signal - not a panic."
                ),
            }[level]

            explanation = (
                f"BTC moved {ret:+.2f}% over the {tf_word} window. "
                f"Combined classifier: <b>{level}</b>.\n"
                f"  • {evidence[0]}\n"
                f"  • {evidence[1]}\n\n"
                f"{level_blurb}"
            )

            suggestion_by_level = {
                "STRONG": (
                    "Verify positions and the liquidation buffer now. Strong "
                    "signals frequently pair with funding-rate spikes and "
                    "worse slippage."
                ),
                "MEDIUM": (
                    "Check positions are sized for moves of this magnitude. "
                    "Auto-resolves when the return falls back inside ±2σ."
                ),
                "WEAK": (
                    "Treat as an awareness signal. If σ catches up the "
                    "combined level will escalate to MEDIUM/STRONG."
                ),
            }[level]

            out.append(Alert(
                rule=NAME,
                severity=severity,
                dedup_key=dedup_key,
                cited_features=[
                    f"btc_ret_{tf}", f"sigma_{tf}", f"z_{tf}",
                    f"iqr_position_{iqr_tf}",
                ],
                feature_values={
                    f"btc_ret_{tf}":           round(float(ret), 4),
                    f"sigma_{tf}":             round(float(sigma), 4),
                    "z":                       round(float(z), 3),
                    f"iqr_position_{iqr_tf}":  iqr_position,
                    "combined_level":          level,
                },
                message=(
                    f"BTC {tf} {ret:+.2f}% - {level} signal "
                    f"(z={z:+.2f}σ, IQR {iqr_position})."
                ),
                explanation=explanation,
                suggestion=suggestion_by_level,
            ))
        return out
