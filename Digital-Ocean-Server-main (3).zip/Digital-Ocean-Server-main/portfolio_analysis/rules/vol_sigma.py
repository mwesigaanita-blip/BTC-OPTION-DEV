"""Rule 4 - σ-based volatility / movement classifier.

Per timeframe in {1h, 4h, 24h}, compares the current return to the live
σ from the rolling 90-day buffer. Bands (multipliers fixed in code):

  Normal      |z| <= 1σ
  Warning     1σ < |z| <= 2σ      → WARNING
  Critical    2σ < |z| <= 3σ      → URGENT
  Extreme     |z| > 3σ            → URGENT (separate dedup bucket)
"""
from __future__ import annotations

from portfolio_analysis import config
from portfolio_analysis.features import FeatureBundle
from portfolio_analysis.rules.base import Alert, URGENT, WARNING

NAME = "VOL_SIGMA"


class VolSigmaRule:
    name: str = NAME

    def evaluate(self, fb: FeatureBundle, t) -> list[Alert]:
        out: list[Alert] = []
        for tf, ret in fb.market.returns.items():
            sigma = fb.market.sigmas.get(tf)
            if ret is None or sigma is None or sigma <= 0:
                continue
            z = ret / sigma
            az = abs(z)
            if az <= config.SIGMA_WARNING_MULT:
                continue
            if az > config.SIGMA_EXTREME_MULT:
                band, severity = "extreme", URGENT
            elif az > config.SIGMA_CRITICAL_MULT:
                band, severity = "critical", URGENT
            else:
                band, severity = "warning", WARNING
            sign = "+" if ret > 0 else "-"
            tf_word = {"1h": "hourly", "4h": "4-hour", "24h": "24-hour"}.get(tf, tf)
            rarity = {
                "warning":  "more extreme than roughly 68% of recent moves",
                "critical": "more extreme than roughly 95% of recent moves",
                "extreme":  "more extreme than roughly 99.7% of recent moves - about a 1-in-1000 event",
            }[band]
            from portfolio_analysis.features.market import sigma_lookback_hours
            lookback_h = sigma_lookback_hours(tf)
            window_word = (
                f"{lookback_h // 24}-day" if lookback_h % 24 == 0 and lookback_h >= 24
                else f"{lookback_h}-hour"
            )
            explanation = (
                f"BTC moved {ret:+.2f}% over the last {tf_word} window. The "
                f"rolling {window_word} standard deviation of {tf} returns is "
                f"{sigma:.2f}%, so this move is {z:+.2f}σ - {rarity}. The "
                f"{band.upper()} band starts at "
                f"{_band_floor_mult(band):.0f}σ."
            )
            suggestion = (
                "Verify positions and the liquidation buffer now. Large moves "
                "often pair with funding-rate spikes and worse slippage."
                if band in ("critical", "extreme") else
                "Check positions are hedged for moves of this magnitude. "
                "Auto-resolves when the return falls back inside ±1σ."
            )
            out.append(Alert(
                rule=NAME,
                severity=severity,
                dedup_key=f"VOL:{tf}:dir={sign}:band={band}",
                cited_features=[f"btc_ret_{tf}", f"sigma_{tf}"],
                feature_values={
                    f"btc_ret_{tf}":  round(float(ret), 4),
                    f"sigma_{tf}":    round(float(sigma), 4),
                    "z":              round(float(z), 3),
                },
                message=(
                    f"BTC {tf} return {ret:+.2f}% = {z:+.2f}σ - {band} band."
                ),
                explanation=explanation,
                suggestion=suggestion,
            ))
        return out


def _band_floor_mult(band: str) -> float:
    return {
        "warning":  config.SIGMA_WARNING_MULT,
        "critical": config.SIGMA_CRITICAL_MULT,
        "extreme":  config.SIGMA_EXTREME_MULT,
    }[band]
