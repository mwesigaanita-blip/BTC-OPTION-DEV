"""Rules engine - registry + dedup + resolution.

Public API:

    ALL_RULES                              - list of registered Rule instances
    evaluate_all(fb, t)                    - run every rule, return Alert candidates
    dedup_and_persist(candidates, ts_utc)  - insert non-duplicate, non-suppressed alerts
    resolve_cleared(active_keys, ts_utc)   - resolve open alerts no longer triggered;
                                             clear matching suppressions
"""
from __future__ import annotations

from typing import Iterable

from portfolio_analysis import storage, thresholds
from portfolio_analysis.features import FeatureBundle
from portfolio_analysis.rules.base import Alert, Rule
from portfolio_analysis.rules.combined import CombinedSignalRule
from portfolio_analysis.rules.delta_drift import DeltaDriftRule
from portfolio_analysis.rules.dte_risk import DTERiskRule
from portfolio_analysis.rules.mm_pressure import MMPressureRule
from portfolio_analysis.rules.price_quantile import PriceQuantileRule
from portfolio_analysis.rules.vol_sigma import VolSigmaRule  # kept importable for tests

__all__ = [
    "ALL_RULES",
    "Alert",
    "Rule",
    "evaluate_all",
    "dedup_and_persist",
    "resolve_cleared",
]

# Rule 6 is intentionally NOT registered (placeholder).
#
# Price-return rules are TEMPORARILY DISABLED while we tune the σ + IQR
# pipeline (downsampling, σ floor, cooldowns). Their classes remain
# importable so tests / replay can exercise them in isolation, and so
# this is a one-line revert when we want them back.
#
#   * VOL_SIGMA       - disabled (its job moved into COMBINED_SIGNAL anyway)
#   * COMBINED_SIGNAL - disabled (1h/4h/24h price-return alerts)
#   * PRICE_QUANTILE  - disabled (7d/15d/30d price-return alerts)
ALL_RULES: list[Rule] = [
    MMPressureRule(),
    DeltaDriftRule(),
    DTERiskRule(),
    # CombinedSignalRule(),   # ← re-enable when ready
    # PriceQuantileRule(),    # ← re-enable when ready
]


# ---------------------------------------------------------------------------
# Engine entry points
# ---------------------------------------------------------------------------

def evaluate_all(fb: FeatureBundle) -> list[Alert]:
    """Run every registered rule, returning the union of all candidate alerts."""
    out: list[Alert] = []
    for rule in ALL_RULES:
        out.extend(rule.evaluate(fb, thresholds))
    return out


def dedup_and_persist(candidates: Iterable[Alert], ts_utc: str) -> list[int]:
    """Insert any candidate whose ``dedup_key`` is not already active.

    "Already active" = either (a) an unresolved alert row exists for the
    key, or (b) an active suppression exists for the key. Returns the list
    of new alert row ids.
    """
    open_keys = {row["dedup_key"] for row in storage.unresolved_alerts()}
    suppressed_keys = {row["dedup_key"] for row in storage.active_suppressions()}
    skip = open_keys | suppressed_keys
    inserted: list[int] = []
    for alert in candidates:
        if alert.dedup_key in skip:
            continue
        # The COMBINED_SIGNAL rule stashes its level in feature_values so the
        # column gets populated without changing the Alert dataclass shape.
        combined_level = alert.feature_values.get("combined_level")
        aid = storage.insert_alert(
            ts_utc=ts_utc,
            rule=alert.rule,
            severity=alert.severity,
            dedup_key=alert.dedup_key,
            cited_features=alert.cited_features,
            feature_values=alert.feature_values,
            message=alert.message,
            combined_level=combined_level,
        )
        if aid is not None:
            inserted.append(aid)
            # Track within this batch so a duplicate dedup_key produced by
            # two rules in the same cycle inserts only once.
            skip.add(alert.dedup_key)
    return inserted


def resolve_cleared(active_keys: set[str], ts_utc: str) -> tuple[list[int], list[str]]:
    """Resolve open alerts whose dedup_key is no longer in ``active_keys``.

    Also clears any matching suppressions (per plan.md §4: "the worker
    stamps resolved_at_utc on the open alert AND clears any matching
    suppression").

    Returns ``(resolved_ids, cleared_dedup_keys)``.
    """
    resolved_ids: list[int] = []
    for row in storage.unresolved_alerts():
        if row["dedup_key"] not in active_keys:
            storage.resolve_alert(alert_id=row["id"], resolved_at_utc=ts_utc)
            resolved_ids.append(row["id"])

    cleared_keys: list[str] = []
    for row in storage.active_suppressions():
        if row["dedup_key"] not in active_keys:
            n = storage.clear_suppression(dedup_key=row["dedup_key"], cleared_at_utc=ts_utc)
            if n > 0:
                cleared_keys.append(row["dedup_key"])
    return resolved_ids, cleared_keys
