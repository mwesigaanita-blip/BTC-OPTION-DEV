"""Rule 6 - PENDING.

Reserved placeholder per plan.md §Rule 6. The module exists so callers
that try to load it surface a deliberate error rather than a missing-
import. Not registered in ``ALL_RULES``.
"""
from __future__ import annotations


class Rule6Pending:
    name: str = "RULE_6_PENDING"

    def evaluate(self, fb, t):  # pragma: no cover - intentionally unreachable
        raise NotImplementedError("Rule 6 is pending and not yet specified.")


def load() -> "Rule6Pending":
    """Public loader - always raises."""
    raise NotImplementedError("Rule 6 is pending and not yet specified.")
