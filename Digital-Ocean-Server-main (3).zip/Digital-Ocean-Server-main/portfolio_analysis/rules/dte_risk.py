"""Rule 3 - time-to-expiry per option position.

Fires once per option position (instrument_name in dedup key) at the
warning or critical band.
"""
from __future__ import annotations

from portfolio_analysis.features import FeatureBundle
from portfolio_analysis.rules.base import Alert, URGENT, WARNING

NAME = "DTE_RISK"


class DTERiskRule:
    name: str = NAME

    def evaluate(self, fb: FeatureBundle, t) -> list[Alert]:
        if not fb.positions:
            return []

        warn = t.get("DTE_WARN_DAYS")
        crit = t.get("DTE_CRITICAL_DAYS")
        out: list[Alert] = []
        for p in fb.positions:
            dte = p.dte_days
            if dte > warn:
                continue
            if dte <= crit:
                band, severity = "critical", URGENT
            else:
                band, severity = "warning", WARNING
            distance = p.distance_to_strike_pct
            explanation = (
                f"This {p.side.lower()} {p.option_type} option has only {dte:.1f} "
                f"days left until expiry. As DTE shrinks, gamma and theta risk "
                f"accelerate sharply - the option's price becomes much more "
                f"sensitive to BTC moves and time decay. The {band.upper()} "
                f"threshold is ≤ {crit if band == 'critical' else warn} days. "
                f"Spot is currently {abs(distance):.1f}% "
                f"{'above' if distance > 0 else 'below'} the strike."
            )
            suggestion = (
                "Decide whether to roll to a later expiry, close the position, "
                "or accept the assignment / settlement risk. Strikes near spot "
                "carry the largest risk during the final week."
                if band == "critical" else
                f"This option enters the CRITICAL band at ≤ {crit} days. Plan a "
                "roll or close before then if you don't want pin/assignment risk."
            )
            out.append(Alert(
                rule=NAME,
                severity=severity,
                dedup_key=f"DTE:{p.instrument_name}:band={band}",
                cited_features=["dte_days", "instrument_name", "side", "option_type", "strike"],
                feature_values={
                    "instrument_name": p.instrument_name,
                    "dte_days": round(float(dte), 3),
                    "strike": p.strike,
                    "option_type": p.option_type,
                    "side": p.side,
                    "distance_to_strike_pct": round(float(p.distance_to_strike_pct), 3),
                    "thresholds": {"warn": warn, "critical": crit},
                },
                message=(
                    f"{p.instrument_name} ({p.side} {p.option_type}) "
                    f"has {dte:.1f}d to expiry - {band} band."
                ),
                explanation=explanation,
                suggestion=suggestion,
            ))
        return out
