"""Rule 2 - delta drift (absolute, BTC).

Bands (per plan.md):
  Good          : abs(delta) <= DELTA_GOOD_BTC                              → no alert
  Warning       : DELTA_GOOD_BTC < abs(delta) <= DELTA_WARN_BTC             → WARNING
  Critical      : DELTA_WARN_BTC < abs(delta) <= DELTA_CRITICAL_BTC         → URGENT
  Beyond crit   : abs(delta) > DELTA_CRITICAL_BTC                            → URGENT (separate dedup)
"""
from __future__ import annotations

from portfolio_analysis.features import FeatureBundle
from portfolio_analysis.rules.base import Alert, URGENT, WARNING

NAME = "DELTA_DRIFT"


class DeltaDriftRule:
    name: str = NAME

    def evaluate(self, fb: FeatureBundle, t) -> list[Alert]:
        delta = fb.delta
        if delta is None:
            return []

        good = t.get("DELTA_GOOD_BTC")
        warn = t.get("DELTA_WARN_BTC")
        crit = t.get("DELTA_CRITICAL_BTC")
        a = abs(float(delta))
        sign = "+" if delta > 0 else ("-" if delta < 0 else "0")

        if a <= good:
            return []
        if a <= warn:
            band, severity = "warning", WARNING
        elif a <= crit:
            band, severity = "critical", URGENT
        else:
            band, severity = "beyond", URGENT

        direction_word = "long BTC" if delta > 0 else "short BTC"
        explanation = (
            f"Net delta is the BTC-equivalent directional exposure of every open "
            f"position summed together. {delta:+.3f} BTC means the book is "
            f"{direction_word} by that amount, so the portfolio gains/loses about "
            f"${a:.3f} for every $1 BTC moves. The GOOD band is |delta| ≤ {good}; "
            f"you're in the {band.upper()} band ({_band_range(band, good, warn, crit)})."
        )
        suggestion = {
            "warning": (
                f"Hedge a small amount: {'sell' if delta > 0 else 'buy'} "
                f"{max(a - good, 0):.3f} BTC of spot or perp to pull net delta "
                f"back inside ±{good}."
            ),
            "critical": (
                f"Significant directional bias. Hedge urgently by "
                f"{'selling' if delta > 0 else 'buying'} BTC to neutralise."
            ),
            "beyond": (
                "Delta exposure has blown past the critical threshold. Hedge "
                "immediately or close offending positions."
            ),
        }[band]

        return [Alert(
            rule=NAME,
            severity=severity,
            dedup_key=f"DELTA:sign={sign}:band={band}",
            cited_features=["delta"],
            feature_values={
                "delta": round(float(delta), 4),
                "thresholds": {"good": good, "warn": warn, "critical": crit},
            },
            message=f"Net delta {delta:+.3f} BTC - {band} band (|delta|={a:.3f}).",
            explanation=explanation,
            suggestion=suggestion,
        )]


def _band_range(band: str, good, warn, crit) -> str:
    return {
        "warning":  f"{good} < |delta| ≤ {warn}",
        "critical": f"{warn} < |delta| ≤ {crit}",
        "beyond":   f"|delta| > {crit}",
    }[band]
