"""Portfolio-analysis Telegram adapter.

Thin wrapper over :class:`hedge_engine.notifications.notifier.TelegramNotifier`.
We pass ``bypass_cooldown=True`` because dedup is already enforced by the
rules engine (Phase 4) - we never want a second cooldown on top.

Reads from .env:
  TELEGRAM_PORTFOLIO_BOT_TOKEN  - bot token from @BotFather
  TELEGRAM_CHAT_IDS             - JSON {"name": "chat_id", ...}
  DRY_RUN                       - "1" → log payload instead of posting
"""
from __future__ import annotations

import json
import os
from typing import Any, Iterable, Optional

from hedge_engine.notifications.notifier import TelegramNotifier
from portfolio_analysis.rules.base import Alert
from realtime._logging import get_logger

__all__ = [
    "format_alert_html",
    "load_chat_ids",
    "is_dry_run",
    "notify_alert",
    "send_document",
    "PortfolioNotifier",
]

log = get_logger("portfolio_analysis.notifier")

_SEVERITY_PREFIX = {
    "INFO":      "ℹ️",
    "WARNING":   "⚠️",
    "URGENT":    "🚨",
    "EMERGENCY": "🆘",
}


# ---------------------------------------------------------------------------
# Env helpers
# ---------------------------------------------------------------------------

def is_dry_run() -> bool:
    """True when DRY_RUN env var is set to a truthy value."""
    return os.getenv("DRY_RUN", "").strip().lower() in ("1", "true", "yes", "on")


def load_chat_ids() -> list[str]:
    """Parse ``TELEGRAM_CHAT_IDS`` (a JSON {name: chat_id} map) into a list
    of non-empty chat IDs. Returns ``[]`` if unset / malformed."""
    raw = os.getenv("TELEGRAM_CHAT_IDS", "").strip()
    if not raw:
        return []
    try:
        m = json.loads(raw)
    except (TypeError, ValueError) as exc:
        log.warning("TELEGRAM_CHAT_IDS is not valid JSON: %s", exc)
        return []
    if not isinstance(m, dict):
        log.warning("TELEGRAM_CHAT_IDS must be a JSON object, got %s", type(m).__name__)
        return []
    out: list[str] = []
    for name, cid in m.items():
        cid_str = str(cid or "").strip()
        if cid_str:
            out.append(cid_str)
    return out


def _load_token() -> str:
    return os.getenv("TELEGRAM_PORTFOLIO_BOT_TOKEN", "").strip()


# ---------------------------------------------------------------------------
# HTML formatting
# ---------------------------------------------------------------------------

def _esc(s: Any) -> str:
    """Telegram HTML escape (same set as plan.md template)."""
    return (
        str(s).replace("&", "&amp;")
              .replace("<", "&lt;")
              .replace(">", "&gt;")
    )


def _render_value(v: Any) -> str:
    if isinstance(v, dict):
        # Render nested dicts as compact key=value lists (e.g., thresholds={...}).
        inner = ", ".join(f"{_esc(k)}={_esc(vv)}" for k, vv in v.items())
        return inner
    if isinstance(v, float):
        return f"{v:.4f}".rstrip("0").rstrip(".")
    return _esc(v)


def format_alert_html(alert: Alert, *, ts_utc: Optional[str] = None) -> str:
    """Render one alert into the HTML template from plan.md §7.

    Layout (top to bottom):
      • Header line with severity icon + rule name
      • One-line headline (``alert.message``)
      • Optional "What this means" paragraph (``alert.explanation``)
      • Optional "What to consider" paragraph (``alert.suggestion``)
      • Cited features bullet list
      • Trailing timestamp
    """
    icon = _SEVERITY_PREFIX.get(alert.severity, "")
    header = f"<b>{icon} [{_esc(alert.severity)}] {_esc(alert.rule)}</b>"
    msg = _esc(alert.message or "")

    # Cited features: prefer the curated list; fall back to all keys.
    keys = list(alert.cited_features) or list(alert.feature_values.keys())
    bullets: list[str] = []
    for k in keys:
        if k not in alert.feature_values:
            continue
        bullets.append(f"• {_esc(k)} = {_render_value(alert.feature_values[k])}")
    # Always surface the threshold dict if present and not already cited.
    if "thresholds" in alert.feature_values and "thresholds" not in keys:
        bullets.append(f"• thresholds = {_render_value(alert.feature_values['thresholds'])}")

    parts: list[str] = [header, "", msg]
    if alert.explanation:
        parts.append("")
        parts.append("<b>📖 What this means:</b>")
        parts.append(_esc(alert.explanation))
    if alert.suggestion:
        parts.append("")
        parts.append("<b>💡 What to consider:</b>")
        parts.append(_esc(alert.suggestion))
    if bullets:
        parts.append("")
        parts.append("<b>Cited features:</b>")
        parts.extend(bullets)
    if ts_utc:
        # Human-readable footer; raw ISO is available in the alerts table.
        from portfolio_analysis._fmt import format_utc_human
        ts_utc = format_utc_human(ts_utc)
        parts.append("")
        parts.append(f"<i>{_esc(ts_utc)}</i>")
    return "\n".join(parts)


# ---------------------------------------------------------------------------
# PortfolioNotifier - wraps TelegramNotifier with DRY_RUN + bypass_cooldown
# ---------------------------------------------------------------------------

class PortfolioNotifier:
    def __init__(
        self,
        *,
        bot_token: Optional[str] = None,
        chat_ids: Optional[Iterable[str]] = None,
        dry_run: Optional[bool] = None,
    ) -> None:
        self.bot_token = bot_token if bot_token is not None else _load_token()
        self.chat_ids = list(chat_ids) if chat_ids is not None else load_chat_ids()
        self.dry_run = is_dry_run() if dry_run is None else dry_run
        self._inner = TelegramNotifier(bot_token=self.bot_token, chat_ids=self.chat_ids)

    def send_alert(self, alert: Alert, *, ts_utc: Optional[str] = None) -> bool:
        text = format_alert_html(alert, ts_utc=ts_utc)
        if self.dry_run:
            log.info(
                "DRY_RUN notify_alert rule=%s severity=%s dedup=%s payload_size=%d "
                "chats=%d\n%s",
                alert.rule, alert.severity, alert.dedup_key,
                len(text), len(self.chat_ids), text,
            )
            return True
        if not self.bot_token:
            log.warning(
                "skip notify_alert (no TELEGRAM_PORTFOLIO_BOT_TOKEN) rule=%s dedup=%s",
                alert.rule, alert.dedup_key,
            )
            return False
        if not self.chat_ids:
            log.warning(
                "skip notify_alert (no chat_ids) rule=%s dedup=%s",
                alert.rule, alert.dedup_key,
            )
            return False
        ok = self._inner.send(
            text, urgency=alert.severity,
            bypass_cooldown=True, parse_mode="HTML",
        )
        if ok:
            log.info(
                "sent alert rule=%s severity=%s dedup=%s payload_size=%d chats=%d",
                alert.rule, alert.severity, alert.dedup_key,
                len(text), len(self.chat_ids),
            )
        else:
            log.warning(
                "telegram send returned False rule=%s dedup=%s",
                alert.rule, alert.dedup_key,
            )
        return ok


# ---------------------------------------------------------------------------
# Module-level singleton + convenience function
# ---------------------------------------------------------------------------

_default_notifier: Optional[PortfolioNotifier] = None


def _get_default() -> PortfolioNotifier:
    global _default_notifier
    if _default_notifier is None:
        _default_notifier = PortfolioNotifier()
    return _default_notifier


def reset_default_notifier() -> None:
    """For tests: drop the cached singleton so the next call re-reads env."""
    global _default_notifier
    _default_notifier = None


def notify_alert(alert: Alert, *, ts_utc: Optional[str] = None) -> bool:
    """Module-level convenience used by the worker hook."""
    return _get_default().send_alert(alert, ts_utc=ts_utc)


# ---------------------------------------------------------------------------
# Document send (used by the daily PDF report - Phase 10)
# ---------------------------------------------------------------------------

def send_document(
    pdf_path: str,
    *,
    caption: Optional[str] = None,
    chat_ids: Optional[Iterable[str]] = None,
) -> list[str]:
    """Send a file via Telegram ``sendDocument`` to every chat.

    Returns the list of chat_ids that received the document. In DRY_RUN
    mode, returns ``[]`` and logs the would-send instead.
    """
    targets = list(chat_ids) if chat_ids is not None else load_chat_ids()
    if is_dry_run():
        log.info(
            "DRY_RUN send_document path=%s caption=%r chats=%d",
            pdf_path, caption, len(targets),
        )
        return []
    token = _load_token()
    if not token:
        log.warning("skip send_document (no TELEGRAM_PORTFOLIO_BOT_TOKEN) path=%s", pdf_path)
        return []
    if not targets:
        log.warning("skip send_document (no chat_ids) path=%s", pdf_path)
        return []

    import requests
    sent: list[str] = []
    url = f"https://api.telegram.org/bot{token}/sendDocument"
    for chat_id in targets:
        try:
            with open(pdf_path, "rb") as fh:
                data = {"chat_id": chat_id}
                if caption:
                    data["caption"] = caption
                r = requests.post(url, data=data, files={"document": fh}, timeout=30)
                r.raise_for_status()
            sent.append(str(chat_id))
        except Exception as exc:
            log.warning("send_document to chat=%s failed: %s", chat_id, exc)
    if sent:
        log.info("send_document path=%s caption=%r chats=%d", pdf_path, caption, len(sent))
    return sent
