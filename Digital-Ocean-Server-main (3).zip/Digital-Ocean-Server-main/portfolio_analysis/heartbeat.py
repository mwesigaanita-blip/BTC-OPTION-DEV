"""HeartbeatWorker - periodic "system alive" digest.

Cadence is driven by the current Calm Score (per plan.md §6c):

  RELAX             → every 6 h     (HEARTBEAT_RELAX_S)
  TAKE_A_LOOK       → every 2 h     (HEARTBEAT_TAKE_A_LOOK_S)
  ACTIVE_MONITORING → every 30 min  (HEARTBEAT_ACTIVE_MONITORING_S)
  URGENT_ACTION     → every 1 min   (HEARTBEAT_URGENT_ACTION_S)

The cadence values are read live from ``thresholds.get`` so a Telegram
override (``/set HEARTBEAT_RELAX_S 60 1h``) takes effect on the next
tick - useful for smoke-testing.

The "last sent" timestamp is persisted in the latest ``state_history``
row's ``last_notified_utc`` column, so a process restart doesn't
re-send immediately.
"""
from __future__ import annotations

import sqlite3
import threading
import time
from datetime import datetime, timezone
from typing import Optional

from portfolio_analysis import notifier as _notifier
from portfolio_analysis import storage, thresholds
from portfolio_analysis.bot.broadcast import broadcast
from portfolio_analysis.state import CalmState
from realtime._logging import get_logger

__all__ = [
    "HeartbeatWorker",
    "tick_once",
    "format_heartbeat",
    "TICK_INTERVAL_S",
]

log = get_logger("portfolio_analysis.heartbeat")

TICK_INTERVAL_S = 10.0   # how often to check whether a heartbeat is due


# ---------------------------------------------------------------------------
# Time helpers (broken out so tests can monkeypatch)
# ---------------------------------------------------------------------------

def _now_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f") + "Z"


def _parse_iso(s: str) -> Optional[datetime]:
    try:
        if s.endswith("Z"):
            s = s[:-1]
        if "." not in s:
            s += ".000000"
        return datetime.fromisoformat(s).replace(tzinfo=timezone.utc)
    except (ValueError, AttributeError):
        return None


# ---------------------------------------------------------------------------
# Cadence
# ---------------------------------------------------------------------------

_CADENCE_KEYS = {
    CalmState.RELAX:             "HEARTBEAT_RELAX_S",
    CalmState.TAKE_A_LOOK:       "HEARTBEAT_TAKE_A_LOOK_S",
    CalmState.ACTIVE_MONITORING: "HEARTBEAT_ACTIVE_MONITORING_S",
    CalmState.URGENT_ACTION:     "HEARTBEAT_URGENT_ACTION_S",
}


def _cadence_for(state_value: str) -> int:
    """Resolve the heartbeat cadence (seconds) for a Calm Score string."""
    try:
        state = CalmState(state_value)
    except ValueError:
        return int(thresholds.get("HEARTBEAT_RELAX_S"))
    return int(thresholds.get(_CADENCE_KEYS[state]))


# ---------------------------------------------------------------------------
# Digest format
# ---------------------------------------------------------------------------

_CALM_HEADER = {
    "RELAX":             "RELAX",
    "TAKE_A_LOOK":       "TAKE A LOOK",
    "ACTIVE_MONITORING": "ACTIVE MONITORING",
    "URGENT_ACTION":     "URGENT ACTION",
}


def format_heartbeat(
    *,
    calm_score: str,
    reasoning: Optional[str],   # kept for API compatibility (unused - we render fresh)
    active_alerts: list[sqlite3.Row],
    suppressions: list[sqlite3.Row],
    ts_utc: str,
) -> str:
    """Render the heartbeat digest as a polished, HTML-formatted message.

    Sections:
      • Header  - Calm Score with state-colored emoji
      • Active alerts - one human-labelled line each, with severity icon
      • Being handled - suppressions per-user (only when present)
      • Footer  - readable UTC timestamp
    """
    from portfolio_analysis._fmt import (
        format_utc_human, human_label_for_dedup_key, severity_icon,
    )

    header = _CALM_HEADER.get(calm_score, calm_score)
    lines: list[str] = [f"<b>🔔 Heartbeat - {header}</b>"]

    # Active alerts - sort by severity (most → least), then by dedup_key.
    severity_rank = {"EMERGENCY": 0, "URGENT": 1, "WARNING": 2, "INFO": 3}

    def _sort_key(a):
        return (severity_rank.get(a["severity"], 99), a["dedup_key"])

    if active_alerts:
        sorted_alerts = sorted(active_alerts, key=_sort_key)
        suppressed_keys = {s["dedup_key"] for s in suppressions}
        suppressed_user_by_key = {
            s["dedup_key"]: s["set_by_user_name"] for s in suppressions
        }
        lines.append(f"\n<b>Active alerts ({len(active_alerts)}):</b>")
        for a in sorted_alerts:
            icon = severity_icon(a["severity"])
            label = human_label_for_dedup_key(a["dedup_key"])
            if a["dedup_key"] in suppressed_keys:
                user = suppressed_user_by_key.get(a["dedup_key"], "?")
                lines.append(f"  {icon} {label} <i>(handled by {user})</i>")
            else:
                lines.append(f"  {icon} {label}")
    else:
        lines.append("\n<b>Active alerts:</b> none ✅")

    # Suppressions whose underlying alert isn't currently firing (rare -
    # would mean a user pre-suppressed something or the resolver is
    # mid-cycle). Only show this block if it's not already covered above.
    active_keys = {a["dedup_key"] for a in active_alerts}
    orphan_sups = [s for s in suppressions if s["dedup_key"] not in active_keys]
    if orphan_sups:
        lines.append(f"\n<b>Pre-suppressed ({len(orphan_sups)}):</b>")
        for s in orphan_sups:
            label = human_label_for_dedup_key(s["dedup_key"])
            lines.append(f"  • {label} <i>(by {s['set_by_user_name']})</i>")

    lines.append(f"\n<i>{format_utc_human(ts_utc)}</i>")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# DB helpers
# ---------------------------------------------------------------------------

def _record_heartbeat_sent(ts_utc: str) -> None:
    """Stamp the latest state_history row's last_notified_utc."""
    conn = storage.get_conn()
    conn.execute(
        "UPDATE state_history SET last_notified_utc = ? "
        "WHERE ts_utc = (SELECT MAX(ts_utc) FROM state_history)",
        (ts_utc,),
    )


def _last_sent_iso() -> Optional[str]:
    """Most recent non-null last_notified_utc in state_history, or None."""
    conn = storage.get_conn()
    row = conn.execute(
        "SELECT last_notified_utc FROM state_history "
        "WHERE last_notified_utc IS NOT NULL "
        "ORDER BY ts_utc DESC LIMIT 1"
    ).fetchone()
    return row["last_notified_utc"] if row is not None else None


# ---------------------------------------------------------------------------
# Single tick (importable + testable)
# ---------------------------------------------------------------------------

def tick_once() -> Optional[dict]:
    """Decide whether a heartbeat is due and, if so, send it.

    Returns a small summary on send, or ``None`` if there was nothing to
    do (no state yet, or cadence not elapsed).
    """
    storage.init_db()
    state = storage.latest_state()
    if state is None:
        return None  # worker hasn't produced a state row yet

    cadence_s = _cadence_for(state["calm_score"])
    last_iso = _last_sent_iso()
    now_dt = _parse_iso(_now_iso())
    if last_iso is not None:
        last_dt = _parse_iso(last_iso)
        if last_dt is not None and now_dt is not None:
            elapsed = (now_dt - last_dt).total_seconds()
            if elapsed < cadence_s:
                return None

    # Build digest from the *current* DB state, not the snapshot in the row.
    active_alerts = storage.unresolved_alerts()
    suppressions = storage.active_suppressions()
    ts_utc = _now_iso()
    text = format_heartbeat(
        calm_score=state["calm_score"],
        reasoning=state["reasoning"],
        active_alerts=active_alerts,
        suppressions=suppressions,
        ts_utc=ts_utc,
    )

    # Send via broadcast() so DRY_RUN behaviour is consistent with /set, /stop, etc.
    broadcast(text)
    _record_heartbeat_sent(ts_utc)
    log.info(
        "heartbeat sent state=%s active=%d suppressed=%d cadence_s=%d",
        state["calm_score"], len(active_alerts), len(suppressions), cadence_s,
    )
    return {
        "ts_utc": ts_utc,
        "calm_score": state["calm_score"],
        "active_alerts": len(active_alerts),
        "suppressions": len(suppressions),
        "cadence_s": cadence_s,
    }


# ---------------------------------------------------------------------------
# Daemon thread
# ---------------------------------------------------------------------------

class HeartbeatWorker:
    """Periodic checker that fires :func:`tick_once` every ``interval_s``."""

    def __init__(
        self,
        *,
        interval_s: float = TICK_INTERVAL_S,
        stop_event: Optional[threading.Event] = None,
    ) -> None:
        self.interval_s = float(interval_s)
        self.stop_event = stop_event or threading.Event()
        self._thread: Optional[threading.Thread] = None

    def start(self) -> None:
        if self._thread is not None and self._thread.is_alive():
            return
        self._thread = threading.Thread(
            target=self._loop, name="portfolio-analysis-heartbeat", daemon=True,
        )
        self._thread.start()
        log.info("HeartbeatWorker started (interval=%.1fs)", self.interval_s)

    def stop(self, timeout: float = 5.0) -> None:
        self.stop_event.set()
        if self._thread is not None:
            self._thread.join(timeout=timeout)
            log.info("HeartbeatWorker stopped")

    def _loop(self) -> None:
        while not self.stop_event.is_set():
            try:
                tick_once()
            except Exception:
                log.exception("HeartbeatWorker tick failed; continuing")
            slept = 0.0
            while slept < self.interval_s and not self.stop_event.is_set():
                step = min(0.5, self.interval_s - slept)
                time.sleep(step)
                slept += step
