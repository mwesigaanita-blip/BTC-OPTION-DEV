"""Display-formatting helpers shared by the bot, notifier, heartbeat,
report, and Streamlit page.

Three concerns, one place:

* **Timestamps** - render UTC ISO strings as ``YYYY-MM-DD HH:MM UTC``
  instead of the raw microsecond ISO that's hard to read at a glance.
* **Durations** - render "seconds" thresholds as ``2d``, ``6h``, ``30m``,
  ``45s`` so users never see ``21600`` for a 6-hour cadence.
* **Examples** - when prompting the user for a new value (wizard step),
  pick an example whose magnitude matches the current default so the
  hint is actually useful (``e.g. 0.6`` for a 0.5 default, not
  ``e.g. 25``).
"""
from __future__ import annotations

from typing import Optional


__all__ = [
    "format_utc_human",
    "format_seconds_human",
    "is_duration_threshold",
    "format_threshold_value",
    "example_for_default",
    "human_label_for_dedup_key",
    "severity_icon",
    "alert_button_text",
]


# ---------------------------------------------------------------------------
# Timestamps
# ---------------------------------------------------------------------------

def format_utc_human(iso_str: Optional[str]) -> str:
    """Render a UTC ISO string as ``YYYY-MM-DD HH:MM UTC``.

    Drops microseconds and the trailing ``Z``. Returns ``"-"`` on None /
    empty / unparseable input so callers can dump the result into a
    table cell without conditional logic.

    Examples::

        '2026-05-05T11:33:02.741574Z'  → '2026-05-05 11:33 UTC'
        '2026-05-05T11:33:02Z'         → '2026-05-05 11:33 UTC'
        '2026-05-05T11:33:02.741574'   → '2026-05-05 11:33 UTC'
        None / ''                       → '-'
    """
    if not iso_str:
        return "-"
    s = str(iso_str).strip()
    if not s:
        return "-"
    if s.upper().endswith(" UTC"):
        s = s[:-4].rstrip()
    if s.endswith("Z"):
        s = s[:-1]
    if "." in s:
        s = s.split(".", 1)[0]
    if "T" in s:
        date_part, time_part = s.split("T", 1)
    elif " " in s:
        date_part, time_part = s.split(" ", 1)
    else:
        return "-"
    # Trim seconds → "HH:MM" (we don't need second precision for humans).
    hm = time_part[:5] if len(time_part) >= 5 else time_part
    return f"{date_part} {hm} UTC"


# ---------------------------------------------------------------------------
# Durations (seconds → "2d 3h 5m 10s")
# ---------------------------------------------------------------------------

def format_seconds_human(seconds: float | int | None) -> str:
    """Render a seconds count as a compact human duration.

    Examples::

        21600  → '6h'
        7200   → '2h'
        1800   → '30m'
        60     → '1m'
        90     → '1m 30s'
        86400  → '1d'
        90000  → '1d 1h'
        0      → '0s'
        None   → '-'
    """
    if seconds is None:
        return "-"
    try:
        n = int(round(float(seconds)))
    except (TypeError, ValueError):
        return str(seconds)
    if n == 0:
        return "0s"
    sign = "-" if n < 0 else ""
    n = abs(n)
    days, n = divmod(n, 86400)
    hours, n = divmod(n, 3600)
    mins, secs = divmod(n, 60)
    parts: list[str] = []
    if days:
        parts.append(f"{days}d")
    if hours:
        parts.append(f"{hours}h")
    if mins:
        parts.append(f"{mins}m")
    if secs:
        parts.append(f"{secs}s")
    return sign + " ".join(parts)


# ---------------------------------------------------------------------------
# Threshold-aware value formatting
# ---------------------------------------------------------------------------

# Threshold names whose value is a duration in seconds. Anything ending
# with "_S" is treated as a duration unless explicitly listed otherwise.
_NON_DURATION_S_SUFFIX_NAMES: set[str] = set()


def is_duration_threshold(name: str) -> bool:
    """True if the threshold's value is a count of seconds (heartbeats etc.)."""
    if not name:
        return False
    if name in _NON_DURATION_S_SUFFIX_NAMES:
        return False
    return name.endswith("_S")


def format_threshold_value(name: str, value) -> str:
    """Render a threshold value the way humans expect.

    * Duration thresholds (``HEARTBEAT_*_S``) → ``6h`` / ``30m``.
    * Everything else → the raw number, trailing zeros trimmed.
    """
    if value is None:
        return "-"
    if is_duration_threshold(name):
        return format_seconds_human(value)
    if isinstance(value, float):
        s = f"{value:.6f}".rstrip("0").rstrip(".")
        return s or "0"
    return str(value)


# ---------------------------------------------------------------------------
# Dedup-key → plain-English label
# ---------------------------------------------------------------------------

# Severity → emoji prefix used by alert buttons / status lines.
_SEVERITY_ICON = {
    "INFO":      "ℹ️",
    "WARNING":   "⚠️",
    "URGENT":    "🚨",
    "EMERGENCY": "🆘",
}


def severity_icon(severity: Optional[str]) -> str:
    return _SEVERITY_ICON.get((severity or "").upper(), "•")


def _kv(parts: list[str], key: str, default: Optional[str] = None) -> Optional[str]:
    """Pluck ``key=value`` out of a colon-split dedup_key list."""
    pref = key + "="
    for p in parts:
        if p.startswith(pref):
            return p[len(pref):]
    return default


def human_label_for_dedup_key(dedup_key: str) -> str:
    """Render a raw dedup_key like ``VOL:1h:dir=+:band=critical`` into
    something a human can read at a glance, e.g. ``BTC 1h up (critical)``.

    Unknown keys fall back to the raw string so debugging still works.
    """
    if not dedup_key:
        return "(unknown)"
    parts = dedup_key.split(":")
    head = parts[0]

    if head == "MM":
        band = _kv(parts, "band", default="?")
        return f"Margin pressure ({band})"

    if head == "DELTA":
        sign = _kv(parts, "sign", default="")
        band = _kv(parts, "band", default="?")
        side = (
            "Long"  if sign == "+"
            else "Short" if sign == "-"
            else "Neutral"
        )
        return f"{side} delta drift ({band})"

    if head == "DTE":
        # DTE:<instrument>:band=warning|critical
        instrument = parts[1] if len(parts) > 1 else "?"
        band = _kv(parts, "band", default="?")
        return f"Option expiry close: {instrument} ({band})"

    if head == "VOL":
        # VOL:<tf>:dir=+|-:band=warning|critical|extreme
        tf = parts[1] if len(parts) > 1 else "?"
        d = _kv(parts, "dir", default="")
        band = _kv(parts, "band", default="?")
        direction = "up" if d == "+" else ("down" if d == "-" else "")
        return f"BTC {tf} {direction} ({band})".replace("  ", " ").strip()

    if head == "QUANTILE":
        tf = parts[1] if len(parts) > 1 else "?"
        d = _kv(parts, "dir", default="")
        if d == "high":
            return f"BTC {tf} move unusually high"
        if d == "low":
            return f"BTC {tf} move unusually low"
        return f"BTC {tf} move outside range"

    return dedup_key


def alert_button_text(
    dedup_key: str,
    severity: Optional[str] = None,
    *,
    max_chars: int = 60,
) -> str:
    """One-line button text for inline-keyboard alert pickers.

    Combines severity icon + human label, truncated to fit Telegram's
    64-char button limit (we keep a small safety margin).
    """
    icon = severity_icon(severity) + " " if severity else ""
    label = human_label_for_dedup_key(dedup_key)
    text = f"{icon}{label}"
    if len(text) > max_chars:
        text = text[: max_chars - 1] + "…"
    return text


# ---------------------------------------------------------------------------
# Example value for wizard prompts
# ---------------------------------------------------------------------------

def example_for_default(name: str, default_value) -> str:
    """A short example string whose magnitude is similar to ``default_value``.

    Used in wizard prompts:  "Send the new value as a number (e.g. {ex})".
    For duration thresholds this returns a duration string (``4h``, ``45m``);
    for numeric thresholds it returns a number close to the default so the
    hint is actually informative (``0.6`` for a default of ``0.5``, not
    the misleading ``25``).
    """
    if is_duration_threshold(name):
        # Pick a duration ~half the default. Drop to a smaller unit if the
        # natural unit would round to 0 or 1 - for a 60s default we want
        # "30s", not "1m".
        try:
            n = float(default_value)
        except (TypeError, ValueError):
            return "30m"
        if n <= 0:
            return "30m"
        if n >= 2 * 86400:
            return f"{int(n // 86400 // 2)}d"
        if n >= 2 * 3600:
            return f"{int(n // 3600 // 2)}h"
        if n >= 2 * 60:
            return f"{int(n // 60 // 2)}m"
        return f"{max(1, int(round(n / 2)))}s"

    # Numeric threshold - generate something with the same order of magnitude.
    try:
        d = float(default_value)
    except (TypeError, ValueError):
        return "25"
    if d == 0:
        return "0.1"
    a = abs(d)
    # Pick "near" the default so the user gets the magnitude right.
    near = d * 1.2 if d > 0 else d * 0.8
    if a < 1:
        s = f"{near:.4f}".rstrip("0").rstrip(".")
    elif a < 10:
        s = f"{near:.2f}".rstrip("0").rstrip(".")
    else:
        s = f"{int(round(near))}"
    return s or str(default_value)
