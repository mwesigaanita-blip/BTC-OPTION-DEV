#!/usr/bin/env python3
"""
BTC Options & Futures Daily Report - Deribit API Edition
=========================================================
Pulls live data from Deribit, generates charts, builds a PDF report.

Sections:
  1. Price Index          6. IV Smile
  2. Funding Rate         7. Historical Volatility
  3. Futures Premium      8. DVOL
  4. OI by Expiry         9. Greeks (Gamma Profile + Net Delta)
  5. OI by Strike        10. Volume & Trades
                         11. Skew Analysis (25-delta RR & Fly)
                         12. Summary Cheat Sheet

Usage:
    python3 btc_daily_report.py                   # generate now
    python3 btc_daily_report.py --out /my/folder  # custom output dir

Requirements:
    pip install requests pandas matplotlib reportlab
"""

import os, sys, time, argparse
import requests
import pandas as pd
import numpy as np
from datetime import datetime, timezone, timedelta
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import matplotlib.ticker as mticker
import matplotlib.gridspec as gridspec
import warnings
warnings.filterwarnings("ignore")

from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Image,
    Table, TableStyle, HRFlowable, PageBreak,
)
from reportlab.lib.enums import TA_LEFT, TA_CENTER, TA_RIGHT

# ══════════════════════════════════════════════════════════════════════════════
# CONFIG
# ══════════════════════════════════════════════════════════════════════════════
CLIENT_ID     = "E69HXqOS"
CLIENT_SECRET = "hXO4smF28rWoIwrREu40SJ1MEHVsgDDwEEp4vsPoM7c"
BASE_URL      = "https://www.deribit.com/api/v2"
CURRENCY      = "BTC"

# ══════════════════════════════════════════════════════════════════════════════
# COLOUR PALETTE
# ══════════════════════════════════════════════════════════════════════════════
DARK  = "#0D1117"; PANEL = "#161B22"; ACC   = "#F7931A"
GRN   = "#26A69A"; RED   = "#EF5350"; BLU   = "#2196F3"
PUR   = "#AB47BC"; TXT   = "#E6EDF3"; GRID  = "#21262D"; YLW = "#FFC107"

C_BG      = colors.HexColor(DARK);  C_PANEL   = colors.HexColor(PANEL)
C_ACCENT  = colors.HexColor(ACC);   C_GREEN   = colors.HexColor(GRN)
C_RED     = colors.HexColor(RED);   C_BLUE    = colors.HexColor(BLU)
C_PURPLE  = colors.HexColor(PUR);   C_TEXT    = colors.HexColor(TXT)
C_SUBTEXT = colors.HexColor("#8B949E"); C_BORDER = colors.HexColor(GRID)
C_YELLOW  = colors.HexColor(YLW)

PAGE_W, PAGE_H = A4
MARGIN = 18 * mm
IMG_W  = PAGE_W - 2 * MARGIN


# ══════════════════════════════════════════════════════════════════════════════
# DERIBIT API CLIENT
# ══════════════════════════════════════════════════════════════════════════════
class DeribitClient:
    def __init__(self, client_id, client_secret):
        self.client_id     = client_id
        self.client_secret = client_secret
        self.access_token  = None
        self.session       = requests.Session()

    def authenticate(self):
        res = self._get("/public/auth", {
            "grant_type": "client_credentials",
            "client_id": self.client_id,
            "client_secret": self.client_secret,
        })
        self.access_token = res["access_token"]
        self.session.headers.update({"Authorization": f"Bearer {self.access_token}"})
        print("✓ Authenticated")

    def _get(self, endpoint, params=None):
        r = self.session.get(f"{BASE_URL}{endpoint}", params=params, timeout=20)
        r.raise_for_status()
        body = r.json()
        if "error" in body:
            raise ValueError(f"API error: {body['error']}")
        return body.get("result", body)

    def _priv(self, endpoint, params=None):
        if not self.access_token:
            self.authenticate()
        return self._get(endpoint, params)

    def get_index_price(self):
        return float(self._get("/public/get_index_price", {"index_name": "btc_usd"})["index_price"])

    def get_price_history(self, hours=168):
        now_ms = int(time.time() * 1000)
        res = self._get("/public/get_tradingview_chart_data", {
            "instrument_name": "BTC-PERPETUAL",
            "start_timestamp": now_ms - hours * 3_600_000,
            "end_timestamp":   now_ms,
            "resolution":      "60",
        })
        return pd.DataFrame({"DateTime": pd.to_datetime(res["ticks"], unit="ms", utc=True),
                              "Price": res["close"]}).sort_values("DateTime").reset_index(drop=True)

    def get_perpetual_ticker(self):
        return self._get("/public/ticker", {"instrument_name": "BTC-PERPETUAL"})

    def get_funding_rate_history(self, hours=168):
        now_ms = int(time.time() * 1000)
        res = self._get("/public/get_funding_rate_history", {
            "instrument_name": "BTC-PERPETUAL",
            "start_timestamp": now_ms - hours * 3_600_000,
            "end_timestamp":   now_ms,
        })
        df = pd.DataFrame(res)
        df["DateTime"] = pd.to_datetime(df["timestamp"], unit="ms", utc=True)
        return df.rename(columns={"interest_8h": "FundingRate"})[["DateTime","FundingRate"]].sort_values("DateTime").reset_index(drop=True)

    def get_historical_volatility(self):
        res = self._get("/public/get_historical_volatility", {"currency": CURRENCY})
        df  = pd.DataFrame(res, columns=["ts","HV"])
        df["DateTime"] = pd.to_datetime(df["ts"], unit="ms", utc=True)
        return df[["DateTime","HV"]].sort_values("DateTime").reset_index(drop=True)

    def get_dvol_history(self, days=30):
        now_ms = int(time.time() * 1000)
        res = self._get("/public/get_volatility_index_data", {
            "currency": CURRENCY,
            "start_timestamp": now_ms - days * 86_400_000,
            "end_timestamp":   now_ms,
            "resolution":      "60",
        })
        df = pd.DataFrame(res.get("data",[]), columns=["ts","open","high","low","close"])
        df["DateTime"] = pd.to_datetime(df["ts"], unit="ms", utc=True)
        return df.rename(columns={"close":"DVOL"})[["DateTime","DVOL"]].sort_values("DateTime").reset_index(drop=True)

    def get_options_summary(self):
        """Returns full options book: OI, mark_iv, greeks (delta/gamma), volume."""
        return pd.DataFrame(self._get("/public/get_book_summary_by_currency",
                                      {"currency": CURRENCY, "kind": "option"}))

    def get_futures_summary(self):
        return pd.DataFrame(self._get("/public/get_book_summary_by_currency",
                                      {"currency": CURRENCY, "kind": "future"}))


# ══════════════════════════════════════════════════════════════════════════════
# DATA PROCESSING
# ══════════════════════════════════════════════════════════════════════════════

# ── Pure-math Black-Scholes (no scipy needed) ─────────────────────────────────
import math as _math

def _ncdf(x):
    """Standard normal CDF via math.erf."""
    return 0.5 * (1.0 + _math.erf(x / _math.sqrt(2.0)))

def _npdf(x):
    """Standard normal PDF."""
    return _math.exp(-0.5 * x * x) / _math.sqrt(2.0 * _math.pi)

_EXPIRY_MAP = {
    "JAN":"01","FEB":"02","MAR":"03","APR":"04","MAY":"05","JUN":"06",
    "JUL":"07","AUG":"08","SEP":"09","OCT":"10","NOV":"11","DEC":"12",
}

def _parse_expiry_date(expiry_str):
    """Convert Deribit expiry string like '10APR26' → datetime."""
    try:
        day = int(expiry_str[:2])
        mon = _EXPIRY_MAP.get(expiry_str[2:5].upper(), "01")
        yr  = int("20" + expiry_str[5:7])
        return datetime(yr, int(mon), day, 8, 0, tzinfo=timezone.utc)  # 08:00 UTC settlement
    except Exception:
        return None

def _bs_greeks(spot, strike, iv_pct, expiry_str, opt_type, r=0.0):
    """
    Black-Scholes delta and gamma.
    Returns (delta, gamma) or (0.5, 0.0) on failure.
    """
    try:
        exp_dt = _parse_expiry_date(expiry_str)
        if exp_dt is None:
            return (0.5, 0.0)
        T = max((exp_dt - datetime.now(timezone.utc)).total_seconds() / (365.25 * 86400), 1e-6)
        sigma = iv_pct / 100.0
        d1 = (_math.log(spot / strike) + (r + 0.5 * sigma**2) * T) / (sigma * _math.sqrt(T))
        delta = _ncdf(d1) if opt_type == "C" else _ncdf(d1) - 1.0
        gamma = _npdf(d1) / (spot * sigma * _math.sqrt(T))
        return (delta, gamma)
    except Exception:
        return (0.5, 0.0)


def _parse_opts(df_opt):
    """
    Add expiry/strike/opt_type columns, coerce numerics.
    Computes delta & gamma via Black-Scholes if Deribit doesn't return greeks
    (get_book_summary_by_currency does not include greeks; ticker does).
    """
    df = df_opt.copy()
    parts = df["instrument_name"].str.split("-", expand=True)
    df["expiry"]   = parts[1]
    df["strike"]   = pd.to_numeric(parts[2], errors="coerce")
    df["opt_type"] = parts[3]
    for col in ["open_interest", "mark_iv", "volume"]:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0)

    # Try to extract delta/gamma from Deribit's greeks dict (ticker endpoint)
    if "greeks" in df.columns:
        g = df["greeks"].apply(lambda x: x if isinstance(x, dict) else {})
        df["delta"] = g.apply(lambda x: float(x.get("delta", np.nan)))
        df["gamma"] = g.apply(lambda x: float(x.get("gamma", np.nan)))

    # Fall back to Black-Scholes for any rows missing delta/gamma
    needs_bs = ("delta" not in df.columns) or df["delta"].isna().any()
    if needs_bs:
        spot_ref = df.get("underlying_price", pd.Series([None]*len(df))).fillna(0)

        def compute_row(row):
            spot = float(row.get("underlying_price", 0) or row.get("index_price", 0) or 0)
            # spot will be 0 from book summary - we fill it later in process_greeks
            iv  = float(row.get("mark_iv", 0) or 0)
            k   = float(row.get("strike", 0) or 0)
            exp = str(row.get("expiry", "") or "")
            opt = str(row.get("opt_type", "") or "C")
            return pd.Series({"_delta": np.nan, "_gamma": np.nan,
                               "_iv": iv, "_k": k, "_exp": exp, "_opt": opt})

        if "delta" not in df.columns:
            df["delta"] = np.nan
        if "gamma" not in df.columns:
            df["gamma"] = np.nan

    return df.dropna(subset=["strike", "opt_type"])


def process_options(df_opt, spot):
    df = _parse_opts(df_opt)
    calls = df[df["opt_type"]=="C"].groupby("strike")["open_interest"].sum().rename("Calls")
    puts  = df[df["opt_type"]=="P"].groupby("strike")["open_interest"].sum().rename("Puts")
    oi_strike = pd.concat([calls, puts], axis=1).fillna(0).reset_index()

    ce = df[df["opt_type"]=="C"].groupby("expiry")["open_interest"].sum().rename("Total_Calls")
    pe = df[df["opt_type"]=="P"].groupby("expiry")["open_interest"].sum().rename("Total_Puts")
    oi_expiry = pd.concat([ce, pe], axis=1).fillna(0).reset_index()

    total_calls = df[df["opt_type"]=="C"]["open_interest"].sum()
    total_puts  = df[df["opt_type"]=="P"]["open_interest"].sum()
    pcr = total_puts / total_calls if total_calls > 0 else 0
    return oi_strike, oi_expiry, total_calls, total_puts, pcr


def process_futures_premium(df_fut, spot):
    df = df_fut[~df_fut["instrument_name"].str.contains("PERPETUAL")].copy()
    df["premium"] = pd.to_numeric(df["mark_price"], errors="coerce") - spot
    return df[["instrument_name","mark_price","premium"]].dropna().sort_values("premium")


def process_greeks(df_opt, spot):
    """
    Net delta exposure (BTC) and net gamma exposure (BTC per 1% move)
    by strike, from dealer perspective (flip sign: if longs own calls,
    dealers are short - so dealer net delta is negative where calls dominate).
    Also compute the gamma flip level.

    Uses Black-Scholes to compute delta/gamma when Deribit's book summary
    endpoint does not return greeks (which is the default for
    get_book_summary_by_currency).
    """
    df = _parse_opts(df_opt)

    # Fill missing delta/gamma with Black-Scholes
    missing = df["delta"].isna() | df["gamma"].isna()
    if missing.any():
        print(f"  Computing B-S greeks for {missing.sum()} rows (greeks not in API response)...")
        for idx in df[missing].index:
            row = df.loc[idx]
            d, g = _bs_greeks(
                spot=spot,
                strike=float(row["strike"]),
                iv_pct=float(row["mark_iv"]) if row["mark_iv"] > 0 else 50.0,
                expiry_str=str(row["expiry"]),
                opt_type=str(row["opt_type"]),
            )
            df.at[idx, "delta"] = d
            df.at[idx, "gamma"] = g

    df["delta"] = pd.to_numeric(df["delta"], errors="coerce").fillna(0)
    df["gamma"] = pd.to_numeric(df["gamma"], errors="coerce").fillna(0)

    # Dealer is short what market is long: flip sign
    df["net_delta"] = np.where(df["opt_type"]=="C",
                               -df["delta"] * df["open_interest"],
                                df["delta"].abs() * df["open_interest"])
    df["net_gamma"] = -df["gamma"] * df["open_interest"]   # dealers always short gamma

    by_strike = df.groupby("strike").agg(
        net_delta=("net_delta","sum"),
        net_gamma=("net_gamma","sum"),
    ).reset_index()

    # Scale gamma to "BTC per 1% spot move"
    by_strike["net_gamma_scaled"] = by_strike["net_gamma"] * spot * 0.01

    # Gamma flip level: where cumulative gamma crosses zero
    by_strike_sorted = by_strike.sort_values("strike")
    cum_gamma = by_strike_sorted["net_gamma"].cumsum()
    flip_idx  = (cum_gamma >= 0).idxmax() if (cum_gamma >= 0).any() else None
    gamma_flip = float(by_strike_sorted.loc[flip_idx, "strike"]) if flip_idx is not None else None

    return by_strike, gamma_flip


def process_volume(df_opt, df_fut):
    """24-hour trading volume by expiry and by strike."""
    df = _parse_opts(df_opt)
    # Volume by expiry
    cv = df[df["opt_type"]=="C"].groupby("expiry")["volume"].sum().rename("Call_Vol")
    pv = df[df["opt_type"]=="P"].groupby("expiry")["volume"].sum().rename("Put_Vol")
    vol_expiry = pd.concat([cv, pv], axis=1).fillna(0).reset_index()
    vol_expiry["Total_Vol"] = vol_expiry["Call_Vol"] + vol_expiry["Put_Vol"]
    vol_expiry = vol_expiry.sort_values("Total_Vol", ascending=False)

    # Top 10 most active strikes
    sv = df.groupby("strike")["volume"].sum().reset_index().rename(columns={"volume":"Total_Vol"})
    sv_calls = df[df["opt_type"]=="C"].groupby("strike")["volume"].sum().rename("Call_Vol")
    sv_puts  = df[df["opt_type"]=="P"].groupby("strike")["volume"].sum().rename("Put_Vol")
    vol_strike = sv.join(sv_calls, on="strike").join(sv_puts, on="strike").fillna(0)
    vol_strike = vol_strike.sort_values("Total_Vol", ascending=False).head(15)

    # Futures volume
    df_f = df_fut.copy()
    df_f["volume"] = pd.to_numeric(df_f.get("volume", 0), errors="coerce").fillna(0)
    total_fut_vol = df_f["volume"].sum()

    total_opt_vol  = df["volume"].sum()
    call_vol_total = df[df["opt_type"]=="C"]["volume"].sum()
    put_vol_total  = df[df["opt_type"]=="P"]["volume"].sum()
    vol_pcr = put_vol_total / call_vol_total if call_vol_total > 0 else 0

    return vol_expiry, vol_strike, total_opt_vol, call_vol_total, put_vol_total, vol_pcr, total_fut_vol


def process_skew(df_opt, spot=None):
    """
    25-delta risk reversal and 25-delta butterfly per expiry.
    Uses delta from Deribit greeks if available; otherwise computes via Black-Scholes.
    RR25  = IV(25d Call) - IV(25d Put)   [negative = put skew = fear]
    Fly25 = (IV(25d Call) + IV(25d Put))/2 - ATM_IV  [positive = vol premium for wings]
    """
    df = _parse_opts(df_opt)

    # Ensure delta exists - compute via B-S if missing
    if "delta" not in df.columns or df["delta"].isna().all():
        if spot is None:
            return pd.DataFrame()
        df["delta"] = np.nan
        df["gamma"] = np.nan

    missing = df["delta"].isna()
    if missing.any() and spot is not None:
        for idx in df[missing].index:
            row = df.loc[idx]
            d, g = _bs_greeks(
                spot=spot,
                strike=float(row["strike"]),
                iv_pct=float(row["mark_iv"]) if row["mark_iv"] > 0 else 50.0,
                expiry_str=str(row["expiry"]),
                opt_type=str(row["opt_type"]),
            )
            df.at[idx, "delta"] = d
    df["delta"] = pd.to_numeric(df["delta"], errors="coerce").fillna(0)

    if df["delta"].abs().max() == 0:
        return pd.DataFrame()

    results = []
    for exp in df["expiry"].unique():
        sub = df[df["expiry"] == exp].copy()
        calls = sub[sub["opt_type"] == "C"]
        puts  = sub[sub["opt_type"] == "P"]

        # 25d call: delta closest to +0.25
        if len(calls) >= 2:
            idx_25c = (calls["delta"] - 0.25).abs().idxmin()
            iv_25c  = calls.loc[idx_25c, "mark_iv"]
        else:
            continue

        # 25d put: delta closest to -0.25
        if len(puts) >= 2:
            idx_25p = (puts["delta"].abs() - 0.25).abs().idxmin()
            iv_25p  = puts.loc[idx_25p, "mark_iv"]
        else:
            continue

        # ATM IV: option with delta closest to 0.5 (call) or -0.5 (put)
        atm_c = calls.iloc[(calls["delta"] - 0.5).abs().argsort()[:1]]
        atm_p = puts.iloc[(puts["delta"].abs() - 0.5).abs().argsort()[:1]]
        iv_atm = (atm_c["mark_iv"].mean() + atm_p["mark_iv"].mean()) / 2

        rr25  = iv_25c - iv_25p
        fly25 = (iv_25c + iv_25p) / 2 - iv_atm

        results.append({
            "expiry":  exp,
            "iv_25c":  round(iv_25c, 2),
            "iv_25p":  round(iv_25p, 2),
            "iv_atm":  round(iv_atm, 2),
            "rr25":    round(rr25, 2),
            "fly25":   round(fly25, 2),
        })

    return pd.DataFrame(results)


# ══════════════════════════════════════════════════════════════════════════════
# CHART GENERATORS
# ══════════════════════════════════════════════════════════════════════════════
def _style(ax, title=""):
    ax.set_facecolor(PANEL)
    ax.tick_params(colors=TXT, labelsize=8)
    for s in ["bottom","left"]: ax.spines[s].set_color(GRID)
    ax.spines["top"].set_visible(False); ax.spines["right"].set_visible(False)
    ax.grid(color=GRID, linestyle="--", linewidth=0.5, alpha=0.7)
    if title: ax.set_title(title, color=TXT, fontsize=10, fontweight="bold", pad=8)


def make_price_chart(df, path):
    fig, ax = plt.subplots(figsize=(7.5, 2.8), facecolor=DARK)
    ax.fill_between(df["DateTime"], df["Price"], alpha=0.18, color=ACC)
    ax.plot(df["DateTime"], df["Price"], color=ACC, linewidth=1.5)
    _style(ax, "BTC/USD Price - Last 7 Days (Hourly)")
    ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda x,_: f"${x:,.0f}"))
    ax.xaxis.set_major_formatter(mdates.DateFormatter("%d %b"))
    ax.xaxis.set_major_locator(mdates.DayLocator())
    plt.tight_layout(pad=0.5); plt.savefig(path, dpi=150, bbox_inches="tight", facecolor=DARK); plt.close()


def make_funding_chart(df, path):
    df = df.copy(); df["FR_ann"] = df["FundingRate"] * 3 * 365 * 100
    fig, ax = plt.subplots(figsize=(7.5, 2.8), facecolor=DARK)
    ax.bar(df["DateTime"], df["FR_ann"], color=[GRN if v>=0 else RED for v in df["FR_ann"]], width=0.03, alpha=0.9)
    ax.axhline(0, color=TXT, linewidth=0.5, linestyle="--")
    _style(ax, "Funding Rate (Annualised %) - Last 7 Days")
    ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda x,_: f"{x:.1f}%"))
    ax.xaxis.set_major_formatter(mdates.DateFormatter("%d %b"))
    ax.xaxis.set_major_locator(mdates.DayLocator())
    plt.tight_layout(pad=0.5); plt.savefig(path, dpi=150, bbox_inches="tight", facecolor=DARK); plt.close()


def make_hv_chart(df, path):
    df14 = df[df["DateTime"] >= df["DateTime"].max() - pd.Timedelta(days=14)]
    fig, ax = plt.subplots(figsize=(7.5, 2.6), facecolor=DARK)
    ax.fill_between(df14["DateTime"], df14["HV"], alpha=0.18, color=PUR)
    ax.plot(df14["DateTime"], df14["HV"], color=PUR, linewidth=1.5)
    _style(ax, "Historical Volatility (%) - Last 14 Days")
    ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda x,_: f"{x:.1f}%"))
    ax.xaxis.set_major_formatter(mdates.DateFormatter("%d %b"))
    ax.xaxis.set_major_locator(mdates.DayLocator(interval=2))
    plt.tight_layout(pad=0.5); plt.savefig(path, dpi=150, bbox_inches="tight", facecolor=DARK); plt.close()


def make_dvol_chart(df, path):
    fig, ax = plt.subplots(figsize=(7.5, 2.6), facecolor=DARK)
    ax.fill_between(df["DateTime"], df["DVOL"], alpha=0.18, color=BLU)
    ax.plot(df["DateTime"], df["DVOL"], color=BLU, linewidth=1.5)
    _style(ax, "DVOL - Deribit BTC Volatility Index (30 Days)")
    ax.xaxis.set_major_formatter(mdates.DateFormatter("%d %b"))
    ax.xaxis.set_major_locator(mdates.WeekdayLocator(interval=5))
    plt.tight_layout(pad=0.5); plt.savefig(path, dpi=150, bbox_inches="tight", facecolor=DARK); plt.close()


def make_oi_expiry_chart(df, path):
    df = df.sort_values("Total_Calls", ascending=False).head(10)
    fig, ax = plt.subplots(figsize=(7.5, 3.2), facecolor=DARK)
    x, w = np.arange(len(df)), 0.35
    ax.bar(x-w/2, df["Total_Calls"], width=w, color=GRN, alpha=0.85, label="Calls")
    ax.bar(x+w/2, df["Total_Puts"],  width=w, color=RED, alpha=0.85, label="Puts")
    ax.set_xticks(x); ax.set_xticklabels(df["expiry"], rotation=35, ha="right", fontsize=7.5)
    _style(ax, "Open Interest by Expiration (BTC)")
    ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda x,_: f"{x:,.0f}"))
    ax.legend(facecolor=PANEL, edgecolor=GRID, labelcolor=TXT, fontsize=8)
    plt.tight_layout(pad=0.5); plt.savefig(path, dpi=150, bbox_inches="tight", facecolor=DARK); plt.close()


def make_oi_strike_chart(df, spot, path):
    df = df[(df["strike"] >= spot*0.7) & (df["strike"] <= spot*1.6)]
    fig, ax = plt.subplots(figsize=(7.5, 3.2), facecolor=DARK)
    w = df["strike"].diff().median() * 0.4 if len(df)>1 else 1000
    ax.bar(df["strike"]-w/2, df["Calls"], width=w, color=GRN, alpha=0.85, label="Calls")
    ax.bar(df["strike"]+w/2, df["Puts"],  width=w, color=RED, alpha=0.85, label="Puts")
    ax.axvline(spot, color=ACC, linewidth=1.2, linestyle="--", label=f"Spot ~${spot:,.0f}")
    _style(ax, "Open Interest by Strike (70%–160% of Spot)")
    ax.xaxis.set_major_formatter(mticker.FuncFormatter(lambda x,_: f"${x/1000:.0f}K"))
    ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda x,_: f"{x:,.0f}"))
    ax.legend(facecolor=PANEL, edgecolor=GRID, labelcolor=TXT, fontsize=8)
    plt.tight_layout(pad=0.5); plt.savefig(path, dpi=150, bbox_inches="tight", facecolor=DARK); plt.close()


def make_futures_premium_chart(df, path):
    fig, ax = plt.subplots(figsize=(7.5, 2.8), facecolor=DARK)
    labels = df["instrument_name"].str.replace("BTC-","",regex=False)
    ax.bar(range(len(df)), df["premium"], color=[GRN if v>=0 else RED for v in df["premium"]], alpha=0.85)
    ax.set_xticks(range(len(df))); ax.set_xticklabels(labels, rotation=35, ha="right", fontsize=7.5)
    ax.axhline(0, color=TXT, linewidth=0.5, linestyle="--")
    _style(ax, "Futures Premium Above Spot (USD)")
    ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda x,_: f"${x:,.0f}"))
    plt.tight_layout(pad=0.5); plt.savefig(path, dpi=150, bbox_inches="tight", facecolor=DARK); plt.close()


def make_iv_smile_chart(df_opt, spot, path):
    df = _parse_opts(df_opt)
    df = df[(df["mark_iv"]>0) & (df["strike"]>=spot*0.4) & (df["strike"]<=spot*2.0)]
    expiries = sorted(df["expiry"].unique())[:8]
    cmap = plt.cm.get_cmap("plasma", len(expiries))
    fig, ax = plt.subplots(figsize=(7.5, 3.0), facecolor=DARK)
    for i, exp in enumerate(expiries):
        sub = df[df["expiry"]==exp].sort_values("strike")
        if len(sub) < 3: continue
        ax.plot(sub["strike"], sub["mark_iv"], color=cmap(i), linewidth=1.4,
                label=exp, alpha=0.85, marker="o", markersize=2)
    ax.axvline(spot, color=ACC, linewidth=1, linestyle="--", label=f"Spot ~${spot:,.0f}")
    _style(ax, "Implied Volatility Smile by Expiry")
    ax.xaxis.set_major_formatter(mticker.FuncFormatter(lambda x,_: f"${x/1000:.0f}K"))
    ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda x,_: f"{x:.0f}%"))
    ax.legend(facecolor=PANEL, edgecolor=GRID, labelcolor=TXT, fontsize=7, ncol=2)
    plt.tight_layout(pad=0.5); plt.savefig(path, dpi=150, bbox_inches="tight", facecolor=DARK); plt.close()


def make_gamma_chart(df_greeks, spot, gamma_flip, path):
    """Dual-panel: gamma profile (top) and net delta by strike (bottom)."""
    df = df_greeks[(df_greeks["strike"] >= spot*0.7) & (df_greeks["strike"] <= spot*1.5)].copy()
    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(7.5, 5.5), facecolor=DARK,
                                    gridspec_kw={"hspace": 0.45})
    w = df["strike"].diff().median() * 0.4 if len(df)>1 else 1000

    # Gamma profile
    gcols = [GRN if v >= 0 else RED for v in df["net_gamma_scaled"]]
    ax1.bar(df["strike"], df["net_gamma_scaled"], width=w, color=gcols, alpha=0.85)
    ax1.axhline(0, color=TXT, linewidth=0.8, linestyle="--")
    ax1.axvline(spot, color=ACC, linewidth=1.2, linestyle="--", label=f"Spot ${spot:,.0f}")
    if gamma_flip:
        ax1.axvline(gamma_flip, color=YLW, linewidth=1, linestyle=":", label=f"Gamma Flip ${gamma_flip:,.0f}")
    _style(ax1, "Dealer Net Gamma Exposure (BTC per 1% move)")
    ax1.xaxis.set_major_formatter(mticker.FuncFormatter(lambda x,_: f"${x/1000:.0f}K"))
    ax1.yaxis.set_major_formatter(mticker.FuncFormatter(lambda x,_: f"{x:,.0f}"))
    ax1.legend(facecolor=PANEL, edgecolor=GRID, labelcolor=TXT, fontsize=7)

    # Net delta
    dcols = [RED if v < 0 else GRN for v in df["net_delta"]]
    ax2.bar(df["strike"], df["net_delta"], width=w, color=dcols, alpha=0.85)
    ax2.axhline(0, color=TXT, linewidth=0.8, linestyle="--")
    ax2.axvline(spot, color=ACC, linewidth=1.2, linestyle="--")
    _style(ax2, "Dealer Net Delta Exposure (BTC)")
    ax2.xaxis.set_major_formatter(mticker.FuncFormatter(lambda x,_: f"${x/1000:.0f}K"))
    ax2.yaxis.set_major_formatter(mticker.FuncFormatter(lambda x,_: f"{x:,.0f}"))

    fig.patch.set_facecolor(DARK)
    plt.savefig(path, dpi=150, bbox_inches="tight", facecolor=DARK); plt.close()


def make_volume_chart(vol_expiry, vol_strike, path):
    """Dual-panel: volume by expiry (top) and top active strikes (bottom)."""
    ve = vol_expiry.head(8)
    vs = vol_strike.head(10).sort_values("strike")

    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(7.5, 5.5), facecolor=DARK,
                                    gridspec_kw={"hspace": 0.45})
    x, w = np.arange(len(ve)), 0.35
    ax1.bar(x-w/2, ve["Call_Vol"], width=w, color=GRN, alpha=0.85, label="Call Vol")
    ax1.bar(x+w/2, ve["Put_Vol"],  width=w, color=RED, alpha=0.85, label="Put Vol")
    ax1.set_xticks(x); ax1.set_xticklabels(ve["expiry"], rotation=35, ha="right", fontsize=7.5)
    _style(ax1, "24h Options Volume by Expiry (BTC)")
    ax1.yaxis.set_major_formatter(mticker.FuncFormatter(lambda x,_: f"{x:,.0f}"))
    ax1.legend(facecolor=PANEL, edgecolor=GRID, labelcolor=TXT, fontsize=8)

    x2, w2 = np.arange(len(vs)), 0.35
    ax2.bar(x2-w2/2, vs["Call_Vol"], width=w2, color=GRN, alpha=0.85, label="Calls")
    ax2.bar(x2+w2/2, vs["Put_Vol"],  width=w2, color=RED, alpha=0.85, label="Puts")
    ax2.set_xticks(x2)
    ax2.set_xticklabels([f"${int(s/1000)}K" for s in vs["strike"]], rotation=35, ha="right", fontsize=7.5)
    _style(ax2, "24h Volume - Top Active Strikes (BTC)")
    ax2.yaxis.set_major_formatter(mticker.FuncFormatter(lambda x,_: f"{x:,.0f}"))
    ax2.legend(facecolor=PANEL, edgecolor=GRID, labelcolor=TXT, fontsize=8)

    fig.patch.set_facecolor(DARK)
    plt.savefig(path, dpi=150, bbox_inches="tight", facecolor=DARK); plt.close()


def make_skew_chart(df_skew, path):
    """Dual-panel: 25-delta risk reversal (top) and butterfly (bottom) by expiry."""
    if df_skew is None or len(df_skew) == 0:
        fig, ax = plt.subplots(figsize=(7.5, 2), facecolor=DARK)
        ax.text(0.5, 0.5, "Insufficient data for skew calculation",
                transform=ax.transAxes, color=TXT, ha="center", va="center")
        _style(ax, "Skew Analysis")
        plt.savefig(path, dpi=150, bbox_inches="tight", facecolor=DARK); plt.close()
        return

    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(7.5, 5.5), facecolor=DARK,
                                    gridspec_kw={"hspace": 0.45})
    x = np.arange(len(df_skew))

    # Risk Reversal
    rr_colors = [RED if v < 0 else GRN for v in df_skew["rr25"]]
    ax1.bar(x, df_skew["rr25"], color=rr_colors, alpha=0.85)
    ax1.axhline(0, color=TXT, linewidth=0.8, linestyle="--")
    ax1.set_xticks(x); ax1.set_xticklabels(df_skew["expiry"], rotation=35, ha="right", fontsize=7.5)
    _style(ax1, "25-Delta Risk Reversal (%) - Negative = Put Skew (Fear)")
    ax1.yaxis.set_major_formatter(mticker.FuncFormatter(lambda x,_: f"{x:.1f}%"))

    # Butterfly
    fly_colors = [GRN if v >= 0 else RED for v in df_skew["fly25"]]
    ax2.bar(x, df_skew["fly25"], color=fly_colors, alpha=0.85)
    ax2.axhline(0, color=TXT, linewidth=0.8, linestyle="--")
    ax2.set_xticks(x); ax2.set_xticklabels(df_skew["expiry"], rotation=35, ha="right", fontsize=7.5)
    _style(ax2, "25-Delta Butterfly (%) - Wings vs ATM Vol Premium")
    ax2.yaxis.set_major_formatter(mticker.FuncFormatter(lambda x,_: f"{x:.1f}%"))

    fig.patch.set_facecolor(DARK)
    plt.savefig(path, dpi=150, bbox_inches="tight", facecolor=DARK); plt.close()


# ══════════════════════════════════════════════════════════════════════════════
# PDF BUILDER
# ══════════════════════════════════════════════════════════════════════════════
def S(name, **kw): return ParagraphStyle(name, **kw)

sTitle    = S("sT",  fontSize=26, textColor=colors.white,  fontName="Helvetica-Bold", alignment=TA_CENTER, leading=32)
sSub      = S("sS",  fontSize=11, textColor=C_SUBTEXT,     fontName="Helvetica",      alignment=TA_CENTER, leading=16)
sDate     = S("sDt", fontSize=10, textColor=C_ACCENT,      fontName="Helvetica-Bold", alignment=TA_CENTER, leading=14)
sH1       = S("h1",  fontSize=13, textColor=C_ACCENT,      fontName="Helvetica-Bold", leading=18, spaceAfter=3)
sH2       = S("h2",  fontSize=10, textColor=C_YELLOW,      fontName="Helvetica-Bold", leading=13, spaceAfter=2)
sBody     = S("bd",  fontSize=8.5,textColor=C_TEXT,        fontName="Helvetica",      leading=13, spaceAfter=4)
sSmall    = S("sm",  fontSize=7.5,textColor=C_SUBTEXT,     fontName="Helvetica",      leading=11)
sCallout  = S("ca",  fontSize=9,  textColor=colors.white,  fontName="Helvetica-Bold", leading=13, alignment=TA_CENTER)
sCallSm   = S("cs",  fontSize=7.5,textColor=C_SUBTEXT,     fontName="Helvetica",      leading=10, alignment=TA_CENTER)
sMLabel   = S("ml",  fontSize=7.5,textColor=C_SUBTEXT,     fontName="Helvetica",      leading=10, alignment=TA_CENTER)
sMValue   = S("mv",  fontSize=14, textColor=colors.white,  fontName="Helvetica-Bold", leading=18, alignment=TA_CENTER)
sSumHead  = S("sh",  fontSize=8,  textColor=C_SUBTEXT,     fontName="Helvetica-Bold", leading=10, alignment=TA_CENTER)
sSumVal   = S("sv",  fontSize=11, textColor=colors.white,  fontName="Helvetica-Bold", leading=14, alignment=TA_CENTER)
sSumSub   = S("ss",  fontSize=7,  textColor=C_SUBTEXT,     fontName="Helvetica",      leading=9,  alignment=TA_CENTER)


def divider(): return HRFlowable(width="100%", thickness=0.5, color=C_BORDER, spaceAfter=5, spaceBefore=5)


def metric_card(label, val, chg=None, pos=True):
    cs = S("_c", fontSize=8, leading=10, fontName="Helvetica-Bold", alignment=TA_CENTER,
           textColor=C_GREEN if pos else C_RED)
    data = [[Paragraph(label, sMLabel)], [Paragraph(val, sMValue)]]
    if chg: data.append([Paragraph(chg, cs)])
    t = Table(data, colWidths=[38*mm])
    t.setStyle(TableStyle([
        ("BACKGROUND",(0,0),(-1,-1),C_PANEL), ("BOX",(0,0),(-1,-1),0.5,C_BORDER),
        ("TOPPADDING",(0,0),(-1,-1),5), ("BOTTOMPADDING",(0,0),(-1,-1),5),
        ("LEFTPADDING",(0,0),(-1,-1),4), ("RIGHTPADDING",(0,0),(-1,-1),4),
    ]))
    return t


def outlook_box(signal, detail, border=C_GREEN):
    inner = Table([[Paragraph(signal, sCallout)],[Paragraph(detail, sCallSm)]],
                  colWidths=[IMG_W - 8*mm])
    inner.setStyle(TableStyle([
        ("BACKGROUND",(0,0),(-1,-1),colors.HexColor("#1A2A1A")),
        ("BOX",(0,0),(-1,-1),1,border),
        ("TOPPADDING",(0,0),(-1,-1),6), ("BOTTOMPADDING",(0,0),(-1,-1),6),
        ("LEFTPADDING",(0,0),(-1,-1),8), ("RIGHTPADDING",(0,0),(-1,-1),8),
    ]))
    return inner


def chart_section(title, subtitle, img_path, h=68*mm):
    items = [Paragraph(title, sH1)]
    if subtitle: items.append(Paragraph(subtitle, sSmall))
    if img_path and os.path.exists(img_path):
        items.append(Image(img_path, width=IMG_W, height=h))
    items.append(divider())
    return items


def build_summary_page(m, df_skew):
    """One-page cheat sheet - everything at a glance."""
    items = [
        Paragraph("★  Daily Cheat Sheet - Key Levels &amp; Signals", sH1),
        Paragraph("All key metrics condensed onto one page", sSmall),
        Spacer(1, 4*mm),
    ]

    # ── Big numbers row ────────────────────────────────────────────────────────
    def big_cell(label, val, sub, val_color=C_TEXT):
        vstyle = S("_v", fontSize=16, textColor=val_color, fontName="Helvetica-Bold",
                   leading=20, alignment=TA_CENTER)
        t = Table([[Paragraph(label, sSumHead)],
                   [Paragraph(val,   vstyle)],
                   [Paragraph(sub,   sSumSub)]], colWidths=[33*mm])
        t.setStyle(TableStyle([
            ("BACKGROUND",(0,0),(-1,-1),C_PANEL),
            ("BOX",(0,0),(-1,-1),0.5,C_BORDER),
            ("TOPPADDING",(0,0),(-1,-1),5), ("BOTTOMPADDING",(0,0),(-1,-1),5),
            ("LEFTPADDING",(0,0),(-1,-1),3), ("RIGHTPADDING",(0,0),(-1,-1),3),
        ]))
        return t

    chg_col = C_GREEN if m["chg_24h"] >= 0 else C_RED
    big_row = Table([[
        big_cell("BTC/USD",      f"${m['spot']:,.0f}", f"{m['chg_24h']:+.2f}% 24h", chg_col),
        big_cell("7d Return",    f"{m['chg_7d']:+.1f}%", f"${m['lo_7d']:,.0f}–${m['hi_7d']:,.0f}",
                 C_GREEN if m["chg_7d"]>=0 else C_RED),
        big_cell("Funding Ann.", f"{m['fr_ann']:.2f}%", "8h rate × 3 × 365",
                 C_GREEN if abs(m["fr_ann"]) < 20 else C_RED),
        big_cell("Hist. Vol",    f"{m['hv']:.1f}%",    f"DVOL {m['dvol']:.1f}"),
        big_cell("OI Total",     f"${m['oi_total_usd']:.1f}B", f"P/C {m['pcr']:.3f}"),
    ]], colWidths=[33*mm]*5)
    big_row.setStyle(TableStyle([("LEFTPADDING",(0,0),(-1,-1),2),("RIGHTPADDING",(0,0),(-1,-1),2)]))
    items += [big_row, Spacer(1, 4*mm)]

    # ── Key levels ─────────────────────────────────────────────────────────────
    items.append(Paragraph("Key Options Levels", sH2))
    lev_data = [
        ["Level", "Strike", "OI / Detail", "Role"],
        ["Call Wall #1",    f"${m['call_wall']:,}",   f"{m['call_wall_oi']:,.0f} BTC calls", "Primary Resistance"],
        ["Put Wall #1",     f"${m['put_wall']:,}",    f"{m['put_wall_oi']:,.0f} BTC puts",  "Primary Support"],
        ["Gamma Flip",      f"${m['gamma_flip']:,}" if m.get("gamma_flip") else "N/A",
                            "Dealer gamma = 0",        "Regime Change Level"],
        ["Max Vol Expiry",  m["max_call_exp"],         "Heaviest OI",         "Gamma Battleground"],
    ]
    lev_tbl = Table(lev_data, colWidths=[38*mm, 30*mm, 52*mm, 47*mm])
    lev_tbl.setStyle(TableStyle([
        ("BACKGROUND",(0,0),(-1,0), colors.HexColor("#1A1A2E")),
        ("TEXTCOLOR",(0,0),(-1,0),  C_ACCENT), ("FONTNAME",(0,0),(-1,0),"Helvetica-Bold"),
        ("FONTSIZE",(0,0),(-1,-1),8),
        ("ROWBACKGROUNDS",(0,1),(-1,-1),[C_PANEL, colors.HexColor("#0D1117")]),
        ("TEXTCOLOR",(0,1),(-1,-1),C_TEXT),
        ("ALIGN",(0,0),(-1,-1),"LEFT"), ("VALIGN",(0,0),(-1,-1),"MIDDLE"),
        ("TOPPADDING",(0,0),(-1,-1),4), ("BOTTOMPADDING",(0,0),(-1,-1),4),
        ("LEFTPADDING",(0,0),(-1,-1),6), ("RIGHTPADDING",(0,0),(-1,-1),6),
        ("BOX",(0,0),(-1,-1),0.5,C_BORDER), ("INNERGRID",(0,0),(-1,-1),0.3,C_BORDER),
        ("TEXTCOLOR",(3,1),(3,1),C_RED), ("TEXTCOLOR",(3,2),(3,2),C_GREEN),
    ]))
    items += [lev_tbl, Spacer(1, 4*mm)]

    # ── Skew snapshot ─────────────────────────────────────────────────────────
    items.append(Paragraph("Skew Snapshot - 25-Delta Risk Reversal by Expiry", sH2))
    if df_skew is not None and len(df_skew) > 0:
        skew_data = [["Expiry","ATM IV","25d Call IV","25d Put IV","RR25","Fly25","Skew"]]
        for _, row in df_skew.iterrows():
            skew_lbl = "Put Skew ▼" if row["rr25"] < -1 else ("Call Skew ▲" if row["rr25"] > 1 else "Neutral")
            skew_data.append([
                row["expiry"], f"{row['iv_atm']:.1f}%", f"{row['iv_25c']:.1f}%",
                f"{row['iv_25p']:.1f}%", f"{row['rr25']:+.1f}%", f"{row['fly25']:+.1f}%", skew_lbl,
            ])
        skew_tbl = Table(skew_data, colWidths=[22*mm,20*mm,22*mm,22*mm,18*mm,16*mm,27*mm])
        sk_style = [
            ("BACKGROUND",(0,0),(-1,0),colors.HexColor("#1A1A2E")),
            ("TEXTCOLOR",(0,0),(-1,0),C_ACCENT), ("FONTNAME",(0,0),(-1,0),"Helvetica-Bold"),
            ("FONTSIZE",(0,0),(-1,-1),7.5),
            ("ROWBACKGROUNDS",(0,1),(-1,-1),[C_PANEL, colors.HexColor("#0D1117")]),
            ("TEXTCOLOR",(0,1),(-1,-1),C_TEXT),
            ("ALIGN",(0,0),(-1,-1),"CENTER"), ("VALIGN",(0,0),(-1,-1),"MIDDLE"),
            ("TOPPADDING",(0,0),(-1,-1),3), ("BOTTOMPADDING",(0,0),(-1,-1),3),
            ("BOX",(0,0),(-1,-1),0.5,C_BORDER), ("INNERGRID",(0,0),(-1,-1),0.3,C_BORDER),
        ]
        for i, row in enumerate(skew_data[1:], 1):
            rr_val = float(row[4].replace("%",""))
            col = C_RED if rr_val < 0 else C_GREEN
            sk_style += [("TEXTCOLOR",(4,i),(4,i),col), ("TEXTCOLOR",(6,i),(6,i),col)]
        skew_tbl.setStyle(TableStyle(sk_style))
        items += [skew_tbl, Spacer(1, 4*mm)]
    else:
        items.append(Paragraph("Skew data unavailable.", sSmall))
        items.append(Spacer(1, 4*mm))

    # ── Signal grid ────────────────────────────────────────────────────────────
    items.append(Paragraph("Signal Grid", sH2))
    vol_prem = m["dvol"] - m["hv"]

    def sig_row(label, reading, verdict, vcolor):
        vstyle = S("_vr", fontSize=8, fontName="Helvetica-Bold", textColor=vcolor, leading=10)
        return [Paragraph(label, sSmall), Paragraph(reading, sSmall), Paragraph(verdict, vstyle)]

    sig_table_data = [
        sig_row("Price Momentum (24h)",    f"{m['chg_24h']:+.2f}%",
                "Bullish" if m["chg_24h"]>0.5 else ("Bearish" if m["chg_24h"]<-0.5 else "Neutral"),
                C_GREEN if m["chg_24h"]>0.5 else (C_RED if m["chg_24h"]<-0.5 else C_SUBTEXT)),
        sig_row("Price Momentum (7d)",     f"{m['chg_7d']:+.1f}%",
                "Bullish" if m["chg_7d"]>3 else ("Bearish" if m["chg_7d"]<-3 else "Neutral"),
                C_GREEN if m["chg_7d"]>3 else (C_RED if m["chg_7d"]<-3 else C_SUBTEXT)),
        sig_row("Funding Rate",            f"{m['fr_ann']:.2f}% ann.",
                "Extreme ⚠" if m["fr_ann"]>50 else ("Bullish" if 0<m["fr_ann"]<=50 else ("Neutral" if abs(m["fr_ann"])<=5 else "Bearish")),
                C_RED if m["fr_ann"]>50 else (C_GREEN if m["fr_ann"]>0 else C_SUBTEXT)),
        sig_row("Put/Call Ratio (OI)",     f"{m['pcr']:.3f}",
                "Bullish" if m["pcr"]<0.7 else ("Neutral" if m["pcr"]<1.0 else "Bearish"),
                C_GREEN if m["pcr"]<0.7 else (C_SUBTEXT if m["pcr"]<1.0 else C_RED)),
        sig_row("Vol/Trades PCR",          f"{m['vol_pcr']:.3f}",
                "Bullish" if m["vol_pcr"]<0.7 else ("Neutral" if m["vol_pcr"]<1.0 else "Bearish"),
                C_GREEN if m["vol_pcr"]<0.7 else (C_SUBTEXT if m["vol_pcr"]<1.0 else C_RED)),
        sig_row("HV vs DVOL",             f"HV {m['hv']:.1f}% / DVOL {m['dvol']:.1f}",
                "IV Fair" if abs(vol_prem)<=3 else ("IV Rich" if vol_prem>3 else "IV Cheap"),
                C_SUBTEXT if abs(vol_prem)<=3 else C_RED),
        sig_row("Term Structure",          "Contango" if m["contango"] else "Backwardation",
                "Bullish" if m["contango"] else "Bearish",
                C_GREEN if m["contango"] else C_RED),
        sig_row("Gamma Flip",
                f"${m['gamma_flip']:,}" if m.get("gamma_flip") else "N/A",
                "Above Spot - Bullish" if m.get("gamma_flip") and m["gamma_flip"] > m["spot"] else "Below Spot - Bearish",
                C_GREEN if m.get("gamma_flip") and m["gamma_flip"] > m["spot"] else C_SUBTEXT),
    ]
    sig_t = Table(sig_table_data, colWidths=[52*mm, 52*mm, 63*mm])
    sig_t.setStyle(TableStyle([
        ("FONTSIZE",(0,0),(-1,-1),8),
        ("ROWBACKGROUNDS",(0,0),(-1,-1),[C_PANEL, colors.HexColor("#0D1117")]),
        ("TOPPADDING",(0,0),(-1,-1),4), ("BOTTOMPADDING",(0,0),(-1,-1),4),
        ("LEFTPADDING",(0,0),(-1,-1),6), ("RIGHTPADDING",(0,0),(-1,-1),6),
        ("BOX",(0,0),(-1,-1),0.5,C_BORDER), ("INNERGRID",(0,0),(-1,-1),0.3,C_BORDER),
    ]))
    items += [sig_t, Spacer(1, 3*mm), divider()]
    items.append(Paragraph(
        "DISCLAIMER: For informational purposes only. Not financial advice. Data from Deribit API.", sSmall))
    return items


def build_pdf(metrics, chart_paths, out_path):
    m = metrics
    report_date = datetime.now(timezone.utc).strftime("%A, %d %B %Y")

    def on_page(canvas, doc):
        canvas.saveState()
        canvas.setFillColor(C_BG); canvas.rect(0,0,PAGE_W,PAGE_H,fill=1,stroke=0)
        canvas.setFillColor(C_PANEL); canvas.rect(0,PAGE_H-14*mm,PAGE_W,14*mm,fill=1,stroke=0)
        canvas.setFillColor(C_ACCENT); canvas.rect(0,PAGE_H-14.6*mm,PAGE_W,0.6*mm,fill=1,stroke=0)
        canvas.setFillColor(C_PANEL); canvas.rect(0,0,PAGE_W,10*mm,fill=1,stroke=0)
        canvas.setFont("Helvetica",7); canvas.setFillColor(C_SUBTEXT)
        canvas.drawString(MARGIN,3.5*mm,"BTC Options & Futures Daily Report  |  Deribit API")
        canvas.drawRightString(PAGE_W-MARGIN,3.5*mm,
            f"Generated {datetime.now(timezone.utc).strftime('%d %b %Y %H:%M UTC')}  |  Page {doc.page}")
        canvas.setFont("Helvetica-Bold",9); canvas.setFillColor(C_ACCENT)
        canvas.drawString(MARGIN,PAGE_H-9*mm,"BTC DAILY")
        canvas.setFont("Helvetica",9); canvas.setFillColor(C_SUBTEXT)
        canvas.drawString(MARGIN+43,PAGE_H-9*mm,"OPTIONS & FUTURES REPORT")
        canvas.drawRightString(PAGE_W-MARGIN,PAGE_H-9*mm,report_date)
        canvas.restoreState()

    story = []

    # ── Cover & KPI ────────────────────────────────────────────────────────────
    story += [Spacer(1,22*mm), Paragraph("BTC Options &amp; Futures",sTitle),
              Paragraph("Daily Market Intelligence Report",sSub), Spacer(1,4*mm),
              Paragraph(report_date,sDate), Spacer(1,6*mm), divider(), Spacer(1,3*mm)]

    chg_pos = m["chg_24h"] >= 0
    kpi = Table([[
        metric_card("BTC/USD Price",    f"${m['spot']:,.0f}",      f"{'▲' if chg_pos else '▼'} {m['chg_24h']:+.2f}% (24h)", chg_pos),
        metric_card("7-Day Return",     f"{m['chg_7d']:+.1f}%",    f"${m['lo_7d']:,.0f}–${m['hi_7d']:,.0f}", m["chg_7d"]>=0),
        metric_card("Funding (8h)",     f"{m['fr_latest']*100:.4f}%",f"Ann. {m['fr_ann']:.2f}%", m["fr_latest"]>=0),
        metric_card("Open Interest",    f"${m['oi_total_usd']:.2f}B",f"P/C {m['pcr']:.3f}", m["pcr"]<1),
        metric_card("HV / DVOL",        f"{m['hv']:.1f}% / {m['dvol']:.0f}", f"Vol premium {m['dvol']-m['hv']:+.1f}pp", True),
    ]], colWidths=[38*mm]*5)
    kpi.setStyle(TableStyle([("ALIGN",(0,0),(-1,-1),"CENTER"),
                              ("LEFTPADDING",(0,0),(-1,-1),2),("RIGHTPADDING",(0,0),(-1,-1),2)]))
    story += [kpi, Spacer(1,6*mm)]

    # ── Outlook ────────────────────────────────────────────────────────────────
    story += [Paragraph("★  Market Outlook &amp; Interpretation",sH1),
              Paragraph(f"Live data as of {datetime.now(timezone.utc).strftime('%d %b %Y %H:%M UTC')}",sSmall),
              Spacer(1,2*mm)]

    bias    = "CAUTIOUSLY BULLISH" if m["chg_7d"]>0 else "CAUTIOUSLY BEARISH"
    brd     = C_GREEN if m["chg_7d"]>0 else C_RED
    gf_str  = f"${m['gamma_flip']:,}" if m.get("gamma_flip") else "N/A"
    ts_str  = "Contango term structure supports bull thesis." if m["contango"] else "Backwardation - near-term caution."
    story.append(outlook_box(
        f"NEAR-TERM BIAS: {bias}  |  CALL WALL: ${m['call_wall']:,}  |  PUT WALL: ${m['put_wall']:,}",
        f"BTC {m['chg_7d']:+.1f}% (7d). Funding {m['fr_ann']:.2f}% ann. OI ${m['oi_total_usd']:.2f}B. "
        f"P/C {m['pcr']:.3f}. Gamma flip {gf_str}. {ts_str}",
        border=brd))
    story.append(Spacer(1,4*mm))

    story.append(Paragraph("Price &amp; Momentum", sH2))
    story.append(Paragraph(
        f"BTC at <b>${m['spot']:,.2f}</b>. 24h: <b>{m['chg_24h']:+.2f}%</b>. 7d: <b>{m['chg_7d']:+.1f}%</b>. "
        f"7-day range ${m['lo_7d']:,.0f}–${m['hi_7d']:,.0f} "
        f"({'above' if m['spot']>(m['hi_7d']+m['lo_7d'])/2 else 'below'} the midpoint - "
        f"{'bullish structure' if m['spot']>(m['hi_7d']+m['lo_7d'])/2 else 'softening bias'}).", sBody))

    story.append(Paragraph("Funding &amp; Leverage", sH2))
    fr_desc = f"Funding at <b>{m['fr_ann']:.2f}% annualised</b>. "
    fr_desc += ("Extreme - overleveraged longs, squeeze risk. " if m["fr_ann"]>50 else
                "Moderate positive - bulls paying, watch for squeeze. " if m["fr_ann"]>10 else
                "Near neutral - healthy base for next move. " if abs(m["fr_ann"])<=5 else
                "Negative - shorts paying longs, contrarian bullish signal. ")
    story.append(Paragraph(fr_desc, sBody))

    story.append(Paragraph("Greeks &amp; Dealer Positioning", sH2))
    gf = m.get("gamma_flip")
    story.append(Paragraph(
        f"Dealer gamma flips from negative to positive at <b>${gf:,}</b>. " if gf else "Gamma flip not computed. ",
        sBody))
    story.append(Paragraph(
        f"Above the gamma flip, dealers are <b>long gamma</b> - they buy dips and sell rips, dampening moves. "
        f"Below it, dealers are <b>short gamma</b> - they chase price, amplifying moves. "
        f"Current spot {'is above' if gf and m['spot']>gf else 'is below'} the gamma flip "
        f"({'stabilising' if gf and m['spot']>gf else 'volatile'} regime).", sBody))

    story.append(Paragraph("Skew &amp; Sentiment", sH2))
    story.append(Paragraph(
        f"24h volume put/call ratio: <b>{m['vol_pcr']:.3f}</b> "
        f"({'bullish flow - call-dominated' if m['vol_pcr']<0.8 else 'elevated put buying - hedging demand'}). "
        f"Vol risk premium (DVOL–HV): <b>{m['dvol']-m['hv']:+.1f}pp</b> "
        f"({'fairly priced' if abs(m['dvol']-m['hv'])<=3 else 'options rich vs. realised' if m['dvol']>m['hv']+3 else 'options cheap vs. realised'}). "
        f"Term structure: <b>{'Contango' if m['contango'] else 'Backwardation'}</b> - "
        f"{'bullish consensus, healthy carry' if m['contango'] else 'near-term selling pressure'}.", sBody))

    # ── Signal table ───────────────────────────────────────────────────────────
    story.append(Paragraph("Signal Summary", sH2))
    vol_prem = m["dvol"] - m["hv"]

    def sig_lbl_col(reading, pos_threshold=None, neg_threshold=None):
        if pos_threshold and reading > pos_threshold: return ("Bullish", C_GREEN)
        if neg_threshold and reading < neg_threshold: return ("Bearish", C_RED)
        return ("Neutral", C_SUBTEXT)

    rows = [
        ["Signal","Reading","Implication"],
        ["Price (24h)",     f"{m['chg_24h']:+.2f}%",   "Bullish" if m["chg_24h"]>0.5 else ("Bearish" if m["chg_24h"]<-0.5 else "Neutral")],
        ["Price (7d)",      f"{m['chg_7d']:+.1f}%",    "Bullish" if m["chg_7d"]>3 else ("Bearish" if m["chg_7d"]<-3 else "Neutral")],
        ["Funding",         f"{m['fr_ann']:.2f}% ann.", "Extreme ⚠" if m["fr_ann"]>50 else ("Bullish" if m["fr_ann"]>0 else "Neutral/Bearish")],
        ["OI P/C Ratio",    f"{m['pcr']:.3f}",          "Bullish" if m["pcr"]<0.7 else ("Neutral" if m["pcr"]<1.0 else "Bearish")],
        ["Volume P/C",      f"{m['vol_pcr']:.3f}",      "Bullish" if m["vol_pcr"]<0.7 else ("Neutral" if m["vol_pcr"]<1.0 else "Bearish")],
        ["HV vs DVOL",      f"{m['hv']:.1f}% / {m['dvol']:.1f}", "IV Fair" if abs(vol_prem)<=3 else ("IV Rich" if vol_prem>3 else "IV Cheap")],
        ["Term Structure",  "Contango" if m["contango"] else "Backwardation", "Bullish" if m["contango"] else "Bearish"],
        ["Call Wall",       f"${m['call_wall']:,} ({m['call_wall_oi']:,.0f} BTC)", "Primary Resistance"],
        ["Put Wall",        f"${m['put_wall']:,} ({m['put_wall_oi']:,.0f} BTC)",   "Primary Support"],
        ["Gamma Flip",      f"${m['gamma_flip']:,}" if m.get("gamma_flip") else "N/A",
                            ("Stabilising" if m.get("gamma_flip") and m["gamma_flip"]>m["spot"] else "Volatile Regime")],
    ]

    def sig_text_color(lbl):
        return {
            "Bullish":C_GREEN, "Bearish":C_RED, "Neutral":C_SUBTEXT,
            "IV Fair":C_SUBTEXT, "IV Rich":C_RED, "IV Cheap":C_GREEN,
            "Extreme ⚠":C_RED, "Contango":C_GREEN, "Backwardation":C_RED,
            "Primary Resistance":C_RED, "Primary Support":C_GREEN,
            "Stabilising":C_GREEN, "Volatile Regime":C_YELLOW,
            "Neutral/Bearish":C_SUBTEXT,
        }.get(lbl, C_TEXT)

    st = Table(rows, colWidths=[40*mm,52*mm,75*mm])
    ts_style = [
        ("BACKGROUND",(0,0),(-1,0),colors.HexColor("#1A1A2E")),
        ("TEXTCOLOR",(0,0),(-1,0),C_ACCENT), ("FONTNAME",(0,0),(-1,0),"Helvetica-Bold"),
        ("FONTSIZE",(0,0),(-1,-1),8),
        ("ROWBACKGROUNDS",(0,1),(-1,-1),[C_PANEL,colors.HexColor("#0D1117")]),
        ("TEXTCOLOR",(0,1),(-1,-1),C_TEXT),
        ("FONTNAME",(0,1),(0,-1),"Helvetica-Bold"), ("TEXTCOLOR",(0,1),(0,-1),C_SUBTEXT),
        ("ALIGN",(0,0),(-1,-1),"LEFT"), ("VALIGN",(0,0),(-1,-1),"MIDDLE"),
        ("TOPPADDING",(0,0),(-1,-1),4), ("BOTTOMPADDING",(0,0),(-1,-1),4),
        ("LEFTPADDING",(0,0),(-1,-1),6), ("RIGHTPADDING",(0,0),(-1,-1),6),
        ("BOX",(0,0),(-1,-1),0.5,C_BORDER), ("INNERGRID",(0,0),(-1,-1),0.3,C_BORDER),
    ]
    for i, row in enumerate(rows[1:], 1):
        ts_style.append(("TEXTCOLOR",(2,i),(2,i), sig_text_color(row[2])))
    st.setStyle(TableStyle(ts_style))
    story += [st, Spacer(1,3*mm), divider()]

    # ── Data chart pages ───────────────────────────────────────────────────────
    story.append(PageBreak())
    story += chart_section("1 · BTC/USD Price Index",    "Hourly - last 7 days",                      chart_paths.get("price"))
    story += chart_section("2 · Perpetual Funding Rate", "Annualised 8h rate - last 7 days",           chart_paths.get("funding"))
    story += chart_section("3 · Futures Term Structure", "USD premium above spot (contango/backwardation)", chart_paths.get("futures_premium"))
    story += chart_section("4 · OI by Expiration",       f"Calls {m['total_calls']:,.0f} | Puts {m['total_puts']:,.0f} | P/C {m['pcr']:.3f}", chart_paths.get("oi_expiry"))

    story.append(PageBreak())
    story += chart_section("5 · OI by Strike",            f"Call wall ${m['call_wall']:,} | Put wall ${m['put_wall']:,}", chart_paths.get("oi_strike"))
    story += chart_section("6 · Implied Volatility Smile",f"ATM IV vs HV {m['hv']:.1f}% | DVOL {m['dvol']:.1f}",        chart_paths.get("iv_smile"))
    story += chart_section("7 · Historical Volatility",   "30-day rolling realised vol - last 14 days",                  chart_paths.get("hv"))
    story += chart_section("8 · DVOL Index",              "Model-free implied vol index - 30 days",                      chart_paths.get("dvol"))

    story.append(PageBreak())
    story += chart_section("9 · Greeks - Dealer Gamma &amp; Delta Exposure",
        f"Gamma flip at ${m['gamma_flip']:,} | Above=stabilising, Below=volatile" if m.get("gamma_flip") else "Dealer Greeks by Strike",
        chart_paths.get("greeks"), h=110*mm)
    story += chart_section("10 · Volume &amp; Trades",
        f"24h opt vol {m['total_opt_vol']:,.0f} BTC | Volume P/C {m['vol_pcr']:.3f} | Futures {m['total_fut_vol']:,.0f} BTC",
        chart_paths.get("volume"), h=110*mm)

    story.append(PageBreak())
    story += chart_section("11 · Skew Analysis - 25-Delta Risk Reversal &amp; Butterfly",
        "Negative RR = put skew (fear) | Fly = vol premium for wings vs ATM",
        chart_paths.get("skew"), h=110*mm)

    # ── Summary cheat sheet ────────────────────────────────────────────────────
    story.append(PageBreak())
    story += build_summary_page(m, metrics.get("df_skew"))

    doc = SimpleDocTemplate(out_path, pagesize=A4,
                            leftMargin=MARGIN, rightMargin=MARGIN,
                            topMargin=18*mm, bottomMargin=14*mm,
                            title=f"BTC Daily Report - {report_date}")
    doc.build(story, onFirstPage=on_page, onLaterPages=on_page)


# ══════════════════════════════════════════════════════════════════════════════
# MAIN ORCHESTRATOR
# ══════════════════════════════════════════════════════════════════════════════
def run(out_dir: str):
    out_dir = Path(out_dir); out_dir.mkdir(parents=True, exist_ok=True)
    tmp = out_dir / "charts";  tmp.mkdir(exist_ok=True)

    print("=" * 55)
    print("  BTC Daily Report - Deribit API Edition v2")
    print("=" * 55)

    client = DeribitClient(CLIENT_ID, CLIENT_SECRET)
    client.authenticate()

    print("Fetching price history...")
    df_price = client.get_price_history(hours=168)
    print("Fetching perpetual ticker...")
    perp     = client.get_perpetual_ticker()
    print("Fetching funding rate history...")
    df_fr    = client.get_funding_rate_history(hours=168)
    print("Fetching historical volatility...")
    df_hv    = client.get_historical_volatility()
    print("Fetching DVOL...")
    df_dvol  = client.get_dvol_history(days=30)
    print("Fetching options book summary (this is the large one)...")
    df_opt   = client.get_options_summary()
    print(f"  → {len(df_opt)} option contracts loaded")
    print("Fetching futures book summary...")
    df_fut   = client.get_futures_summary()

    # ── Metrics ────────────────────────────────────────────────────────────────
    spot    = float(perp["index_price"])
    now_ts  = df_price["DateTime"].max()
    p_24h   = df_price[df_price["DateTime"] <= now_ts - pd.Timedelta(hours=24)]["Price"].iloc[-1]
    p_7d    = df_price[df_price["DateTime"] <= now_ts - pd.Timedelta(days=7)]["Price"].iloc[-1]

    fr_latest     = float(perp.get("current_funding", df_fr["FundingRate"].iloc[-1]))
    fr_ann        = fr_latest * 3 * 365 * 100
    fr_7d_avg_ann = df_fr["FundingRate"].mean() * 3 * 365 * 100

    oi_strike, oi_expiry, total_calls, total_puts, pcr = process_options(df_opt, spot)
    df_fp    = process_futures_premium(df_fut, spot)
    df_greeks, gamma_flip = process_greeks(df_opt, spot)
    vol_expiry, vol_strike, total_opt_vol, call_vol, put_vol, vol_pcr, total_fut_vol = process_volume(df_opt, df_fut)
    df_skew  = process_skew(df_opt, spot=spot)

    calls_above = oi_strike[oi_strike["strike"] > spot].nlargest(1, "Calls")
    puts_below  = oi_strike[oi_strike["strike"] < spot].nlargest(1, "Puts")
    call_wall    = int(calls_above["strike"].iloc[0]) if len(calls_above) else 0
    call_wall_oi = calls_above["Calls"].iloc[0]       if len(calls_above) else 0
    put_wall     = int(puts_below["strike"].iloc[0])  if len(puts_below)  else 0
    put_wall_oi  = puts_below["Puts"].iloc[0]         if len(puts_below)  else 0
    max_call_exp = oi_expiry.loc[oi_expiry["Total_Calls"].idxmax(), "expiry"]

    metrics = dict(
        spot=spot, chg_24h=(spot/p_24h-1)*100, chg_7d=(spot/p_7d-1)*100,
        hi_7d=df_price["Price"].max(), lo_7d=df_price["Price"].min(),
        fr_latest=fr_latest, fr_ann=fr_ann, fr_7d_avg_ann=fr_7d_avg_ann,
        hv=float(df_hv["HV"].iloc[-1]), dvol=float(df_dvol["DVOL"].iloc[-1]),
        total_calls=total_calls, total_puts=total_puts, pcr=pcr,
        call_wall=call_wall, call_wall_oi=call_wall_oi,
        put_wall=put_wall,   put_wall_oi=put_wall_oi,
        max_call_exp=max_call_exp, contango=df_fp["premium"].mean() > 0,
        oi_total_usd=(total_calls + total_puts) * spot / 1e9,
        gamma_flip=int(gamma_flip) if gamma_flip else None,
        total_opt_vol=total_opt_vol, call_vol=call_vol, put_vol=put_vol,
        vol_pcr=vol_pcr, total_fut_vol=total_fut_vol, df_skew=df_skew,
    )

    # ── Charts ─────────────────────────────────────────────────────────────────
    print("Generating charts...")
    cp = {
        "price":           str(tmp/"price.png"),
        "funding":         str(tmp/"funding.png"),
        "hv":              str(tmp/"hv.png"),
        "dvol":            str(tmp/"dvol.png"),
        "oi_expiry":       str(tmp/"oi_expiry.png"),
        "oi_strike":       str(tmp/"oi_strike.png"),
        "futures_premium": str(tmp/"futures_premium.png"),
        "iv_smile":        str(tmp/"iv_smile.png"),
        "greeks":          str(tmp/"greeks.png"),
        "volume":          str(tmp/"volume.png"),
        "skew":            str(tmp/"skew.png"),
    }
    make_price_chart(df_price,             cp["price"])
    make_funding_chart(df_fr,              cp["funding"])
    make_hv_chart(df_hv,                   cp["hv"])
    make_dvol_chart(df_dvol,               cp["dvol"])
    make_oi_expiry_chart(oi_expiry,        cp["oi_expiry"])
    make_oi_strike_chart(oi_strike, spot,  cp["oi_strike"])
    make_futures_premium_chart(df_fp,      cp["futures_premium"])
    make_iv_smile_chart(df_opt, spot,      cp["iv_smile"])
    make_gamma_chart(df_greeks, spot, gamma_flip, cp["greeks"])
    make_volume_chart(vol_expiry, vol_strike,      cp["volume"])
    make_skew_chart(df_skew,               cp["skew"])
    print("✓ All 11 charts generated")

    # ── PDF ────────────────────────────────────────────────────────────────────
    date_str = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    pdf_path = str(out_dir / f"BTC_Daily_Report_{date_str}.pdf")
    print("Building PDF...")
    build_pdf(metrics, cp, pdf_path)
    print(f"\n✓ Report saved: {pdf_path}")
    return pdf_path


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="BTC Deribit Daily Report")
    parser.add_argument("--out", default=".", help="Output directory")
    args = parser.parse_args()
    run(args.out)
