"""Phase 3 tests - quantile features."""
from __future__ import annotations

from pathlib import Path

import pytest

from portfolio_analysis import storage
from portfolio_analysis.features import price_change
from portfolio_analysis.tests.conftest import seed_btc_prices, seed_market_ticks


@pytest.fixture(autouse=True)
def _isolated_pa_db(tmp_path: Path):
    storage.set_db_path_for_tests(tmp_path / "pa.sqlite")
    yield
    storage.set_db_path_for_tests(None)


# ---------------------------------------------------------------------------
# compute_returns - 6 timeframes
# ---------------------------------------------------------------------------

def test_short_term_returns_use_realtime(
    isolated_realtime_db: Path, isolated_market_data_db: Path,
) -> None:
    """1h and 4h MUST come from the realtime ticks, not from btc_prices."""
    seed_market_ticks(isolated_realtime_db, [
        ("2026-05-02T08:00:00.000000Z", 100.0),    # 4h ago
        ("2026-05-02T11:00:00.000000Z", 105.0),    # 1h ago
        ("2026-05-02T12:00:00.000000Z", 110.0),    # now
    ])
    # Seed btc_prices at very different values; if the implementation
    # accidentally read from there for 1h/4h, the assertion would fail.
    seed_btc_prices(isolated_market_data_db, [
        ("2026-05-02", 999.0),
        ("2026-05-01", 999.0),
    ])
    out = price_change.compute_returns("2026-05-02T12:00:00.000000Z")
    assert out["1h"] == pytest.approx((110 - 105) / 105 * 100)
    assert out["4h"] == pytest.approx((110 - 100) / 100 * 100)


def test_long_term_returns_use_btc_prices(
    isolated_realtime_db: Path, isolated_market_data_db: Path,
) -> None:
    """1d / 7d / 15d / 30d MUST come from btc_prices, not from realtime."""
    # Latest realtime tick is the "now" leg.
    seed_market_ticks(isolated_realtime_db, [
        ("2026-05-02T12:00:00.000000Z", 110.0),
    ])
    # Seed btc_prices for each historical horizon. Sparse-by-design:
    # 30d-ago and 15d-ago dates are missing so we exercise the
    # "at-or-before" fallback.
    seed_btc_prices(isolated_market_data_db, [
        ("2026-04-01", 60.0),  # ≤ 30d ago (target 2026-04-02 → falls back to 04-01)
        ("2026-04-17", 70.0),  # 15d ago exact
        ("2026-04-25", 80.0),  # 7d ago exact
        ("2026-05-01", 90.0),  # 1d ago exact
    ])
    out = price_change.compute_returns("2026-05-02T12:00:00.000000Z")
    assert out["1d"]  == pytest.approx((110 - 90) / 90  * 100)
    assert out["7d"]  == pytest.approx((110 - 80) / 80  * 100)
    assert out["15d"] == pytest.approx((110 - 70) / 70  * 100)
    assert out["30d"] == pytest.approx((110 - 60) / 60  * 100)


def test_long_term_returns_handle_gaps(
    isolated_realtime_db: Path, isolated_market_data_db: Path,
) -> None:
    """If a target date is missing, daily-close lookup uses the most
    recent prior close (not None)."""
    seed_market_ticks(isolated_realtime_db, [
        ("2026-05-02T12:00:00.000000Z", 100.0),
    ])
    # Only one row in btc_prices, dated 9 days before "now". Both 1d and 7d
    # should fall through to it.
    seed_btc_prices(isolated_market_data_db, [
        ("2026-04-23", 80.0),
    ])
    out = price_change.compute_returns("2026-05-02T12:00:00.000000Z")
    expected = (100 - 80) / 80 * 100
    assert out["1d"] == pytest.approx(expected)
    assert out["7d"] == pytest.approx(expected)


def test_long_term_returns_none_when_btc_prices_empty(
    isolated_realtime_db: Path, isolated_market_data_db: Path,
) -> None:
    seed_market_ticks(isolated_realtime_db, [
        ("2026-05-02T12:00:00.000000Z", 100.0),
    ])
    out = price_change.compute_returns("2026-05-02T12:00:00.000000Z")
    for tf in ("1d", "7d", "15d", "30d"):
        assert out[tf] is None, f"expected None for {tf}, got {out[tf]}"


# ---------------------------------------------------------------------------
# compute_quantiles - agrees with numpy's linear interpolation
# ---------------------------------------------------------------------------

def test_quantiles_match_numpy_default() -> None:
    """Q1/median/Q3 match numpy's default 'linear' interpolation."""
    np = pytest.importorskip("numpy")
    values = [-2.0, -1.0, 0.0, 0.5, 1.0, 1.5, 2.0, 3.0]
    for i, v in enumerate(values):
        storage.insert_return(
            ts_utc=f"2026-05-02T0{i}:00:00.000000Z",
            timeframe="1h", return_pct=v,
        )
    q = price_change.compute_quantiles("1h")
    assert q is not None
    expected_q1 = float(np.percentile(values, 25))
    expected_med = float(np.percentile(values, 50))
    expected_q3 = float(np.percentile(values, 75))
    assert q[0] == pytest.approx(expected_q1)
    assert q[1] == pytest.approx(expected_med)
    assert q[2] == pytest.approx(expected_q3)


def test_quantiles_returns_none_when_too_few_samples() -> None:
    for i, v in enumerate([0.1, 0.2, 0.3]):  # only 3 - minimum is 4
        storage.insert_return(
            ts_utc=f"2026-05-02T0{i}:00:00Z", timeframe="1h", return_pct=v,
        )
    assert price_change.compute_quantiles("1h") is None


def test_quantiles_unknown_timeframe_raises() -> None:
    with pytest.raises(ValueError):
        price_change.compute_quantiles("99d")


def test_quantiles_isolated_per_timeframe() -> None:
    for i, v in enumerate([0.1, 0.2, 0.3, 0.4, 0.5]):
        storage.insert_return(
            ts_utc=f"2026-05-02T0{i}:00:00Z", timeframe="7d", return_pct=v,
        )
    assert price_change.compute_quantiles("1h") is None
    assert price_change.compute_quantiles("7d") is not None


# ---------------------------------------------------------------------------
# compute (bundle)
# ---------------------------------------------------------------------------

def test_compute_bundle_shape(isolated_realtime_db: Path) -> None:
    seed_market_ticks(isolated_realtime_db, [
        ("2026-05-02T11:00:00.000000Z", 100.0),
        ("2026-05-02T12:00:00.000000Z", 110.0),
    ])
    bundle = price_change.compute("2026-05-02T12:00:00.000000Z")
    assert set(bundle.returns.keys()) == set(price_change.PRICE_CHANGE_TIMEFRAMES.keys())
    assert set(bundle.quantiles.keys()) == set(price_change.PRICE_CHANGE_TIMEFRAMES.keys())
    assert bundle.returns["1h"] == pytest.approx(10.0)
