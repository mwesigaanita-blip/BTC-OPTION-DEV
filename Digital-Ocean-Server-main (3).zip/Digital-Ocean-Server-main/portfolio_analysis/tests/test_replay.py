"""Phase 12 tests - offline replay tool."""
from __future__ import annotations

import json
import sqlite3
from pathlib import Path

import pytest

from portfolio_analysis import notifier, replay, storage, thresholds


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture(autouse=True)
def _isolated_pa_db(tmp_path: Path, monkeypatch):
    """Replay should manage its own DB. We still pin the production override
    to a temp path so any accidental write is caught.

    Also isolate the BTC data sources (realtime + market_data) to empty
    files. Without this, the new ``btc_returns.compute_return`` would
    pick up real machine data, which makes alert counts non-deterministic.
    """
    storage.set_db_path_for_tests(tmp_path / "guard.sqlite")
    thresholds.invalidate_cache()
    notifier.reset_default_notifier()

    # Empty realtime + market_data DBs so all return computations return None.
    rt = tmp_path / "rt-empty.sqlite"
    md = tmp_path / "md-empty.sqlite"
    sqlite3.connect(str(rt)).close()
    sqlite3.connect(str(md)).close()
    import shared.db_paths as _dbp
    from portfolio_analysis.features import btc_returns as _btc_returns
    monkeypatch.setattr(_dbp, "REALTIME_DB", rt)
    monkeypatch.setattr(_dbp, "MARKET_DATA_DB", md)
    monkeypatch.setattr(_btc_returns, "REALTIME_DB", rt)
    monkeypatch.setattr(_btc_returns, "MARKET_DATA_DB", md)

    monkeypatch.setenv("DRY_RUN", "1")
    monkeypatch.setenv("TELEGRAM_PORTFOLIO_BOT_TOKEN", "fake")
    monkeypatch.setenv("TELEGRAM_CHAT_IDS", json.dumps({"remo": "111"}))
    yield
    thresholds.invalidate_cache()
    notifier.reset_default_notifier()
    storage.set_db_path_for_tests(None)


@pytest.fixture
def synthetic_he_db(tmp_path: Path):
    """Build a temp ``hedge_engine.sqlite`` with the agg-metrics table.
    Returns a callable that seeds rows: ``seed(rows: list[dict])``."""
    he_path = tmp_path / "hedge_engine.sqlite"
    conn = sqlite3.connect(str(he_path))
    conn.executescript("""
        CREATE TABLE hedge_engine_aggregated_metrics (
            ts_utc TEXT PRIMARY KEY,
            delta REAL, gamma REAL, vega REAL,
            mm_pct REAL, btc_price REAL, btc_roc REAL,
            sample_n INTEGER, created_at TEXT
        );
    """)
    conn.commit()

    def seed(rows: list[dict]) -> None:
        c = sqlite3.connect(str(he_path))
        for r in rows:
            c.execute(
                """INSERT OR REPLACE INTO hedge_engine_aggregated_metrics
                   (ts_utc, delta, gamma, vega, mm_pct, btc_price, btc_roc,
                    sample_n, created_at)
                   VALUES (?, ?, ?, ?, ?, ?, ?, 1, ?)""",
                (r["ts_utc"], r.get("delta", 0.0), r.get("gamma", 0.0),
                 r.get("vega", 0.0), r.get("mm_pct", 0.0),
                 r.get("btc_price", 100000.0), r.get("btc_roc", 0.0),
                 r["ts_utc"]),
            )
        c.commit(); c.close()

    return he_path, seed


# ---------------------------------------------------------------------------
# iter_agg_rows
# ---------------------------------------------------------------------------

def test_iter_agg_rows_empty_db_returns_nothing(tmp_path: Path) -> None:
    he_path = tmp_path / "missing.sqlite"
    rows = list(replay.iter_agg_rows(hours=24, he_db_path=he_path))
    assert rows == []


def test_iter_agg_rows_in_window(synthetic_he_db) -> None:
    he_path, seed = synthetic_he_db
    seed([
        {"ts_utc": "2026-05-02T08:00:00.000000Z"},
        {"ts_utc": "2026-05-02T11:00:00.000000Z"},
        {"ts_utc": "2026-05-02T11:30:00.000000Z"},
    ])
    rows = list(replay.iter_agg_rows(
        hours=24, he_db_path=he_path,
        end_iso="2026-05-02T12:00:00.000000Z",
    ))
    assert [r["ts_utc"] for r in rows] == [
        "2026-05-02T08:00:00.000000Z",
        "2026-05-02T11:00:00.000000Z",
        "2026-05-02T11:30:00.000000Z",
    ]


def test_iter_agg_rows_excludes_outside_window(synthetic_he_db) -> None:
    he_path, seed = synthetic_he_db
    seed([
        {"ts_utc": "2026-05-01T11:00:00.000000Z"},   # 25h before end → excluded
        {"ts_utc": "2026-05-02T11:00:00.000000Z"},   # in window
    ])
    rows = list(replay.iter_agg_rows(
        hours=24, he_db_path=he_path,
        end_iso="2026-05-02T12:00:00.000000Z",
    ))
    assert [r["ts_utc"] for r in rows] == ["2026-05-02T11:00:00.000000Z"]


# ---------------------------------------------------------------------------
# run_replay - controlled alert volume
# ---------------------------------------------------------------------------

def test_run_replay_no_data(synthetic_he_db) -> None:
    he_path, _ = synthetic_he_db
    out: list[str] = []
    s = replay.run_replay(hours=24, he_db_path=he_path, print_fn=out.append)
    assert s["rows"] == 0
    assert s["alerts_inserted"] == 0
    assert s["exceeded"] is False
    assert s["max_state"] == "RELAX"


def test_run_replay_under_ceiling(synthetic_he_db) -> None:
    """One MM warning band crossing → exactly 1 alert over 24h, well under ceiling."""
    he_path, seed = synthetic_he_db
    # 24 ticks (one per hour), MM jumps to warning band on tick 5 and stays.
    rows = []
    for i in range(24):
        rows.append({
            "ts_utc": f"2026-05-02T{i:02d}:00:00.000000Z",
            "mm_pct": 42.0 if i >= 5 else 10.0,
        })
    seed(rows)
    out: list[str] = []
    s = replay.run_replay(
        hours=24, he_db_path=he_path,
        end_iso="2026-05-03T00:00:00.000000Z",
        print_fn=out.append,
    )
    assert s["rows"] == 24
    assert s["alerts_inserted"] == 1               # dedup kept it to one
    assert s["alerts_per_hour"] < s["ceiling_per_hour"]
    assert s["exceeded"] is False
    assert s["max_state"] in ("TAKE_A_LOOK", "ACTIVE_MONITORING")
    # State-change line printed for the 1st transition.
    assert any("STATE" in line for line in out)
    assert any("ALERT" in line for line in out)


def test_run_replay_over_ceiling_marks_exceeded(synthetic_he_db) -> None:
    """Force many distinct alerts so per-hour count exceeds the ceiling."""
    he_path, seed = synthetic_he_db
    # Alternate mm_pct between bands across many ticks so MM keeps re-firing.
    bands = [10.0, 32.0, 10.0, 42.0, 10.0, 52.0]
    rows = [
        {
            "ts_utc": f"2026-05-02T01:{i:02d}:00.000000Z",
            "mm_pct": bands[i % len(bands)],
        }
        for i in range(60)
    ]
    seed(rows)
    s = replay.run_replay(
        hours=1, he_db_path=he_path, ceiling_per_hour=2.0,
        end_iso="2026-05-02T02:00:00.000000Z",
        quiet=True,
    )
    assert s["alerts_inserted"] >= 3
    assert s["alerts_per_hour"] > s["ceiling_per_hour"]
    assert s["exceeded"] is True


def test_run_replay_uses_temp_db_not_production(synthetic_he_db, tmp_path: Path) -> None:
    """The guard PA DB pinned by the autouse fixture must remain untouched."""
    he_path, seed = synthetic_he_db
    seed([{"ts_utc": "2026-05-02T11:00:00.000000Z", "mm_pct": 42.0}])
    guard_db = tmp_path / "guard.sqlite"
    # Sanity: the autouse fixture pinned this path.
    storage.init_db()
    rows_before = storage.unresolved_alerts()
    replay.run_replay(
        hours=24, he_db_path=he_path,
        end_iso="2026-05-02T12:00:00.000000Z",
        quiet=True,
    )
    rows_after = storage.unresolved_alerts()
    assert rows_before == rows_after  # production DB unchanged


def test_run_replay_quiet_suppresses_per_row(synthetic_he_db) -> None:
    he_path, seed = synthetic_he_db
    seed([{"ts_utc": "2026-05-02T11:00:00.000000Z", "mm_pct": 42.0}])
    out: list[str] = []
    replay.run_replay(
        hours=24, he_db_path=he_path,
        end_iso="2026-05-02T12:00:00.000000Z",
        quiet=True, print_fn=out.append,
    )
    # quiet → no header, no per-row, no summary.
    assert out == []


# ---------------------------------------------------------------------------
# CLI exit codes
# ---------------------------------------------------------------------------

def test_cli_exit_zero_under_ceiling(monkeypatch, synthetic_he_db, capsys) -> None:
    he_path, seed = synthetic_he_db
    seed([{"ts_utc": "2026-05-02T11:00:00.000000Z", "mm_pct": 42.0}])
    monkeypatch.setattr(replay, "HEDGE_ENGINE_DB", he_path)
    rc = replay.main([
        "--hours", "24", "--end-iso", "2026-05-02T12:00:00.000000Z",
        "--quiet",
    ])
    assert rc == 0


def test_cli_exit_nonzero_over_ceiling(monkeypatch, synthetic_he_db) -> None:
    he_path, seed = synthetic_he_db
    bands = [10.0, 32.0, 10.0, 42.0, 10.0, 52.0]
    rows = [
        {
            "ts_utc": f"2026-05-02T01:{i:02d}:00.000000Z",
            "mm_pct": bands[i % len(bands)],
        }
        for i in range(60)
    ]
    seed(rows)
    monkeypatch.setattr(replay, "HEDGE_ENGINE_DB", he_path)
    rc = replay.main([
        "--hours", "1",
        "--ceiling", "2.0",
        "--end-iso", "2026-05-02T02:00:00.000000Z",
        "--quiet",
    ])
    assert rc == 1
