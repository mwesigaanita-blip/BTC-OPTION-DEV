"""Tests for the unified BTC return calculator.

Verifies the source-by-horizon contract:
  * < 24 h → realtime.sqlite::market_ticks
  * ≥ 24 h → market_data.sqlite::btc_prices.close
"""
from __future__ import annotations

from pathlib import Path

import pytest

from portfolio_analysis.features import btc_returns
from portfolio_analysis.tests.conftest import seed_btc_prices, seed_market_ticks


# ---------------------------------------------------------------------------
# is_long_term - boundary
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("seconds,expected", [
    (60,        False),  # 1 m
    (3600,      False),  # 1 h
    (4 * 3600,  False),  # 4 h
    (86399,     False),  # just under 24 h
    (86400,     True),   # exactly 24 h
    (7 * 86400, True),
])
def test_is_long_term_boundary(seconds, expected) -> None:
    assert btc_returns.is_long_term(seconds) is expected


# ---------------------------------------------------------------------------
# Short-term path - uses realtime, ignores btc_prices
# ---------------------------------------------------------------------------

def test_short_term_uses_intraday(
    isolated_realtime_db: Path, isolated_market_data_db: Path,
) -> None:
    seed_market_ticks(isolated_realtime_db, [
        ("2026-05-02T11:00:00.000000Z", 100.0),  # 1h ago
        ("2026-05-02T12:00:00.000000Z", 110.0),  # now
    ])
    # Pollute btc_prices with values that would cause a wrong answer if
    # the implementation accidentally fell through to it.
    seed_btc_prices(isolated_market_data_db, [
        ("2026-05-02", 999.0), ("2026-05-01", 999.0),
    ])
    pct = btc_returns.compute_return(3600, now_utc="2026-05-02T12:00:00.000000Z")
    assert pct == pytest.approx(10.0)


def test_short_term_returns_none_when_realtime_empty(
    isolated_realtime_db: Path, isolated_market_data_db: Path,
) -> None:
    """No fallback to daily for sub-24h horizons."""
    seed_btc_prices(isolated_market_data_db, [
        ("2026-05-02", 100.0), ("2026-05-01", 100.0),
    ])
    pct = btc_returns.compute_return(3600, now_utc="2026-05-02T12:00:00.000000Z")
    assert pct is None  # current_price() falls back to daily, but past leg can't


# ---------------------------------------------------------------------------
# Long-term path - uses btc_prices, ignores realtime past
# ---------------------------------------------------------------------------

def test_long_term_uses_daily_close(
    isolated_realtime_db: Path, isolated_market_data_db: Path,
) -> None:
    seed_market_ticks(isolated_realtime_db, [
        ("2026-05-02T12:00:00.000000Z", 110.0),  # current price
    ])
    seed_btc_prices(isolated_market_data_db, [
        ("2026-05-01", 100.0),  # 1d ago
    ])
    pct = btc_returns.compute_return(86400, now_utc="2026-05-02T12:00:00.000000Z")
    assert pct == pytest.approx((110 - 100) / 100 * 100)


def test_long_term_uses_at_or_before_for_missing_dates(
    isolated_realtime_db: Path, isolated_market_data_db: Path,
) -> None:
    """Sparse daily series → walk back to the most recent prior close."""
    seed_market_ticks(isolated_realtime_db, [
        ("2026-05-02T12:00:00.000000Z", 110.0),
    ])
    # Target date for 1d return is 2026-05-01 - but it's missing.
    seed_btc_prices(isolated_market_data_db, [
        ("2026-04-30", 95.0),
    ])
    pct = btc_returns.compute_return(86400, now_utc="2026-05-02T12:00:00.000000Z")
    assert pct == pytest.approx((110 - 95) / 95 * 100)


def test_long_term_returns_none_when_btc_prices_empty(
    isolated_realtime_db: Path, isolated_market_data_db: Path,
) -> None:
    seed_market_ticks(isolated_realtime_db, [
        ("2026-05-02T12:00:00.000000Z", 110.0),
    ])
    pct = btc_returns.compute_return(86400, now_utc="2026-05-02T12:00:00.000000Z")
    assert pct is None


# ---------------------------------------------------------------------------
# current_price fallback ordering
# ---------------------------------------------------------------------------

def test_current_price_prefers_realtime(
    isolated_realtime_db: Path, isolated_market_data_db: Path,
) -> None:
    seed_market_ticks(isolated_realtime_db, [
        ("2026-05-02T12:00:00.000000Z", 111.0),
    ])
    seed_btc_prices(isolated_market_data_db, [
        ("2026-05-02", 999.0),
    ])
    assert btc_returns.current_price() == 111.0


def test_current_price_falls_back_to_daily(
    isolated_realtime_db: Path, isolated_market_data_db: Path,
) -> None:
    """No realtime ticks → use the latest daily close."""
    seed_btc_prices(isolated_market_data_db, [
        ("2026-05-02", 222.0),
    ])
    assert btc_returns.current_price() == 222.0


def test_current_price_returns_none_when_both_empty(
    isolated_realtime_db: Path, isolated_market_data_db: Path,
) -> None:
    assert btc_returns.current_price() is None


# ---------------------------------------------------------------------------
# Validation
# ---------------------------------------------------------------------------

def test_compute_return_rejects_non_positive_horizon(
    isolated_realtime_db: Path, isolated_market_data_db: Path,
) -> None:
    with pytest.raises(ValueError):
        btc_returns.compute_return(0)
    with pytest.raises(ValueError):
        btc_returns.compute_return(-3600)
