"""Tests for the per-day report retention sweep."""
from __future__ import annotations

import os
import time
from pathlib import Path

import pytest

from portfolio_analysis.report_daily import cleanup_duplicate_reports


# ---------------------------------------------------------------------------
# Helpers - make a fake PDF and stamp its mtime
# ---------------------------------------------------------------------------

def _touch_report(directory: Path, name: str, *, mtime: float | None = None) -> Path:
    p = directory / name
    p.write_bytes(b"%PDF-1.4 fake\n")
    if mtime is not None:
        os.utime(p, (mtime, mtime))
    return p


# ---------------------------------------------------------------------------
# Cases
# ---------------------------------------------------------------------------

def test_no_duplicates_no_op(tmp_path: Path) -> None:
    """With one PDF per day, nothing is deleted."""
    _touch_report(tmp_path, "portfolio_20260503-091500.pdf")
    _touch_report(tmp_path, "portfolio_20260504-091500.pdf")
    summary = cleanup_duplicate_reports(report_dir=tmp_path)
    assert summary["deleted"] == []
    assert summary["groups_scanned"] == 2
    assert {p.name for p in tmp_path.iterdir()} == {
        "portfolio_20260503-091500.pdf",
        "portfolio_20260504-091500.pdf",
    }


def test_keeps_only_newest_per_day_by_mtime(tmp_path: Path) -> None:
    """Three PDFs on the same date - only the newest mtime survives."""
    base = time.time()
    older   = _touch_report(tmp_path, "portfolio_20260505-090000.pdf", mtime=base - 200)
    middle  = _touch_report(tmp_path, "portfolio_20260505-103000.pdf", mtime=base - 100)
    newest  = _touch_report(tmp_path, "portfolio_20260505-160000.pdf", mtime=base - 1)
    summary = cleanup_duplicate_reports(report_dir=tmp_path)
    survivors = {p.name for p in tmp_path.iterdir()}
    assert survivors == {newest.name}
    assert sorted(summary["deleted"]) == sorted([str(older), str(middle)])
    assert summary["kept"] == [str(newest)]


def test_respects_keep_path(tmp_path: Path) -> None:
    """``keep_path`` overrides mtime ordering - that exact file survives."""
    base = time.time()
    older   = _touch_report(tmp_path, "portfolio_20260505-090000.pdf", mtime=base - 200)
    middle  = _touch_report(tmp_path, "portfolio_20260505-103000.pdf", mtime=base - 100)
    newest  = _touch_report(tmp_path, "portfolio_20260505-160000.pdf", mtime=base - 1)

    # Pin the OLDEST one as the survivor.
    cleanup_duplicate_reports(report_dir=tmp_path, keep_path=older)
    survivors = {p.name for p in tmp_path.iterdir()}
    assert survivors == {older.name}


def test_multi_day_independent(tmp_path: Path) -> None:
    """Cleanup operates per-day - duplicates on day X don't affect day Y."""
    base = time.time()
    a1 = _touch_report(tmp_path, "portfolio_20260504-090000.pdf", mtime=base - 600)
    a2 = _touch_report(tmp_path, "portfolio_20260504-150000.pdf", mtime=base - 500)
    b1 = _touch_report(tmp_path, "portfolio_20260505-080000.pdf", mtime=base - 200)
    b2 = _touch_report(tmp_path, "portfolio_20260505-160000.pdf", mtime=base - 100)
    cleanup_duplicate_reports(report_dir=tmp_path)
    survivors = sorted(p.name for p in tmp_path.iterdir())
    assert survivors == [a2.name, b2.name]


def test_ignores_unrelated_files(tmp_path: Path) -> None:
    """Foreign filenames in REPORT_DIR are NEVER touched."""
    _touch_report(tmp_path, "portfolio_20260505-090000.pdf")
    _touch_report(tmp_path, "portfolio_20260505-160000.pdf")
    foreign1 = tmp_path / "notes.txt"
    foreign1.write_text("keep me")
    foreign2 = tmp_path / "old_format_20260505.pdf"
    foreign2.write_bytes(b"%PDF-1.4")
    sub = tmp_path / "charts"
    sub.mkdir()
    cleanup_duplicate_reports(report_dir=tmp_path)
    assert foreign1.exists()
    assert foreign2.exists()
    assert sub.is_dir()


def test_missing_directory_returns_empty(tmp_path: Path) -> None:
    summary = cleanup_duplicate_reports(report_dir=tmp_path / "does_not_exist")
    assert summary["groups_scanned"] == 0
    assert summary["deleted"] == []


def test_default_dir_uses_config(monkeypatch, tmp_path: Path) -> None:
    """No ``report_dir`` arg → reads ``config.REPORT_DIR``."""
    from portfolio_analysis import config
    monkeypatch.setattr(config, "REPORT_DIR", tmp_path)
    base = time.time()
    a = _touch_report(tmp_path, "portfolio_20260505-090000.pdf", mtime=base - 200)
    b = _touch_report(tmp_path, "portfolio_20260505-160000.pdf", mtime=base - 1)
    cleanup_duplicate_reports()
    assert {p.name for p in tmp_path.iterdir()} == {b.name}
