"""Phase 7 tests - Telegram notifier adapter (DRY_RUN)."""
from __future__ import annotations

import json
from pathlib import Path

import pytest

from portfolio_analysis import notifier
from portfolio_analysis.rules.base import Alert


@pytest.fixture(autouse=True)
def _reset_notifier_singleton():
    notifier.reset_default_notifier()
    yield
    notifier.reset_default_notifier()


def _alert(**overrides) -> Alert:
    base = dict(
        rule="MM_PRESSURE",
        severity="WARNING",
        dedup_key="MM:band=warning",
        cited_features=["mm_pct"],
        feature_values={"mm_pct": 41.0, "thresholds": {"warn": 30, "urgent": 40}},
        message="Maintenance margin 41.00% - warning band (≥ 40%).",
    )
    base.update(overrides)
    return Alert(**base)


# ---------------------------------------------------------------------------
# load_chat_ids - JSON parsing of TELEGRAM_CHAT_IDS
# ---------------------------------------------------------------------------

def test_load_chat_ids_skips_empty(monkeypatch) -> None:
    monkeypatch.setenv(
        "TELEGRAM_CHAT_IDS",
        json.dumps({"remo": "1680106723", "andres": "", "ahmed": "  "}),
    )
    assert notifier.load_chat_ids() == ["1680106723"]


def test_load_chat_ids_unset(monkeypatch) -> None:
    monkeypatch.delenv("TELEGRAM_CHAT_IDS", raising=False)
    assert notifier.load_chat_ids() == []


def test_load_chat_ids_malformed_json(monkeypatch) -> None:
    monkeypatch.setenv("TELEGRAM_CHAT_IDS", "not-json")
    assert notifier.load_chat_ids() == []


def test_load_chat_ids_not_a_dict(monkeypatch) -> None:
    monkeypatch.setenv("TELEGRAM_CHAT_IDS", json.dumps(["111", "222"]))
    assert notifier.load_chat_ids() == []


def test_load_chat_ids_coerces_int_values(monkeypatch) -> None:
    monkeypatch.setenv("TELEGRAM_CHAT_IDS", json.dumps({"remo": 1680106723}))
    assert notifier.load_chat_ids() == ["1680106723"]


# ---------------------------------------------------------------------------
# is_dry_run
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("value,expected", [
    ("1", True), ("true", True), ("True", True), ("YES", True), ("on", True),
    ("0", False), ("false", False), ("", False),
])
def test_is_dry_run(monkeypatch, value, expected) -> None:
    monkeypatch.setenv("DRY_RUN", value)
    assert notifier.is_dry_run() is expected


def test_is_dry_run_unset(monkeypatch) -> None:
    monkeypatch.delenv("DRY_RUN", raising=False)
    assert notifier.is_dry_run() is False


# ---------------------------------------------------------------------------
# format_alert_html - snapshot
# ---------------------------------------------------------------------------

def test_format_alert_html_snapshot() -> None:
    text = notifier.format_alert_html(
        _alert(),
        ts_utc="2026-05-02T13:42:11Z",
    )
    expected = (
        "<b>⚠️ [WARNING] MM_PRESSURE</b>\n"
        "\n"
        "Maintenance margin 41.00% - warning band (≥ 40%).\n"
        "\n"
        "<b>Cited features:</b>\n"
        "• mm_pct = 41\n"
        "• thresholds = warn=30, urgent=40\n"
        "\n"
        "<i>2026-05-02 13:42 UTC</i>"
    )
    assert text == expected


def test_format_alert_html_escapes_html_special_chars() -> None:
    text = notifier.format_alert_html(
        _alert(message="x < y > z & q"),
    )
    assert "&lt;" in text and "&gt;" in text and "&amp;" in text
    assert "< y >" not in text


def test_format_alert_html_severity_icons() -> None:
    for sev, icon in [
        ("INFO", "ℹ️"), ("WARNING", "⚠️"), ("URGENT", "🚨"), ("EMERGENCY", "🆘"),
    ]:
        out = notifier.format_alert_html(_alert(severity=sev))
        assert icon in out


def test_format_alert_html_renders_explanation_and_suggestion() -> None:
    out = notifier.format_alert_html(
        _alert(
            explanation="MM% measures liquidation distance - at 41% you've crossed warning.",
            suggestion="Reduce leverage or add collateral.",
        ),
        ts_utc="2026-05-02T13:42:11Z",
    )
    assert "📖 What this means:" in out
    assert "MM% measures liquidation distance" in out
    assert "💡 What to consider:" in out
    assert "Reduce leverage or add collateral." in out
    # Explanation must come before cited features.
    assert out.index("What this means") < out.index("Cited features")


def test_format_alert_html_omits_sections_when_blank() -> None:
    out = notifier.format_alert_html(_alert())  # no explanation / suggestion
    assert "What this means" not in out
    assert "What to consider" not in out


# ---------------------------------------------------------------------------
# DRY_RUN end-to-end - no HTTP, log message only
# ---------------------------------------------------------------------------

def test_send_alert_dry_run_does_not_post(monkeypatch, caplog) -> None:
    """DRY_RUN=1 → no HTTP call; log line emitted with payload size."""
    posted = {"calls": 0}

    def fake_post(*a, **kw):
        posted["calls"] += 1
        raise AssertionError("must not hit Telegram in DRY_RUN")

    import requests
    monkeypatch.setattr(requests, "post", fake_post)
    monkeypatch.setenv("DRY_RUN", "1")
    monkeypatch.setenv("TELEGRAM_PORTFOLIO_BOT_TOKEN", "fake")
    monkeypatch.setenv("TELEGRAM_CHAT_IDS", json.dumps({"remo": "111"}))

    n = notifier.PortfolioNotifier()
    with caplog.at_level("INFO", logger="portfolio_analysis.notifier"):
        ok = n.send_alert(_alert(), ts_utc="2026-05-02T13:42:11Z")
    assert ok is True
    assert posted["calls"] == 0
    assert any("DRY_RUN notify_alert" in rec.message for rec in caplog.records)


def test_send_alert_no_token_returns_false(monkeypatch) -> None:
    monkeypatch.setenv("DRY_RUN", "0")
    monkeypatch.setenv("TELEGRAM_PORTFOLIO_BOT_TOKEN", "")
    monkeypatch.setenv("TELEGRAM_CHAT_IDS", json.dumps({"remo": "111"}))
    n = notifier.PortfolioNotifier()
    assert n.send_alert(_alert()) is False


def test_send_alert_no_chats_returns_false(monkeypatch) -> None:
    monkeypatch.setenv("DRY_RUN", "0")
    monkeypatch.setenv("TELEGRAM_PORTFOLIO_BOT_TOKEN", "fake")
    monkeypatch.setenv("TELEGRAM_CHAT_IDS", "")
    n = notifier.PortfolioNotifier()
    assert n.send_alert(_alert()) is False


# ---------------------------------------------------------------------------
# Real send (mocked HTTP) - bypass_cooldown + parse_mode=HTML
# ---------------------------------------------------------------------------

def test_send_alert_real_path_uses_bypass_cooldown_and_html(monkeypatch) -> None:
    captured: list[dict] = []

    class _Resp:
        def raise_for_status(self): pass

    def fake_post(url, json, timeout):
        captured.append({"url": url, "json": json, "timeout": timeout})
        return _Resp()

    import requests
    monkeypatch.setattr(requests, "post", fake_post)
    monkeypatch.setenv("DRY_RUN", "0")
    monkeypatch.setenv("TELEGRAM_PORTFOLIO_BOT_TOKEN", "TOKEN123")
    monkeypatch.setenv(
        "TELEGRAM_CHAT_IDS",
        json.dumps({"remo": "111", "andres": "222"}),
    )

    n = notifier.PortfolioNotifier()
    a = _alert()
    assert n.send_alert(a) is True
    # First send → 2 chats hit.
    assert len(captured) == 2
    chat_ids_sent = [c["json"]["chat_id"] for c in captured]
    assert chat_ids_sent == ["111", "222"]
    for c in captured:
        assert c["url"].endswith("/sendMessage")
        assert c["json"]["parse_mode"] == "HTML"
        assert "<b>" in c["json"]["text"]

    # Second send IMMEDIATELY → must NOT be cooldown-blocked.
    captured.clear()
    assert n.send_alert(a) is True
    assert len(captured) == 2  # still goes through


# ---------------------------------------------------------------------------
# Worker integration - inserted alerts trigger notify_alert
# ---------------------------------------------------------------------------

def test_worker_calls_notifier_on_new_alert(monkeypatch, tmp_path: Path) -> None:
    import sqlite3
    from portfolio_analysis import storage, thresholds, worker

    storage.set_db_path_for_tests(tmp_path / "pa.sqlite")
    thresholds.invalidate_cache()
    notifier.reset_default_notifier()

    # Patch HE DB to a temp file with a synthetic agg row.
    he_path = tmp_path / "hedge_engine.sqlite"
    c = sqlite3.connect(str(he_path))
    c.executescript("""
        CREATE TABLE hedge_engine_aggregated_metrics (
            ts_utc TEXT PRIMARY KEY,
            delta REAL, gamma REAL, vega REAL,
            mm_pct REAL, btc_price REAL, btc_roc REAL,
            sample_n INTEGER, created_at TEXT
        );
    """)
    c.execute(
        "INSERT INTO hedge_engine_aggregated_metrics VALUES "
        "('2026-05-02T12:00:00.000000Z', 0, 0, 0, 42.0, 100000, 0, 1, '2026-05-02T12:00:00Z')"
    )
    c.commit(); c.close()
    import shared.db_paths as _dbp
    monkeypatch.setattr(_dbp, "HEDGE_ENGINE_DB", he_path)
    monkeypatch.setattr(worker, "HEDGE_ENGINE_DB", he_path)

    # Force DRY_RUN to capture the call without real HTTP.
    monkeypatch.setenv("DRY_RUN", "1")
    monkeypatch.setenv("TELEGRAM_PORTFOLIO_BOT_TOKEN", "fake")
    monkeypatch.setenv("TELEGRAM_CHAT_IDS", json.dumps({"remo": "111"}))

    seen: list[Alert] = []
    real_notify = notifier.notify_alert

    def spy(alert, *, ts_utc=None):
        seen.append(alert)
        return real_notify(alert, ts_utc=ts_utc)

    monkeypatch.setattr("portfolio_analysis.worker._notifier.notify_alert", spy)

    try:
        s = worker.run_once()
        assert s is not None
        assert len(s["inserted"]) == 1
        assert len(seen) == 1
        assert seen[0].dedup_key == "MM:band=warning"

        # Second cycle: dedup → no insert → no notify.
        seen.clear()
        worker.run_once()
        assert seen == []
    finally:
        thresholds.invalidate_cache()
        storage.set_db_path_for_tests(None)
        notifier.reset_default_notifier()
