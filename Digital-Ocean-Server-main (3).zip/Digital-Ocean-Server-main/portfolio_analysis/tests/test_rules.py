"""Phase 4 tests - rules engine + dedup + resolution."""
from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path

import pytest

from portfolio_analysis import rules, storage, thresholds
from portfolio_analysis.features import FeatureBundle
from portfolio_analysis.features.market import MarketFeatures
from portfolio_analysis.features.positions import PositionFeature
from portfolio_analysis.features.price_change import PriceChangeFeatures
from portfolio_analysis.rules.delta_drift import DeltaDriftRule
from portfolio_analysis.rules.dte_risk import DTERiskRule
from portfolio_analysis.rules.mm_pressure import MMPressureRule
from portfolio_analysis.rules.price_quantile import PriceQuantileRule
from portfolio_analysis.rules.vol_sigma import VolSigmaRule


@pytest.fixture(autouse=True)
def _isolated(tmp_path: Path):
    storage.set_db_path_for_tests(tmp_path / "pa.sqlite")
    thresholds.invalidate_cache()
    yield
    thresholds.invalidate_cache()
    storage.set_db_path_for_tests(None)


def _bundle(
    *,
    ts="2026-05-02T12:00:00.000000Z",
    delta=None, gamma=None, vega=None, mm_pct=None, spot=100000.0,
    market_returns=None, market_sigmas=None,
    pc_returns=None, pc_quantiles=None,
    positions=None,
) -> FeatureBundle:
    return FeatureBundle(
        ts_utc=ts,
        spot=spot, delta=delta, gamma=gamma, vega=vega, mm_pct=mm_pct,
        market=MarketFeatures(
            returns=market_returns or {"1h": None, "4h": None, "24h": None},
            sigmas=market_sigmas or {"1h": None, "4h": None, "24h": None},
        ),
        price_change=PriceChangeFeatures(
            returns=pc_returns or {tf: None for tf in
                                   ["1h", "4h", "1d", "7d", "15d", "30d"]},
            quantiles=pc_quantiles or {tf: None for tf in
                                       ["1h", "4h", "1d", "7d", "15d", "30d"]},
        ),
        positions=list(positions or []),
    )


def _option(name="BTC-30MAY26-100000-C", *, dte_days=10.0, side="short",
            strike=100000.0, opt="C", spot=100000.0):
    return PositionFeature(
        instrument_name=name,
        strike=strike,
        expiry_utc=datetime(2026, 5, 30, 8, tzinfo=timezone.utc),
        dte_days=dte_days,
        distance_to_strike_pct=(strike - spot) / spot * 100.0,
        side=side,
        option_type=opt,
    )


# ===========================================================================
# Rule 1 - MM_PRESSURE
# ===========================================================================

@pytest.mark.parametrize("mm,expected_band,expected_severity", [
    (10.0, None, None),
    (29.99, None, None),
    (30.0, "attention", "INFO"),
    (39.99, "attention", "INFO"),
    (40.0, "warning", "WARNING"),
    (49.99, "warning", "WARNING"),
    (50.0, "critical", "URGENT"),
    (75.0, "critical", "URGENT"),
])
def test_mm_bands(mm, expected_band, expected_severity) -> None:
    alerts = MMPressureRule().evaluate(_bundle(mm_pct=mm), thresholds)
    if expected_band is None:
        assert alerts == []
    else:
        assert len(alerts) == 1
        assert alerts[0].dedup_key == f"MM:band={expected_band}"
        assert alerts[0].severity == expected_severity


def test_mm_no_alert_when_mm_pct_missing() -> None:
    assert MMPressureRule().evaluate(_bundle(mm_pct=None), thresholds) == []


def test_mm_respects_threshold_override() -> None:
    """Override MM_WARN_PCT to 15 → mm_pct=20 should now fire attention."""
    thresholds.set_override(
        name="MM_WARN_PCT", value=15.0, duration_s=3600,
        user_id=1, user_name="x",
    )
    alerts = MMPressureRule().evaluate(_bundle(mm_pct=20.0), thresholds)
    assert len(alerts) == 1
    assert alerts[0].dedup_key == "MM:band=attention"


# ===========================================================================
# Rule 2 - DELTA_DRIFT
# ===========================================================================

@pytest.mark.parametrize("delta,band,severity,sign", [
    (0.0,   None,        None,      None),
    (0.5,   None,        None,      None),
    (-0.5,  None,        None,      None),
    (0.6,   "warning",   "WARNING", "+"),
    (-0.7,  "warning",   "WARNING", "-"),
    (1.0,   "warning",   "WARNING", "+"),
    (1.5,   "critical",  "URGENT",  "+"),
    (-1.5,  "critical",  "URGENT",  "-"),
    (2.0,   "critical",  "URGENT",  "+"),
    (2.1,   "beyond",    "URGENT",  "+"),
    (-3.0,  "beyond",    "URGENT",  "-"),
])
def test_delta_bands(delta, band, severity, sign) -> None:
    alerts = DeltaDriftRule().evaluate(_bundle(delta=delta), thresholds)
    if band is None:
        assert alerts == []
    else:
        assert len(alerts) == 1
        assert alerts[0].dedup_key == f"DELTA:sign={sign}:band={band}"
        assert alerts[0].severity == severity


def test_delta_no_alert_when_missing() -> None:
    assert DeltaDriftRule().evaluate(_bundle(delta=None), thresholds) == []


# ===========================================================================
# Rule 3 - DTE_RISK (per-position)
# ===========================================================================

def test_dte_filters_above_warn() -> None:
    alerts = DTERiskRule().evaluate(_bundle(positions=[_option(dte_days=45)]), thresholds)
    assert alerts == []


def test_dte_warning_band() -> None:
    alerts = DTERiskRule().evaluate(_bundle(positions=[_option(dte_days=20)]), thresholds)
    assert len(alerts) == 1
    assert alerts[0].dedup_key.endswith(":band=warning")
    assert alerts[0].severity == "WARNING"


def test_dte_critical_band_at_boundary() -> None:
    alerts = DTERiskRule().evaluate(_bundle(positions=[_option(dte_days=15)]), thresholds)
    assert alerts[0].dedup_key.endswith(":band=critical")
    assert alerts[0].severity == "URGENT"


def test_dte_one_alert_per_position() -> None:
    alerts = DTERiskRule().evaluate(_bundle(positions=[
        _option(name="A", dte_days=20),
        _option(name="B", dte_days=10),
        _option(name="C", dte_days=45),  # safe - no alert
    ]), thresholds)
    keys = sorted(a.dedup_key for a in alerts)
    assert keys == ["DTE:A:band=warning", "DTE:B:band=critical"]


def test_dte_empty_positions() -> None:
    assert DTERiskRule().evaluate(_bundle(positions=[]), thresholds) == []


# ===========================================================================
# Rule 4 - VOL_SIGMA (per timeframe)
# ===========================================================================

@pytest.mark.parametrize("ret,sigma,band,severity,sign", [
    (0.5, 1.0, None, None, None),         # |z|=0.5 → normal
    (1.0, 1.0, None, None, None),         # |z|=1.0 → normal (boundary)
    (1.5, 1.0, "warning",  "WARNING", "+"),
    (-1.5, 1.0, "warning",  "WARNING", "-"),
    (2.5, 1.0, "critical", "URGENT",  "+"),
    (3.5, 1.0, "extreme",  "URGENT",  "+"),
    (-3.5, 1.0, "extreme", "URGENT",  "-"),
])
def test_vol_bands(ret, sigma, band, severity, sign) -> None:
    fb = _bundle(
        market_returns={"1h": ret, "4h": None, "24h": None},
        market_sigmas={"1h": sigma, "4h": None, "24h": None},
    )
    alerts = VolSigmaRule().evaluate(fb, thresholds)
    if band is None:
        assert alerts == []
    else:
        assert len(alerts) == 1
        assert alerts[0].dedup_key == f"VOL:1h:dir={sign}:band={band}"
        assert alerts[0].severity == severity


def test_vol_skipped_when_sigma_missing() -> None:
    fb = _bundle(
        market_returns={"1h": 5.0, "4h": None, "24h": None},
        market_sigmas={"1h": None, "4h": None, "24h": None},
    )
    assert VolSigmaRule().evaluate(fb, thresholds) == []


def test_vol_skipped_when_sigma_zero() -> None:
    fb = _bundle(
        market_returns={"1h": 5.0, "4h": None, "24h": None},
        market_sigmas={"1h": 0.0, "4h": None, "24h": None},
    )
    assert VolSigmaRule().evaluate(fb, thresholds) == []


def test_vol_one_alert_per_timeframe() -> None:
    fb = _bundle(
        market_returns={"1h": 1.5, "4h": 2.5, "24h": 0.5},
        market_sigmas={"1h": 1.0, "4h": 1.0, "24h": 1.0},
    )
    keys = sorted(a.dedup_key for a in VolSigmaRule().evaluate(fb, thresholds))
    assert keys == [
        "VOL:1h:dir=+:band=warning",
        "VOL:4h:dir=+:band=critical",
    ]


# ===========================================================================
# Rule 5 - PRICE_QUANTILE
# ===========================================================================

def test_quantile_inside_iqr_no_alert() -> None:
    fb = _bundle(
        pc_returns={"1h": 0.0, "4h": None, "1d": None, "7d": None, "15d": None, "30d": None},
        pc_quantiles={"1h": (-1.0, 0.0, 1.0), "4h": None, "1d": None, "7d": None, "15d": None, "30d": None},
    )
    assert PriceQuantileRule().evaluate(fb, thresholds) == []


def test_quantile_above_q3() -> None:
    """Short-horizon timeframes (1h/4h/1d) are owned by COMBINED_SIGNAL now;
    PRICE_QUANTILE only fires on 7d/15d/30d."""
    fb = _bundle(
        pc_returns={"1h": None, "4h": None, "1d": None, "7d": 1.5, "15d": None, "30d": None},
        pc_quantiles={"1h": None, "4h": None, "1d": None, "7d": (-1.0, 0.0, 1.0), "15d": None, "30d": None},
    )
    alerts = PriceQuantileRule().evaluate(fb, thresholds)
    assert len(alerts) == 1
    assert alerts[0].dedup_key == "QUANTILE:7d:dir=high"
    assert alerts[0].severity == "WARNING"


def test_quantile_below_q1() -> None:
    fb = _bundle(
        pc_returns={"1h": None, "4h": None, "1d": None, "7d": -2.0, "15d": None, "30d": None},
        pc_quantiles={"1h": None, "4h": None, "1d": None, "7d": (-1.0, 0.0, 1.0), "15d": None, "30d": None},
    )
    alerts = PriceQuantileRule().evaluate(fb, thresholds)
    assert alerts[0].dedup_key == "QUANTILE:7d:dir=low"


def test_quantile_skips_short_horizons() -> None:
    """1h, 4h, and 1d MUST be left to the combined rule - even with
    outside-IQR data, PRICE_QUANTILE produces nothing."""
    fb = _bundle(
        pc_returns={"1h": 5.0, "4h": -3.0, "1d": 2.0, "7d": None, "15d": None, "30d": None},
        pc_quantiles={
            "1h":  (-1.0, 0.0, 1.0),
            "4h":  (-1.0, 0.0, 1.0),
            "1d":  (-1.0, 0.0, 1.0),
            "7d":  None, "15d": None, "30d": None,
        },
    )
    assert PriceQuantileRule().evaluate(fb, thresholds) == []


def test_quantile_skipped_when_no_history() -> None:
    fb = _bundle(
        pc_returns={"1h": 5.0, "4h": None, "1d": None, "7d": None, "15d": None, "30d": None},
        pc_quantiles={"1h": None, "4h": None, "1d": None, "7d": None, "15d": None, "30d": None},
    )
    assert PriceQuantileRule().evaluate(fb, thresholds) == []


# ===========================================================================
# Rule 6 - pending stub
# ===========================================================================

def test_rule6_module_imports_but_not_in_registry() -> None:
    from portfolio_analysis.rules import rule6
    rule_names = [r.name for r in rules.ALL_RULES]
    assert "RULE_6_PENDING" not in rule_names
    with pytest.raises(NotImplementedError):
        rule6.load()


# ===========================================================================
# Registry
# ===========================================================================

def test_all_rules_registry_active_set() -> None:
    """Three rules are registered: MM, DELTA, DTE.

    Price-return rules (COMBINED_SIGNAL, PRICE_QUANTILE) and the legacy
    VOL_SIGMA are intentionally OFF - see ``rules/__init__.py`` for the
    one-line revert. Re-enabling either is a single uncomment.
    """
    assert len(rules.ALL_RULES) == 3
    names = {r.name for r in rules.ALL_RULES}
    assert names == {"MM_PRESSURE", "DELTA_DRIFT", "DTE_RISK"}


def test_evaluate_all_runs_every_active_rule() -> None:
    """A synthetic bundle hits all three currently-active rules."""
    fb = _bundle(
        mm_pct=42.0,
        delta=1.5,
        positions=[_option(dte_days=10)],
    )
    alerts = rules.evaluate_all(fb)
    rule_names = {a.rule for a in alerts}
    assert rule_names == {"MM_PRESSURE", "DELTA_DRIFT", "DTE_RISK"}


# ===========================================================================
# Dedup + resolution
# ===========================================================================

def test_dedup_first_fire_inserts_second_skipped() -> None:
    fb = _bundle(mm_pct=42.0)
    candidates = rules.evaluate_all(fb)
    inserted = rules.dedup_and_persist(candidates, ts_utc="2026-05-02T12:00:00Z")
    assert len(inserted) == 1
    # Same band → second pass inserts nothing.
    inserted2 = rules.dedup_and_persist(candidates, ts_utc="2026-05-02T12:00:30Z")
    assert inserted2 == []
    assert len(storage.unresolved_alerts()) == 1


def test_dedup_resolve_then_refire_inserts_new_row() -> None:
    fb_warn = _bundle(mm_pct=42.0)
    rules.dedup_and_persist(rules.evaluate_all(fb_warn), ts_utc="2026-05-02T12:00:00Z")

    # mm clears → resolve_cleared() should resolve the open alert.
    fb_clear = _bundle(mm_pct=10.0)
    active_keys = {a.dedup_key for a in rules.evaluate_all(fb_clear)}
    resolved, cleared = rules.resolve_cleared(active_keys, ts_utc="2026-05-02T12:01:00Z")
    assert len(resolved) == 1
    assert cleared == []
    assert storage.unresolved_alerts() == []

    # mm rises again → must insert a new row (different ts_utc).
    inserted = rules.dedup_and_persist(rules.evaluate_all(fb_warn),
                                        ts_utc="2026-05-02T12:02:00Z")
    assert len(inserted) == 1
    assert len(storage.unresolved_alerts()) == 1


def test_dedup_active_suppression_blocks_insert() -> None:
    """If user suppressed this dedup_key, the rule must not insert."""
    storage.insert_suppression(
        dedup_key="MM:band=warning",
        set_by_user_id=42, set_by_user_name="andres",
    )
    fb = _bundle(mm_pct=42.0)
    inserted = rules.dedup_and_persist(rules.evaluate_all(fb),
                                        ts_utc="2026-05-02T12:00:00Z")
    assert inserted == []
    assert storage.unresolved_alerts() == []


def test_resolve_clears_matching_suppression() -> None:
    """When the underlying condition resolves, the active suppression
    for that dedup_key must also be cleared (per plan.md §4)."""
    # Fire once.
    fb_warn = _bundle(mm_pct=42.0)
    rules.dedup_and_persist(rules.evaluate_all(fb_warn), ts_utc="2026-05-02T12:00:00Z")
    # User suppresses.
    storage.insert_suppression(
        dedup_key="MM:band=warning",
        set_by_user_id=42, set_by_user_name="andres",
    )
    assert len(storage.active_suppressions()) == 1
    # Condition clears.
    active = {a.dedup_key for a in rules.evaluate_all(_bundle(mm_pct=10.0))}
    resolved, cleared = rules.resolve_cleared(active, ts_utc="2026-05-02T12:05:00Z")
    assert len(resolved) == 1
    assert cleared == ["MM:band=warning"]
    assert storage.active_suppressions() == []

    # And once cleared, the next fire is allowed again.
    inserted = rules.dedup_and_persist(rules.evaluate_all(fb_warn),
                                        ts_utc="2026-05-02T12:06:00Z")
    assert len(inserted) == 1


def test_dedup_within_same_batch_only_inserts_once() -> None:
    """If two rules emitted the same dedup_key in one cycle, only one row."""
    a = _bundle(mm_pct=42.0)
    candidates = rules.evaluate_all(a) + rules.evaluate_all(a)  # duplicated on purpose
    inserted = rules.dedup_and_persist(candidates, ts_utc="2026-05-02T12:00:00Z")
    assert len(inserted) == 1
    assert len(storage.unresolved_alerts()) == 1
