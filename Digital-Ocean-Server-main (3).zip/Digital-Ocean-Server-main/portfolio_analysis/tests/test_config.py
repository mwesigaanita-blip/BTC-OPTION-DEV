"""Phase 0 tests - config defaults & master threshold list."""
from __future__ import annotations

import pytest

from portfolio_analysis import config


EXPECTED_DEFAULTS: dict[str, float | int] = {
    "MM_WARN_PCT":                   30.0,
    "MM_URGENT_PCT":                 40.0,
    "MM_CRITICAL_PCT":               50.0,
    "DELTA_GOOD_BTC":                0.50,
    "DELTA_WARN_BTC":                1.00,
    "DELTA_CRITICAL_BTC":            2.00,
    "DTE_WARN_DAYS":                 30,
    "DTE_CRITICAL_DAYS":             15,
    "HEARTBEAT_RELAX_S":             6 * 60 * 60,
    "HEARTBEAT_TAKE_A_LOOK_S":       2 * 60 * 60,
    "HEARTBEAT_ACTIVE_MONITORING_S": 30 * 60,
    "HEARTBEAT_URGENT_ACTION_S":     60,
}


@pytest.mark.parametrize("name,expected", list(EXPECTED_DEFAULTS.items()))
def test_default_value_matches_master_list(name: str, expected: float | int) -> None:
    """Every overrideable threshold has the documented default value."""
    assert name in config.DEFAULT_THRESHOLDS, f"{name} missing from DEFAULT_THRESHOLDS"
    assert config.DEFAULT_THRESHOLDS[name] == expected
    assert getattr(config, name) == expected


def test_default_thresholds_contains_only_known_names() -> None:
    """No surprise entries - DEFAULT_THRESHOLDS exactly matches the spec."""
    assert set(config.DEFAULT_THRESHOLDS.keys()) == set(EXPECTED_DEFAULTS.keys())


@pytest.mark.parametrize("name", list(EXPECTED_DEFAULTS.keys()))
def test_default_value_is_numeric(name: str) -> None:
    value = config.DEFAULT_THRESHOLDS[name]
    assert isinstance(value, (int, float)) and not isinstance(value, bool)


def test_fixed_constants_present() -> None:
    """Sigma + quantile constants are fixed (not overrideable) but must exist."""
    assert config.SIGMA_LOOKBACK_DAYS == 90
    assert config.SIGMA_WARNING_MULT == 1.0
    assert config.SIGMA_CRITICAL_MULT == 2.0
    assert config.SIGMA_EXTREME_MULT == 3.0
    assert config.QUANTILE_LOOKBACK_DAYS == 90
    assert config.QUANTILE_LOW == 0.25
    assert config.QUANTILE_MEDIAN == 0.50
    assert config.QUANTILE_HIGH == 0.75


def test_fixed_constants_not_in_overrideable_list() -> None:
    """Sigma / quantile constants must NOT be in the overrideable master list."""
    forbidden = {
        "SIGMA_LOOKBACK_DAYS", "SIGMA_WARNING_MULT", "SIGMA_CRITICAL_MULT", "SIGMA_EXTREME_MULT",
        "QUANTILE_LOOKBACK_DAYS", "QUANTILE_LOW", "QUANTILE_MEDIAN", "QUANTILE_HIGH",
    }
    assert forbidden.isdisjoint(config.DEFAULT_THRESHOLDS.keys())
