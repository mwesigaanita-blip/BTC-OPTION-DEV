"""Phase 11 tests - PortfolioScheduler (process supervisor)."""
from __future__ import annotations

import json
import sys
import time
from io import StringIO
from pathlib import Path

import pytest

from portfolio_analysis import notifier, scheduler, storage, thresholds


@pytest.fixture(autouse=True)
def _isolated(tmp_path: Path, monkeypatch):
    storage.set_db_path_for_tests(tmp_path / "pa.sqlite")
    thresholds.invalidate_cache()
    notifier.reset_default_notifier()
    monkeypatch.setenv("DRY_RUN", "1")
    monkeypatch.setenv("TELEGRAM_PORTFOLIO_BOT_TOKEN", "fake")
    monkeypatch.setenv("TELEGRAM_CHAT_IDS", json.dumps({"remo": "111"}))
    yield
    thresholds.invalidate_cache()
    notifier.reset_default_notifier()
    storage.set_db_path_for_tests(None)


# ---------------------------------------------------------------------------
# Lifecycle
# ---------------------------------------------------------------------------

def test_scheduler_start_runs_three_workers() -> None:
    s = scheduler.PortfolioScheduler(
        alert_interval_s=0.1, heartbeat_interval_s=0.1, report_interval_s=0.1,
    )
    s.start()
    try:
        time.sleep(0.3)
        h = s.health_check()
        assert h["workers"]["alert"] is True
        assert h["workers"]["heartbeat"] is True
        assert h["workers"]["report"] is True
        assert h["uptime_s"] > 0
        assert h["stopped"] is False
    finally:
        s.stop(timeout_s=2.0)


def test_scheduler_stop_clean_within_timeout() -> None:
    s = scheduler.PortfolioScheduler(
        alert_interval_s=0.1, heartbeat_interval_s=0.1, report_interval_s=0.1,
    )
    s.start()
    time.sleep(0.2)
    t0 = time.monotonic()
    s.stop(timeout_s=10.0)
    elapsed = time.monotonic() - t0
    # Generous bound: under load, the daemon-thread join can take a few
    # seconds while other tests run. We only care that stop is bounded,
    # not that it's instantaneous.
    assert elapsed < 9.0, f"stop took {elapsed:.2f}s - workers didn't exit cleanly"
    h = s.health_check()
    assert h["workers"]["alert"] is False
    assert h["workers"]["heartbeat"] is False
    assert h["workers"]["report"] is False


def test_scheduler_double_start_raises() -> None:
    s = scheduler.PortfolioScheduler(
        alert_interval_s=10, heartbeat_interval_s=10, report_interval_s=10,
    )
    s.start()
    try:
        with pytest.raises(RuntimeError):
            s.start()
    finally:
        s.stop(timeout_s=2.0)


def test_scheduler_stop_without_start_is_noop() -> None:
    s = scheduler.PortfolioScheduler()
    s.stop()  # must not raise


# ---------------------------------------------------------------------------
# Health
# ---------------------------------------------------------------------------

def test_health_check_includes_db_state(tmp_path: Path, monkeypatch) -> None:
    # Steer the AlertWorker's HE DB read at a non-existent path so it can't
    # resolve our pre-seeded alert by reading "real" data.
    import shared.db_paths as _dbp
    from portfolio_analysis import worker as _worker
    missing = tmp_path / "missing-he.sqlite"
    monkeypatch.setattr(_dbp, "HEDGE_ENGINE_DB", missing)
    monkeypatch.setattr(_worker, "HEDGE_ENGINE_DB", missing)

    storage.insert_state(
        ts_utc="2026-05-02T12:00:00Z", calm_score="ACTIVE_MONITORING",
        active_alert_ids=[1], reasoning="r",
    )
    storage.insert_alert(
        ts_utc="2026-05-02T12:00:00Z", rule="MM_PRESSURE", severity="WARNING",
        dedup_key="MM:band=warning", cited_features=[], feature_values={},
    )
    storage.insert_suppression(
        dedup_key="MM:band=warning",
        set_by_user_id=1, set_by_user_name="x",
    )
    s = scheduler.PortfolioScheduler()
    s.start()
    try:
        time.sleep(0.05)
        h = s.health_check()
        assert h["calm_score"] == "ACTIVE_MONITORING"
        assert h["active_alerts"] >= 1
        assert h["active_suppressions"] >= 1
    finally:
        s.stop(timeout_s=2.0)


def test_health_check_before_start() -> None:
    s = scheduler.PortfolioScheduler()
    h = s.health_check()
    assert h["uptime_s"] == 0.0
    assert h["workers"] == {"alert": False, "heartbeat": False, "report": False}


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def test_cli_health_runs_full_stack_and_exits_zero(monkeypatch, capsys) -> None:
    """``--health`` runs ~12s in production; we patch sleep to fast-forward."""
    real_sleep = time.sleep
    sleeps: list[float] = []

    def fake_sleep(n):
        sleeps.append(float(n))
        if n >= 5:
            real_sleep(0.1)   # short-circuit the 12s wait
        else:
            real_sleep(n)

    monkeypatch.setattr(scheduler.time, "sleep", fake_sleep)
    rc = scheduler.main(["--health"])
    out = capsys.readouterr().out
    assert rc == 0
    payload = json.loads(out)
    assert "uptime_s" in payload
    assert set(payload["workers"].keys()) == {"alert", "heartbeat", "report"}
    assert any(s >= 5 for s in sleeps)  # the 12s health pause was issued


def test_cli_parses_interval_overrides() -> None:
    """The argparser accepts the three interval overrides without crashing."""
    import argparse
    # We don't run the loop - just verify args parse.
    parser = argparse.ArgumentParser()
    # Smoke-test by importing main and inspecting it doesn't reject flags.
    # If parsing fails, calling main([...]) with --health would raise SystemExit(2).
    rc = scheduler.main([
        "--alert-interval", "0.1",
        "--heartbeat-interval", "0.1",
        "--report-interval", "0.1",
        "--health",
    ])
    assert rc == 0
