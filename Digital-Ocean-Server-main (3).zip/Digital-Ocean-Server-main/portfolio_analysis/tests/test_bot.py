"""Phase 8 tests - Telegram bot control plane."""
from __future__ import annotations

import json
from pathlib import Path

import pytest

from portfolio_analysis import notifier as _notifier
from portfolio_analysis import storage, thresholds
from portfolio_analysis.bot import auth, broadcast, commands


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture(autouse=True)
def _isolated_db(tmp_path: Path):
    storage.set_db_path_for_tests(tmp_path / "pa.sqlite")
    thresholds.invalidate_cache()
    _notifier.reset_default_notifier()
    yield
    thresholds.invalidate_cache()
    _notifier.reset_default_notifier()
    storage.set_db_path_for_tests(None)


@pytest.fixture(autouse=True)
def _dry_run_on(monkeypatch):
    """All bot tests run in DRY_RUN so broadcasts log instead of posting."""
    monkeypatch.setenv("DRY_RUN", "1")
    monkeypatch.setenv("TELEGRAM_PORTFOLIO_BOT_TOKEN", "fake")
    monkeypatch.setenv("TELEGRAM_CHAT_IDS", json.dumps({"remo": "111"}))


@pytest.fixture
def auth_env(monkeypatch):
    monkeypatch.setenv(
        "AUTHORIZED_TELEGRAM_USERS",
        json.dumps({"andres": "42", "remo": "111", "blank": ""}),
    )


# ===========================================================================
# auth
# ===========================================================================

def test_auth_load_users(auth_env) -> None:
    users = auth.load_authorized_users()
    assert users == {42: "andres", 111: "remo"}  # blank skipped


def test_auth_is_authorized(auth_env) -> None:
    assert auth.is_authorized(42) is True
    assert auth.is_authorized(99) is False


def test_auth_name_for(auth_env) -> None:
    assert auth.name_for(42) == "andres"
    assert auth.name_for(99) is None


def test_auth_unset(monkeypatch) -> None:
    monkeypatch.delenv("AUTHORIZED_TELEGRAM_USERS", raising=False)
    assert auth.load_authorized_users() == {}
    assert auth.is_authorized(42) is False


def test_auth_malformed_json(monkeypatch) -> None:
    monkeypatch.setenv("AUTHORIZED_TELEGRAM_USERS", "not-json")
    assert auth.load_authorized_users() == {}


def test_auth_bad_id_value(monkeypatch) -> None:
    monkeypatch.setenv(
        "AUTHORIZED_TELEGRAM_USERS",
        json.dumps({"a": "42", "b": "abc", "c": "99"}),
    )
    assert auth.load_authorized_users() == {42: "a", 99: "c"}


# ===========================================================================
# broadcast
# ===========================================================================

def test_broadcast_dry_run_logs(caplog) -> None:
    with caplog.at_level("INFO", logger="portfolio_analysis.bot.broadcast"):
        ok = broadcast.broadcast("hello world")
    assert ok is True
    assert any("DRY_RUN broadcast" in r.message for r in caplog.records)


def test_broadcast_no_token_returns_false(monkeypatch) -> None:
    monkeypatch.setenv("DRY_RUN", "0")
    monkeypatch.setenv("TELEGRAM_PORTFOLIO_BOT_TOKEN", "")
    assert broadcast.broadcast("hello") is False


def test_broadcast_no_chats_returns_false(monkeypatch) -> None:
    monkeypatch.setenv("DRY_RUN", "0")
    monkeypatch.setenv("TELEGRAM_PORTFOLIO_BOT_TOKEN", "fake")
    monkeypatch.setenv("TELEGRAM_CHAT_IDS", "")
    assert broadcast.broadcast("hello") is False


# ===========================================================================
# dispatch - auth + parsing
# ===========================================================================

def test_dispatch_unauthorized(auth_env) -> None:
    r = commands.dispatch(text="/status", user_id=999)
    assert r is not None
    assert r.ok is False
    assert "Not authorized" in r.reply


def test_dispatch_non_command_returns_none(auth_env) -> None:
    assert commands.dispatch(text="hey there", user_id=42) is None


def test_dispatch_unknown_command(auth_env) -> None:
    r = commands.dispatch(text="/totallymade_up", user_id=42)
    assert r is not None
    assert r.ok is False
    assert "Unknown command" in r.reply


def test_dispatch_strips_bot_suffix(auth_env) -> None:
    r = commands.dispatch(text="/status@MyPortfolioBot", user_id=42)
    assert r is not None
    assert "Calm Score" in r.reply


# ===========================================================================
# /set
# ===========================================================================

def test_set_happy_path(auth_env) -> None:
    r = commands.dispatch(text="/set MM_WARN_PCT 25 1h", user_id=42)
    assert r.ok is True
    assert "MM_WARN_PCT" in r.reply
    assert "25" in r.reply
    # Override applied.
    assert thresholds.get("MM_WARN_PCT") == 25.0
    # Audit row written (set_threshold from thresholds.set_override).
    audit = storage.recent_audit(10)
    assert any(a["action"] == "set_threshold" for a in audit)


def test_set_unknown_threshold(auth_env) -> None:
    r = commands.dispatch(text="/set NOPE 25 1h", user_id=42)
    assert r.ok is False
    assert "Unknown threshold" in r.reply


def test_set_wrong_arg_count(auth_env) -> None:
    r = commands.dispatch(text="/set MM_WARN_PCT 25", user_id=42)
    assert r.ok is False
    assert "Usage" in r.reply


def test_set_bad_value(auth_env) -> None:
    r = commands.dispatch(text="/set MM_WARN_PCT abc 1h", user_id=42)
    assert r.ok is False
    assert "Invalid value" in r.reply


def test_set_bad_duration(auth_env) -> None:
    r = commands.dispatch(text="/set MM_WARN_PCT 25 fortnight", user_id=42)
    assert r.ok is False
    assert "Invalid duration" in r.reply


# ===========================================================================
# /stop + /resume
# ===========================================================================

def test_stop_no_match(auth_env) -> None:
    r = commands.dispatch(text="/stop MM:band=warning", user_id=42)
    assert r.ok is False
    assert "nothing to stop" in r.reply


def test_stop_explicit_dedup_key(auth_env) -> None:
    # Pre-seed an open alert so /stop has something to match.
    storage.insert_alert(
        ts_utc="2026-05-02T12:00:00Z", rule="MM_PRESSURE", severity="WARNING",
        dedup_key="MM:band=warning", cited_features=[], feature_values={},
    )
    r = commands.dispatch(text="/stop MM:band=warning", user_id=42)
    assert r.ok is True
    assert "now handling" in r.reply
    assert any(s["dedup_key"] == "MM:band=warning"
               for s in storage.active_suppressions())
    # Audit row appended.
    assert any(a["action"] == "stop"
               for a in storage.recent_audit(10))


def test_stop_by_rule_name(auth_env) -> None:
    storage.insert_alert(
        ts_utc="2026-05-02T12:00:00Z", rule="MM_PRESSURE", severity="WARNING",
        dedup_key="MM:band=warning", cited_features=[], feature_values={},
    )
    storage.insert_alert(
        ts_utc="2026-05-02T12:00:01Z", rule="MM_PRESSURE", severity="URGENT",
        dedup_key="MM:band=critical", cited_features=[], feature_values={},
    )
    r = commands.dispatch(text="/stop MM_PRESSURE", user_id=42)
    assert r.ok is True
    keys = {s["dedup_key"] for s in storage.active_suppressions()}
    assert keys == {"MM:band=warning", "MM:band=critical"}


def test_stop_already_suppressed(auth_env) -> None:
    storage.insert_alert(
        ts_utc="2026-05-02T12:00:00Z", rule="MM_PRESSURE", severity="WARNING",
        dedup_key="MM:band=warning", cited_features=[], feature_values={},
    )
    storage.insert_suppression(
        dedup_key="MM:band=warning",
        set_by_user_id=1, set_by_user_name="x",
    )
    r = commands.dispatch(text="/stop MM:band=warning", user_id=42)
    assert r.ok is False
    assert "already suppressed" in r.reply


def test_resume_clears_suppression(auth_env) -> None:
    storage.insert_suppression(
        dedup_key="MM:band=warning",
        set_by_user_id=1, set_by_user_name="x",
    )
    r = commands.dispatch(text="/resume MM:band=warning", user_id=42)
    assert r.ok is True
    assert storage.active_suppressions() == []
    assert any(a["action"] == "resume" for a in storage.recent_audit(10))


def test_resume_no_match(auth_env) -> None:
    r = commands.dispatch(text="/resume MM:band=warning", user_id=42)
    assert r.ok is False
    assert "No active suppressions" in r.reply


# ===========================================================================
# /status
# ===========================================================================

def test_status_empty(auth_env) -> None:
    r = commands.dispatch(text="/status", user_id=42)
    assert r.ok is True
    assert "no state yet" in r.reply
    assert "Active alerts:</b> none" in r.reply


def test_status_with_alerts_and_suppressions(auth_env) -> None:
    storage.insert_state(
        ts_utc="2026-05-02T12:00:00Z",
        calm_score="ACTIVE_MONITORING",
        active_alert_ids=[1],
        reasoning="ACTIVE_MONITORING - 1 URGENT.",
    )
    storage.insert_alert(
        ts_utc="2026-05-02T12:00:00Z", rule="MM_PRESSURE", severity="URGENT",
        dedup_key="MM:band=critical", cited_features=[], feature_values={},
    )
    storage.insert_suppression(
        dedup_key="MM:band=critical",
        set_by_user_id=42, set_by_user_name="andres",
    )
    r = commands.dispatch(text="/status", user_id=42)
    assert "ACTIVE_MONITORING" in r.reply
    # Status now uses the plain-English label, not the raw rule name.
    assert "Margin pressure (critical)" in r.reply
    assert "Being handled" in r.reply
    assert "andres" in r.reply


# ===========================================================================
# /thresholds
# ===========================================================================

def test_thresholds_lists_all(auth_env) -> None:
    r = commands.dispatch(text="/thresholds", user_id=42)
    assert r.ok is True
    for name in ("MM_WARN_PCT", "DELTA_WARN_BTC", "DTE_WARN_DAYS",
                 "HEARTBEAT_RELAX_S"):
        assert name in r.reply
    assert "Current thresholds" in r.reply


def test_thresholds_marks_overridden(auth_env) -> None:
    thresholds.set_override(
        name="MM_WARN_PCT", value=25.0, duration_s=3600,
        user_id=42, user_name="andres",
    )
    r = commands.dispatch(text="/thresholds", user_id=42)
    assert "← override" in r.reply
    assert "andres" in r.reply


# ===========================================================================
# /audit
# ===========================================================================

def test_audit_empty(auth_env) -> None:
    r = commands.dispatch(text="/audit", user_id=42)
    assert "audit log empty" in r.reply


def test_audit_lists_recent(auth_env) -> None:
    commands.dispatch(text="/set MM_WARN_PCT 25 1h", user_id=42)
    r = commands.dispatch(text="/audit", user_id=42)
    assert "MM_WARN_PCT" in r.reply
    assert "andres" in r.reply
    assert "set_threshold" in r.reply


def test_audit_n_limit(auth_env) -> None:
    for v in (10, 20, 30):
        commands.dispatch(text=f"/set MM_WARN_PCT {v} 1h", user_id=42)
    r = commands.dispatch(text="/audit 2", user_id=42)
    # 2 entries shown
    assert r.reply.count("set_threshold") == 2


def test_audit_bad_n(auth_env) -> None:
    r = commands.dispatch(text="/audit abc", user_id=42)
    assert r.ok is False
    assert "Usage" in r.reply


# ===========================================================================
# /report (Phase 10 placeholder) + /help
# ===========================================================================

def test_report_audits_request(auth_env, monkeypatch, tmp_path: Path) -> None:
    """/report builds a PDF (in DRY_RUN: writes to disk only) and audits."""
    from portfolio_analysis import config
    monkeypatch.setattr(config, "REPORT_DIR", tmp_path / "reports")
    (tmp_path / "reports").mkdir(parents=True, exist_ok=True)
    r = commands.dispatch(text="/report", user_id=42)
    assert r.ok is True
    # In DRY_RUN, the reply mentions the PDF path.
    assert ".pdf" in r.reply
    # And it audits the request.
    assert any(a["action"] == "report" for a in storage.recent_audit(10))


def test_help(auth_env) -> None:
    r = commands.dispatch(text="/help", user_id=42)
    assert "/set" in r.reply and "/stop" in r.reply and "/status" in r.reply


def test_start_returns_help(auth_env) -> None:
    r = commands.dispatch(text="/start", user_id=42)
    assert "/set" in r.reply
