"""Phase 3 tests - per-option position features."""
from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path

import pytest

from portfolio_analysis.features import positions
from portfolio_analysis.tests.conftest import seed_positions_tick


# ---------------------------------------------------------------------------
# parse_instrument_name
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("name,strike,year,month,day,typ", [
    ("BTC-30MAY26-100000-C", 100000.0, 2026, 5, 30, "C"),
    ("BTC-1JAN27-50000-P",   50000.0,  2027, 1, 1,  "P"),
    ("BTC-31DEC25-75000.5-C", 75000.5, 2025, 12, 31, "C"),
])
def test_parse_instrument_name_valid(name, strike, year, month, day, typ) -> None:
    parsed = positions.parse_instrument_name(name)
    assert parsed is not None
    assert parsed["strike"] == strike
    assert parsed["option_type"] == typ
    assert parsed["expiry_utc"].year == year
    assert parsed["expiry_utc"].month == month
    assert parsed["expiry_utc"].day == day


@pytest.mark.parametrize("bad", [
    "", "BTC-PERPETUAL", "BTC-30MAY26", "BTC-30MAY26-100000",
    "BTC-30XXX26-100000-C",  # bad month
    "BTC-30MAY26-100000-X",  # bad type
])
def test_parse_instrument_name_invalid(bad) -> None:
    assert positions.parse_instrument_name(bad) is None


# ---------------------------------------------------------------------------
# compute_position_features - round-trip through positions_ticks
# ---------------------------------------------------------------------------

def _otm_call_payload():
    """One short OTM call, one long ITM put - both options."""
    return [
        {
            "instrument_name": "BTC-30MAY26-110000-C",
            "direction": "sell",
            "size": -1.0,
            # No explicit strike/option_type/expiration_timestamp - must be parsed.
        },
        {
            "instrument_name": "BTC-30MAY26-95000-P",
            "direction": "buy",
            "size": 0.5,
            "strike": 95000.0,
            "option_type": "P",
            "expiration_timestamp": int(
                datetime(2026, 5, 30, 8, tzinfo=timezone.utc).timestamp() * 1000
            ),
        },
        {
            "instrument_name": "BTC-PERPETUAL",
            "direction": "buy",
            "size": 1000,
        },
    ]


def test_two_options_one_perp(isolated_realtime_db: Path) -> None:
    seed_positions_tick(isolated_realtime_db, "2026-05-02T12:00:00Z", _otm_call_payload())
    feats = positions.compute_position_features(
        spot=100000.0, now_utc="2026-05-02T12:00:00.000000Z",
    )
    # PERPETUAL is filtered out
    assert len(feats) == 2
    by_name = {f.instrument_name: f for f in feats}

    call = by_name["BTC-30MAY26-110000-C"]
    assert call.option_type == "C"
    assert call.strike == 110000.0
    assert call.side == "short"
    # +10% above spot
    assert call.distance_to_strike_pct == pytest.approx(10.0)
    # 28 days to expiry from 2026-05-02 12:00 → 2026-05-30 08:00
    assert 27.5 < call.dte_days < 28.5

    put = by_name["BTC-30MAY26-95000-P"]
    assert put.option_type == "P"
    assert put.strike == 95000.0
    assert put.side == "long"
    assert put.distance_to_strike_pct == pytest.approx(-5.0)


def test_explicit_fields_override_parsing(isolated_realtime_db: Path) -> None:
    """When the payload carries strike/expiry, use them instead of parsing."""
    payload = [{
        "instrument_name": "BTC-30MAY26-100000-C",
        "direction": "buy",
        "size": 1,
        "strike": 99999.0,         # different from instrument name on purpose
        "option_type": "C",
        "expiration_timestamp": int(
            datetime(2026, 6, 30, 8, tzinfo=timezone.utc).timestamp() * 1000
        ),
    }]
    seed_positions_tick(isolated_realtime_db, "2026-05-02T12:00:00Z", payload)
    feats = positions.compute_position_features(
        spot=100000.0, now_utc="2026-05-02T12:00:00.000000Z",
    )
    assert len(feats) == 1
    assert feats[0].strike == 99999.0
    assert feats[0].expiry_utc.month == 6


def test_short_side_via_negative_size(isolated_realtime_db: Path) -> None:
    payload = [{
        "instrument_name": "BTC-30MAY26-100000-C",
        "size": -1.0,                # no 'direction' field
    }]
    seed_positions_tick(isolated_realtime_db, "2026-05-02T12:00:00Z", payload)
    feats = positions.compute_position_features(
        spot=100000.0, now_utc="2026-05-02T12:00:00.000000Z",
    )
    assert len(feats) == 1
    assert feats[0].side == "short"


def test_empty_positions_table(isolated_realtime_db: Path) -> None:
    feats = positions.compute_position_features(spot=100000.0)
    assert feats == []


def test_invalid_spot_returns_empty(isolated_realtime_db: Path) -> None:
    seed_positions_tick(isolated_realtime_db, "2026-05-02T12:00:00Z", _otm_call_payload())
    assert positions.compute_position_features(spot=0.0) == []
    assert positions.compute_position_features(spot=-1.0) == []


def test_realtime_db_missing_returns_empty(tmp_path: Path, monkeypatch) -> None:
    import shared.db_paths as _dbp
    from portfolio_analysis.features import market as _market
    missing = tmp_path / "does-not-exist.sqlite"
    monkeypatch.setattr(_dbp, "REALTIME_DB", missing)
    monkeypatch.setattr(_market, "REALTIME_DB", missing)
    assert positions.compute_position_features(spot=100000.0) == []


# ---------------------------------------------------------------------------
# FeatureBundle integration
# ---------------------------------------------------------------------------

def test_feature_bundle_integration(isolated_realtime_db: Path, tmp_path: Path) -> None:
    """Compose all three feature modules into a FeatureBundle."""
    from portfolio_analysis import storage
    from portfolio_analysis.features import FeatureBundle, market, price_change

    storage.set_db_path_for_tests(tmp_path / "pa.sqlite")
    try:
        from portfolio_analysis.tests.conftest import seed_market_ticks
        seed_market_ticks(isolated_realtime_db, [
            ("2026-05-02T11:00:00.000000Z", 100.0),
            ("2026-05-02T12:00:00.000000Z", 110.0),
        ])
        seed_positions_tick(isolated_realtime_db, "2026-05-02T12:00:00Z", _otm_call_payload())

        ts = "2026-05-02T12:00:00.000000Z"
        bundle = FeatureBundle(
            ts_utc=ts,
            spot=110.0, delta=0.5, gamma=0.01, vega=12.3, mm_pct=28.0,
            market=market.compute(ts),
            price_change=price_change.compute(ts),
            positions=positions.compute_position_features(spot=110.0, now_utc=ts),
        )
        assert bundle.market.returns["1h"] == pytest.approx(10.0)
        assert len(bundle.positions) == 2  # PERPETUAL skipped
    finally:
        storage.set_db_path_for_tests(None)
