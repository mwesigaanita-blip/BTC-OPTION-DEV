"""Tests for ``returns_history`` write-time downsampling."""
from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path

import pytest

from portfolio_analysis import storage
from portfolio_analysis.features.downsample import (
    DOWNSAMPLE_MINUTES,
    downsampled_ts_for,
)


# ---------------------------------------------------------------------------
# Boundary alignment
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("ts_in,expected", [
    # 1h → round to nearest 5-minute boundary, UTC anchored.
    ("2026-05-05T12:00:00.000000Z", "2026-05-05T12:00:00.000000Z"),
    ("2026-05-05T12:04:59.999999Z", "2026-05-05T12:00:00.000000Z"),
    ("2026-05-05T12:05:00.000000Z", "2026-05-05T12:05:00.000000Z"),
    ("2026-05-05T12:09:42.123456Z", "2026-05-05T12:05:00.000000Z"),
    ("2026-05-05T12:55:30.000000Z", "2026-05-05T12:55:00.000000Z"),
    ("2026-05-05T12:59:59.999999Z", "2026-05-05T12:55:00.000000Z"),
])
def test_1h_downsample(ts_in, expected) -> None:
    assert downsampled_ts_for("1h", ts_in) == expected


@pytest.mark.parametrize("ts_in,expected", [
    # 4h → round to nearest 10-minute boundary.
    ("2026-05-05T12:00:00.000000Z", "2026-05-05T12:00:00.000000Z"),
    ("2026-05-05T12:09:59.999999Z", "2026-05-05T12:00:00.000000Z"),
    ("2026-05-05T12:10:00.000000Z", "2026-05-05T12:10:00.000000Z"),
    ("2026-05-05T12:15:00.000000Z", "2026-05-05T12:10:00.000000Z"),
    ("2026-05-05T12:55:00.000000Z", "2026-05-05T12:50:00.000000Z"),
])
def test_4h_downsample(ts_in, expected) -> None:
    assert downsampled_ts_for("4h", ts_in) == expected


def test_24h_skips_before_trigger(monkeypatch) -> None:
    """24h returns ``None`` when the tick is before today's trigger."""
    from portfolio_analysis import config
    monkeypatch.setattr(config, "REPORT_DAILY_UTC_HOUR", 0)
    monkeypatch.setattr(config, "REPORT_DAILY_UTC_MINUTE", 5)
    # Trigger is 2026-05-05 00:05 UTC. Anything before is skipped.
    assert downsampled_ts_for("24h", "2026-05-05T00:00:00.000000Z") is None
    assert downsampled_ts_for("24h", "2026-05-05T00:04:59.999999Z") is None


def test_24h_collapses_to_trigger_after(monkeypatch) -> None:
    """24h returns today's trigger ts for any tick on/after the trigger."""
    from portfolio_analysis import config
    monkeypatch.setattr(config, "REPORT_DAILY_UTC_HOUR", 0)
    monkeypatch.setattr(config, "REPORT_DAILY_UTC_MINUTE", 5)
    expected = "2026-05-05T00:05:00.000000Z"
    assert downsampled_ts_for("24h", "2026-05-05T00:05:00.000000Z") == expected
    assert downsampled_ts_for("24h", "2026-05-05T12:34:56.000000Z") == expected
    assert downsampled_ts_for("24h", "2026-05-05T23:59:59.999999Z") == expected


@pytest.mark.parametrize("tf", ["1d", "7d", "15d", "30d"])
def test_daily_horizons_skip_before_trigger(monkeypatch, tf) -> None:
    """1d/7d/15d/30d behave like 24h: skipped before today's daily trigger."""
    from portfolio_analysis import config
    monkeypatch.setattr(config, "REPORT_DAILY_UTC_HOUR", 0)
    monkeypatch.setattr(config, "REPORT_DAILY_UTC_MINUTE", 5)
    assert downsampled_ts_for(tf, "2026-05-05T00:00:00.000000Z") is None
    assert downsampled_ts_for(tf, "2026-05-05T00:04:59.999999Z") is None


@pytest.mark.parametrize("tf", ["1d", "7d", "15d", "30d"])
def test_daily_horizons_collapse_to_trigger_after(monkeypatch, tf) -> None:
    """1d/7d/15d/30d collapse to today's trigger ts after the trigger time."""
    from portfolio_analysis import config
    monkeypatch.setattr(config, "REPORT_DAILY_UTC_HOUR", 0)
    monkeypatch.setattr(config, "REPORT_DAILY_UTC_MINUTE", 5)
    expected = "2026-05-05T00:05:00.000000Z"
    assert downsampled_ts_for(tf, "2026-05-05T00:05:00.000000Z") == expected
    assert downsampled_ts_for(tf, "2026-05-05T12:34:56.000000Z") == expected
    assert downsampled_ts_for(tf, "2026-05-05T23:59:59.999999Z") == expected


# ---------------------------------------------------------------------------
# Integration: PK suppresses duplicate inserts at the same boundary
# ---------------------------------------------------------------------------

def test_repeated_inserts_at_same_bucket_collapse_to_one_row(tmp_path: Path) -> None:
    """Multiple ticks within the same 5-minute window write the same
    boundary ts → INSERT OR REPLACE → exactly one row."""
    storage.set_db_path_for_tests(tmp_path / "pa.sqlite")
    try:
        # Three ticks within the 12:00 → 12:05 bucket.
        for ts in (
            "2026-05-05T12:00:00.000000Z",
            "2026-05-05T12:00:47.000000Z",
            "2026-05-05T12:04:30.000000Z",
        ):
            ds = downsampled_ts_for("1h", ts)
            assert ds is not None
            storage.insert_return(ts_utc=ds, timeframe="1h", return_pct=0.5)
        rows = storage.returns_for("1h")
        assert len(rows) == 1
        # All three ticks rounded down to the same boundary.
        assert rows[0]["ts_utc"] == "2026-05-05T12:00:00.000000Z"
    finally:
        storage.set_db_path_for_tests(None)


def test_distinct_buckets_yield_distinct_rows(tmp_path: Path) -> None:
    storage.set_db_path_for_tests(tmp_path / "pa.sqlite")
    try:
        for ts in (
            "2026-05-05T12:00:00.000000Z",
            "2026-05-05T12:05:30.000000Z",
            "2026-05-05T12:10:00.000000Z",
        ):
            ds = downsampled_ts_for("1h", ts)
            storage.insert_return(ts_utc=ds, timeframe="1h", return_pct=0.5)
        rows = storage.returns_for("1h")
        assert [r["ts_utc"] for r in rows] == [
            "2026-05-05T12:00:00.000000Z",
            "2026-05-05T12:05:00.000000Z",
            "2026-05-05T12:10:00.000000Z",
        ]
    finally:
        storage.set_db_path_for_tests(None)


def test_downsample_minutes_table() -> None:
    """Sanity: the published mapping matches the spec."""
    assert DOWNSAMPLE_MINUTES["1h"] == 5
    assert DOWNSAMPLE_MINUTES["4h"] == 10
