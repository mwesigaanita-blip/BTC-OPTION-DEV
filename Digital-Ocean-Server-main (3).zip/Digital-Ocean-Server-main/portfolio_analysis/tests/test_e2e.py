"""Phase 13 - end-to-end integration test (DRY_RUN, in-process).

We don't spin a real bot subprocess (it would long-poll the Telegram API);
instead we run the full scheduler in-process and simulate user commands by
calling ``commands.dispatch`` directly. That covers exactly the same code
paths a real Telegram message would take, but is hermetic - no network,
no shared state with the production DB, no real PDF emails.

Flow exercised (matches plan.md §10 Phase 13):
  1. Scheduler running with all 3 workers + DRY_RUN=1.
  2. Seed agg row that triggers MM_PRESSURE warning.
  3. After one cycle → alert in `alerts`, DRY_RUN notify line logged,
     state_history row written.
  4. ``/stop MM:band=warning`` → suppression row + audit row + broadcast
     logged.
  5. Seed same agg row again → second alert NOT inserted (suppression
     blocks new fire).
  6. Seed normal mm_pct → alert auto-resolves, suppression auto-clears.
  7. Seed warning agg row again → brand new alert fires (key was reset).
  8. ``/report`` → PDF appears in REPORT_DIR, audit row appended.
"""
from __future__ import annotations

import json
import sqlite3
import time
from pathlib import Path

import pytest

from portfolio_analysis import notifier, scheduler, storage, thresholds
from portfolio_analysis.bot import commands as bot_commands


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def isolated_env(tmp_path: Path, monkeypatch):
    """Pin every external dependency to a tmp location; stay in DRY_RUN."""
    # Portfolio DB.
    storage.set_db_path_for_tests(tmp_path / "pa.sqlite")
    thresholds.invalidate_cache()
    notifier.reset_default_notifier()

    # Hedge-engine DB (synthetic, only the agg-metrics table).
    he_path = tmp_path / "hedge_engine.sqlite"
    c = sqlite3.connect(str(he_path))
    c.executescript("""
        CREATE TABLE hedge_engine_aggregated_metrics (
            ts_utc TEXT PRIMARY KEY,
            delta REAL, gamma REAL, vega REAL,
            mm_pct REAL, btc_price REAL, btc_roc REAL,
            sample_n INTEGER, created_at TEXT
        );
    """)
    c.commit(); c.close()
    import shared.db_paths as _dbp
    from portfolio_analysis import worker as _worker
    monkeypatch.setattr(_dbp, "HEDGE_ENGINE_DB", he_path)
    monkeypatch.setattr(_worker, "HEDGE_ENGINE_DB", he_path)

    # Report dir → temp.
    from portfolio_analysis import config as _config
    monkeypatch.setattr(_config, "REPORT_DIR", tmp_path / "reports")
    (tmp_path / "reports").mkdir(parents=True, exist_ok=True)

    # Env vars.
    monkeypatch.setenv("DRY_RUN", "1")
    monkeypatch.setenv("TELEGRAM_PORTFOLIO_BOT_TOKEN", "fake")
    monkeypatch.setenv("TELEGRAM_CHAT_IDS", json.dumps({"remo": "111"}))
    monkeypatch.setenv("AUTHORIZED_TELEGRAM_USERS", json.dumps({"andres": "42"}))

    yield {"he_path": he_path, "tmp_path": tmp_path}

    thresholds.invalidate_cache()
    notifier.reset_default_notifier()
    storage.set_db_path_for_tests(None)


def _seed_agg(he_path: Path, *, ts: str, mm_pct: float,
              delta: float = 0.0, btc_price: float = 100000.0) -> None:
    c = sqlite3.connect(str(he_path))
    c.execute(
        "INSERT OR REPLACE INTO hedge_engine_aggregated_metrics "
        "(ts_utc, delta, gamma, vega, mm_pct, btc_price, btc_roc, sample_n, created_at) "
        "VALUES (?, ?, 0, 0, ?, ?, 0, 1, ?)",
        (ts, delta, mm_pct, btc_price, ts),
    )
    c.commit(); c.close()


def _wait_until(predicate, *, timeout_s: float = 3.0, step_s: float = 0.05) -> bool:
    """Poll ``predicate()`` every ``step_s`` until True or timeout."""
    deadline = time.monotonic() + timeout_s
    while time.monotonic() < deadline:
        if predicate():
            return True
        time.sleep(step_s)
    return False


# ---------------------------------------------------------------------------
# The full flow
# ---------------------------------------------------------------------------

def test_e2e_full_flow(isolated_env, caplog) -> None:
    he_path = isolated_env["he_path"]
    tmp_path = isolated_env["tmp_path"]

    # --- 1. Start scheduler with accelerated intervals -------------------
    s = scheduler.PortfolioScheduler(
        alert_interval_s=0.1,
        heartbeat_interval_s=0.5,
        report_interval_s=10,    # daily worker won't actually fire in this test
    )
    s.start()
    try:
        with caplog.at_level("INFO", logger="portfolio_analysis"):
            # --- 2. Seed an MM warning row ------------------------------
            _seed_agg(he_path, ts="2026-05-02T12:00:00.000000Z", mm_pct=42.0)

            # --- 3. Wait for the cycle, expect 1 inserted alert ---------
            assert _wait_until(
                lambda: len(storage.unresolved_alerts()) == 1,
                timeout_s=3.0,
            ), "AlertWorker did not insert MM warning"
            row = storage.unresolved_alerts()[0]
            assert row["dedup_key"] == "MM:band=warning"
            assert row["severity"] == "WARNING"

            # State history populated.
            last = storage.latest_state()
            assert last is not None
            assert last["calm_score"] in ("TAKE_A_LOOK", "ACTIVE_MONITORING")

            # DRY_RUN notify line written for the inserted alert.
            assert _wait_until(
                lambda: any(
                    "DRY_RUN notify_alert" in r.message
                    and "MM:band=warning" in r.message
                    for r in caplog.records
                ),
                timeout_s=2.0,
            ), "no DRY_RUN notify_alert log line for the MM warning"

            # --- 4. /stop suppresses it ---------------------------------
            r = bot_commands.dispatch(text="/stop MM:band=warning", user_id=42)
            assert r is not None and r.ok is True
            assert any(
                s["dedup_key"] == "MM:band=warning"
                for s in storage.active_suppressions()
            )
            # Audit row appended for the stop.
            assert any(a["action"] == "stop" for a in storage.recent_audit(20))
            # Broadcast was logged (DRY_RUN).
            assert any(
                "DRY_RUN broadcast" in r.message and "is now handling" in r.message
                for r in caplog.records
            )

            # --- 5. Re-seeding with same severity → no duplicate insert -
            inserted_ids_before = {r["id"] for r in storage.unresolved_alerts()}
            _seed_agg(he_path, ts="2026-05-02T12:00:30.000000Z", mm_pct=43.0)
            time.sleep(0.4)  # let several worker cycles run
            inserted_ids_after = {r["id"] for r in storage.unresolved_alerts()}
            assert inserted_ids_before == inserted_ids_after, \
                "suppression failed to block the second fire"

            # --- 6. mm_pct returns to normal → alert resolves, suppr clears
            _seed_agg(he_path, ts="2026-05-02T12:01:00.000000Z", mm_pct=10.0)
            assert _wait_until(
                lambda: storage.unresolved_alerts() == [],
                timeout_s=3.0,
            ), "alert did not auto-resolve when condition cleared"
            assert _wait_until(
                lambda: storage.active_suppressions() == [],
                timeout_s=3.0,
            ), "suppression did not auto-clear when alert resolved"

            # --- 7. mm_pct above threshold again → fresh alert fires ----
            _seed_agg(he_path, ts="2026-05-02T12:02:00.000000Z", mm_pct=42.0)
            assert _wait_until(
                lambda: any(
                    a["dedup_key"] == "MM:band=warning"
                    for a in storage.unresolved_alerts()
                ),
                timeout_s=3.0,
            ), "alert did not re-fire after suppression cleared"

            # --- 8. /report builds a PDF in REPORT_DIR ------------------
            r = bot_commands.dispatch(text="/report", user_id=42)
            assert r is not None and r.ok is True
            assert ".pdf" in r.reply
            pdf_files = list((tmp_path / "reports").glob("*.pdf"))
            assert pdf_files, "no PDF was generated by /report"
            assert any(p.stat().st_size > 0 for p in pdf_files)
            assert any(
                a["action"] == "report" for a in storage.recent_audit(20)
            ), "/report did not append an audit row"
    finally:
        s.stop(timeout_s=2.0)


# ---------------------------------------------------------------------------
# Unauthorized commands are rejected even with the scheduler running
# ---------------------------------------------------------------------------

def test_e2e_unauthorized_command_rejected(isolated_env) -> None:
    s = scheduler.PortfolioScheduler(
        alert_interval_s=0.1, heartbeat_interval_s=0.5, report_interval_s=10,
    )
    s.start()
    try:
        r = bot_commands.dispatch(text="/status", user_id=999)
        assert r is not None
        assert r.ok is False
        assert "Not authorized" in r.reply
        # Crucially: no audit row for the rejected command.
        assert all(a["user_id"] != 999 for a in storage.recent_audit(50))
    finally:
        s.stop(timeout_s=2.0)
