"""Phase 9 tests - HeartbeatWorker."""
from __future__ import annotations

import json
import threading
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path

import pytest

from portfolio_analysis import heartbeat, notifier, storage, thresholds


# ---------------------------------------------------------------------------
# Fixtures - isolated DB + DRY_RUN, mockable clock
# ---------------------------------------------------------------------------

@pytest.fixture(autouse=True)
def _isolated(tmp_path: Path, monkeypatch):
    storage.set_db_path_for_tests(tmp_path / "pa.sqlite")
    thresholds.invalidate_cache()
    notifier.reset_default_notifier()
    monkeypatch.setenv("DRY_RUN", "1")
    monkeypatch.setenv("TELEGRAM_PORTFOLIO_BOT_TOKEN", "fake")
    monkeypatch.setenv("TELEGRAM_CHAT_IDS", json.dumps({"remo": "111"}))
    yield
    thresholds.invalidate_cache()
    notifier.reset_default_notifier()
    storage.set_db_path_for_tests(None)


@pytest.fixture
def mock_clock(monkeypatch):
    """Patch ``heartbeat._now_iso`` so we can fast-forward time."""
    state = {"now": datetime(2026, 5, 2, 12, 0, 0, tzinfo=timezone.utc)}

    def now_iso() -> str:
        return state["now"].strftime("%Y-%m-%dT%H:%M:%S.%f") + "Z"

    def advance(seconds: float) -> None:
        state["now"] = state["now"] + timedelta(seconds=seconds)

    monkeypatch.setattr(heartbeat, "_now_iso", now_iso)
    return advance


def _seed_state(*, calm_score: str = "RELAX", ts: str = "2026-05-02T11:59:00Z",
                reasoning: str = "RELAX - no active alerts.") -> None:
    storage.insert_state(
        ts_utc=ts,
        calm_score=calm_score,
        active_alert_ids=[],
        reasoning=reasoning,
    )


# ===========================================================================
# tick_once - basic gating
# ===========================================================================

def test_tick_once_no_state_returns_none() -> None:
    assert heartbeat.tick_once() is None


def test_tick_once_first_send_when_last_notified_null(mock_clock) -> None:
    """If state_history has rows but no last_notified_utc → fire immediately."""
    _seed_state(calm_score="RELAX")
    s = heartbeat.tick_once()
    assert s is not None
    assert s["calm_score"] == "RELAX"
    # And the latest row got stamped.
    last = storage.latest_state()
    assert last["last_notified_utc"] is not None


def test_tick_once_skips_when_within_cadence(mock_clock) -> None:
    """RELAX cadence is 6h; second tick after 1h must NOT fire."""
    _seed_state(calm_score="RELAX")
    heartbeat.tick_once()       # fires
    mock_clock(3600)             # +1h
    assert heartbeat.tick_once() is None


def test_tick_once_fires_after_full_cadence(mock_clock) -> None:
    _seed_state(calm_score="RELAX")
    heartbeat.tick_once()       # fires at t0
    mock_clock(6 * 3600 + 1)     # +6h+1s → cadence elapsed
    s = heartbeat.tick_once()
    assert s is not None


# ===========================================================================
# Per-state cadence
# ===========================================================================

@pytest.mark.parametrize("state,cadence_s", [
    ("RELAX",             6 * 3600),
    ("TAKE_A_LOOK",       2 * 3600),
    ("ACTIVE_MONITORING", 30 * 60),
    ("URGENT_ACTION",     60),
])
def test_cadence_per_state(mock_clock, state, cadence_s) -> None:
    _seed_state(calm_score=state)
    s1 = heartbeat.tick_once()
    assert s1 is not None
    assert s1["cadence_s"] == cadence_s

    # Just under cadence → no fire.
    mock_clock(cadence_s - 1)
    assert heartbeat.tick_once() is None

    # Tip over cadence → fires.
    mock_clock(2)
    assert heartbeat.tick_once() is not None


def test_urgent_action_fires_every_minute(mock_clock) -> None:
    _seed_state(calm_score="URGENT_ACTION")
    heartbeat.tick_once()       # t=0 fires
    for _ in range(3):
        mock_clock(60)
        s = heartbeat.tick_once()
        assert s is not None    # every minute fires


# ===========================================================================
# Threshold override
# ===========================================================================

def test_cadence_respects_threshold_override(mock_clock) -> None:
    """Override HEARTBEAT_RELAX_S → 60 → second fire after 60s, not 6h."""
    _seed_state(calm_score="RELAX")
    heartbeat.tick_once()       # t=0 fires
    thresholds.set_override(
        name="HEARTBEAT_RELAX_S", value=60, duration_s=3600,
        user_id=42, user_name="andres",
    )
    thresholds.invalidate_cache()
    mock_clock(61)
    s = heartbeat.tick_once()
    assert s is not None
    assert s["cadence_s"] == 60


# ===========================================================================
# Digest format - snapshot
# ===========================================================================

def test_format_heartbeat_with_alerts_and_suppressions() -> None:
    storage.insert_alert(
        ts_utc="2026-05-02T12:00:00Z", rule="MM_PRESSURE", severity="WARNING",
        dedup_key="MM:band=warning", cited_features=[], feature_values={},
    )
    storage.insert_suppression(
        dedup_key="DELTA:sign=+:band=warning",
        set_by_user_id=42, set_by_user_name="andres",
    )
    text = heartbeat.format_heartbeat(
        calm_score="ACTIVE_MONITORING",
        reasoning="ACTIVE_MONITORING - 1 URGENT, 2 WARNING.",
        active_alerts=storage.unresolved_alerts(),
        suppressions=storage.active_suppressions(),
        ts_utc="2026-05-02T14:00:00Z",
    )
    # Active MM warning, plus a "pre-suppressed" DELTA whose underlying
    # alert isn't currently firing.
    assert text == (
        "<b>🔔 Heartbeat - 🟧 ACTIVE MONITORING</b>\n"
        "\n<b>Active alerts (1):</b>\n"
        "  ⚠️ Margin pressure (warning)\n"
        "\n<b>Pre-suppressed (1):</b>\n"
        "  • Long delta drift (warning) <i>(by andres)</i>\n"
        "\n<i>2026-05-02 14:00 UTC</i>"
    )


def test_format_heartbeat_relax_no_alerts() -> None:
    text = heartbeat.format_heartbeat(
        calm_score="RELAX",
        reasoning="RELAX - no active alerts.",
        active_alerts=[],
        suppressions=[],
        ts_utc="2026-05-02T18:00:00Z",
    )
    assert text == (
        "<b>🔔 Heartbeat - 💚 RELAX</b>\n"
        "\n<b>Active alerts:</b> none ✅\n"
        "\n<i>2026-05-02 18:00 UTC</i>"
    )


# ===========================================================================
# DB persistence - last_notified_utc gets stamped
# ===========================================================================

def test_tick_persists_last_notified_utc(mock_clock) -> None:
    _seed_state(calm_score="RELAX")
    heartbeat.tick_once()
    last = storage.latest_state()
    assert last["last_notified_utc"] is not None
    assert last["last_notified_utc"].endswith("Z")


def test_state_change_does_not_reset_last_notified(mock_clock) -> None:
    """Adding a NEW state_history row (e.g. state changed) must not lose
    the heartbeat clock - _last_sent_iso scans across all rows."""
    _seed_state(calm_score="RELAX", ts="2026-05-02T11:00:00Z")
    heartbeat.tick_once()       # stamps the RELAX row
    # Worker writes a fresh state row (e.g., state still RELAX, new tick).
    _seed_state(calm_score="RELAX", ts="2026-05-02T11:30:00Z")
    mock_clock(3600)             # +1h since last heartbeat
    assert heartbeat.tick_once() is None  # still within RELAX cadence
    mock_clock(6 * 3600)         # +7h total
    assert heartbeat.tick_once() is not None


# ===========================================================================
# Daemon thread lifecycle
# ===========================================================================

def test_heartbeat_worker_starts_and_stops(mock_clock) -> None:
    _seed_state(calm_score="URGENT_ACTION")
    stop = threading.Event()
    w = heartbeat.HeartbeatWorker(interval_s=0.05, stop_event=stop)
    w.start()
    time.sleep(0.2)
    w.stop(timeout=2.0)
    assert not w._thread.is_alive()
    last = storage.latest_state()
    assert last["last_notified_utc"] is not None


def test_heartbeat_worker_survives_tick_exceptions(monkeypatch, mock_clock) -> None:
    _seed_state(calm_score="RELAX")
    calls = {"n": 0}
    real = heartbeat.tick_once

    def maybe_explode():
        calls["n"] += 1
        if calls["n"] == 1:
            raise RuntimeError("boom")
        return real()

    monkeypatch.setattr(heartbeat, "tick_once", maybe_explode)
    stop = threading.Event()
    w = heartbeat.HeartbeatWorker(interval_s=0.05, stop_event=stop)
    w.start()
    time.sleep(0.3)
    w.stop(timeout=2.0)
    assert calls["n"] >= 2


def test_heartbeat_worker_double_start_is_noop() -> None:
    w = heartbeat.HeartbeatWorker(interval_s=10)
    w.start()
    first = w._thread
    w.start()
    assert w._thread is first
    w.stop(timeout=1.0)
