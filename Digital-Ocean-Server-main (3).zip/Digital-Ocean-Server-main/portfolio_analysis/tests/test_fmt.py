"""Tests for the user-facing display helpers."""
from __future__ import annotations

import pytest

from portfolio_analysis._fmt import (
    example_for_default,
    format_seconds_human,
    format_threshold_value,
    format_utc_human,
    is_duration_threshold,
)


# ---------------------------------------------------------------------------
# format_utc_human
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("inp,out", [
    ("2026-05-05T11:33:02.741574Z",  "2026-05-05 11:33 UTC"),
    ("2026-05-05T11:33:02Z",         "2026-05-05 11:33 UTC"),
    ("2026-05-05T11:33:02.741574",   "2026-05-05 11:33 UTC"),
    ("2026-05-05 11:33:02 UTC",      "2026-05-05 11:33 UTC"),
    ("",  "-"),
    (None, "-"),
])
def test_format_utc_human(inp, out) -> None:
    assert format_utc_human(inp) == out


def test_format_utc_human_unparseable() -> None:
    # Anything without 'T' or space → the helper returns "-" rather than raising.
    assert format_utc_human("nonsense") == "-"


# ---------------------------------------------------------------------------
# format_seconds_human
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("inp,out", [
    (0,         "0s"),
    (45,        "45s"),
    (60,        "1m"),
    (90,        "1m 30s"),
    (1800,      "30m"),
    (3600,      "1h"),
    (7200,      "2h"),
    (21600,     "6h"),
    (86400,     "1d"),
    (90000,     "1d 1h"),
    (172860,    "2d 1m"),
    (-3600,     "-1h"),
    (None,      "-"),
])
def test_format_seconds_human(inp, out) -> None:
    assert format_seconds_human(inp) == out


# ---------------------------------------------------------------------------
# is_duration_threshold + format_threshold_value
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("name,expected", [
    ("HEARTBEAT_RELAX_S",             True),
    ("HEARTBEAT_TAKE_A_LOOK_S",       True),
    ("HEARTBEAT_ACTIVE_MONITORING_S", True),
    ("HEARTBEAT_URGENT_ACTION_S",     True),
    ("MM_WARN_PCT",                   False),
    ("DELTA_GOOD_BTC",                False),
    ("DTE_WARN_DAYS",                 False),
    ("",                              False),
])
def test_is_duration_threshold(name, expected) -> None:
    assert is_duration_threshold(name) is expected


def test_format_threshold_value_duration() -> None:
    assert format_threshold_value("HEARTBEAT_RELAX_S",       21600) == "6h"
    assert format_threshold_value("HEARTBEAT_TAKE_A_LOOK_S", 7200)  == "2h"
    assert format_threshold_value("HEARTBEAT_URGENT_ACTION_S", 60)  == "1m"


def test_format_threshold_value_numeric() -> None:
    assert format_threshold_value("MM_WARN_PCT",     30.0)  == "30"
    assert format_threshold_value("DELTA_GOOD_BTC",  0.5)   == "0.5"
    assert format_threshold_value("DTE_WARN_DAYS",   30)    == "30"


def test_format_threshold_value_none() -> None:
    assert format_threshold_value("MM_WARN_PCT", None) == "-"


# ---------------------------------------------------------------------------
# example_for_default
# ---------------------------------------------------------------------------

def test_example_for_default_small_float_matches_magnitude() -> None:
    """For a default of 0.5, the example must look like a small number,
    not '25'."""
    ex = example_for_default("DELTA_GOOD_BTC", 0.5)
    val = float(ex)
    assert 0.1 < val < 5.0, f"example {ex!r} is out of magnitude for default 0.5"


def test_example_for_default_percentage() -> None:
    ex = example_for_default("MM_WARN_PCT", 30.0)
    val = float(ex)
    # Should be roughly the same order of magnitude.
    assert 5 < val < 200


def test_example_for_default_integer_days() -> None:
    ex = example_for_default("DTE_WARN_DAYS", 30)
    val = float(ex)
    assert 1 < val < 200


def test_example_for_default_heartbeat_returns_duration_string() -> None:
    """Heartbeat thresholds → example is a duration like '3h', not '10800'."""
    for name, default, expected_unit in [
        ("HEARTBEAT_RELAX_S",             21600, "h"),  # 6h default
        ("HEARTBEAT_TAKE_A_LOOK_S",       7200,  "h"),  # 2h default
        ("HEARTBEAT_ACTIVE_MONITORING_S", 1800,  "m"),  # 30m default
        ("HEARTBEAT_URGENT_ACTION_S",     60,    "s"),  # 1m default → "30s" example
    ]:
        ex = example_for_default(name, default)
        assert ex.endswith(expected_unit), (
            f"{name} default={default}: expected example ending in "
            f"{expected_unit!r}, got {ex!r}"
        )
        # Must NOT be a raw integer / float
        with pytest.raises(ValueError):
            float(ex)
