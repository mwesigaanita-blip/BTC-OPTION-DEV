"""Shared test fixtures for the portfolio_analysis tests.

Both fixtures patch the path constant in every module that captured it
by name at import time (``shared.db_paths`` plus the feature modules
plus ``btc_returns``).
"""
from __future__ import annotations

import json
import sqlite3
from pathlib import Path
from typing import Any, Iterable

import pytest


_REALTIME_SCHEMA = """
CREATE TABLE IF NOT EXISTS market_ticks (
    ts_utc    TEXT PRIMARY KEY,
    btc_price REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS positions_ticks (
    ts_utc       TEXT PRIMARY KEY,
    payload_json TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS account_ticks (
    ts_utc       TEXT PRIMARY KEY,
    payload_json TEXT NOT NULL
);
"""

_MARKET_DATA_SCHEMA = """
CREATE TABLE IF NOT EXISTS btc_prices (
    date           TEXT PRIMARY KEY,
    open           REAL,
    high           REAL,
    low            REAL,
    close          REAL,
    change         REAL,
    percent_change REAL,
    volume         REAL
);
"""


@pytest.fixture
def isolated_realtime_db(tmp_path: Path, monkeypatch):
    """Point every reference of REALTIME_DB at a fresh temp DB."""
    rt_path = tmp_path / "realtime.sqlite"
    conn = sqlite3.connect(str(rt_path))
    conn.executescript(_REALTIME_SCHEMA)
    conn.close()

    import shared.db_paths as _dbp
    monkeypatch.setattr(_dbp, "REALTIME_DB", rt_path, raising=True)

    from portfolio_analysis.features import btc_returns as _btc_returns
    from portfolio_analysis.features import market as _market
    monkeypatch.setattr(_btc_returns, "REALTIME_DB", rt_path, raising=True)
    monkeypatch.setattr(_market, "REALTIME_DB", rt_path, raising=True)

    return rt_path


@pytest.fixture
def isolated_market_data_db(tmp_path: Path, monkeypatch):
    """Point every reference of MARKET_DATA_DB at a fresh temp DB."""
    md_path = tmp_path / "market_data.sqlite"
    conn = sqlite3.connect(str(md_path))
    conn.executescript(_MARKET_DATA_SCHEMA)
    conn.close()

    import shared.db_paths as _dbp
    monkeypatch.setattr(_dbp, "MARKET_DATA_DB", md_path, raising=True)

    from portfolio_analysis.features import btc_returns as _btc_returns
    monkeypatch.setattr(_btc_returns, "MARKET_DATA_DB", md_path, raising=True)

    return md_path


def seed_market_ticks(db_path: Path, rows: Iterable[tuple[str, float]]) -> None:
    conn = sqlite3.connect(str(db_path))
    conn.executemany(
        "INSERT OR REPLACE INTO market_ticks (ts_utc, btc_price) VALUES (?, ?)",
        list(rows),
    )
    conn.commit()
    conn.close()


def seed_btc_prices(db_path: Path, rows: Iterable[tuple[str, float]]) -> None:
    """``rows`` is an iterable of ``(date YYYY-MM-DD, close)`` pairs."""
    conn = sqlite3.connect(str(db_path))
    conn.executemany(
        "INSERT OR REPLACE INTO btc_prices "
        "(date, open, high, low, close, change, percent_change, volume) "
        "VALUES (?, ?, ?, ?, ?, 0, 0, 0)",
        [(d, c, c, c, c) for d, c in rows],
    )
    conn.commit()
    conn.close()


def seed_positions_tick(db_path: Path, ts_utc: str, payload: Any) -> None:
    conn = sqlite3.connect(str(db_path))
    conn.execute(
        "INSERT OR REPLACE INTO positions_ticks (ts_utc, payload_json) VALUES (?, ?)",
        (ts_utc, json.dumps(payload)),
    )
    conn.commit()
    conn.close()
