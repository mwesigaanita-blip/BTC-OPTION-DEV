"""Phase 5 tests - Calm Score classifier."""
from __future__ import annotations

from dataclasses import dataclass

import pytest

from portfolio_analysis.state import (
    CalmState,
    WARNING_COUNT_FOR_ACTIVE_MONITORING,
    classify,
)


@dataclass(frozen=True)
class _A:
    """Minimal AlertLike stand-in for the classifier."""
    rule: str
    severity: str
    dedup_key: str


# ===========================================================================
# Tier triggers
# ===========================================================================

def test_relax_when_empty() -> None:
    state, text = classify([])
    assert state is CalmState.RELAX
    assert text == "RELAX - no active alerts."


@pytest.mark.parametrize("alerts", [
    [_A("MM_PRESSURE", "INFO", "MM:band=attention")],
    [_A("DELTA_DRIFT", "WARNING", "DELTA:sign=+:band=warning")],
    [
        _A("MM_PRESSURE", "INFO", "MM:band=attention"),
        _A("DELTA_DRIFT", "WARNING", "DELTA:sign=+:band=warning"),
    ],
    [_A("DTE_RISK", "WARNING", "DTE:X:band=warning")] * 2,  # 2 warnings - still TAL
])
def test_take_a_look_for_info_or_few_warnings(alerts) -> None:
    state, _ = classify(alerts)
    assert state is CalmState.TAKE_A_LOOK


def test_active_monitoring_for_one_urgent() -> None:
    state, _ = classify([_A("MM_PRESSURE", "URGENT", "MM:band=critical")])
    assert state is CalmState.ACTIVE_MONITORING


def test_active_monitoring_at_warning_threshold() -> None:
    """Exactly the threshold count of WARNINGs promotes to ACTIVE_MONITORING."""
    alerts = [
        _A("R", "WARNING", f"K:{i}")
        for i in range(WARNING_COUNT_FOR_ACTIVE_MONITORING)
    ]
    state, _ = classify(alerts)
    assert state is CalmState.ACTIVE_MONITORING


def test_active_monitoring_when_warning_plus_urgent() -> None:
    state, _ = classify([
        _A("DELTA_DRIFT", "WARNING", "DELTA:sign=+:band=warning"),
        _A("MM_PRESSURE", "URGENT", "MM:band=critical"),
    ])
    assert state is CalmState.ACTIVE_MONITORING


def test_urgent_action_for_emergency() -> None:
    state, _ = classify([_A("FAKE", "EMERGENCY", "EM:1")])
    assert state is CalmState.URGENT_ACTION


def test_urgent_action_wins_over_lower_tiers() -> None:
    """Even with many WARNINGs and URGENTs, EMERGENCY → URGENT_ACTION."""
    state, _ = classify([
        _A("R", "WARNING", "k1"),
        _A("R", "WARNING", "k2"),
        _A("R", "URGENT", "k3"),
        _A("R", "EMERGENCY", "k4"),
    ])
    assert state is CalmState.URGENT_ACTION


# ===========================================================================
# Reasoning text - deterministic format
# ===========================================================================

def test_reasoning_relax_snapshot() -> None:
    _, text = classify([])
    assert text == "RELAX - no active alerts."


def test_reasoning_take_a_look_snapshot() -> None:
    _, text = classify([
        _A("MM_PRESSURE", "INFO", "MM:band=attention"),
        _A("DELTA_DRIFT", "WARNING", "DELTA:sign=+:band=warning"),
    ])
    assert text == (
        "TAKE_A_LOOK - 1 WARNING, 1 INFO active: "
        "DELTA_DRIFT [DELTA:sign=+:band=warning]; "
        "MM_PRESSURE [MM:band=attention]."
    )


def test_reasoning_active_monitoring_snapshot() -> None:
    _, text = classify([
        _A("MM_PRESSURE", "URGENT", "MM:band=critical"),
        _A("DELTA_DRIFT", "WARNING", "DELTA:sign=+:band=warning"),
        _A("VOL_SIGMA", "WARNING", "VOL:1h:dir=+:band=warning"),
    ])
    assert text == (
        "ACTIVE_MONITORING - 1 URGENT, 2 WARNING active: "
        "MM_PRESSURE [MM:band=critical]; "
        "DELTA_DRIFT [DELTA:sign=+:band=warning]; "
        "VOL_SIGMA [VOL:1h:dir=+:band=warning]."
    )


def test_reasoning_urgent_action_snapshot() -> None:
    _, text = classify([
        _A("MM_PRESSURE", "URGENT", "MM:band=critical"),
        _A("FAKE", "EMERGENCY", "EM:1"),
    ])
    assert text == (
        "URGENT_ACTION - 1 EMERGENCY, 1 URGENT active: "
        "FAKE [EM:1]; MM_PRESSURE [MM:band=critical]."
    )


def test_reasoning_is_deterministic_regardless_of_input_order() -> None:
    a = _A("MM_PRESSURE", "URGENT", "MM:band=critical")
    b = _A("DELTA_DRIFT", "WARNING", "DELTA:sign=+:band=warning")
    c = _A("VOL_SIGMA", "WARNING", "VOL:1h:dir=+:band=warning")
    state1, text1 = classify([a, b, c])
    state2, text2 = classify([c, a, b])
    state3, text3 = classify([b, c, a])
    assert state1 is state2 is state3
    assert text1 == text2 == text3


def test_reasoning_lists_every_rule_and_dedup_key() -> None:
    """Sanity: the reasoning string mentions every alert."""
    alerts = [
        _A("MM_PRESSURE", "URGENT", "MM:band=critical"),
        _A("DELTA_DRIFT", "WARNING", "DELTA:sign=+:band=warning"),
        _A("DTE_RISK", "URGENT", "DTE:BTC-30MAY26-100000-C:band=critical"),
    ]
    _, text = classify(alerts)
    for a in alerts:
        assert a.rule in text
        assert a.dedup_key in text


# ===========================================================================
# Edge cases
# ===========================================================================

def test_unknown_severity_does_not_crash() -> None:
    """A future / unknown severity tier should fall back to TAKE_A_LOOK
    rather than raise (we never want the worker to crash on bad data)."""
    state, _ = classify([_A("WEIRD", "MAYBE", "k")])
    assert state is CalmState.TAKE_A_LOOK


def test_calm_state_is_string_enum() -> None:
    """CalmState values must serialize to the documented strings."""
    assert CalmState.RELAX.value == "RELAX"
    assert CalmState.TAKE_A_LOOK.value == "TAKE_A_LOOK"
    assert CalmState.ACTIVE_MONITORING.value == "ACTIVE_MONITORING"
    assert CalmState.URGENT_ACTION.value == "URGENT_ACTION"
