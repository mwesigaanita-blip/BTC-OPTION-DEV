"""Phase 10 tests - daily PDF report."""
from __future__ import annotations

import json
import threading
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path

import pytest

from portfolio_analysis import notifier, report_daily, storage, thresholds


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture(autouse=True)
def _isolated(tmp_path: Path, monkeypatch):
    storage.set_db_path_for_tests(tmp_path / "pa.sqlite")
    thresholds.invalidate_cache()
    notifier.reset_default_notifier()
    # Redirect REPORT_DIR so PDFs don't pollute the real data dir.
    from portfolio_analysis import config
    monkeypatch.setattr(config, "REPORT_DIR", tmp_path / "reports")
    (tmp_path / "reports").mkdir(parents=True, exist_ok=True)
    monkeypatch.setenv("DRY_RUN", "1")
    monkeypatch.setenv("TELEGRAM_PORTFOLIO_BOT_TOKEN", "fake")
    monkeypatch.setenv("TELEGRAM_CHAT_IDS", json.dumps({"remo": "111"}))
    # Skip Deribit network calls - exercise the portfolio-only fallback path.
    monkeypatch.setattr(report_daily, "_build_market_data", lambda _tmp: (None, {}))
    yield
    thresholds.invalidate_cache()
    notifier.reset_default_notifier()
    storage.set_db_path_for_tests(None)


# ---------------------------------------------------------------------------
# next_fire_time
# ---------------------------------------------------------------------------

def test_next_fire_time_today_if_in_future(monkeypatch) -> None:
    """If now < today's trigger, next fire is today."""
    from portfolio_analysis import config
    monkeypatch.setattr(config, "REPORT_DAILY_UTC_HOUR", 12)
    monkeypatch.setattr(config, "REPORT_DAILY_UTC_MINUTE", 0)
    now = datetime(2026, 5, 2, 8, 0, 0, tzinfo=timezone.utc)
    nxt = report_daily.next_fire_time(after=now)
    assert nxt == datetime(2026, 5, 2, 12, 0, 0, tzinfo=timezone.utc)


def test_next_fire_time_tomorrow_if_in_past(monkeypatch) -> None:
    from portfolio_analysis import config
    monkeypatch.setattr(config, "REPORT_DAILY_UTC_HOUR", 0)
    monkeypatch.setattr(config, "REPORT_DAILY_UTC_MINUTE", 5)
    now = datetime(2026, 5, 2, 12, 0, 0, tzinfo=timezone.utc)
    nxt = report_daily.next_fire_time(after=now)
    assert nxt == datetime(2026, 5, 3, 0, 5, 0, tzinfo=timezone.utc)


# ---------------------------------------------------------------------------
# build_report - empty + populated windows
# ---------------------------------------------------------------------------

def _seed_window(start: datetime) -> None:
    """Populate state_history, alerts, threshold_overrides, audit_log
    inside a known 24h window so build_report has data to render."""
    storage.insert_state(
        ts_utc=(start + timedelta(hours=1)).strftime("%Y-%m-%dT%H:%M:%S.%fZ"),
        calm_score="RELAX", active_alert_ids=[], reasoning="r1",
    )
    storage.insert_state(
        ts_utc=(start + timedelta(hours=2)).strftime("%Y-%m-%dT%H:%M:%S.%fZ"),
        calm_score="ACTIVE_MONITORING",
        active_alert_ids=[1],
        reasoning="r2 - 1 URGENT.",
    )
    storage.insert_alert(
        ts_utc=(start + timedelta(hours=2)).strftime("%Y-%m-%dT%H:%M:%S.%fZ"),
        rule="MM_PRESSURE", severity="WARNING",
        dedup_key="MM:band=warning",
        cited_features=["mm_pct"], feature_values={"mm_pct": 41.0},
        message="Maintenance margin 41% - warning band.",
    )
    storage.insert_override(
        name="MM_WARN_PCT", value=25.0,
        set_by_user_id=42, set_by_user_name="andres",
        set_at_utc=(start + timedelta(hours=3)).strftime("%Y-%m-%dT%H:%M:%S.%fZ"),
        expires_at_utc=(start + timedelta(hours=27)).strftime("%Y-%m-%dT%H:%M:%S.%fZ"),
    )
    storage.insert_audit(
        user_id=42, user_name="andres", action="set_threshold",
        payload={"name": "MM_WARN_PCT", "value": 25.0, "duration_s": 86400},
        ts_utc=(start + timedelta(hours=3)).strftime("%Y-%m-%dT%H:%M:%S.%fZ"),
    )


def test_build_report_empty_window_still_produces_pdf(tmp_path: Path) -> None:
    """The 'in all cases' rule - even with zero activity, a PDF is built."""
    end = datetime(2026, 5, 2, 0, 5, 0, tzinfo=timezone.utc)
    pdf = report_daily.build_report(window_end=end, out_path=tmp_path / "empty.pdf")
    assert pdf.exists() and pdf.stat().st_size > 0
    text = _read_pdf_text(pdf)
    # Cover + portfolio control plane.
    assert "Portfolio Co-Pilot" in text
    assert "Portfolio Control Plane" in text
    # Per-event tables (Calm Score timeline / Alerts / Threshold overrides /
    # Audit log) were intentionally removed - daily PDF is portfolio-state
    # focused only.
    assert "Calm Score timeline" not in text
    assert "Threshold overrides" not in text
    assert "Audit log" not in text
    # ROC section is always present.
    assert "BTC rate-of-change" in text


def test_build_report_populated_contains_expected_sections(tmp_path: Path) -> None:
    end = datetime(2026, 5, 2, 12, 0, 0, tzinfo=timezone.utc)
    start = end - timedelta(hours=24)
    _seed_window(start)
    pdf = report_daily.build_report(
        window_start=start, window_end=end, out_path=tmp_path / "full.pdf",
    )
    text = _read_pdf_text(pdf)
    # Cover + control plane present.
    assert "Portfolio Control Plane" in text
    assert "BTC rate-of-change" in text
    # The per-event history sections are intentionally excluded - they
    # bloated the PDF and now live in /audit, /status, and the SQLite
    # tables.
    assert "Calm Score timeline" not in text
    assert "Threshold overrides" not in text
    assert "Audit log" not in text
    # The seeded MM_PRESSURE alert no longer appears (alerts table gone),
    # but the calm-score badge picks up the seeded ACTIVE_MONITORING state.
    assert "ACTIVE_MONITORING" in text or "Portfolio Control Plane" in text
    assert "ACTIVE_MONITORING" in text


def _read_pdf_text(pdf: Path) -> str:
    """Extract text from a generated PDF for assertions."""
    from pypdf import PdfReader
    reader = PdfReader(str(pdf))
    return "\n".join(page.extract_text() or "" for page in reader.pages)


# ---------------------------------------------------------------------------
# send_report - DRY_RUN + real-path
# ---------------------------------------------------------------------------

def test_send_report_dry_run_writes_report_run(tmp_path: Path) -> None:
    """DRY_RUN: PDF is created in REPORT_DIR, no HTTP, report_runs row written."""
    end = datetime(2026, 5, 2, 0, 5, 0, tzinfo=timezone.utc)
    pdf = report_daily.build_report(window_end=end, out_path=tmp_path / "dry.pdf")
    result = report_daily.send_report(pdf, caption="hi", window_end=end)
    assert result["sent_chat_ids"] == []   # DRY_RUN
    last = storage.latest_report_run()
    assert last is not None
    assert last["pdf_path"] == str(pdf)
    assert json.loads(last["sent_chat_ids"]) == []


def test_send_report_real_calls_telegram(monkeypatch, tmp_path: Path) -> None:
    """Non-DRY_RUN sendDocument uses Telegram API and records sent chat IDs."""
    captured: list[dict] = []

    class _Resp:
        def raise_for_status(self): pass

    def fake_post(url, data=None, files=None, timeout=None):
        captured.append({"url": url, "chat_id": data["chat_id"], "has_file": bool(files)})
        return _Resp()

    import requests
    monkeypatch.setattr(requests, "post", fake_post)
    monkeypatch.setenv("DRY_RUN", "0")
    monkeypatch.setenv(
        "TELEGRAM_CHAT_IDS",
        json.dumps({"remo": "111", "andres": "222"}),
    )
    notifier.reset_default_notifier()

    end = datetime(2026, 5, 2, 0, 5, 0, tzinfo=timezone.utc)
    pdf = report_daily.build_report(window_end=end, out_path=tmp_path / "live.pdf")
    result = report_daily.send_report(pdf, caption="x", window_end=end)
    assert {c["chat_id"] for c in captured} == {"111", "222"}
    assert all(c["has_file"] for c in captured)
    assert sorted(result["sent_chat_ids"]) == ["111", "222"]
    last = storage.latest_report_run()
    assert sorted(json.loads(last["sent_chat_ids"])) == [111, 222]


def test_send_with_retry_succeeds_after_failure(monkeypatch, tmp_path: Path) -> None:
    """First send → 0 successes → retry once → success the second time."""
    monkeypatch.setenv("DRY_RUN", "0")
    notifier.reset_default_notifier()

    monkeypatch.setattr(report_daily, "RETRY_DELAY_S", 0.01)

    calls = {"n": 0}

    def fake_send(path, *, caption=None, chat_ids=None):
        calls["n"] += 1
        return ["111"] if calls["n"] >= 2 else []   # fail first, succeed second

    monkeypatch.setattr(notifier, "send_document", fake_send)

    end = datetime(2026, 5, 2, 0, 5, 0, tzinfo=timezone.utc)
    pdf = report_daily.build_report(window_end=end, out_path=tmp_path / "retry.pdf")
    result = report_daily._send_with_retry(pdf, caption="x", window_end=end)
    assert calls["n"] == 2
    assert result["sent_chat_ids"] == ["111"]


# ---------------------------------------------------------------------------
# Worker - restart safety
# ---------------------------------------------------------------------------

def test_worker_catch_up_when_no_run_yet(monkeypatch) -> None:
    """If no report_runs row exists for the most recent expected window,
    fire once on startup."""
    fired: list[datetime] = []

    def fake_fire(self, *, window_end):
        fired.append(window_end)

    monkeypatch.setattr(report_daily.DailyReportWorker, "_fire", fake_fire)

    w = report_daily.DailyReportWorker()
    w._catch_up_if_needed()
    assert len(fired) == 1


def test_worker_does_not_catch_up_when_recent_run_exists(monkeypatch) -> None:
    """If we already sent a report after the most recent expected window,
    don't fire again at startup."""
    fired: list[datetime] = []

    def fake_fire(self, *, window_end):
        fired.append(window_end)

    monkeypatch.setattr(report_daily.DailyReportWorker, "_fire", fake_fire)

    # Pre-seed a report_runs row dated AFTER the most recent expected fire.
    now = datetime.now(timezone.utc)
    storage.insert_report_run(
        ts_utc=now.strftime("%Y-%m-%dT%H:%M:%S.%fZ"),
        window_start_utc=(now - timedelta(hours=24)).strftime("%Y-%m-%dT%H:%M:%S.%fZ"),
        window_end_utc=now.strftime("%Y-%m-%dT%H:%M:%S.%fZ"),
    )
    w = report_daily.DailyReportWorker()
    w._catch_up_if_needed()
    assert fired == []


def test_worker_start_stop_cleanly(monkeypatch) -> None:
    """Daemon thread starts, ticks, and stops cleanly. No real sends."""
    monkeypatch.setattr(report_daily.DailyReportWorker, "_fire", lambda self, *, window_end: None)
    stop = threading.Event()
    w = report_daily.DailyReportWorker(interval_s=0.05, stop_event=stop)
    w.start()
    time.sleep(0.2)
    w.stop(timeout=2.0)
    assert not w._thread.is_alive()


# ---------------------------------------------------------------------------
# /report bot command - end to end (DRY_RUN)
# ---------------------------------------------------------------------------

def test_bot_report_command_dry_run(monkeypatch) -> None:
    monkeypatch.setenv(
        "AUTHORIZED_TELEGRAM_USERS",
        json.dumps({"andres": "42"}),
    )
    from portfolio_analysis.bot.commands import dispatch
    r = dispatch(text="/report", user_id=42)
    assert r is not None
    assert r.ok is True
    assert "DRY_RUN" in r.reply
    assert ".pdf" in r.reply
    # Audit row appended.
    audit = storage.recent_audit(10)
    assert any(a["action"] == "report" for a in audit)


def test_bot_report_command_real_send(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setenv("DRY_RUN", "0")
    monkeypatch.setenv(
        "AUTHORIZED_TELEGRAM_USERS",
        json.dumps({"andres": "42"}),
    )
    notifier.reset_default_notifier()

    captured: list[str] = []

    def fake_send_document(path, *, caption=None, chat_ids=None):
        captured.append(path)
        return ["111"]

    monkeypatch.setattr(notifier, "send_document", fake_send_document)

    from portfolio_analysis.bot.commands import dispatch
    r = dispatch(text="/report", user_id=42)
    assert r.ok is True
    assert "Report sent" in r.reply
    assert len(captured) == 1
    assert captured[0].endswith(".pdf")
