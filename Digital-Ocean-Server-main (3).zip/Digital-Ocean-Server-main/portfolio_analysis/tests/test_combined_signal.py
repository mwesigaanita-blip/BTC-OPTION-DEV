"""Tests for the combined σ + IQR classifier."""
from __future__ import annotations

import pytest

from portfolio_analysis.combined_signal import (
    Z_THRESHOLD,
    classify_combined_signal,
    severity_for_level,
)


@pytest.mark.parametrize("z,iqr,expected", [
    # |z| > 2 AND outside IQR → STRONG
    (2.5,  "high",   "STRONG"),
    (-2.5, "low",    "STRONG"),
    (3.0,  "low",    "STRONG"),

    # |z| > 2 only → MEDIUM
    (2.5,  "normal", "MEDIUM"),
    (-2.5, "normal", "MEDIUM"),
    (5.0,  "normal", "MEDIUM"),

    # outside IQR only → WEAK
    (1.0,  "high",   "WEAK"),
    (0.5,  "low",    "WEAK"),
    (-1.0, "high",   "WEAK"),

    # boundary: |z| == 2 (NOT > 2) and inside IQR → NORMAL
    (2.0,  "normal", "NORMAL"),
    (-2.0, "normal", "NORMAL"),

    # boundary: |z| == 2 and outside IQR → WEAK (σ side fails the > 2 test)
    (2.0,  "high",   "WEAK"),

    # quiet → NORMAL
    (0.0,  "normal", "NORMAL"),
    (1.5,  "normal", "NORMAL"),
])
def test_classify(z, iqr, expected) -> None:
    out = classify_combined_signal(z, iqr)
    assert out["level"] == expected
    assert out["z_score"] == z
    assert out["iqr"] == iqr


def test_severity_for_level() -> None:
    assert severity_for_level("STRONG") == "URGENT"
    assert severity_for_level("MEDIUM") == "WARNING"
    assert severity_for_level("WEAK")   == "INFO"
    assert severity_for_level("NORMAL") == ""   # no alert


def test_z_threshold_value() -> None:
    """Sanity: the spec says |z| > 2; if someone changes the constant
    the tests above are wrong."""
    assert Z_THRESHOLD == 2.0


def test_invalid_iqr_position_raises() -> None:
    with pytest.raises(ValueError):
        classify_combined_signal(1.0, "huge")  # type: ignore[arg-type]
