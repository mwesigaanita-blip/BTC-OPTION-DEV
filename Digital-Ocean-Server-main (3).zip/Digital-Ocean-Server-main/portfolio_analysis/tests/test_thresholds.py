"""Phase 2 tests - dynamic threshold resolver."""
from __future__ import annotations

import time
from datetime import datetime, timedelta, timezone
from pathlib import Path

import pytest

from portfolio_analysis import config, storage, thresholds
from portfolio_analysis.thresholds import (
    InvalidDuration,
    UnknownThreshold,
    parse_duration,
)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture(autouse=True)
def _isolated_db(tmp_path: Path):
    db_path = tmp_path / "portfolio_analysis.sqlite"
    storage.set_db_path_for_tests(db_path)
    thresholds.invalidate_cache()
    yield db_path
    thresholds.invalidate_cache()
    storage.set_db_path_for_tests(None)


@pytest.fixture(autouse=True)
def _short_cache_ttl(monkeypatch):
    """Make the cache TTL effectively zero so tests see DB writes immediately
    even when invalidate_cache() is not called manually."""
    monkeypatch.setattr(thresholds, "_CACHE_TTL_S", 0.0)


# ---------------------------------------------------------------------------
# parse_duration
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("text,expected", [
    ("30s", 30),
    ("30m", 30 * 60),
    ("4h",  4 * 3600),
    ("7d",  7 * 86400),
    ("1d",  86400),
    (" 2h ", 2 * 3600),
    ("15M", 15 * 60),  # case-insensitive
])
def test_parse_duration_valid(text: str, expected: int) -> None:
    assert parse_duration(text) == expected


@pytest.mark.parametrize("bad", ["", "abc", "10", "0h", "-3d", "h", "1.5h", "1y", None, 10])
def test_parse_duration_invalid(bad) -> None:
    with pytest.raises(InvalidDuration):
        parse_duration(bad)  # type: ignore[arg-type]


# ---------------------------------------------------------------------------
# get() - defaults, overrides, expiry, types
# ---------------------------------------------------------------------------

def test_get_returns_default_when_no_override() -> None:
    assert thresholds.get("MM_WARN_PCT") == config.MM_WARN_PCT
    assert thresholds.get("DTE_WARN_DAYS") == config.DTE_WARN_DAYS


def test_get_unknown_threshold_raises() -> None:
    with pytest.raises(UnknownThreshold):
        thresholds.get("NOT_A_REAL_THRESHOLD")


def test_get_returns_override_value() -> None:
    thresholds.set_override(
        name="MM_WARN_PCT", value=25.0, duration_s=3600,
        user_id=42, user_name="andres",
    )
    assert thresholds.get("MM_WARN_PCT") == 25.0


def test_get_preserves_int_type_for_int_defaults() -> None:
    """DTE_WARN_DAYS is an int; an override should still come back as int."""
    thresholds.set_override(
        name="DTE_WARN_DAYS", value=20, duration_s=3600,
        user_id=1, user_name="x",
    )
    v = thresholds.get("DTE_WARN_DAYS")
    assert v == 20
    assert isinstance(v, int)


def test_get_returns_float_for_float_defaults() -> None:
    thresholds.set_override(
        name="MM_WARN_PCT", value=25, duration_s=3600,
        user_id=1, user_name="x",
    )
    v = thresholds.get("MM_WARN_PCT")
    assert v == 25.0
    assert isinstance(v, float)


def test_override_reverts_to_default_after_expiry() -> None:
    """Insert an override that already expired in the past → get() ignores it."""
    past = (datetime.now(timezone.utc) - timedelta(hours=1)).strftime(
        "%Y-%m-%dT%H:%M:%S.%fZ"
    )
    storage.insert_override(
        name="MM_WARN_PCT", value=25.0,
        set_by_user_id=1, set_by_user_name="x",
        set_at_utc="2026-05-01T00:00:00.000000Z",
        expires_at_utc=past,
    )
    thresholds.invalidate_cache()
    assert thresholds.get("MM_WARN_PCT") == config.MM_WARN_PCT


def test_most_recent_override_wins() -> None:
    thresholds.set_override(
        name="MM_WARN_PCT", value=25.0, duration_s=3600,
        user_id=1, user_name="a",
    )
    time.sleep(0.005)  # ensure distinct set_at_utc
    thresholds.set_override(
        name="MM_WARN_PCT", value=28.0, duration_s=3600,
        user_id=2, user_name="b",
    )
    assert thresholds.get("MM_WARN_PCT") == 28.0


# ---------------------------------------------------------------------------
# set_override - DB write + audit row + cache invalidation
# ---------------------------------------------------------------------------

def test_set_override_writes_audit_row() -> None:
    thresholds.set_override(
        name="MM_WARN_PCT", value=25.0, duration_s=3600,
        user_id=42, user_name="andres",
    )
    audit = storage.recent_audit(10)
    assert len(audit) == 1
    assert audit[0]["action"] == "set_threshold"
    assert audit[0]["user_name"] == "andres"


def test_set_override_unknown_name_raises() -> None:
    with pytest.raises(UnknownThreshold):
        thresholds.set_override(
            name="NOPE", value=1, duration_s=60,
            user_id=1, user_name="x",
        )


def test_set_override_zero_or_negative_duration_raises() -> None:
    with pytest.raises(InvalidDuration):
        thresholds.set_override(
            name="MM_WARN_PCT", value=25.0, duration_s=0,
            user_id=1, user_name="x",
        )
    with pytest.raises(InvalidDuration):
        thresholds.set_override(
            name="MM_WARN_PCT", value=25.0, duration_s=-1,
            user_id=1, user_name="x",
        )


def test_set_override_returns_descriptor() -> None:
    desc = thresholds.set_override(
        name="MM_WARN_PCT", value=25.0, duration_s=3600,
        user_id=42, user_name="andres",
    )
    assert desc["name"] == "MM_WARN_PCT"
    assert desc["value"] == 25.0
    assert desc["duration_s"] == 3600
    assert desc["expires_at_utc"].endswith("Z")
    assert desc["set_by"] == {"user_id": 42, "user_name": "andres"}


def test_set_override_invalidates_cache(monkeypatch) -> None:
    """Even with a long TTL, set_override must drop the cached value."""
    # Restore a long TTL to verify invalidation explicitly.
    monkeypatch.setattr(thresholds, "_CACHE_TTL_S", 60.0)

    assert thresholds.get("MM_WARN_PCT") == config.MM_WARN_PCT  # caches default
    thresholds.set_override(
        name="MM_WARN_PCT", value=25.0, duration_s=3600,
        user_id=1, user_name="x",
    )
    assert thresholds.get("MM_WARN_PCT") == 25.0  # would still be 30 if cached


# ---------------------------------------------------------------------------
# Cache behaviour
# ---------------------------------------------------------------------------

def test_cache_serves_repeated_reads(monkeypatch) -> None:
    """With TTL > 0, second get() must NOT hit storage."""
    monkeypatch.setattr(thresholds, "_CACHE_TTL_S", 60.0)
    thresholds.invalidate_cache()

    calls = {"n": 0}
    real = storage.active_overrides_for

    def spy(name, **kw):
        calls["n"] += 1
        return real(name, **kw)

    monkeypatch.setattr(storage, "active_overrides_for", spy)
    thresholds.get("MM_WARN_PCT")
    thresholds.get("MM_WARN_PCT")
    thresholds.get("MM_WARN_PCT")
    assert calls["n"] == 1


def test_cache_expires_with_ttl(monkeypatch) -> None:
    monkeypatch.setattr(thresholds, "_CACHE_TTL_S", 0.05)
    thresholds.invalidate_cache()

    calls = {"n": 0}
    real = storage.active_overrides_for

    def spy(name, **kw):
        calls["n"] += 1
        return real(name, **kw)

    monkeypatch.setattr(storage, "active_overrides_for", spy)
    thresholds.get("MM_WARN_PCT")
    time.sleep(0.08)
    thresholds.get("MM_WARN_PCT")
    assert calls["n"] == 2


# ---------------------------------------------------------------------------
# list_active
# ---------------------------------------------------------------------------

def test_list_active_all_defaults_when_no_overrides() -> None:
    rows = thresholds.list_active()
    assert {r["name"] for r in rows} == set(config.DEFAULT_THRESHOLDS.keys())
    for r in rows:
        assert r["overridden"] is False
        assert r["current"] == r["default"]
        assert r["expires_at_utc"] is None


def test_list_active_marks_overridden_rows() -> None:
    thresholds.set_override(
        name="MM_WARN_PCT", value=25.0, duration_s=3600,
        user_id=42, user_name="andres",
    )
    rows = thresholds.list_active()
    by_name = {r["name"]: r for r in rows}

    assert by_name["MM_WARN_PCT"]["overridden"] is True
    assert by_name["MM_WARN_PCT"]["current"] == 25.0
    assert by_name["MM_WARN_PCT"]["set_by_user_name"] == "andres"
    assert by_name["MM_WARN_PCT"]["expires_at_utc"] is not None

    assert by_name["DELTA_WARN_BTC"]["overridden"] is False
    assert by_name["DELTA_WARN_BTC"]["current"] == config.DELTA_WARN_BTC


def test_list_active_preserves_int_type() -> None:
    thresholds.set_override(
        name="HEARTBEAT_RELAX_S", value=300, duration_s=3600,
        user_id=1, user_name="x",
    )
    rows = thresholds.list_active()
    by_name = {r["name"]: r for r in rows}
    assert by_name["HEARTBEAT_RELAX_S"]["current"] == 300
    assert isinstance(by_name["HEARTBEAT_RELAX_S"]["current"], int)
