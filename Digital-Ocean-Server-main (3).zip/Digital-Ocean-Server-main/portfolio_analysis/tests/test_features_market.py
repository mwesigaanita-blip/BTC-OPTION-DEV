"""Phase 3 tests - market features (returns + σ)."""
from __future__ import annotations

import math
from pathlib import Path

import pytest

from portfolio_analysis import storage
from portfolio_analysis.features import market
from portfolio_analysis.tests.conftest import seed_market_ticks


@pytest.fixture(autouse=True)
def _isolated_pa_db(tmp_path: Path):
    storage.set_db_path_for_tests(tmp_path / "pa.sqlite")
    yield
    storage.set_db_path_for_tests(None)


# ---------------------------------------------------------------------------
# compute_returns
# ---------------------------------------------------------------------------

def test_returns_simple_1h(
    isolated_realtime_db: Path, isolated_market_data_db: Path,
) -> None:
    """now=$110, 1h ago=$100 → +10% return.

    24h reads from the daily-close table now; with btc_prices empty
    (the isolated_market_data_db fixture is empty), 24h must be None.
    """
    seed_market_ticks(isolated_realtime_db, [
        ("2026-05-02T11:00:00.000000Z", 100.0),
        ("2026-05-02T12:00:00.000000Z", 110.0),
    ])
    out = market.compute_returns("2026-05-02T12:00:00.000000Z")
    assert out["1h"] == pytest.approx(10.0)
    # 4h has no realtime past tick → None
    assert out["4h"] is None
    # 24h reads daily, which is empty → None
    assert out["24h"] is None


def test_returns_negative(isolated_realtime_db: Path) -> None:
    seed_market_ticks(isolated_realtime_db, [
        ("2026-05-02T11:00:00.000000Z", 100.0),
        ("2026-05-02T12:00:00.000000Z", 95.0),
    ])
    out = market.compute_returns("2026-05-02T12:00:00.000000Z")
    assert out["1h"] == pytest.approx(-5.0)


def test_returns_uses_most_recent_tick_at_or_before(isolated_realtime_db: Path) -> None:
    """Picks the latest tick with ts <= now-horizon, not strictly equal."""
    seed_market_ticks(isolated_realtime_db, [
        ("2026-05-02T10:55:00.000000Z", 100.0),    # ~5min before 1h horizon
        ("2026-05-02T11:00:00.000000Z", 102.0),    # exactly 1h horizon
        ("2026-05-02T11:30:00.000000Z", 105.0),    # within 1h window - must NOT use
        ("2026-05-02T12:00:00.000000Z", 110.0),
    ])
    out = market.compute_returns("2026-05-02T12:00:00.000000Z")
    # Should use 102 (latest <= 11:00:00), not 105.
    assert out["1h"] == pytest.approx((110 - 102) / 102 * 100.0)


def test_returns_empty_db(
    isolated_realtime_db: Path, isolated_market_data_db: Path,
) -> None:
    """Both DBs empty → every timeframe is None."""
    out = market.compute_returns("2026-05-02T12:00:00.000000Z")
    assert out == {tf: None for tf in market.MARKET_TIMEFRAMES}


def test_returns_realtime_db_missing(tmp_path: Path, monkeypatch) -> None:
    """If realtime.sqlite is absent, all returns are None (no crash)."""
    import shared.db_paths as _dbp
    from portfolio_analysis.features import btc_returns as _btc_returns
    from portfolio_analysis.features import market as _market
    missing_rt = tmp_path / "does-not-exist-rt.sqlite"
    missing_md = tmp_path / "does-not-exist-md.sqlite"
    monkeypatch.setattr(_dbp, "REALTIME_DB", missing_rt)
    monkeypatch.setattr(_dbp, "MARKET_DATA_DB", missing_md)
    monkeypatch.setattr(_btc_returns, "REALTIME_DB", missing_rt)
    monkeypatch.setattr(_btc_returns, "MARKET_DATA_DB", missing_md)
    monkeypatch.setattr(_market, "REALTIME_DB", missing_rt)
    out = market.compute_returns("2026-05-02T12:00:00.000000Z")
    assert out == {tf: None for tf in market.MARKET_TIMEFRAMES}


# ---------------------------------------------------------------------------
# compute_sigma
# ---------------------------------------------------------------------------

def test_sigma_matches_sample_stdev() -> None:
    """σ should equal the sample standard deviation of the seeded returns."""
    values = [0.5, -0.3, 1.2, -1.0, 0.7]
    for i, v in enumerate(values):
        storage.insert_return(
            ts_utc=f"2026-05-02T1{i}:00:00.000000Z",
            timeframe="1h",
            return_pct=v,
        )
    # Reference "now" anchored to the seed window so the 48h lookback covers it.
    sigma = market.compute_sigma("1h", now_utc="2026-05-02T20:00:00.000000Z")
    mean = sum(values) / len(values)
    expected = math.sqrt(sum((v - mean) ** 2 for v in values) / (len(values) - 1))
    assert sigma == pytest.approx(expected)


def test_sigma_returns_none_when_too_few_samples() -> None:
    storage.insert_return(ts_utc="2026-05-02T10:00:00Z", timeframe="1h", return_pct=0.5)
    assert market.compute_sigma("1h") is None  # only 1 sample


def test_sigma_unknown_timeframe_raises() -> None:
    with pytest.raises(ValueError):
        market.compute_sigma("99d")


def test_sigma_only_uses_matching_timeframe() -> None:
    for v in [0.1, 0.2, 0.3]:
        storage.insert_return(
            ts_utc=f"2026-05-02T1{int(v*10)}:00:00Z",
            timeframe="4h", return_pct=v,
        )
    ref = "2026-05-02T20:00:00.000000Z"  # anchor inside the 48h window
    # No 1h rows
    assert market.compute_sigma("1h", now_utc=ref) is None
    assert market.compute_sigma("4h", now_utc=ref) is not None


# ---------------------------------------------------------------------------
# compute (bundle)
# ---------------------------------------------------------------------------

def test_compute_bundle_shape(isolated_realtime_db: Path) -> None:
    seed_market_ticks(isolated_realtime_db, [
        ("2026-05-02T11:00:00.000000Z", 100.0),
        ("2026-05-02T12:00:00.000000Z", 110.0),
    ])
    bundle = market.compute("2026-05-02T12:00:00.000000Z")
    assert set(bundle.returns.keys()) == set(market.MARKET_TIMEFRAMES.keys())
    assert set(bundle.sigmas.keys()) == set(market.MARKET_TIMEFRAMES.keys())
    assert bundle.returns["1h"] == pytest.approx(10.0)
    # No returns_history seeded → all sigmas None
    assert all(s is None for s in bundle.sigmas.values())
