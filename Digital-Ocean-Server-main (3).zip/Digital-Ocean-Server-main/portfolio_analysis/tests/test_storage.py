"""Phase 1 tests - storage layer."""
from __future__ import annotations

import json
import sqlite3
from pathlib import Path

import pytest

from portfolio_analysis import storage


# ---------------------------------------------------------------------------
# Fixtures - every test gets a fresh SQLite file via tmp_path.
# ---------------------------------------------------------------------------

@pytest.fixture(autouse=True)
def _isolated_db(tmp_path: Path):
    """Point storage at a temp DB for the duration of the test."""
    db_path = tmp_path / "portfolio_analysis.sqlite"
    storage.set_db_path_for_tests(db_path)
    yield db_path
    storage.set_db_path_for_tests(None)


# ---------------------------------------------------------------------------
# init_db - idempotency, WAL, all tables present
# ---------------------------------------------------------------------------

def test_init_db_creates_all_tables(_isolated_db: Path) -> None:
    storage.init_db()
    conn = sqlite3.connect(str(_isolated_db))
    rows = conn.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()
    names = {r[0] for r in rows}
    expected = {
        "alerts", "state_history", "threshold_overrides",
        "suppressions", "audit_log", "returns_history", "report_runs",
    }
    assert expected.issubset(names), f"missing tables: {expected - names}"


def test_init_db_is_idempotent(_isolated_db: Path) -> None:
    storage.init_db()
    storage.init_db()  # must not raise, must not duplicate tables
    conn = sqlite3.connect(str(_isolated_db))
    cnt = conn.execute(
        "SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name='alerts'"
    ).fetchone()[0]
    assert cnt == 1


def test_init_db_enables_wal(_isolated_db: Path) -> None:
    storage.init_db()
    conn = sqlite3.connect(str(_isolated_db))
    mode = conn.execute("PRAGMA journal_mode").fetchone()[0]
    assert mode.lower() == "wal"


def test_init_db_creates_required_indexes(_isolated_db: Path) -> None:
    storage.init_db()
    conn = sqlite3.connect(str(_isolated_db))
    rows = conn.execute("SELECT name FROM sqlite_master WHERE type='index'").fetchall()
    names = {r[0] for r in rows}
    for required in (
        "idx_alerts_ts", "idx_alerts_dedup", "idx_alerts_unresolved",
        "idx_overrides_active", "idx_audit_ts",
        "idx_returns_tf_ts", "idx_report_runs_ts",
    ):
        assert required in names, f"missing index: {required}"


# ---------------------------------------------------------------------------
# alerts - round-trip + UNIQUE(dedup_key, ts_utc)
# ---------------------------------------------------------------------------

def _sample_alert(**overrides):
    base = dict(
        ts_utc="2026-05-02T12:00:00.000000Z",
        rule="MM_PRESSURE",
        severity="WARNING",
        dedup_key="MM:band=warning",
        cited_features=["mm_pct"],
        feature_values={"mm_pct": 41.0},
        message="MM crossed warning band",
    )
    base.update(overrides)
    return base


def test_insert_alert_round_trip() -> None:
    aid = storage.insert_alert(**_sample_alert())
    assert aid is not None
    row = storage.unresolved_alerts()[0]
    assert row["rule"] == "MM_PRESSURE"
    assert row["severity"] == "WARNING"
    assert row["dedup_key"] == "MM:band=warning"
    assert json.loads(row["cited_features"]) == ["mm_pct"]
    assert json.loads(row["feature_values"]) == {"mm_pct": 41.0}
    assert row["resolved_at_utc"] is None


def test_insert_alert_duplicate_rejected() -> None:
    a = _sample_alert()
    first = storage.insert_alert(**a)
    second = storage.insert_alert(**a)  # same dedup_key + ts_utc
    assert first is not None
    assert second is None  # duplicate ignored
    assert len(storage.unresolved_alerts()) == 1


def test_insert_alert_same_dedup_different_ts_allowed() -> None:
    storage.insert_alert(**_sample_alert(ts_utc="2026-05-02T12:00:00.000000Z"))
    storage.insert_alert(**_sample_alert(ts_utc="2026-05-02T12:30:00.000000Z"))
    assert len(storage.unresolved_alerts()) == 2


def test_unresolved_alerts_filters_resolved() -> None:
    aid = storage.insert_alert(**_sample_alert())
    assert aid is not None
    storage.resolve_alert(alert_id=aid)
    assert storage.unresolved_alerts() == []


def test_resolve_alert_is_idempotent() -> None:
    aid = storage.insert_alert(**_sample_alert())
    assert aid is not None
    storage.resolve_alert(alert_id=aid, resolved_at_utc="2026-05-02T13:00:00Z")
    storage.resolve_alert(alert_id=aid, resolved_at_utc="2026-05-02T14:00:00Z")
    conn = storage.get_conn()
    row = conn.execute("SELECT resolved_at_utc FROM alerts WHERE id=?", (aid,)).fetchone()
    # First resolve wins; second is a no-op.
    assert row["resolved_at_utc"] == "2026-05-02T13:00:00Z"


# ---------------------------------------------------------------------------
# state_history
# ---------------------------------------------------------------------------

def test_state_history_round_trip() -> None:
    storage.insert_state(
        ts_utc="2026-05-02T12:00:00Z",
        calm_score="ACTIVE_MONITORING",
        active_alert_ids=[1, 2, 3],
        reasoning="1 URGENT, 2 WARNING",
        last_notified_utc="2026-05-02T12:00:00Z",
    )
    row = storage.latest_state()
    assert row is not None
    assert row["calm_score"] == "ACTIVE_MONITORING"
    assert json.loads(row["active_alert_ids"]) == [1, 2, 3]


def test_latest_state_returns_newest() -> None:
    storage.insert_state(ts_utc="2026-05-02T12:00:00Z", calm_score="RELAX")
    storage.insert_state(ts_utc="2026-05-02T13:00:00Z", calm_score="TAKE_A_LOOK")
    storage.insert_state(ts_utc="2026-05-02T11:00:00Z", calm_score="URGENT_ACTION")
    row = storage.latest_state()
    assert row["calm_score"] == "TAKE_A_LOOK"


def test_latest_state_empty_returns_none() -> None:
    assert storage.latest_state() is None


# ---------------------------------------------------------------------------
# threshold_overrides
# ---------------------------------------------------------------------------

def test_override_round_trip_and_active_lookup() -> None:
    storage.insert_override(
        name="MM_WARN_PCT",
        value=25.0,
        set_by_user_id=42,
        set_by_user_name="andres",
        set_at_utc="2026-05-02T12:00:00Z",
        expires_at_utc="2026-05-09T12:00:00Z",
    )
    row = storage.active_overrides_for("MM_WARN_PCT", now_utc="2026-05-03T00:00:00Z")
    assert row is not None
    assert row["value"] == 25.0
    assert row["set_by_user_name"] == "andres"


def test_expired_override_not_returned() -> None:
    storage.insert_override(
        name="MM_WARN_PCT", value=25.0,
        set_by_user_id=1, set_by_user_name="x",
        set_at_utc="2026-05-01T00:00:00Z",
        expires_at_utc="2026-05-02T00:00:00Z",
    )
    row = storage.active_overrides_for("MM_WARN_PCT", now_utc="2026-05-03T00:00:00Z")
    assert row is None


def test_most_recent_override_wins() -> None:
    storage.insert_override(
        name="MM_WARN_PCT", value=25.0,
        set_by_user_id=1, set_by_user_name="a",
        set_at_utc="2026-05-02T10:00:00Z",
        expires_at_utc="2026-05-09T00:00:00Z",
    )
    storage.insert_override(
        name="MM_WARN_PCT", value=28.0,
        set_by_user_id=2, set_by_user_name="b",
        set_at_utc="2026-05-02T11:00:00Z",
        expires_at_utc="2026-05-09T00:00:00Z",
    )
    row = storage.active_overrides_for("MM_WARN_PCT", now_utc="2026-05-02T12:00:00Z")
    assert row["value"] == 28.0


# ---------------------------------------------------------------------------
# suppressions - UNIQUE(dedup_key, cleared_at_utc=NULL) means at most one active
# ---------------------------------------------------------------------------

def test_only_one_active_suppression_per_key() -> None:
    first = storage.insert_suppression(
        dedup_key="MM:band=warning",
        set_by_user_id=1, set_by_user_name="a",
    )
    second = storage.insert_suppression(
        dedup_key="MM:band=warning",
        set_by_user_id=2, set_by_user_name="b",
    )
    assert first is not None
    assert second is None  # duplicate active suppression rejected
    assert len(storage.active_suppressions()) == 1


def test_clear_then_resuppress_allowed() -> None:
    storage.insert_suppression(
        dedup_key="MM:band=warning",
        set_by_user_id=1, set_by_user_name="a",
    )
    cleared = storage.clear_suppression(dedup_key="MM:band=warning")
    assert cleared == 1
    assert storage.active_suppressions() == []
    # Now a new suppression for the same key must be allowed.
    new_id = storage.insert_suppression(
        dedup_key="MM:band=warning",
        set_by_user_id=2, set_by_user_name="b",
    )
    assert new_id is not None
    assert len(storage.active_suppressions()) == 1


def test_clear_suppression_no_active_returns_zero() -> None:
    cleared = storage.clear_suppression(dedup_key="DOES_NOT_EXIST")
    assert cleared == 0


def test_active_suppressions_only_returns_uncleared() -> None:
    storage.insert_suppression(dedup_key="A", set_by_user_id=1, set_by_user_name="x")
    storage.insert_suppression(dedup_key="B", set_by_user_id=1, set_by_user_name="x")
    storage.clear_suppression(dedup_key="A")
    keys = {r["dedup_key"] for r in storage.active_suppressions()}
    assert keys == {"B"}


# ---------------------------------------------------------------------------
# audit_log
# ---------------------------------------------------------------------------

def test_audit_round_trip() -> None:
    storage.insert_audit(
        user_id=42, user_name="andres",
        action="set_threshold",
        payload={"name": "MM_WARN_PCT", "value": 25, "duration": "1h"},
        ts_utc="2026-05-02T12:00:00Z",
    )
    rows = storage.recent_audit(10)
    assert len(rows) == 1
    assert rows[0]["action"] == "set_threshold"
    assert json.loads(rows[0]["payload_json"])["value"] == 25


def test_recent_audit_orders_newest_first() -> None:
    for i, ts in enumerate([
        "2026-05-02T10:00:00Z",
        "2026-05-02T12:00:00Z",
        "2026-05-02T11:00:00Z",
    ]):
        storage.insert_audit(
            user_id=1, user_name="x", action=f"a{i}", payload={}, ts_utc=ts,
        )
    rows = storage.recent_audit(10)
    assert [r["ts_utc"] for r in rows] == [
        "2026-05-02T12:00:00Z",
        "2026-05-02T11:00:00Z",
        "2026-05-02T10:00:00Z",
    ]


def test_recent_audit_limit() -> None:
    for i in range(5):
        storage.insert_audit(
            user_id=1, user_name="x", action="a", payload={},
            ts_utc=f"2026-05-02T1{i}:00:00Z",
        )
    assert len(storage.recent_audit(3)) == 3


# ---------------------------------------------------------------------------
# returns_history
# ---------------------------------------------------------------------------

def test_returns_round_trip_and_filter() -> None:
    storage.insert_return(ts_utc="2026-05-02T10:00:00Z", timeframe="1h", return_pct=0.5)
    storage.insert_return(ts_utc="2026-05-02T11:00:00Z", timeframe="1h", return_pct=-0.3)
    storage.insert_return(ts_utc="2026-05-02T12:00:00Z", timeframe="4h", return_pct=1.2)
    rows_1h = storage.returns_for("1h")
    assert [r["return_pct"] for r in rows_1h] == [0.5, -0.3]
    rows_4h = storage.returns_for("4h")
    assert [r["return_pct"] for r in rows_4h] == [1.2]


def test_returns_replace_on_same_pk() -> None:
    storage.insert_return(ts_utc="2026-05-02T10:00:00Z", timeframe="1h", return_pct=0.5)
    storage.insert_return(ts_utc="2026-05-02T10:00:00Z", timeframe="1h", return_pct=0.9)
    rows = storage.returns_for("1h")
    assert len(rows) == 1
    assert rows[0]["return_pct"] == 0.9


def test_returns_for_since_filter() -> None:
    storage.insert_return(ts_utc="2026-05-01T00:00:00Z", timeframe="1h", return_pct=0.1)
    storage.insert_return(ts_utc="2026-05-02T00:00:00Z", timeframe="1h", return_pct=0.2)
    rows = storage.returns_for("1h", since_utc="2026-05-02T00:00:00Z")
    assert [r["return_pct"] for r in rows] == [0.2]


# ---------------------------------------------------------------------------
# report_runs
# ---------------------------------------------------------------------------

def test_report_run_round_trip() -> None:
    rid = storage.insert_report_run(
        ts_utc="2026-05-02T00:05:00Z",
        window_start_utc="2026-05-01T00:05:00Z",
        window_end_utc="2026-05-02T00:05:00Z",
        pdf_path="/tmp/report.pdf",
        sent_chat_ids=[111, 222],
    )
    assert rid > 0
    row = storage.latest_report_run()
    assert row is not None
    assert row["pdf_path"] == "/tmp/report.pdf"
    assert json.loads(row["sent_chat_ids"]) == [111, 222]
    assert row["error"] is None


def test_latest_report_run_returns_newest() -> None:
    storage.insert_report_run(
        ts_utc="2026-05-01T00:05:00Z",
        window_start_utc="2026-04-30T00:05:00Z",
        window_end_utc="2026-05-01T00:05:00Z",
    )
    storage.insert_report_run(
        ts_utc="2026-05-02T00:05:00Z",
        window_start_utc="2026-05-01T00:05:00Z",
        window_end_utc="2026-05-02T00:05:00Z",
    )
    row = storage.latest_report_run()
    assert row["ts_utc"] == "2026-05-02T00:05:00Z"


# ---------------------------------------------------------------------------
# utc_now_iso
# ---------------------------------------------------------------------------

def test_utc_now_iso_format() -> None:
    s = storage.utc_now_iso()
    assert s.endswith("Z")
    # YYYY-MM-DDTHH:MM:SS.ffffffZ
    assert len(s) == len("2026-05-02T12:00:00.000000Z")
