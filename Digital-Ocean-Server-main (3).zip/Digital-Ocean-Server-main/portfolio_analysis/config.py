"""Default thresholds and constants for the portfolio_analysis package.

Single source of truth for every threshold's *default* value. At runtime
all comparisons go through ``portfolio_analysis.thresholds.get(name)``,
which returns an active override (if any) or falls back here.

Do NOT hard-code threshold values anywhere else in the package.
"""
from __future__ import annotations

from typing import Final

# ---------------------------------------------------------------------------
# Rule 1 - Maintenance margin (MM%) bands
# ---------------------------------------------------------------------------
MM_WARN_PCT:     Final[float] = 30.0
MM_URGENT_PCT:   Final[float] = 40.0
MM_CRITICAL_PCT: Final[float] = 50.0

# ---------------------------------------------------------------------------
# Rule 2 - Delta drift bands (absolute, BTC)
# ---------------------------------------------------------------------------
DELTA_GOOD_BTC:     Final[float] = 0.50
DELTA_WARN_BTC:     Final[float] = 1.00
DELTA_CRITICAL_BTC: Final[float] = 2.00

# ---------------------------------------------------------------------------
# Rule 3 - Time to expiry (DTE) per option position
# ---------------------------------------------------------------------------
DTE_WARN_DAYS:     Final[int] = 30
DTE_CRITICAL_DAYS: Final[int] = 15

# ---------------------------------------------------------------------------
# Heartbeat cadence per Calm Score state (seconds)
# ---------------------------------------------------------------------------
HEARTBEAT_RELAX_S:             Final[int] = 6 * 60 * 60   # 21600
HEARTBEAT_TAKE_A_LOOK_S:       Final[int] = 2 * 60 * 60   # 7200
HEARTBEAT_ACTIVE_MONITORING_S: Final[int] = 30 * 60       # 1800
HEARTBEAT_URGENT_ACTION_S:     Final[int] = 60            # 60

# ---------------------------------------------------------------------------
# Fixed constants (NOT overrideable per plan.md)
# ---------------------------------------------------------------------------
# σ lookback per timeframe.
# Short-term timeframes (1h, 4h) match the realtime DB's 48-hour window -
# we don't want a "4h vol" metric to silently include data that's 80 days
# old. The 24h timeframe keeps a long-term context (90 days of daily
# moves) because that horizon needs more samples to be meaningful.
SIGMA_LOOKBACK_HOURS_PER_TF: Final[dict[str, int]] = {
    "1h":  48,
    "4h":  48,
    "24h": 90 * 24,   # 90 days
}
# Default fallback for unknown timeframes (mirrors the original behaviour).
SIGMA_LOOKBACK_DAYS: Final[int] = 90

SIGMA_WARNING_MULT:  Final[float] = 1.0
SIGMA_CRITICAL_MULT: Final[float] = 2.0
SIGMA_EXTREME_MULT:  Final[float] = 3.0

# Minimum σ used for z-score classification. In dead-calm markets the
# raw σ collapses toward 0 and a totally normal +0.4 % move would
# register as +20σ "extreme". The floor stops the engine from screaming
# at noise during quiet periods. Applied per-timeframe (same value).
SIGMA_FLOOR_PCT: Final[float] = 0.50

QUANTILE_LOOKBACK_DAYS: Final[int] = 90
QUANTILE_LOW:           Final[float] = 0.25
QUANTILE_MEDIAN:        Final[float] = 0.50
QUANTILE_HIGH:          Final[float] = 0.75

# ---------------------------------------------------------------------------
# Daily PDF report (Phase 10)
# ---------------------------------------------------------------------------
import os as _os
from pathlib import Path as _Path

from shared.db_paths import DATA_DIR as _DATA_DIR

# UTC time at which the daily report fires (default 00:05 UTC).
REPORT_DAILY_UTC_HOUR:   Final[int] = int(_os.getenv("REPORT_DAILY_UTC_HOUR", "0"))
REPORT_DAILY_UTC_MINUTE: Final[int] = int(_os.getenv("REPORT_DAILY_UTC_MINUTE", "5"))

# Where PDFs are written (DRY_RUN destination + backup copy of sent files).
REPORT_DIR: Final[_Path] = _Path(
    _os.getenv("PORTFOLIO_REPORT_DIR", str(_DATA_DIR / "reports"))
)
REPORT_DIR.mkdir(parents=True, exist_ok=True)

# ---------------------------------------------------------------------------
# Master list - every overrideable threshold name and its default value.
# Used by the threshold resolver, /thresholds command, and tests to enforce
# that no override targets an unknown name.
# ---------------------------------------------------------------------------
DEFAULT_THRESHOLDS: Final[dict[str, float | int]] = {
    "MM_WARN_PCT":                   MM_WARN_PCT,
    "MM_URGENT_PCT":                 MM_URGENT_PCT,
    "MM_CRITICAL_PCT":               MM_CRITICAL_PCT,
    "DELTA_GOOD_BTC":                DELTA_GOOD_BTC,
    "DELTA_WARN_BTC":                DELTA_WARN_BTC,
    "DELTA_CRITICAL_BTC":            DELTA_CRITICAL_BTC,
    "DTE_WARN_DAYS":                 DTE_WARN_DAYS,
    "DTE_CRITICAL_DAYS":             DTE_CRITICAL_DAYS,
    "HEARTBEAT_RELAX_S":             HEARTBEAT_RELAX_S,
    "HEARTBEAT_TAKE_A_LOOK_S":       HEARTBEAT_TAKE_A_LOOK_S,
    "HEARTBEAT_ACTIVE_MONITORING_S": HEARTBEAT_ACTIVE_MONITORING_S,
    "HEARTBEAT_URGENT_ACTION_S":     HEARTBEAT_URGENT_ACTION_S,
}

__all__ = [
    "MM_WARN_PCT", "MM_URGENT_PCT", "MM_CRITICAL_PCT",
    "DELTA_GOOD_BTC", "DELTA_WARN_BTC", "DELTA_CRITICAL_BTC",
    "DTE_WARN_DAYS", "DTE_CRITICAL_DAYS",
    "HEARTBEAT_RELAX_S", "HEARTBEAT_TAKE_A_LOOK_S",
    "HEARTBEAT_ACTIVE_MONITORING_S", "HEARTBEAT_URGENT_ACTION_S",
    "SIGMA_LOOKBACK_DAYS", "SIGMA_WARNING_MULT", "SIGMA_CRITICAL_MULT", "SIGMA_EXTREME_MULT",
    "QUANTILE_LOOKBACK_DAYS", "QUANTILE_LOW", "QUANTILE_MEDIAN", "QUANTILE_HIGH",
    "DEFAULT_THRESHOLDS",
]
