"""portfolio_analysis package.

Loads ``.env`` from the repo root at import time so any direct
``python -m portfolio_analysis.<x>`` entry point picks up
``TELEGRAM_PORTFOLIO_BOT_TOKEN``, ``TELEGRAM_CHAT_IDS``,
``AUTHORIZED_TELEGRAM_USERS``, ``DRY_RUN`` etc. without requiring the
caller to source the file first.

Mirrors the pattern of ``backend_api/settings.py``.
"""
from __future__ import annotations

from pathlib import Path

try:
    import dotenv as _dotenv
    _dotenv.load_dotenv(Path(__file__).resolve().parents[1] / ".env")
except ImportError:
    # python-dotenv is in requirements.txt; missing only in odd test envs.
    pass
