"""AlertWorker - the 30-second deterministic evaluation loop.

Each cycle:

  1. Read the latest ``hedge_engine_aggregated_metrics`` row.
  2. Append the latest market / price-change returns to ``returns_history``
     (one row per timeframe per cycle, used by Rules 4 and 5).
  3. Compute the FeatureBundle (market σ, quantiles, per-position).
  4. Resolve any previously-open alerts whose conditions no longer hold;
     clear matching suppressions (per plan.md §4).
  5. Run all rules → dedup → insert new alerts.
  6. Classify the Calm Score → persist a ``state_history`` row.

Notification (Phase 7) and Telegram bot (Phase 8) are *not* wired in
this phase - the worker only writes to the DB so the rest of the system
can pick it up. The notifier hand-off happens in Phase 7 via a tiny
post-cycle hook.
"""
from __future__ import annotations

import sqlite3
import threading
import time
from types import SimpleNamespace
from typing import Callable, Optional

from portfolio_analysis import notifier as _notifier
from portfolio_analysis import rules, state, storage
from portfolio_analysis.rules.base import Alert
from portfolio_analysis.features import FeatureBundle, market, positions, price_change
from realtime._logging import get_logger
from shared.db_paths import HEDGE_ENGINE_DB

__all__ = [
    "AlertWorker",
    "run_once",
    "WORKER_INTERVAL_S",
    "CYCLE_SLOW_THRESHOLD_S",
]

WORKER_INTERVAL_S = 30.0           # cadence between cycles
CYCLE_SLOW_THRESHOLD_S = 1.0       # warn-log if a cycle exceeds this

log = get_logger("portfolio_analysis.worker")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _read_latest_agg_metrics() -> Optional[sqlite3.Row]:
    """Most recent row of ``hedge_engine_aggregated_metrics``, or None."""
    try:
        conn = sqlite3.connect(
            f"file:{HEDGE_ENGINE_DB}?mode=ro", uri=True, timeout=2.0,
        )
    except sqlite3.OperationalError:
        return None
    conn.row_factory = sqlite3.Row
    try:
        return conn.execute(
            "SELECT * FROM hedge_engine_aggregated_metrics "
            "ORDER BY ts_utc DESC LIMIT 1"
        ).fetchone()
    except sqlite3.OperationalError:
        # Table may not exist yet (e.g., aggregator hasn't run).
        return None
    finally:
        conn.close()


def _persist_market_returns(ts_utc: str, returns: dict) -> None:
    """Write the per-timeframe returns to ``returns_history`` for σ/quantile buffers.

    Each timeframe is downsampled to a UTC-anchored boundary (see
    ``portfolio_analysis.features.downsample``). The ``(ts_utc, timeframe)``
    primary key on ``returns_history`` makes repeated inserts at the same
    boundary idempotent, so we don't need any "did we already insert?"
    bookkeeping in the worker.
    """
    from portfolio_analysis.features.downsample import downsampled_ts_for
    for tf, ret in returns.items():
        if ret is None:
            continue
        bucket_ts = downsampled_ts_for(tf, ts_utc)
        if bucket_ts is None:
            continue  # before this tf's first trigger of the day (24h case)
        try:
            storage.insert_return(ts_utc=bucket_ts, timeframe=tf, return_pct=float(ret))
        except Exception as exc:  # never let one bad row kill the cycle
            log.warning("failed to persist return %s/%s: %s", tf, ret, exc)


def _notify_inserted_alerts(
    inserted_ids: list[int],
    candidates: list[Alert],
    ts_utc: str,
) -> None:
    """Push every newly-inserted alert to the notifier.

    Matches inserted DB rows (we have ids) back to the in-memory ``Alert``
    objects via ``dedup_key`` so the notifier formats from the rich source
    rather than re-parsing ``feature_values`` JSON.
    """
    if not inserted_ids:
        return
    # Build dedup_key → Alert map (a key may appear multiple times in
    # candidates if two rules emit it; insertion path keeps only the first).
    by_key: dict[str, Alert] = {}
    for c in candidates:
        by_key.setdefault(c.dedup_key, c)
    # Look up inserted rows to get their dedup_keys.
    conn = storage.get_conn()
    rows = list(conn.execute(
        f"SELECT id, dedup_key FROM alerts WHERE id IN ({','.join('?'*len(inserted_ids))})",
        tuple(inserted_ids),
    ))
    for row in rows:
        alert = by_key.get(row["dedup_key"])
        if alert is None:
            continue
        try:
            _notifier.notify_alert(alert, ts_utc=ts_utc)
        except Exception:
            log.exception("notify_alert raised for dedup=%s", row["dedup_key"])


def _build_feature_bundle(agg: sqlite3.Row) -> FeatureBundle:
    """Glue agg-metrics + feature modules into a single FeatureBundle."""
    ts = agg["ts_utc"]
    spot = agg["btc_price"]
    market_feats = market.compute(ts)
    pc_feats = price_change.compute(ts)
    pos_feats = positions.compute_position_features(spot=float(spot or 0.0), now_utc=ts)
    return FeatureBundle(
        ts_utc=ts,
        spot=spot,
        delta=agg["delta"],
        gamma=agg["gamma"],
        vega=agg["vega"],
        mm_pct=agg["mm_pct"],
        market=market_feats,
        price_change=pc_feats,
        positions=pos_feats,
    )


# ---------------------------------------------------------------------------
# One cycle (pure & importable for tests)
# ---------------------------------------------------------------------------

def run_once(
    *,
    on_new_alerts: Optional[Callable[[list[int]], None]] = None,
    on_state_change: Optional[Callable[[state.CalmState, str], None]] = None,
) -> Optional[dict]:
    """Run exactly one evaluation cycle. Returns a small summary or None
    if there is no agg-metrics row yet (cold start).

    Hooks are intentionally simple so Phase 7 can wire the notifier in
    without modifying this module.
    """
    cycle_start = time.monotonic()
    storage.init_db()

    agg = _read_latest_agg_metrics()
    if agg is None:
        log.debug("no agg-metrics row yet; skipping cycle")
        return None

    fb = _build_feature_bundle(agg)
    _persist_market_returns(fb.ts_utc, fb.market.returns)
    # price_change returns share the same long-horizon timeframes; persist
    # only the ones not already covered to avoid duplicate writes.
    overlap = set(fb.market.returns.keys())
    pc_only = {tf: r for tf, r in fb.price_change.returns.items() if tf not in overlap}
    _persist_market_returns(fb.ts_utc, pc_only)

    # 1. Evaluate everything → set of currently-active dedup keys.
    candidates = rules.evaluate_all(fb)
    active_keys = {a.dedup_key for a in candidates}

    # 2. Resolve previously-open alerts whose keys are no longer active;
    #    clear matching suppressions.
    resolved_ids, cleared_keys = rules.resolve_cleared(active_keys, ts_utc=fb.ts_utc)
    if resolved_ids:
        log.info("resolved %d alerts: %s", len(resolved_ids), resolved_ids)
    if cleared_keys:
        log.info("cleared %d suppressions: %s", len(cleared_keys), cleared_keys)

    # 3. Insert new alerts (dedup against open + suppressed).
    inserted_ids = rules.dedup_and_persist(candidates, ts_utc=fb.ts_utc)
    if inserted_ids:
        log.info("inserted %d alerts: %s", len(inserted_ids), inserted_ids)

    # 4. Classify Calm Score against the now-current set of unresolved alerts
    #    and persist a state_history row. Wrap sqlite3.Row in a SimpleNamespace
    #    so it satisfies the AlertLike protocol (attribute access).
    active_alerts = storage.unresolved_alerts()
    active_views = [
        SimpleNamespace(
            rule=row["rule"],
            severity=row["severity"],
            dedup_key=row["dedup_key"],
        )
        for row in active_alerts
    ]
    calm, reasoning = state.classify(active_views)
    last = storage.latest_state()
    last_score = last["calm_score"] if last is not None else None
    storage.insert_state(
        ts_utc=fb.ts_utc,
        calm_score=calm.value,
        active_alert_ids=[r["id"] for r in active_alerts],
        reasoning=reasoning,
    )
    if last_score != calm.value:
        log.info("state change: %s → %s - %s", last_score, calm.value, reasoning)
        if on_state_change is not None:
            try:
                on_state_change(calm, reasoning)
            except Exception:
                log.exception("on_state_change hook raised")

    if inserted_ids:
        # Default behaviour: push every newly-inserted alert to the notifier.
        # The hook (if provided) runs alongside, not instead - useful for tests.
        _notify_inserted_alerts(inserted_ids, candidates, fb.ts_utc)
        if on_new_alerts is not None:
            try:
                on_new_alerts(inserted_ids)
            except Exception:
                log.exception("on_new_alerts hook raised")

    elapsed = time.monotonic() - cycle_start
    if elapsed > CYCLE_SLOW_THRESHOLD_S:
        log.warning("slow cycle: %.3fs (target < %.1fs)", elapsed, CYCLE_SLOW_THRESHOLD_S)
    else:
        log.debug("cycle ok in %.3fs", elapsed)

    return {
        "ts_utc": fb.ts_utc,
        "inserted": inserted_ids,
        "resolved": resolved_ids,
        "cleared_suppressions": cleared_keys,
        "calm_score": calm.value,
        "elapsed_s": round(elapsed, 4),
    }


# ---------------------------------------------------------------------------
# Daemon thread
# ---------------------------------------------------------------------------

class AlertWorker:
    """Daemon thread that calls :func:`run_once` every ``interval_s``.

    Mirrors the per-worker pattern of ``realtime/scheduler.py``: a single
    shared ``stop_event`` controls shutdown, exceptions inside a cycle
    are logged and swallowed so one bad row never kills the loop.
    """
    def __init__(
        self,
        *,
        interval_s: float = WORKER_INTERVAL_S,
        stop_event: Optional[threading.Event] = None,
        on_new_alerts: Optional[Callable[[list[int]], None]] = None,
        on_state_change: Optional[Callable[[state.CalmState, str], None]] = None,
    ) -> None:
        self.interval_s = float(interval_s)
        self.stop_event = stop_event or threading.Event()
        self._on_new_alerts = on_new_alerts
        self._on_state_change = on_state_change
        self._thread: Optional[threading.Thread] = None

    def start(self) -> None:
        if self._thread is not None and self._thread.is_alive():
            return
        self._thread = threading.Thread(
            target=self._loop, name="portfolio-analysis-alert", daemon=True,
        )
        self._thread.start()
        log.info("AlertWorker started (interval=%.1fs)", self.interval_s)

    def stop(self, timeout: float = 5.0) -> None:
        self.stop_event.set()
        if self._thread is not None:
            self._thread.join(timeout=timeout)
            log.info("AlertWorker stopped")

    def _loop(self) -> None:
        while not self.stop_event.is_set():
            try:
                run_once(
                    on_new_alerts=self._on_new_alerts,
                    on_state_change=self._on_state_change,
                )
            except Exception:
                log.exception("AlertWorker cycle failed; continuing")
            # Sleep in small chunks so stop_event responsiveness is < 1s.
            slept = 0.0
            while slept < self.interval_s and not self.stop_event.is_set():
                step = min(0.5, self.interval_s - slept)
                time.sleep(step)
                slept += step
