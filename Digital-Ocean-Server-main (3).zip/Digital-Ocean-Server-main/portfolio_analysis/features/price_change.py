"""Price-change features for the quantile-based rule (Rule 5).

Returns over {1h, 4h, 1d, 7d, 15d, 30d} are computed via
``portfolio_analysis.features.btc_returns.compute_return``, which picks
the right data source by horizon:

* 1 h, 4 h                → ``realtime.sqlite::market_ticks``
* 1 d, 7 d, 15 d, 30 d    → ``market_data.sqlite::btc_prices.close``

Quantiles (Q1 / median / Q3) are still computed from
``portfolio_analysis.sqlite::returns_history`` over the last
``config.QUANTILE_LOOKBACK_DAYS`` days.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Optional, Tuple

from portfolio_analysis import config, storage
from portfolio_analysis.features import btc_returns
from portfolio_analysis.features.market import _fmt_iso, _parse_iso  # backwards-compat

__all__ = [
    "PRICE_CHANGE_TIMEFRAMES",
    "PriceChangeFeatures",
    "compute_returns",
    "compute_quantiles",
    "compute",
]

PRICE_CHANGE_TIMEFRAMES: dict[str, int] = {
    "1h":  3600,
    "4h":  4 * 3600,
    "1d":  86400,
    "7d":  7 * 86400,
    "15d": 15 * 86400,
    "30d": 30 * 86400,
}


@dataclass(frozen=True)
class PriceChangeFeatures:
    """Per-timeframe return + (Q1, median, Q3) of the historical buffer."""
    returns:   dict[str, Optional[float]] = field(default_factory=dict)
    quantiles: dict[str, Optional[Tuple[float, float, float]]] = field(default_factory=dict)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def compute_returns(now_utc: str) -> dict[str, Optional[float]]:
    """Realized BTC return (%) over each timeframe in ``PRICE_CHANGE_TIMEFRAMES``.

    Source per horizon (handled inside :mod:`btc_returns`):
      * 1 h, 4 h            → realtime ticks (intraday)
      * 1 d, 7 d, 15 d, 30 d → daily close (``btc_prices``)
    """
    return {
        tf: btc_returns.compute_return(seconds, now_utc=now_utc)
        for tf, seconds in PRICE_CHANGE_TIMEFRAMES.items()
    }


def _percentile(sorted_values: list[float], q: float) -> float:
    """Linear-interpolation percentile, matches numpy default."""
    n = len(sorted_values)
    if n == 1:
        return sorted_values[0]
    pos = q * (n - 1)
    lo = int(pos)
    hi = min(lo + 1, n - 1)
    frac = pos - lo
    return sorted_values[lo] + (sorted_values[hi] - sorted_values[lo]) * frac


def compute_quantiles(timeframe: str) -> Optional[Tuple[float, float, float]]:
    """Return ``(Q1, median, Q3)`` of historical returns for ``timeframe``.

    Uses the trailing ``config.QUANTILE_LOOKBACK_DAYS``-day window. Returns
    ``None`` if fewer than 4 samples (need at least 4 for a meaningful IQR).
    """
    if timeframe not in PRICE_CHANGE_TIMEFRAMES:
        raise ValueError(f"unknown timeframe: {timeframe!r}")

    cutoff_dt = datetime.now(timezone.utc) - timedelta(days=config.QUANTILE_LOOKBACK_DAYS)
    rows = storage.returns_for(timeframe, since_utc=_fmt_iso(cutoff_dt))
    values = sorted(float(r["return_pct"]) for r in rows)
    if len(values) < 4:
        return None
    q1 = _percentile(values, config.QUANTILE_LOW)
    med = _percentile(values, config.QUANTILE_MEDIAN)
    q3 = _percentile(values, config.QUANTILE_HIGH)
    return (q1, med, q3)


def compute(now_utc: str) -> PriceChangeFeatures:
    returns = compute_returns(now_utc)
    quantiles = {tf: compute_quantiles(tf) for tf in PRICE_CHANGE_TIMEFRAMES}
    return PriceChangeFeatures(returns=returns, quantiles=quantiles)
