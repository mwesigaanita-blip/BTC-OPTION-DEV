"""Per-option-position features for Rule 3 (DTE / pin risk).

Reads the latest ``realtime.sqlite::positions_ticks`` row, parses the
Deribit ``private/get_positions`` payload, and returns one
``PositionFeature`` per **option** position. Futures and perpetuals are
skipped (the DTE rule does not apply to them).
"""
from __future__ import annotations

import json
import re
import sqlite3
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Optional

from portfolio_analysis.features.market import _open_realtime_ro, _parse_iso

__all__ = [
    "PositionFeature",
    "compute_position_features",
    "parse_instrument_name",
]


@dataclass(frozen=True)
class PositionFeature:
    instrument_name: str
    strike: float
    expiry_utc: datetime
    dte_days: float
    distance_to_strike_pct: float       # signed: (strike - spot) / spot * 100
    side: str                           # "long" | "short"
    option_type: str                    # "C" | "P"


# ---------------------------------------------------------------------------
# Deribit instrument-name parsing.
# Format: BTC-DDMMMYY-STRIKE-{C,P}     e.g.  BTC-30MAY26-100000-C
# ---------------------------------------------------------------------------

_INSTR_RE = re.compile(
    r"^(?P<asset>[A-Z]+)-(?P<day>\d{1,2})(?P<mon>[A-Z]{3})(?P<yy>\d{2})"
    r"-(?P<strike>\d+(?:\.\d+)?)-(?P<typ>[CP])$"
)
_MONTHS = {
    "JAN": 1, "FEB": 2, "MAR": 3, "APR": 4, "MAY": 5, "JUN": 6,
    "JUL": 7, "AUG": 8, "SEP": 9, "OCT": 10, "NOV": 11, "DEC": 12,
}


def parse_instrument_name(name: str) -> Optional[dict]:
    """Return ``{strike, expiry_utc, option_type}`` or None for non-options."""
    m = _INSTR_RE.match((name or "").upper())
    if not m:
        return None
    mon = _MONTHS.get(m.group("mon"))
    if mon is None:
        return None
    expiry = datetime(
        year=2000 + int(m.group("yy")),
        month=mon,
        day=int(m.group("day")),
        hour=8,  # Deribit options expire at 08:00 UTC
        tzinfo=timezone.utc,
    )
    return {
        "strike": float(m.group("strike")),
        "expiry_utc": expiry,
        "option_type": m.group("typ"),
    }


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def _latest_positions_payload() -> tuple[Optional[str], list[dict]]:
    """Return (ts_utc, positions_list) from the most recent ``positions_ticks``."""
    try:
        conn = _open_realtime_ro()
    except sqlite3.OperationalError:
        return None, []
    try:
        row = conn.execute(
            "SELECT ts_utc, payload_json FROM positions_ticks ORDER BY ts_utc DESC LIMIT 1"
        ).fetchone()
    finally:
        conn.close()
    if row is None:
        return None, []
    try:
        payload = json.loads(row["payload_json"])
    except (TypeError, ValueError):
        return row["ts_utc"], []
    if isinstance(payload, dict):
        payload = payload.get("result", payload.get("positions", []))
    return row["ts_utc"], list(payload or [])


def _side(p: dict) -> str:
    """Map Deribit 'direction'/'size' to long/short."""
    direction = (p.get("direction") or "").lower()
    if direction in ("buy", "long"):
        return "long"
    if direction in ("sell", "short"):
        return "short"
    size = p.get("size") or p.get("net_size")
    try:
        return "long" if float(size) >= 0 else "short"
    except (TypeError, ValueError):
        return "long"


def compute_position_features(
    spot: float,
    *,
    now_utc: Optional[str] = None,
) -> list[PositionFeature]:
    """One ``PositionFeature`` per option in the latest positions tick.

    Non-option positions (futures, perpetuals) are skipped - they don't
    have DTE / strike to reason about.
    """
    if spot <= 0:
        return []
    now_dt = _parse_iso(now_utc) if now_utc else datetime.now(timezone.utc)

    _ts, positions = _latest_positions_payload()
    out: list[PositionFeature] = []
    for p in positions:
        name = p.get("instrument_name") or ""

        # Strike + expiry: prefer explicit fields, fall back to instrument-name parsing.
        strike = p.get("strike")
        option_type = (p.get("option_type") or "").upper() or None
        expiry_ts_ms = p.get("expiration_timestamp")
        expiry_utc: Optional[datetime] = None
        if expiry_ts_ms is not None:
            try:
                expiry_utc = datetime.fromtimestamp(int(expiry_ts_ms) / 1000.0, tz=timezone.utc)
            except (TypeError, ValueError, OSError):
                expiry_utc = None

        if strike is None or expiry_utc is None or option_type not in ("C", "P"):
            parsed = parse_instrument_name(name)
            if parsed is None:
                continue  # not an option (e.g., BTC-PERPETUAL)
            strike = strike if strike is not None else parsed["strike"]
            expiry_utc = expiry_utc or parsed["expiry_utc"]
            option_type = option_type or parsed["option_type"]

        try:
            strike_f = float(strike)
        except (TypeError, ValueError):
            continue

        dte_days = (expiry_utc - now_dt).total_seconds() / 86400.0
        distance_pct = (strike_f - spot) / spot * 100.0

        out.append(PositionFeature(
            instrument_name=name,
            strike=strike_f,
            expiry_utc=expiry_utc,
            dte_days=dte_days,
            distance_to_strike_pct=distance_pct,
            side=_side(p),
            option_type=option_type,
        ))
    return out
