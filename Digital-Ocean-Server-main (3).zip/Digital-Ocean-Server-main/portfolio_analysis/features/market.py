"""Market features for the σ-based volatility rule (Rule 4).

Returns over {1h, 4h, 24h} are computed via
``portfolio_analysis.features.btc_returns.compute_return``, which picks
the right data source by horizon:

* 1 h, 4 h  → ``realtime.sqlite::market_ticks`` (60-second-ish ticks)
* 24 h      → ``market_data.sqlite::btc_prices.close`` (daily close)

σ is still computed from the rolling buffer in
``portfolio_analysis.sqlite::returns_history`` over the last
``config.SIGMA_LOOKBACK_DAYS``.
"""
from __future__ import annotations

import math
import sqlite3
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Optional

from portfolio_analysis import config, storage
from portfolio_analysis.features import btc_returns
from shared.db_paths import REALTIME_DB

__all__ = [
    "MARKET_TIMEFRAMES",
    "MarketFeatures",
    "compute_returns",
    "compute_sigma",
]

# Timeframe → seconds. These are the σ-rule horizons (Rule 4).
MARKET_TIMEFRAMES: dict[str, int] = {
    "1h":  3600,
    "4h":  4 * 3600,
    "24h": 24 * 3600,
}


@dataclass(frozen=True)
class MarketFeatures:
    """Per-timeframe return + live σ estimate."""
    returns: dict[str, Optional[float]] = field(default_factory=dict)
    sigmas:  dict[str, Optional[float]] = field(default_factory=dict)


# ---------------------------------------------------------------------------
# Date helpers
# ---------------------------------------------------------------------------

_ISO_FMT = "%Y-%m-%dT%H:%M:%S.%fZ"


def _parse_iso(s: str) -> datetime:
    """Parse a UTC ISO string written by ``utc_now_iso`` (microsecond + 'Z')."""
    if s.endswith("Z"):
        s = s[:-1]
    if "." not in s:
        s += ".000000"
    return datetime.fromisoformat(s).replace(tzinfo=timezone.utc)


def _fmt_iso(dt: datetime) -> str:
    return dt.astimezone(timezone.utc).strftime(_ISO_FMT)


# ---------------------------------------------------------------------------
# Connection to the realtime DB (read-only). We do not import realtime.storage
# directly because it owns its own thread-local connection - opening our own
# read-only conn keeps the dependency one-way.
# ---------------------------------------------------------------------------

def _open_realtime_ro() -> sqlite3.Connection:
    conn = sqlite3.connect(f"file:{REALTIME_DB}?mode=ro", uri=True, timeout=2.0)
    conn.row_factory = sqlite3.Row
    return conn


def _btc_price_at(conn: sqlite3.Connection, target_iso: str) -> Optional[float]:
    """Most recent ``btc_price`` with ``ts_utc <= target_iso``, or None."""
    row = conn.execute(
        "SELECT btc_price FROM market_ticks WHERE ts_utc <= ? ORDER BY ts_utc DESC LIMIT 1",
        (target_iso,),
    ).fetchone()
    return float(row["btc_price"]) if row is not None else None


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def compute_returns(now_utc: str) -> dict[str, Optional[float]]:
    """Realized BTC return (%) over each timeframe in ``MARKET_TIMEFRAMES``.

    Source per horizon (handled inside :mod:`btc_returns`):
      * < 24 h → realtime ticks
      * ≥ 24 h → daily close-to-close

    Returns ``None`` for any timeframe where the chosen source has no
    suitable past price.
    """
    return {
        tf: btc_returns.compute_return(seconds, now_utc=now_utc)
        for tf, seconds in MARKET_TIMEFRAMES.items()
    }


def sigma_lookback_hours(timeframe: str) -> int:
    """Number of hours of history used to compute σ for ``timeframe``.

    Short timeframes (``1h``, ``4h``) only look at the last 48 hours - the
    same window the realtime DB holds - so the σ benchmark is consistent
    with the source of the *current* return. The 24h timeframe still
    keeps a long-term context (90 days).
    """
    return config.SIGMA_LOOKBACK_HOURS_PER_TF.get(
        timeframe, config.SIGMA_LOOKBACK_DAYS * 24,
    )


def compute_sigma(
    timeframe: str,
    *,
    now_utc: Optional[str] = None,
) -> Optional[float]:
    """Rolling σ of returns at ``timeframe`` over a horizon-aware window.

    ``now_utc`` is the reference "now" - defaults to wall-clock time. Tests
    that seed historical rows can pass a fixed reference so the lookback
    window covers their seeds.

    Returns ``None`` if fewer than 2 samples are available.
    """
    if timeframe not in MARKET_TIMEFRAMES:
        raise ValueError(f"unknown timeframe: {timeframe!r}")

    if now_utc is not None:
        ref_dt = _parse_iso(now_utc)
    else:
        ref_dt = datetime.now(timezone.utc)
    hours = sigma_lookback_hours(timeframe)
    cutoff_dt = ref_dt - timedelta(hours=hours)
    rows = storage.returns_for(timeframe, since_utc=_fmt_iso(cutoff_dt))
    values = [float(r["return_pct"]) for r in rows]
    if len(values) < 2:
        return None
    mean = sum(values) / len(values)
    var = sum((v - mean) ** 2 for v in values) / (len(values) - 1)  # sample stddev
    raw = math.sqrt(var)
    # Floor σ so dead-calm markets don't produce inflated z-scores
    # (and false "extreme" alerts).
    return max(raw, float(config.SIGMA_FLOOR_PCT))


def compute(now_utc: str) -> MarketFeatures:
    """Bundle of returns + σ for every timeframe."""
    returns = compute_returns(now_utc)
    sigmas = {tf: compute_sigma(tf, now_utc=now_utc) for tf in MARKET_TIMEFRAMES}
    return MarketFeatures(returns=returns, sigmas=sigmas)
