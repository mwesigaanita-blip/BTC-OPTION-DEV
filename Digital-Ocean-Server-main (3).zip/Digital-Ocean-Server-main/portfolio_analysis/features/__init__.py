"""Feature derivation for the portfolio_analysis rules engine."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

from portfolio_analysis.features.market import MarketFeatures
from portfolio_analysis.features.positions import PositionFeature
from portfolio_analysis.features.price_change import PriceChangeFeatures

__all__ = [
    "FeatureBundle",
    "MarketFeatures",
    "PositionFeature",
    "PriceChangeFeatures",
]


@dataclass(frozen=True)
class FeatureBundle:
    """All features needed by the rules engine for one evaluation cycle."""
    ts_utc: str
    spot: Optional[float]
    delta: Optional[float]
    gamma: Optional[float]
    vega: Optional[float]
    mm_pct: Optional[float]
    market: MarketFeatures
    price_change: PriceChangeFeatures
    positions: list[PositionFeature] = field(default_factory=list)
