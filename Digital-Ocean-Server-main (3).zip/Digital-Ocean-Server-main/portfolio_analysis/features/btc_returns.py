"""Single source of truth for BTC return calculations.

The data source depends on the horizon:

* **Short-term** (< 24 h) → ``realtime.sqlite::market_ticks``
  The realtime poller writes a ``btc_price`` tick every few seconds and
  keeps only the last ~48 h. Perfect for 1 h / 4 h returns.

* **Long-term** (≥ 24 h) → ``market_data.sqlite::btc_prices``
  Daily-resolution OHLCV table going back ~15 years. Used for 1 d, 7 d,
  15 d, 30 d (and any other ≥ 24 h horizon).

For BOTH paths the *current* price comes from the latest realtime tick
when one is available - that gives "right now vs N days ago" rather
than "yesterday's close vs N+1 days ago". If realtime has nothing yet
(a fresh install) we fall back to the latest daily close.

Edge cases handled:

* Missing realtime DB (file or table) → returns ``None`` for short-term.
* Missing daily DB → returns ``None`` for long-term.
* Sparse daily data with gaps → uses the most recent close at-or-before
  the target date. The actual return therefore covers *at least* the
  requested horizon (often slightly more on weekends / holidays). This
  is documented and unavoidable: the alternative would be to silently
  fail in any window that lands on a missing day.
* No history deep enough → returns ``None``.
* Past price is zero or negative (impossible in practice but defensive)
  → returns ``None``.
"""
from __future__ import annotations

import sqlite3
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Optional

from shared.db_paths import MARKET_DATA_DB, REALTIME_DB

__all__ = [
    "LONG_TERM_THRESHOLD_S",
    "intraday_price_at",
    "daily_close_at_or_before",
    "current_price",
    "compute_return",
    "is_long_term",
]

# Returns over horizons strictly shorter than this come from realtime ticks;
# anything ≥ this comes from the daily-close table.
LONG_TERM_THRESHOLD_S = 24 * 3600   # 86_400


# ---------------------------------------------------------------------------
# Time helpers
# ---------------------------------------------------------------------------

_ISO_FMT = "%Y-%m-%dT%H:%M:%S.%fZ"


def _parse_iso(s: str) -> datetime:
    """Parse a UTC ISO string written by ``utc_now_iso`` (microsecond + 'Z')."""
    if s.endswith("Z"):
        s = s[:-1]
    if "." not in s:
        s += ".000000"
    dt = datetime.fromisoformat(s)
    return dt.replace(tzinfo=timezone.utc) if dt.tzinfo is None else dt.astimezone(timezone.utc)


def _fmt_iso(dt: datetime) -> str:
    return dt.astimezone(timezone.utc).strftime(_ISO_FMT)


def _resolve_now(now_utc: Optional[str | datetime]) -> datetime:
    if now_utc is None:
        return datetime.now(timezone.utc)
    if isinstance(now_utc, datetime):
        return now_utc.astimezone(timezone.utc) if now_utc.tzinfo else now_utc.replace(tzinfo=timezone.utc)
    return _parse_iso(now_utc)


# ---------------------------------------------------------------------------
# Connection helpers (read-only, short-lived - fine for the rules cadence)
# ---------------------------------------------------------------------------

def _open_ro(path: Path) -> Optional[sqlite3.Connection]:
    try:
        conn = sqlite3.connect(f"file:{path}?mode=ro", uri=True, timeout=2.0)
    except sqlite3.OperationalError:
        return None
    conn.row_factory = sqlite3.Row
    return conn


# ---------------------------------------------------------------------------
# Short-term: intraday from realtime.sqlite
# ---------------------------------------------------------------------------

def intraday_price_at(target_iso: str) -> Optional[float]:
    """Most recent realtime ``btc_price`` with ``ts_utc <= target_iso``.

    Returns ``None`` when the realtime DB is missing, the table is empty,
    or no tick exists at-or-before ``target_iso``.
    """
    conn = _open_ro(REALTIME_DB)
    if conn is None:
        return None
    try:
        row = conn.execute(
            "SELECT btc_price FROM market_ticks WHERE ts_utc <= ? "
            "ORDER BY ts_utc DESC LIMIT 1",
            (target_iso,),
        ).fetchone()
        return float(row["btc_price"]) if row is not None else None
    except sqlite3.OperationalError:
        return None
    finally:
        conn.close()


def _latest_intraday_price() -> Optional[float]:
    conn = _open_ro(REALTIME_DB)
    if conn is None:
        return None
    try:
        row = conn.execute(
            "SELECT btc_price FROM market_ticks ORDER BY ts_utc DESC LIMIT 1"
        ).fetchone()
        return float(row["btc_price"]) if row is not None else None
    except sqlite3.OperationalError:
        return None
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Long-term: daily close from market_data.sqlite
# ---------------------------------------------------------------------------

def daily_close_at_or_before(target_date: str) -> Optional[float]:
    """Most recent ``close`` in ``btc_prices`` with ``date <= target_date``
    (date format ``YYYY-MM-DD``). Returns ``None`` if nothing matches.

    "At-or-before" tolerates the gaps in the daily series (the live table
    has missing days). Callers that need strictly-equal lookups should
    handle that themselves; nobody currently does.
    """
    conn = _open_ro(MARKET_DATA_DB)
    if conn is None:
        return None
    try:
        row = conn.execute(
            "SELECT close FROM btc_prices WHERE date <= ? "
            "ORDER BY date DESC LIMIT 1",
            (target_date,),
        ).fetchone()
        return float(row["close"]) if row is not None and row["close"] is not None else None
    except sqlite3.OperationalError:
        return None
    finally:
        conn.close()


def _latest_daily_close() -> Optional[float]:
    conn = _open_ro(MARKET_DATA_DB)
    if conn is None:
        return None
    try:
        row = conn.execute(
            "SELECT close FROM btc_prices ORDER BY date DESC LIMIT 1"
        ).fetchone()
        return float(row["close"]) if row is not None and row["close"] is not None else None
    except sqlite3.OperationalError:
        return None
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Current price (used as the "now" leg of every return calculation)
# ---------------------------------------------------------------------------

def current_price() -> Optional[float]:
    """Latest BTC price - realtime tick if available, else latest daily close."""
    p = _latest_intraday_price()
    return p if p is not None else _latest_daily_close()


# ---------------------------------------------------------------------------
# Source classification + return computation
# ---------------------------------------------------------------------------

def is_long_term(timeframe_seconds: int) -> bool:
    """True if the horizon is ``>= 24 h`` (i.e. should read the daily table)."""
    return int(timeframe_seconds) >= LONG_TERM_THRESHOLD_S


def compute_return(
    timeframe_seconds: int,
    *,
    now_utc: Optional[str | datetime] = None,
) -> Optional[float]:
    """Percent return of BTC over the given horizon.

    Picks the data source automatically:
      * short-term → realtime tick at ``now - timeframe``
      * long-term  → daily close at-or-before ``(now - timeframe).date()``

    Returns ``None`` if either leg is missing.
    """
    if timeframe_seconds <= 0:
        raise ValueError("timeframe_seconds must be positive")

    now_dt = _resolve_now(now_utc)
    current = current_price()
    if current is None:
        return None

    target_dt = now_dt - timedelta(seconds=int(timeframe_seconds))
    if is_long_term(timeframe_seconds):
        past = daily_close_at_or_before(target_dt.strftime("%Y-%m-%d"))
    else:
        past = intraday_price_at(_fmt_iso(target_dt))

    if past is None or past <= 0:
        return None
    return (current - past) / past * 100.0
