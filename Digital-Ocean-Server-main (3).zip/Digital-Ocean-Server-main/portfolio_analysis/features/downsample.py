"""Downsampling rules for ``returns_history`` writes.

Why this exists
---------------
The AlertWorker computes returns every ~30 seconds. Storing all of those
into ``returns_history`` produces highly overlapping samples - adjacent
rows for the 1h timeframe differ only by 30 seconds of price drift, so
they're almost identical. That artificially shrinks σ (the rolling
standard deviation) and produces false "extreme" alerts.

The fix is to insert into ``returns_history`` only at fixed UTC-anchored
boundaries:

* 1h timeframe                  → every 5 minutes  (UTC minute 0, 5, 10, …, 55)
* 4h timeframe                  → every 10 minutes (UTC minute 0, 10, 20, …, 50)
* 24h, 1d, 7d, 15d, 30d         → once per day at the configured daily-close
                                  trigger (default 00:05 UTC)

Why daily for the long horizons: a 7-day or 30-day return changes only
marginally over 30 seconds, so storing every cycle produces a buffer
densely clustered around the current value. The IQR over the lookback
window then collapses to a few basis points and Rule 5 (PRICE_QUANTILE)
fires every cycle as natural price noise flaps the return in and out
of the artificially narrow band.

Implementation: round the candidate ``ts_utc`` *down* to the boundary,
then rely on the ``(ts_utc, timeframe)`` UNIQUE primary key on
``returns_history`` to suppress duplicate writes. Subsequent inserts
within the same boundary become a no-op via INSERT OR REPLACE.
"""
from __future__ import annotations

from datetime import datetime, timezone
from typing import Optional

from portfolio_analysis import config
from portfolio_analysis.features.market import _fmt_iso, _parse_iso

__all__ = [
    "DOWNSAMPLE_MINUTES",
    "DAILY_TIMEFRAMES",
    "downsampled_ts_for",
]


# Minute boundaries per timeframe. Anything not listed here either falls
# under DAILY_TIMEFRAMES (once-per-day at the daily trigger) or passes
# through at the raw cycle ts_utc.
DOWNSAMPLE_MINUTES: dict[str, int] = {
    "1h":  5,
    "4h":  10,
}

# Timeframes downsampled to one row per day at REPORT_DAILY_UTC_HOUR:MINUTE.
DAILY_TIMEFRAMES: frozenset[str] = frozenset({"24h", "1d", "7d", "15d", "30d"})


def _round_down_to_minute_multiple(dt: datetime, mod_minutes: int) -> datetime:
    """Round ``dt`` down to the nearest ``mod_minutes``-minute UTC boundary."""
    minute_floor = (dt.minute // mod_minutes) * mod_minutes
    return dt.replace(minute=minute_floor, second=0, microsecond=0)


def _todays_daily_close(dt: datetime) -> datetime:
    """The configured daily-close trigger (UTC) for ``dt``'s calendar day."""
    return dt.replace(
        hour=int(config.REPORT_DAILY_UTC_HOUR),
        minute=int(config.REPORT_DAILY_UTC_MINUTE),
        second=0, microsecond=0,
    )


def downsampled_ts_for(timeframe: str, ts_utc: str) -> Optional[str]:
    """Return the boundary-rounded ``ts_utc`` to insert at for ``timeframe``,
    or ``None`` if this tick should be skipped entirely.

    For UTC-anchored downsampling we round DOWN to the boundary and rely
    on the ``(ts_utc, timeframe)`` PK on ``returns_history`` to make
    repeated inserts at the same boundary idempotent.

    The 24h timeframe is special: it stores exactly one row per day, at
    the same UTC time that the daily PDF runs. Any tick before today's
    trigger time is skipped (``None``); ticks at-or-after collapse to
    today's trigger timestamp.
    """
    dt = _parse_iso(ts_utc)
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)

    # 1h, 4h: minute-aligned downsampling.
    mod = DOWNSAMPLE_MINUTES.get(timeframe)
    if mod is not None:
        return _fmt_iso(_round_down_to_minute_multiple(dt, mod))

    # 24h and the daily-or-longer horizons: once per day at the configured
    # trigger. A 7d/15d/30d return changes only marginally tick-to-tick, so
    # one sample/day is sufficient for quantile estimation and avoids the
    # IQR-collapse failure mode described in the module docstring.
    if timeframe in DAILY_TIMEFRAMES:
        trigger = _todays_daily_close(dt)
        if dt < trigger:
            return None  # before today's trigger - wait
        return _fmt_iso(trigger)

    # Anything else passes through unchanged.
    return ts_utc
