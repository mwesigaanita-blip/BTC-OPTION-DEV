"""Combined-signal classifier - STRONG / MEDIUM / WEAK / NORMAL.

Replaces the previous "two independent alerts per move" behaviour
(VOL_SIGMA + PRICE_QUANTILE on the same horizon would each fire in
parallel) with a single combined classification per timeframe.

Inputs
------
* ``z_score`` - current_return / σ from the σ-rule.
* ``iqr_position`` - ``"normal"``, ``"low"``, or ``"high"`` from the
  IQR-rule.

Logic
-----
* ``|z| > 2`` AND outside IQR  → ``STRONG``
* ``|z| > 2``                  → ``MEDIUM``
* outside IQR only             → ``WEAK``
* otherwise                    → ``NORMAL``
"""
from __future__ import annotations

from typing import Literal, TypedDict


__all__ = [
    "Z_THRESHOLD",
    "IqrPosition",
    "CombinedLevel",
    "CombinedSignal",
    "classify_combined_signal",
    "severity_for_level",
]

# Z-score above which σ alone counts as "big". Mirrors the existing
# critical-band multiplier in :mod:`portfolio_analysis.config`
# (SIGMA_CRITICAL_MULT = 2.0).
Z_THRESHOLD: float = 2.0

IqrPosition = Literal["normal", "low", "high"]
CombinedLevel = Literal["NORMAL", "WEAK", "MEDIUM", "STRONG"]


class CombinedSignal(TypedDict):
    level: CombinedLevel
    z_score: float
    iqr: IqrPosition


# Severity mapping: how the combined level becomes an alert severity.
_LEVEL_TO_SEVERITY: dict[CombinedLevel, str] = {
    "STRONG": "URGENT",
    "MEDIUM": "WARNING",
    "WEAK":   "INFO",
    "NORMAL": "",   # no alert
}


def severity_for_level(level: CombinedLevel) -> str:
    """Map a combined level to the alert severity used by the notifier."""
    return _LEVEL_TO_SEVERITY[level]


def classify_combined_signal(
    z_score: float,
    iqr_position: IqrPosition,
) -> CombinedSignal:
    """Classify a (z_score, iqr_position) pair into the combined level.

    See module docstring for the truth table.
    """
    if iqr_position not in ("normal", "low", "high"):
        raise ValueError(f"invalid iqr_position: {iqr_position!r}")

    big_sigma = abs(float(z_score)) > Z_THRESHOLD
    outside_iqr = iqr_position != "normal"

    if big_sigma and outside_iqr:
        level: CombinedLevel = "STRONG"
    elif big_sigma:
        level = "MEDIUM"
    elif outside_iqr:
        level = "WEAK"
    else:
        level = "NORMAL"

    return {
        "level": level,
        "z_score": float(z_score),
        "iqr": iqr_position,
    }
