"""Process supervisor - owns AlertWorker, HeartbeatWorker, DailyReportWorker.

Run with: ``python -m portfolio_analysis.scheduler``

Mirrors the daemon-thread + shared-stop-event pattern of
``realtime/scheduler.py``. Each child worker owns its own loop and
swallows per-cycle exceptions; the scheduler is purely a lifecycle
manager.

The Telegram bot (``portfolio_analysis.bot.server``) is intentionally
NOT started by this scheduler - it lives in its own process so the bot
can restart without disturbing alerting, and vice versa.

CLI:
    python -m portfolio_analysis.scheduler            # run forever
    python -m portfolio_analysis.scheduler --health   # 12s smoke test, exit 0
"""
from __future__ import annotations

import argparse
import json
import signal
import threading
import time
from typing import Optional

from portfolio_analysis import storage
from portfolio_analysis.heartbeat import HeartbeatWorker, TICK_INTERVAL_S as HB_TICK_S
from portfolio_analysis.report_daily import DailyReportWorker, TICK_INTERVAL_S as RPT_TICK_S
from portfolio_analysis.vol_worker import VolTickWorker, TICK_INTERVAL_S as VOL_TICK_S
from portfolio_analysis.worker import AlertWorker, WORKER_INTERVAL_S
from realtime._logging import get_logger

__all__ = ["PortfolioScheduler", "main"]

log = get_logger("portfolio_analysis.scheduler")


class PortfolioScheduler:
    """Owns the lifecycle of all three portfolio_analysis workers."""

    def __init__(
        self,
        *,
        alert_interval_s: float = WORKER_INTERVAL_S,
        heartbeat_interval_s: float = HB_TICK_S,
        report_interval_s: float = RPT_TICK_S,
        vol_interval_s: float = VOL_TICK_S,
    ) -> None:
        self._stop = threading.Event()
        self._started_at: Optional[float] = None

        # Each worker shares the same stop_event so a single set() halts everything.
        self.alert = AlertWorker(
            interval_s=alert_interval_s, stop_event=self._stop,
        )
        self.heartbeat = HeartbeatWorker(
            interval_s=heartbeat_interval_s, stop_event=self._stop,
        )
        self.report = DailyReportWorker(
            interval_s=report_interval_s, stop_event=self._stop,
        )
        self.vol = VolTickWorker(
            interval_s=vol_interval_s, stop_event=self._stop,
        )

    # ------------------------------------------------------------------
    # Public lifecycle
    # ------------------------------------------------------------------

    def start(self) -> None:
        if self._started_at is not None:
            raise RuntimeError("scheduler already started")
        self._started_at = time.time()
        self._stop.clear()
        # Make sure the schema exists once before any worker writes.
        storage.init_db()
        self.alert.start()
        self.heartbeat.start()
        self.report.start()
        self.vol.start()
        log.info("PortfolioScheduler started (alert+heartbeat+report+vol)")

    def stop(self, timeout_s: float = 10.0) -> None:
        if self._started_at is None:
            return
        log.info("PortfolioScheduler stopping...")
        self._stop.set()
        # Each child also accepts the shared stop, but join individually so a
        # slow worker doesn't block faster ones from being noted as exited.
        deadline = time.time() + float(timeout_s)
        for w, name in (
            (self.alert,     "alert"),
            (self.heartbeat, "heartbeat"),
            (self.report,    "report"),
            (self.vol,       "vol"),
        ):
            remaining = max(0.0, deadline - time.time())
            w.stop(timeout=remaining)
        self._started_at = None
        log.info("PortfolioScheduler stopped")

    def health_check(self) -> dict:
        uptime = time.time() - self._started_at if self._started_at else 0.0
        workers = {
            "alert":     getattr(self.alert._thread,     "is_alive", lambda: False)(),
            "heartbeat": getattr(self.heartbeat._thread, "is_alive", lambda: False)(),
            "report":    getattr(self.report._thread,    "is_alive", lambda: False)(),
            "vol":       getattr(self.vol._thread,       "is_alive", lambda: False)(),
        }
        last_state = storage.latest_state()
        last_run = storage.latest_report_run()
        return {
            "uptime_s": round(uptime, 1),
            "stopped": self._stop.is_set(),
            "workers": workers,
            "calm_score": last_state["calm_score"] if last_state else None,
            "last_state_ts": last_state["ts_utc"] if last_state else None,
            "active_alerts": len(storage.unresolved_alerts()),
            "active_suppressions": len(storage.active_suppressions()),
            "last_report_ts": last_run["ts_utc"] if last_run else None,
        }

    # Convenience - used by ``--health`` and by ``main()`` when no flags.
    def run_blocking(self) -> None:
        self.start()
        try:
            signal.signal(signal.SIGINT, lambda *_: self._stop.set())
            try:
                signal.signal(signal.SIGTERM, lambda *_: self._stop.set())
            except (AttributeError, ValueError):
                pass  # SIGTERM unavailable / not in main thread
            while not self._stop.is_set():
                if self._stop.wait(timeout=1.0):
                    break
        except KeyboardInterrupt:
            pass
        finally:
            self.stop()


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main(argv: Optional[list[str]] = None) -> int:
    p = argparse.ArgumentParser(prog="portfolio_analysis.scheduler")
    p.add_argument("--alert-interval", type=float, default=WORKER_INTERVAL_S,
                   help="AlertWorker cycle interval (s)")
    p.add_argument("--heartbeat-interval", type=float, default=HB_TICK_S,
                   help="HeartbeatWorker tick interval (s)")
    p.add_argument("--report-interval", type=float, default=RPT_TICK_S,
                   help="DailyReportWorker tick interval (s)")
    p.add_argument("--vol-interval", type=float, default=VOL_TICK_S,
                   help="VolTickWorker HV/IV recording interval (s)")
    p.add_argument("--health", action="store_true",
                   help="Run the full stack 12s, print health JSON, exit 0")
    args = p.parse_args(argv)

    sched = PortfolioScheduler(
        alert_interval_s=args.alert_interval,
        heartbeat_interval_s=args.heartbeat_interval,
        report_interval_s=args.report_interval,
        vol_interval_s=args.vol_interval,
    )
    if args.health:
        sched.start()
        time.sleep(12)
        print(json.dumps(sched.health_check(), indent=2))
        sched.stop()
        return 0

    sched.run_blocking()
    return 0


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
