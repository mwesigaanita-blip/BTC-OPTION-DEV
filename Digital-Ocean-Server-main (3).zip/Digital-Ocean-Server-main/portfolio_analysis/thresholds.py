"""Dynamic threshold resolver.

Single source of truth for every numeric threshold. At runtime, every
rule / classifier / heartbeat reads its value here - never directly from
``config.py``. The resolver returns the latest active override (if any)
or falls back to the default in ``portfolio_analysis.config``.

Overrides expire silently: once ``expires_at_utc`` has passed, the next
``get()`` returns the default again - no broadcast, no audit, by spec.

The broadcast that fires on a NEW override (Section 8 of plan.md) is
wired in Phase 8 once the bot exists. Until then ``set_override`` only
writes to the DB and audit log.
"""
from __future__ import annotations

import re
import threading
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Any, Optional

from portfolio_analysis import config, storage

__all__ = [
    "UnknownThreshold",
    "InvalidDuration",
    "parse_duration",
    "get",
    "set_override",
    "list_active",
    "invalidate_cache",
]


# ---------------------------------------------------------------------------
# Errors
# ---------------------------------------------------------------------------

class UnknownThreshold(KeyError):
    """Raised when a name is not in ``config.DEFAULT_THRESHOLDS``."""


class InvalidDuration(ValueError):
    """Raised when ``parse_duration`` cannot parse the input."""


# ---------------------------------------------------------------------------
# Duration parsing
# ---------------------------------------------------------------------------

_DURATION_RE = re.compile(r"^\s*(\d+)\s*([smhd])\s*$", re.IGNORECASE)
_UNIT_S = {"s": 1, "m": 60, "h": 3600, "d": 86400}


def _format_duration(seconds: int) -> str:
    """Render a seconds count as the most natural unit (e.g. ``7d``, ``4h``)."""
    s = int(seconds)
    if s % 86400 == 0:
        return f"{s // 86400}d"
    if s % 3600 == 0:
        return f"{s // 3600}h"
    if s % 60 == 0:
        return f"{s // 60}m"
    return f"{s}s"


def parse_duration(s: str) -> int:
    """Parse ``"30m"``, ``"4h"``, ``"7d"``, ``"45s"`` → seconds.

    Raises :class:`InvalidDuration` on malformed input.
    """
    if not isinstance(s, str):
        raise InvalidDuration(f"duration must be a string, got {type(s).__name__}")
    m = _DURATION_RE.match(s)
    if not m:
        raise InvalidDuration(f"invalid duration: {s!r} (expected e.g. '30m', '4h', '7d')")
    n = int(m.group(1))
    if n <= 0:
        raise InvalidDuration(f"duration must be positive: {s!r}")
    return n * _UNIT_S[m.group(2).lower()]


# ---------------------------------------------------------------------------
# In-process cache
# ---------------------------------------------------------------------------

# {name: (value, cached_at_monotonic)}; lock guards both the dict and the
# global "everything is stale" generation counter.
_cache: dict[str, tuple[float | int, float]] = {}
_cache_lock = threading.Lock()
_CACHE_TTL_S = 60.0


def _now_monotonic() -> float:
    # Indirection so tests can monkeypatch.
    import time
    return time.monotonic()


def invalidate_cache() -> None:
    """Drop all cached values. Called after every override write."""
    with _cache_lock:
        _cache.clear()


# ---------------------------------------------------------------------------
# Core API
# ---------------------------------------------------------------------------

def _ensure_known(name: str) -> None:
    if name not in config.DEFAULT_THRESHOLDS:
        raise UnknownThreshold(name)


def _resolve_uncached(name: str) -> float | int:
    """Read storage; return active override value or default."""
    row = storage.active_overrides_for(name)
    if row is not None:
        raw = row["value"]
        default = config.DEFAULT_THRESHOLDS[name]
        # Preserve int-ness when the default is an int (e.g., DTE_WARN_DAYS).
        return int(raw) if isinstance(default, int) and not isinstance(default, bool) else float(raw)
    return config.DEFAULT_THRESHOLDS[name]


def get(name: str) -> float | int:
    """Active override value if present and non-expired, else the default.

    Raises :class:`UnknownThreshold` if ``name`` is not in the master list.
    """
    _ensure_known(name)
    now = _now_monotonic()
    with _cache_lock:
        cached = _cache.get(name)
        if cached is not None and (now - cached[1]) < _CACHE_TTL_S:
            return cached[0]
    value = _resolve_uncached(name)
    with _cache_lock:
        _cache[name] = (value, now)
    return value


def set_override(
    *,
    name: str,
    value: float | int,
    duration_s: int,
    user_id: int,
    user_name: str,
) -> dict[str, Any]:
    """Record a new override and append to audit_log. Cache is invalidated.

    Returns a dict suitable for broadcasting / logging:
    ``{name, value, duration_s, expires_at_utc, set_by}``.

    NOTE: the Telegram broadcast itself is wired in Phase 8.
    """
    _ensure_known(name)
    if duration_s <= 0:
        raise InvalidDuration("duration_s must be positive")

    set_at = datetime.now(timezone.utc)
    expires_at = set_at + timedelta(seconds=int(duration_s))
    set_at_iso = set_at.strftime("%Y-%m-%dT%H:%M:%S.%f") + "Z"
    expires_iso = expires_at.strftime("%Y-%m-%dT%H:%M:%S.%f") + "Z"

    storage.insert_override(
        name=name,
        value=float(value),
        set_by_user_id=int(user_id),
        set_by_user_name=user_name,
        set_at_utc=set_at_iso,
        expires_at_utc=expires_iso,
    )
    storage.insert_audit(
        user_id=int(user_id),
        user_name=user_name,
        action="set_threshold",
        payload={
            "name": name,
            "value": float(value),
            "duration_s": int(duration_s),
            "expires_at_utc": expires_iso,
        },
        ts_utc=set_at_iso,
    )
    invalidate_cache()
    # Broadcast the change so every chat sees who did what.
    try:
        from portfolio_analysis.bot.broadcast import broadcast
        from portfolio_analysis.thresholds import _format_duration  # local helper
        broadcast(
            f"User {user_name} changed {name} to {value} for "
            f"{_format_duration(int(duration_s))}"
        )
    except Exception:
        # Bot import / network failures must not block the override write.
        import logging
        logging.getLogger("portfolio_analysis.thresholds").exception(
            "broadcast for set_override failed (override still applied)"
        )
    return {
        "name": name,
        "value": float(value),
        "duration_s": int(duration_s),
        "expires_at_utc": expires_iso,
        "set_by": {"user_id": int(user_id), "user_name": user_name},
    }


@dataclass(frozen=True)
class ThresholdView:
    name: str
    default: float | int
    current: float | int
    overridden: bool
    expires_at_utc: Optional[str]
    set_by_user_name: Optional[str]


def list_active() -> list[dict[str, Any]]:
    """Snapshot of every threshold with its current effective value.

    Returned as a list of plain dicts in the order of
    ``config.DEFAULT_THRESHOLDS``. Used by the ``/thresholds`` command.
    """
    out: list[dict[str, Any]] = []
    for name, default in config.DEFAULT_THRESHOLDS.items():
        row = storage.active_overrides_for(name)
        if row is not None:
            current: float | int = (
                int(row["value"])
                if isinstance(default, int) and not isinstance(default, bool)
                else float(row["value"])
            )
            out.append({
                "name": name,
                "default": default,
                "current": current,
                "overridden": True,
                "expires_at_utc": row["expires_at_utc"],
                "set_by_user_name": row["set_by_user_name"],
            })
        else:
            out.append({
                "name": name,
                "default": default,
                "current": default,
                "overridden": False,
                "expires_at_utc": None,
                "set_by_user_name": None,
            })
    return out
