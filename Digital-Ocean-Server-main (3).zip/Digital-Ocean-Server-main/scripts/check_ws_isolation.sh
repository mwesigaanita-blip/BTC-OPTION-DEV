#!/usr/bin/env bash
# Phase 1 isolation guard.
# Fails (exit 1) if realtime_ws/ or backend_ws/ imports from any forbidden package.
# See: new_dashboard_plan_doc/02_priority1_backend_ws_implementation_plan.md §5.
set -euo pipefail

cd "$(dirname "$0")/.."

FORBIDDEN='^[[:space:]]*(from|import)[[:space:]]+(realtime|mm_alert_bot|backend_api|hedge_engine|shared)([[:space:]]|\.|$)'

bad=0
for dir in realtime_ws backend_ws; do
  if [ ! -d "$dir" ]; then
    continue
  fi
  matches=$(grep -rEn --include='*.py' "$FORBIDDEN" "$dir" || true)
  if [ -n "$matches" ]; then
    echo "FORBIDDEN imports under $dir/:"
    echo "$matches"
    bad=1
  fi
done

if [ "$bad" -ne 0 ]; then
  echo
  echo "Isolation rule violated. New WS packages must NOT import from old packages."
  exit 1
fi

echo "isolation guard: OK"
