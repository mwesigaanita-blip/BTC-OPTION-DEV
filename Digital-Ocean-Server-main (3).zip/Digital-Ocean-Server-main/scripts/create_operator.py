# scripts/create_operator.py
#
# One-time bootstrap script - run this ONCE on the server to create
# the first operator account before launching the Streamlit app.
#
# Usage:
#   python scripts/create_operator.py
#
# Run from the project root (Digital-Ocean-Server folder):
#   cd C:\Drive\work\upwork\btc\code\BTC-Options-Project\Digital-Ocean-Server
#   python scripts/create_operator.py
#
# Safe to re-run - will not overwrite an existing username.

import sys
import os
import getpass
import logging

logging.basicConfig(level=logging.INFO, format="%(message)s")
logger = logging.getLogger(__name__)

# ── Make sure project root is on the path ────────────────────────────────────
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

# ── Imports (after path fix) ──────────────────────────────────────────────────
try:
    from multi_agent_system.config import DB_PATH
except ImportError:
    DB_PATH = os.getenv("DB_PATH", "database.db")
    logger.warning(f"multi_agents.config not found - using DB_PATH='{DB_PATH}'")

from shared.auth import (
    create_streamlit_users_table,
    insert_user,
    username_exists,
    hash_password,
    ALL_PAGES,
)


# ── Main ──────────────────────────────────────────────────────────────────────

def main() -> None:
    print("=" * 55)
    print("  MHE - Create First Operator Account")
    print("=" * 55)
    print(f"  Database: {DB_PATH}")
    print("=" * 55)
    print()

    # Step 1 - ensure table exists
    create_streamlit_users_table(DB_PATH)

    # Step 2 - collect username
    while True:
        username = input("Operator username: ").strip()
        if not username:
            print("  ✗ Username cannot be empty. Try again.")
            continue
        if username_exists(DB_PATH, username):
            print(f"  ✗ Username '{username}' already exists. Choose a different one.")
            continue
        break

    # Step 3 - collect password (with confirmation)
    while True:
        password = getpass.getpass("Password: ")
        if len(password) < 8:
            print("  ✗ Password must be at least 8 characters. Try again.")
            continue
        confirm = getpass.getpass("Confirm password: ")
        if password != confirm:
            print("  ✗ Passwords do not match. Try again.")
            continue
        break

    # Step 4 - hash and insert
    print()
    print("  Hashing password...")
    hashed = hash_password(password)

    insert_user(
        db_path=DB_PATH,
        username=username,
        hashed_password=hashed,
        role="operator",
        pages=ALL_PAGES,   # operators get all pages
    )

    print()
    print("=" * 55)
    print(f"  ✓ Operator '{username}' created successfully.")
    print(f"  Role  : operator")
    print(f"  Access: all {len(ALL_PAGES)} pages")
    print("=" * 55)
    print()
    print("  You can now launch the Streamlit app and log in.")
    print()


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n  Aborted.")
        sys.exit(0)
    except Exception as e:
        logger.error(f"Failed: {e}")
        sys.exit(1)