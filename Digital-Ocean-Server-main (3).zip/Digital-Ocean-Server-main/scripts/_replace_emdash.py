"""One-shot: replace every em-dash (U+2014) with a hyphen-minus (U+002D)
across the repo. Skips vendored / generated trees and binary file types.
Safe to re-run."""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

EXCLUDE_DIRS = {
    ".git",
    "node_modules",
    "dist",
    "build",
    "__pycache__",
    ".venv",
    "venv",
    ".next",
    ".mypy_cache",
    ".pytest_cache",
    ".ruff_cache",
}

INCLUDE_EXTS = {
    ".py", ".pyi",
    ".ts", ".tsx", ".js", ".jsx", ".mjs", ".cjs",
    ".md", ".mdx",
    ".css", ".scss",
    ".html",
    ".yml", ".yaml",
    ".json",
    ".conf", ".ini", ".toml", ".cfg",
    ".bat", ".sh", ".ps1",
    ".sql",
    ".txt",
    ".env", ".example",
    ".dockerignore", ".gitignore",
    ".disable",
}

# Skip lockfiles and notebooks (notebook re-serialization risk).
SKIP_NAMES = {"package-lock.json", "yarn.lock", "pnpm-lock.yaml"}
SKIP_EXTS = {".ipynb"}

EM_DASH = "-"


def main() -> int:
    total_files = 0
    total_replacements = 0
    changed_files: list[Path] = []

    for path in ROOT.rglob("*"):
        if not path.is_file():
            continue
        parts = set(path.relative_to(ROOT).parts)
        if parts & EXCLUDE_DIRS:
            continue
        if path.name in SKIP_NAMES:
            continue
        if path.suffix in SKIP_EXTS:
            continue
        # Treat suffix-less files conservatively (e.g. LICENSE) - include if .env-ish only
        if path.suffix not in INCLUDE_EXTS:
            # Allow Dockerfile, Makefile, .env-style names that have no suffix
            if path.name not in {"Dockerfile", "Makefile", ".env", ".env.local", ".env.example", "Caddyfile"}:
                continue
        try:
            text = path.read_text(encoding="utf-8")
        except (UnicodeDecodeError, OSError):
            continue
        if EM_DASH not in text:
            continue
        n = text.count(EM_DASH)
        new_text = text.replace(EM_DASH, "-")
        path.write_text(new_text, encoding="utf-8", newline="")
        total_files += 1
        total_replacements += n
        changed_files.append(path)

    print(f"changed_files={total_files} replacements={total_replacements}")
    for p in changed_files[:25]:
        print(" ", p.relative_to(ROOT))
    if len(changed_files) > 25:
        print(f"  ... and {len(changed_files) - 25} more")
    return 0


if __name__ == "__main__":
    sys.exit(main())
