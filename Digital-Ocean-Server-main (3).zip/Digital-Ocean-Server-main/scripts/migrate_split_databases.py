#!/usr/bin/env python3
"""
Production-safe migration that COPIES tables from the monolithic
``data/btc_trading.sqlite`` into a set of smaller, purpose-specific
SQLite databases.

Targets
-------
- data/trading.sqlite        (transaction_log, trade_recap_comments, trade_log,
                              fee_events, account_flows)
- data/snapshots.sqlite      (account_snapshots, positions_snapshots,
                              vol_metrics_snapshots, worker_status,
                              forecast_messages)
- data/market_data.sqlite    (btc_daily, btc_prices,
                              deribit_current_positions_daily, macro_daily)
- data/hedge_engine.sqlite   (hedge_engine_*_ticks, hedge_engine_state,
                              hedge_ticks, ml_regime_ticks, ml_vol_ticks,
                              hedge_decisions_log)
- data/models.sqlite         (x_score, strategy_text_store, model_run_meta,
                              model_quality_daily, MM_IM, plus dynamic
                              decisions_*_multi_agent and open_trades_*)
- data/infra.sqlite          (api_jobs, scheduler_config, scheduler_state,
                              mm_alert_config, simple_hedge_config,
                              simple_hedge_log)
- data/auth.sqlite           (only if streamlit_users exists in the monolith)

The old monolith DB is never modified. ``data/decision_board.sqlite`` is
already separate and is not touched.

Usage
-----
    python scripts/migrate_split_databases.py                  # dry-run (default)
    python scripts/migrate_split_databases.py --dry-run
    python scripts/migrate_split_databases.py --execute
    python scripts/migrate_split_databases.py --execute --overwrite
    python scripts/migrate_split_databases.py --verify-only
    python scripts/migrate_split_databases.py --execute --verbose

Environment
-----------
    DB_BASE_DIR   Optional. Directory containing the SQLite files. Takes
                  priority over everything else.
    DATA_DIR      Optional. Used by the rest of the app (see
                  ``multi_agent_system/config.py``). Honoured as a
                  fallback so the script Just Works on the server where
                  ``data/`` lives outside the code tree (e.g.
                  ``btc_app/data`` while code is in ``btc_app/app``).
    Default       ``<project_root>/data``.

Compatible with Python 3.10+ and uses only the standard library.
"""
from __future__ import annotations

import argparse
import json
import logging
import os
import shutil
import sqlite3
import sys
import traceback
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple

# ---------------------------------------------------------------------------
# Path resolution (works regardless of cwd / venv activation / Docker mount)
# ---------------------------------------------------------------------------

PROJECT_ROOT: Path = Path(__file__).resolve().parents[1]


def _load_dotenv_if_present() -> Optional[Path]:
    """Load ``<project_root>/.env`` into ``os.environ`` if the file exists.

    Uses ``python-dotenv`` if it is installed (matches the rest of the
    project) and otherwise falls back to a tiny inline parser so the
    script keeps working with only the standard library. Existing
    environment variables are NOT overridden - explicit shell exports
    win.
    """
    env_path = PROJECT_ROOT / ".env"
    if not env_path.exists():
        return None
    try:
        from dotenv import load_dotenv  # type: ignore[import-not-found]

        load_dotenv(env_path, override=False)
        return env_path
    except ImportError:
        pass

    try:
        with env_path.open("r", encoding="utf-8") as fh:
            for raw in fh:
                line = raw.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                key, _, value = line.partition("=")
                key = key.strip()
                value = value.strip()
                # strip inline comment (whitespace + #)
                if " #" in value:
                    value = value.split(" #", 1)[0].rstrip()
                # strip surrounding quotes
                if len(value) >= 2 and value[0] == value[-1] and value[0] in {"'", '"'}:
                    value = value[1:-1]
                os.environ.setdefault(key, value)
    except OSError:
        return None
    return env_path


# Load .env eagerly so resolve_base_dir() and friends see the values.
_DOTENV_LOADED_FROM: Optional[Path] = _load_dotenv_if_present()


def resolve_base_dir() -> Path:
    """Resolve the base data directory.

    Resolution order (first match wins):

    1. ``DB_BASE_DIR`` env var (script-specific override).
    2. ``DATA_DIR`` env var (matches the rest of the app - see
       ``multi_agent_system/config.py``). On the server this is set to
       ``btc_app/data``; in Docker it is typically ``/data``.
    3. ``<project_root>/data`` (local default).

    The directory is created if missing so the script works on a fresh
    checkout.
    """
    for var in ("DB_BASE_DIR", "DATA_DIR"):
        env_value = os.environ.get(var)
        if env_value:
            base = Path(env_value).expanduser().resolve()
            break
    else:
        base = (PROJECT_ROOT / "data").resolve()
    base.mkdir(parents=True, exist_ok=True)
    return base


def resolve_logs_dir() -> Path:
    logs_dir = (PROJECT_ROOT / "logs").resolve()
    logs_dir.mkdir(parents=True, exist_ok=True)
    return logs_dir


# ---------------------------------------------------------------------------
# Static grouping map
# ---------------------------------------------------------------------------

# Target DB file name -> list of static table names that belong in it.
TABLE_GROUPS: Dict[str, List[str]] = {
    "trading.sqlite": [
        "transaction_log",
        "trade_recap_comments",
        "trade_log",
        "fee_events",
        "account_flows",
    ],
    "snapshots.sqlite": [
        "account_snapshots",
        "positions_snapshots",
        "vol_metrics_snapshots",
        "worker_status",
        "forecast_messages",
    ],
    "market_data.sqlite": [
        "btc_daily",
        "btc_prices",
        "deribit_current_positions_daily",
        "macro_daily",
    ],
    "hedge_engine.sqlite": [
        "hedge_engine_account_ticks",
        "hedge_engine_positions_ticks",
        "hedge_engine_vol_ticks",
        "hedge_engine_markets_ticks",
        "hedge_engine_instruments_ticks",
        "hedge_engine_book_summaries_ticks",
        "hedge_engine_state",
        "hedge_ticks",
        "ml_regime_ticks",
        "ml_vol_ticks",
        "hedge_decisions_log",
    ],
    "models.sqlite": [
        "x_score",
        "strategy_text_store",
        "model_run_meta",
        "model_quality_daily",
        "MM_IM",
    ],
    "infra.sqlite": [
        "api_jobs",
        "scheduler_config",
        "scheduler_state",
        "mm_alert_config",
        "simple_hedge_config",
        "simple_hedge_log",
    ],
}

# Dynamic table prefixes/patterns routed to models.sqlite.
DYNAMIC_PATTERNS_FOR_MODELS: List[str] = [
    "decisions_%_multi_agent",
    "open_trades_%",
]

# Conditional: only migrated when present in the monolith.
CONDITIONAL_TABLES: Dict[str, str] = {
    "streamlit_users": "auth.sqlite",
}

OLD_DB_NAME = "btc_trading.sqlite"
DECISION_BOARD_DB_NAME = "decision_board.sqlite"  # never touched

LOG = logging.getLogger("migrate_split_databases")


# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------


def configure_logging(verbose: bool) -> Path:
    """Configure root logger to write to both stdout and a logfile."""
    logs_dir = resolve_logs_dir()
    logfile = logs_dir / "db_split_migration.log"

    level = logging.DEBUG if verbose else logging.INFO
    fmt = "%(asctime)s [%(levelname)s] %(message)s"
    datefmt = "%Y-%m-%dT%H:%M:%S%z"

    LOG.setLevel(level)
    LOG.handlers.clear()

    stream = logging.StreamHandler(stream=sys.stdout)
    stream.setLevel(level)
    stream.setFormatter(logging.Formatter(fmt, datefmt=datefmt))
    LOG.addHandler(stream)

    try:
        file_handler = logging.FileHandler(logfile, encoding="utf-8")
        file_handler.setLevel(level)
        file_handler.setFormatter(logging.Formatter(fmt, datefmt=datefmt))
        LOG.addHandler(file_handler)
    except OSError as exc:
        LOG.warning("Could not open logfile %s: %s", logfile, exc)

    LOG.propagate = False
    return logfile


# ---------------------------------------------------------------------------
# SQLite helpers
# ---------------------------------------------------------------------------


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def utc_now_compact() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")


def open_ro(db_path: Path) -> sqlite3.Connection:
    """Open the source DB read-only via URI so we can never mutate it."""
    uri = f"file:{db_path.as_posix()}?mode=ro"
    conn = sqlite3.connect(uri, uri=True)
    conn.row_factory = sqlite3.Row
    conn.text_factory = str
    return conn


def open_rw(db_path: Path) -> sqlite3.Connection:
    db_path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(db_path))
    conn.row_factory = sqlite3.Row
    conn.text_factory = str
    conn.execute("PRAGMA foreign_keys=ON;")
    return conn


def list_user_tables(conn: sqlite3.Connection) -> List[str]:
    cur = conn.execute(
        "SELECT name FROM sqlite_master "
        "WHERE type='table' AND name NOT LIKE 'sqlite_%' "
        "ORDER BY name"
    )
    return [row[0] for row in cur.fetchall()]


def find_dynamic_tables(conn: sqlite3.Connection, patterns: Iterable[str]) -> List[str]:
    """Return tables matching any of the LIKE patterns, deduplicated/sorted."""
    found: set[str] = set()
    for pattern in patterns:
        cur = conn.execute(
            "SELECT name FROM sqlite_master "
            "WHERE type='table' AND name NOT LIKE 'sqlite_%' AND name LIKE ?",
            (pattern,),
        )
        found.update(row[0] for row in cur.fetchall())
    return sorted(found)


def get_table_create_sql(conn: sqlite3.Connection, table: str) -> Optional[str]:
    cur = conn.execute(
        "SELECT sql FROM sqlite_master WHERE type='table' AND name=?",
        (table,),
    )
    row = cur.fetchone()
    return row[0] if row and row[0] else None


def get_related_objects_sql(
    conn: sqlite3.Connection, table: str, kinds: Iterable[str]
) -> List[str]:
    """Return CREATE statements for indexes/triggers/views attached to ``table``.

    Auto-created statements (``sqlite_autoindex_*``) and rows with NULL sql
    are skipped.
    """
    kinds_list = list(kinds)
    placeholders = ",".join(["?"] * len(kinds_list))
    cur = conn.execute(
        f"SELECT sql FROM sqlite_master "
        f"WHERE tbl_name=? AND type IN ({placeholders}) AND sql IS NOT NULL "
        f"AND name NOT LIKE 'sqlite_%' "
        f"ORDER BY type, name",
        (table, *kinds_list),
    )
    return [row[0] for row in cur.fetchall() if row[0]]


def table_exists(conn: sqlite3.Connection, table: str) -> bool:
    cur = conn.execute(
        "SELECT 1 FROM sqlite_master WHERE type='table' AND name=?",
        (table,),
    )
    return cur.fetchone() is not None


def count_rows(conn: sqlite3.Connection, table: str) -> int:
    cur = conn.execute(f'SELECT COUNT(*) FROM "{table}"')
    return int(cur.fetchone()[0])


def get_column_names(conn: sqlite3.Connection, table: str) -> List[str]:
    cur = conn.execute(f'PRAGMA table_info("{table}")')
    return [row[1] for row in cur.fetchall()]


# ---------------------------------------------------------------------------
# Migration core
# ---------------------------------------------------------------------------


class TableResult(dict):
    """Lightweight dict subclass for typed-ish reporting entries."""


def build_full_table_map(
    src_conn: sqlite3.Connection,
) -> Tuple[Dict[str, List[str]], List[str]]:
    """Return (db_name -> [tables]) including dynamic and conditional tables.

    Also returns the list of dynamic tables that were detected (for the
    report).
    """
    full_map: Dict[str, List[str]] = {db: list(tables) for db, tables in TABLE_GROUPS.items()}

    dynamic_tables = find_dynamic_tables(src_conn, DYNAMIC_PATTERNS_FOR_MODELS)
    if dynamic_tables:
        full_map.setdefault("models.sqlite", [])
        existing = set(full_map["models.sqlite"])
        for tbl in dynamic_tables:
            if tbl not in existing:
                full_map["models.sqlite"].append(tbl)

    for tbl, db_name in CONDITIONAL_TABLES.items():
        if table_exists(src_conn, tbl):
            full_map.setdefault(db_name, []).append(tbl)

    return full_map, dynamic_tables


def backup_target_db(target_db: Path, backup_root: Path) -> Optional[Path]:
    """Copy ``target_db`` into ``backup_root`` preserving the file name.

    Returns the backup path, or ``None`` if the target does not exist yet.
    """
    if not target_db.exists():
        return None
    backup_root.mkdir(parents=True, exist_ok=True)
    dst = backup_root / target_db.name
    shutil.copy2(target_db, dst)
    # Also copy WAL/SHM siblings if present so the backup is consistent.
    for suffix in ("-wal", "-shm"):
        sibling = target_db.with_name(target_db.name + suffix)
        if sibling.exists():
            shutil.copy2(sibling, backup_root / sibling.name)
    return dst


def copy_table(
    src_conn: sqlite3.Connection,
    dst_conn: sqlite3.Connection,
    table: str,
    overwrite: bool,
) -> TableResult:
    """Copy schema + rows for a single table from src to dst.

    Returns a TableResult describing the outcome.
    """
    result = TableResult(
        table=table,
        source_rows=None,
        copied_rows=0,
        status="pending",
        message="",
    )

    if not table_exists(src_conn, table):
        result["status"] = "missing"
        result["message"] = "source table not present"
        return result

    src_count = count_rows(src_conn, table)
    result["source_rows"] = src_count

    create_sql = get_table_create_sql(src_conn, table)
    if not create_sql:
        result["status"] = "error"
        result["message"] = "could not read CREATE TABLE statement"
        return result

    target_existed = table_exists(dst_conn, table)

    if target_existed and not overwrite:
        result["status"] = "skipped_exists"
        result["copied_rows"] = count_rows(dst_conn, table)
        result["message"] = "target table exists; rerun with --overwrite to replace"
        return result

    related_sql = get_related_objects_sql(src_conn, table, kinds=("index", "trigger"))

    try:
        with dst_conn:
            if target_existed:
                dst_conn.execute(f'DROP TABLE "{table}"')

            dst_conn.execute(create_sql)
            for stmt in related_sql:
                try:
                    dst_conn.execute(stmt)
                except sqlite3.OperationalError as exc:
                    LOG.warning(
                        "  could not recreate index/trigger for %s: %s", table, exc
                    )

            cols = get_column_names(src_conn, table)
            quoted_cols = ", ".join(f'"{c}"' for c in cols)
            placeholders = ", ".join(["?"] * len(cols))
            insert_sql = (
                f'INSERT INTO "{table}" ({quoted_cols}) VALUES ({placeholders})'
            )

            cur = src_conn.execute(f'SELECT {quoted_cols} FROM "{table}"')
            batch: List[Tuple] = []
            batch_size = 1000
            copied = 0
            for row in cur:
                batch.append(tuple(row))
                if len(batch) >= batch_size:
                    dst_conn.executemany(insert_sql, batch)
                    copied += len(batch)
                    batch.clear()
            if batch:
                dst_conn.executemany(insert_sql, batch)
                copied += len(batch)

            result["copied_rows"] = copied
    except sqlite3.Error as exc:
        result["status"] = "error"
        result["message"] = f"sqlite error: {exc}"
        return result

    if result["copied_rows"] != src_count:
        result["status"] = "validation_failed"
        result["message"] = (
            f"row count mismatch: source={src_count}, copied={result['copied_rows']}"
        )
        return result

    result["status"] = "copied"
    return result


def verify_table(
    src_conn: sqlite3.Connection,
    dst_conn: sqlite3.Connection,
    table: str,
) -> TableResult:
    result = TableResult(
        table=table,
        source_rows=None,
        copied_rows=None,
        status="pending",
        message="",
    )
    if not table_exists(src_conn, table):
        result["status"] = "missing"
        result["message"] = "source table not present"
        return result
    if not table_exists(dst_conn, table):
        result["status"] = "missing_target"
        result["message"] = "target table not present"
        return result
    src_count = count_rows(src_conn, table)
    dst_count = count_rows(dst_conn, table)
    result["source_rows"] = src_count
    result["copied_rows"] = dst_count
    if src_count == dst_count:
        result["status"] = "ok"
    else:
        result["status"] = "validation_failed"
        result["message"] = f"source={src_count}, target={dst_count}"
    return result


# ---------------------------------------------------------------------------
# Top-level driver
# ---------------------------------------------------------------------------


def run_migration(
    base_dir: Path,
    *,
    execute: bool,
    overwrite: bool,
    verify_only: bool,
) -> Tuple[int, dict]:
    """Drive the full migration. Returns (exit_code, report_dict)."""
    src_path = base_dir / OLD_DB_NAME
    LOG.info("Project root:        %s", PROJECT_ROOT)
    LOG.info("DB base dir:         %s", base_dir)
    LOG.info("Source (read-only):  %s", src_path)
    LOG.info("Mode:                %s", _mode_label(execute, overwrite, verify_only))

    if not src_path.exists():
        LOG.error("Source DB not found: %s", src_path)
        return 2, {
            "timestamp": utc_now_iso(),
            "source_db": str(src_path),
            "error": "source DB not found",
        }

    backup_root = base_dir / "backups" / "db_split" / utc_now_compact()
    will_backup = execute and not verify_only

    report: dict = {
        "timestamp": utc_now_iso(),
        "python": {"executable": sys.executable, "version": sys.version},
        "mode": _mode_label(execute, overwrite, verify_only),
        "source_db": str(src_path),
        "base_dir": str(base_dir),
        "backup_dir": str(backup_root) if will_backup else None,
        "target_dbs": {},
        "copied_tables": [],
        "skipped_tables": [],
        "missing_tables": [],
        "validation_errors": [],
        "dynamic_tables_detected": [],
    }

    src_conn = open_ro(src_path)
    try:
        full_map, dynamic_tables = build_full_table_map(src_conn)
        report["dynamic_tables_detected"] = dynamic_tables
        for db_name, tables in full_map.items():
            target_path = base_dir / db_name
            LOG.info("Target DB:           %s  (%d tables)", target_path, len(tables))
            report["target_dbs"][db_name] = {
                "path": str(target_path),
                "tables": list(tables),
            }

        any_errors = False

        for db_name, tables in full_map.items():
            target_path = base_dir / db_name
            LOG.info("")
            LOG.info("=== %s ===", db_name)

            if verify_only:
                if not target_path.exists():
                    LOG.warning("  target DB does not exist yet: %s", target_path)
                    for tbl in tables:
                        report["validation_errors"].append(
                            {"db": db_name, "table": tbl, "reason": "target DB missing"}
                        )
                        any_errors = True
                    continue
                dst_conn = open_rw(target_path)
                try:
                    for tbl in tables:
                        res = verify_table(src_conn, dst_conn, tbl)
                        _record_result(report, db_name, target_path, res)
                        _log_table_result(db_name, target_path, src_path, res)
                        if res["status"] in ("validation_failed", "missing_target", "error"):
                            any_errors = True
                finally:
                    dst_conn.close()
                continue

            if not execute:
                # dry-run: do not create files, just report what we would do.
                for tbl in tables:
                    src_present = table_exists(src_conn, tbl)
                    src_count = count_rows(src_conn, tbl) if src_present else None
                    res = TableResult(
                        table=tbl,
                        source_rows=src_count,
                        copied_rows=0,
                        status="dry_run" if src_present else "missing",
                        message="" if src_present else "source table not present",
                    )
                    _record_result(report, db_name, target_path, res)
                    _log_table_result(db_name, target_path, src_path, res)
                continue

            # execute mode: backup target if it exists, then copy each table.
            try:
                backup_path = backup_target_db(target_path, backup_root)
                if backup_path:
                    LOG.info("  backed up existing target -> %s", backup_path)
            except OSError as exc:
                LOG.error("  could not back up target %s: %s", target_path, exc)
                any_errors = True
                continue

            try:
                dst_conn = open_rw(target_path)
            except (sqlite3.Error, OSError) as exc:
                LOG.error("  could not open target DB %s: %s", target_path, exc)
                any_errors = True
                continue

            try:
                for tbl in tables:
                    res = copy_table(src_conn, dst_conn, tbl, overwrite=overwrite)
                    _record_result(report, db_name, target_path, res)
                    _log_table_result(db_name, target_path, src_path, res)
                    if res["status"] in ("error", "validation_failed"):
                        any_errors = True
            finally:
                dst_conn.close()

        _print_summary(report)

        if will_backup and backup_root.exists():
            LOG.info("")
            LOG.info("Backups stored at: %s", backup_root)

        return (1 if any_errors else 0), report
    finally:
        src_conn.close()


def _mode_label(execute: bool, overwrite: bool, verify_only: bool) -> str:
    if verify_only:
        return "verify-only"
    if not execute:
        return "dry-run"
    return "execute (overwrite)" if overwrite else "execute"


def _record_result(
    report: dict, db_name: str, target_path: Path, res: TableResult
) -> None:
    entry = {
        "db": db_name,
        "target_path": str(target_path),
        "table": res["table"],
        "source_rows": res.get("source_rows"),
        "copied_rows": res.get("copied_rows"),
        "status": res["status"],
        "message": res.get("message", ""),
    }
    status = res["status"]
    if status in ("copied", "ok", "dry_run"):
        report["copied_tables"].append(entry)
    elif status in ("skipped_exists",):
        report["skipped_tables"].append(entry)
    elif status == "missing":
        report["missing_tables"].append(entry)
    else:  # error, validation_failed, missing_target
        report["validation_errors"].append(entry)


def _log_table_result(
    db_name: str, target_path: Path, source_path: Path, res: TableResult
) -> None:
    LOG.info(
        "  table=%-40s src=%-7s dst=%-7s status=%s%s",
        res["table"],
        _fmt_count(res.get("source_rows")),
        _fmt_count(res.get("copied_rows")),
        res["status"],
        f"  [{res['message']}]" if res.get("message") else "",
    )
    LOG.debug("    source=%s -> target=%s", source_path, target_path)


def _fmt_count(value) -> str:
    if value is None:
        return "-"
    return str(value)


def _print_summary(report: dict) -> None:
    LOG.info("")
    LOG.info("================ MIGRATION SUMMARY ================")
    LOG.info("Source DB:          %s", report["source_db"])
    LOG.info("Mode:               %s", report["mode"])
    if report.get("backup_dir"):
        LOG.info("Backup dir:         %s", report["backup_dir"])
    for db_name, info in report["target_dbs"].items():
        LOG.info("Target %-22s -> %s", db_name, info["path"])
    LOG.info("Tables copied:      %d", len(report["copied_tables"]))
    LOG.info("Tables skipped:     %d", len(report["skipped_tables"]))
    LOG.info("Tables missing:     %d", len(report["missing_tables"]))
    LOG.info("Validation errors:  %d", len(report["validation_errors"]))
    if report["dynamic_tables_detected"]:
        LOG.info(
            "Dynamic models tables: %d (%s)",
            len(report["dynamic_tables_detected"]),
            ", ".join(report["dynamic_tables_detected"]),
        )
    LOG.info("===================================================")


def write_report(report: dict) -> Path:
    logs_dir = resolve_logs_dir()
    out = logs_dir / "db_split_migration_report.json"
    try:
        with out.open("w", encoding="utf-8") as fh:
            json.dump(report, fh, indent=2, sort_keys=True, default=str)
        LOG.info("Wrote JSON report: %s", out)
    except OSError as exc:
        LOG.error("Could not write JSON report %s: %s", out, exc)
    return out


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------


def parse_args(argv: Optional[List[str]] = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Copy tables from data/btc_trading.sqlite into multiple smaller "
            "SQLite databases. Default mode is dry-run."
        ),
    )
    group = parser.add_mutually_exclusive_group()
    group.add_argument(
        "--dry-run",
        action="store_true",
        help="Report what would be copied; do not write any target DBs (default).",
    )
    group.add_argument(
        "--execute",
        action="store_true",
        help="Actually create target DBs and copy data.",
    )
    group.add_argument(
        "--verify-only",
        action="store_true",
        help="Compare row counts between source and target DBs without copying.",
    )
    parser.add_argument(
        "--overwrite",
        action="store_true",
        help=(
            "When combined with --execute, drop and recreate the target table "
            "if it already exists. Existing target DB is backed up first."
        ),
    )
    parser.add_argument(
        "--verbose",
        action="store_true",
        help="Enable DEBUG-level logging.",
    )
    return parser.parse_args(argv)


def main(argv: Optional[List[str]] = None) -> int:
    args = parse_args(argv)
    logfile = configure_logging(args.verbose)

    LOG.info("Python executable: %s", sys.executable)
    LOG.info("Python version:    %s", sys.version.replace("\n", " "))
    LOG.info("Logfile:           %s", logfile)
    if _DOTENV_LOADED_FROM:
        LOG.info("Loaded .env from:  %s", _DOTENV_LOADED_FROM)
    else:
        LOG.info("No .env file at %s (using shell env / defaults)", PROJECT_ROOT / ".env")

    if args.overwrite and not args.execute:
        LOG.warning("--overwrite has no effect without --execute")

    execute = bool(args.execute)
    verify_only = bool(args.verify_only)
    if not execute and not verify_only:
        # default mode = dry-run
        args.dry_run = True

    try:
        base_dir = resolve_base_dir()
    except OSError as exc:
        LOG.error("Could not resolve/create base dir: %s", exc)
        return 2

    try:
        exit_code, report = run_migration(
            base_dir,
            execute=execute,
            overwrite=bool(args.overwrite),
            verify_only=verify_only,
        )
    except PermissionError as exc:
        LOG.error("Permission error: %s", exc)
        return 3
    except sqlite3.Error as exc:
        LOG.error("SQLite error: %s", exc)
        LOG.debug("%s", traceback.format_exc())
        return 4
    except Exception as exc:  # last-resort catch-all so cron gets a clean exit code
        LOG.error("Unexpected error: %s", exc)
        LOG.debug("%s", traceback.format_exc())
        return 5

    write_report(report)
    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
