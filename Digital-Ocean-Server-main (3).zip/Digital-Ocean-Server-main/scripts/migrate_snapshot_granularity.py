"""
One-off migration: rename the Deribit BTC options snapshot folder and
state file from `granularity=1h` to `granularity=5m`, and rewrite the
`granularity` column inside every migrated parquet from "1h" to "5m".

The scheduler actually runs every 5 minutes (SNAPSHOT_INTERVAL_SECONDS=300),
but the label was never updated from the original hourly cadence. This
script brings the on-disk layout in line with the new code.

Usage:
    python -m scripts.migrate_snapshot_granularity [--dry-run] [--data-root PATH]

Stop the API container before running so the scheduler cannot write
into `granularity=1h` while the rename is in progress.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import List

import pyarrow.parquet as pq
import pyarrow as pa


OLD_LABEL = "granularity=1h"
NEW_LABEL = "granularity=5m"
OLD_STATE_NAME = "deribit_btc_1h.json"
NEW_STATE_NAME = "deribit_btc_5m.json"


def resolve_data_root(arg: str | None) -> Path:
    if arg:
        return Path(arg).resolve()
    from multi_agent_system.config import DATA_ROOT
    return Path(DATA_ROOT)


def snapshot_paths(data_root: Path) -> tuple[Path, Path, Path, Path]:
    base = data_root / "raw" / "cefi" / "options" / "snapshot" / "exchange=deribit" / "underlying=BTC"
    old_folder = base / OLD_LABEL
    new_folder = base / NEW_LABEL
    state_dir = data_root / "raw" / "cefi" / "options" / "snapshot" / "_state"
    old_state = state_dir / OLD_STATE_NAME
    new_state = state_dir / NEW_STATE_NAME
    return old_folder, new_folder, old_state, new_state


def find_parquets(root: Path) -> List[Path]:
    if not root.exists():
        return []
    return sorted(root.rglob("*.parquet"))


def rewrite_parquet_granularity(path: Path, dry_run: bool) -> str:
    table = pq.read_table(path)
    if "granularity" not in table.column_names:
        return "skip (no granularity column)"

    col = table.column("granularity")
    try:
        unique_vals = set(col.to_pylist())
    except Exception:
        unique_vals = set()

    if unique_vals and unique_vals.issubset({"5m"}):
        return "skip (already 5m)"

    if dry_run:
        return f"would rewrite (values={sorted(v for v in unique_vals if v is not None)})"

    new_col = pa.array(["5m"] * table.num_rows, type=pa.string())
    idx = table.column_names.index("granularity")
    new_table = table.set_column(idx, "granularity", new_col)

    tmp = path.with_suffix(path.suffix + ".tmp")
    pq.write_table(new_table, tmp)
    tmp.replace(path)
    return "rewritten"


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dry-run", action="store_true", help="Print planned actions without touching disk")
    parser.add_argument("--data-root", help="Override DATA_ROOT (defaults to multi_agent_system.config.DATA_ROOT)")
    args = parser.parse_args()

    data_root = resolve_data_root(args.data_root)
    old_folder, new_folder, old_state, new_state = snapshot_paths(data_root)

    print(f"DATA_ROOT    : {data_root}")
    print(f"old folder   : {old_folder}")
    print(f"new folder   : {new_folder}")
    print(f"old state    : {old_state}")
    print(f"new state    : {new_state}")
    print(f"dry-run      : {args.dry_run}")
    print()

    old_exists = old_folder.exists()
    new_exists = new_folder.exists()

    if not old_exists and new_exists:
        print("Already migrated (new folder exists, old folder absent). Nothing to do.")
        return 0

    if not old_exists and not new_exists:
        print("Neither old nor new snapshot folder exists. Nothing to migrate.")
        return 0

    if old_exists and new_exists:
        print("ERROR: both old and new snapshot folders exist. Refusing to merge -")
        print("       per-day parquet filenames collide. Resolve manually:")
        print(f"         {old_folder}")
        print(f"         {new_folder}")
        return 2

    # old exists, new does not
    parquets = find_parquets(old_folder)
    print(f"Found {len(parquets)} parquet file(s) under old folder.")
    print()

    print("Step 1: rewrite in-row `granularity` column on each parquet under the old folder")
    for p in parquets:
        rel = p.relative_to(old_folder)
        try:
            status = rewrite_parquet_granularity(p, args.dry_run)
        except Exception as exc:
            print(f"  ERROR  {rel}: {exc}")
            return 3
        print(f"  {status:40s}  {rel}")
    print()

    print("Step 2: rename folder")
    if args.dry_run:
        print(f"  would rename: {old_folder} -> {new_folder}")
    else:
        new_folder.parent.mkdir(parents=True, exist_ok=True)
        old_folder.rename(new_folder)
        print(f"  renamed: {old_folder} -> {new_folder}")
    print()

    print("Step 3: rename state file")
    if old_state.exists():
        if new_state.exists():
            print(f"  WARNING: new state file already exists: {new_state}")
            print(f"           leaving old state file in place: {old_state}")
        elif args.dry_run:
            print(f"  would rename: {old_state} -> {new_state}")
        else:
            new_state.parent.mkdir(parents=True, exist_ok=True)
            old_state.rename(new_state)
            print(f"  renamed: {old_state} -> {new_state}")
    else:
        print(f"  old state file not present, skipping: {old_state}")
    print()

    print("Migration complete.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
