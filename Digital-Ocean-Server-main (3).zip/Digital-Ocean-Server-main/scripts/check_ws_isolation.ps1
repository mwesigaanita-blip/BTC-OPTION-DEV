# Phase 1 isolation guard (PowerShell).
# Fails (exit 1) if realtime_ws/ or backend_ws/ imports from any forbidden package.
# See: new_dashboard_plan_doc/02_priority1_backend_ws_implementation_plan.md §5.

$ErrorActionPreference = 'Stop'

$root = Split-Path -Parent $PSScriptRoot
Set-Location $root

$pattern = '^\s*(from|import)\s+(realtime|mm_alert_bot|backend_api|hedge_engine|shared)(\s|\.|$)'
$bad = $false

foreach ($dir in @('realtime_ws', 'backend_ws')) {
    if (-not (Test-Path $dir)) { continue }
    $matches = Get-ChildItem -Path $dir -Recurse -Filter '*.py' -File |
        Select-String -Pattern $pattern
    if ($matches) {
        Write-Host "FORBIDDEN imports under $dir/:"
        $matches | ForEach-Object { Write-Host ("  {0}:{1}: {2}" -f $_.Path, $_.LineNumber, $_.Line.Trim()) }
        $bad = $true
    }
}

if ($bad) {
    Write-Host ""
    Write-Host "Isolation rule violated. New WS packages must NOT import from old packages."
    exit 1
}

Write-Host "isolation guard: OK"
