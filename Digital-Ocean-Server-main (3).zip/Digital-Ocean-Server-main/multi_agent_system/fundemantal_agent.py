from __future__ import annotations
# fundamental_adapter.py
from typing import Literal, Tuple
from typing import Dict, Any, List, Tuple
from datetime import datetime, timezone
import time, math, requests
from datetime import datetime, timedelta, timezone
from typing import List, Dict, Any
import feedparser 
from .sentiment import *
from .config import *
from .stage_1 import *
Bias = Literal["bullish", "bearish", "neutral"]
from typing import Dict, Any, List, Tuple
from datetime import datetime, timezone
import json
from dotenv import load_dotenv
load_dotenv(os.path.join(DEPLOYMENT_ROOT, ".env"))
REQUIRED_MIN_KEYS = ["macro_now"]  # LLM can work with this alone
REQUEST_TIMEOUT = 12
from .llm_io import *

def macro_to_bias_confidence(now: float, m7: float | None = None, m30: float | None = None):
    # combine current + trend (light weight on trend)
    score = now if (m7 is None or m30 is None) else (0.65*now + 0.35*0.5*(m7 + m30))

    if score >= 0.15:
        bias = "bullish"
    elif score <= -0.15:
        bias = "bearish"
    else:
        bias = "neutral"

    conf = 0.35 + 0.55*abs(score)
    # same-sign boost / disagreement penalty
    if m7 is not None and m30 is not None:
        same_sign = (now >= 0 and m7 >= 0 and m30 >= 0) or (now <= 0 and m7 <= 0 and m30 <= 0)
        conf += 0.10 if same_sign else -0.10
    return bias, round(max(0.05, min(0.95, conf)), 3)


def fetch_rss_headlines(limit_per_feed: int = 50, lookback_hours: int = 36) -> List[str]:
    """
    Lightweight RSS grab (titles only). No LLM needed. Safe for token budget.
    """


    FEEDS = [
        "https://www.coindesk.com/arc/outboundfeeds/rss/",
        "https://cointelegraph.com/rss",
        "https://www.federalreserve.gov/feeds/rss",
        "https://feeds.a.dj.com/rss/RSSMarketsMain.xml",
        "http://feeds.reuters.com/reuters/topNews",
        "https://www.bloomberg.com/crypto/rss",
    ]
    cutoff = datetime.now(timezone.utc) - timedelta(hours=lookback_hours)
    out: List[str] = []

    for url in FEEDS:
        try:
            feed = feedparser.parse(url)
            cnt = 0
            for e in feed.entries:
                dt = getattr(e, "published_parsed", None) or getattr(e, "updated_parsed", None)
                pub = datetime(*dt[:6], tzinfo=timezone.utc) if dt else cutoff
                if pub < cutoff:
                    continue
                title = (getattr(e, "title", "") or "").strip()
                if len(title) >= 8:
                    out.append(title[:1024])
                    cnt += 1
                    if cnt >= limit_per_feed:
                        break
        except Exception:
            continue
    return out[: 4 * limit_per_feed]  # compact list

# ---- Blockchain.com charts (free) ----
# Slugs: "hash-rate", "estimated-transaction-volume-usd", "n-unique-addresses", "total-bitcoins"
def _blockchain_chart_latest(slug: str, days: int = 14) -> float | None:
    url = f"https://api.blockchain.info/charts/{slug}?timespan={days}days&format=json"
    try:
        r = requests.get(url, timeout=REQUEST_TIMEOUT)
        r.raise_for_status()
        js = r.json()
        vals = js.get("values") or []
        if not vals:
            return None
        return float(vals[-1].get("y"))
    except Exception:
        return None

def fetch_on_chain_basics() -> Dict[str, Any]:
    """
    Returns: {"hash_rate": TH/s, "tx_volume_usd": USD, "active_addresses": count}
    """
    return {
        "hash_rate": _blockchain_chart_latest("hash-rate", 14),                       # TH/s
        "tx_volume": _blockchain_chart_latest("estimated-transaction-volume-usd", 14),# USD
        "active_addresses": _blockchain_chart_latest("n-unique-addresses", 14),       # count
    }

# ---- Supply & days to halving ----
def _current_block_height() -> int | None:
    # Free simple endpoint
    try:
        r = requests.get("https://blockchain.info/q/getblockcount", timeout=REQUEST_TIMEOUT)
        r.raise_for_status()
        return int(r.text.strip())
    except Exception:
        return None

def _circulating_supply() -> float | None:
    # total-bitcoins (in BTC)
    return _blockchain_chart_latest("total-bitcoins", 14)

def _days_to_next_halving(height: int | None) -> int | None:
    if height is None:
        return None
    HALVING_INTERVAL = 210_000
    next_halving = ((height // HALVING_INTERVAL) + 1) * HALVING_INTERVAL
    blocks_left = max(0, next_halving - height)
    avg_block_minutes = 10.0
    return int(math.ceil((blocks_left * avg_block_minutes) / (60 * 24)))

def fetch_supply_context() -> Dict[str, Any]:
    h = _current_block_height()
    return {
        "circulating_supply": _circulating_supply(),      # BTC
        "days_to_halving": _days_to_next_halving(h),
    }

def pull_fundamental_inputs(macro_now: float , macro_7D: float , macro_30: float) -> Dict[str, Any]:
    """
    Aggregate all available free data in one call. Safe if some endpoints fail.
    """
    return {
        "macro_now": float(macro_now),           # your [-1,1] score
        "macro_7D": float(macro_7D),           # your [-1,1] score
        "macro_30D": float(macro_30),           # your [-1,1] score
        "headlines": fetch_rss_headlines(),          # optional list[str]
        "on_chain": fetch_on_chain_basics(),         # may contain None values
        "supply": fetch_supply_context(),            # may contain None values
    }

# --- Requirements & Normalization ---


REQUIRED_MIN_KEYS = ["macro_now"]  # LLM can work with this alone

def check_requirements(data: Dict[str, Any]) -> Dict[str, List[str]]:
    missing = [k for k in REQUIRED_MIN_KEYS if data.get(k) is None]
    optional_missing = []
    for k in ["headlines", "on_chain", "supply"]:
        if k not in data:
            optional_missing.append(k)
    return {"missing": missing, "optional_missing": optional_missing}



def check_requirements(data: Dict[str, Any]) -> Dict[str, List[str]]:
    missing = [k for k in REQUIRED_MIN_KEYS if data.get(k) is None]
    optional_missing = []
    for k in ["headlines", "on_chain", "supply"]:
        if k not in data:
            optional_missing.append(k)
    return {"missing": missing, "optional_missing": optional_missing}

def normalize_inputs(raw: Dict[str, Any]) -> Dict[str, Any]:
    """Light normalization for LLM: trim lists, add units, add asof."""
    on = raw.get("on_chain") or {}
    norm = {
        "asof_utc": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "macro_now": float(raw["macro_now"]),
        "macro_7D": float(raw.get("macro_7D", 0.0)),
        "macro_30D": float(raw.get("macro_30D", 0.0)),
        "headlines": (raw.get("headlines") or []),
        "on_chain": {
            "hash_rate_ehs": (on.get("hash_rate") / 1e6) if on.get("hash_rate") is not None else None,  # TH/s→EH/s
            "tx_volume_usd": on.get("tx_volume"),
            "active_addresses": on.get("active_addresses"),
        },
        "supply": {
            "circulating_btc": (raw.get("supply") or {}).get("circulating_supply"),
            "days_to_halving": (raw.get("supply") or {}).get("days_to_halving"),
        },
        "sources": ["blockchain.com charts", "public RSS (summaries)"],
    }
    return norm

# --- LLM Prompt Builder (schema-first) ---
def build_llm_prompt(norm: dict, ta_summary: str) -> str:
    SCHEMA = (
        '{\n'
        '  "agent": "fundamental",\n'
        '  "bias": "bullish|bearish|neutral",\n'
        '  "confidence": 0.0,\n'
        '  "horizon_days": 5,\n'
        '  "rationale": "≤300 words",\n'
        '  "key_signals": ["short tags"],\n'
        '  "red_flags": [{"code":"LOW_DATA","severity":"soft","note":"short"}],\n'
        '  "recommendations": [],\n'
        '  "metrics": {"pop_est": 0.70}\n'
        '}'
    )

    RULES = (
        "Decision rules (must follow):\n"
        "- Map macro_now ∈ [-1,1] to bias:\n"
        "  • score ≥ +0.15 ⇒ bullish\n"
        "  • score ≤ -0.15 ⇒ bearish\n"
        "  • otherwise ⇒ neutral\n"
        "- Use macro_7D and macro_30D as trend confirmers:\n"
        "  • If macro_now ∈ [-0.15, +0.15] but macro_7D and macro_30D share the SAME sign and |value| ≥ 0.10,\n"
        "    set bias to that sign (bullish if both ≥ +0.10, bearish if both ≤ -0.10).\n"
        "  • If all three (now, 7D, 30D) share the SAME sign, add +0.10 to confidence (cap at 0.95).\n"
        "  • If they DISAGREE in sign, subtract 0.10 from confidence (floor at 0.05) and add red_flag "
        '{"code":"CONFLICTING_SIGNALS","severity":"soft","note":"macro windows disagree"}.\n'
        "- horizon_days MUST be 15.\n"
        "- Return ONLY JSON per schema."
    )

    return (
        "You are the BTC Fundamental Agent. Return ONLY valid JSON per schema.\n\n"
        f"Schema:\n{SCHEMA}\n\n"
        f"{RULES}\n\n"
        "Inputs:\n"
        "- macro_now (-1..1)\n"
        "- macro_7D (-1..1)\n"
        "- macro_30D (-1..1)\n"
        "- headlines (0..5)\n"
        "- on_chain: hash_rate_ehs, tx_volume_usd, active_addresses\n"
        "- supply: circulating_btc, days_to_halving\n"
        "- technical_summary: trend, RSI, Ichimoku cloud, Fibonacci zones\n\n"
        "Technical summary (must be used when deciding bias and confidence):\n"
        f"{ta_summary}\n\n"
        f"Data:\n{norm}"
    )

# --- Output Validation ---

from typing import Literal
Bias = Literal["bullish","bearish","neutral"]

def validate_agent_output(js: Dict[str, Any]) -> Tuple[bool, List[str]]:
    errs: List[str] = []
    if js.get("agent") != "fundamental":
        errs.append("agent must be 'fundamental'")
    if js.get("bias") not in ("bullish","bearish","neutral"):
        errs.append("bias must be bullish|bearish|neutral")
    try:
        c = float(js.get("confidence", -1))
        if not (0.0 <= c <= 1.0):
            errs.append("confidence must be in [0,1]")
    except Exception:
        errs.append("confidence must be float")
    if not isinstance(js.get("horizon_days", 0), int):
        errs.append("horizon_days must be int")
    if not isinstance(js.get("key_signals", []), list):
        errs.append("key_signals must be list")
    if not isinstance(js.get("red_flags", []), list):
        errs.append("red_flags must be list")
    if "metrics" not in js:
        errs.append("metrics missing")
    return (len(errs) == 0, errs)

# --- Fundamental Agent ---

# ===== LLM Client Factory with Cost Accounting (OpenAI / xAI) =====

import os, json, re, time, requests
from typing import Any, Dict, Optional, Tuple

_JSON_RE = re.compile(r"\{.*\}", re.DOTALL)

class LLMError(RuntimeError): ...

# --- Pricing per 1K tokens (USD). Adjust as needed or override via env. ---


import json
from typing import Dict, Any, Optional

def run_fundamental_agent(
    raw_inputs: Dict[str, Any],
    use_llm: bool = False,
    client: Optional[callable] = None,     # from make_llm_client(...)
    provider: str = "openai",
    model: str = "gpt-4o-mini",
    temperature: float = 0.2,
    max_tokens: int = 400,
    verbose: bool = True,
    ta_summary: Optional[str] = None,
) -> Dict[str, Any]:
    # 0) Requirements
    req = check_requirements(raw_inputs)
    if req["missing"]:
        return {
            "agent": "fundamental",
            "bias": "neutral",
            "confidence": 0.15,
            "horizon_days": 15,
            "rationale": f"Insufficient inputs: {req['missing']}",
            "key_signals": ["limited_inputs"],
            "red_flags": [{"code": "DATA_GAP", "severity": "hard", "note": str(req["missing"])}],
            "recommendations": [],
            "metrics": {"pop_est": 0.65}
        }

    # 1) Normalize
    norm = normalize_inputs(raw_inputs)

    # 2) Rule-only baseline (always available)
    bias, conf = macro_to_bias_confidence(norm["macro_now"])
    baseline = {
        "agent": "fundamental",
        "bias": bias,
        "confidence": conf,
        "horizon_days": 15,
        "rationale": (
            f"Macro score {norm['macro_now']:.2f} → {bias}. "
            f"{'Headlines present' if norm['headlines'] else 'Headlines missing'}."
        ),
        "key_signals": (
            ["macro_now", "regulatory_headlines_seen"] if norm["headlines"] else ["macro_now"],
            ["macro_7D", "macro_30D"]
        ),
        "red_flags": ([] if norm["headlines"] else [{"code": "LOW_DATA", "severity": "soft", "note": "no headlines"}]),
        "recommendations": [],
        "metrics": {"pop_est": 0.70}
    }

    if not use_llm:
        return baseline , 0

    # 3) LLM-enhanced path (with client factory + cost/usage)
    try:
        # Create client once if not injected
        if client is None:
            client = make_llm_client(provider=provider, model=model)

        prompt = build_llm_prompt(norm, ta_summary or "Technical summary not available.")
        resp = client(prompt, temperature=temperature, max_tokens=max_tokens, verbose=verbose)
        # resp: {"json_str", "usage": {"prompt":int,"completion":int}, "usd_est": float, "raw": ...}

        parsed = json.loads(resp["json_str"])
        cost = resp.get("usd_est", 0.0)
        # After parsed = json.loads(resp["json_str"])
        try:
            c = float(parsed.get("confidence", -1))
        except Exception:
            c = -1

        # If out of range, fall back to adapter
        if not (0.0 < c <= 1.0):
            base_bias, base_conf = macro_to_bias_confidence(norm["macro_now"])
            parsed["confidence"] = round(base_conf, 3)
            rf = parsed.get("red_flags") or []
            rf.append({"code": "CONFIDENCE_FIX", "severity": "soft", "note": "Reset confidence from adapter"})
            parsed["red_flags"] = rf

        ok, errs = validate_agent_output(parsed)

        # attach usage/cost into metrics (without breaking schema)
        usage = resp.get("usage", {})
        usd_est = float(resp.get("usd_est", 0.0))
        if "metrics" not in parsed or not isinstance(parsed["metrics"], dict):
            parsed["metrics"] = {}
        parsed["metrics"].update({
            "llm_prompt_tokens": int(usage.get("prompt", 0)),
            "llm_completion_tokens": int(usage.get("completion", 0)),
            "llm_usd_est": round(usd_est, 6),
        })

        if ok:
            # print cost line (optional)
            if verbose:
                print(f"[FundamentalAgent] LLM cost ≈ ${usd_est:.4f} "
                      f"(p={usage.get('prompt',0)}, c={usage.get('completion',0)})")
            return parsed , cost

        # schema errors → fallback
        baseline["red_flags"].append({
            "code": "DATA_GAP", "severity": "soft", "note": f"LLM schema errors: {errs}"
        })
        # still record cost on baseline
        baseline["metrics"].update({
            "llm_prompt_tokens": int(usage.get("prompt", 0)),
            "llm_completion_tokens": int(usage.get("completion", 0)),
            "llm_usd_est": round(usd_est, 6),
        })
        return baseline , cost

    except Exception as e:
        baseline["red_flags"].append({"code": "DATA_GAP", "severity": "soft", "note": f"LLM error: {e}"})
        return baseline , 0

import os, json
from pathlib import Path
from datetime import datetime, timezone
from typing import Dict, Any

def run_fundamental(
    model: str,
    temperature: float,
    max_tokens: int,
    use_llm: bool = True,
    macro_now: Optional[float] = None,
    marco_7D : Optional[float] = None,
    macro_30D : Optional[float] = None,
    provider: str = "openai",
    ta_summary: Optional[str] = None,
) -> Dict[str, Any]:
    # 1) Build inputs (real data)
    macro_now = macro_now  # returns [-1, 1]
    raw = pull_fundamental_inputs(macro_now , marco_7D , macro_30D)

    # 2) Pick provider from model (simple heuristic)

    # 3) Create LLM client if needed
    client = make_llm_client(provider=provider, model=model) if use_llm else None

    # 4) Run agent
    result , cost = run_fundamental_agent(
        raw_inputs=raw,
        use_llm=use_llm,
        client=client,
        temperature=float(temperature),
        max_tokens=int(max_tokens),
        verbose=True,
        ta_summary=ta_summary,
    )
    
    # 5) Save decision to folder named with model + date (UTC, to avoid timezone ambiguity)
    now = datetime.now(timezone.utc)
    stamp = now.strftime("%Y-%m-%d_%H-%M-%S")  # date + minutes + seconds
    folder_name = f"{model}_{stamp}"
    out_dir = Path("fundamental_runs") / folder_name
    out_dir.mkdir(parents=True, exist_ok=True)

    # Persist both inputs and decision for auditability
    with (out_dir / "inputs.json").open("w", encoding="utf-8") as f:
        json.dump(raw, f, ensure_ascii=False, indent=2)
    with (out_dir / "fundamental_decision.json").open("w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)

    print(f"[Saved] {out_dir.as_posix()}/fundamental_decision.json")
    return result , cost



if __name__ == "__main__":
    macro_now = get_macro_sentiment_score()
    out = run_fundamental(model="gpt-4o-mini", temperature=0, max_tokens=600, use_llm=True, macro_now=macro_now)
    print(json.dumps(out, indent=2))
