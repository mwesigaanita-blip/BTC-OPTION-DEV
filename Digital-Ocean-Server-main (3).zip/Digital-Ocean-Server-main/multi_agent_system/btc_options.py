import pandas as pd
import numpy as np
import requests
import os

import logging
from datetime import datetime, timedelta

import time

import warnings

import sys
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from tqdm import tqdm


import math
from pathlib import Path

import math

from datetime import datetime
import os,  math, time, logging
from datetime import datetime, timedelta
from .config import *
from .deribit_access import *
import sys

warnings.filterwarnings("ignore")
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('Main_file_log.log'),
        logging.StreamHandler()
    ]
)


def create_retry_session(retries=5, backoff_factor=1, status_forcelist=(500, 502, 503, 504)):
    session = requests.Session()
    retry = Retry(
        total=retries,
        read=retries,
        connect=retries,
        backoff_factor=backoff_factor,
        status_forcelist=status_forcelist,
        allowed_methods=["GET"]
    )
    adapter = HTTPAdapter(max_retries=retry)
    session.mount("https://", adapter)
    session.mount("http://", adapter)
    return session

def fetch_all_btc_options_live_data(CFG: dict, days_ahead=DAYS_AHEAD):
    """
    Fetch live BTC options with top-of-book liquidity and qty caps.

    Filters (from CFG):
      - dte_min / dte_max
      - delta_abs_min / delta_abs_max
      - min_vol  (filters by stats.volume when available)

    Adds:
      - qty_max_sell: int floor(best_bid_amount)
      - qty_max_buy : int floor(best_ask_amount)
      - qty         : int min(qty_max_sell, qty_max_buy)
      - min_trade_amount (from instrument meta)
      - contract_multiplier = 1  (Deribit options are 1 BTC/contract)
      - theta_usd_per_day, premium_* fields, POP estimate
    """
    # ---- read config ----
    dte_min = int(CFG.get("dte_min", 0))
    dte_max = int(CFG.get("dte_max", 10_000))

    min_vol = float(CFG.get("min_vol", 0.0))

    session = create_retry_session()
    url_instruments = "https://www.deribit.com/api/v2/public/get_instruments"

    try:
        res = session.get(
            url_instruments,
            params={"currency": "BTC", "kind": "option", "expired": "false"},
            timeout=15,
        )
        res.raise_for_status()
        instruments = res.json().get("result", [])
        logging.info(f"Fetched {len(instruments)} BTC option instruments.")
    except Exception as e:
        logging.error(f"Failed to fetch instrument list: {e}")
        return pd.DataFrame()

    CONTRACT_MULTIPLIER = 1

    # Keep useful per-instrument meta for qty step sizing
    meta_by_name = {}
    for opt in instruments:
        name = opt.get("instrument_name")
        if not name:
            continue
        meta_by_name[name] = {
            "min_trade_amount": opt.get("min_trade_amount"),
            "tick_size": opt.get("tick_size"),
            "block_trade_minimum": opt.get("block_trade_minimum"),
        }

    now = datetime.utcnow()
    max_expiry = now + timedelta(days=days_ahead)

    # ---- Filter by expiry window + DTE BEFORE ticker calls ----
    options = []
    for opt in instruments:
        exp_ts = opt.get("expiration_timestamp")
        if exp_ts is None:
            continue
        exp_dt = datetime.utcfromtimestamp(exp_ts / 1000)

        if not (now <= exp_dt <= max_expiry):
            continue

        dte = (exp_dt - now).days
        if dte < dte_min or dte > dte_max:
            continue

        options.append(opt)

    logging.info(f"Found {len(options)} BTC options after DTE filter [{dte_min},{dte_max}].")

    records = []
    for opt in tqdm(options, desc="Fetching option tickers"):
        name = opt["instrument_name"]
        try:
            ticker_res = session.get(
                "https://www.deribit.com/api/v2/public/ticker",
                params={"instrument_name": name},
                timeout=10,
            )
            ticker_res.raise_for_status()
            data = ticker_res.json().get("result", {}) or {}

            greeks = data.get("greeks", {}) or {}
            stats = data.get("stats", {}) or {}

            # ---- Delta filter AFTER ticker call ----
            delta_val = greeks.get("delta")
            try:
                if delta_val is None:
                    continue
                delta_abs = abs(float(delta_val))

            except Exception:
                continue



            # Top-of-book sizes → integer contract caps
            bid_amt = data.get("best_bid_amount")
            ask_amt = data.get("best_ask_amount")
            try:
                qty_max_sell = int(float(bid_amt or 0.0))
            except Exception:
                qty_max_sell = 0
            try:
                qty_max_buy = int(float(ask_amt or 0.0))
            except Exception:
                qty_max_buy = 0
            qty_book = int(max(0, min(qty_max_sell, qty_max_buy)))

            # Pricing helpers
            underlying_price = data.get("underlying_price")
            mark_price = data.get("mark_price")
            bid_price = data.get("best_bid_price")
            ask_price = data.get("best_ask_price")
            mid_price = (bid_price + ask_price) / 2.0 if (bid_price and ask_price) else None

            # Theta normalization (keep your /100 convention)
            theta_raw = greeks.get("theta")
            theta_btc_per_day = None
            try:
                if theta_raw is not None:
                    theta_btc_per_day = float(theta_raw) / 100.0
            except Exception:
                theta_btc_per_day = None

            # Premium per contract (BTC)
            premium_mark_btc = mark_price
            premium_mid_btc = mid_price

            # Premium per contract (USD)
            premium_mark_usd = None
            premium_mid_usd = None
            if underlying_price and premium_mark_btc is not None:
                premium_mark_usd = premium_mark_btc * underlying_price
            if underlying_price and premium_mid_btc is not None:
                premium_mid_usd = premium_mid_btc * underlying_price

            # Theta in USD per contract per day
            theta_usd_per_day = None
            if underlying_price and theta_btc_per_day is not None:
                theta_usd_per_day = theta_btc_per_day * underlying_price
                

            # POP estimate: 1 - abs(delta)
            pop_est = None
            try:
                pop_est = 1.0 - delta_abs
                if pop_est < 0.0:
                    pop_est = 0.0
                elif pop_est > 1.0:
                    pop_est = 1.0
            except Exception:
                pop_est = None

            records.append({
                "timestamp": datetime.utcnow(),
                "instrument_name": name,
                "expiration": pd.to_datetime(opt["expiration_timestamp"], unit="ms", utc=True),
                "strike": opt.get("strike"),
                "option_type": opt.get("option_type"),

                "mark_price": mark_price,
                "bid_price": bid_price,
                "ask_price": ask_price,
                "mid_price": mid_price,

                "mark_iv": data.get("mark_iv"),
                "bid_iv": data.get("bid_iv"),
                "ask_iv": data.get("ask_iv"),

                "delta": float(delta_val),
                "theta": theta_btc_per_day,
                "vega": greeks.get("vega"),
                "gamma": greeks.get("gamma"),
                "rho": greeks.get("rho"),

                "volume": stats.get("volume"),
                "open_interest": data.get("open_interest"),
                "last_price": data.get("last_price"),
                "underlying_price": underlying_price,

                "bid_size": bid_amt,
                "ask_size": ask_amt,

                "qty_max_sell": qty_max_sell,
                "qty_max_buy": qty_max_buy,
                "qty": qty_book,

                "min_trade_amount": (meta_by_name.get(name) or {}).get("min_trade_amount"),
                "contract_multiplier": CONTRACT_MULTIPLIER,

                "iv": None,  # placeholder

                "premium_mark_btc": premium_mark_btc,
                "premium_mid_btc": premium_mid_btc,
                "premium_mark_usd": premium_mark_usd,
                "premium_mid_usd": premium_mid_usd,
                "theta_usd_per_day": theta_usd_per_day,
                "POP": pop_est,
            })

        except Exception as e:
            logging.warning(f"Failed to fetch ticker for {name}: {e}")
            continue

        time.sleep(0.05)

    df = pd.DataFrame(records)
    logging.info(f"Collected {len(df)} option records after CFG filters.")
    return df


def load_or_fetch_live_options(days_ahead: int, use_cache: bool = True, **kwargs) -> pd.DataFrame:
    """
    Load latest live options from the Parquet snapshot cache.
    If no recent snapshot exists or use_cache=False, fetch fresh from Deribit.
    """
    from .snapshot_pipeline import read_latest_snapshot

    if use_cache:
        try:
            df = read_latest_snapshot()
            if df is not None and not df.empty:
                # Rename snapshot_ts back to timestamp for backward compat
                if "snapshot_ts" in df.columns and "timestamp" not in df.columns:
                    df = df.rename(columns={"snapshot_ts": "timestamp"})

                logging.info("Loaded cached live options from Parquet (%d rows).", len(df))

                iv_col = 'mark_iv' if 'mark_iv' in df.columns else ('iv' if 'iv' in df.columns else None)
                if iv_col:
                    df['ivr_xsec'] = (
                        df.groupby('expiration')[iv_col]
                        .transform(lambda s: (s - s.min()) / (s.max() - s.min() + 1e-9))
                    )
                else:
                    df['ivr_xsec'] = np.nan

                if 'iv_rank' not in df.columns:
                    df['iv_rank'] = df['ivr_xsec']

                return df
        except Exception as e:
            logging.warning("Failed to read Parquet snapshot cache: %s. Fetching fresh.", e)

    # Fallback: fetch fresh from Deribit
    df = fetch_all_btc_options_live_data(CFG=CFG, days_ahead=days_ahead)
    if df is None or df.empty:
        logging.error("No live options returned from Deribit.")
        return pd.DataFrame()

    # Compute ivr_xsec / iv_rank
    iv_col = 'mark_iv' if 'mark_iv' in df.columns else ('iv' if 'iv' in df.columns else None)
    if iv_col:
        df['ivr_xsec'] = (
            df.groupby('expiration')[iv_col]
              .transform(lambda s: (s - s.min()) / (s.max() - s.min() + 1e-9))
        )
    else:
        df['ivr_xsec'] = np.nan
    if 'iv_rank' not in df.columns:
        df['iv_rank'] = df['ivr_xsec']

    return df

# --- Robust retrying session for PRIVATE calls (Auth + bigger pool) ---
def create_retry_session_private(
    retries=5,
    backoff_factor=0.8,
    status_forcelist=(408, 429, 500, 502, 503, 504, 522),
    pool_connections=20,
    pool_maxsize=40,
):
    sess = requests.Session()
    retry = Retry(
        total=retries,
        connect=retries,
        read=retries,
        backoff_factor=backoff_factor,             # exponential backoff: 0.8, 1.6, 3.2, ...
        status_forcelist=status_forcelist,
        allowed_methods=["GET"],                    # we only GET here
        raise_on_status=False,
    )
    adapter = HTTPAdapter(max_retries=retry, pool_connections=pool_connections, pool_maxsize=pool_maxsize)
    sess.mount("https://", adapter)
    sess.mount("http://", adapter)
    # Keep-alive + sane default timeouts via hook
    sess.headers.update({"Connection": "keep-alive", "Accept": "application/json"})
    return sess



def fetch_current_deribit_positions(timeout: int = 12) -> "pd.DataFrame":
    """
    Returns a DataFrame of current BTC option **and BTC-PERPETUAL** positions with enriched fields.
    Also upserts a single JSON/CSV snapshot per day via `_upsert_daily_positions_snapshot`.

    Adds/normalizes columns:
      - qty (abs(size)), side (BUY/SELL)
      - For options: right (C/P), strike, expiration/expiry (UTC), DTE (days, floor)
      - avg_price_btc/usd, mark_price_btc/usd (USD derived if missing: *_btc * index_price)
      - moneyness (options only) = index_price / strike - 1
      - Deribit PnL fields (floating/realized/total in BTC and converted USD), model PnL, pnl_pct
      - For perpetuals: kind='perpetual', is_perpetual=True, no strike/right/expiry (NaT), DTE=0
    """
    import re, time, logging, json, sqlite3, os, sys
    from pathlib import Path
    import numpy as np
    import pandas as pd
    import requests

    # ----- helpers -----
    MON = {"JAN":1,"FEB":2,"MAR":3,"APR":4,"MAY":5,"JUN":6,"JUL":7,"AUG":8,"SEP":9,"OCT":10,"NOV":11,"DEC":12}

    def parse_expiry_from_symbol(sym: str) -> "pd.Timestamp":
        # BTC-29AUG25-65000-C  ->  2025-08-29 08:00:00+00:00
        s = str(sym).upper().strip()
        m = re.match(r"^(BTC|ETH)-(\d{2})([A-Z]{3})(\d{2})-", s)
        if not m:
            return pd.NaT
        dd, mon_str, yy = int(m.group(2)), m.group(3), 2000 + int(m.group(4))
        mon = MON.get(mon_str, 0)
        if mon == 0:
            return pd.NaT
        return pd.Timestamp(year=yy, month=mon, day=dd, hour=8, tz="UTC")  # Deribit opts expire ~08:00 UTC

    def parse_strike_right_from_symbol(sym: str):
        # ...-65000-C or ...-35000-P
        s = str(sym).upper().strip()
        m = re.search(r"-(\d+)-(C|P)$", s)
        if not m:
            return (np.nan, None)
        return (float(m.group(1)), m.group(2))

    # ----- 0) AUTH -----
    try:
        token = get_access_token()  # your existing helper
    except Exception as e:
        logging.error(f"Auth failed, cannot fetch positions: {e}")
        df_empty = pd.DataFrame(columns=[
            "instrument_name","symbol","qty","side","direction","kind","strike","option_type",
            "expiration","expiry","DTE","right","is_perpetual",
            "size","average_price","average_price_usd","avg_price_btc","avg_price_usd",
            "mark_price","mark_price_btc","mark_price_usd","mark_usd","index_price",
            "delta","delta_raw","delta_norm","gamma","vega","theta",
            "maintenance_margin","initial_margin",
            "floating_profit_loss","realized_profit_loss","total_profit_loss",
            "moneyness","pnl_usd_per_contract","pnl_usd_total","pnl_pct"
        ])
        _upsert_daily_positions_snapshot(df_empty)
        return df_empty

    # ----- 1) SESSION -----
    session = create_retry_session_private()
    session.headers.update({"Authorization": f"Bearer {token}", "User-Agent": "btc-multi-agent/1.0"})

    # Endpoints & params
    url_positions = "https://www.deribit.com/api/v2/private/get_positions"
    opt_params    = {"currency": "BTC", "kind": "option"}
    fut_params    = {"currency": "BTC", "kind": "future"}   # we'll filter BTC-PERPETUAL from here

    def _fetch_positions(params):
        attempts, last_exc = 3, None
        for i in range(attempts):
            try:
                resp = session.get(url_positions, params=params, timeout=timeout)
                if resp.status_code in (401, 403):
                    logging.info("Token expired; refreshing once and retrying.")
                    tok2 = get_access_token()
                    session.headers.update({"Authorization": f"Bearer {tok2}"})
                    resp = session.get(url_positions, params=params, timeout=timeout)
                resp.raise_for_status()
                out = resp.json().get("result", [])
                # logging.info(out)
                if not isinstance(out, list):
                    out = []
                return out
            except (requests.exceptions.ConnectTimeout,
                    requests.exceptions.ReadTimeout,
                    requests.exceptions.ConnectionError) as e:
                last_exc = e
                wait_s = (1.5 ** i) + np.random.uniform(0, 0.5)
                logging.warning("Positions fetch attempt %d/%d failed: %s; retrying in %.2fs",
                                i+1, attempts, str(e), wait_s)
                time.sleep(wait_s)
            except Exception as e:
                last_exc = e
                logging.error(f"Failed to fetch positions: {e}")
                break
        logging.error("Giving up fetching positions." + (f" Last error: {last_exc}" if last_exc else ""))
        return []

    # ----- 2) FETCH options & perpetual -----
    opt_result = _fetch_positions(opt_params)
    fut_result = _fetch_positions(fut_params)  # contains dated futures + perpetual (BTC-PERPETUAL)

    # Keep only BTC-PERPETUAL from futures block
    perp_result = [r for r in (fut_result or []) if str(r.get("instrument_name","")).upper().strip() == "BTC-PERPETUAL"]

    # ----- 2a) Build records (options first, same as your original) -----
    recs = []
    for r in (opt_result or []):
        symbol = str(r.get("instrument_name") or "").upper().strip()
        # sizes & side
        size = pd.to_numeric(r.get("size"), errors="coerce")
        if pd.isna(size): size = 0.0
        qty  = abs(float(size))
        direction = str(r.get("direction") or "").lower()
        side = "SELL" if direction == "sell" else ("BUY" if direction == "buy" else ("SELL" if size < 0 else "BUY" if size > 0 else ""))

        # prices (BTC & USD where present)
        mark_btc = pd.to_numeric(r.get("mark_price"), errors="coerce")
        avg_btc  = pd.to_numeric(r.get("average_price"), errors="coerce")
        idx_px   = pd.to_numeric(r.get("index_price"), errors="coerce")

        avg_usd_api  = pd.to_numeric(r.get("average_price_usd"), errors="coerce")
        mark_usd_api = pd.to_numeric(r.get("mark_price_usd"), errors="coerce")

        # derive USD if missing and we have index
        avg_usd = avg_usd_api
        if (not np.isfinite(avg_usd)) and np.isfinite(avg_btc) and np.isfinite(idx_px):
            avg_usd = float(avg_btc) * float(idx_px)

        mark_usd = mark_usd_api
        if (not np.isfinite(mark_usd)) and np.isfinite(mark_btc) and np.isfinite(idx_px):
            mark_usd = float(mark_btc) * float(idx_px)

        # strike / right
        strike = pd.to_numeric(r.get("strike"), errors="coerce")
        right  = r.get("option_type")
        right  = (str(right).strip().upper() if right is not None else None)
        if right not in ("C","P"):
            if str(r.get("option_type")).lower().startswith("c"):
                right = "C"
            elif str(r.get("option_type")).lower().startswith("p"):
                right = "P"

        if (not np.isfinite(strike)) or strike <= 0 or right not in ("C","P"):
            s_strike, s_right = parse_strike_right_from_symbol(symbol)
            if (not np.isfinite(strike)) or strike <= 0:
                strike = s_strike
            if right not in ("C","P"):
                right = s_right
        
        _mark_iv = np.nan
        try:
            _tk_resp = session.get(
                "https://www.deribit.com/api/v2/public/ticker",
                params={"instrument_name": symbol},
                timeout=8,
            )
            if _tk_resp.status_code == 200:
                _tk_data = _tk_resp.json().get("result", {}) or {}
                _miv = _tk_data.get("mark_iv")
                if _miv is not None:
                    _mark_iv = float(_miv)
            time.sleep(0.03)
        except Exception:
            pass

        recs.append({
            "instrument_name": symbol,
            "symbol": symbol,
            "kind": r.get("kind"),                 # 'option'
            "is_perpetual": False,
            "direction": r.get("direction"),
            "side": side,
            "size": float(size),                   # signed
            "qty": qty,                            # abs
            "strike": strike,
            "option_type": r.get("option_type"),
            "average_price": avg_btc,
            "average_price_usd": avg_usd_api,
            "avg_price_btc": avg_btc,
            "avg_price_usd": avg_usd,
            "mark_price": mark_btc,
            "mark_price_btc": mark_btc,
            "mark_price_usd": mark_usd_api,
            "mark_usd": mark_usd,
            "index_price": idx_px,
            "delta": r.get("delta"),
            "gamma": r.get("gamma"),
            "vega": r.get("vega"),
            "theta": r.get("theta"),
            "mark_iv": _mark_iv,
            "maintenance_margin": r.get("maintenance_margin"),
            "initial_margin": r.get("initial_margin"),
            "floating_profit_loss": r.get("floating_profit_loss"),
            "realized_profit_loss": r.get("realized_profit_loss"),
            "total_profit_loss": r.get("total_profit_loss"),
            "right": right,                        # C / P
        })

    # ----- 2b) Build records (perpetual) -----
    for r in (perp_result or []):
        symbol = str(r.get("instrument_name") or "").upper().strip()  # 'BTC-PERPETUAL'
        size = pd.to_numeric(r.get("size"), errors="coerce")
        if pd.isna(size): size = 0.0
        qty  = abs(float(size))
        direction = str(r.get("direction") or "").lower()
        side = "SELL" if direction == "sell" else ("BUY" if direction == "buy" else ("SELL" if size < 0 else "BUY" if size > 0 else ""))

        # NOTE: Deribit futures/perp prices are quoted in USD.
        avg_usd = pd.to_numeric(r.get("average_price"), errors="coerce")
        mark_usd = pd.to_numeric(r.get("mark_price"), errors="coerce")
        idx_px   = pd.to_numeric(r.get("index_price"), errors="coerce")

        # For schema uniformity, back-compute *_btc for perps (avg_usd / index)
        avg_btc = np.nan
        if np.isfinite(avg_usd) and np.isfinite(idx_px) and (idx_px != 0):
            avg_btc = float(avg_usd) / float(idx_px)
        mark_btc = np.nan
        if np.isfinite(mark_usd) and np.isfinite(idx_px) and (idx_px != 0):
            mark_btc = float(mark_usd) / float(idx_px)

        recs.append({
            "instrument_name": symbol,
            "symbol": symbol,
            "kind": "perpetual",                  # normalize for downstream logic
            "is_perpetual": True,
            "direction": r.get("direction"),
            "side": side,
            "size": float(size),                  # signed
            "qty": qty,
            # No strike/right for perp
            "strike": np.nan,
            "option_type": None,
            "right": None,
            # price mapping to unified columns
            "average_price": avg_btc,            # keep your original alias (BTC)
            "average_price_usd": avg_usd,        # for reference
            "avg_price_btc": avg_btc,
            "avg_price_usd": avg_usd,
            "mark_price": mark_btc,
            "mark_price_btc": mark_btc,
            "mark_price_usd": mark_usd,
            "mark_usd": mark_usd,
            "index_price": idx_px,
            # Greeks don't apply to perp
            "delta": np.nan, "gamma": np.nan, "vega": np.nan, "theta": np.nan,
            "mark_iv": np.nan,
            "maintenance_margin": r.get("maintenance_margin"),
            "initial_margin": r.get("initial_margin"),
            "floating_profit_loss": r.get("floating_profit_loss"),
            "realized_profit_loss": r.get("realized_profit_loss"),
            "total_profit_loss": r.get("total_profit_loss"),
            # expiry fields will be NaT later
        })

    df = pd.DataFrame(recs)
    # df.to_csv("debug_positions_combined_raw.csv", index=False)
    # # Debug dump (safe)
    # try:
    #     df.to_csv("debug_positions_raw.csv", index=False)
    # except Exception:
    #     pass

    logging.info("Fetched %d option rows and %d perpetual rows.", len(opt_result), len(perp_result))

    # If nothing, still snapshot & exit
    if df.empty:
        _upsert_daily_positions_snapshot(df)
        try:
            Path("current_positions").mkdir(parents=True, exist_ok=True)
            df.to_csv("current_positions/current_positions.csv", index=False)
        except Exception:
            pass
        return df

    # ----- 3) DERIVED FIELDS -----
    now_utc = pd.Timestamp.now(tz="UTC")

    # expiration/expiry (options only)
    exp = pd.Series(pd.NaT, index=df.index, dtype="datetime64[ns, UTC]")
    need_exp = df["instrument_name"].notna() & df["instrument_name"].str.contains(r"^(BTC|ETH)-\d{2}[A-Z]{3}\d{2}-", regex=True)
    if need_exp.any():
        exp.loc[need_exp] = df.loc[need_exp, "instrument_name"].map(parse_expiry_from_symbol)

    df["expiration"] = exp
    df["expiry"]     = exp

    # DTE (floor, non-negative); perps will be 0
    dte_float = ((df["expiration"] - now_utc).dt.total_seconds() / 86400.0)
    df["DTE"] = np.maximum(0, np.floor(dte_float.fillna(0)).astype(int))

    # Right (C/P) final fallback from symbol (options only)
    still_need_right = df["right"].isna() & (df["kind"] != "perpetual")
    if still_need_right.any():
        df.loc[still_need_right, "right"] = df.loc[still_need_right, "instrument_name"].map(lambda s: parse_strike_right_from_symbol(s)[1])

    # BUY/SELL normalization (prefer direction)
    dir_ser = df.get("direction").fillna("").astype(str).str.lower()
    df["side"] = np.where(dir_ser.eq("sell"), "SELL",
                   np.where(dir_ser.eq("buy"), "BUY", df["side"]))

    # Ensure numerics
    for col in ["avg_price_btc","avg_price_usd","mark_price_btc","mark_usd","mark_price_usd",
                "index_price","strike","size","qty",
                "floating_profit_loss","realized_profit_loss","total_profit_loss",
                "delta","gamma","vega","theta",
                "maintenance_margin","initial_margin"]:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce")

    # Fill USD conversions if still missing (options path)
    idx = df["index_price"]
    need_mark_usd = df["mark_usd"].isna() & df["mark_price_btc"].notna() & idx.notna()
    df.loc[need_mark_usd, "mark_usd"] = df.loc[need_mark_usd, "mark_price_btc"] * df.loc[need_mark_usd, "index_price"]

    need_avg_usd = df["avg_price_usd"].isna() & df["avg_price_btc"].notna() & idx.notna()
    df.loc[need_avg_usd, "avg_price_usd"]  = df.loc[need_avg_usd,  "avg_price_btc"]  * df.loc[need_avg_usd,  "index_price"]

    # Moneyness (options only)
    df["moneyness"] = np.nan
    has_strike = df["strike"].notna() & (df["strike"].astype(float) > 0)
    df.loc[(df["kind"] != "perpetual") & has_strike & idx.notna(), "moneyness"] = \
        (df.loc[(df["kind"] != "perpetual") & has_strike, "index_price"] / df.loc[(df["kind"] != "perpetual") & has_strike, "strike"]) - 1.0

    # Deribit-accurate PnL (BTC → USD via index price)
    for c in ["index_price", "floating_profit_loss", "realized_profit_loss", "total_profit_loss"]:
        if c in df.columns:
            df[c] = pd.to_numeric(df[c], errors="coerce")

    idx = pd.to_numeric(df.get("index_price"), errors="coerce")
    df["pnl_btc_total_deribit"]    = pd.to_numeric(df.get("total_profit_loss"), errors="coerce")
    df["pnl_btc_floating_deribit"] = pd.to_numeric(df.get("floating_profit_loss"), errors="coerce")
    df["pnl_btc_realized_deribit"] = pd.to_numeric(df.get("realized_profit_loss"), errors="coerce")

    df["pnl_usd_total_deribit"]    = df["pnl_btc_total_deribit"]    * idx
    df["pnl_usd_floating_deribit"] = df["pnl_btc_floating_deribit"] * idx
    df["pnl_usd_realized_deribit"] = df["pnl_btc_realized_deribit"] * idx
    df["pnl_usd_total"] = df["pnl_usd_total_deribit"]

    # Additional diagnostics (per-contract model calc)
    avg_usd   = pd.to_numeric(df.get("avg_price_usd"), errors="coerce")
    mark_usd  = pd.to_numeric(df.get("mark_usd"), errors="coerce")
    qty_ser   = pd.to_numeric(df.get("qty"), errors="coerce")
    side_ser  = df.get("side", "").astype(str).str.upper()
    is_sell   = side_ser.eq("SELL")

    delta_usd = mark_usd - avg_usd
    ok = delta_usd.notna() & avg_usd.notna()

    df["pnl_usd_per_contract"] = np.nan
    df.loc[ok, "pnl_usd_per_contract"] = np.where(is_sell, -delta_usd, delta_usd)

    df["pnl_usd_total_model"] = np.nan
    df.loc[ok, "pnl_usd_total_model"] = df.loc[ok, "pnl_usd_per_contract"] * qty_ser

    df["pnl_pct"] = np.nan
    denom = avg_usd.abs()
    safe = ok & (denom > 1e-12)
    df.loc[safe, "pnl_pct"] = (df.loc[safe, "pnl_usd_per_contract"] / denom[safe]) * 100.0

    # Tidy/ordering (optional)
    order_cols = [
        "instrument_name","symbol","kind","is_perpetual","right","strike",
        "direction","side","size","qty",
        "expiration","expiry","DTE",
        "index_price",
        "avg_price_btc","avg_price_usd",
        "mark_price_btc","mark_usd","mark_price_usd",
        "delta","gamma","vega","theta",
        "maintenance_margin","initial_margin",
        "floating_profit_loss","realized_profit_loss","total_profit_loss",
        "moneyness","pnl_usd_per_contract","pnl_usd_total","pnl_pct"
    ]
    df = df[[c for c in order_cols if c in df.columns] + [c for c in df.columns if c not in order_cols]]

    # ----- FILTER OUT zero-qty / zero-avg-price rows -----
    _before = len(df)
    mask_qty = df["qty"].fillna(0).astype(float) != 0
    # Options: require avg_price_btc != 0; Perp: require avg_price_usd != 0
    mask_opt = (df["kind"] != "perpetual") & (df["avg_price_btc"].fillna(0).astype(float) != 0)
    mask_perp = (df["kind"] == "perpetual") & (df["avg_price_usd"].fillna(0).astype(float) != 0)
    df = df.loc[mask_qty & (mask_opt | mask_perp)].copy()
    dropped = _before - len(df)
    if dropped > 0:
        logging.info("Filtered out %d rows with zero qty or zero avg price.", dropped)

    # ----- 4) SNAPSHOT & SAVE -----
    _upsert_daily_positions_snapshot(df)
    try:
        Path("current_positions").mkdir(parents=True, exist_ok=True)
        df.to_csv("current_positions/current_positions.csv", index=False)
    except Exception as e_w:
        logging.warning(f"Could not write positions CSV: {e_w}")

    return df

# ═══════════════════════════════════════════════════════════════════
# REPLACE fetch_trade_types() in btc_options.py with this version
# Uses get_transaction_log (which works) instead of get_user_trades (which doesn't)
# ═══════════════════════════════════════════════════════════════════

def fetch_trade_types(days_back: int = 90) -> dict:
    """
    Returns {instrument_name: {"order_type": str, "trades": [...]}} for all trades.

    Uses /private/get_transaction_log which returns:
      - type: "trade" for actual trades
      - side: "open buy", "open sell", "close buy", "close sell",
              "liquidation buy", "liquidation sell"
      - info: "Source: autoliquidation" for system-forced closes

    Returns dict like:
      {
        "BTC-25DEC26-60000-P": {
            "has_liquidation": True,
            "trades": [
                {"side": "liquidation buy", "amount": 2.0, "price": 0.109, "timestamp": ..., "trade_id": ...},
                {"side": "open sell", "amount": 6.0, "price": 0.0399, ...},
            ]
        },
        "BTC-29MAY26-73000-C": {
            "has_liquidation": False,
            "trades": [...]
        },
      }
    """
    try:
        token = get_access_token()
    except Exception:
        return {}

    session = create_retry_session_private()
    session.headers.update({"Authorization": f"Bearer {token}"})

    url = "https://www.deribit.com/api/v2/private/get_transaction_log"
    now_ms = int(time.time() * 1000)
    start_ms = now_ms - (days_back * 24 * 60 * 60 * 1000)

    result = {}
    continuation = None
    page = 0
    max_pages = 100

    while page < max_pages:
        params = {
            "currency": "BTC",
            "start_timestamp": start_ms,
            "end_timestamp": now_ms,
            "count": 100,
        }
        if continuation:
            params["continuation"] = continuation

        try:
            resp = session.get(url, params=params, timeout=15)
            if resp.status_code in (401, 403):
                token = get_access_token()
                session.headers.update({"Authorization": f"Bearer {token}"})
                resp = session.get(url, params=params, timeout=15)
            resp.raise_for_status()

            data = resp.json().get("result", {})
            logs = data.get("logs", [])
            continuation = data.get("continuation")

            if not logs:
                break

            for entry in logs:
                if entry.get("type") != "trade":
                    continue

                iname = entry.get("instrument_name", "")
                if not iname:
                    continue

                side = str(entry.get("side") or "").lower()
                info = str(entry.get("info") or "").lower()
                is_liq = "liquidation" in side or "autoliquidation" in info

                trade_record = {
                    "trade_id": entry.get("trade_id"),
                    "timestamp": entry.get("timestamp"),
                    "side": entry.get("side"),
                    "amount": entry.get("amount"),
                    "price": entry.get("price"),
                    "index_price": entry.get("index_price"),
                    "commission": entry.get("commission"),
                    "info": entry.get("info"),
                    "is_liquidation": is_liq,
                }

                if iname not in result:
                    result[iname] = {"has_liquidation": False, "trades": []}

                result[iname]["trades"].append(trade_record)
                if is_liq:
                    result[iname]["has_liquidation"] = True

            if not continuation:
                break

            page += 1
            time.sleep(0.05)

        except Exception:
            break

    return result

def _upsert_daily_positions_snapshot(df: pd.DataFrame) -> None:
    """Create/overwrite a single row per day in SQLite (or path given by POSITIONS_DB_PATH)."""
    import sqlite3, os, json
    import numpy as np
    from shared.db_paths import MARKET_DATA_DB

    db_path = str(MARKET_DATA_DB)
    tz_name = os.getenv("POSITIONS_DAY_TZ", "UTC")

    now_utc = pd.Timestamp.now(tz="UTC")
    # Use configured timezone for the daily key (e.g., 'Africa/Cairo'); fallback to UTC on error
    try:
        now_local = now_utc.tz_convert(tz_name)
    except Exception:
        now_local = now_utc

    date_key = now_local.strftime("%Y-%m-%d")
    snapshot_ts = now_utc.isoformat()

    # Aggregate PnL (safe to 0.0 if columns missing)
    def safe_sum(colname: str) -> float:
        if colname in df.columns:
            return float(pd.to_numeric(df[colname], errors="coerce").fillna(0.0).sum())
        return 0.0

    rows_count = int(len(df))
    pnl_total = safe_sum("total_profit_loss")
    pnl_float = safe_sum("floating_profit_loss")
    pnl_real  = safe_sum("realized_profit_loss")

    payload = "[]"
    try:
        # keep the raw dict records; avoid NaN (use None) for JSON portability
        payload = json.dumps(json.loads(df.to_json(orient="records")), ensure_ascii=False)
    except Exception:
        # very defensive; if conversion fails, still save basic info
        payload = "[]"

    con = sqlite3.connect(db_path)
    try:
        con.execute("""
            CREATE TABLE IF NOT EXISTS deribit_current_positions_daily (
                date_key     TEXT PRIMARY KEY,
                snapshot_ts  TEXT NOT NULL,
                rows_count   INTEGER NOT NULL,
                pnl_total    REAL,
                pnl_float    REAL,
                pnl_realized REAL,
                payload      TEXT NOT NULL
            )
        """)
        con.execute("""
            INSERT INTO deribit_current_positions_daily
                (date_key, snapshot_ts, rows_count, pnl_total, pnl_float, pnl_realized, payload)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(date_key) DO UPDATE SET
                snapshot_ts  = excluded.snapshot_ts,
                rows_count   = excluded.rows_count,
                pnl_total    = excluded.pnl_total,
                pnl_float    = excluded.pnl_float,
                pnl_realized = excluded.pnl_realized,
                payload      = excluded.payload
        """, (date_key, snapshot_ts, rows_count, pnl_total, pnl_float, pnl_real, payload))
        con.commit()
    finally:
        con.close()

def fetch_and_save_daily_live_options(*, days_ahead: int) -> pd.DataFrame:
    """
    Fetch fresh live options and persist via the snapshot Parquet pipeline.
    """
    from .snapshot_pipeline import run_snapshot_pipeline

    result = run_snapshot_pipeline(days_ahead=days_ahead)
    rows = sum(result.get("files_written", {}).values())
    logging.info("Snapshot pipeline wrote %d rows", rows)

    # Return the fresh data for callers that expect a DataFrame
    return load_or_fetch_live_options(days_ahead=days_ahead, use_cache=True)


def mark_live_options_schedule_ran(
    *,
    date_key: str,
    db_path: str = "",
) -> None:
    import sqlite3
    from datetime import datetime, timezone
    from shared.db_paths import INFRA_DB

    # ``live_options_schedule`` is owned by the scheduler in
    # backend_api/jobs.py (INFRA_DB). The ``db_path`` parameter is kept
    # for backward compatibility but ignored.
    now_utc = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

    con = sqlite3.connect(str(INFRA_DB))
    try:
        con.execute("""
        UPDATE live_options_schedule
           SET last_run_at_utc = ?,
               last_run_date_key = ?
         WHERE id = 1;
        """, (now_utc, date_key))
        con.commit()
    finally:
        con.close()


if __name__== "__main__":

    print(fetch_current_deribit_positions())