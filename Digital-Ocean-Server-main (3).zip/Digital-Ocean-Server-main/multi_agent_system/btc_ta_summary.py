"""
btc_ta_summary.py

Compute a compact technical analysis summary for BTC from the `btc_prices`
table in btc_trading.sqlite, to be used as context in LLM agents.

Intended usage (from multi_agents.py):

    from btc_ta_summary import get_btc_ta_summary

    ta_summary = get_btc_ta_summary()
    # pass ta_summary into fundamental / sentiment agents

"""

import logging
import os
import sqlite3
from typing import Optional

import numpy as np
import pandas as pd
from .config import DB_PATH

# ---------------------------------------------------------------------
# DB path helper (mirror Streamlit/data_service.py logic)
# ---------------------------------------------------------------------

DB_PATH_DEFAULT = DB_PATH


# ---------------------------------------------------------------------
# Core public function
# ---------------------------------------------------------------------

def get_btc_ta_summary(db_path: Optional[str] = None, lookback_days: int = 200) -> str:
    """
    Load BTC daily prices from SQLite, compute a few TA indicators, and return
    a short text summary for LLM prompts.

    Parameters
    ----------
    db_path : Optional[str]
        Path to btc_trading.sqlite. If None, use project-root default.
    lookback_days : int
        How many days of history to use for Fib & Ichimoku context.
        (Needs at least ~200 days to be meaningful.)

    Returns
    -------
    summary : str
        One or two sentences, e.g.:
        "As of 2025-11-25 close 87,906: uptrend (price above EMA200 and EMA50, EMA21 > EMA50),
         RSI 62 (neutral-high), price above Ichimoku cloud, near 1.618 Fib resistance (~90,500)."
    """
    path = db_path or DB_PATH_DEFAULT

    df = _load_btc_prices(path)
    if df is None or df.empty:
        return "Technical summary unavailable (no btc_prices data found)."

    # Restrict to last N days for TA context (but EMAs/RSI still based on full history)
    df_full = df.copy()
    df = df_full.copy()
    if len(df) > lookback_days:
        df = df.iloc[-lookback_days:].copy()

    # Compute indicators on full history (for stable EMAs / RSI)
    df_full = _add_ema_rsi(df_full)
    df_full = _add_ichimoku(df_full)
    fib_info = _compute_fib_levels(df)

    # Use the last fully-valid row
    last = df_full.dropna(subset=["close"]).iloc[-1]

    trend_text = _build_trend_text(last)
    rsi_text = _build_rsi_text(last)
    ichimoku_text = _build_ichimoku_text(df_full)
    fib_text = _build_fib_text(last, fib_info)

    date_str = str(last["date"].date())
    close_str = _fmt_price(last["close"])

    parts = [
        f"As of {date_str} close {close_str}:",
        trend_text,
        rsi_text,
        ichimoku_text,
        fib_text,
    ]
    # Remove empty fragments and join nicely
    parts = [p for p in parts if p]
    return " ".join(parts)


# ---------------------------------------------------------------------
# Data loading
# ---------------------------------------------------------------------

def _load_btc_prices(db_path: str) -> Optional[pd.DataFrame]:
    """
    Read btc_prices table from SQLite.

    Expected schema (from your description):

        date (TEXT, YYYY-MM-DD)
        open, high, low, close, change, percent_change, volume (FLOAT)
    """
    if not os.path.exists(db_path):
        return None

    try:
        with sqlite3.connect(db_path) as conn:
            df = pd.read_sql_query(
                "SELECT date, open, high, low, close, volume FROM btc_prices ORDER BY date ASC",
                conn,
            )
    except Exception:
        return None

    if df.empty:
        return None

    # Parse date and ensure numeric columns are clean
    df["date"] = pd.to_datetime(df["date"])
    for col in ["open", "high", "low", "close", "volume"]:
        df[col] = pd.to_numeric(df[col], errors="coerce")

    df = df.dropna(subset=["close"])
    df = df.reset_index(drop=True)
    return df


# ---------------------------------------------------------------------
# Indicator calculations
# ---------------------------------------------------------------------

def _add_ema_rsi(df: pd.DataFrame) -> pd.DataFrame:
    """
    Add EMA21, EMA50, EMA200 and RSI(14) columns.
    """
    out = df.copy()

    for span in (21, 50, 200):
        out[f"ema_{span}"] = out["close"].ewm(span=span, adjust=False).mean()

    out["rsi_14"] = _compute_rsi(out["close"], period=14)
    return out


def _compute_rsi(series: pd.Series, period: int = 14) -> pd.Series:
    """
    Classic RSI implementation on closing prices.
    """
    delta = series.diff()
    gain = delta.clip(lower=0.0)
    loss = -delta.clip(upper=0.0)

    avg_gain = gain.rolling(window=period, min_periods=period).mean()
    avg_loss = loss.rolling(window=period, min_periods=period).mean()

    # Wilder's smoothing
    avg_gain = avg_gain.ewm(alpha=1 / period, adjust=False).mean()
    avg_loss = avg_loss.ewm(alpha=1 / period, adjust=False).mean()

    rs = avg_gain / (avg_loss.replace(0, np.nan))
    rsi = 100 - (100 / (1 + rs))
    return rsi


def _add_ichimoku(df: pd.DataFrame) -> pd.DataFrame:
    """
    Add simple Ichimoku components:

    - tenkan_sen (9-period midpoint)
    - kijun_sen (26-period midpoint)
    - senkou_span_a, senkou_span_b (shifted forward, but we care about
      current cloud values to classify "above / inside / below cloud")
    """
    out = df.copy()

    high = out["high"]
    low = out["low"]

    period_tenkan = 9
    period_kijun = 26
    period_senkou_b = 52
    shift = 26

    tenkan_sen = (high.rolling(window=period_tenkan).max() +
                  low.rolling(window=period_tenkan).min()) / 2
    kijun_sen = (high.rolling(window=period_kijun).max() +
                 low.rolling(window=period_kijun).min()) / 2

    senkou_span_a = ((tenkan_sen + kijun_sen) / 2).shift(shift)
    senkou_span_b = ((high.rolling(window=period_senkou_b).max() +
                      low.rolling(window=period_senkou_b).min()) / 2).shift(shift)

    out["tenkan_sen"] = tenkan_sen
    out["kijun_sen"] = kijun_sen
    out["senkou_span_a"] = senkou_span_a
    out["senkou_span_b"] = senkou_span_b

    return out


def _compute_fib_levels(df: pd.DataFrame, window: int = 120) -> dict:
    """
    Compute simple Fib retracement + 1.618 extension from last N days.

    Returns dict with:
        {
          "swing_low": float,
          "swing_high": float,
          "levels": {
              "0.382": value,
              "0.5": value,
              "0.618": value,
              "1.0": value,
              "1.618": value,
          }
        }
    """
    if df.empty:
        return {}

    tail = df.iloc[-min(len(df), window):]
    swing_low = float(tail["low"].min())
    swing_high = float(tail["high"].max())
    diff = swing_high - swing_low
    if diff <= 0:
        return {}

    levels = {
        "0.382": swing_high - 0.382 * diff,
        "0.5": swing_high - 0.5 * diff,
        "0.618": swing_high - 0.618 * diff,
        "1.0": swing_high,
        "1.618": swing_high + 0.618 * diff,
    }
    return {"swing_low": swing_low, "swing_high": swing_high, "levels": levels}


# ---------------------------------------------------------------------
# Text builders
# ---------------------------------------------------------------------

def _build_trend_text(row: pd.Series) -> str:
    """
    Summarize trend using EMAs.
    """
    close = row["close"]
    ema21 = row.get("ema_21", np.nan)
    ema50 = row.get("ema_50", np.nan)
    ema200 = row.get("ema_200", np.nan)

    if np.isnan(ema21) or np.isnan(ema50) or np.isnan(ema200):
        return "trend unclear (insufficient EMA history)."

    parts = []

    if close > ema200 and close > ema50:
        parts.append("uptrend")
    elif close < ema200 and close < ema50:
        parts.append("downtrend")
    else:
        parts.append("sideways trend")

    # EMA alignment
    if ema21 > ema50 > ema200:
        parts.append("(EMA21 > EMA50 > EMA200)")
    elif ema21 < ema50 < ema200:
        parts.append("(EMA21 < EMA50 < EMA200)")

    return " ".join(parts) + ","


def _build_rsi_text(row: pd.Series) -> str:
    rsi = row.get("rsi_14", np.nan)
    if np.isnan(rsi):
        return "RSI unavailable,"

    rsi_val = float(round(rsi, 1))
    if rsi_val >= 70:
        zone = "overbought"
    elif rsi_val <= 30:
        zone = "oversold"
    elif 55 <= rsi_val < 70:
        zone = "bullish momentum"
    elif 30 < rsi_val <= 45:
        zone = "bearish momentum"
    else:
        zone = "neutral"

    return f"RSI {rsi_val} ({zone}),"


def _build_ichimoku_text(df: pd.DataFrame) -> str:
    """
    Classify price vs cloud: above / inside / below.
    """
    last = df.dropna(subset=["close", "senkou_span_a", "senkou_span_b"])
    if last.empty:
        return "Ichimoku cloud signal unavailable,"

    last = last.iloc[-1]
    close = last["close"]
    a = last["senkou_span_a"]
    b = last["senkou_span_b"]
    cloud_top = max(a, b)
    cloud_bottom = min(a, b)

    if close > cloud_top:
        state = "above the Ichimoku cloud"
    elif close < cloud_bottom:
        state = "below the Ichimoku cloud"
    else:
        state = "inside the Ichimoku cloud"

    return f"price is {state},"


def _build_fib_text(row: pd.Series, fib_info: dict, proximity_pct: float = 1.0) -> str:
    """
    Describe if price is near any key Fib levels (within +/- proximity_pct %).
    """
    if not fib_info or "levels" not in fib_info:
        return ""

    close = float(row["close"])
    levels = fib_info["levels"]

    nearest_name = None
    nearest_val = None
    nearest_diff_pct = None

    for name, val in levels.items():
        diff_pct = abs(close - val) / val * 100
        if nearest_diff_pct is None or diff_pct < nearest_diff_pct:
            nearest_name = name
            nearest_val = val
            nearest_diff_pct = diff_pct

    if nearest_name is None or nearest_diff_pct is None:
        return ""

    if nearest_diff_pct <= proximity_pct:
        level_type = "support/resistance"
        if nearest_name == "1.618":
            level_type = "Fib extension resistance"
        level_price = _fmt_price(nearest_val)
        return f"trading near Fib {nearest_name} {level_type} (~{level_price})."
    else:
        logging.info("Price not near any Fib levels (nearest %s at %.2f%% away).",
                     nearest_name, nearest_diff_pct)
        return ""


def _fmt_price(x: float) -> str:
    """
    Format price with thousands separator, no or few decimals.
    """
    if np.isnan(x):
        return "NaN"
    if abs(x) >= 100:
        return f"{x:,.0f}"
    return f"{x:,.2f}"


if __name__ == "__main__":
    """
    Simple manual test:
    - Reads btc_prices from btc_trading.sqlite using the default DB path.
    - Prints the technical analysis summary string.
    """
    summary = get_btc_ta_summary()
    print("=== BTC Technical Analysis Summary ===")
    print(summary)
