# llm_io.py
from __future__ import annotations

import json
import os
import re
import time
from typing import Any, Dict, Optional, Tuple, Sequence, Callable
from .config import *
import requests  # make sure requests is installed

__all__ = [
    "_extract_json_str",
    "_usage_from_resp",
    "_estimate_tokens_by_chars",
    "make_llm_client",
    "LLMError",
]
def _to_int(x, default=0):
    try:
        if x is None:
            return default
        # some providers return strings
        return int(float(x))
    except Exception:
        return default

# --- Exceptions & Pricing -----------------------------------------------------

class LLMError(RuntimeError):
    pass

# Per-1K token prices (USD). Edit to your real rates.
PRICING = {
    # OpenAI
    ("openai", "gpt-5"): {
        "in":  float(os.getenv("PRICE_OPENAI_GPT5_IN",        "0.00125")),
        "out": float(os.getenv("PRICE_OPENAI_GPT5_OUT",       "0.01")),
    },
    ("openai", "gpt-5-mini"): {
        "in":  float(os.getenv("PRICE_OPENAI_GPT5_MINI_IN",   "0.00025")),
        "out": float(os.getenv("PRICE_OPENAI_GPT5_MINI_OUT",  "0.001")),
    },
    ("openai", "gpt-4o"): {
        "in":  float(os.getenv("PRICE_OPENAI_GPT4O_IN",       "0.0025")),
        "out": float(os.getenv("PRICE_OPENAI_GPT4O_OUT",      "0.01")),
    },
    ("openai", "gpt-4o-mini"): {
        "in":  float(os.getenv("PRICE_OPENAI_GPT4O_MINI_IN",  "0.00015")),
        "out": float(os.getenv("PRICE_OPENAI_GPT4O_MINI_OUT", "0.0006")),
    },

    # xAI
    ("xai", "grok-4"): {
        "in":  float(os.getenv("PRICE_XAI_GROK4_IN",          "0.0002")),
        "out": float(os.getenv("PRICE_XAI_GROK4_OUT",         "0.0005")),
    },

    # Anthropic (Claude)
    ("anthropic", "claude-sonnet-4-20250514"): {
        "in":  float(os.getenv("PRICE_ANTHROPIC_SONNET_IN",   "0.003")),
        "out": float(os.getenv("PRICE_ANTHROPIC_SONNET_OUT",  "0.015")),
    },
}







import json, re

_CODE_FENCE_RE = re.compile(r"^\s*`{3,}.*?\n|`{3,}\s*$", re.DOTALL | re.IGNORECASE | re.MULTILINE)

def _strip_code_fences(s: str) -> str:
    # remove leading/trailing code fences if present
    return _CODE_FENCE_RE.sub("", s or "").strip()

def _find_first_balanced_json_object(s: str) -> str | None:
    """
    Return the first balanced {...} substring from s, ignoring braces inside quotes.
    Works even if there is leading/trailing text around the JSON.
    """
    if not s:
        return None
    s = s.strip()

    start = None
    depth = 0
    in_str = False
    esc = False
    for i, ch in enumerate(s):
        if start is None:
            if ch == "{":
                start = i
                depth = 1
                in_str = False
                esc = False
        else:
            if in_str:
                if esc:
                    esc = False
                elif ch == "\\":
                    esc = True
                elif ch == '"':
                    in_str = False
            else:
                if ch == '"':
                    in_str = True
                elif ch == "{":
                    depth += 1
                elif ch == "}":
                    depth -= 1
                    if depth == 0:
                        return s[start:i+1]
    return None

def _repair_trivial_json_issues(s: str) -> str:
    # convert smart quotes to plain quotes
    s = (s or "").replace("“", '"').replace("”", '"').replace("’", "'").replace("‘", "'")
    # strip code fences if any remain
    s = _strip_code_fences(s)
    return s.strip()

def _extract_json_str(text: str) -> str:
    """
    Robust JSON extractor:
    1) remove code fences
    2) try to parse raw
    3) search first balanced {...}
    4) minimal repair & retry
    Raises ValueError if no valid JSON object can be found.
    """
    if not isinstance(text, str) or not text.strip():
        raise ValueError("Empty text for JSON extraction")

    raw = _strip_code_fences(text)

    # 1) direct parse
    try:
        json.loads(raw)
        return raw
    except Exception:
        pass

    # 2) find first balanced object
    candidate = _find_first_balanced_json_object(raw)
    if candidate:
        try:
            json.loads(candidate)
            return candidate
        except Exception:
            # try a repaired version
            repaired = _repair_trivial_json_issues(candidate)
            json.loads(repaired)
            return repaired

    # 3) repair entire text and retry both strategies
    repaired = _repair_trivial_json_issues(raw)
    try:
        json.loads(repaired)
        return repaired
    except Exception:
        pass

    candidate = _find_first_balanced_json_object(repaired)
    if candidate:
        json.loads(candidate)
        return candidate

    raise ValueError("No valid JSON found in response.")

#--- Usage & token estimation -------------------------------------------------

def _usage_from_resp(data: Dict[str, Any]) -> tuple[int, int]:
    """
    Return (prompt_tokens, completion_tokens) if available; else (0, 0).
    Tries multiple provider-specific locations.
    """
    u = data.get("usage") or {}
    # OpenAI path (standard)
    p = _to_int(u.get("prompt_tokens"), 0)
    c = _to_int(u.get("completion_tokens"), 0)

    if p or c:
        return p, c

    # Some providers put totals only, or nest under different keys - try common fallbacks
    p = _to_int(u.get("prompt"), 0) or _to_int(u.get("input_tokens"), 0)
    c = _to_int(u.get("completion"), 0) or _to_int(u.get("output_tokens"), 0)
    return p, c


def _estimate_tokens_by_chars(text: str) -> int:
    """
    Fallback tokenizer: ~ 4 chars/token OVERestimates for JSON/CSV prompts.
    Use ~ 5 chars/token (closer to cl100k-like BPE for long ASCII) and floor to >=1.
    """
    return max(1, int(len(text) / 5))


# --- LLM client factory -------------------------------------------------------
from typing import Optional, Dict, Tuple, Any, Callable
import os, time, requests

# -------- Robust extractor for OpenAI Chat + Responses API ----------
def _extract_text_from_any_openai_response(data: dict) -> str:
    """
    Unified text extractor for OpenAI Chat Completions + Responses API.

    Handles shapes like:
      - Chat:      data["choices"][0]["message"]["content"]
      - Responses: data["output_text"]
                   data["output"][i == 'message']["content"][j]["text"]
    Also tolerates nested {"response": {...}} wrappers.
    """
    if not isinstance(data, dict):
        return ""

    # 0) Some Responses payloads are wrapped in {"response": {...}}
    if isinstance(data.get("response"), dict):
        data = data["response"]

    def _pluck_list_segments(lst) -> str:
        parts = []
        if isinstance(lst, list):
            for seg in lst:
                if isinstance(seg, dict):
                    # Responses segments: {"type": "output_text", "text": "..."}
                    t = seg.get("text") or seg.get("content")
                    if isinstance(t, str) and t.strip():
                        parts.append(t.strip())
                elif isinstance(seg, str) and seg.strip():
                    parts.append(seg.strip())
        return "\n".join(parts).strip()

    # 1) Chat Completions fast path
    try:
        msg = (data.get("choices", [{}])[0] or {}).get("message", {})
        c = msg.get("content")
        if isinstance(c, str) and c.strip():
            return c.strip()
        if isinstance(c, list):
            s = _pluck_list_segments(c)
            if s:
                return s
    except Exception:
        pass

    # 2) Responses API: direct convenience field if present
    if isinstance(data.get("output_text"), str) and data["output_text"].strip():
        return data["output_text"].strip()

    # 3) Responses API: walk output items (prefer 'message' items)
    out = data.get("output")
    if isinstance(out, list):
        # First pass: only items explicitly marked as a message
        msg_parts = []
        for item in out:
            if isinstance(item, dict) and item.get("type") == "message":
                s = _pluck_list_segments(item.get("content"))
                if s:
                    msg_parts.append(s)
        if msg_parts:
            return "\n".join(msg_parts).strip()

        # Fallback: accept any item with content text
        any_parts = []
        for item in out:
            if isinstance(item, dict):
                s = _pluck_list_segments(item.get("content"))
                if s:
                    any_parts.append(s)
        if any_parts:
            return "\n".join(any_parts).strip()

    # 4) Last-resort: a top-level "content" field (rare)
    top = data.get("content")
    if isinstance(top, str) and top.strip():
        return top.strip()
    if isinstance(top, list):
        s = _pluck_list_segments(top)
        if s:
            return s

    return ""


# ----------------- LOW-LEVEL RAW CLIENT (no LangChain) -----------------

# llm_io.py  - minimal, surgical fix
import json, os, time, requests
from urllib.parse import urlparse

class LLMError(RuntimeError):
    pass

def _estimate_tokens_by_chars(text: str) -> int:
    return max(1, int(len(text) / 5))

def _usage_from_resp(data: dict) -> tuple[int, int]:
    u = data.get("usage") or {}
    p = int(u.get("prompt_tokens") or u.get("prompt") or u.get("input_tokens") or 0)
    c = int(u.get("completion_tokens") or u.get("completion") or u.get("output_tokens") or 0)
    return p, c

def _extract_text_from_any_openai_response(data: dict) -> str:
    if not isinstance(data, dict):
        return ""
    # Chat Completions
    try:
        c = data.get("choices", [{}])[0].get("message", {}).get("content")
        if isinstance(c, str) and c.strip():
            return c.strip()
        if isinstance(c, list):
            return "\n".join(
                seg.get("text") or seg.get("content") or ""
                for seg in c if isinstance(seg, dict)
            ).strip()
    except Exception:
        pass
    # Responses API
    if isinstance(data.get("output_text"), str) and data["output_text"].strip():
        return data["output_text"].strip()
    out = data.get("output")
    if isinstance(out, list):
        parts = []
        for item in out:
            if not isinstance(item, dict): 
                continue
            content = item.get("content")
            if isinstance(content, list):
                for seg in content:
                    if isinstance(seg, dict):
                        t = seg.get("text") or seg.get("content")
                        if isinstance(t, str) and t.strip():
                            parts.append(t.strip())
        if parts:
            return "\n".join(parts).strip()
    return ""

def _extract_json_str(text: str) -> str:
    text = (text or "").strip().strip("`")
    # quick try
    try:
        json.loads(text); return text
    except Exception:
        pass
    # find first balanced {...}
    depth = 0; start = text.find("{")
    if start == -1: 
        raise LLMError("No valid JSON found in response.")
    in_str = False; esc = False
    for i, ch in enumerate(text[start:], start):
        if in_str:
            if esc: esc = False
            elif ch == "\\": esc = True
            elif ch == '"': in_str = False
        else:
            if ch == '"': in_str = True
            elif ch == "{": depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    cand = text[start:i+1]
                    json.loads(cand)
                    return cand
    raise LLMError("No valid JSON found in response.")


def _extract_text_from_anthropic_response(data: dict) -> str:
    """
    Anthropic /v1/messages returns {'content': [{'type':'text','text':'...'}], ...}
    """
    if not isinstance(data, dict):
        return ""
    blocks = data.get("content")
    if isinstance(blocks, list):
        parts = []
        for b in blocks:
            if isinstance(b, dict) and b.get("type") == "text":
                t = b.get("text", "")
                if isinstance(t, str) and t.strip():
                    parts.append(t.strip())
        if parts:
            return "\n".join(parts)
    # Some SDKs wrap under {'message': {...}}
    msg = data.get("message")
    if isinstance(msg, dict) and isinstance(msg.get("content"), list):
        return _extract_text_from_anthropic_response(msg)  # reuse logic
    return ""


# ----------------- RAW CLIENT (minimal patch incl. Anthropic) -----------------
def make_llm_client_raw(
    provider: str = "openai",
    model: str = "gpt-5-mini",
    timeout: int = 300,
    base_url: Optional[str] = None,
    pricing: Optional[Dict[Tuple[str, str], Dict[str, float]]] = None,
) -> Callable[..., Dict[str, Any]]:

    provider = provider.lower().strip()
    if provider not in {"openai", "xai", "anthropic"}:
        raise ValueError("provider must be 'openai', 'xai', or 'anthropic'.")

    def _is_gpt5(m: str) -> bool:
        return (m or "").lower().startswith("gpt-5")

    # ----- OpenAI -----
    if provider == "openai":
        api_key = os.getenv("OPENAI_API_KEY", "").strip()
        if not api_key:
            raise LLMError("Missing OPENAI_API_KEY.")
        is_gpt5 = _is_gpt5(model)
        url = (base_url or ("https://api.openai.com/v1/responses" if is_gpt5
                            else "https://api.openai.com/v1/chat/completions")).rstrip("/")
        headers = {"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"}

        # NOTE: keep max tokens out for raw minimal path (your original design)
        def _payload(prompt: str, temperature: float, _max_tokens_ignored: Optional[int]) -> Dict[str, Any]:
            if is_gpt5:
                return {
                    "model": model,
                    "input": "Return ONLY a single valid JSON object. No prose, no code fences.\n\n" + prompt,
                    "reasoning": {"effort": "low"},
                    "modalities": ["text"],
                    "text": {"format": {"type": "text"}, "verbosity": "low"},
                    "tool_choice": "none",
                }
            else:
                return {
                    "model": model,
                    "temperature": float(temperature),
                    "response_format": {"type": "json_object"},
                    "messages": [
                        {"role": "system", "content": "Return ONLY a single valid JSON object."},
                        {"role": "user", "content": prompt},
                    ],
                }

    # ----- Anthropic (Claude) -----
    elif provider == "anthropic":
        api_key = os.getenv("ANTHROPIC_API_KEY", "").strip()
        if not api_key:
            raise LLMError("Missing ANTHROPIC_API_KEY.")
        model = (model or os.getenv("CLAUDE_MODEL", "claude-sonnet-4-20250514")).strip()
        url = (base_url or "https://api.anthropic.com/v1/messages").rstrip("/")
        headers = {
            "x-api-key": api_key,
            "anthropic-version": "2023-06-01",
            "content-type": "application/json",
        }

        def _payload(prompt: str, temperature: float, max_tokens: Optional[int]) -> Dict[str, Any]:
            return {
                "model": model,
                "max_tokens": int(max_tokens) if (max_tokens and max_tokens > 0) else 1024,
                "temperature": float(temperature),
                "system": "Return ONLY a single valid JSON object. No prose, no code fences.",
                "messages": [{"role": "user", "content": prompt}],
            }

    # ----- xAI (Grok) -----
    else:
        api_key = os.getenv("XAI_API_KEY", "").strip()
        if not api_key:
            raise LLMError("Missing XAI_API_KEY.")
        url = (base_url or "https://api.x.ai/v1/chat/completions").rstrip("/")
        headers = {"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"}

        # keep raw path simple (no explicit max_tokens)
        def _payload(prompt: str, temperature: float, _max_tokens_ignored: Optional[int]) -> Dict[str, Any]:
            return {
                "model": model,
                "temperature": float(temperature),
                "messages": [
                    {"role": "system", "content": "Return ONLY a single valid JSON object. No prose."},
                    {"role": "user", "content": prompt},
                ],
            }

    price_table = pricing or PRICING
    price = price_table.get((provider, model), {"in": 0.0, "out": 0.0})

    def llm_client(
        prompt: str,
        temperature: float = 0,
        max_tokens: int | None = None,
        retries: int = 3,
        request_timeout: Optional[int] = 300,
        verbose: bool = True,
    ) -> Dict[str, Any]:
        last_err = None
        for attempt in range(retries + 1):
            try:
                resp = requests.post(
                    url,
                    headers=headers,
                    json=_payload(prompt, temperature, max_tokens),
                    timeout=(request_timeout or timeout),
                )
                if resp.status_code >= 400:
                    raise LLMError(f"HTTP {resp.status_code}: {resp.text[:800]}")
                data = resp.json()

                # Provider-specific extraction
                if provider == "anthropic":
                    content = _extract_text_from_anthropic_response(data)
                else:
                    content = _extract_text_from_any_openai_response(data)

                if not content:
                    raise LLMError(f"Empty content in LLM response. Keys: {list(data.keys())[:10]}")

                json_str = _extract_json_str(content)

                p_toks, c_toks = _usage_from_resp(data)
                if p_toks == 0 and c_toks == 0:
                    p_toks = _estimate_tokens_by_chars(prompt)
                    c_toks = _estimate_tokens_by_chars(json_str)

                usd_est = (p_toks / 1000.0) * float(price["in"]) + (c_toks / 1000.0) * float(price["out"])

                if verbose:
                    print(f"[LLM/raw] provider={provider} model={model} prompt_toks={p_toks} "
                          f"completion_toks={c_toks} est_cost=${usd_est}")

                return {
                    "json_str": json_str,
                    "usage": {"prompt": int(p_toks), "completion": int(c_toks)},
                    "usd_est": round(float(usd_est), 6),
                    "raw": data,
                }

            except Exception as e:
                last_err = e
                if attempt < retries:
                    time.sleep(0.8 * (attempt + 1))
                else:
                    break
        raise LLMError(f"LLM call failed after retries: {last_err}")

    return llm_client




# --- LangChain-based client (no requests) ---


import os
import re
import json
import time
from typing import Any, Dict, Optional, Tuple, Callable

from langchain_core.messages import SystemMessage, HumanMessage
from langchain_core.output_parsers import JsonOutputParser

try:
    from langchain_openai import ChatOpenAI
except Exception:
    ChatOpenAI = None

try:
    from langchain_anthropic import ChatAnthropic
except Exception:
    ChatAnthropic = None

try:
    from langchain_community.chat_models import ChatXAI as _ChatXAI
except Exception:
    _ChatXAI = None


# ---- You already have this in your codebase; keeping here for completeness
class LLMError(RuntimeError):
    pass


try:
    PRICING  # type: ignore  # noqa: F401
except NameError:
    PRICING = {}


def _estimate_tokens_by_chars(s: str) -> int:
    return max(1, int(len(s) / 4))  # ~4 chars/token heuristic


def _safe_json_extract(text: str) -> str:
    try:
        obj = json.loads(text)
        return json.dumps(obj, ensure_ascii=False)
    except Exception:
        pass
    m = re.search(r"\{(?:[^{}]|(?R))*\}", text, flags=re.DOTALL)
    if m:
        candidate = m.group(0)
        try:
            obj = json.loads(candidate)
            return json.dumps(obj, ensure_ascii=False)
        except Exception:
            return candidate.strip()
    return text.strip()


def _extract_usage_from_metadata(meta: Dict[str, Any]) -> Tuple[int, int]:
    tok = meta.get("token_usage") or meta.get("usage") or {}
    p = tok.get("prompt_tokens") or tok.get("input_tokens") or 0
    c = tok.get("completion_tokens") or tok.get("output_tokens") or 0
    try:
        p = int(p)
    except Exception:
        p = 0
    try:
        c = int(c)
    except Exception:
        c = 0
    return p, c


def _is_gpt5(model: str) -> bool:
    return (model or "").lower().startswith("gpt-5")


def make_llm_client(
    provider: str = "openai",
    model: str = "gpt-5-mini",
    timeout: int = 600,
    base_url: Optional[str] = None,
    pricing: Optional[Dict[Tuple[str, str], Dict[str, float]]] = None,
) -> Callable[..., Dict[str, Any]]:
    """
    LangChain-only implementation; unified on Chat interface.
    Special handling for GPT-5 family:
      - omit temperature
      - force verbosity="medium" in model kwargs
    """

    provider = (provider or "").lower().strip()
    if provider not in {"openai", "xai", "anthropic"}:
        raise ValueError("provider must be 'openai', 'xai', or 'anthropic'.")

    # ---- Build the LC chat model (once)
    def _build_openai_model(_timeout: int):
        if ChatOpenAI is None:
            raise LLMError("langchain-openai is not installed.")
        api_key = (os.getenv("OPENAI_API_KEY") or "").strip()
        if not api_key:
            raise LLMError("Missing OPENAI_API_KEY.")

        # GPT-5: inject verbosity="medium" via model_kwargs; omit temperature later
        model_kwargs = {}
        if _is_gpt5(model):
            model_kwargs["verbosity"] = "medium"

        return ChatOpenAI(
            model=model,
            api_key=api_key,
            timeout=_timeout,
            base_url=base_url or os.getenv("OPENAI_BASE_URL") or None,
            model_kwargs=model_kwargs if model_kwargs else None,
        )

    def _build_anthropic_model(_timeout: int):
        if ChatAnthropic is None:
            raise LLMError("langchain-anthropic is not installed.")
        api_key = (os.getenv("ANTHROPIC_API_KEY") or "").strip()
        if not api_key:
            raise LLMError("Missing ANTHROPIC_API_KEY.")
        return ChatAnthropic(model=model, api_key=api_key, timeout=_timeout)

    def _build_xai_model(_timeout: int):
        api_key = (os.getenv("XAI_API_KEY") or "").strip()
        if not api_key:
            raise LLMError("Missing XAI_API_KEY.")
        # Prefer native class if present
        if _ChatXAI is not None:
            return _ChatXAI(model=model, api_key=api_key, timeout=_timeout, base_url=base_url or "https://api.x.ai/v1")
        # Fallback: OpenAI-compatible Chat client toward xAI endpoint
        if ChatOpenAI is None:
            raise LLMError("langchain-openai is not installed.")
        return ChatOpenAI(model=model, api_key=api_key, timeout=_timeout, base_url=base_url or "https://api.x.ai/v1")

    if provider == "openai":
        llm = _build_openai_model(timeout)
    elif provider == "anthropic":
        llm = _build_anthropic_model(timeout)
    else:  # xai
        llm = _build_xai_model(timeout)

    # Pricing (unchanged)
    price_table = pricing or PRICING
    price = price_table.get((provider, model), {"in": 0.0, "out": 0.0})

    SYSTEM_JSON_RULE = "Return ONLY a single valid JSON object. No explanations, no code fences."
    parser = JsonOutputParser()

    def _temp_supported() -> bool:
        # For GPT-5 family, treat temperature as unsupported
        if provider == "openai" and _is_gpt5(model):
            return False
        return True

    def _build_gen_kwargs(temperature_: Optional[float], max_tokens_: Optional[int]) -> Dict[str, Any]:
        gen = {}
        # Only include temperature if supported by this model
        if temperature_ is not None and _temp_supported():
            gen["temperature"] = float(temperature_)
        if max_tokens_ and max_tokens_ > 0:
            gen["max_tokens"] = int(max_tokens_)
        return gen

    def llm_client(
        prompt: str,
        temperature: float = 0,
        max_tokens: Optional[int] = None,
        retries: int = 3,
        request_timeout: Optional[int] = None,  # per-call override
        verbose: bool = True,
    ) -> Dict[str, Any]:
        if not isinstance(prompt, str) or not prompt:
            raise ValueError("prompt must be a non-empty string.")

        last_err: Optional[Exception] = None
        for attempt in range(retries + 1):
            try:
                # Per-call timeout override → rebuild same-type model with new timeout
                effective_llm = llm
                if request_timeout and request_timeout > 0:
                    if provider == "openai":
                        effective_llm = _build_openai_model(int(request_timeout))
                    elif provider == "anthropic":
                        effective_llm = _build_anthropic_model(int(request_timeout))
                    else:
                        effective_llm = _build_xai_model(int(request_timeout))

                # Build generation kwargs
                gen_kwargs = _build_gen_kwargs(temperature, max_tokens)

                # Bind per-call gen kwargs
                bound = effective_llm.bind(**gen_kwargs)

                # Messages (unified chat)
                messages = [
                    SystemMessage(content=SYSTEM_JSON_RULE),
                    HumanMessage(content=prompt),
                ]

                # Invoke (no callbacks)
                t0 = time.time()
                try:
                    result = bound.invoke(messages)
                except Exception as e:
                    # If provider rejects temperature, retry once without it
                    msg = str(e)
                    if "unsupported_value" in msg.lower() and "temperature" in msg.lower():
                        bound = effective_llm.bind(**_build_gen_kwargs(None, max_tokens))
                        result = bound.invoke(messages)
                    else:
                        raise
                elapsed = time.time() - t0

                # Extract content
                if isinstance(result.content, str):
                    content = result.content
                else:
                    try:
                        content = "".join(
                            ch.get("text", "") if isinstance(ch, dict) else str(ch)
                            for ch in (result.content or [])
                        )
                    except Exception:
                        content = str(result.content)

                if not content:
                    raise LLMError("Empty content in LLM response.")

                # Parse JSON (parser first, then safe fallback)
                try:
                    parsed_obj = parser.parse(content)
                    json_str = json.dumps(parsed_obj, ensure_ascii=False)
                except Exception:
                    json_str = _safe_json_extract(content)
                    try:
                        _ = json.loads(json_str)
                    except Exception:
                        raise LLMError("Model did not return valid JSON and fallback could not repair it.")

                # Usage / cost
                meta = getattr(result, "response_metadata", {}) or {}
                p_toks, c_toks = _extract_usage_from_metadata(meta)
                if p_toks == 0 and c_toks == 0:
                    p_toks = _estimate_tokens_by_chars(prompt)
                    c_toks = _estimate_tokens_by_chars(json_str)

                usd_est = (p_toks / 1000.0) * float(price.get("in", 0.0)) \
                          + (c_toks / 1000.0) * float(price.get("out", 0.0))

                if verbose:
                    print(
                        f"[LLM/LC] provider={provider} model={model} "
                        f"prompt_toks={p_toks} completion_toks={c_toks} "
                        f"est_cost=${usd_est:.6f} time={elapsed:.2f}s"
                    )

                raw = {
                    "content": content,
                    "response_metadata": meta,
                    "id": getattr(result, "id", None),
                }

                return {
                    "json_str": json_str,
                    "usage": {"prompt": int(p_toks), "completion": int(c_toks)},
                    "usd_est": round(float(usd_est), 6),
                    "raw": raw,
                }

            except Exception as e:
                last_err = e
                if attempt < retries:
                    time.sleep(0.8 * (attempt + 1))
                else:
                    break

        raise LLMError(f"LLM call failed after retries: {last_err}")

    return llm_client
