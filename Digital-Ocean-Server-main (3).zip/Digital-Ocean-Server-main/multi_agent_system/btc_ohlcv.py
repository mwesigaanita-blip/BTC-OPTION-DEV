# ----- BTC OHLCV daily (Deribit) + SQLite utils -----
import pandas as pd

import requests
import os

from dotenv import load_dotenv
import logging
from datetime import datetime, timedelta, timezone

import time
import sqlite3
import warnings

import sys
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

from typing import  Optional

from .config import *  # noqa: F401,F403  (non-DB constants)
from shared.db_paths import MARKET_DATA_DB as DB_PATH

print(f"[DB] Using {DB_PATH} in {__file__}", flush=True)
from typing import Dict

from datetime import datetime
import os,  time, logging, sqlite3
from datetime import datetime, timedelta
from typing import  Dict
import sys

warnings.filterwarnings("ignore")
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('Main_file_log.log'),
        logging.StreamHandler()
    ]
)
import os, time, sqlite3, requests
import pandas as pd
from typing import Optional, Dict, Iterable
from datetime import datetime, date, time as dtime, timedelta, timezone
from urllib3.util.retry import Retry
from requests.adapters import HTTPAdapter

from datetime import datetime, date, time as dtime, timedelta, timezone

def _as_date_ms(ts_ms: int) -> date:
    return datetime.utcfromtimestamp(ts_ms / 1000.0).date()

# ===HTTP retry session ===
def _make_retry_session(
    total: int = 6,
    backoff_factor: float = 0.5,
    status_forcelist: tuple = (429, 500, 502, 503, 504),
) -> requests.Session:
    s = requests.Session()
    retry = Retry(
        total=total, connect=total, read=total, status=total,
        backoff_factor=backoff_factor,
        status_forcelist=status_forcelist,
        allowed_methods=frozenset(["GET"]),
        raise_on_status=False,
    )
    adapter = HTTPAdapter(max_retries=retry, pool_connections=10, pool_maxsize=10)
    s.mount("https://", adapter)
    s.headers.update({"User-Agent": "btc-yday-ohlcv/1.0"})
    return s

# === Deribit fetch (UTC) ===
def deribit_yesterday_ohlcv(
    instrument: str = "BTC-PERPETUAL",
    resolution: str = "1D",
    timeout: tuple = (3.05, 20),
    max_attempts: int = 3,
    session: Optional[requests.Session] = None,
) -> Dict[str, float]:
    """
    Returns dict for UTC 'yesterday':
      {"time","open","high","low","last","change","%chg","volume"}
    """
    today_utc = date.fromtimestamp(datetime.now(timezone.utc).timestamp())
    start_dt = datetime.combine(today_utc - timedelta(days=30), dtime(0, 0), tzinfo=timezone.utc)
    end_dt   = datetime.combine(today_utc, dtime(0, 0), tzinfo=timezone.utc)

    params = {
        "instrument_name": instrument,
        "resolution": resolution,  # "1D"
        "start_timestamp": int(start_dt.timestamp() * 1000),
        "end_timestamp": int(end_dt.timestamp() * 1000) - 1,  # inclusive
    }

    sess = session or _make_retry_session()
    last_err = None

    for attempt in range(1, max_attempts + 1):
        try:
            r = sess.get(DERIBIT_TV_URL, params=params, timeout=timeout)
            r.raise_for_status()
            result = (r.json().get("result") or {})
            if result.get("status") != "ok":
                raise ValueError(f"Deribit status={result.get('status')}")
            ticks  = result.get("ticks")  or []
            opens  = result.get("open")   or []
            highs  = result.get("high")   or []
            lows   = result.get("low")    or []
            closes = result.get("close")  or []
            vols   = result.get("volume") or []
            if len(closes) < 2 or len(ticks) < 2:
                raise ValueError("Fewer than 2 full candles returned")

            # pick candle whose date == yesterday (UTC)
            yday = today_utc - timedelta(days=1)
            idx_y = None
            for i in range(len(ticks) - 1, -1, -1):
                if _as_date_ms(ticks[i]) == yday:
                    idx_y = i
                    break
            # fallback: latest candle strictly before today
            if idx_y is None:
                for i in range(len(ticks) - 1, -1, -1):
                    if _as_date_ms(ticks[i]) <= yday:
                        idx_y = i
                        break
            if idx_y is None or idx_y - 1 < 0:
                raise ValueError("Could not locate yesterday candle in Deribit response")

            prev_close = float(closes[idx_y - 1])
            last_close = float(closes[idx_y])

            return {
                "time":   datetime.utcfromtimestamp(ticks[idx_y] / 1000).strftime("%Y-%m-%d"),
                "open":   float(opens[idx_y]),
                "high":   float(highs[idx_y]),
                "low":    float(lows[idx_y]),
                "last":   last_close,
                "change": last_close - prev_close,
                "%chg":   ((last_close - prev_close) / prev_close) * 100.0 if prev_close else 0.0,
                "volume": float(vols[idx_y]),
            }
        except (requests.RequestException, ValueError) as e:
            last_err = e
            if attempt < max_attempts:
                time.sleep((0.5 * attempt) + 0.05 * attempt)
    raise RuntimeError(f"Failed to fetch yesterday OHLCV for {instrument}: {last_err}")

# === SQLite table + UPSERT ===
def init_btc_prices_table(db_path: str = DB_PATH) -> None:
    """Create table if missing; enforce unique date."""
    con = sqlite3.connect(str(db_path), timeout=30)
    try:
        con.execute("PRAGMA journal_mode=WAL;")
        con.execute("PRAGMA synchronous=NORMAL;")
        con.execute("""
            CREATE TABLE IF NOT EXISTS btc_prices (
                date            TEXT PRIMARY KEY,   -- YYYY-MM-DD (UTC)
                open            REAL NOT NULL,
                high            REAL NOT NULL,
                low             REAL NOT NULL,
                close           REAL NOT NULL,
                change          REAL,
                percent_change  REAL,
                volume          REAL
            )
        """)
        con.execute("CREATE UNIQUE INDEX IF NOT EXISTS btc_prices_date_unq ON btc_prices(date)")
        con.commit()
    finally:
        con.close()

def _upsert_rows(db_path: str, rows: Iterable[tuple]) -> None:
    """
    rows: iterable of (date, open, high, low, close, change, percent_change, volume)
    """
    con = sqlite3.connect(str(db_path), timeout=30)
    try:
        con.execute("PRAGMA journal_mode=WAL;")
        sql = """
          INSERT INTO btc_prices(date, open, high, low, close, change, percent_change, volume)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?)
          ON CONFLICT(date) DO UPDATE SET
            open=excluded.open,
            high=excluded.high,
            low=excluded.low,
            close=excluded.close,
            change=excluded.change,
            percent_change=excluded.percent_change,
            volume=excluded.volume
        """
        con.executemany(sql, rows)
        con.commit()
    finally:
        con.close()

def upsert_btc_yday_from_deribit(
    db_path: str = DB_PATH,
    instrument: str = "BTC-PERPETUAL",
    session: Optional[requests.Session] = None,
) -> Dict[str, float]:
    """
    Fetch yesterday (UTC) from Deribit and UPSERT into btc_prices.
    No duplicates by construction (date is PK).
    """
    init_btc_prices_table(db_path)
    y = deribit_yesterday_ohlcv(instrument=instrument, session=session)
    row = (
        y["time"], float(y["open"]), float(y["high"]), float(y["low"]),
        float(y["last"]), float(y["change"]), float(y["%chg"]), float(y.get("volume") or 0.0)
    )
    _upsert_rows(db_path, [row])
    return y

def load_btc_history_df(db_path: str = DB_PATH) -> pd.DataFrame:
    """Return DataFrame for modeling: date, open, high, low, close, volume (ASC; clean types)."""
    with sqlite3.connect(str(db_path)) as con:
        df = pd.read_sql_query(
            "SELECT date, open, high, low, close, volume FROM btc_prices ORDER BY date ASC",
            con
        )
    # ensure proper dtype and ordering
    df["date"] = pd.to_datetime(df["date"], utc=True, errors="coerce")
    df = df.dropna(subset=["date", "close"]).drop_duplicates(subset=["date"], keep="last")
    df = df.sort_values("date").reset_index(drop=True)

    # exclude today's (potentially partial) row
    today_utc = pd.Timestamp.utcnow().normalize()
    df = df[df["date"] < today_utc].reset_index(drop=True)
    return df


def extract_llm_range_features(forecast: dict,
                               include_abs: bool = True,
                               round_pct: int = 2,
                               round_price: int = 2) -> dict:
    """
    Take btc_range_forecast(...) output and return a lean dict the LLM can use.
    Keeps only: as_of, close, per-horizon +/-% (and optionally absolute bands) + m_used.

    Example return:
    {
      "as_of": "2025-08-28",
      "close": 112951.17,
      "bands_pct": {"5d":{"up":8.24,"down":-6.33}, ...},
      "bands_abs": {"5d":{"upper":122256.42,"lower":105803.68}, ...},   # if include_abs=True
      "m_used": {"5d":1.144, ...}
    }
    """
    import numpy as np

    if not forecast or "horizons" not in forecast:
        return {}

    order = ["5d", "10d", "21d", "42d", "63d"]  # only horizons we train
    out = {
        "as_of": forecast.get("as_of"),
        "close": round(float(forecast.get("close", np.nan)), round_price),
        "bands_pct": {},
        "m_used": {},
    }
    if include_abs:
        out["bands_abs"] = {}

    for h in order:
        rec = forecast["horizons"].get(h)
        if not rec:
            continue
        up = float(rec.get("up_pct", 0.0))
        dn = float(rec.get("down_pct", 0.0))
        out["bands_pct"][h] = {"up": round(up, round_pct), "down": round(dn, round_pct)}
        out["m_used"][h] = round(float(rec.get("m_used", 1.0)), 3)
        if include_abs:
            out["bands_abs"][h] = {
                "upper": round(float(rec.get("upper", np.nan)), round_price),
                "lower": round(float(rec.get("lower", np.nan)), round_price),
            }
    return out

def build_llm_range_message(forecast: dict) -> str:
    """
    Human/LLM-friendly single-line summary to drop into the prompt.
    Example:
      "As of 2025-08-28 close 112,951: 5d +8.24%/-6.33%; 10d +12.70%/-8.17%; ..."
    """
    f = extract_llm_range_features(forecast, include_abs=False)
    if not f or not f.get("bands_pct"):
        return ""

    def _fmt(n):  # thousands separator, no decimals unless needed
        return f"{n:,.0f}" if abs(n - round(n)) < 1e-6 else f"{n:,.2f}"

    parts = []
    for h in ["5d","10d","21d","42d","63d"]:
        b = f["bands_pct"].get(h)
        if b:
            parts.append(f"{h} +{b['up']:.2f}%/{b['down']:.2f}%")
    return f"As of {f['as_of']} close {_fmt(f['close'])}: " + "; ".join(parts)

def btc_range_forecast(
    daily_ohlc,                       # DataFrame OR CSV path (your original file format is OK)
    artifacts_dir="Models/range_model_artifacts_42d",
):
    """
    Load the trained LSTM range model + scaler + meta and produce calibrated price bands
    for available horizons among: 5d (1w), 10d (2w), 21d (1m), 42d (2m), 63d (3m),
    based on the latest LOOKBACK trading days.

    Loader strategy (robust to keras/tf.keras differences):
      1) Prefer loading the .keras file with standalone `keras` (Keras 3).
      2) If a SavedModel directory is present in meta, try `tf.keras.models.load_model` on it.
      3) As a last resort, try `tf.keras.models.load_model` on the .keras file.
    """
    import os, json, re
    import numpy as np
    import pandas as pd
    from pathlib import Path
    import joblib

    # ---------- 0) Load artifacts ----------
    meta_path   = os.path.join(artifacts_dir, "meta.json")
    scaler_path = os.path.join(artifacts_dir, "scaler.pkl")

    if not (os.path.exists(meta_path) and os.path.exists(scaler_path)):
        raise FileNotFoundError(f"Missing artifacts in {artifacts_dir}. Expect scaler.pkl and meta.json")

    with open(meta_path, "r", encoding="utf-8") as f:
        meta = json.load(f)

    # Model filenames from meta (with fallbacks)
    model_file      = meta.get("model_file") or "lstm_range_multiout_42d.keras"
    weights_file    = meta.get("weights_file")  # optional
    savedmodel_dir  = meta.get("savedmodel_dir")  # optional (directory name)
    preferred_loader = (meta.get("preferred_loader") or "keras").lower()

    keras_model_path   = os.path.join(artifacts_dir, model_file)
    savedmodel_path    = os.path.join(artifacts_dir, savedmodel_dir) if savedmodel_dir else None
    weights_path       = os.path.join(artifacts_dir, weights_file) if weights_file else None

    # Load scaler
    scaler = joblib.load(scaler_path)

    # Try to load the model in a loader-safe way
    model = None
    load_errors = []

    # 1) Standalone keras (Keras 3) on .keras file
    if model is None and os.path.exists(keras_model_path) and preferred_loader == "keras":
        try:
            os.environ.setdefault("KERAS_BACKEND", "tensorflow")
            import keras as k  # standalone Keras 3
            model = k.models.load_model(keras_model_path, compile=False)
        except Exception as e:
            load_errors.append(("keras.load_model(.keras)", str(e)))
            model = None

    # 2) tf.keras on SavedModel directory (if available)
    if model is None and savedmodel_path and os.path.isdir(savedmodel_path):
        try:
            from tensorflow import keras as tfk
            model = tfk.models.load_model(savedmodel_path, compile=False)
        except Exception as e:
            load_errors.append(("tf.keras.load_model(SavedModel)", str(e)))
            model = None

    # 3) tf.keras on .keras file (last resort)
    if model is None and os.path.exists(keras_model_path):
        try:
            from tensorflow import keras as tfk
            model = tfk.models.load_model(keras_model_path, compile=False)
        except Exception as e:
            load_errors.append(("tf.keras.load_model(.keras)", str(e)))
            model = None

    if model is None:
        hint = (
            f"Failed to load model. Tried: {load_errors}. "
            f"Artifacts seen: model_file={keras_model_path!r}, savedmodel_dir={savedmodel_path!r}, weights={weights_path!r}. "
            "Ensure you load .keras with standalone `keras` or use the SavedModel with `tf.keras`."
        )
        raise RuntimeError(hint)

    # Meta
    LOOKBACK     = int(meta.get("lookback", 63))
    feature_cols = list(meta.get("feature_cols") or [])
    y_cols       = list(meta.get("y_cols") or [])
    m_per_h      = {k: float(v) for k, v in (meta.get("m_per_h", {}) or {}).items()}

    if not feature_cols:
        feature_cols = [
            "ret_1d","logret_1d",
            "rvol_5","rvol_10","rvol_21","rvol_63",
            "hl_pct","hl_mean_5","hl_mean_10","hl_mean_21","hl_mean_63",
            "sma_ratio_5","sma_ratio_10","sma_ratio_21","sma_ratio_63",
            "vol_chg","vol_z_5","vol_z_21","vol_z_63",
        ]
    if not y_cols:
        # fallback supports both 8-output (no 42d) and 10-output (with 42d)
        if "42d" in m_per_h:
            y_cols = [
                "range_up_5d","range_up_10d","range_up_21d","range_up_42d","range_up_63d",
                "range_dn_5d","range_dn_10d","range_dn_21d","range_dn_42d","range_dn_63d",
            ]
        else:
            y_cols = [
                "range_up_5d","range_up_10d","range_up_21d","range_up_63d",
                "range_dn_5d","range_dn_10d","range_dn_21d","range_dn_63d",
            ]

    # ---------- 1) Load data (CSV or DF) and normalize OHLCV ----------
    if isinstance(daily_ohlc, (str, os.PathLike)):
        df = pd.read_csv(daily_ohlc)
    else:
        df = daily_ohlc.copy()

    # lower-case columns for matching
    df.columns = [str(c).strip().lower() for c in df.columns]

    # Find a date/time column
    date_col = None
    for c in ("time","date","datetime","timestamp","open_time","close_time"):
        if c in df.columns:
            date_col = c
            break
    if date_col is None:
        raise ValueError("No timestamp-like column found (expected one of: time/date/datetime/timestamp/open_time/close_time).")

    # Parse to datetime (UTC), drop non-date rows (e.g., footer), sort ascending
    df["date"] = pd.to_datetime(df[date_col], errors="coerce", utc=True)
    df = df.dropna(subset=["date"]).sort_values("date").set_index("date")

    # Map common source names to OHLCV (your CSV had: time, open, high, low, last, change, %chg, volume)
    name_map = {}
    cols = set(df.columns)
    if "open" in cols:  name_map["open"]  = "open"
    if "high" in cols:  name_map["high"]  = "high"
    if "low"  in cols:  name_map["low"]   = "low"
    if "close" in cols:             name_map["close"]  = "close"
    elif "last" in cols:            name_map["close"]  = "last"
    elif "adj_close" in cols:       name_map["close"]  = "adj_close"
    elif "adj close" in cols:       name_map["close"]  = "adj close"
    if "volume" in cols:            name_map["volume"] = "volume"

    missing = [k for k in ("open","high","low","close","volume") if k not in name_map]
    if missing:
        raise ValueError(f"Missing required OHLCV columns (after mapping): {missing}. Found columns: {sorted(df.columns)}")

    use = df[[name_map["open"], name_map["high"], name_map["low"], name_map["close"], name_map["volume"]]].copy()
    use.columns = ["open","high","low","close","volume"]

    # Clean numerics: strip commas, parse K/M/B in volume
    def _to_float(x):
        if isinstance(x, (int, float)): return float(x)
        s = str(x).strip().replace(",", "")
        try:
            return float(s)
        except Exception:
            return np.nan

    def _parse_volume(x):
        if isinstance(x, (int, float)): return float(x)
        s = str(x).strip().replace(",", "").upper()
        m = re.match(r"^([+-]?\d*\.?\d+)\s*([KMB])?$", s)
        if not m:
            try: return float(s)
            except: return np.nan
        val, suf = m.groups()
        mult = {"K":1e3, "M":1e6, "B":1e9}.get(suf, 1.0)
        return float(val) * mult

    for c in ("open","high","low","close"):
        use[c] = use[c].apply(_to_float)
    use["volume"] = use["volume"].apply(_parse_volume)

    # ---------- 2) Recreate notebook features ----------
    feat = use.copy()
    feat["ret_1d"]    = feat["close"].pct_change()
    feat["logret_1d"] = np.log1p(feat["ret_1d"])
    for w in (5, 10, 21, 63):
        feat[f"rvol_{w}"] = feat["logret_1d"].rolling(w).std() * np.sqrt(252)

    feat["hl_pct"] = (feat["high"] - feat["low"]) / feat["close"]
    for w in (5, 10, 21, 63):
        feat[f"hl_mean_{w}"] = feat["hl_pct"].rolling(w).mean()

    for w in (5, 10, 21, 63):
        feat[f"sma_ratio_{w}"] = feat["close"] / feat["close"].rolling(w).mean() - 1.0

    feat["vol_chg"] = feat["volume"].pct_change()
    for w in (5, 21, 63):
        m = feat["volume"].rolling(w).mean()
        s = feat["volume"].rolling(w).std()
        feat[f"vol_z_{w}"] = (feat["volume"] - m) / (s + 1e-12)

    # Keep only the features we trained on; drop warmup NaNs and grab the last LOOKBACK rows
    feat = feat[feature_cols].replace([np.inf, -np.inf], np.nan).dropna().tail(LOOKBACK)
    if len(feat) < LOOKBACK:
        raise ValueError(f"Not enough clean history to build a {LOOKBACK}-step window (got {len(feat)} rows after warmup).")

    # ---------- 3) Scale, make sequence, predict ----------
    X = scaler.transform(feat.values)[None, :, :]   # (1, LOOKBACK, n_features)
    y = model.predict(X, verbose=0)[0]              # (len(y_cols),) in fractions, e.g. 0.05 = +5%

    raw = dict(zip(y_cols, [float(v) for v in y.tolist()]))

    # ---------- 4) Apply calibration factors per horizon ----------
    anchor_idx = feat.index[-1]
    close_t    = float(use.loc[anchor_idx, "close"])
    as_of      = anchor_idx.date().isoformat()

    # discover available horizons dynamically from y_cols
    def has_pair(h):
        return (f"range_up_{h}" in raw) and (f"range_dn_{h}" in raw)

    horizons = [h for h in ("5d","10d","21d","42d","63d") if has_pair(h)]

    def _apply(h):
        up_key, dn_key = f"range_up_{h}", f"range_dn_{h}"
        m = float(m_per_h.get(h, 1.0))
        up = max(float(raw[up_key]), 0.0)
        dn = min(float(raw[dn_key]), 0.0)
        up_pct  = m * up
        dn_pct  = m * dn
        return {
            "upper": close_t * (1.0 + up_pct),
            "lower": close_t * (1.0 + dn_pct),
            "up_pct":   100.0 * up_pct,
            "down_pct": 100.0 * dn_pct,
            "m_used":   m,
        }

    out = {
        "as_of": as_of,
        "close": close_t,
        "horizons": {h: _apply(h) for h in horizons},
        "raw_pred": raw,
        "meta": {
            "lookback": LOOKBACK,
            "feature_cols": feature_cols,
            "y_cols": y_cols,
            "calibration_used": m_per_h,
        },
    }
    return out


def build_forecast_line_safe(db_path: str) -> str:
    """
    Fetch/refresh yesterday candle, load history, run the range forecast,
    and return a concise LLM message. Produces an empty string on benign
    failure, but logs the exact cause.
    """
    # 1) Try to refresh yesterday’s candle (don’t crash the run if it fails)
    try:
        sess = _make_retry_session(total=8, backoff_factor=0.8)
        upsert_btc_yday_from_deribit(db_path=db_path, session=sess)
    except Exception as e:
        logging.warning("Deribit upsert failed (continuing with existing DB): %s", e)

    # 2) Load history and validate
    try:
        df_hist = load_btc_history_df(db_path=db_path)
        print(df_hist.head())
        print(20*"*")
        print(df_hist.tail())
    except Exception as e:
        logging.exception("Failed to load btc history from DB: %s", e)
        return ""

    if df_hist is None or df_hist.empty:
        logging.warning("BTC history is empty; cannot build forecast.")
        return ""

    required_cols = {"date", "open", "high", "low", "close", "volume"}
    missing = required_cols - set(df_hist.columns)
    if missing:
        logging.warning("BTC history missing columns: %s", ", ".join(sorted(missing)))
        return ""

    # 3) Run your forecast only if the functions are available
    try:

        # Optional pre-clean
        df_hist = df_hist.dropna(subset=["open", "high", "low", "close"]).copy()

        # Safety: ensure date sorted ascending
        try:
            df_hist["date"] = pd.to_datetime(df_hist["date"], errors="coerce", utc=True)
            df_hist = df_hist.sort_values("date")
        except Exception:
            pass

        # 4) Forecast + message
        forecast_obj = btc_range_forecast(daily_ohlc=df_hist)
        forecast_line = build_llm_range_message(forecast_obj)

        if not isinstance(forecast_line, str) or not forecast_line.strip():
            logging.warning("Forecast returned empty message.")
            return ""

        logging.info("Forecast: %s", forecast_line)
        return forecast_line.strip()

    except ModuleNotFoundError as e:
        logging.warning("Forecast utilities not found: %s", e)
        return ""
    except Exception as e:
        logging.error("Forecast failed: %s", e)
        return ""



if __name__== "__main__":
    # Example usage
    try:
        message = build_forecast_line_safe(DB_PATH)    
        logging.info(f"Forecast message: {message}")
    except Exception as e:
        logging.error(f"Error updating BTC OHLCV: {e}")

