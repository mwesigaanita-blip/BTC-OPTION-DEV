from __future__ import annotations
import sqlite3
import subprocess
from datetime import datetime, timezone

import pandas as pd
import numpy as np
import os
import joblib
import logging
import warnings
import sys
from typing import Any, Dict
import joblib
import os,  math, logging
from typing import  Dict
import sys
from .config import *

warnings.filterwarnings("ignore")
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
from .util_vega import (
    compute_platform_vega,
    compute_account_vega,
    apply_vega_concentration_to_slate,
    compute_dynamic_vega_caps,
)

# Logging setup
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('Main_file_log.log'),
        logging.StreamHandler()
    ]
)



def _today_utc_str() -> str:
    return datetime.now(timezone.utc).date().isoformat()  # 'YYYY-MM-DD'

def _regime_row_exists_today(db_path: str) -> bool:
    try:
        with sqlite3.connect(db_path) as con:
            cur = con.execute(
                "SELECT 1 FROM market_regime_daily WHERE snap_date=? LIMIT 1",
                (_today_utc_str(),)
            )
            return cur.fetchone() is not None
    except Exception:
        return False

_has_checked_regime_today = False  # module-level guard

def ensure_regime_daily_available():
    """
    Ensure market_regime_daily has today's row.
    If missing AND config.AUTO_RUN_DAILY_REGIME is True, run Task-7 computer once.
    Idempotent: guarded to run at most once per process.
    """
    global _has_checked_regime_today
    if _has_checked_regime_today:
        return
    _has_checked_regime_today = True

    try:
        auto = bool(globals().get("AUTO_RUN_DAILY_REGIME", True))
        dbp  = str(globals().get("DB_PATH", "btc_trading.sqlite"))
        if _regime_row_exists_today(dbp):
            return
        if not auto:
            return
        # Call the Task-7 script (relative path from project root)
        subprocess.run(
            ["python", "tasks/task_7/compute_market_regime.py"],
            check=False
        )
    except Exception:
        # soft-fail: never crash stage_1 on regime compute
        pass

def append_regime_features_if_enabled(df: pd.DataFrame) -> pd.DataFrame:
    """
    If ENABLE_REGIME_FEATURES, append regime columns for today's date
    in this order: realized_vol_7d, realized_vol_21d, iv_slope_30_7,
    market_regime_enc, regime_missing_flag.
    Missing values are filled conservatively and a missing flag is set to 1.
    """
    try:
        if not bool(globals().get("ENABLE_REGIME_FEATURES", False)):
            return df

        # make sure regime table is present for today
        ensure_regime_daily_available()

        dbp = str(globals().get("DB_PATH", "btc_trading.sqlite"))
        with sqlite3.connect(dbp) as con:
            q = "SELECT realized_vol_7d, realized_vol_21d, iv_slope_30_7, market_regime_enc FROM market_regime_daily WHERE snap_date=? LIMIT 1"
            row = pd.read_sql_query(q, con, params=[_today_utc_str()])

        # default-safe frame if missing
        if row.empty:
            row = pd.DataFrame([{
                "realized_vol_7d": np.nan,
                "realized_vol_21d": np.nan,
                "iv_slope_30_7": np.nan,
                "market_regime_enc": -1
            }])

        row = row.iloc[0]
        regime_cols = {
            "realized_vol_7d": float(row.get("realized_vol_7d")) if pd.notna(row.get("realized_vol_7d")) else np.nan,
            "realized_vol_21d": float(row.get("realized_vol_21d")) if pd.notna(row.get("realized_vol_21d")) else np.nan,
            "iv_slope_30_7": float(row.get("iv_slope_30_7")) if pd.notna(row.get("iv_slope_30_7")) else np.nan,
            "market_regime_enc": int(row.get("market_regime_enc")) if pd.notna(row.get("market_regime_enc")) else -1,
        }
        # regime_missing_flag = 1 if any numeric is NaN or enc == -1
        miss = (pd.isna(regime_cols["realized_vol_7d"]) or
                pd.isna(regime_cols["realized_vol_21d"]) or
                pd.isna(regime_cols["iv_slope_30_7"]) or
                regime_cols["market_regime_enc"] == -1)
        regime_cols["regime_missing_flag"] = 1 if miss else 0

        out = df.copy()
        for k, v in regime_cols.items():
            out[k] = v
        return out
    except Exception:
        # soft-fail: if anything goes wrong, return input unchanged
        return df


# =========================
# ML PIPELINE (SIMPLE, 6 FUNCS)
# =========================
def ml_build_features(live_df: pd.DataFrame) -> pd.DataFrame:
    """
    Build a minimal, robust feature set for PoP estimation.

    Produces at least:
      POP_FEATURES = [
        "STRIKE", "UNDERLYING_PRICE", "DTE", "DELTA", "THETA",
        "RIGHT_ENC", "MARK_IV", "STRIKE_DISTANCE_PCT"
      ]

    Also passes through when present:
      ["instrument_name","symbol","expiry_ts","MID_PRICE",
       "bid_price","ask_price","mark_price","last_price",
       "open_interest","volume","mm_required","iv_rank"]

    Notes:
      - DTE computed from: dte OR any(expiry_ts/expiration_ts/expiry/expiration/maturity/exp_ts).
      - RIGHT_ENC = 1 for Put, 0 for Call.
      - UNDERLYING_PRICE from: underlying_price/underlying/spot/index_price.
      - MID_PRICE = (bid+ask)/2 fallback->mark_price->last_price.
      - STRIKE_DISTANCE_PCT = |strike - underlying| / underlying.
      - Keeps both 'instrument_name' and 'symbol' (creates missing one from the other).
      - Adds 'expiry_ts' (epoch seconds) when an expiry can be inferred.
    """
    import numpy as np
    import pandas as pd
    from pandas.api.types import (
        is_datetime64_any_dtype,
        is_datetime64tz_dtype,
        is_object_dtype,
    )
    from datetime import datetime, timezone

    df = live_df.copy()

    # ---------- helpers ----------
    def _col(d: pd.DataFrame, names, default=np.nan):
        for n in names:
            if n in d.columns:
                return d[n]
        return pd.Series(default, index=d.index)

    def _now_ts_seconds() -> float:
        return datetime.now(timezone.utc).timestamp()

    def _right_enc(s: pd.Series) -> pd.Series:
        # Accept many synonyms, robust mapping -> {C,P} -> {0,1}
        ss = s.astype(str).str.upper().str.strip().replace({"CALL": "C", "PUT": "P"})
        return (ss == "P").astype(int)

    def _safe_midprice(d: pd.DataFrame) -> pd.Series:
        bid  = pd.to_numeric(_col(d, ["bid_price","best_bid","bid"]), errors="coerce")
        ask  = pd.to_numeric(_col(d, ["ask_price","best_ask","ask"]), errors="coerce")
        mark = pd.to_numeric(_col(d, ["mark_price","mark"]), errors="coerce")
        last = pd.to_numeric(_col(d, ["last_price","last"]), errors="coerce")
        mid = (bid + ask) / 2.0
        mid = mid.where(mid.notna(), mark).where(lambda x: x.notna(), last)
        return mid

    def _strike_distance_pct(strike: pd.Series, underlying: pd.Series) -> pd.Series:
        with np.errstate(divide="ignore", invalid="ignore"):
            out = (strike - underlying).abs() / underlying.replace(0, np.nan)
        return out.fillna(0.0)

    def _derive_expiry(df_in: pd.DataFrame):
        """
        Return (dte_days: float series, expiry_ts: float seconds series or NaN).
        Supports:
          - 'dte' directly (days)
          - numeric epoch columns (sec/ms/ns)
          - datetime-like columns (tz-naive or tz-aware)
          - ISO strings
        """
        # 1) direct dte
        if "dte" in df_in.columns:
            dte_days = pd.to_numeric(df_in["dte"], errors="coerce").fillna(0.0).astype(float)
            return dte_days, pd.Series(np.nan, index=df_in.index, dtype="float64")

        # 2) candidate expiry column
        cand_cols = ["expiry_ts","expiration_ts","exp_ts","expiry","expiration","maturity"]
        col_found = next((c for c in cand_cols if c in df_in.columns), None)
        if not col_found:
            z = pd.Series(0.0, index=df_in.index, dtype="float64")
            return z, pd.Series(np.nan, index=df_in.index, dtype="float64")

        ser = df_in[col_found]

        # A) already datetime-like (tz-naive or tz-aware)
        if is_datetime64_any_dtype(ser) or is_datetime64tz_dtype(ser):
            exp_dt = pd.to_datetime(ser, utc=True, errors="coerce")
            exp_ts = (exp_dt.view("int64") / 1e9).astype(float)  # ns -> s
            now_ts = _now_ts_seconds()
            dte = (exp_ts - now_ts) / 86400.0
            return pd.Series(np.maximum(dte, 0.0), index=ser.index), pd.to_numeric(exp_ts, errors="coerce")

        # B) object -> try parse ISO datetimes
        if is_object_dtype(ser):
            exp_dt = pd.to_datetime(ser, utc=True, errors="coerce")
            if exp_dt.notna().any():
                exp_ts = (exp_dt.view("int64") / 1e9).astype(float)
                now_ts = _now_ts_seconds()
                dte = (exp_ts - now_ts) / 86400.0
                return pd.Series(np.maximum(dte, 0.0), index=ser.index), pd.to_numeric(exp_ts, errors="coerce")

        # C) numeric epoch (seconds / ms / ns)
        num = pd.to_numeric(ser, errors="coerce").astype(float)
        exp_ts = num.copy()
        is_ms = (num > 1e11) & (num < 1e15)   # ~ms
        exp_ts[is_ms] = num[is_ms] / 1e3
        is_ns = num >= 1e15                    # ~ns
        exp_ts[is_ns] = num[is_ns] / 1e9

        now_ts = _now_ts_seconds()
        dte = (exp_ts - now_ts) / 86400.0
        dte = pd.Series(np.maximum(dte, 0.0), index=ser.index)
        return dte, pd.to_numeric(exp_ts, errors="coerce")

    # ---------- identifiers harmonization ----------
    if "instrument_name" not in df.columns and "symbol" in df.columns:
        df["instrument_name"] = df["symbol"].astype(str)
    if "symbol" not in df.columns and "instrument_name" in df.columns:
        df["symbol"] = df["instrument_name"].astype(str)

    # ---------- core numerics ----------
    df["STRIKE"]           = pd.to_numeric(_col(df, ["strike","k","exercise_price"]), errors="coerce")
    df["UNDERLYING_PRICE"] = pd.to_numeric(_col(df, ["underlying_price","underlying","spot","index_price"]), errors="coerce")
    df["DELTA"]            = pd.to_numeric(_col(df, ["delta"]), errors="coerce")
    df["THETA"]            = pd.to_numeric(_col(df, ["theta"]), errors="coerce")
    df["MARK_IV"]          = pd.to_numeric(_col(df, ["mark_iv","iv","implied_volatility"]), errors="coerce")

    dte_days, expiry_ts = _derive_expiry(df)
    df["DTE"] = dte_days.astype(float)
    df["expiry_ts"] = expiry_ts  # may be NaN if unknown

    # RIGHT_ENC from any right/option_type column
    right_src = _col(df, ["option_right","right","type","option_type"], default="C")
    df["RIGHT_ENC"] = _right_enc(right_src)

    # ---------- derived ----------
    df["STRIKE_DISTANCE_PCT"] = _strike_distance_pct(df["STRIKE"], df["UNDERLYING_PRICE"])
    df["MID_PRICE"] = _safe_midprice(df)

    # ---------- pass-through (numeric where appropriate) ----------
    for c in ["bid_price","ask_price","mark_price","last_price",
              "open_interest","volume","mm_required","iv_rank"]:
        if c in df.columns:
            df[c] = pd.to_numeric(df[c], errors="coerce")

    # ---------- ensure POP features exist ----------
    pop_features = ["STRIKE","UNDERLYING_PRICE","DTE","DELTA","THETA","RIGHT_ENC","MARK_IV","STRIKE_DISTANCE_PCT"]
    for c in pop_features:
        if c not in df.columns:
            df[c] = 0.0

    return df


# Features expected (built by ml_build_features):
POP_FEATURES = [
    "STRIKE", "UNDERLYING_PRICE", "DTE", "DELTA", "THETA",
    "RIGHT_ENC", "MARK_IV", "STRIKE_DISTANCE_PCT"
]

def ml_predict_pop(df_feat: pd.DataFrame, models: Dict[str, object]) -> pd.DataFrame:
    """
    Append model-estimated PoP columns to the feature frame:
      - pop_short: probability of success for SHORT setups
      - pop_long : probability of success for LONG setups

    Robustness:
      - Tries predict_proba (p[:, idx_pos]) with classes_ awareness
      - Falls back to decision_function -> logistic
      - Falls back to predict -> min-max scaling to [0,1] if needed
      - Handles NaNs/±inf in features, coerces to float32
    """
    import numpy as np
    import logging

    # 1) Assemble X in correct order & dtype
    X = df_feat.reindex(columns=POP_FEATURES, fill_value=0.0)
    X = X.replace([np.inf, -np.inf], np.nan).fillna(0.0)
    Xnp = X.to_numpy(dtype=np.float32, copy=False)

    m_short = models.get("pop_short")
    m_long  = models.get("pop_long")

    def _predict_prob(m, Xnp_: np.ndarray) -> np.ndarray:
        if m is None:
            # Neutral fallback if model missing
            return np.full((len(Xnp_),), 0.5, dtype=np.float32)

        # Try predict_proba first
        try:
            p = m.predict_proba(Xnp_)
            p = np.asarray(p)
            if p.ndim == 2:
                # Pick positive-class column (prefer class==1 when available)
                if hasattr(m, "classes_"):
                    try:
                        classes = list(m.classes_)
                        pos_idx = classes.index(1) if 1 in classes else -1
                    except Exception:
                        pos_idx = -1
                else:
                    pos_idx = -1
                p = p[:, pos_idx]
            else:
                p = np.squeeze(p).astype(float)
        except Exception:
            # decision_function -> logistic
            try:
                z = m.decision_function(Xnp_)
                p = 1.0 / (1.0 + np.exp(-np.asarray(z, dtype=float)))
            except Exception:
                # predict -> normalize if needed
                y = np.asarray(m.predict(Xnp_), dtype=float)
                y_min, y_max = np.nanmin(y), np.nanmax(y)
                if not (np.isfinite(y_min) and np.isfinite(y_max) and 0.0 <= y_min <= 1.0 and 0.0 <= y_max <= 1.0):
                    finite = np.isfinite(y)
                    if finite.any():
                        a, b = float(np.nanmin(y[finite])), float(np.nanmax(y[finite]))
                        if b > a:
                            y = (y - a) / (b - a)
                        else:
                            y = np.zeros_like(y, dtype=float)
                    else:
                        y = np.zeros_like(y, dtype=float)
                p = y

        # Final cleaning
        p = np.asarray(p, dtype=float)
        if p.shape != (len(Xnp_),):
            # Shape guard (rare pipeline quirks)
            try:
                p = np.squeeze(p)
            except Exception:
                p = np.full((len(Xnp_),), 0.5, dtype=float)
        p = np.clip(p, 0.0, 1.0)
        if np.isnan(p).any():
            p = np.where(np.isnan(p), 0.5, p)
        return p.astype(np.float32)

    try:
        ps = _predict_prob(m_short, Xnp)
    except Exception as e:
        logging.warning("pop_short prediction failed (%s); using 0.5.", e)
        ps = np.full((len(Xnp),), 0.5, dtype=np.float32)

    try:
        pl = _predict_prob(m_long, Xnp)
    except Exception as e:
        logging.warning("pop_long prediction failed (%s); using 0.5.", e)
        pl = np.full((len(Xnp),), 0.5, dtype=np.float32)

    out = df_feat.copy()
    out["pop_short"] = ps
    out["pop_long"]  = pl

    logging.info("PoP prediction: %d rows (short/long mean=%.3f/%.3f)",
                 len(out), float(np.mean(ps)), float(np.mean(pl)))
    return out

# --- 5) Rank & clip
def ml_rank_and_clip(df: pd.DataFrame) -> pd.DataFrame:
    """
    Add efficiency features to a single candidate DataFrame and return it.
    Columns added (if inputs available):
      - _theta_usd    = (-theta) * underlying_price   (clipped >= 0)
      - _premium_usd  = entry_btc * underlying_price  (entry_btc = MID_PRICE or mark_price)
      - _mm_est       = mark_price + 0.1 * underlying_price
      - _theta_eff    = _theta_usd   / _mm_est
      - _premium_eff  = _premium_usd / _mm_est
    No ranking/clipping. No short/long split.
    """
    import numpy as np
    import pandas as pd

    if df is None or df.empty:
        return df.copy() if isinstance(df, pd.DataFrame) else pd.DataFrame()

    out = df.copy()

    # Resolve column names (support old UPPER/new lower-case schemas)
    def _col(*names: str) -> str | None:
        for n in names:
            if n in out.columns:
                return n
        return None

    c_theta = _col("THETA", "theta")
    c_under = _col("UNDERLYING_PRICE", "underlying_price", "index_price")
    c_mid   = _col("MID_PRICE", "mid_price")
    c_mark  = _col("mark_price", "MARK_PRICE")

    # Prepare numeric series (float) aligned to index
    idx = out.index
    theta = pd.to_numeric(out[c_theta], errors="coerce") if c_theta else pd.Series(np.nan, index=idx, dtype=float)
    under = pd.to_numeric(out[c_under], errors="coerce") if c_under else pd.Series(np.nan, index=idx, dtype=float)
    mid   = pd.to_numeric(out[c_mid],   errors="coerce") if c_mid   else pd.Series(np.nan, index=idx, dtype=float)
    mark  = pd.to_numeric(out[c_mark],  errors="coerce") if c_mark  else pd.Series(np.nan, index=idx, dtype=float)

    # Theta $/day: short benefits from holder's negative theta
    out["_theta_usd"] = (-theta) * under
    out["_theta_usd"] = out["_theta_usd"].clip(lower=0.0)

    # Premium USD using preferred entry price (MID then mark)
    entry_btc = mid.where(mid.notna(), mark)
    out["_premium_usd"] = entry_btc * under

    # Cheap margin proxy (preserve heuristic units from prior code)
    mm_est = (mark.fillna(0.0) + 0.1 * under.fillna(0.0))
    mm_est = mm_est.replace(0.0, np.nan)  # avoid div-by-zero / inf
    out["_mm_est"] = mm_est

    # Efficiencies
    out["_theta_eff"]   = out["_theta_usd"]   / out["_mm_est"]
    out["_premium_eff"] = out["_premium_usd"] / out["_mm_est"]

    return out

from typing import Optional
import numpy as np
import pandas as pd

def _safe_col(df: pd.DataFrame, name: str, default=0.0, dtype=float) -> pd.Series:
    """
    Always returns a pandas Series aligned to df.index.
    If column is missing, returns a Series filled with `default`.
    If present, coerces to numeric and fills NaNs with `default`.
    """
    if name in df.columns:
        s = pd.to_numeric(df[name], errors="coerce")
        return s.fillna(default).astype(dtype)
    # missing column -> scalar default is unsafe for .fillna; return Series
    return pd.Series(default, index=df.index, dtype=dtype)


def ml_prepare_candidate_tables(candidates_df: pd.DataFrame,
                                max_cand_rows: int = 800) -> pd.DataFrame:
    """
    Build a compact, single-slate candidates table (NO short/long split).

    - Robust to missing columns (never calls .fillna on scalars).
    - Ensures 'symbol' (UPPER) and 'instrument_name' exist.
    - Keeps LLM/ML-friendly columns, including Task-8 Vega diagnostics if present.
    - Creates a stable ordering score 'ord_score' from:
        _theta_eff, _premium_eff, iv_rank/ivr_xsec, and liquidity (open_interest + volume).
      Falls back to score_short/score_long or pop_short/pop_long if efficiencies are missing.
    - Returns top `max_cand_rows`, preserves float `qty`.
    """
    if not isinstance(candidates_df, pd.DataFrame) or candidates_df.empty:
        return pd.DataFrame()

    df = candidates_df.copy()

    # ---------------- ID harmonization ----------------
    if "symbol" not in df.columns and "instrument_name" in df.columns:
        df["symbol"] = df["instrument_name"].astype(str)
    if "instrument_name" not in df.columns and "symbol" in df.columns:
        df["instrument_name"] = df["symbol"].astype(str)
    if "symbol" in df.columns:
        df["symbol"] = df["symbol"].astype(str).str.upper()

    # ---------------- Numeric harmonization ----------------
    # DTE: accept either 'DTE' or 'dte'; create numeric 'DTE'
    if "DTE" not in df.columns:
        if "dte" in df.columns:
            df["DTE"] = _safe_col(df, "dte", default=0.0, dtype=float)
        else:
            df["DTE"] = pd.Series(0.0, index=df.index, dtype=float)
    else:
        df["DTE"] = _safe_col(df, "DTE", default=0.0, dtype=float)

    # STRIKE / strike -> 'strike' as float
    if "strike" not in df.columns and "STRIKE" in df.columns:
        df["strike"] = df["STRIKE"]
    df["strike"] = _safe_col(df, "strike", default=np.nan, dtype=float)

    # Greeks / prices / liquidity (safe series)
    delta = _safe_col(df, "delta", default=np.nan, dtype=float)
    theta = _safe_col(df, "theta", default=np.nan, dtype=float)
    oi    = _safe_col(df, "open_interest", default=0.0, dtype=float)
    vol   = _safe_col(df, "volume", default=0.0, dtype=float)
    bid   = _safe_col(df, "bid_price", default=np.nan, dtype=float)
    ask   = _safe_col(df, "ask_price", default=np.nan, dtype=float)

    # mid_price: prefer 'mid_price', else (bid+ask)/2, else mark_price, else UNDERLYING_PRICE fallback
    mid_existing = _safe_col(df, "mid_price", default=np.nan, dtype=float)
    mark_price  = _safe_col(df, "mark_price", default=np.nan, dtype=float)
    mid_by_ba   = (bid + ask) / 2.0
    underlying  = _safe_col(df, "underlying_price", default=np.nan, dtype=float)

    mid = mid_existing.copy()
    mid = np.where(np.isfinite(mid), mid, np.where(np.isfinite(mid_by_ba), mid_by_ba, mid))
    mid = np.where(np.isfinite(mid), mid, np.where(np.isfinite(mark_price), mark_price, mid))
    mid = pd.Series(np.where(np.isfinite(mid), mid, underlying), index=df.index, dtype=float)
    df["mid_price"] = mid

    # spread_pct (safe)
    with pd.option_context("mode.use_inf_as_na", True):
        spread_num = ask - bid
        spread_den = df["mid_price"]
        df["spread_pct"] = (spread_num / spread_den) * 100.0
        df["spread_pct"] = pd.to_numeric(df["spread_pct"], errors="coerce").replace([np.inf, -np.inf], np.nan)

    # Sizing hints (keep qty as float)
    df["qty"]         = _safe_col(df, "qty", default=0.0, dtype=float)
    df["qty_max_sell"]= _safe_col(df, "qty_max_sell", default=0.0, dtype=float)
    df["qty_max_buy"] = _safe_col(df, "qty_max_buy", default=0.0, dtype=float)

    # ---------------- Scoring features ----------------
    theta_eff = _safe_col(df, "_theta_eff", default=0.0, dtype=float)
    prem_eff  = _safe_col(df, "_premium_eff", default=0.0, dtype=float)
    iv_rank   = _safe_col(df, "iv_rank", default=0.0, dtype=float)
    ivr_xsec  = _safe_col(df, "ivr_xsec", default=0.0, dtype=float)
    iv_sig    = iv_rank.copy()
    if (iv_sig.max() <= 0) and (ivr_xsec.max() > 0):
        iv_sig = ivr_xsec

    liq = oi + vol
    liq = pd.to_numeric(liq, errors="coerce").fillna(0.0)
    liq = liq.clip(lower=0.0)

    def _norm01(s: pd.Series) -> pd.Series:
        s = pd.to_numeric(s, errors="coerce").fillna(0.0).astype(float)
        m = float(s.max()) if len(s) else 0.0
        return (s / m) if m > 0 else s * 0.0

    ord_score = (
        0.45 * _norm01(theta_eff) +
        0.35 * _norm01(prem_eff)  +
        0.15 * _norm01(iv_sig)    +
        0.05 * _norm01(liq)
    )

    # Fallback when efficiencies are missing/zero
    if float(ord_score.max() if len(ord_score) else 0.0) == 0.0:
        alt = None
        if ("score_short" in df.columns) or ("score_long" in df.columns):
            alt = pd.concat(
                [ _safe_col(df, "score_short", default=0.0, dtype=float),
                  _safe_col(df, "score_long",  default=0.0, dtype=float) ],
                axis=1
            ).max(axis=1, skipna=True)
        elif ("pop_short" in df.columns) or ("pop_long" in df.columns):
            alt = pd.concat(
                [ _safe_col(df, "pop_short", default=0.0, dtype=float),
                  _safe_col(df, "pop_long",  default=0.0, dtype=float) ],
                axis=1
            ).max(axis=1, skipna=True)
        if alt is not None:
            ord_score = _norm01(alt)

    df["_ord"] = pd.to_numeric(ord_score, errors="coerce").fillna(0.0)

    # ---------------- Columns to keep (LLM/ML friendly) ----------------
    keep_cols = []

    def _add_if_exists(cols):
        nonlocal keep_cols
        keep_cols += [c for c in cols if c in df.columns]

    _add_if_exists([
        # IDs
        "symbol", "instrument_name",
        # core fields
        "option_type", "expiry", "DTE", "strike",
        "mid_price", "bid_price", "ask_price", "spread_pct",
        "open_interest", "volume",
        # sizing
        "qty_max_sell", "qty_max_buy", "qty",
        # greeks (optional but useful)
        "delta", "theta",
        # efficiencies/signals
        "_theta_eff", "_premium_eff", "iv_rank", "ivr_xsec",
        # fallbacks
        "score_short", "score_long", "pop_short", "pop_long",
        # Task-8 Vega diagnostics (include if present)
        "vega_bucket_code", "vega_bucket_label",
        "share_bucket_now", "share_bucket_proj",
        "share_total_now", "share_total_proj",
        "eligible_vega"
    ])

    df = df.sort_values("_ord", ascending=False).drop(columns=["_ord"]).reset_index(drop=True)
    if max_cand_rows is not None:
        df = df.head(int(max_cand_rows))

    # Ensure we only return the curated columns (but keep graceful if some missing)
    keep_cols = [c for c in keep_cols if c in df.columns]
    if keep_cols:
        df = df[keep_cols].copy()

    # Strip any legacy 'side' column if present
    if "side" in df.columns:
        df = df.drop(columns=["side"])

    # Final light rounding for presentation (NOT execution)
    if "qty" in df.columns:
        df["qty"] = pd.to_numeric(df["qty"], errors="coerce").astype(float).round(5)
    for c in ("mid_price","bid_price","ask_price"):
        if c in df.columns:
            df[c] = pd.to_numeric(df[c], errors="coerce").astype(float).round(5)
    if "spread_pct" in df.columns:
        df["spread_pct"] = pd.to_numeric(df["spread_pct"], errors="coerce").astype(float).round(3)
    if "strike" in df.columns:
        df["strike"] = pd.to_numeric(df["strike"], errors="coerce").astype(float).round(2)
    if "DTE" in df.columns:
        # keep DTE as int-like for readability
        try:
            df["DTE"] = df["DTE"].astype(float).round(0).astype(int)
        except Exception:
            pass

    return df

def backtest_rsi_stoch_rule(use_df: "pd.DataFrame", forward_days: int = 5) -> dict:
    """
    use_df must have columns: close, signal_bearish_overbought, signal_bullish_oversold
    Returns basic stats for each signal.
    """
    import numpy as np
    import pandas as pd

    df = use_df.copy()
    df = df.dropna(subset=["close"])
    df["fwd_ret"] = df["close"].shift(-forward_days) / df["close"] - 1.0

    def _stats(mask: pd.Series) -> dict:
        sub = df.loc[mask & df["fwd_ret"].notna(), "fwd_ret"]
        if sub.empty:
            return {"count": 0, "avg_ret": None, "median_ret": None, "win_rate": None}
        return {
            "count": int(sub.shape[0]),
            "avg_ret": float(sub.mean()),
            "median_ret": float(sub.median()),
            "win_rate": float((sub > 0).mean()),
        }

    out = {
        "forward_days": forward_days,
        "bearish_overbought": _stats(df["signal_bearish_overbought"] == True),
        "bullish_oversold": _stats(df["signal_bullish_oversold"] == True),
    }
    return out


def btc_range_forecast(
    daily_ohlc,                       # DataFrame OR CSV path (your original file format is OK)
    artifacts_dir="Models/range_model_artifacts_42d",
):
    """
    Load the trained LSTM range model + scaler + meta and produce calibrated price bands
    for available horizons among: 5d (1w), 10d (2w), 21d (1m), 42d (2m), 63d (3m),
    based on the latest LOOKBACK trading days.

    Loader strategy (robust to keras/tf.keras differences):
      1) Prefer loading the .keras file with standalone `keras` (Keras 3).
      2) If a SavedModel directory is present in meta, try `tf.keras.models.load_model` on it.
      3) As a last resort, try `tf.keras.models.load_model` on the .keras file.
    """
    import os, json, re
    import numpy as np
    import pandas as pd
    from pathlib import Path
    import joblib

    # ---------- 0) Load artifacts ----------
    meta_path   = os.path.join(artifacts_dir, "meta.json")
    scaler_path = os.path.join(artifacts_dir, "scaler.pkl")

    if not (os.path.exists(meta_path) and os.path.exists(scaler_path)):
        raise FileNotFoundError(f"Missing artifacts in {artifacts_dir}. Expect scaler.pkl and meta.json")

    with open(meta_path, "r", encoding="utf-8") as f:
        meta = json.load(f)

    # Model filenames from meta (with fallbacks)
    model_file      = meta.get("model_file") or "lstm_range_multiout_42d.keras"
    weights_file    = meta.get("weights_file")  # optional
    savedmodel_dir  = meta.get("savedmodel_dir")  # optional (directory name)
    preferred_loader = (meta.get("preferred_loader") or "keras").lower()

    keras_model_path   = os.path.join(artifacts_dir, model_file)
    savedmodel_path    = os.path.join(artifacts_dir, savedmodel_dir) if savedmodel_dir else None
    weights_path       = os.path.join(artifacts_dir, weights_file) if weights_file else None

    # Load scaler
    scaler = joblib.load(scaler_path)

    # Try to load the model in a loader-safe way
    model = None
    load_errors = []

    # 1) Standalone keras (Keras 3) on .keras file
    if model is None and os.path.exists(keras_model_path) and preferred_loader == "keras":
        try:
            os.environ.setdefault("KERAS_BACKEND", "tensorflow")
            import keras as k  # standalone Keras 3
            model = k.models.load_model(keras_model_path, compile=False)
        except Exception as e:
            load_errors.append(("keras.load_model(.keras)", str(e)))
            model = None

    # 2) tf.keras on SavedModel directory (if available)
    if model is None and savedmodel_path and os.path.isdir(savedmodel_path):
        try:
            from tensorflow import keras as tfk
            model = tfk.models.load_model(savedmodel_path, compile=False)
        except Exception as e:
            load_errors.append(("tf.keras.load_model(SavedModel)", str(e)))
            model = None

    # 3) tf.keras on .keras file (last resort)
    if model is None and os.path.exists(keras_model_path):
        try:
            from tensorflow import keras as tfk
            model = tfk.models.load_model(keras_model_path, compile=False)
        except Exception as e:
            load_errors.append(("tf.keras.load_model(.keras)", str(e)))
            model = None

    if model is None:
        hint = (
            f"Failed to load model. Tried: {load_errors}. "
            f"Artifacts seen: model_file={keras_model_path!r}, savedmodel_dir={savedmodel_path!r}, weights={weights_path!r}. "
            "Ensure you load .keras with standalone `keras` or use the SavedModel with `tf.keras`."
        )
        raise RuntimeError(hint)

    # Meta
    LOOKBACK     = int(meta.get("lookback", 63))
    feature_cols = list(meta.get("feature_cols") or [])
    y_cols       = list(meta.get("y_cols") or [])
    m_per_h      = {k: float(v) for k, v in (meta.get("m_per_h", {}) or {}).items()}

    if not feature_cols:
        feature_cols = [
            "ret_1d","logret_1d",
            "rvol_5","rvol_10","rvol_21","rvol_63",
            "hl_pct","hl_mean_5","hl_mean_10","hl_mean_21","hl_mean_63",
            "sma_ratio_5","sma_ratio_10","sma_ratio_21","sma_ratio_63",
            "vol_chg","vol_z_5","vol_z_21","vol_z_63",
        ]
    if not y_cols:
        # fallback supports both 8-output (no 42d) and 10-output (with 42d)
        if "42d" in m_per_h:
            y_cols = [
                "range_up_5d","range_up_10d","range_up_21d","range_up_42d","range_up_63d",
                "range_dn_5d","range_dn_10d","range_dn_21d","range_dn_42d","range_dn_63d",
            ]
        else:
            y_cols = [
                "range_up_5d","range_up_10d","range_up_21d","range_up_63d",
                "range_dn_5d","range_dn_10d","range_dn_21d","range_dn_63d",
            ]

    # ---------- 1) Load data (CSV or DF) and normalize OHLCV ----------
    if isinstance(daily_ohlc, (str, os.PathLike)):
        df = pd.read_csv(daily_ohlc)
    else:
        df = daily_ohlc.copy()

    # lower-case columns for matching
    df.columns = [str(c).strip().lower() for c in df.columns]

    # Find a date/time column
    date_col = None
    for c in ("time","date","datetime","timestamp","open_time","close_time"):
        if c in df.columns:
            date_col = c
            break
    if date_col is None:
        raise ValueError("No timestamp-like column found (expected one of: time/date/datetime/timestamp/open_time/close_time).")

    # Parse to datetime (UTC), drop non-date rows (e.g., footer), sort ascending
    df["date"] = pd.to_datetime(df[date_col], errors="coerce", utc=True)
    df = df.dropna(subset=["date"]).sort_values("date").set_index("date")

    # Map common source names to OHLCV (your CSV had: time, open, high, low, last, change, %chg, volume)
    name_map = {}
    cols = set(df.columns)
    if "open" in cols:  name_map["open"]  = "open"
    if "high" in cols:  name_map["high"]  = "high"
    if "low"  in cols:  name_map["low"]   = "low"
    if "close" in cols:             name_map["close"]  = "close"
    elif "last" in cols:            name_map["close"]  = "last"
    elif "adj_close" in cols:       name_map["close"]  = "adj_close"
    elif "adj close" in cols:       name_map["close"]  = "adj close"
    if "volume" in cols:            name_map["volume"] = "volume"

    missing = [k for k in ("open","high","low","close","volume") if k not in name_map]
    if missing:
        raise ValueError(f"Missing required OHLCV columns (after mapping): {missing}. Found columns: {sorted(df.columns)}")

    use = df[[name_map["open"], name_map["high"], name_map["low"], name_map["close"], name_map["volume"]]].copy()
    use.columns = ["open","high","low","close","volume"]
    # ---------- INDICATORS (NOT fed to the LSTM model) ----------
    def _rsi(series: pd.Series, period: int = 14) -> pd.Series:
        delta = series.diff()
        gain = delta.clip(lower=0)
        loss = (-delta).clip(lower=0)

        # Wilder's smoothing
        avg_gain = gain.ewm(alpha=1/period, min_periods=period, adjust=False).mean()
        avg_loss = loss.ewm(alpha=1/period, min_periods=period, adjust=False).mean()

        rs = avg_gain / (avg_loss + 1e-12)
        return 100 - (100 / (1 + rs))

    def _stoch_k(high: pd.Series, low: pd.Series, close: pd.Series, k_period: int = 14) -> pd.Series:
        ll = low.rolling(k_period).min()
        hh = high.rolling(k_period).max()
        return 100 * (close - ll) / ((hh - ll) + 1e-12)

    # Compute indicator series on full history (so backtest works too)
    use["rsi_14"] = _rsi(use["close"], period=14)
    use["stoch_k_14"] = _stoch_k(use["high"], use["low"], use["close"], k_period=14)
    use["stoch_d_14"] = use["stoch_k_14"].rolling(3).mean()

    # The rule you want to test
    use["signal_bearish_overbought"] = (use["rsi_14"] > 70) & (use["stoch_k_14"] > 90)
    use["signal_bullish_oversold"]   = (use["rsi_14"] < 30) & (use["stoch_k_14"] < 10)
    # ----------------------------------------------------------
    # Clean numerics: strip commas, parse K/M/B in volume
    def _to_float(x):
        if isinstance(x, (int, float)): return float(x)
        s = str(x).strip().replace(",", "")
        try:
            return float(s)
        except Exception:
            return np.nan

    def _parse_volume(x):
        if isinstance(x, (int, float)): return float(x)
        s = str(x).strip().replace(",", "").upper()
        m = re.match(r"^([+-]?\d*\.?\d+)\s*([KMB])?$", s)
        if not m:
            try: return float(s)
            except: return np.nan
        val, suf = m.groups()
        mult = {"K":1e3, "M":1e6, "B":1e9}.get(suf, 1.0)
        return float(val) * mult

    for c in ("open","high","low","close"):
        use[c] = use[c].apply(_to_float)
    use["volume"] = use["volume"].apply(_parse_volume)

    # ---------- 2) Recreate notebook features ----------
    feat = use.copy()
    feat["ret_1d"]    = feat["close"].pct_change()
    feat["logret_1d"] = np.log1p(feat["ret_1d"])
    for w in (5, 10, 21, 63):
        feat[f"rvol_{w}"] = feat["logret_1d"].rolling(w).std() * np.sqrt(252)

    feat["hl_pct"] = (feat["high"] - feat["low"]) / feat["close"]
    for w in (5, 10, 21, 63):
        feat[f"hl_mean_{w}"] = feat["hl_pct"].rolling(w).mean()

    for w in (5, 10, 21, 63):
        feat[f"sma_ratio_{w}"] = feat["close"] / feat["close"].rolling(w).mean() - 1.0

    feat["vol_chg"] = feat["volume"].pct_change()
    for w in (5, 21, 63):
        m = feat["volume"].rolling(w).mean()
        s = feat["volume"].rolling(w).std()
        feat[f"vol_z_{w}"] = (feat["volume"] - m) / (s + 1e-12)

    # Keep only the features we trained on; drop warmup NaNs and grab the last LOOKBACK rows
    feat = feat[feature_cols].replace([np.inf, -np.inf], np.nan).dropna().tail(LOOKBACK)
    if len(feat) < LOOKBACK:
        raise ValueError(f"Not enough clean history to build a {LOOKBACK}-step window (got {len(feat)} rows after warmup).")

    # ---------- 3) Scale, make sequence, predict ----------
    X = scaler.transform(feat.values)[None, :, :]   # (1, LOOKBACK, n_features)
    y = model.predict(X, verbose=0)[0]              # (len(y_cols),) in fractions, e.g. 0.05 = +5%

    raw = dict(zip(y_cols, [float(v) for v in y.tolist()]))

    # ---------- 4) Apply calibration factors per horizon ----------
    close_t = float(use["close"].iloc[-1])
    as_of   = feat.index[-1].date().isoformat()

    # discover available horizons dynamically from y_cols
    def has_pair(h):
        return (f"range_up_{h}" in raw) and (f"range_dn_{h}" in raw)

    horizons = [h for h in ("5d","10d","21d","42d","63d") if has_pair(h)]

    def _apply(h):
        up_key, dn_key = f"range_up_{h}", f"range_dn_{h}"
        m = float(m_per_h.get(h, 1.0))
        up = max(float(raw[up_key]), 0.0)
        dn = min(float(raw[dn_key]), 0.0)
        up_pct  = m * up
        dn_pct  = m * dn
        return {
            "upper": close_t * (1.0 + up_pct),
            "lower": close_t * (1.0 + dn_pct),
            "up_pct":   100.0 * up_pct,
            "down_pct": 100.0 * dn_pct,
            "m_used":   m,
        }
    # Latest indicator snapshot (may be NaN if not enough history yet)
    latest_rsi = float(use["rsi_14"].iloc[-1]) if pd.notna(use["rsi_14"].iloc[-1]) else None
    latest_k   = float(use["stoch_k_14"].iloc[-1]) if pd.notna(use["stoch_k_14"].iloc[-1]) else None

    latest_bearish = bool(use["signal_bearish_overbought"].iloc[-1]) if pd.notna(use["signal_bearish_overbought"].iloc[-1]) else False
    latest_bullish = bool(use["signal_bullish_oversold"].iloc[-1])   if pd.notna(use["signal_bullish_oversold"].iloc[-1]) else False

    rule_bt_5d = backtest_rsi_stoch_rule(use, forward_days=5)
    # ---------- 5) Build output ----------
    out = {
        "as_of": as_of,
        "close": close_t,

        "indicators": {
            "rsi_14": latest_rsi,
            "stoch_k_14": latest_k,
            "signal_bearish_overbought": latest_bearish,
            "signal_bullish_oversold": latest_bullish,
        },

        "horizons": {h: _apply(h) for h in horizons},
        "raw_pred": raw,
        "meta": {
            "lookback": LOOKBACK,
            "feature_cols": feature_cols,
            "y_cols": y_cols,
            "calibration_used": m_per_h,
        },
        "rule_backtest": {
            "rsi_stoch": rule_bt_5d
        },
    }

    return out


def ml_load_models(pop_short_path: str, pop_long_path: str, voting_model_path: str | None = None) -> Dict[str, object]:
    models = {
        "pop_short": joblib.load(pop_short_path),
        "pop_long" : joblib.load(pop_long_path),
    }
    if voting_model_path:
        try:
            models["voting"] = joblib.load(voting_model_path)
        except FileNotFoundError:
            models["voting"] = None
    else:
        models["voting"] = None
    return models

# stage_1.py - helper for soft fallback
def _maybe_soft_fallback_caps(bucket_caps: dict, min_thr: dict):
    """
    Returns (bucket_caps2, min_thr2) after applying one-time soft fallback boosts.
    """
    from . import config
    if not getattr(config, "SOFT_FALLBACK_ENABLE", True):
        return bucket_caps, min_thr
    bcap2 = {k: v * float(getattr(config, "SOFT_FALLBACK_BUCKET_BOOST", 1.10)) for k, v in bucket_caps.items()}
    mthr2 = {k: (v * float(getattr(config, "SOFT_FALLBACK_MIN_THR_SHRINK", 0.90))) for k, v in min_thr.items()}
    return bcap2, mthr2



def phase1_screen_and_rank(
    df: pd.DataFrame,
    *,
    positions_df: pd.DataFrame | None = None,
    return_after_vega: bool = True,
    min_target_after_cfg: int = 20,   # try to keep at least this many before Vega
    **kwargs
) -> pd.DataFrame:
    """
    Phase-1 deterministic screening + (optional) Vega concentration enforcement.
    Adds diagnostics so we can see *why* rows are filtered.
    Adaptive: if IVR is over-filtering, relax it automatically.
    """
    import logging, numpy as np, pandas as pd
    from . import config


    if df is None or df.empty:
        logging.info("[Phase-1] Empty live universe.")
        return df

    slate = df.copy()
    slate["_drop_reason"] = ""

    # ---------- 0) Ensure DTE BEFORE CFG ----------
    if "DTE" not in slate.columns:
        if "expiration" in slate.columns:
            exp = pd.to_datetime(slate["expiration"], errors="coerce", utc=True)
            now_utc = pd.Timestamp.now(tz="UTC")
            slate["DTE"] = np.maximum(
                0, np.floor((exp - now_utc).dt.total_seconds() / 86400.0).astype("float")
            )
        else:
            raise ValueError("[Phase-1] Required column 'DTE' missing and cannot be derived from 'expiration'.")

    # ---------- 1) IV decimal fallback ----------
    if "mark_iv_dec" not in slate.columns:
        if "mark_iv" in slate.columns:
            tmp_iv = pd.to_numeric(slate["mark_iv"], errors="coerce")
            slate["mark_iv_dec"] = tmp_iv.where(tmp_iv <= 2.5, tmp_iv / 100.0).clip(lower=0.0)
        else:
            slate["mark_iv_dec"] = np.nan

    # ---------- 2) CFG ----------
    _cfg = (kwargs.get("cfg") or getattr(config, "CFG", {})) or {}
    dte_min        = float(_cfg.get("dte_min",        70))
    dte_max        = float(_cfg.get("dte_max",        280))
    # IMPORTANT: allow ultra-OTM by default; let Phase-2 kill bad ones
    delta_abs_min  = float(_cfg.get("delta_abs_min",  0.0))
    delta_abs_max  = float(_cfg.get("delta_abs_max",  0.28))
    min_vol        = float(_cfg.get("min_vol",        0.0001))


    # ---------- 3) Normalize numeric ----------
    slate["DTE"]           = pd.to_numeric(slate["DTE"], errors="coerce")
    slate["open_interest"] = pd.to_numeric(slate.get("open_interest"), errors="coerce")
    slate["volume"]        = pd.to_numeric(slate.get("volume"), errors="coerce")

    bid  = pd.to_numeric(slate.get("bid_price"),  errors="coerce")
    ask  = pd.to_numeric(slate.get("ask_price"),  errors="coerce")
    mid0 = pd.to_numeric(slate.get("mid_price"),  errors="coerce")
    mark = pd.to_numeric(slate.get("mark_price"), errors="coerce")
    mid_ba = (bid + ask) / 2.0
    mid = mid0.where(mid0.notna(), mid_ba.where(mid_ba.notna(), mark))
    slate["mid_price"] = pd.to_numeric(mid, errors="coerce")

    den = slate["mid_price"].where(slate["mid_price"] > 0, np.nan)
    slate["_spread_frac"] = pd.to_numeric((ask - bid) / den, errors="coerce")

    delta = pd.to_numeric(slate.get("delta"), errors="coerce")
    slate["_delta_abs"] = delta.abs()

    # --- NEW: delta diagnostics ---
    n_total = int(len(slate))
    n_delta_nan = int(delta.isna().sum())
    n_delta_ok = n_total - n_delta_nan
    logging.info(f"[Phase-1] Delta coverage: total={n_total} | delta_nan={n_delta_nan} | delta_present={n_delta_ok}")

    # Optional: show a quick breakdown by option_type (helpful)
    if "option_type" in slate.columns and n_total > 0:
        try:
            by_type = (
                slate.assign(_delta_nan=delta.isna())
                     .groupby("option_type")["_delta_nan"]
                     .agg(total="count", delta_nan="sum")
            )
            by_type["delta_present"] = by_type["total"] - by_type["delta_nan"]
            # one-line log (avoid huge logs)
            parts = []
            for idx, row in by_type.iterrows():
                parts.append(f"{idx}:total={int(row['total'])},nan={int(row['delta_nan'])},ok={int(row['delta_present'])}")
            logging.info("[Phase-1] Delta coverage by option_type: " + " | ".join(parts))
        except Exception as e:
            logging.warning(f"[Phase-1] Could not compute delta coverage by option_type: {e}")

    slate["_delta_abs"] = delta.abs()

    iv       = pd.to_numeric(slate.get("mark_iv_dec"), errors="coerce")
    iv_rank  = pd.to_numeric(slate.get("iv_rank"),     errors="coerce")
    ivr_xsec = pd.to_numeric(slate.get("ivr_xsec"),    errors="coerce")

    # ---------- 4) Deterministic masks (or-missing passes) ----------
    m_dte    = slate["DTE"].between(dte_min, dte_max, inclusive="both").where(slate["DTE"].notna(), True)
    m_delta  = slate["_delta_abs"].between(delta_abs_min, delta_abs_max, inclusive="both").where(
        slate["_delta_abs"].notna(), True
    )

    # --- NEW: delta filter diagnostics ---
    try:
        # only evaluate pass/fail among rows that actually have a delta
        has_delta = slate["_delta_abs"].notna()
        n_has = int(has_delta.sum())
        n_pass = int((m_delta & has_delta).sum())
        n_fail = int((~m_delta & has_delta).sum())
        logging.info(
            f"[Phase-1] Delta filter (only where present): has_delta={n_has} | pass={n_pass} | fail={n_fail} "
            f"| band=[{delta_abs_min},{delta_abs_max}]"
        )
    except Exception as e:
        logging.warning(f"[Phase-1] Could not compute delta filter diagnostics: {e}")



    # IV only if we actually have values
    m_iv = pd.Series(True, index=slate.index)


    # IVR enforcement ONLY if enough coverage; else pass
    m_ivr = pd.Series(True, index=slate.index)
    ivr_cov = (iv_rank.notna().mean() if len(iv_rank) else 0.0)
    xsec_cov = (ivr_xsec.notna().mean() if len(ivr_xsec) else 0.0)

    # else leave m_ivr=True (don’t over-filter on sparse IVR)

    mask_all = m_dte & m_delta  & m_iv & m_ivr
    after_cfg = slate.loc[mask_all].copy()

    # Diagnostics (why dropped)
    dropped = slate.index.difference(after_cfg.index)
    if len(dropped):
        reasons = []
        for name, m in [
            ("DTE", m_dte), ("DELTA", m_delta),
            ("IV", m_iv), ("IVR", m_ivr),
        ]:
            bad = (~m).fillna(False)
            cnt = int(bad.loc[dropped].sum())
            if cnt:
                reasons.append(f"{name}:{cnt}")
        logging.info(f"[Phase-1] Dropped {len(dropped)} rows at CFG stage; reasons: {', '.join(reasons) or 'mixed'}")

    if after_cfg.empty:
        logging.info("[Phase-1] Empty after CFG filters.")
        return after_cfg

    # Adaptive nudge: if we’re still too few, relax IVR (only) once
    if len(after_cfg) < min_target_after_cfg and (ivr_cov >= 0.70 or xsec_cov >= 0.70):
        logging.info(f"[Phase-1] Only {len(after_cfg)} after CFG; relaxing IVR for this pass.")
        mask_all2 = m_dte & m_delta  & m_iv
        after_cfg = slate.loc[mask_all2].copy()

    if not return_after_vega:
        return after_cfg

    # ---------- 5) Vega prerequisites ----------
    if "vega" not in after_cfg.columns:
        raise ValueError("[Phase-1] Required column 'vega' not found in live universe.")
    after_cfg["vega"] = pd.to_numeric(after_cfg["vega"], errors="coerce").fillna(0.0)

    if "open_interest" not in after_cfg.columns:
        raise ValueError("[Phase-1] Need 'open_interest' to estimate platform Vega.")
    after_cfg["open_interest"] = pd.to_numeric(after_cfg["open_interest"], errors="coerce").fillna(0.0)

    # qty: default to book or 1 (so vega caps won’t drop due to 0)
    if "qty" not in after_cfg.columns:
        logging.info("[Phase-1] 'qty' column missing; deriving from qty_max_sell/qty_max_buy or defaulting to 1.")
        q_s = pd.to_numeric(after_cfg.get("qty_max_sell"), errors="coerce")
        q_b = pd.to_numeric(after_cfg.get("qty_max_buy"),  errors="coerce")
        q = np.minimum(q_s.fillna(0.0), q_b.fillna(0.0))
        q = np.where((q_s.notna() | q_b.notna()), q, 1.0)  # default 1 if both missing
        after_cfg["qty"] = pd.to_numeric(q, errors="coerce").fillna(1.0).astype(float)
    else:
        after_cfg["qty"] = pd.to_numeric(after_cfg["qty"], errors="coerce").fillna(1.0).astype(float)

    # ---------- 6) Compute platform & account Vega ----------
    plat_bucket, plat_total = compute_platform_vega(after_cfg, config.VEGA_BUCKETS)
    acct_bucket, acct_total = ({b[2]: 0.0 for b in config.VEGA_BUCKETS}, 0.0)
    if positions_df is not None and not positions_df.empty:
        try:
            acct_bucket, acct_total = compute_account_vega(positions_df, config.VEGA_BUCKETS)
        except Exception as e:
            logging.warning(f"[Phase-1] Could not compute account vega from positions: {e}")

    # ---------- 7) Caps (with optional auto-tune) ----------
    dyn_cfg = dict(
        enable  = bool(getattr(config, "DYNAMIC_VEGA_CAP_BOOST_ENABLE", True)),
        trigger = float(getattr(config, "DYNAMIC_VEGA_CAP_TRIGGER_TOTAL", 0.10)),
        factor  = float(getattr(config, "DYNAMIC_VEGA_CAP_BOOST_FACTOR", 1.5)),
    )
    if bool(getattr(config, "AUTO_VEGA_TUNE_ENABLE", False)) and "compute_dynamic_vega_caps" in globals():
        max_share_bucket, max_share_total, min_vega_threshold = compute_dynamic_vega_caps(
            plat_bucket, plat_total, acct_bucket, acct_total
        )
    else:
        max_share_bucket   = getattr(config, "MAX_VEGA_SHARE_BUCKET")
        max_share_total    = getattr(config, "MAX_VEGA_SHARE_TOTAL")
        min_vega_threshold = getattr(config, "MIN_VEGA_THRESHOLD")

    # ---------- 8) Apply Vega caps ----------
    after_vega = apply_vega_concentration_to_slate(
        after_cfg,
        vega_buckets       = config.VEGA_BUCKETS,
        platform_bucket    = plat_bucket,
        platform_total     = plat_total,
        account_bucket     = acct_bucket,
        account_total      = acct_total,
        max_share_bucket   = max_share_bucket,
        max_share_total    = max_share_total,
        min_vega_threshold = min_vega_threshold,
        dynamic_cfg        = dyn_cfg,
        allow_scale        = True,
    )
    keep = after_vega.get("eligible_vega", 1) == 1
    dropped_vega = int((~keep).sum())
    if dropped_vega:
        logging.info(f"[Phase-1] Dropped {dropped_vega} by Vega caps (eligible_vega=0).")
    after_vega = after_vega.loc[keep].copy()

    # ---------- 9) Soft fallback if empty ----------
    if after_vega.empty and getattr(config, "SOFT_FALLBACK_ENABLE", True):
        logging.info("[Phase-1] Empty after Vega caps; applying soft fallback.")
        bcap2, mthr2 = _maybe_soft_fallback_caps(max_share_bucket, min_vega_threshold)
        after_vega = apply_vega_concentration_to_slate(
            after_cfg.copy(),
            vega_buckets       = config.VEGA_BUCKETS,
            platform_bucket    = plat_bucket,
            platform_total     = plat_total,
            account_bucket     = acct_bucket,
            account_total      = acct_total,
            max_share_bucket   = bcap2,
            max_share_total    = max_share_total,
            min_vega_threshold = mthr2,
            dynamic_cfg        = dyn_cfg,
            allow_scale        = True,
        )
        after_vega = after_vega.loc[after_vega.get("eligible_vega", 1) == 1].copy()

    return after_vega


from typing import Dict, Any

def llm_prepare_context(
    candidates_df: pd.DataFrame,
    positions_df: pd.DataFrame,
    max_cand_rows: int = 300,  # keep API compatibility (we won't force-cap)
    max_pos_rows: int = 60,    # keep API compatibility (we won't force-cap)
) -> Dict[str, Any]:
    """
    Build CSV payloads + whitelists for the LLM using the provided DataFrames.
    **Do not drop columns**. We harmonize IDs, option_type, DTE, and add helpful price columns.
    """

    import numpy as np
    import pandas as pd

    def _ensure_ids(d: pd.DataFrame) -> pd.DataFrame:
        x = d.copy()
        if "symbol" not in x.columns and "instrument_name" in x.columns:
            x["symbol"] = x["instrument_name"].astype(str)
        if "instrument_name" not in x.columns and "symbol" in x.columns:
            x["instrument_name"] = x["symbol"].astype(str)
        if "symbol" in x.columns:
            x["symbol"] = x["symbol"].astype(str).str.upper().str.strip()
        return x

    def _derive_dte(d: pd.DataFrame) -> pd.Series:
        if "dte" in d.columns:
            return pd.to_numeric(d["dte"], errors="coerce").fillna(0).clip(lower=0).astype(int)
        if "DTE" in d.columns:
            return pd.to_numeric(d["DTE"], errors="coerce").fillna(0).clip(lower=0).astype(int)
        exp = None
        if "expiration" in d.columns:
            exp = pd.to_datetime(d["expiration"], utc=True, errors="coerce")
        elif "expiry" in d.columns:
            exp = pd.to_datetime(d["expiry"], utc=True, errors="coerce")
        elif "expiration_timestamp" in d.columns:
            exp = pd.to_datetime(pd.to_numeric(d["expiration_timestamp"], errors="coerce"), unit="ms", utc=True, errors="coerce")
        if exp is None:
            return pd.Series(0, index=d.index, dtype=int)
        now_utc = pd.Timestamp.now(tz="UTC")
        dte_days = np.floor((exp - now_utc).dt.total_seconds() / 86400.0)
        return pd.to_numeric(dte_days, errors="coerce").fillna(0).clip(lower=0).astype(int)

    def _canon_option_type(series: pd.Series) -> pd.Series:
        s = series.astype("string").str.upper().str.strip()
        return s.replace({"CALL": "C", "PUT": "P"})

    def _to_csv(df: pd.DataFrame) -> str:
        if df is None or df.empty:
            return ""
        d = df.copy()
        # Round numerics to control token bloat (keeps all columns)
        for c in d.columns:
            if pd.api.types.is_numeric_dtype(d[c]):
                d[c] = pd.to_numeric(d[c], errors="coerce").round(6)
        # canonicalize option_type to C/P for compactness if present
        if "option_type" in d.columns:
            d["option_type"] = _canon_option_type(d["option_type"])
        # render timestamps as ISO
        if "expiration" in d.columns and pd.api.types.is_datetime64_any_dtype(d["expiration"]):
            d["expiration"] = pd.to_datetime(d["expiration"], utc=True, errors="coerce").dt.strftime("%Y-%m-%d")
        return d.to_csv(index=False)

    # ---------- Candidates ----------
    cand = candidates_df.copy() if isinstance(candidates_df, pd.DataFrame) else pd.DataFrame()
    cand = _ensure_ids(cand)
    if "dte" not in cand.columns:
        cand["dte"] = _derive_dte(cand)
    # Normalize option_type non-destructively
    if "option_type" in cand.columns:
        opt = cand["option_type"].astype(str).str.strip().str.upper()
        cand["option_type"] = opt.map({"C": "CALL", "CALL": "CALL", "P": "PUT", "PUT": "PUT"}).fillna(opt)
    else:
        symu = cand["symbol"].astype(str).str.upper()
        cand["option_type"] = np.where(symu.str.endswith("-C"), "CALL",
                                np.where(symu.str.endswith("-P"), "PUT", ""))

    # Add explicit BTC/USD mid/mark (idempotent if already present)
    if "mid_price_btc" not in cand.columns:
        cand["mid_price_btc"]  = pd.to_numeric(cand.get("mid_price"),  errors="coerce")
    if "mark_price_btc" not in cand.columns:
        cand["mark_price_btc"] = pd.to_numeric(cand.get("mark_price"), errors="coerce")
    if "mid_price_usd" not in cand.columns or "mark_price_usd" not in cand.columns:
        spot = pd.to_numeric(cand.get("underlying_price"), errors="coerce")
        if "mid_price_usd" not in cand.columns:
            cand["mid_price_usd"]  = pd.to_numeric(cand.get("mid_price_btc"),  errors="coerce") * spot
        if "mark_price_usd" not in cand.columns:
            cand["mark_price_usd"] = pd.to_numeric(cand.get("mark_price_btc"), errors="coerce") * spot

    # No column dropping; optional preview clip for safety (keep rows, keep ALL cols)
    cand_small = cand.head(int(max_cand_rows)).reset_index(drop=True)
    cand_csv   = _to_csv(cand_small)

    # ---------- Positions ----------
    pos = positions_df.copy() if isinstance(positions_df, pd.DataFrame) else pd.DataFrame()
    pos = _ensure_ids(pos)
    if "dte" not in pos.columns:
        pos["dte"] = _derive_dte(pos)

    # derive side if missing
    if not pos.empty and "side" not in pos.columns:
        if "direction" in pos.columns:
            dl = pos["direction"].astype(str).str.lower()
            pos["side"] = np.where(dl.eq("sell"), "SHORT",
                            np.where(dl.eq("buy"),  "LONG",  "SHORT"))
        else:
            # fallback from signed size
            signed_size = pd.to_numeric(pos.get("size"), errors="coerce")
            pos["side"] = np.where(signed_size < 0, "SHORT", np.where(signed_size > 0, "LONG", ""))

    # qty = abs(size) if not present
    if "qty" not in pos.columns and "size" in pos.columns:
        pos["qty"] = (
            pd.to_numeric(pos["size"], errors="coerce")
            .abs().fillna(0).round().astype(int)
        )

    # Keep all columns; just format for CSV
    pos_small = pos.head(int(max_pos_rows)).reset_index(drop=True)
    pos_csv   = _to_csv(pos_small)

    # ---------- Whitelists ----------
    wl_open = set()
    if not cand_small.empty:
        wl_open |= set(cand_small.get("symbol", pd.Series([], dtype=str)).astype(str).str.upper())
        if "instrument_name" in cand_small.columns:
            wl_open |= set(cand_small["instrument_name"].astype(str).str.upper())

    wl_pos = set()
    if not pos_small.empty:
        wl_pos |= set(pos_small.get("symbol", pd.Series([], dtype=str)).astype(str).str.upper())
        if "instrument_name" in pos_small.columns:
            wl_pos |= set(pos_small["instrument_name"].astype(str).str.upper())

    return {
        "cand_small": cand_small,  # all columns preserved
        "pos_small":  pos_small,   # all columns preserved
        "cand_csv":   cand_csv,    # all columns serialized (rounded)
        "pos_csv":    pos_csv,     # all columns serialized (rounded)
        "whitelist_open": wl_open,
        "whitelist_positions": wl_pos,
    }

# --- 3) Shared: parse first JSON block safely
def llm_parse_json(text: str) -> dict:
    """
    Robustly extract a {"open":[], "hold":[], "close":[]} dict from LLM output.
    Tolerates:
      - fenced code blocks (``` or ```json)
      - extra wrapping objects (e.g., {"decisions": {...}})
      - different key casing (Open/HOLD/CLOSE)
      - minor trailing commas before } or ].

    Always returns a dict with keys: "open", "hold", "close" (lists).
    """
    import json, re

    default = {"open": [], "hold": [], "close": []}

    if not isinstance(text, str) or not text.strip():
        return default

    def _normalize_obj(obj) -> dict:
        """Map any dict-like to our schema, searching nested containers and case-insensitively."""
        if not isinstance(obj, dict):
            return default

        # Unwrap common containers once if present
        for k in ("decisions", "result", "data", "response"):
            if k in obj and isinstance(obj[k], dict):
                obj = obj[k]
                break

        def _get_list(key_lower: str):
            for k, v in obj.items():
                if isinstance(k, str) and k.lower() == key_lower:
                    return v if isinstance(v, list) else []
            return []

        return {
            "open":  _get_list("open"),
            "hold":  _get_list("hold"),
            "close": _get_list("close"),
        }

    def _strip_fences(s: str) -> str:
        # Remove ```...``` fences (optionally with language tag)
        s = s.strip()
        if s.startswith("```") and s.endswith("```"):
            s = re.sub(r"^```[a-zA-Z0-9_-]*\s*", "", s, flags=re.DOTALL)
            s = re.sub(r"\s*```$", "", s, flags=re.DOTALL)
        return s.strip()

    def _remove_trailing_commas(s: str) -> str:
        # Cheap fix for trailing commas before } or ]
        return re.sub(r",\s*([}\]])", r"\1", s)

    def _try_json(s: str):
        try:
            return json.loads(s)
        except Exception:
            return None

    # 1) Direct parse (with fence stripping + comma cleanup)
    s0 = _remove_trailing_commas(_strip_fences(text))
    obj = _try_json(s0)
    if isinstance(obj, dict):
        return _normalize_obj(obj)

    # 2) Look for a fenced JSON block inside the text
    m = re.search(r"```(?:json)?\s*({[\s\S]*?})\s*```", text, flags=re.IGNORECASE)
    if m:
        s1 = _remove_trailing_commas(m.group(1))
        obj = _try_json(s1)
        if isinstance(obj, dict):
            return _normalize_obj(obj)

    # 3) First balanced {...} slice (simple brace counting)
    def _balanced_slice(s: str):
        start = s.find("{")
        if start < 0:
            return None
        depth = 0
        for i, ch in enumerate(s[start:], start):
            if ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    return s[start:i+1]
        return None

    cand = _balanced_slice(text)
    if cand:
        s2 = _remove_trailing_commas(cand)
        obj = _try_json(s2)
        if isinstance(obj, dict):
            return _normalize_obj(obj)

    # 4) Last-ditch: extract arrays for open/hold/close independently
    result = {"open": [], "hold": [], "close": []}
    for key in ("open", "hold", "close"):
        m = re.search(rf'"{key}"\s*:\s*(\[[\s\S]*?\])', text, flags=re.IGNORECASE)
        if m:
            arr_txt = _remove_trailing_commas(m.group(1))
            try:
                arr_val = json.loads(arr_txt)
                if isinstance(arr_val, list):
                    result[key] = arr_val
            except Exception:
                pass
    if any(result[k] for k in result):
        return result

    return default

# --- 4) Shared: normalize & enforce whitelists, return tidy df
def llm_normalize_and_to_df(
    decisions: dict,
    whitelist_open: set[str],
    whitelist_positions: set[str],
    cand_small: pd.DataFrame,
    pos_small: pd.DataFrame,
) -> pd.DataFrame:
    """
    Normalize one-stage LLM decisions to a uniform DataFrame.

    Expected LLM item keys (case-insensitive tolerated):
      symbol | instrument_name, side, action {OPEN|HOLD|CLOSE}, score [0..1],
      quantity (int), POP (float), rationale, closing_recommendation

    Rules:
      - OPEN rows must be in whitelist_open; HOLD/CLOSE in whitelist_positions.
      - For HOLD/CLOSE, quantity is capped to the live position size (abs).
        If LLM omits quantity for HOLD/CLOSE, defaults to current size.
      - For OPEN, missing quantity defaults to 1.
      - Side may be empty; we try to backfill from candidate/position tables.
    """
    import os
    import json
    import re
    import logging
    from typing import Any
    import numpy as np
    import pandas as pd

    TOP_K = int(os.getenv("TOP_K", "10"))

    # -------- helpers --------
    def _coerce_item(item: Any, act: str) -> dict:
        # Accept dict or string (attempt JSON, else extract BTC-... token)
        if isinstance(item, dict):
            return item
        if isinstance(item, str):
            s = item.strip()
            try:
                obj = json.loads(s)
                if isinstance(obj, dict):
                    return obj
            except Exception:
                pass
            m = re.search(r"\bBTC-[A-Z0-9\-]+", s, flags=re.I)
            sym = (m.group(0) if m else "").upper()
            return {
                "symbol": sym,
                "side": "",
                "action": act,
                "score": 0.0,
                "quantity": None,
                "POP": None,
                "rationale": s,
                "closing_recommendation": "",
            }
        # Fallback minimal
        return {
            "symbol": "",
            "side": "",
            "action": act,
            "score": 0.0,
            "quantity": None,
            "POP": None,
            "rationale": "",
            "closing_recommendation": "",
        }

    def _rows(lst, act: str) -> list[dict]:
        out = []
        for it in (lst or []):
            it = _coerce_item(it, act)
            sym = (it.get("symbol")
                   or it.get("instrument_name")
                   or it.get("ticker")
                   or "")
            side = (it.get("side") or "").upper().strip()
            score = it.get("score", 0)
            qty = it.get("quantity", it.get("qty", None))
            popv = it.get("POP", it.get("pop", None))
            try:
                score = float(score)
            except Exception:
                score = 0.0
            out.append({
                "symbol": str(sym).strip().upper(),
                "side": side,
                "action": act,
                "score": score,
                "quantity": qty,
                "POP": popv,
                "rationale": str(it.get("rationale", "") or "").strip(),
                "closing_recommendation": str(it.get("closing_recommendation", "") or "").strip(),
            })
        return out

    # -------- build df from decisions --------
    df = pd.DataFrame(
        _rows(decisions.get("open", []), "OPEN")
        + _rows(decisions.get("hold", []), "HOLD")
        + _rows(decisions.get("close", []), "CLOSE")
    )

    final_cols = [
        "symbol", "side", "action", "score", "quantity", "POP",
        "rationale", "closing_recommendation",
    ]
    if df.empty:
        return pd.DataFrame(columns=final_cols)

    # -------- normalize symbol/instrument --------
    df["symbol"] = df["symbol"].astype(str).str.upper().str.strip()

    # -------- whitelists (symbol-based) --------
    wl_open = {str(s).upper() for s in (whitelist_open or set())}
    wl_pos  = {str(s).upper() for s in (whitelist_positions or set())}

    m_open  = (df["action"] == "OPEN")  & (df["symbol"].isin(wl_open))
    m_hold  = (df["action"] == "HOLD")  & (df["symbol"].isin(wl_pos))
    m_close = (df["action"] == "CLOSE") & (df["symbol"].isin(wl_pos))
    df = df[m_open | m_hold | m_close].copy()
    if df.empty:
        return pd.DataFrame(columns=final_cols)

    # -------- enrich from candidates/positions to backfill side and sizes --------
    cand_map = pd.DataFrame()
    if cand_small is not None and not cand_small.empty:
        cand_map = cand_small.copy()
        if "symbol" not in cand_map.columns and "instrument_name" in cand_map.columns:
            cand_map["symbol"] = cand_map["instrument_name"]
        cand_map["symbol"] = cand_map["symbol"].astype(str).str.upper()
        # Keep only light, helpful columns
        extra_cols_cand = [
            "side", "_theta_eff", "_premium_eff", "iv_rank", "ivr_xsec",
            "mid_price", "mark_price", "underlying_price", "dte",
            "qty", "qty_max_sell", "qty_max_buy", "option_type"
        ]
        keep = ["symbol"] + [c for c in extra_cols_cand if c in cand_map.columns]
        cand_map = cand_map[keep].drop_duplicates("symbol")

    pos_map = pd.DataFrame()
    if pos_small is not None and not pos_small.empty:
        pos_map = pos_small.copy()
        if "symbol" not in pos_map.columns and "instrument_name" in pos_map.columns:
            pos_map["symbol"] = pos_map["instrument_name"]
        pos_map["symbol"] = pos_map["symbol"].astype(str).str.upper()
        pos_map["pos_size_abs"] = (
            pd.to_numeric(pos_map.get("size"), errors="coerce")
            .abs()
            .fillna(0)
            .astype(int)
        )
        keep_p = ["symbol", "pos_size_abs"]
        if "side" in pos_map.columns:
            keep_p.append("side")
        pos_map = pos_map[keep_p].drop_duplicates("symbol")

    # Merge to backfill side and size cap
    if not cand_map.empty:
        df = df.merge(cand_map, on="symbol", how="left", suffixes=("", "_cand"))
        # fill side from candidates if missing
        df["side"] = df["side"].replace("", np.nan)
        if "side_cand" in df.columns:
            df["side"] = df["side"].fillna(df["side_cand"])
        df["side"] = df["side"].fillna("").astype(str).str.upper()
        if "side_cand" in df.columns:
            df = df.drop(columns=["side_cand"], errors="ignore")

    if not pos_map.empty:
        df = df.merge(pos_map, on="symbol", how="left", suffixes=("", "_pos"))
        # fill side from positions if still missing
        df["side"] = df["side"].replace("", np.nan)
        if "side_pos" in df.columns:
            df["side"] = df["side"].fillna(df["side_pos"])
        df["side"] = df["side"].fillna("").astype(str).str.upper()
        df = df.drop(columns=["side_pos"], errors="ignore")

    # -------- quantity normalization & capping --------
    def _safe_int(v, default=None):
        try:
            if v is None or (isinstance(v, float) and np.isnan(v)):
                return default
            return int(float(v))
        except Exception:
            return default

    for idx, row in df.iterrows():
        act = row["action"]
        q = _safe_int(row.get("quantity"), None)
        if act == "OPEN":
            q = _safe_int(q, 1)
            df.at[idx, "quantity"] = max(0, q)
        else:
            cap = _safe_int(row.get("pos_size_abs"), 0)
            if q is None:
                q = cap
            if cap is not None:
                q = min(max(0, q), max(0, cap))
            df.at[idx, "quantity"] = max(0, int(q if q is not None else 0))

    # -------- score/POP coercion --------
    df["score"] = pd.to_numeric(df["score"], errors="coerce").fillna(0.0).clip(0.0, 1.0)
    if "POP" in df.columns:
        df["POP"] = pd.to_numeric(df["POP"], errors="coerce")

    # -------- cap TOP_K per bucket by score --------
    parts = []
    for act in ("OPEN", "HOLD", "CLOSE"):
        part = df[df["action"] == act].sort_values("score", ascending=False).head(TOP_K)
        parts.append(part)
    df = pd.concat(parts, ignore_index=True) if any(len(p) for p in parts) else df.head(0)

    # -------- finalize columns/order --------
    for c in final_cols:
        if c not in df.columns:
            df[c] = np.nan
    df = df[final_cols].reset_index(drop=True)

    logging.info(
        "llm_normalize_and_to_df: normalized %d rows (TOP_K=%d per bucket).",
        len(df), TOP_K
    )
    return df

# _safe_col already exists above; we reuse it. :contentReference[oaicite:2]{index=2}
def _safe_col(df: pd.DataFrame, name: str, default=0.0, dtype=float) -> pd.Series:
    """
    Always returns a pandas Series aligned to df.index.
    If column is missing, returns a Series filled with `default`.
    If present, coerces to numeric and fills NaNs with `default`.
    """
    if name in df.columns:
        s = pd.to_numeric(df[name], errors="coerce")
        return s.fillna(default).astype(dtype)
    return pd.Series(default, index=df.index, dtype=dtype)

def apply_portfolio_constraints(
    candidates: pd.DataFrame | list[dict],
    *,
    account_state: dict,
    risk_rules: Optional[dict] = None,
    max_size_per_leg: int = 20,
) -> pd.DataFrame:
    """
    Phase-2 (portfolio-aware) filter + sizer.

    Accepts either:
      - a pandas DataFrame, or
      - a list[dict] (e.g. from open_with_margin_list)
    Always returns a DataFrame.
    """

    from . import config
  # use config.RISK_RULES if risk_rules not provided

    # --- normalize input to a DataFrame ---
    if candidates is None:
        return pd.DataFrame()

    if isinstance(candidates, list):
        if not candidates:
            return pd.DataFrame()
        df = pd.DataFrame(candidates)
    elif isinstance(candidates, pd.DataFrame):
        if candidates.empty:
            return pd.DataFrame()
        df = candidates.copy()
    else:
        # unsupported type, just return empty DF
        return pd.DataFrame()


    # ---- account state ----
    equity_btc        = float(account_state.get("equity_btc", 0.0))
    free_margin_ratio = float(account_state.get("free_margin_ratio", 0.0))
    current_vega      = float(account_state.get("current_vega", 0.0))
    current_theta_usd = float(account_state.get("current_theta_usd", 0.0))

    if equity_btc <= 0 or free_margin_ratio <= 0:
        # can't size anything safely if we don't know equity/margin
        return pd.DataFrame(columns=list(df.columns) + [
            "size_recommended", "new_margin_usage", "new_vega", "new_total_theta_usd"
        ])

    # ---- risk rules ----
    base_rules = getattr(config, "RISK_RULES", {})
    rr = dict(base_rules)
    if risk_rules:
        rr.update(risk_rules)

    max_margin_usage   = float(rr.get("max_margin_usage",   0.86))
    max_vega_allowed   = float(rr.get("max_vega_allowed",  -8500.0))
    min_pop            = float(rr.get("min_pop",            0.0))     # 0.0 = POP check off
    min_theta_per_marg = float(rr.get("min_theta_per_marg", 0.0))     # 0.0 = theta/marg check off

    # ---- numeric columns (robust to naming) ----
    # spot
    under = _safe_col(df, "underlying_price", default=0.0)
    if (under == 0).all():
        under = _safe_col(df, "UNDERLYING_PRICE", default=0.0)

    # greeks
    theta = _safe_col(df, "theta", default=0.0)
    if (theta == 0).all():
        theta = _safe_col(df, "THETA", default=0.0)

    vega = _safe_col(df, "vega", default=0.0)
    if (vega == 0).all():
        vega = _safe_col(df, "VEGA", default=0.0)

    # pricing
    mid = _safe_col(df, "mid_price", default=0.0)
    if (mid == 0).all():
        mid = _safe_col(df, "MID_PRICE", default=0.0)

    # POP (optional)
    pop_short = _safe_col(df, "pop_short", default=np.nan)
    if pop_short.isna().all() and "POP" in df.columns:
        pop = _safe_col(df, "POP", default=np.nan)
    else:
        pop = pop_short

    # margin proxy: prefer real 'mm_required', else cheap heuristic
    mm_req = _safe_col(df, "mm_required", default=np.nan)
    mm_est = mm_req.copy()
    mask_bad = (~np.isfinite(mm_est)) | (mm_est <= 0)
    if mask_bad.any():
        # fallback: ~10% notional as IM proxy
        fallback = mid * under * 0.10
        mm_est = mm_est.where(~mask_bad, fallback)

    # convert margin proxy USD -> BTC (assuming under is BTCUSD)
    with np.errstate(divide="ignore", invalid="ignore"):
        mm_est_btc = mm_est / under.replace(0, np.nan)
    mm_est_btc = mm_est_btc.replace([np.inf, -np.inf], np.nan)

    # theta in USD/day for a SHORT (negative theta is good)
    theta_usd_day = (-theta) * under
    theta_usd_day = theta_usd_day.clip(lower=0.0)

    # theta per 1 BTC of margin
    with np.errstate(divide="ignore", invalid="ignore"):
        theta_per_marg = theta_usd_day / mm_est_btc
    theta_per_marg = theta_per_marg.replace([np.inf, -np.inf], np.nan).fillna(0.0)

    df["_theta_usd_day"]    = theta_usd_day
    df["_mm_est_btc"]       = mm_est_btc
    df["_theta_per_margin"] = theta_per_marg
    df["_pop"]              = pop

    free_margin_btc = free_margin_ratio * equity_btc

    def _can_add(idx, size: int):
        """Single-leg version of your client's can_add_trade."""
        row_mm_btc = df.loc[idx, "_mm_est_btc"]
        if not np.isfinite(row_mm_btc) or row_mm_btc <= 0:
            return False, None, None, None

        margin_est_btc = row_mm_btc * size
        vega_add       = float(vega.loc[idx])         * size
        theta_add      = float(theta_usd_day.loc[idx]) * size
        pop_here       = float(df.loc[idx, "_pop"]) if "_pop" in df.columns else np.nan
        tpm_here       = float(theta_per_marg.loc[idx])

        new_margin_usage = 1.0 - (free_margin_btc - margin_est_btc) / equity_btc
        new_vega         = current_vega + vega_add
        new_theta        = current_theta_usd + theta_add

        # hard constraints
        if new_margin_usage > max_margin_usage:
            return False, new_margin_usage, new_vega, new_theta
        if new_vega < max_vega_allowed:
            return False, new_margin_usage, new_vega, new_theta
        if (min_pop > 0.0) and np.isfinite(pop_here) and (pop_here < min_pop):
            return False, new_margin_usage, new_vega, new_theta
        if (min_theta_per_marg > 0.0) and (tpm_here < min_theta_per_marg):
            return False, new_margin_usage, new_vega, new_theta

        return True, new_margin_usage, new_vega, new_theta

    # ---- iterate candidates, find max safe size ----
    out_rows = []
    for idx in df.index:
        row_mm = df.loc[idx, "_mm_est_btc"]
        if not np.isfinite(row_mm) or row_mm <= 0 or free_margin_btc <= 0:
            continue

        max_size_budget = int(free_margin_btc / row_mm)
        if max_size_budget <= 0:
            continue

        max_size_budget = min(max_size_budget, max_size_per_leg)

        best_size       = 0
        best_marg_usage = None
        best_vega       = None
        best_theta      = None

        for size in range(max_size_budget, 0, -1):
            ok, m_usage, v_new, t_new = _can_add(idx, size)
            if ok:
                best_size       = size
                best_marg_usage = m_usage
                best_vega       = v_new
                best_theta      = t_new
                break

        if best_size > 0:
            r = df.loc[idx].copy()
            r["size_recommended"]    = int(best_size)
            r["new_margin_usage"]    = float(best_marg_usage)
            r["new_vega"]            = float(best_vega)
            r["new_total_theta_usd"] = float(best_theta)
            out_rows.append(r)

    if not out_rows:
        logging.info("apply_portfolio_constraints: no rows passed sizing constraints.")
        return pd.DataFrame(columns=list(df.columns) + [
            "size_recommended", "new_margin_usage", "new_vega", "new_total_theta_usd"
        ])
    logging.info(f"apply_portfolio_constraints: selected {len(out_rows)} rows after sizing.")
    return pd.DataFrame(out_rows).reset_index(drop=True)