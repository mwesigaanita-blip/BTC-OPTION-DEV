from __future__ import annotations

import logging
from typing import Optional, Union

import numpy as np
import pandas as pd
from .config import *  # if you still use CAPITAL, MM_CAP_RATIO, etc.

from .stage_1 import (
    phase1_screen_and_rank,
)


VEGA_EXPOSE_COLS = [
    "vega_bucket_code", "vega_bucket_label",
    "share_bucket_now", "share_bucket_proj",
    "share_total_now", "share_total_proj",
    "eligible_vega", "qty"
]
def _ensure_pop(df: pd.DataFrame) -> pd.DataFrame:
    """
    Ensure a POP column exists:
        POP = 1 - |delta|
    clipped to [0, 1].
    If no delta column is present, POP is left as-is or set to NaN.
    """
    if df is None or df.empty:
        return df

    out = df.copy()

    # If POP already exists (e.g. computed upstream), don't overwrite it.
    if "POP" in out.columns:
        return out

    delta_col = None
    for name in ("delta", "DELTA"):
        if name in out.columns:
            delta_col = name
            break

    if delta_col is None:
        out["POP"] = np.nan
        return out

    d = pd.to_numeric(out[delta_col], errors="coerce")
    pop = 1.0 - d.abs()
    pop = pop.clip(lower=0.0, upper=1.0)
    out["POP"] = pop

    return out

def _exclude_positions_from_candidates(
    live_options_df: pd.DataFrame,
    current_positions_df: Optional[pd.DataFrame]
) -> pd.DataFrame:
    """
    Remove any live option whose instrument_name exists in current positions.

    Parameters
    ----------
    live_options_df : pd.DataFrame
        Universe after initial fetch (unfiltered or pre-filtered).
        Must contain column 'instrument_name'.
    current_positions_df : pd.DataFrame | None
        Current positions snapshot. If None or empty, returns input unchanged.
        Should contain column 'instrument_name' or 'symbol'.

    Returns
    -------
    pd.DataFrame
        live_options_df with overlapping instruments removed (deduplicated, index reset).
    """
    if live_options_df is None or live_options_df.empty:
        return pd.DataFrame(columns=live_options_df.columns if live_options_df is not None else [])

    df = live_options_df.copy()
    if "instrument_name" not in df.columns:
        raise ValueError("live_options_df must contain 'instrument_name'.")

    if current_positions_df is None or current_positions_df.empty:
        return df.reset_index(drop=True).drop_duplicates(subset=["instrument_name"])

    pos = current_positions_df.copy()
    # Normalize possible column naming
    if "instrument_name" not in pos.columns and "symbol" in pos.columns:
        pos["instrument_name"] = pos["symbol"].astype(str)

    if "instrument_name" not in pos.columns:
        # If still missing, nothing to exclude safely
        return df.reset_index(drop=True).drop_duplicates(subset=["instrument_name"])

    held = set(pos["instrument_name"].astype(str).dropna().unique().tolist())
    out = df[~df["instrument_name"].astype(str).isin(held)]
    return out.reset_index(drop=True).drop_duplicates(subset=["instrument_name"])

def _apply_phase1_filters(
    live_options_df: pd.DataFrame,
    *,
    capital_usd: Optional[float] = None,
    mm_cap_ratio: Optional[float] = None,
    max_rows_to_llm: Optional[int] = None,
    cfg: Optional[dict] = None,
    account_snapshot: Optional[dict] = None
) -> pd.DataFrame:
    """
    Thin wrapper over stage_1.phase1_screen_and_rank:
    applies deterministic filters/ranking and returns a ranked candidate slate.

    Parameters
    ----------
    live_options_df : pd.DataFrame
        Raw or lightly-cleaned live options snapshot.
    capital_usd : float | None
        Capital for sizing constraints; if None, pulls from config.CAPITAL (if defined there).
    mm_cap_ratio : float | None
        Market-making capital share; if None, pulls from config.MM_CAP_RATIO.
    max_rows_to_llm : int | None
        Upper cap for the slate size; if None, pulls from config (e.g., LLM row caps).
    cfg : dict | None
        Extra config dict to pass-through to phase1_screen_and_rank; if None, uses globals from config.py.

    Returns
    -------
    pd.DataFrame
        Ranked candidate DataFrame with required feature columns for downstream steps.
    """
    # Fallbacks to config if not provided
    try:
        cap = float(capital_usd) if capital_usd is not None else float(globals().get("CAPITAL"))
    except Exception:
        cap = None

    try:
        mmr = float(mm_cap_ratio) if mm_cap_ratio is not None else float(globals().get("MM_CAP_RATIO", 0.5))
    except Exception:
        mmr = 0.5

    try:
        max_rows = int(max_rows_to_llm) if max_rows_to_llm is not None else int(globals().get("LLAMA_MAX_CAND_ROWS", 50))
    except Exception:
        max_rows = 50

    cfg_pass = cfg if cfg is not None else globals()

    # Delegate to your Stage 1 pipeline
    cand = phase1_screen_and_rank(
        df=live_options_df,
        positions_df=None,              # or your live positions df if you use Vega buckets
        return_after_vega=True,
        max_rows_to_llm=max_rows,
        cfg=cfg_pass,
    )

    # Ensure a stable, deduped output
    if "instrument_name" in cand.columns:
        cand = cand.drop_duplicates(subset=["instrument_name"])
    return cand.reset_index(drop=True)

def _ensure_basic_derivatives(df: pd.DataFrame) -> pd.DataFrame:
    """
    Ensure key derived columns exist for downstream (DTE, mid, spread_pct, iv_spread_abs, moneyness).
    """
    if df is None or df.empty:
        return df

    out = df.copy()

    # --- DTE (days) ---
    if "expiration" in out.columns:
        exp = pd.to_datetime(out["expiration"], utc=True, errors="coerce")  # tz-aware UTC
        # Use tz-aware 'now' (don't tz_localize an aware ts)
        now = pd.Timestamp.now(tz="UTC")
        out["DTE"] = np.floor((exp - now).dt.total_seconds() / 86400.0)
        # keep as Int64 nullable if you like, otherwise float is fine
        out["DTE"] = out["DTE"].astype("Int64")

    # --- Mid price ---
    if "mid_price" not in out.columns or out["mid_price"].isna().all():
        if "bid_price" in out.columns and "ask_price" in out.columns:
            out["mid_price"] = (pd.to_numeric(out["bid_price"], errors="coerce") +
                                pd.to_numeric(out["ask_price"], errors="coerce")) / 2

    # --- Spread % ---
    if "bid_price" in out.columns and "ask_price" in out.columns:
        bid = pd.to_numeric(out["bid_price"], errors="coerce")
        ask = pd.to_numeric(out["ask_price"], errors="coerce")
        mid = pd.to_numeric(out.get("mid_price", (bid + ask) / 2), errors="coerce")
        with np.errstate(divide='ignore', invalid='ignore'):
            out["spread_pct"] = (ask - bid) / mid.replace(0, np.nan)

    # --- IV spread abs ---
    if "ask_iv" in out.columns and "bid_iv" in out.columns:
        out["iv_spread_abs"] = (pd.to_numeric(out["ask_iv"], errors="coerce") -
                                pd.to_numeric(out["bid_iv"], errors="coerce")).abs()

    # --- Moneyness ---
    if "underlying_price" in out.columns and "strike" in out.columns:
        u = pd.to_numeric(out["underlying_price"], errors="coerce")
        k = pd.to_numeric(out["strike"], errors="coerce")
        with np.errstate(divide='ignore', invalid='ignore'):
            out["moneyness"] = (u / k) - 1.0

    return out

def run_valuation_filter_with_pop(
    df_live: pd.DataFrame | None = None,
    current_positions_df: pd.DataFrame | None = None,
    cfg: Optional[dict] = None,
    account_snapshot: Optional[dict] = None,
    **kwargs,
) -> pd.DataFrame:
    """
    Minimal Valuation agent:

      1) Filter live options using the Phase-1 pipeline with CFG.
      2) Remove symbols already held in current positions.
      3) Ensure a POP column exists with POP = 1 - |delta|.
      4) Add basic derived columns (DTE, mid_price, spread_pct, moneyness).

    Returns a DataFrame of candidate options for the OPEN agent.
    """

    # Backwards compatibility: some callers might pass live_options_df=...
    if df_live is None and "live_options_df" in kwargs:
        df_live = kwargs["live_options_df"]

    if df_live is None or df_live.empty:
        logging.info("[Valuation Agent] Empty live universe.")
        return pd.DataFrame(columns=df_live.columns if df_live is not None else [])

    # 1) Phase-1 filters (using your CFG dict)
    phase1 = _apply_phase1_filters(
        live_options_df=df_live,
        capital_usd=kwargs.get("capital_usd"),
        mm_cap_ratio=kwargs.get("mm_cap_ratio"),
        max_rows_to_llm=kwargs.get("max_rows_to_llm"),
        cfg=cfg,
        account_snapshot=account_snapshot,
    )
    logging.info("[Valuation Agent] After Phase-1 filters: %d rows", len(phase1))

    # 2) Exclude already-held positions
    excl = _exclude_positions_from_candidates(phase1, current_positions_df)
    logging.info("[Valuation Agent] After excluding current positions: %d rows", len(excl))

    # 3) Ensure POP exists: POP = 1 - |delta|
    excl = _ensure_pop(excl)

    # 4) Basic derivatives (DTE, mid, spread, moneyness, etc.)
    pruned_df = _ensure_basic_derivatives(excl)
    logging.info("[Valuation Agent] Final valuation slate: %d rows", len(pruned_df))

    return pruned_df

def results_reducer(root: Union[str, Path]) -> Path:
    """Small helper so results_root can be either str or Path."""
    return root if isinstance(root, Path) else Path(root)
