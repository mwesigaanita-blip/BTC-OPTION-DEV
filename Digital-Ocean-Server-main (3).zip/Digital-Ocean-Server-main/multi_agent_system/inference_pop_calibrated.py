# --- in inference_pop_calibrated.py ---

from pathlib import Path
import numpy as np
import pandas as pd
import joblib

HERE = Path(__file__).resolve().parent
MODELS_DIR = HERE / "models" / "pop_models"
CAL_DIR    = HERE / "models" / "pop_calibration"

POP_LONG_FILE  = "POP_Estimator_long.joblib"
POP_SHORT_FILE = "POP_Estimator_short.joblib"
CAL_LONG_FILE  = "POP_Calibrator_long.pkl"
CAL_SHORT_FILE = "POP_Calibrator_short.pkl"

def _load_artifact(p: Path):
    if not p.exists():
        raise FileNotFoundError(f"Missing artifact: {p}")
    return joblib.load(p)

pop_long  = _load_artifact(MODELS_DIR / POP_LONG_FILE)
pop_short = _load_artifact(MODELS_DIR / POP_SHORT_FILE)
cal_long  = _load_artifact(CAL_DIR / CAL_LONG_FILE)
cal_short = _load_artifact(CAL_DIR / CAL_SHORT_FILE)

# required POP feature vector (lowercase)
import numpy as np
import pandas as pd

CAL_ENSEMBLE_FILE = "POP_Calibrator_ensemble.pkl"  # if present, use for ensemble POP


REQUIRED_FEATS = [
    "strike", "underlying_price", "dte", "delta",
    "theta", "right_enc", "mark_iv_dec", "strike_distance_pct",
]

def _as_series(x, index, dtype="float32"):
    """Ensure we always assign a Series aligned to df.index."""
    if isinstance(x, (pd.Series, pd.Index)):
        s = pd.Series(x.values, index=index)
    elif isinstance(x, (list, tuple, np.ndarray)):
        s = pd.Series(x, index=index)
    else:
        # scalar fallback -> broadcast to length of index
        s = pd.Series([x] * len(index), index=index)
    return pd.to_numeric(s, errors="coerce").fillna(0).astype(dtype)

# def _ensure_pop_features(df: pd.DataFrame) -> pd.DataFrame:
#     g = df.copy()
#     # empty → return empty columns so join won’t crash later
#     if g.empty:
#         for c in REQUIRED_FEATS:
#             g[c] = np.zeros(0, dtype=np.float32)
#         return g

#     # 1) normalize names
#     g.columns = [str(c).lower() for c in g.columns]

#     # 2) strike / underlying_price
#     if "strike" not in g.columns:
#         for c in ("k","opt_strike","strike_price"):
#             if c in g.columns:
#                 g["strike"] = g[c]; break
#     if "underlying_price" not in g.columns:
#         for c in ("underlying","spot","s","index_price","mark_price","px_mid","last_price"):
#             if c in g.columns:
#                 g["underlying_price"] = g[c]; break

#     # 3) dte
#     if "dte" not in g.columns:
#         if "expiration" in g.columns and "snap_date" in g.columns:
#             exp  = pd.to_datetime(g["expiration"], errors="coerce", utc=True)
#             snap = pd.to_datetime(g["snap_date"],  errors="coerce", utc=True)
#             g["dte"] = (exp - snap).dt.days
#         else:
#             g["dte"] = 0

#     # 4) delta / theta
#     if "delta" not in g.columns:
#         for c in ("greeks_delta","delta_mid","opt_delta","delta_bid","delta_ask"):
#             if c in g.columns: g["delta"] = g[c]; break
#         if "delta" not in g.columns: g["delta"] = 0
#     if "theta" not in g.columns:
#         for c in ("greeks_theta","theta_mid","opt_theta","theta_bid","theta_ask"):
#             if c in g.columns: g["theta"] = g[c]; break
#         if "theta" not in g.columns: g["theta"] = 0

#     # 5) right_enc (C=1, P=0)
#     if "right_enc" not in g.columns or g["right_enc"].dtype == object:
#         src = None
#         for c in ("right_enc","option_type","right","cp","opt_type","type"):
#             if c in g.columns: src = c; break
#         if src is not None:
#             se = g[src].astype(str).str.upper().str.strip()
#             # try numeric cast first
#             ne = pd.to_numeric(se, errors="coerce")
#             if ne.notna().any():
#                 g["right_enc"] = ne.fillna(0)
#             else:
#                 g["right_enc"] = se.map({"C":1,"CALL":1,"P":0,"PUT":0}).fillna(0)
#         else:
#             g["right_enc"] = 0

#     # 6) mark_iv_dec (ensure decimal 0..2.5, not percent)
#     if "mark_iv_dec" not in g.columns:
#         src = None
#         for c in ("mark_iv","iv","imp_vol","implied_vol","sigma","iv_mid"):
#             if c in g.columns: src = c; break
#         if src is not None:
#             v = pd.to_numeric(g[src], errors="coerce")
#         else:
#             v = pd.Series(0.5, index=g.index)  # neutral default
#         v = v.where(v <= 2.5, v / 100.0).clip(lower=0.0)
#         g["mark_iv_dec"] = v

#     # 7) strike_distance_pct = (strike - underlying_price)/underlying_price
#     if "strike_distance_pct" not in g.columns:
#         st = pd.to_numeric(g.get("strike", 0), errors="coerce")
#         up = pd.to_numeric(g.get("underlying_price", 0), errors="coerce")
#         denom = up.where(up != 0, np.nan)
#         g["strike_distance_pct"] = ((st - up) / denom).fillna(0)

#     # 8) enforce dtype & fill for all required feats (always as Series)
#     for c in REQUIRED_FEATS:
#         if c in g.columns:
#             g[c] = _as_series(g[c], index=g.index, dtype="float32")
#         else:
#             g[c] = _as_series(0.0, index=g.index, dtype="float32")

#     return g

def _safe_feat(g: pd.DataFrame, name: str, default=np.nan, *, numeric=True, dtype=float) -> pd.Series:
    """Always return a Series aligned to g.index; never a scalar."""
    if name in g.columns:
        s = g[name]
        if numeric:
            s = pd.to_numeric(s, errors="coerce")
        try:
            return s.astype(dtype)
        except Exception:
            return pd.to_numeric(s, errors="coerce")
    return pd.Series(default, index=g.index, dtype=(dtype or float))

def _ensure_pop_features(g: pd.DataFrame) -> pd.DataFrame:
    """
    Build all POP model features safely (no .get(...).fillna on scalars).
    Ensures Series types, guards divide-by-zero, and fills NaNs.
    """
    g = g.copy()

    # Core numeric inputs (Series, never scalars)
    up   = _safe_feat(g, "underlying_price", default=np.nan)
    st   = _safe_feat(g, "strike",            default=np.nan)
    bid  = _safe_feat(g, "bid_price",         default=np.nan)
    ask  = _safe_feat(g, "ask_price",         default=np.nan)
    mid0 = _safe_feat(g, "mid_price",         default=np.nan)
    mark = _safe_feat(g, "mark_price",        default=np.nan)

    # Rebuild mid_price robustly: existing → (bid+ask)/2 → mark
    mid_ba = (bid + ask) / 2.0
    mid = mid0.copy()
    mid = np.where(np.isfinite(mid), mid, np.where(np.isfinite(mid_ba), mid_ba, mark))
    g["mid_price"] = pd.to_numeric(mid, errors="coerce")

    # spread_pct = (ask - bid) / mid * 100
    denom = g["mid_price"].where(g["mid_price"] != 0, np.nan)
    g["spread_pct"] = pd.to_numeric(((ask - bid) / denom) * 100.0, errors="coerce").replace([np.inf, -np.inf], np.nan).fillna(0.0)

    # strike_distance_pct = (strike - underlying) / underlying
    den2 = up.where(up != 0, np.nan)
    g["strike_distance_pct"] = pd.to_numeric(((st - up) / den2), errors="coerce").replace([np.inf, -np.inf], np.nan).fillna(0.0)

    # Common features (as Series)
    g["delta"]      = _safe_feat(g, "delta", default=np.nan)
    g["delta_abs"]  = g["delta"].abs().fillna(0.0)
    g["theta"]      = _safe_feat(g, "theta", default=0.0)
    g["gamma"]      = _safe_feat(g, "gamma", default=0.0)
    g["vega"]       = _safe_feat(g, "vega",  default=0.0)
    g["open_interest"] = _safe_feat(g, "open_interest", default=0.0)
    g["volume"]        = _safe_feat(g, "volume",        default=0.0)

    # IV features (present or zeros)
    g["iv_rank"]  = _safe_feat(g, "iv_rank",  default=0.0)
    g["ivr_xsec"] = _safe_feat(g, "ivr_xsec", default=0.0)

    # DTE as float (keep NaNs → 0)
    if "DTE" not in g.columns and "dte" in g.columns:
        g["DTE"] = _safe_feat(g, "dte", default=0.0)
    else:
        g["DTE"] = _safe_feat(g, "DTE", default=0.0)

    # Final cleanups: ensure no infs, fill NaNs where appropriate
    for col in ["mid_price","spread_pct","strike_distance_pct","delta","delta_abs","theta","gamma","vega",
                "open_interest","volume","iv_rank","ivr_xsec","DTE"]:
        g[col] = pd.to_numeric(g[col], errors="coerce").replace([np.inf, -np.inf], np.nan).fillna(0.0)

    return g

def _apply_calibrator(cal, p: np.ndarray) -> np.ndarray:
    p = np.clip(p, 1e-8, 1 - 1e-8)
    if hasattr(cal, "transform"):
        return cal.transform(p)
    # LogisticRegression or calibrator with predict_proba
    if hasattr(cal, "predict_proba"):
        return cal.predict_proba(p.reshape(-1,1))[:,1]
    # identity fallback
    return p

def predict_ci_from_probs(p_raw: np.ndarray, *, mode: str = "ensemble") -> pd.DataFrame:
    """
    Calibrate a 1D array of raw POP probs (e.g., ensemble output) and return CI columns.
    Tries an ensemble calibrator first, else identity (safe fallback).
    """
    p_raw = np.asarray(p_raw).reshape(-1)
    # Choose calibrator
    cal = None
    try:
        cal_path = CAL_DIR / CAL_ENSEMBLE_FILE
        if cal_path.exists():
            cal = _load_artifact(cal_path)
    except Exception:
        cal = None

    p = _apply_calibrator(cal, p_raw) if cal is not None else np.clip(p_raw, 1e-8, 1-1e-8)

    # Bootstrap CI (same style as legacy)
    n = len(p)
    if n:
        rng = np.random.default_rng(42)
        B = 100
        eps = rng.normal(0, 0.007, size=(n, B))
        boots = np.clip(p[:, None] + eps, 0, 1)
        alpha = 0.10
        lo = np.quantile(boots, q=alpha/2,     axis=1)
        hi = np.quantile(boots, q=1 - alpha/2, axis=1)
    else:
        lo = np.array([], dtype=np.float32)
        hi = np.array([], dtype=np.float32)

    out = pd.DataFrame({
        "pop_mean": p.astype("float32"),
        "pop_low":  lo.astype("float32"),
        "pop_high": hi.astype("float32"),
    })
    out["pop_width"] = (out["pop_high"] - out["pop_low"]).clip(lower=0).astype("float32")
    return out


def predict_calibrated(df: pd.DataFrame) -> pd.DataFrame:
    feat = _ensure_pop_features(df).copy()

    # Drop any duplicate columns by name (keep first)
    feat.columns = feat.columns.map(str).str.lower()
    feat = feat.loc[:, ~feat.columns.duplicated(keep="first")]

    # Build a clean 8-column frame by *reindexing* columns (missing → NaN Series)
    Xdf = feat.reindex(columns=REQUIRED_FEATS, fill_value=np.nan)  # typo fix below!
    # ⬆️ NOTE: see correct line just below; keep this placeholder if you’re patching manually.

    # ✅ Correct line (typo fix): use REQUIRED_FEATS
    Xdf = feat.reindex(columns=REQUIRED_FEATS)

    # Vectorized numeric coercion; no per-column loop → no scalar issues
    Xdf = Xdf.apply(pd.to_numeric, errors="coerce").fillna(0.0).astype("float32")

    # Final guard: ensure exactly 8 columns in correct order
    Xdf = Xdf.reindex(columns=REQUIRED_FEATS).astype("float32")

    X = Xdf.to_numpy(dtype="float32")

    # now safe to call the pipelines
    p_long_raw  = pop_long.predict_proba(X)[:, 1]
    p_short_raw = pop_short.predict_proba(X)[:, 1]

    p_long  = _apply_calibrator(cal_long,  p_long_raw)
    p_short = _apply_calibrator(cal_short, p_short_raw)
    p_mean  = 0.5 * (p_long + p_short)

    # simple bootstrap band (or call your sidecar-based routine)
    n = len(p_mean)
    if n:
        rng = np.random.default_rng(42)
        B = 100
        epsL = rng.normal(0, 0.005, size=(n, B))
        epsS = rng.normal(0, 0.005, size=(n, B))
        boots = 0.5 * (np.clip(p_long[:, None] + epsL, 0, 1) +
                       np.clip(p_short[:, None] + epsS, 0, 1))
        alpha = 0.10
        lo = np.quantile(boots, q=alpha/2,     axis=1)
        hi = np.quantile(boots, q=1 - alpha/2, axis=1)
    else:
        lo = np.array([], dtype=np.float32)
        hi = np.array([], dtype=np.float32)

    out = pd.DataFrame(
        {"pop_mean": p_mean.astype("float32"),
         "pop_low":  lo.astype("float32"),
         "pop_high": hi.astype("float32")},
        index=df.index,
    )
    out["pop_width"] = (out["pop_high"] - out["pop_low"]).clip(lower=0).astype("float32")
    return out