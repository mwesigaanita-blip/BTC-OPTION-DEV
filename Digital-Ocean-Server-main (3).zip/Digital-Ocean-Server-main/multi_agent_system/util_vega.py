# util_vega.py
from __future__ import annotations
import numpy as np
import pandas as pd
from typing import Dict, Tuple, List


def compute_dynamic_vega_caps(platform_bucket: dict, platform_total: float,
                              account_bucket: dict, account_total: float) -> tuple[dict, float, dict]:
    """
    Returns (max_share_bucket, max_share_total, min_vega_threshold) tuned from live vega.
    - Per-bucket caps start from TARGET_BUCKET_VEGA_SHARE, nudged if account is tiny/large.
    - Total cap starts from TARGET_TOTAL_VEGA_SHARE.
    - Thresholds exempt you from caps when the platform bucket is tiny.
    """
    import math, config

    # --- Totals safe-guards ---
    plat_tot = float(platform_total) if math.isfinite(platform_total) and platform_total > 0 else 1.0
    acct_tot = float(account_total) if math.isfinite(account_total) else 0.0

    # --- Start from targets ---
    total_cap = float(getattr(config, "TARGET_TOTAL_VEGA_SHARE", 0.10))
    bucket_cap_base = float(getattr(config, "TARGET_BUCKET_VEGA_SHARE", 0.12))

    # Size-aware nudge: smaller accounts get slightly lower caps; larger can get closer to base
    acct_share = abs(acct_tot) / plat_tot
    if acct_share < 0.03:      # very small
        bucket_cap = bucket_cap_base * 0.8
        total_cap  = total_cap * 0.8
    elif acct_share > 0.12:    # already large
        bucket_cap = bucket_cap_base * 0.9
        total_cap  = total_cap * 0.9
    else:
        bucket_cap = bucket_cap_base

    # Clamp caps into global limits
    CAP_BUCKET_MIN = float(getattr(config, "CAP_BUCKET_MIN", 0.05))
    CAP_BUCKET_MAX = float(getattr(config, "CAP_BUCKET_MAX", 0.40))
    CAP_TOTAL_MIN  = float(getattr(config, "CAP_TOTAL_MIN",  0.05))
    CAP_TOTAL_MAX  = float(getattr(config, "CAP_TOTAL_MAX",  0.30))

    bucket_cap = max(CAP_BUCKET_MIN, min(CAP_BUCKET_MAX, bucket_cap))
    total_cap  = max(CAP_TOTAL_MIN,  min(CAP_TOTAL_MAX,  total_cap))

    # --- Thresholds (cap exempt if below threshold) ---
    THR_PCT   = float(getattr(config, "THR_PCT_OF_PLATFORM", 0.015))  # 1.5% of platform bucket
    THR_FLOOR = float(getattr(config, "MIN_THR_FLOOR", 20_000.0))
    THR_CEIL  = float(getattr(config, "MIN_THR_CEIL",  300_000.0))
    THR_PAD   = float(getattr(config, "THR_SAFETY_MULT", 1.15))

    min_thr = {}
    for b, plat_b in platform_bucket.items():
        base = max(THR_FLOOR, min(THR_CEIL, abs(plat_b) * THR_PCT))
        min_thr[b] = float(base * THR_PAD)

    # Keep legacy TOTAL threshold semantics if you use them downstream
    min_thr["TOTAL"] = sum(min_thr.values()) * 0.5

    # Build bucket caps dict with same keys as platform map (B1..)
    max_share_bucket = {b: bucket_cap for b in platform_bucket.keys()}

    return max_share_bucket, float(total_cap), min_thr



def _bucket_from_dte(dte: float, vega_buckets: List[Tuple[int,int,str,str]]) -> Tuple[str, str]:
    d = float(dte if dte is not None else 0.0)
    for lo, hi, code, label in vega_buckets:
        if lo <= d <= hi:
            return code, label
    # fallback to last bucket
    lo, hi, code, label = vega_buckets[-1]
    return code, label

def tag_buckets(df: pd.DataFrame, vega_buckets) -> pd.DataFrame:
    if "DTE" not in df.columns:
        raise ValueError("Expected 'DTE' column for bucket tagging.")
    codes, labels = [], []
    for d in df["DTE"].to_list():
        c, l = _bucket_from_dte(d, vega_buckets)
        codes.append(c); labels.append(l)
    out = df.copy()
    out["vega_bucket_code"] = codes
    out["vega_bucket_label"] = labels
    return out

def compute_platform_vega(df_live: pd.DataFrame, vega_buckets) -> Tuple[Dict[str,float], float]:
    # live df must have: DTE, vega (per contract), open_interest
    x = df_live.copy()
    for col in ["vega","open_interest","DTE"]:
        if col not in x.columns:
            x[col] = np.nan
    x["vega"] = pd.to_numeric(x["vega"], errors="coerce")
    x["open_interest"] = pd.to_numeric(x["open_interest"], errors="coerce")
    x = x.replace([np.inf, -np.inf], np.nan).dropna(subset=["vega","open_interest","DTE"])
    if x.empty:
        return {b[2]: 1e-9 for b in vega_buckets}, 1e-9

    x = tag_buckets(x, vega_buckets)
    # absolute vega * OI as a proxy of platform vega mass in bucket
    x["platform_vega_contrib"] = x["vega"].abs() * x["open_interest"].abs()
    bucket_sum = x.groupby("vega_bucket_code")["platform_vega_contrib"].sum().to_dict()
    total = float(np.nansum(list(bucket_sum.values())))
    # anti-zero
    for _, _, code, _ in vega_buckets:
        bucket_sum[code] = float(bucket_sum.get(code, 0.0)) if float(bucket_sum.get(code, 0.0)) > 0 else 1e-9
    total = total if total > 0 else 1e-9
    return bucket_sum, total

def compute_account_vega(df_pos: pd.DataFrame, vega_buckets) -> Tuple[Dict[str,float], float]:
    # positions df must have: kind, DTE, vega (per contract), size (signed contracts)
    x = df_pos.copy()
    if "kind" in x.columns:
        x = x[x["kind"].astype(str).str.lower() != "perpetual"]  # ignore perps
    for col in ["vega","size","DTE"]:
        if col not in x.columns:
            x[col] = np.nan
    x["vega"] = pd.to_numeric(x["vega"], errors="coerce")
    x["size"] = pd.to_numeric(x["size"], errors="coerce")
    x = x.replace([np.inf, -np.inf], np.nan).dropna(subset=["vega","size","DTE"])
    if x.empty:
        return {b[2]: 0.0 for b in vega_buckets}, 0.0

    x = tag_buckets(x, vega_buckets)
    # net account vega per bucket (signed)
    x["account_vega_contrib"] = x["vega"] * x["size"]
    bucket_net = x.groupby("vega_bucket_code")["account_vega_contrib"].sum().to_dict()
    total = float(np.nansum(list(bucket_net.values())))
    for _, _, code, _ in vega_buckets:
        bucket_net[code] = float(bucket_net.get(code, 0.0))
    return bucket_net, total

def maybe_boost_caps_per_bucket(
    max_share_bucket: Dict[str,float],
    account_total_share: float,
    trigger: float,
    factor: float,
    enable: bool = True
) -> Dict[str,float]:
    if enable and (account_total_share < trigger):
        return {k: v * factor for k, v in max_share_bucket.items()}
    return dict(max_share_bucket)

def apply_vega_concentration_to_slate(
    slate: pd.DataFrame,
    *,
    vega_buckets,
    platform_bucket: Dict[str,float],
    platform_total: float,
    account_bucket: Dict[str,float],
    account_total: float,
    max_share_bucket: Dict[str,float],
    max_share_total: float,
    min_vega_threshold: Dict[str,float],
    dynamic_cfg: Dict[str, object],
    allow_scale: bool = True,
) -> pd.DataFrame:
    """
    Expects slate to contain at minimum: DTE, vega, qty (float).
    Returns slate with:
      - vega_bucket_code, vega_bucket_label
      - share_bucket_now, share_total_now
      - share_bucket_proj, share_total_proj
      - eligible_vega (0/1)
      - qty (possibly scaled, float)
    """
    df = slate.copy()
    df = tag_buckets(df, vega_buckets)

    # shares now
    share_total_now = (account_total / max(platform_total, 1e-9))
    caps_bucket = maybe_boost_caps_per_bucket(
        max_share_bucket,
        account_total_share=abs(share_total_now),
        trigger=float(dynamic_cfg.get("trigger", 0.10)),
        factor=float(dynamic_cfg.get("factor", 1.5)),
        enable=bool(dynamic_cfg.get("enable", True))
    )

    df["eligible_vega"] = 1
    df["share_total_now"] = share_total_now

    for idx, row in df.iterrows():
        b = row["vega_bucket_code"]
        cand_v = float(row.get("vega", 0.0))
        qty    = float(row.get("qty", 0.0))
        # candidate vega impact is vega_per_contract * qty  (signed vega follows trade sign; here use row.vega sign)
        cand_vega_total = cand_v * qty

        acct_b = float(account_bucket.get(b, 0.0))
        plat_b = float(platform_bucket.get(b, 1e-9))

        share_b_now = (acct_b / max(plat_b, 1e-9))
        df.at[idx, "share_bucket_now"] = share_b_now

        # thresholds
        thr_b = float(min_vega_threshold.get(b, 0.0))
        thr_total = float(min_vega_threshold.get("TOTAL", 0.0))
        cap_b = float(caps_bucket.get(b, max_share_bucket.get(b, 1.0)))

        # ignore near-zero regimes (below thresholds)
        if abs(acct_b) < thr_b and abs(cand_vega_total) < thr_b and abs(account_total) < thr_total:
            # Still write projections for transparency
            df.at[idx, "share_bucket_proj"] = share_b_now
            df.at[idx, "share_total_proj"]  = share_total_now
            continue

        share_b_proj = (acct_b + cand_vega_total) / max(plat_b, 1e-9)
        share_t_proj = (account_total + cand_vega_total) / max(platform_total, 1e-9)
        df.at[idx, "share_bucket_proj"] = share_b_proj
        df.at[idx, "share_total_proj"]  = share_t_proj

        violates_bucket = abs(share_b_proj) > cap_b
        violates_total  = abs(share_t_proj) > max_share_total

        if violates_bucket or violates_total:
            if not allow_scale:
                df.at[idx, "eligible_vega"] = 0
                continue
            # compute headroom in vega units (signed)
            headroom_b = (np.sign(cand_vega_total) *
                          (cap_b * plat_b - np.sign(cand_vega_total) * acct_b))
            headroom_t = (np.sign(cand_vega_total) *
                          (max_share_total * platform_total - np.sign(cand_vega_total) * account_total))
            # choose the tightest headroom
            # convert to quantity scale: qty_new = headroom / vega_per_contract
            denom = cand_v if abs(cand_v) > 1e-12 else np.nan
            if not np.isfinite(denom):
                df.at[idx, "eligible_vega"] = 0
                continue
            max_addable_vega = np.sign(cand_vega_total) * min(abs(headroom_b), abs(headroom_t))
            new_qty = max_addable_vega / denom
            if new_qty <= 0:
                df.at[idx, "eligible_vega"] = 0
            else:
                df.at[idx, "qty"] = float(new_qty)

    return df
