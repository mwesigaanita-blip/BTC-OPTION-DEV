# ref_mm_estimator.py
# ------------------------------------------------------------
# Estimate ref_mm_per_contract_btc from:
#   - account_info (your dict structure below),
#   - live options DataFrame,
#   - optional current positions DataFrame,
# using either your margin simulator (recommended) or a safe heuristic fallback.
#
# Usage (quick):
#   ref = estimate_ref_mm_per_contract_btc(
#       account_info=account_info,
#       live_options_df=filtered_options_df,      # prefer filtered_options.csv
#       positions_df=current_positions_df,        # optional
#       margin_estimator=estimate_margins_standard_real,  # your simulator
#       trials=16,
#       side="SELL",
#       percentile=0.75,  # P75 for conservative budget
#   )
#   print("ref_mm_per_contract_btc:", ref)
# ------------------------------------------------------------

from typing import Callable, Dict, Optional
import pandas as pd


def _build_current_positions(df: Optional[pd.DataFrame]) -> Dict[str, int]:
    """
    Convert positions into {symbol: signed_qty}.
    SELL/SHORT -> negative; BUY/LONG -> positive.
    Falls back to raw 'size' sign if side/direction is missing.
    """
    if df is None or getattr(df, "empty", True):
        return {}
    name_col = "instrument_name" if "instrument_name" in df.columns else ("symbol" if "symbol" in df.columns else None)
    if not name_col:
        return {}
    cur: Dict[str, int] = {}
    for _, row in df.iterrows():
        sym = str(row.get(name_col, "")).upper().strip()
        if not sym:
            continue
        try:
            qty_abs = int(round(abs(float(row.get("qty", row.get("size", 0)) or 0))))
        except Exception:
            qty_abs = 0
        if qty_abs == 0:
            continue
        side = str(row.get("side") or row.get("direction") or "").upper()
        if side in ("SELL", "SHORT"):
            signed = -qty_abs
        elif side in ("BUY", "LONG"):
            signed = +qty_abs
        else:
            try:
                signed = int(round(float(row.get("size", 0))))
            except Exception:
                signed = 0
        if signed != 0:
            cur[sym] = cur.get(sym, 0) + signed
    return {k: int(v) for k, v in cur.items()}


def _make_mark_lookup_from_live(live_df: pd.DataFrame):
    """
    Build a lookup(sym)->mark_price_btc from a live options DataFrame.
    Tries several common column names. All prices must be BTC-denominated.
    """
    if live_df is None or getattr(live_df, "empty", True):
        raise ValueError("live options dataframe is empty")

    sym_col = None
    for c in ("instrument_name", "symbol"):
        if c in live_df.columns:
            sym_col = c
            break
    if sym_col is None:
        raise ValueError("Missing symbol column in live options (expected 'instrument_name' or 'symbol')")

    mark_cols_order = [
        "mark_price_btc",
        "mark_price",   # Deribit native mark (BTC)
        "mid_btc",
        "mid",
        "mark",
    ]

    cache: Dict[str, float] = {}
    chosen = None
    for col in mark_cols_order:
        if col in live_df.columns:
            vals = []
            for s, v in zip(live_df[sym_col], live_df[col]):
                if s is None:
                    continue
                try:
                    vv = float(v)
                except Exception:
                    continue
                if vv > 0:
                    cache[str(s).upper()] = vv
                    vals.append(vv)
            if len(vals) >= max(1, len(live_df) // 30):  # minimal coverage check
                chosen = col
                break

    if chosen is None:
        # Last resort: bid/ask mid, BTC-denominated
        if "bid_price_btc" in live_df.columns and "ask_price_btc" in live_df.columns:
            for s, b, a in zip(live_df[sym_col], live_df["bid_price_btc"], live_df["ask_price_btc"]):
                if s is None:
                    continue
                try:
                    b = float(b); a = float(a)
                except Exception:
                    continue
                if b > 0 and a > 0:
                    cache[str(s).upper()] = float((b + a) / 2.0)
        else:
            raise ValueError("Could not locate a BTC mark column in live options")

    def _lookup(sym: str) -> float:
        key = (sym or "").upper()
        if key in cache:
            return float(cache[key])
        raise ValueError(f"Missing mark for symbol: {key}")
    return _lookup


def _default_candidate_filter(df: pd.DataFrame) -> pd.DataFrame:
    """
    Conservative, generic filter for short-option candidates.
    (DTE 10–60 if present, |Δ| 0.10–0.40 if present, OI>=10, spread_pct<=0.15, positive mark.)
    """
    out = df.copy()
    sym_col = None
    for c in ("instrument_name", "symbol"):
        if c in out.columns:
            sym_col = c
            break
    if sym_col is None:
        return out.iloc[0:0]

    # Positive mark
    mark_cols = [c for c in ("mark_price_btc", "mark_price", "mid_btc", "mid", "mark") if c in out.columns]
    if mark_cols:
        mcol = mark_cols[0]
        out = out[pd.to_numeric(out[mcol], errors="coerce") > 0]

    # DTE band
    if "dte" in out.columns:
        out = out[(pd.to_numeric(out["dte"], errors="coerce") >= 10) & (pd.to_numeric(out["dte"], errors="coerce") <= 60)]

    # Liquidity & spread
    if "oi" in out.columns:
        out = out[pd.to_numeric(out["oi"], errors="coerce") >= 10]
    if "open_interest" in out.columns:
        out = out[pd.to_numeric(out["open_interest"], errors="coerce") >= 10]
    if "spread_pct" in out.columns:
        out = out[pd.to_numeric(out["spread_pct"], errors="coerce") <= 0.15]

    # Delta band
    if "delta" in out.columns:
        ad = out["delta"].astype(float).abs()
        out = out[(ad >= 0.10) & (ad <= 0.40)]

    return out.drop_duplicates(subset=[sym_col])


def estimate_ref_mm_per_contract_btc(
    account_info: Dict,
    live_options_df: pd.DataFrame,
    positions_df: Optional[pd.DataFrame] = None,
    margin_estimator: Optional[Callable[..., Dict]] = None,
    trials: int = 16,
    side: str = "SELL",
    percentile: float = 0.50,
    seed: Optional[int] = 42,
    candidate_filter=None,
    futures_contract_usd: float = 10.0,
    allow_heuristic_fallback: bool = True,
) -> float:
    """
    Empirically estimate ref_mm_per_contract_btc by probing N=trials hypothetical OPEN(1)
    on live options, measuring the delta maintenance margin.
    Returns a single float in BTC.

    Parameters
    ----------
    account_info : dict
        Must include 'maintenance_margin' and 'margin_balance' (or 'equity'), and 'index_price_usd' if your simulator needs it.
    live_options_df : DataFrame
        Prefer your filtered candidates (filtered_options.csv). Must have instrument_name/symbol and a BTC mark column.
    positions_df : DataFrame or None
        Optional; improves accuracy via offsets.
    margin_estimator : callable or None
        Your simulator (e.g., estimate_margins_standard_real). If None, falls back to a premium-based heuristic if allowed.
    trials : int
        Number of candidate symbols to probe with qty=1.
    side : str
        "SELL" (default) or "BUY" for the hypothetical open.
    percentile : float
        0.50=median, 0.75=P75 (safer).
    seed : int or None
        For reproducible sampling; set None to just take head(trials).
    candidate_filter : callable or None
        To override the default filter.
    futures_contract_usd : float
        Passed through to the simulator (Deribit futures = 10.0).
    allow_heuristic_fallback : bool
        If True and simulator unavailable/failing, use a conservative premium-based fallback.

    Returns
    -------
    float : ref_mm_per_contract_btc
    """
    if margin_estimator is None and not allow_heuristic_fallback:
        raise ValueError("margin_estimator is required when allow_heuristic_fallback=False")

    # Baseline (post-close if you've already simulated closes upstream)
    mb_after = float(account_info.get("margin_balance") or account_info.get("equity") or 0.0)
    mm_after = float(account_info.get("maintenance_margin") or 0.0)
    index_price_usd = float(account_info.get("index_price_usd") or account_info.get("equity_usd", 0.0))

    current_positions = _build_current_positions(positions_df)
    mark_lookup_fn = _make_mark_lookup_from_live(live_options_df)

    filt_fn = candidate_filter or _default_candidate_filter
    cand = filt_fn(live_options_df)

    # Identify symbol column
    sym_col = None
    for c in ("instrument_name", "symbol"):
        if c in cand.columns:
            sym_col = c
            break

    # If nothing usable, return heuristic
    if sym_col is None or cand.empty:
        if allow_heuristic_fallback:
            premium_cols = [c for c in ("mark_price_btc", "mark_price", "mid_btc", "mid", "mark") if c in live_options_df.columns]
            if premium_cols:
                mcol = premium_cols[0]
                prem = pd.to_numeric(live_options_df[mcol], errors="coerce")
                prem = prem[prem > 0]
                if prem.empty:
                    return 0.02
                med_prem = float(prem.median())
                return float(max(0.002, 1.2 * med_prem + 0.003))  # α*premium+β heuristic
            return 0.02
        return 0.0

    # Sample candidates
    if seed is not None:
        cand = cand.sample(n=min(trials, len(cand)), random_state=seed, replace=False)
    else:
        cand = cand.head(trials)

    deltas = []
    for sym in cand[sym_col].astype(str).str.upper().tolist():
        decisions_df = pd.DataFrame([{
            "symbol": sym,
            "action": "OPEN",
            "side": side.upper(),
            "quantity": 1,
        }])
        if margin_estimator is None:
            # Heuristic per-symbol if no simulator
            try:
                mark = float(mark_lookup_fn(sym))
                deltas.append(max(0.0, 1.2 * mark + 0.003))
            except Exception:
                continue
        else:
            try:
                est = margin_estimator(
                    account_info=account_info,
                    decisions_df=decisions_df,
                    index_price=float(index_price_usd),
                    mark_lookup=mark_lookup_fn,
                    futures_contract_usd=float(futures_contract_usd),
                    current_positions=current_positions,
                )
                mm_new = float(est["new"].get("mm_btc", mm_after))
                delta = mm_new - mm_after
                if delta > 0:
                    deltas.append(delta)
            except Exception:
                # Skip symbols that fail simulation
                continue

    if not deltas:
        # Global heuristic fallback
        if allow_heuristic_fallback:
            premium_cols = [c for c in ("mark_price_btc", "mark_price", "mid_btc", "mid", "mark") if c in live_options_df.columns]
            if premium_cols:
                mcol = premium_cols[0]
                prem = pd.to_numeric(live_options_df[mcol], errors="coerce")
                prem = prem[prem > 0]
                if prem.empty:
                    return 0.02
                med_prem = float(prem.median())
                return float(max(0.002, 1.2 * med_prem + 0.003))
            return 0.02
        return 0.0

    deltas.sort()
    pct = max(0.0, min(1.0, float(percentile)))
    idx = int(round((len(deltas) - 1) * pct))
    ref = float(deltas[idx])
    return float(max(1e-6, ref))

