"""
Deribit BTC Options - 1-Minute OHLCV Pipeline
===============================================
Fetches 1-minute candlestick data for every active BTC option on Deribit,
validates, deduplicates, and writes daily-partitioned Parquet files into
a data-lake folder structure.

Target path (inside container):
  /data/raw/cefi/options/ohlcv/exchange=deribit/underlying=BTC/
      granularity=1m/year={Y}/month={MM}/{YYYY-MM-DD}.parquet

CLI usage:
  python -m multi_agent_system.options_ohlcv --lookback-hours 2
  python -m multi_agent_system.options_ohlcv --backfill-days 7
  python -m multi_agent_system.options_ohlcv --validate-only
"""
from __future__ import annotations

import argparse
import json
import logging
import os
import time
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import date, datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

from .config import DATA_ROOT, DERIBIT_TV_URL

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------
log = logging.getLogger("options_ohlcv")

DERIBIT_INSTRUMENTS_URL = "https://www.deribit.com/api/v2/public/get_instruments"

OHLCV_BASE = DATA_ROOT / "raw" / "cefi" / "options" / "ohlcv" / "exchange=deribit" / "underlying=BTC" / "granularity=1m"
STATE_DIR = DATA_ROOT / "raw" / "cefi" / "options" / "ohlcv" / "_state"
STATE_FILE = STATE_DIR / "deribit_btc_1m.json"
DEBUG_DIR = DATA_ROOT / "raw" / "cefi" / "options" / "ohlcv" / "_debug"

MAX_CONCURRENT = 10
INTER_REQUEST_SLEEP = 0.055  # ~18 req/s
BATCH_SIZE = 50
BATCH_PAUSE = 1.0  # seconds pause every BATCH_SIZE instruments

REQUIRED_COLUMNS = [
    "timestamp", "open", "high", "low", "close",
    "volume", "cost", "instrument_name",
    "exchange", "underlying", "granularity",
]

PARQUET_SCHEMA = pa.schema([
    ("timestamp", pa.timestamp("ms", tz="UTC")),
    ("open", pa.float64()),
    ("high", pa.float64()),
    ("low", pa.float64()),
    ("close", pa.float64()),
    ("volume", pa.float64()),
    ("cost", pa.float64()),
    ("instrument_name", pa.string()),
    ("exchange", pa.string()),
    ("underlying", pa.string()),
    ("granularity", pa.string()),
])

# How many debug files to keep
DEBUG_KEEP = 48


# ---------------------------------------------------------------------------
# HTTP session
# ---------------------------------------------------------------------------
def _make_session(
    total: int = 6,
    backoff_factor: float = 0.5,
    status_forcelist: tuple = (429, 500, 502, 503, 504),
) -> requests.Session:
    s = requests.Session()
    retry = Retry(
        total=total,
        connect=total,
        read=total,
        status=total,
        backoff_factor=backoff_factor,
        status_forcelist=status_forcelist,
        allowed_methods=frozenset(["GET"]),
        raise_on_status=False,
    )
    adapter = HTTPAdapter(max_retries=retry, pool_connections=20, pool_maxsize=20)
    s.mount("https://", adapter)
    s.headers.update({"User-Agent": "btc-options-ohlcv/1.0"})
    return s


# ---------------------------------------------------------------------------
# State management
# ---------------------------------------------------------------------------
_DEFAULT_STATE: Dict[str, Any] = {
    "last_successful_ts_ms": None,
    "last_completed_date": None,
    "last_run_at": None,
    "instruments_fetched": 0,
    "rows_written": 0,
    "gaps": [],
}


def load_state() -> Dict[str, Any]:
    if STATE_FILE.exists():
        try:
            with open(STATE_FILE, "r", encoding="utf-8") as f:
                return {**_DEFAULT_STATE, **json.load(f)}
        except Exception as exc:
            log.warning("Failed to read state file, using defaults: %s", exc)
    return dict(_DEFAULT_STATE)


def save_state(state: Dict[str, Any]) -> None:
    STATE_DIR.mkdir(parents=True, exist_ok=True)
    tmp = STATE_FILE.with_suffix(".tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(state, f, indent=2, default=str)
    tmp.replace(STATE_FILE)


# ---------------------------------------------------------------------------
# Fetch instruments (active + recently expired)
# ---------------------------------------------------------------------------
def fetch_active_btc_options(
    session: requests.Session,
    timeout: tuple = (5.0, 30),
    include_expired: bool = True,
) -> List[str]:
    all_names: set = set()

    # Always fetch active instruments
    params = {"currency": "BTC", "kind": "option", "expired": "false"}
    resp = session.get(DERIBIT_INSTRUMENTS_URL, params=params, timeout=timeout)
    resp.raise_for_status()
    active = resp.json().get("result", [])
    for inst in active:
        if inst.get("instrument_name"):
            all_names.add(inst["instrument_name"])
    log.info("Fetched %d active BTC option instruments", len(active))

    # Also fetch recently expired instruments
    if include_expired:
        params_exp = {"currency": "BTC", "kind": "option", "expired": "true"}
        resp_exp = session.get(DERIBIT_INSTRUMENTS_URL, params=params_exp, timeout=timeout)
        resp_exp.raise_for_status()
        expired = resp_exp.json().get("result", [])
        for inst in expired:
            if inst.get("instrument_name"):
                all_names.add(inst["instrument_name"])
        log.info("Fetched %d expired BTC option instruments", len(expired))

    log.info("Total instruments (active + expired): %d", len(all_names))
    return sorted(all_names)


# ---------------------------------------------------------------------------
# Fetch OHLCV for one instrument
# ---------------------------------------------------------------------------
def fetch_instrument_ohlcv(
    session: requests.Session,
    instrument_name: str,
    start_ms: int,
    end_ms: int,
    resolution: str = "1",
    timeout: tuple = (3.05, 20),
) -> Optional[pd.DataFrame]:
    params = {
        "instrument_name": instrument_name,
        "resolution": resolution,
        "start_timestamp": start_ms,
        "end_timestamp": end_ms,
    }
    try:
        resp = session.get(DERIBIT_TV_URL, params=params, timeout=timeout)
        resp.raise_for_status()
        result = resp.json().get("result") or {}

        if result.get("status") != "ok":
            return None

        ticks = result.get("ticks") or []
        if not ticks:
            return None

        opens = result.get("open") or []
        highs = result.get("high") or []
        lows = result.get("low") or []
        closes = result.get("close") or []
        volumes = result.get("volume") or []
        costs = result.get("cost") or []

        n = len(ticks)
        df = pd.DataFrame({
            "timestamp": pd.to_datetime(ticks, unit="ms", utc=True),
            "open": [float(opens[i]) if i < len(opens) else float("nan") for i in range(n)],
            "high": [float(highs[i]) if i < len(highs) else float("nan") for i in range(n)],
            "low": [float(lows[i]) if i < len(lows) else float("nan") for i in range(n)],
            "close": [float(closes[i]) if i < len(closes) else float("nan") for i in range(n)],
            "volume": [float(volumes[i]) if i < len(volumes) else 0.0 for i in range(n)],
            "cost": [float(costs[i]) if i < len(costs) else 0.0 for i in range(n)],
            "instrument_name": instrument_name,
        })
        return df

    except requests.RequestException as exc:
        log.debug("Failed to fetch OHLCV for %s: %s", instrument_name, exc)
        return None
    except (KeyError, ValueError, TypeError) as exc:
        log.debug("Parse error for %s: %s", instrument_name, exc)
        return None


# ---------------------------------------------------------------------------
# Batch fetch with concurrency
# ---------------------------------------------------------------------------
def fetch_all_instruments_ohlcv(
    instruments: List[str],
    start_ms: int,
    end_ms: int,
    session: Optional[requests.Session] = None,
    max_workers: int = MAX_CONCURRENT,
) -> pd.DataFrame:
    sess = session or _make_session()
    lock = threading.Lock()
    counter = {"submitted": 0}
    results: List[pd.DataFrame] = []
    failed: List[str] = []

    def _fetch_one(inst: str) -> Optional[pd.DataFrame]:
        time.sleep(INTER_REQUEST_SLEEP)
        return fetch_instrument_ohlcv(sess, inst, start_ms, end_ms)

    with ThreadPoolExecutor(max_workers=max_workers) as pool:
        futures = {}
        for inst in instruments:
            fut = pool.submit(_fetch_one, inst)
            futures[fut] = inst

            with lock:
                counter["submitted"] += 1
                if counter["submitted"] % BATCH_SIZE == 0:
                    time.sleep(BATCH_PAUSE)

        for fut in as_completed(futures):
            inst = futures[fut]
            try:
                df = fut.result()
                if df is not None and not df.empty:
                    results.append(df)
            except Exception as exc:
                log.warning("Unexpected error fetching %s: %s", inst, exc)
                failed.append(inst)

    if failed:
        log.warning("Failed to fetch %d instruments: %s", len(failed), failed[:10])

    if not results:
        log.warning("No OHLCV data returned for any instrument")
        return pd.DataFrame(columns=REQUIRED_COLUMNS)

    df = pd.concat(results, ignore_index=True)
    log.info(
        "Fetched %d rows from %d/%d instruments",
        len(df), len(results), len(instruments),
    )
    return df


# ---------------------------------------------------------------------------
# Validation
# ---------------------------------------------------------------------------
def validate_dataframe(df: pd.DataFrame) -> Tuple[pd.DataFrame, List[str]]:
    issues: List[str] = []

    if df.empty:
        issues.append("Empty DataFrame - nothing to validate")
        return df, issues

    # Required columns
    missing_cols = [c for c in REQUIRED_COLUMNS if c not in df.columns]
    if missing_cols:
        issues.append(f"Missing columns: {missing_cols}")

    # Ensure timestamp is datetime
    if "timestamp" in df.columns:
        df["timestamp"] = pd.to_datetime(df["timestamp"], utc=True, errors="coerce")
        null_ts = df["timestamp"].isna().sum()
        if null_ts > 0:
            issues.append(f"Dropped {null_ts} rows with null timestamps")
            df = df.dropna(subset=["timestamp"])
    else:
        issues.append("No timestamp column")
        return df, issues

    # Coerce numeric columns
    for col in ("open", "high", "low", "close", "volume", "cost"):
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce")

    # OHLC sanity
    if {"high", "low"}.issubset(df.columns):
        bad_hl = (df["high"] < df["low"]).sum()
        if bad_hl > 0:
            issues.append(f"{bad_hl} rows where high < low")

    # Non-negative volume and cost
    for col in ("volume", "cost"):
        if col in df.columns:
            neg = (df[col] < 0).sum()
            if neg > 0:
                issues.append(f"{neg} rows with negative {col}")
                df.loc[df[col] < 0, col] = 0.0

    # Add metadata columns
    df["exchange"] = "deribit"
    df["underlying"] = "BTC"
    df["granularity"] = "1m"

    # Dedup
    pre_len = len(df)
    df = df.drop_duplicates(subset=["instrument_name", "timestamp"], keep="last")
    dupes = pre_len - len(df)
    if dupes > 0:
        issues.append(f"Removed {dupes} duplicate rows (instrument_name + timestamp)")

    return df, issues


# ---------------------------------------------------------------------------
# Gap detection
# ---------------------------------------------------------------------------
def detect_gaps(df: pd.DataFrame) -> List[Dict[str, Any]]:
    if df.empty or "timestamp" not in df.columns:
        return []

    gaps = []
    for inst, grp in df.groupby("instrument_name"):
        ts = grp["timestamp"].sort_values()
        diffs = ts.diff().dropna()
        expected = pd.Timedelta(minutes=1)
        big_gaps = diffs[diffs > expected * 1.5]
        for idx in big_gaps.index:
            gaps.append({
                "instrument": inst,
                "gap_after": str(ts.loc[idx] - diffs.loc[idx]),
                "gap_before": str(ts.loc[idx]),
                "gap_minutes": diffs.loc[idx].total_seconds() / 60.0,
            })

    return gaps


# ---------------------------------------------------------------------------
# Partition path
# ---------------------------------------------------------------------------
def build_partition_path(dt: date) -> Path:
    return (
        OHLCV_BASE
        / f"year={dt.year}"
        / f"month={dt.month:02d}"
        / f"{dt.isoformat()}.parquet"
    )


# ---------------------------------------------------------------------------
# Parquet write (merge + dedup)
# ---------------------------------------------------------------------------
def write_parquet_partitioned(df: pd.DataFrame) -> Dict[str, int]:
    if df.empty:
        return {}

    df["_utc_date"] = df["timestamp"].dt.date
    file_counts: Dict[str, int] = {}

    for dt, grp in df.groupby("_utc_date"):
        grp = grp.drop(columns=["_utc_date"])
        path = build_partition_path(dt)
        path.parent.mkdir(parents=True, exist_ok=True)

        # Merge with existing file
        if path.exists():
            try:
                existing = pd.read_parquet(path)
                grp = pd.concat([existing, grp], ignore_index=True)
                grp = grp.drop_duplicates(
                    subset=["instrument_name", "timestamp"], keep="last"
                )
            except Exception as exc:
                log.warning("Failed to read existing parquet %s, overwriting: %s", path, exc)

        # Ensure column order and dtypes
        for col in REQUIRED_COLUMNS:
            if col not in grp.columns:
                grp[col] = None

        grp = grp[REQUIRED_COLUMNS].copy()
        grp["timestamp"] = pd.to_datetime(grp["timestamp"], utc=True)

        # Write atomically via temp file
        tmp_path = path.with_suffix(".parquet.tmp")
        table = pa.Table.from_pandas(grp, schema=PARQUET_SCHEMA, preserve_index=False)
        pq.write_table(table, tmp_path, compression="snappy")
        tmp_path.replace(path)

        date_str = dt.isoformat()
        file_counts[date_str] = len(grp)
        log.info("Wrote %d rows to %s", len(grp), path)

    return file_counts


# ---------------------------------------------------------------------------
# Debug dump
# ---------------------------------------------------------------------------
def write_debug_dump(summary: Dict[str, Any]) -> Path:
    DEBUG_DIR.mkdir(parents=True, exist_ok=True)
    ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    path = DEBUG_DIR / f"run_{ts}.json"

    with open(path, "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2, default=str)

    # Prune old files
    files = sorted(DEBUG_DIR.glob("run_*.json"), key=lambda p: p.stat().st_mtime)
    for old in files[:-DEBUG_KEEP]:
        try:
            old.unlink()
        except OSError:
            pass

    return path


# ---------------------------------------------------------------------------
# Validate existing parquet files (CLI --validate-only)
# ---------------------------------------------------------------------------
def validate_existing_files(base_path: Path = OHLCV_BASE) -> List[Dict[str, Any]]:
    results = []
    for pf in sorted(base_path.rglob("*.parquet")):
        entry: Dict[str, Any] = {"file": str(pf), "issues": []}
        try:
            df = pd.read_parquet(pf)
            entry["rows"] = len(df)

            missing = [c for c in REQUIRED_COLUMNS if c not in df.columns]
            if missing:
                entry["issues"].append(f"Missing columns: {missing}")

            if "timestamp" in df.columns and "instrument_name" in df.columns:
                dupes = df.duplicated(subset=["instrument_name", "timestamp"]).sum()
                if dupes > 0:
                    entry["issues"].append(f"{dupes} duplicate rows")

            # Check path matches data
            stem = pf.stem  # e.g. 2026-04-13
            if "timestamp" in df.columns:
                dates_in_data = df["timestamp"].dt.date.unique()
                for d in dates_in_data:
                    if d.isoformat() != stem:
                        entry["issues"].append(f"Row date {d} doesn't match file {stem}")

        except Exception as exc:
            entry["issues"].append(f"Read error: {exc}")

        results.append(entry)

    return results


# ---------------------------------------------------------------------------
# Main pipeline orchestrator
# ---------------------------------------------------------------------------
def run_options_ohlcv_pipeline(
    *,
    lookback_hours: int = 2,
    force_start_ms: Optional[int] = None,
) -> Dict[str, Any]:
    run_start = datetime.now(timezone.utc)
    log.info("Starting options OHLCV pipeline (lookback_hours=%d)", lookback_hours)

    state = load_state()
    session = _make_session()

    # Determine time range
    now_ms = int(run_start.timestamp() * 1000)

    if force_start_ms is not None:
        start_ms = force_start_ms
    elif state.get("last_successful_ts_ms"):
        # Overlap by 3 minutes for safety
        start_ms = state["last_successful_ts_ms"] - 180_000
    else:
        # First run - 24 hours back
        start_ms = now_ms - (lookback_hours * 3_600_000)
        if lookback_hours <= 2:
            start_ms = now_ms - (24 * 3_600_000)

    end_ms = now_ms
    log.info(
        "Fetch range: %s → %s",
        datetime.utcfromtimestamp(start_ms / 1000).isoformat(),
        datetime.utcfromtimestamp(end_ms / 1000).isoformat(),
    )

    # Fetch instruments
    try:
        instruments = fetch_active_btc_options(session)
    except Exception as exc:
        log.error("Failed to fetch instruments: %s", exc)
        return {"error": str(exc), "run_start": run_start.isoformat()}

    # Fetch OHLCV for all instruments
    df_raw = fetch_all_instruments_ohlcv(instruments, start_ms, end_ms, session=session)
    rows_fetched = len(df_raw)

    # Validate and enrich
    df, validation_issues = validate_dataframe(df_raw)
    rows_after_validation = len(df)
    duplicates_removed = rows_fetched - rows_after_validation

    # Gap detection
    gap_summary = detect_gaps(df)
    if gap_summary:
        log.info("Detected %d gaps in 1-minute continuity", len(gap_summary))

    # Write partitioned parquet
    files_written = write_parquet_partitioned(df)
    rows_written = sum(files_written.values()) if files_written else 0

    run_end = datetime.now(timezone.utc)

    # Update state
    state["last_successful_ts_ms"] = end_ms
    state["last_completed_date"] = run_end.strftime("%Y-%m-%d")
    state["last_run_at"] = run_end.isoformat()
    state["instruments_fetched"] = len(instruments)
    state["rows_written"] = rows_written
    state["gaps"] = gap_summary[:20]  # cap to prevent bloat
    save_state(state)

    # Build summary
    instruments_with_data = df["instrument_name"].nunique() if not df.empty else 0
    summary = {
        "run_start": run_start.isoformat(),
        "run_end": run_end.isoformat(),
        "duration_seconds": round((run_end - run_start).total_seconds(), 1),
        "requested_range_ms": [start_ms, end_ms],
        "instruments_total": len(instruments),
        "instruments_with_data": instruments_with_data,
        "rows_fetched": rows_fetched,
        "rows_after_validation": rows_after_validation,
        "duplicates_removed": duplicates_removed,
        "gap_summary": gap_summary[:10],
        "files_written": files_written,
        "validation_failures": validation_issues,
    }

    # Write debug dump
    debug_path = write_debug_dump(summary)
    log.info(
        "Pipeline complete: %d instruments, %d rows written to %d files (debug: %s)",
        len(instruments), rows_written, len(files_written), debug_path,
    )

    return summary


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------
def main():
    parser = argparse.ArgumentParser(
        description="Deribit BTC Options OHLCV Pipeline",
    )
    parser.add_argument(
        "--lookback-hours", type=int, default=2,
        help="Hours to look back from now (default: 2, first run always does 24h)",
    )
    parser.add_argument(
        "--backfill-days", type=int, default=None,
        help="Override: backfill N days of history",
    )
    parser.add_argument(
        "--validate-only", action="store_true",
        help="Validate existing parquet files without fetching",
    )
    args = parser.parse_args()

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
        handlers=[logging.StreamHandler()],
        force=True,
    )

    if args.validate_only:
        results = validate_existing_files()
        for r in results:
            status = "OK" if not r["issues"] else "ISSUES"
            print(f"[{status}] {r['file']} - {r.get('rows', '?')} rows")
            for issue in r.get("issues", []):
                print(f"        {issue}")
        return

    force_start_ms = None
    if args.backfill_days:
        now = datetime.now(timezone.utc)
        start = now - timedelta(days=args.backfill_days)
        force_start_ms = int(start.timestamp() * 1000)
        log.info("Backfill mode: %d days (%s)", args.backfill_days, start.isoformat())

    result = run_options_ohlcv_pipeline(
        lookback_hours=args.lookback_hours,
        force_start_ms=force_start_ms,
    )

    print(json.dumps(result, indent=2, default=str))


if __name__ == "__main__":
    main()
