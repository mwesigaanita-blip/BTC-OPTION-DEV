# sentiment.py  (ver_10/)
from __future__ import annotations

import os
import re
import sqlite3
import logging
from datetime import datetime, timedelta, timezone
from typing import List, Dict, Any, Tuple

import numpy as np
import pandas as pd
import feedparser

# Pull shared settings/paths from config (already loads .env & sets BASE_DIR/DB_PATH)
from .config import *  # noqa: F401,F403  (non-DB constants)
from shared.db_paths import MARKET_DATA_DB, MODELS_DB

# ``macro_daily`` lives in MARKET_DATA_DB; ``x_score`` lives in MODELS_DB.
# DB_PATH is kept as an alias to MARKET_DATA_DB for any external code
# that previously imported ``DB_PATH`` from this module.
DB_PATH = MARKET_DATA_DB
print(f"[DB] Using MARKET_DATA_DB={MARKET_DATA_DB}, MODELS_DB={MODELS_DB} in {__file__}",
      flush=True)

# Optional: basic logging if main/config didn't attach a handler
if not logging.getLogger().handlers:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")


def get_macro_sentiment_score(
    days_back: int = 2,
    half_life_hours: float = 24.0,
    max_articles: int = 600,
    max_per_source: int = 150,
    min_relevance: float = 0.15,     # 0..1; filter out off-topic pieces
    model_name: str = "ProsusAI/finbert",
    text_max_length: int = 512,      # FinBERT is BERT-size (512 tokens)
    return_details: bool = False,
) -> float | Tuple[float, Dict[str, Any]]:
    """
    Advanced macro news sentiment for BTC context.
    Pulls RSS, filters for macro/crypto relevance, scores with FinBERT (batched),
    and returns a time- & relevance-weighted average in [-1, 1].

    Side effect: saves ONE macro score per UTC date into SQLite table macro_daily(day_utc, score, n_items, ts_utc).
    Save mode via env MACRO_SAVE_MODE: "override" (default) or "skip".
    """

    # Optional HF + VADER imports with graceful fallbacks
    try:
        import torch  # noqa: F401
    except Exception:
        torch = None
    try:
        from transformers import pipeline
    except Exception:
        pipeline = None
    try:
        from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer as _VADER
    except Exception:
        _VADER = None

    SAVE_MODE = (os.getenv("MACRO_SAVE_MODE", "override") or "override").lower()  # "override" | "skip"

    RSS_FEEDS: List[Tuple[str, str]] = [
        ("https://www.federalreserve.gov/feeds/rss", "Federal Reserve"),
        ("https://feeds.a.dj.com/rss/RSSMarketsMain.xml", "WSJ/DJ Markets"),
        ("http://feeds.reuters.com/reuters/topNews", "Reuters"),
        ("https://www.bloomberg.com/markets/economics/rss", "Bloomberg Econ"),
        ("https://www.bloomberg.com/crypto/rss", "Bloomberg Crypto"),
        ("https://www.coindesk.com/arc/outboundfeeds/rss/", "Coindesk"),
        ("https://cointelegraph.com/rss", "Cointelegraph"),
        ("https://finance.yahoo.com/news/rssindex", "Yahoo Finance"),
    ]

    # Macro + crypto lexicons for soft relevance
    CRYPTO_TERMS = {
        "bitcoin": 1.0, "btc": 1.0, "satoshi": 0.6, "crypto": 0.9, "cryptocurrency": 0.9,
        "ethereum": 0.6, "eth": 0.5, "blockchain": 0.7, "etf": 0.6, "spot etf": 0.8,
        "halving": 0.8, "hashrate": 0.6, "miners": 0.6, "lightning": 0.5
    }
    MACRO_TERMS = {
        "inflation": 0.8, "cpi": 0.9, "ppi": 0.7, "pce": 0.7,
        "fed": 1.0, "federal reserve": 1.0, "powell": 0.8, "interest rate": 1.0,
        "rate hike": 1.0, "rate cut": 1.0, "dot plot": 0.6, "qe": 0.7, "qt": 0.7,
        "yields": 0.6, "treasury": 0.7, "jobs": 0.5, "nfp": 0.7, "unemployment": 0.6,
        "manufacturing": 0.4, "ism": 0.6, "gdp": 0.7, "recession": 0.8,
        "liquidity": 0.7, "volatility": 0.5, "market breadth": 0.4
    }
    SOURCE_WEIGHTS = {
        "Federal Reserve": 1.10,
        "Reuters": 1.15,
        "WSJ/DJ Markets": 1.10,
        "Bloomberg Econ": 1.12,
        "Bloomberg Crypto": 1.00,
        "Yahoo Finance": 0.95,
        "Coindesk": 0.90,
        "Cointelegraph": 0.85,
    }

    # ---------- Helpers ----------
    def _utcnow() -> datetime:
        return datetime.now(timezone.utc)

    def _parse_dt(entry) -> datetime:
        def _to_dt(t):
            try:
                return datetime(*t[:6], tzinfo=timezone.utc)
            except Exception:
                return None
        for fld in ("published_parsed", "updated_parsed"):
            tstruct = entry.get(fld)
            if tstruct:
                dt = _to_dt(tstruct)
                if dt:
                    return dt
        return _utcnow()

    def relevance_score(text: str) -> float:
        t = text.lower()
        if not t:
            return 0.0
        hits = 0.0
        for k, w in CRYPTO_TERMS.items():
            if k in t:
                hits += w * 1.0
        for k, w in MACRO_TERMS.items():
            if k in t:
                hits += w * 0.8
        norm = 5.0 + 0.02 * max(0, len(text))
        return float(max(0.0, min(1.0, (hits / norm) * 12.0)))

    # ---------- Load model or fallback ----------
    device = 0 if (torch is not None and getattr(torch, "cuda", None) and torch.cuda.is_available()) else -1
    analyzer = None
    use_vader = False

    if pipeline is not None:
        try:
            analyzer = pipeline(
                task="text-classification",
                model=model_name,
                tokenizer=model_name,
                device=device,
                truncation=True
            )
            logging.info("Loaded %s on %s", model_name, "GPU" if device == 0 else "CPU")
        except Exception as e:
            logging.warning("HF model load failed (%s); falling back to VADER.", e)
            analyzer = None

    if analyzer is None:
        if _VADER is not None:
            vader = _VADER()
            use_vader = True
        else:
            logging.error("No sentiment model available (HF + VADER missing).")
            return (0.0, {"reason": "no_model"}) if return_details else 0.0

    # ---------- Ensure table & uniqueness ----------
    db_conn = None
    try:
        db_conn = sqlite3.connect(str(MARKET_DATA_DB), timeout=30)
        cur = db_conn.cursor()
        cur.execute("PRAGMA journal_mode=WAL;")
        cur.execute("""
            CREATE TABLE IF NOT EXISTS macro_daily (
                day_utc  TEXT PRIMARY KEY,
                score    REAL NOT NULL,
                n_items  INTEGER NOT NULL DEFAULT 0,
                ts_utc   TEXT NOT NULL
            )
        """)
        cur.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_macro_daily_day_utc ON macro_daily(day_utc);")
        db_conn.commit()
    except Exception as e:
        logging.warning("DB init failed (%s). Will proceed without saving.", e)
        db_conn = None

    # ---------- Fetch feeds ----------
    cutoff = _utcnow() - timedelta(days=days_back)
    rows: List[Dict[str, Any]] = []

    for url, source in RSS_FEEDS:
        try:
            feed = feedparser.parse(url)
            cnt = 0
            for entry in feed.entries:
                pub_dt = _parse_dt(entry)
                if pub_dt < cutoff:
                    continue
                title = entry.get("title", "") or ""
                summary = entry.get("summary", "") or ""
                summary_clean = re.sub(r"<[^>]+>", " ", summary)
                text = (title + " " + summary_clean).strip()
                if len(text) < 40:
                    continue
                rel = relevance_score(text)
                if rel < min_relevance:
                    continue
                link = entry.get("link", "") or f"{source}:{hash(title)}"
                rows.append({
                    "timestamp": _utcnow().isoformat(),
                    "date": _utcnow().date().isoformat(),
                    "source": source,
                    "title": title[:300],
                    "summary": summary_clean[:1500],
                    "published": pub_dt.isoformat(),
                    "link": link[:600],
                    "btc_relevance": "btc_related",
                    "relevance": float(round(rel, 4)),
                })
                cnt += 1
                if cnt >= max_per_source:
                    break
        except Exception as e:
            logging.warning("Failed to fetch from %s: %s", source, e)

    if not rows:
        logging.warning("No macro/crypto-relevant articles found in time window.")
        return (0.0, {"reason": "no_articles"}) if return_details else 0.0

    df = pd.DataFrame(rows)

    # Deduplicate & limit
    df = df.sort_values("published", ascending=False)
    df = df.drop_duplicates(subset=["link"])
    df["title_norm"] = df["title"].str.lower().str.replace(r"[^a-z0-9 ]+", "", regex=True)
    df = df.drop_duplicates(subset=["title_norm"]).drop(columns=["title_norm"])
    if len(df) > max_articles:
        df = df.head(max_articles)

    # ---------- Sentiment scoring ----------
    texts = (df["title"].fillna("") + " " + df["summary"].fillna("")).tolist()
    scores: List[float] = []

    if use_vader:
        for t in texts:
            ss = vader.polarity_scores(t or "")
            scores.append(float(ss.get("compound", 0.0)))
    else:
        BATCH = 32
        for i in range(0, len(texts), BATCH):
            chunk = texts[i:i+BATCH]
            try:
                out = analyzer(
                    chunk,
                    truncation=True,
                    max_length=text_max_length,
                    return_all_scores=True
                )
                for item in out:
                    p_pos = p_neg = 0.0
                    for lab in item:
                        lab_name = str(lab.get("label", "")).lower()
                        sc = float(lab.get("score", 0.0))
                        if "pos" in lab_name:
                            p_pos = sc
                        elif "neg" in lab_name:
                            p_neg = sc
                    scores.append(float(np.clip(p_pos - p_neg, -1.0, 1.0)))
            except Exception as e:
                logging.warning("HF inference error: %s; using 0.0 for this batch.", e)
                scores.extend([0.0] * len(chunk))

    df["sentiment_score"] = np.array(scores, dtype=float)

    # ---------- Weights ----------
    try:
        df["published_dt"] = pd.to_datetime(df["published"], utc=True, errors="coerce")
        now_utc = datetime.now(timezone.utc)
        df["age_hours"] = (now_utc - df["published_dt"]).dt.total_seconds() / 3600.0
        df["w_recency"] = np.where(
            df["age_hours"].notna(),
            0.5 ** (df["age_hours"] / max(float(half_life_hours), 1e-9)),
            0.0
        )
    except Exception as e:
        logging.warning("Timestamp normalization failed (%s); setting recency weight to 1.0", e)
        df["w_recency"] = 1.0

    df["w_source"] = df["source"].map(SOURCE_WEIGHTS).fillna(1.0)
    df["w_relevance"] = np.sqrt(df["relevance"].clip(0, 1.0))
    df["weight"] = (df["w_recency"] * df["w_source"] * df["w_relevance"]).astype(float)

    # ---------- Aggregate ----------
    if df["weight"].sum() <= 0:
        agg = 0.0
    else:
        try:
            lo, hi = df["sentiment_score"].quantile([0.05, 0.95])
            keep = (df["sentiment_score"] >= lo) & (df["sentiment_score"] <= hi)
            use = df[keep].copy() if keep.sum() >= 10 else df.copy()
            agg = float(np.clip(np.average(use["sentiment_score"], weights=use["weight"]), -1.0, 1.0))
        except Exception as e:
            logging.warning("Aggregation failed (%s); using simple mean.", e)
            agg = float(np.clip(df["sentiment_score"].mean(), -1.0, 1.0))

    # ---------- Persist ONE daily score ----------
    logging.info("Macro sentiment score (weighted): %.4f on n=%d articles", agg, len(df))

    if db_conn is not None:
        try:
            cur = db_conn.cursor()
            cur.execute("PRAGMA journal_mode=WAL;")

            day_utc = datetime.now(timezone.utc).date().isoformat()
            ts_utc  = datetime.now(timezone.utc).isoformat()
            n_items = int(len(df))  # <-- FIX: define n_items for saving

            if SAVE_MODE == "skip":
                cur.execute(
                    "INSERT OR IGNORE INTO macro_daily(day_utc, score, n_items, ts_utc) VALUES (?,?,?,?)",
                    (day_utc, float(agg), n_items, ts_utc),
                )
            else:
                cur.execute(
                    """
                    INSERT INTO macro_daily(day_utc, score, n_items, ts_utc)
                    VALUES (?, ?, ?, ?)
                    ON CONFLICT(day_utc) DO UPDATE SET
                        score   = excluded.score,
                        n_items = excluded.n_items,
                        ts_utc  = excluded.ts_utc
                    """,
                    (day_utc, float(agg), n_items, ts_utc),
                )
            db_conn.commit()
            logging.info("Saved macro_daily[%s]=%.6f (n=%d)", day_utc, float(agg), n_items)
        except Exception as e:
            logging.warning("Failed to save macro_daily to DB (%s)", e)
        finally:
            try:
                db_conn.close()
            except Exception:
                pass

    if not return_details:
        return round(agg, 4)

    by_source = (
        df.groupby("source")
          .apply(lambda g: pd.Series({
              "n": int(len(g)),
              "avg_score": float(np.round(g["sentiment_score"].mean(), 4)),
              "avg_weight": float(np.round(g["weight"].mean(), 4))
          }))
          .sort_values("n", ascending=False)
          .to_dict(orient="index")
    )

    details: Dict[str, Any] = {
        "score": round(agg, 4),
        "n_articles": int(len(df)),
        "window_start": (datetime.now(timezone.utc) - timedelta(days=days_back)).isoformat(),
        "window_end": datetime.now(timezone.utc).isoformat(),
        "by_source": by_source,
        "examples": df.sort_values("weight", ascending=False)[
            ["source","title","sentiment_score","relevance","w_recency","w_source"]
        ].head(5).to_dict(orient="records")
    }
    return round(agg, 4), details

X_sentiment_sentnce = """Short-Term Sentiment: BTC stabilizes near $123.6K with positive spot CVD of +1.6K per @MeteFeridun, 2025-10-08 18:38 UTC.\nLonger-Term Sentiment: IBIT overtook Deribit in options OI at $38B versus $32B signaling institutional conviction per @coinbureau, 2025-10-08 14:26 UTC.\nInfluencing Factors: ETF inflows hit $3.5B to IBIT in a week driving accumulation per @shanaka86, 2025-10-08 12:49 UTC."""
X_score = 0.7

def get_X_score_sentiment() -> float:
    return X_score , X_sentiment_sentnce


def save_daily_x_sentiment(
    score_now: float | None,
    x_sentiment_sentence: str,
    db_path: str = "",
    *,
    score_7d: float | None = None,
    score_30d: float | None = None,
    save_mode: str | None = "override",   # "override" | "skip"; default from env X_SAVE_MODE or "override"
    date_utc: str | None = None,    # optional "YYYY-MM-DD"; default = today (UTC)
) -> dict:
    """
    Save ONE X/Twitter sentiment per UTC day into SQLite table `x_score` with the NEW schema:

        x_score(
            date TEXT PRIMARY KEY,
            score_now REAL,
            score_7d REAL,
            score_30d REAL,
            x_sentiment_sentence TEXT
        )

    Modes:
      - "override" (default): upsert; only NON-None fields overwrite existing values (None keeps old values)
      - "skip": insert-or-ignore; first write of the day wins

    Returns:
        dict: {
          "sentence": str,
          "score_now": float | None,
          "score_7d": float | None,
          "score_30d": float | None,
          "date_utc": "YYYY-MM-DD",
        }
    """
    import os, sqlite3, math, logging
    from datetime import datetime, timezone

    # ``x_score`` lives in MODELS_DB; the ``db_path`` parameter is kept
    # for backward compatibility but is no longer consulted.
    db_path = str(MODELS_DB)

    # Normalize/clamp numeric inputs if provided
    def _clamp(v):
        if v is None:
            return None
        if not isinstance(v, (int, float)) or not math.isfinite(v):
            raise ValueError("Scores must be finite floats or None.")
        return float(max(-1.0, min(1.0, float(v))))

    score_now  = _clamp(score_now)
    score_7d   = _clamp(score_7d)
    score_30d  = _clamp(score_30d)
    x_sent     = (x_sentiment_sentence or "").strip()

    if date_utc is None:
        date_utc = datetime.now(timezone.utc).date().isoformat()

    mode = (save_mode or os.getenv("X_SAVE_MODE", "override")).lower().strip()
    if mode not in ("override", "skip"):
        mode = "override"

    con = None
    try:
        con = sqlite3.connect(db_path, timeout=30)
        cur = con.cursor()
        cur.execute("PRAGMA journal_mode=WAL;")

        # Ensure new schema
        cur.execute("""
            CREATE TABLE IF NOT EXISTS x_score (
                date TEXT PRIMARY KEY,
                score_now REAL,
                score_7d REAL,
                score_30d REAL,
                x_sentiment_sentence TEXT
            )
        """)
        con.commit()

        if mode == "skip":
            # Insert or ignore; None values are fine to store
            cur.execute(
                """
                INSERT OR IGNORE INTO x_score(date, score_now, score_7d, score_30d, x_sentiment_sentence)
                VALUES (?, ?, ?, ?, ?)
                """,
                (date_utc, score_now, score_7d, score_30d, x_sent)
            )
        else:
            sets, params = [], []

            # build sets/params in the SAME order
            if score_now is not None:
                sets.append("score_now = ?")
                params.append(score_now)
            if score_7d is not None:
                sets.append("score_7d = ?")
                params.append(score_7d)
            if score_30d is not None:
                sets.append("score_30d = ?")
                params.append(score_30d)

            # sentence last (always overwrite)
            sets.append("x_sentiment_sentence = ?")
            params.append(x_sent)

            if sets:
                params.append(date_utc)
                cur.execute(f"UPDATE x_score SET {', '.join(sets)} WHERE date = ?", params)

            if cur.rowcount == 0:
                cur.execute(
                    """
                    INSERT INTO x_score (date, score_now, score_7d, score_30d, x_sentiment_sentence)
                    VALUES (?, ?, ?, ?, ?)
                    """,
                    (date_utc, score_now, score_7d, score_30d, x_sent),
                )



        con.commit()

        # Return the saved row
        cur.execute(
            "SELECT score_now, score_7d, score_30d, x_sentiment_sentence FROM x_score WHERE date=?",
            (date_utc,)
        )
        row = cur.fetchone()
        score_now_db, score_7d_db, score_30d_db, sent_db = row if row else (None, None, None, "")

        logging.info(
            "Saved x_score[%s]: now=%s 7d=%s 30d=%s (sent_len=%d, mode=%s)",
            date_utc, score_now_db, score_7d_db, score_30d_db, len(sent_db or ""), mode
        )

        return {
            "sentence": sent_db or "",
            "score_now": None if score_now_db is None else float(score_now_db),
            "score_7d": None if score_7d_db is None else float(score_7d_db),
            "score_30d": None if score_30d_db is None else float(score_30d_db),
            "date_utc": date_utc,
        }

    except Exception as e:
        logging.warning("Failed to save x_score to DB: %s", e)
        # Still return a structured payload for caller handling
        return {
            "sentence": x_sent,
            "score_now": score_now,
            "score_7d": score_7d,
            "score_30d": score_30d,
            "date_utc": date_utc,
            "error": str(e),
        }
    finally:
        try:
            if con is not None:
                con.close()
        except Exception:
            pass

# x_sentiment.py (or wherever you persist x_score)
import os, sqlite3, json
from datetime import datetime, timezone
import numpy as np

from .config import DB_PATH



# sentiment_macro_v2.py

import os, re, json, math, sqlite3, logging
from typing import Any, Dict, List, Tuple
from datetime import datetime, timedelta, timezone

import numpy as np
import pandas as pd
import feedparser

from .config import DB_PATH
from .llm_io import make_llm_client

def get_macro_sentiment_scores_llm(
    days_back: int = 2,
    half_life_hours: float = 24.0,
    max_articles: int = 600,
    max_per_source: int = 300,
    min_relevance: float = 0.15,     # 0..1
    return_details: bool = False,
    provider: str = "openai",
    model_id: str = "gpt-5-mini",
) -> Tuple[Dict[str, float], Dict[str, Any]] | Dict[str, float]:
    """
    LLM-based macro/crypto sentiment:
      • Fetches curated RSS (macro + crypto), filters by relevance,
      • Packages top weighted headlines/summaries,
      • Asks an LLM to output a one-line 'sentence' + three scores in [-1,1]:
            - score_now     (impact today / near-term)
            - score_7d      (next ~1 week)
            - score_30d     (next ~1 month)
      • Persists ONE row per run into SQLite table 'macro_daily'
        with schema: [asof_utc, sentence, score_now, score_7d, score_30d,
                      model_provider, model_id, features_json, meta_json]

    Env:
      LLM_PROVIDER: 'openai' | 'xai' | 'together' ... (supported by llm_io)
      LLM_MODEL:    provider-specific model id (e.g. 'gpt-4o-mini', 'grok-4')
      MACRO_SAVE_MODE: 'override' (default) or 'skip'

    Returns:
      dict(scores) or (dict(scores), details) if return_details=True
      scores = {'score_now': float, 'score_7d': float, 'score_30d': float, 'sentence': str}
    """

    SAVE_MODE = "override"
    provider  = provider 
    model_id  = model_id

    RSS_FEEDS: List[Tuple[str, str]] = [
        ("https://www.federalreserve.gov/feeds/rss", "Federal Reserve"),
        ("https://feeds.a.dj.com/rss/RSSMarketsMain.xml", "WSJ/DJ Markets"),
        ("http://feeds.reuters.com/reuters/topNews", "Reuters"),
        ("https://www.bloomberg.com/markets/economics/rss", "Bloomberg Econ"),
        ("https://www.bloomberg.com/crypto/rss", "Bloomberg Crypto"),
        ("https://www.coindesk.com/arc/outboundfeeds/rss/", "Coindesk"),
        ("https://cointelegraph.com/rss", "Cointelegraph"),
        ("https://finance.yahoo.com/news/rssindex", "Yahoo Finance"),
    ]

    CRYPTO_TERMS = {
        "bitcoin": 1.0, "btc": 1.0, "satoshi": 0.6, "crypto": 0.9, "cryptocurrency": 0.9,
        "ethereum": 0.6, "eth": 0.5, "blockchain": 0.7, "etf": 0.6, "spot etf": 0.8,
        "halving": 0.8, "hashrate": 0.6, "miners": 0.6, "lightning": 0.5
    }
    MACRO_TERMS = {
        "inflation": 0.8, "cpi": 0.9, "ppi": 0.7, "pce": 0.7,
        "fed": 1.0, "federal reserve": 1.0, "powell": 0.8, "interest rate": 1.0,
        "rate hike": 1.0, "rate cut": 1.0, "dot plot": 0.6, "qe": 0.7, "qt": 0.7,
        "yields": 0.6, "treasury": 0.7, "jobs": 0.5, "nfp": 0.7, "unemployment": 0.6,
        "manufacturing": 0.4, "ism": 0.6, "gdp": 0.7, "recession": 0.8,
        "liquidity": 0.7, "volatility": 0.5, "market breadth": 0.4
    }
    SOURCE_WEIGHTS = {
        "Federal Reserve": 1.10,
        "Reuters": 1.15,
        "WSJ/DJ Markets": 1.10,
        "Bloomberg Econ": 1.12,
        "Bloomberg Crypto": 1.00,
        "Yahoo Finance": 0.95,
        "Coindesk": 0.90,
        "Cointelegraph": 0.85,
    }

    def _utcnow() -> datetime:
        return datetime.now(timezone.utc)

    def _parse_dt(entry) -> datetime:
        def _to_dt(t):
            try:
                return datetime(*t[:6], tzinfo=timezone.utc)
            except Exception:
                return None
        for fld in ("published_parsed", "updated_parsed"):
            tstruct = entry.get(fld)
            if tstruct:
                dt = _to_dt(tstruct)
                if dt:
                    return dt
        return _utcnow()

    def relevance_score(text: str) -> float:
        t = (text or "").lower()
        if not t:
            return 0.0
        hits = 0.0
        for k, w in CRYPTO_TERMS.items():
            if k in t:
                hits += w * 1.0
        for k, w in MACRO_TERMS.items():
            if k in t:
                hits += w * 0.8
        norm = 5.0 + 0.02 * max(0, len(text))
        return float(max(0.0, min(1.0, (hits / norm) * 12.0)))

    # ---- Fetch feeds
    cutoff = _utcnow() - timedelta(days=days_back)
    rows: List[Dict[str, Any]] = []
    for url, source in RSS_FEEDS:
        try:
            feed = feedparser.parse(url)
            cnt = 0
            for entry in feed.entries:
                pub_dt = _parse_dt(entry)
                if pub_dt < cutoff:
                    continue
                title = entry.get("title", "") or ""
                summary = entry.get("summary", "") or ""
                summary_clean = re.sub(r"<[^>]+>", " ", summary)
                text = (title + " " + summary_clean).strip()
                if len(text) < 40:
                    continue
                rel = relevance_score(text)
                if rel < min_relevance:
                    continue
                link = entry.get("link", "") or f"{source}:{hash(title)}"
                rows.append({
                    "source": source,
                    "title": title[:300],
                    "summary": summary_clean[:1500],
                    "published": pub_dt.isoformat(),
                    "link": link[:600],
                    "relevance": float(round(rel, 4)),
                })
                cnt += 1
                if cnt >= max_per_source:
                    break
        except Exception as e:
            logging.warning("RSS fetch failed for %s: %s", source, e)

    if not rows:
        logging.warning("No articles found; returning neutral zeros.")
        result = {"sentence": "", "score_now": 0.0, "score_7d": 0.0, "score_30d": 0.0}
        return (result, {"reason": "no_articles"}) if return_details else result

    df = pd.DataFrame(rows).drop_duplicates(subset=["link"])
    df = df.sort_values("published", ascending=False)
    # extra de-dupe by normalized title
    df["title_norm"] = df["title"].str.lower().str.replace(r"[^a-z0-9 ]+", "", regex=True)
    df = df.drop_duplicates(subset=["title_norm"]).drop(columns=["title_norm"])
    if len(df) > max_articles:
        df = df.head(max_articles)

    # ---- Weighting
    try:
        df["published_dt"] = pd.to_datetime(df["published"], utc=True, errors="coerce")
        now_utc = _utcnow()
        df["age_hours"] = (now_utc - df["published_dt"]).dt.total_seconds() / 3600.0
        df["w_recency"] = np.where(
            df["age_hours"].notna(),
            0.5 ** (df["age_hours"] / max(float(half_life_hours), 1e-9)),
            0.0
        )
    except Exception as e:
        logging.warning("Timestamp normalization failed (%s); setting recency weight = 1.0", e)
        df["w_recency"] = 1.0

    df["w_source"] = df["source"].map(SOURCE_WEIGHTS).fillna(1.0)
    df["w_relevance"] = np.sqrt(df["relevance"].clip(0, 1.0))
    df["weight"] = (df["w_recency"] * df["w_source"] * df["w_relevance"]).astype(float)

    # ---- Build compact context for LLM (most informative, sorted by weight)
    context_df = df.sort_values("weight", ascending=False).copy()
    # Keep a sane cap to avoid prompt bloat (LLM still sees strongest signals)
    MAX_CTX = 80
    context_df = context_df.head(MAX_CTX)

    # Format items tersely: [source | age | title - summary]
    def _fmt_age(h):
        try:
            h = float(h)
            if h < 1:   return f"{int(round(h*60))}m"
            if h < 48:  return f"{round(h,1)}h"
            d = h / 24.0
            return f"{round(d,1)}d"
        except Exception:
            return "NA"

    items_for_llm = []
    for _, r in context_df.iterrows():
        items_for_llm.append(
            f"- [{r['source']} | { _fmt_age(r.get('age_hours', 'NA')) }] "
            f"{(r['title'] or '').strip()} - {(r['summary'] or '').strip()}"
        )

    # ---- LLM prompt
    # ---- LLM prompt
    system_msg = (
        "You are a macro/crypto news risk analyst. "
        "Given recent weighted headlines and summaries, estimate short-, medium-, and long-term market sentiment. "
        "Return ONLY a valid JSON object with exactly these keys: "
        "`sentence`, `score_now`, `score_7d`, `score_30d`.\n\n"
        "Definitions:\n"
        "- score_now : sentiment over the next 0–48 hours\n"
        "- score_7d  : sentiment over the next 7 days\n"
        "- score_30d : sentiment over the next 30 days\n\n"
        "Each score must be in [-1,1], where +1 = strongly bullish and -1 = strongly bearish.\n"
        "Avoid extreme values unless the headlines are clearly positive/negative."
    )

    # Concatenate context lines for the LLM
    context_str = "\n".join(items_for_llm)
    prompt = (
        f"{system_msg}\n\n"
        f"Recent weighted news items (most relevant first):\n{context_str}\n\n"
        "Respond with STRICT JSON only, e.g.:\n"
        '{"sentence": "Markets show cautious optimism after soft CPI data.", '
        '"score_now": 0.15, "score_7d": 0.12, "score_30d": 0.05}'
    )

    # ---- Call LLM (using make_llm_client signature)
    client = make_llm_client(provider=provider, model=model_id)
    llm_resp = client(
        prompt=prompt,
        temperature=0.2,
        max_tokens=5000,
        retries=2,
        request_timeout=300,
        verbose=True,
    )


    # Robust parse
    try:
        payload = json.loads(llm_resp["json_str"])
        sentence   = str(payload.get("sentence", "")).strip()
        score_now  = float(np.clip(float(payload.get("score_now", 0.0)),  -1.0, 1.0))
        score_7d   = float(np.clip(float(payload.get("score_7d", 0.0)),   -1.0, 1.0))
        score_30d  = float(np.clip(float(payload.get("score_30d", 0.0)),  -1.0, 1.0))
    except Exception as e:
        logging.warning("LLM JSON parse failed (%s). Falling back to neutral zeros.", e)
        sentence, score_now, score_7d, score_30d = "", 0.0, 0.0, 0.0

    result = {
        "sentence": sentence,
        "score_now": round(score_now, 4),
        "score_7d":  round(score_7d, 4),
        "score_30d": round(score_30d, 4),
    }

    # ---- Persist to new macro_daily schema
    # ---------- Persist ONE daily row (DD/MM/YYYY) ----------
    asof_dt  = _utcnow()
    asof_dmy = asof_dt.strftime("%d/%m/%Y")  # <- match table's date-only format

    features_json = {
        "window_days": days_back,
        "half_life_hours": half_life_hours,
        "n_articles_used": int(len(context_df)),
        "source_weight_means": (
            context_df.assign(sw=context_df["w_source"])
                      .groupby("source")["sw"].mean()
                      .round(4).to_dict()
        ),
        "relevance_threshold": min_relevance,
        "rss": [u for u, _ in RSS_FEEDS],
    }
    meta_json = {
        "usage": llm_resp.get("usage", {}),
        "usd_est": float(llm_resp.get("usd_est", 0.0)),
        "notes": "LLM macro/crypto sentiment now/7d/30d from weighted RSS context",
        "engine": "macro_v2",
        "llm": {"provider": provider, "model": model_id},
    }

    row = (
        asof_dmy,                             # asof_utc stored as DD/MM/YYYY
        sentence,
        float(result["score_now"]),
        float(result["score_7d"]),
        float(result["score_30d"]),
        provider,
        model_id,
        json.dumps(features_json, ensure_ascii=False),
        json.dumps(meta_json, ensure_ascii=False),
    )

    try:
        conn = sqlite3.connect(str(MARKET_DATA_DB), timeout=30)
        cur = conn.cursor()
        cur.execute("PRAGMA journal_mode=WAL;")
        cur.execute("""
            CREATE TABLE IF NOT EXISTS macro_daily (
                asof_utc        TEXT NOT NULL,
                sentence        TEXT NOT NULL,
                score_now       REAL NOT NULL,
                score_7d        REAL NOT NULL,
                score_30d       REAL NOT NULL,
                model_provider  TEXT,
                model_id        TEXT,
                features_json   TEXT,
                meta_json       TEXT
            )
        """)
        cur.execute("CREATE INDEX IF NOT EXISTS idx_macro_daily_asof ON macro_daily(asof_utc);")
        conn.commit()

        if SAVE_MODE == "skip":
            # Insert only if no row exists for this date
            cur.execute("""
                INSERT INTO macro_daily(asof_utc, sentence, score_now, score_7d, score_30d,
                                        model_provider, model_id, features_json, meta_json)
                SELECT ?,?,?,?,?,?,?,?,?
                WHERE NOT EXISTS (
                    SELECT 1 FROM macro_daily WHERE asof_utc = ?
                )
            """, (*row, asof_dmy))
        else:
            # OVERRIDE: delete any existing rows for this date (including duplicates), then insert the new one
            cur.execute("BEGIN IMMEDIATE;")
            cur.execute("DELETE FROM macro_daily WHERE asof_utc = ?;", (asof_dmy,))
            cur.execute("""
                INSERT INTO macro_daily(asof_utc, sentence, score_now, score_7d, score_30d,
                                        model_provider, model_id, features_json, meta_json)
                VALUES (?,?,?,?,?,?,?,?,?)
            """, row)
            conn.commit()

        logging.info("Saved macro_daily[%s]: now=%.4f 7d=%.4f 30d=%.4f (mode=%s)",
                     asof_dmy, row[2], row[3], row[4], SAVE_MODE)

    except Exception as e:
        logging.warning("Failed to save macro_daily to DB (%s)", e)
    finally:
        try:
            conn.close()
        except Exception:
            pass


    if not return_details:
        return result

    # by-source summary for debugging/monitoring
    by_source = (
        context_df.groupby("source")
                  .agg(n=("source","count"),
                       avg_w=("weight","mean"),
                       avg_rel=("relevance","mean"))
                  .round(4)
                  .sort_values("n", ascending=False)
                  .to_dict(orient="index")
    )
    details = {
        "scores": result,
        "asof_utc": asof_dmy,
        "provider": provider,
        "model_id": model_id,
        "n_articles": int(len(df)),
        "n_used": int(len(context_df)),
        "by_source": by_source,
        "examples": context_df[["source","title","relevance","weight","published"]].head(8).to_dict(orient="records"),
    }
    return result, details

import os
import json
import time
import requests
from dotenv import load_dotenv


OPENAI_API_BASE = "https://api.openai.com/v1/chat/completions"
SUPPORTED_MODELS = {"gpt-5", "gpt-5-mini"}


# 🧠 X Sentiment Agent Prompt

# Inputs (from caller):
# BTC_PRICE_USD = 123,456.78
# PRICE_TS_UTC = "2025-10-14 12:34:56"

# Role & Scope:
# You are an advanced financial sentiment analysis agent focused exclusively on X (Twitter) content.
# Your job is to analyze recent posts about Bitcoin (BTC) and BTC options and infer the crowd’s sentiment
# across three time horizons. You must NOT use or infer from any other sources
# (no price APIs, news sites, blogs, Reddit, or data feeds).

# Task:
# 1. Gather and interpret the most recent (past 12–24 hours) X posts that mention:
#    - Bitcoin price movement, momentum, or volatility
#    - BTC options (IV, skew, open interest, large trades)
#    - Funding rates, basis changes, or liquidations
# 2. Infer sentiment strength and direction using only what is explicitly written in these posts.
#    - Prefer credible accounts (analysts, traders, exchanges, data providers).
#    - Deduplicate reposts and translate non-English text neutrally.
# 3. Estimate crowd bias toward BTC price movement for:
#    - Now (current) sentiment
#    - Next 7 days (weekly) sentiment
#    - Next 30 days (monthly) sentiment
# 4. Support reasoning with specific observations (e.g., “IV up 3%”, “funding +0.02%”, “trader consensus bullish”).
# 5. Do not invent metrics. If data is missing, indicate uncertainty clearly but still provide a balanced estimate.

# Output Format (STRICT):
# Return only one short paragraph followed by three sentiment scores.

# Structure:
# Sentence:
# A concise summary (≤80 words) describing how BTC sentiment on X appears right now and how it’s evolving
# across 7-day and 30-day horizons, with at least one concrete datapoint from posts (IV, skew, funding, levels, or open interest).

# Scores:
# - Score_Now: <float between -1 and 1> (instant sentiment)
# - Score_7D: <float between -1 and 1> (next-week sentiment)
# - Score_30D: <float between -1 and 1> (next-month sentiment)

# Formatting Rules:
# - No hashtags, URLs, or emojis
# - Neutral, factual tone
# - One paragraph + three scores on new lines
# - No extra commentary or JSON formatting



from datetime import datetime, timezone

def build_x_sentiment_prompt(btc_price_usd: float) -> str:
    """
    Return the X Sentiment Agent prompt text, inserting:
      - BTC_PRICE_USD from the function argument (formatted with commas, 2 decimals)
      - PRICE_TS_UTC as the current UTC timestamp "YYYY-MM-DD HH:MM:SS"
    """
    price_str = f"{btc_price_usd:,.2f}"
    ts_utc = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")

    prompt = f"""🧠 X Sentiment Agent Prompt

Inputs (from caller):
BTC_PRICE_USD = {price_str}
PRICE_TS_UTC = "{ts_utc}"

Role & Scope:
You are an advanced financial sentiment analysis agent focused exclusively on X (Twitter) content.
Your job is to analyze recent posts about Bitcoin (BTC) and BTC options and infer the crowd’s sentiment
across three time horizons. You must NOT use or infer from any other sources
(no price APIs, news sites, blogs, Reddit, or data feeds).

Task:
1. Gather and interpret the most recent (past 12–24 hours) X posts that mention:
   - Bitcoin price movement, momentum, or volatility
   - BTC options (IV, skew, open interest, large trades)
   - Funding rates, basis changes, or liquidations
2. Infer sentiment strength and direction using only what is explicitly written in these posts.
   - Prefer credible accounts (analysts, traders, exchanges, data providers).
   - Deduplicate reposts and translate non-English text neutrally.
3. Estimate crowd bias toward BTC price movement for:
   - Now (current) sentiment
   - Next 7 days (weekly) sentiment
   - Next 30 days (monthly) sentiment
4. Support reasoning with specific observations (e.g., “IV up 3%”, “funding +0.02%”, “trader consensus bullish”).
5. Do not invent metrics. If data is missing, indicate uncertainty clearly but still provide a balanced estimate.

Output Format (STRICT):
Return only one short paragraph followed by three sentiment scores.

Structure:
Sentence:
A concise summary (≤80 words) describing how BTC sentiment on X appears right now and how it’s evolving
across 7-day and 30-day horizons, with at least one concrete datapoint from posts (IV, skew, funding, levels, or open interest).

Scores:
- Score_Now: <float between -1 and 1> (instant sentiment)
- Score_7D: <float between -1 and 1> (next-week sentiment)
- Score_30D: <float between -1 and 1> (next-month sentiment)

Formatting Rules:
- No hashtags, URLs, or emojis
- Neutral, factual tone
- One paragraph + three scores on new lines
- No extra commentary or JSON formatting
"""
    return prompt

# Example:
# print(build_x_sentiment_prompt(123456.78))
if __name__ == "__main__":
    print(build_x_sentiment_prompt(123456.78))


