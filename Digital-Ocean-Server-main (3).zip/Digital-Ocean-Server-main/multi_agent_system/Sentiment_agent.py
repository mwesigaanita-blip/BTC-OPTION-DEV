# Sentiment_agent.py
# Python 3.11+

from __future__ import annotations

# ── Stdlib
import os
import json
import math
import time
import re
from typing import Callable, Dict, Any, List, Tuple, Literal, Optional, TypedDict
from datetime import datetime, timedelta, timezone
from pathlib import Path
import logging
from .sentiment import *
from .config import *
from dotenv import load_dotenv
load_dotenv(os.path.join(DEPLOYMENT_ROOT, ".env"))
from .llm_io import *

# ── Networking
import requests  # Deribit public REST

# ── Local minimal Agent types (since you don't have agents.types)
Bias = Literal["bullish", "bearish", "neutral"]

class AgentOutput(TypedDict, total=False):
    agent: Literal["sentiment"]
    bias: Bias
    confidence: float
    horizon_days: int
    rationale: str
    key_signals: List[str]
    red_flags: List[Dict[str, Any]]
    recommendations: List[Dict[str, Any]]
    metrics: Dict[str, float]

# ── Logging / constants
LOGGER = logging.getLogger("SentimentAgent")
logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

DERIBIT_API = "https://www.deribit.com/api/v2"
REQUEST_TIMEOUT = 12

def _persist_oi(oi_now: float | None, store: Path = Path(".sentiment_cache/oi_btc.json")) -> float | None:
    try:
        store.parent.mkdir(parents=True, exist_ok=True)
        prev = None
        if store.exists():
            with store.open("r", encoding="utf-8") as f:
                prev = json.load(f).get("oi_now")
        if oi_now is not None:
            with store.open("w", encoding="utf-8") as f:
                json.dump({"ts": datetime.now(timezone.utc).isoformat(), "oi_now": oi_now}, f)
        return prev
    except Exception:
        return None

# --- Deribit REST helper ---
def _deribit_get(method: str, params: Dict[str, Any]) -> Dict[str, Any] | None:
    url = f"{DERIBIT_API}{method}"
    for attempt in range(3):
        try:
            r = requests.get(url, params=params, timeout=REQUEST_TIMEOUT)
            r.raise_for_status()
            js = r.json()
            return js.get("result")
        except Exception as e:
            LOGGER.warning(f"Deribit GET {method} failed (try {attempt+1}/3): {e}")
            time.sleep(0.5 * (attempt + 1))
    return None

def fetch_funding_rate_btc() -> float | None:
    res = _deribit_get("/public/get_funding_rate_history", {
        "instrument_name": "BTC-PERPETUAL",
        "start_timestamp": int((datetime.now(timezone.utc) - timedelta(days=2)).timestamp() * 1000),
        "end_timestamp":   int(datetime.now(timezone.utc).timestamp() * 1000),
        "count": 200,
        "include_old": True,
    })
    if isinstance(res, list) and res:
        last = res[-1]
        for k in ("funding_8h", "interest_8h", "funding_rate"):
            if last.get(k) is not None:
                try:
                    return float(last[k])
                except Exception:
                    pass

    # Valid fallback
    res2 = _deribit_get("/public/get_funding_rate_value", {
        "instrument_name": "BTC-PERPETUAL",
        "start_timestamp": int((datetime.now(timezone.utc) - timedelta(hours=9)).timestamp() * 1000),
        "end_timestamp":   int(datetime.now(timezone.utc).timestamp() * 1000),
    })
    if isinstance(res2, (int, float)):
        return float(res2)

    return None

# --- Options OI summary (BTC) and crude 24h delta ---
def fetch_options_oi_summary_btc() -> Dict[str, float | None]:
    cur = _deribit_get("/public/get_book_summary_by_currency", {"currency": "BTC", "kind": "option"})
    def _sum_oi(rows):
        try:
            return float(sum((row.get("open_interest") or 0.0) for row in rows))
        except Exception:
            return None
    oi_now = _sum_oi(cur) if isinstance(cur, list) else None

    # Persist and compute 24h-ish delta across runs
    oi_prev = _persist_oi(oi_now)
    oi_delta = (oi_now - oi_prev) if (oi_now is not None and oi_prev is not None) else None
    return {"oi_now": oi_now, "oi_24h_delta": oi_delta}

# --- Optional: Fear & Greed Index (alternative.me) ---
def fetch_fear_greed() -> Dict[str, Any] | None:
    try:
        r = requests.get("https://api.alternative.me/fng/?limit=1&format=json", timeout=REQUEST_TIMEOUT)
        r.raise_for_status()
        data = r.json().get("data", [])
        if not data:
            return None
        item = data[0]
        return {"value": int(item.get("value")), "classification": item.get("value_classification")}
    except Exception as e:
        LOGGER.warning(f"Fear&Greed fetch failed: {e}")
        return None

# --- Aggregate inputs for Sentiment Agent ---
def pull_sentiment_inputs(
    x_score_now: float | None,
    x_score_7d: float | None,
    x_score_30d: float | None,
    x_sentence: str | None
) -> Dict[str, Any]:
    fr   = fetch_funding_rate_btc()
    ois  = fetch_options_oi_summary_btc()
    fng  = fetch_fear_greed()
    return {
        "asof_utc": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "funding_rate_8h": fr,
        "open_interest": ois,
        "x_sentiment": {
            "x_score_now": x_score_now,
            "x_score_7d":  x_score_7d,
            "x_score_30d": x_score_30d,
            "x_sentence": (x_sentence or "")
        },
        "fear_greed": fng,
        "sources": ["Deribit public", "alternative.me (optional)", "X (provided)"],
    }

def check_requirements(data: Dict[str, Any]) -> Dict[str, List[str]]:
    missing = []
    xs = (data.get("x_sentiment") or {})
    has_any_x = any(xs.get(k) is not None for k in ("x_score_now", "x_score_7d", "x_score_30d"))
    if data.get("funding_rate_8h") is None and not has_any_x:
        missing.append("funding_rate_8h_or_any_x_score")
    optional_missing = []
    if not data.get("open_interest"):
        optional_missing.append("open_interest")
    return {"missing": missing, "optional_missing": optional_missing}

def normalize_inputs(raw: Dict[str, Any]) -> Dict[str, Any]:
    fr  = raw.get("funding_rate_8h")
    ois = raw.get("open_interest") or {}
    xs  = raw.get("x_sentiment") or {}
    fng = raw.get("fear_greed") or None

    funding_bps = None if fr is None else round(float(fr) * 10_000, 3)
    funding_deadband = None if funding_bps is None else (abs(funding_bps) <= 1.5)

    return {
        "asof_utc": raw.get("asof_utc"),
        "funding_bps_8h": funding_bps,
        "funding_deadband": funding_deadband,
        "oi_now": ois.get("oi_now"),
        "oi_24h_delta": ois.get("oi_24h_delta"),
        "x_score_now":  xs.get("x_score_now"),
        "x_score_7d":   xs.get("x_score_7d"),
        "x_score_30d":  xs.get("x_score_30d"),
        "x_sentence":  (xs.get("x_sentence") or "")[:240],
        "fear_greed": fng,
        "sources": raw.get("sources", []),
    }

Bias = Literal["bullish","bearish","neutral"]

def sentiment_to_bias_conf(n: Dict[str, Any]) -> Tuple[Bias, float, List[str]]:
    signals = []
    score = 0.0

    # Funding: +bullish if positive & non-trivial
    if n["funding_bps_8h"] is not None:
        fbps = float(n["funding_bps_8h"])
        if fbps > 1.5:  # >0.015% per 8h
            score += 0.4; signals.append("funding_pos")
        elif fbps < -1.5:
            score -= 0.4; signals.append("funding_neg")

    # OI delta: rising OI → trend continuation (weak), falling → risk-off
    if n["oi_24h_delta"] is not None and isinstance(n["oi_24h_delta"], (int,float)):
        if n["oi_24h_delta"] > 0:
            score += 0.2; signals.append("oi_up")
        elif n["oi_24h_delta"] < 0:
            score -= 0.2; signals.append("oi_down")

    # X score (your external sentiment)
    if n["x_score"] is not None:
        xs = float(n["x_score"])
        if xs > 0.15: score += 0.25; signals.append("x_pos")
        elif xs < -0.15: score -= 0.25; signals.append("x_neg")

    # Fear&Greed (optional, mild)
    fg = n.get("fear_greed") or {}
    if fg.get("value") is not None:
        v = int(fg["value"])
        if v >= 70: score += 0.05; signals.append("fg_greedy")
        elif v <= 30: score -= 0.05; signals.append("fg_fear")

    # Map score → bias/conf
    if score >= 0.25:
        bias: Bias = "bullish"; conf = 0.45 + min(0.45, score)  # cap
    elif score <= -0.25:
        bias = "bearish"; conf = 0.45 + min(0.45, -score)
    else:
        bias = "neutral"; conf = 0.35 + 0.3 * (abs(score) / 0.25)

    return bias, round(min(conf, 0.9), 3), signals or ["sparse_signals"]

AGENT_SCHEMA_JSON = """
{
  "agent": "sentiment",
  "bias": "bullish|bearish|neutral",
  "confidence": 0.0,
  "horizon_days": 10,
  "rationale": "≤300 words, plain English",
  "key_signals": ["short tags"],
  "red_flags": [{"code":"LOW_DATA|DATA_GAP|CONFLICTING_SIGNALS","severity":"hard|soft","note":"short"}],
  "recommendations": [],
  "metrics": {"pop_est": 0.70}
}
""".strip()

def build_llm_prompt(norm: Dict[str, Any], ta_summary: str) -> str:
    SCHEMA = (
        '{\n'
        '  "agent": "fundamental",\n'
        '  "bias": "bullish|bearish|neutral",\n'
        '  "confidence": 0.0,\n'
        '  "horizon_days": 5,\n'
        '  "rationale": "≤300 words",\n'
        '  "key_signals": ["short tags"],\n'
        '  "red_flags": [{"code":"LOW_DATA","severity":"soft","note":"short"}],\n'
        '  "recommendations": [],\n'
        '  "metrics": {"pop_est": 0.70}\n'
        '}'
    )
    RULES = (
        "Decision rules (must follow):\n"
        "- Map macro_now ∈ [-1,1] to bias:\n"
        "  • score ≥ +0.15 ⇒ bullish\n"
        "  • score ≤ -0.15 ⇒ bearish\n"
        "  • otherwise ⇒ neutral\n"
        "- Use macro_7D and macro_30D as trend confirmers:\n"
        "  • If macro_now ∈ [-0.15, +0.15] but macro_7D and macro_30D share the SAME sign and |value| ≥ 0.10,\n"
        "    set bias to that sign (bullish if both ≥ +0.10, bearish if both ≤ -0.10).\n"
        "  • If all three (now, 7D, 30D) share the SAME sign, add +0.10 to confidence (cap at 0.95).\n"
        "  • If they DISAGREE in sign, subtract 0.10 from confidence (floor at 0.05) and add red_flag "
        '{"code":"CONFLICTING_SIGNALS","severity":"soft","note":"macro windows disagree"}.\n'
        "- horizon_days MUST be 15.\n"
        "- Return ONLY JSON per schema."
    )
    return (
        "You are the BTC Fundamental Agent. Return ONLY valid JSON per schema.\n\n"
        f"Schema:\n{SCHEMA}\n\n"
        f"{RULES}\n\n"
        "Inputs:\n"
        "- macro_now (-1..1)\n"
        "- macro_7D (-1..1)\n"
        "- macro_30D (-1..1)\n"
        "- headlines (0..5)\n"
        "- on_chain: hash_rate_ehs, tx_volume_usd, active_addresses\n"
        "- supply: circulating_btc, days_to_halving\n\n"
        "Technical analysis summary (TA):\n"
        f"{ta_summary}\n\n"
        f"Data (normalized fundamentals):\n{norm}"
    )

def validate_agent_output(js: Dict[str, Any]) -> Tuple[bool, List[str]]:
    errs: List[str] = []
    if js.get("agent") != "sentiment": errs.append("agent must be 'sentiment'")
    if js.get("bias") not in ("bullish","bearish","neutral"): errs.append("invalid bias")
    try:
        c = float(js.get("confidence", -1))
        if not (0.0 <= c <= 1.0): errs.append("confidence out of range")
    except Exception:
        errs.append("confidence not float")
    if not isinstance(js.get("horizon_days", 0), int): errs.append("horizon_days must be int")
    if not isinstance(js.get("key_signals", []), list): errs.append("key_signals must be list")
    if not isinstance(js.get("red_flags", []), list): errs.append("red_flags must be list")
    if "metrics" not in js: errs.append("metrics missing")
    return (len(errs) == 0, errs)

def run_sentiment_agent(
    raw_inputs: Dict[str, Any],
    use_llm: bool,
    client=None,
    temperature: float = 0.0,
    max_tokens: int = 1500,
    provider: str = "openai",
    model: str = "gpt-5-mini",
    verbose: bool = False,
    ta_summary: str | None = None,
    **client_kwargs,
) -> Tuple[Dict[str, Any], float]:
    """
    Returns (result_dict, cost_usd).
    On failure, returns a safe baseline and cost=0.0.
    Accepts 'verbose' and forwards any extra **client_kwargs to the llm client.
    """
    cost: float = 0.0
    baseline = {
        "summary": "Sentiment fallback due to LLM error",
        "score": 0.0,
        "red_flags": [],
        "horizon_days": 10,
    }

    try:
        if not use_llm:
            return baseline, cost

        # Build client if not provided
        if client is None:
            client = make_llm_client(provider=provider, model=model)

        # Prepare prompt (normalize if you have a helper; otherwise use raw_inputs)
        norm = normalize_inputs(raw_inputs)
        prompt = build_llm_prompt(norm, ta_summary or "Technical summary not available.")


        # Call LLM; GPT-5 path ignores temperature inside payload (handled in make_llm_client)
        resp = client(
            prompt,
            temperature=temperature,
            max_tokens=max_tokens,
            retries=3,
            request_timeout=300,
            verbose=verbose,
            **client_kwargs,
        )

        # Cost (if present)
        try:
            cost = float(resp.get("usd_est", 0.0))
        except Exception:
            cost = 0.0

        parsed = json.loads(resp["json_str"])
        parsed["horizon_days"] = 10
        return parsed, cost

    except Exception as e:
        baseline["red_flags"].append({
            "code": "LLM_ERROR",
            "severity": "MEDIUM",
            "detail": str(e),
        })
        return baseline, cost

def run_sentiment(
    model: str,
    temperature: float,
    max_tokens: int,
    x_score_now: float | None,
    x_score_7D: float | None,
    x_score_30D: float | None,
    x_sentence: str | None,
    use_llm: bool = True,
    provider: str = "openai",
    ta_summary: str | None = None,
) -> Dict[str, Any]:
    raw = pull_sentiment_inputs(
        x_score_now=x_score_now,
        x_score_7d=x_score_7D,
        x_score_30d=x_score_30D,
        x_sentence=x_sentence,
    )
    client = make_llm_client(provider=provider, model=model) if use_llm else None

    result , cost = run_sentiment_agent(
        raw_inputs=raw,
        use_llm=use_llm,
        client=client,
        provider=provider,
        model=model,
        temperature=temperature,
        max_tokens=max_tokens,
        verbose=True,
        ta_summary=ta_summary,
    )

    # Save under sentiment_runs/<model>_<UTC timestamp>/
    ts = datetime.now(timezone.utc).strftime("%Y-%m-%d_%H-%M-%S")
    out_dir = Path("sentiment_runs") / f"{model}_{ts}"
    out_dir.mkdir(parents=True, exist_ok=True)
    with (out_dir / "inputs.json").open("w", encoding="utf-8") as f:
        json.dump(raw, f, ensure_ascii=False, indent=2)
    with (out_dir / "sentiment_decision.json").open("w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)
    print(f"[Saved] {out_dir.as_posix()}/sentiment_decision.json")
    return result , cost



