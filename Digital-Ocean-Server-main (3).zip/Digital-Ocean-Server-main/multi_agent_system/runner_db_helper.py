# multi_agent_system/db_runner_helper.py
from __future__ import annotations

import json
import logging
import sqlite3
import traceback
from datetime import datetime
from typing import Any, Dict, Optional

import pandas as pd

from .config import get_strategy_text
from shared.db_paths import MODELS_DB

DB_PATH = MODELS_DB  # backward-compat alias for any external importer

log = logging.getLogger("db_runner_helper")
print(f"[DB] Using {MODELS_DB} in {__file__}", flush=True)

X_TABLE = "x_score"                         # existing
STRATEGY_TABLE = "strategy_text_store"      # new
RUN_META_TABLE = "model_run_meta"           # new


def _con() -> sqlite3.Connection:
    # check_same_thread=False helps if called from background threads
    return sqlite3.connect(str(MODELS_DB), timeout=30, check_same_thread=False)


# ---------- X score helpers ----------
def get_today_x() -> Optional[dict[str, Any]]:
    today = datetime.utcnow().date().isoformat()
    with _con() as con:
        cur = con.cursor()
        cur.execute(
            f"""
            SELECT score_now, score_7d, score_30d, x_sentiment_sentence
            FROM {X_TABLE}
            WHERE date=?
            """,
            (today,),
        )
        row = cur.fetchone()

    if not row:
        return None

    score_now, score_7d, score_30d, sentence = row
    return {
        "sentence": sentence or "",
        "score_now": None if score_now is None else float(score_now),
        "score_7d": None if score_7d is None else float(score_7d),
        "score_30d": None if score_30d is None else float(score_30d),
        "date_utc": today,
    }

def get_latest_x() -> Optional[dict[str, Any]]:
    with _con() as con:
        cur = con.cursor()
        cur.execute(
            f"""
            SELECT date, score_now, score_7d, score_30d, x_sentiment_sentence
            FROM {X_TABLE}
            ORDER BY date DESC
            LIMIT 1
            """
        )
        row = cur.fetchone()

    if not row:
        return None

    date_utc, score_now, score_7d, score_30d, sentence = row
    return {
        "sentence": sentence or "",
        "score_now": None if score_now is None else float(score_now),
        "score_7d": None if score_7d is None else float(score_7d),
        "score_30d": None if score_30d is None else float(score_30d),
        "date_utc": str(date_utc),
    }

def get_x_for_run() -> tuple[dict[str, Any], str | None]:
    """
    Returns (x_scores_dict, warning_str_or_None)
    """
    today = datetime.utcnow().date().isoformat()
    x_today = get_today_x()
    if x_today:
        return x_today, None

    x_latest = get_latest_x()
    if x_latest:
        warn = f"No X score for today – using last available score (date: {x_latest.get('date_utc')})"
        return x_latest, warn

    # Nothing exists at all: safe neutral fallback
    warn = "No X score exists in DB – proceeding with neutral sentiment (0.0) and empty sentence."
    return {
        "sentence": "",
        "score_now": 0.0,
        "score_7d": 0.0,
        "score_30d": 0.0,
        "date_utc": today,
    }, warn

# ---------- Strategy text store ----------
def ensure_aux_tables() -> None:
    with _con() as con:
        cur = con.cursor()
        cur.execute(f"""
            CREATE TABLE IF NOT EXISTS {STRATEGY_TABLE}(
                key TEXT PRIMARY KEY,
                text TEXT NOT NULL,
                updated_at TEXT NOT NULL
            )
        """)
        cur.execute(f"""
            CREATE TABLE IF NOT EXISTS {RUN_META_TABLE}(
                id INTEGER PRIMARY KEY,
                model_label TEXT NOT NULL,
                provider TEXT NOT NULL,
                model_id TEXT NOT NULL,
                run_time_utc TEXT NOT NULL,
                run_time_cairo TEXT NOT NULL,
                total_cost_usd REAL NOT NULL,
                created_at TEXT NOT NULL
            )
        """)
        con.commit()


def seed_default_strategy_if_missing() -> None:
    ensure_aux_tables()
    default_txt = get_strategy_text() or (
        "SELL premium with risk-aware rules; prioritize PoP, IVR, DTE, and tight spreads. "
        "Close to realize gains once ≥60% of entry credit is captured (net of fees); respect SL and close rules."
    )
    with _con() as con:
        cur = con.cursor()
        cur.execute(f"SELECT text FROM {STRATEGY_TABLE} WHERE key='default'")
        if not cur.fetchone():
            cur.execute(
                f"INSERT OR REPLACE INTO {STRATEGY_TABLE}(key, text, updated_at) VALUES(?,?,?)",
                ("default", default_txt, datetime.utcnow().isoformat()),
            )
        cur.execute(f"SELECT text FROM {STRATEGY_TABLE} WHERE key='active'")
        if not cur.fetchone():
            cur.execute(
                f"INSERT OR REPLACE INTO {STRATEGY_TABLE}(key, text, updated_at) VALUES(?,?,?)",
                ("active", default_txt, datetime.utcnow().isoformat()),
            )
        con.commit()


def get_strategy_pair() -> tuple[str, str]:
    seed_default_strategy_if_missing()
    with _con() as con:
        cur = con.cursor()
        cur.execute(f"SELECT text FROM {STRATEGY_TABLE} WHERE key='active'")
        active = (cur.fetchone() or [""])[0]
        cur.execute(f"SELECT text FROM {STRATEGY_TABLE} WHERE key='default'")
        default = (cur.fetchone() or [""])[0]
        return active, default


# ---------- Forecast helpers ----------
def extract_llm_range_features(
    forecast: dict,
    include_abs: bool = True,
    round_pct: int = 2,
    round_price: int = 2
) -> dict:
    import numpy as np

    if not forecast or "horizons" not in forecast:
        return {}

    order = ["5d", "10d", "21d", "42d", "63d"]
    out = {
        "as_of": forecast.get("as_of"),
        "close": round(float(forecast.get("close", np.nan)), round_price),
        "bands_pct": {},
        "m_used": {},
    }
    if include_abs:
        out["bands_abs"] = {}

    for h in order:
        rec = forecast["horizons"].get(h)
        if not rec:
            continue
        up = float(rec.get("up_pct", 0.0))
        dn = float(rec.get("down_pct", 0.0))
        out["bands_pct"][h] = {"up": round(up, round_pct), "down": round(dn, round_pct)}
        out["m_used"][h] = round(float(rec.get("m_used", 1.0)), 3)
        if include_abs:
            out["bands_abs"][h] = {
                "upper": round(float(rec.get("upper", np.nan)), round_price),
                "lower": round(float(rec.get("lower", np.nan)), round_price),
            }
    return out


def build_llm_range_message(forecast: dict) -> str:
    """
    Final LLM-friendly forecast line:
    - Price bands in absolute levels (no % math)
    - Explicit Signal label (RSI/Stoch extremes)  ✅ matches task:
        * RSI > 70 AND StochK > 90  -> bearish risk
        * RSI < 30 AND StochK < 10  -> bullish reversal risk
    - Momentum label (Weak / Neutral / Strong) (kept, but separate from task-signal)
    - Band skew label (Upside / Downside / Balanced)
    - Position cue within 5d band (Near lower / Mid / Near upper)
    - Monotonic-widening display bands (presentation only)
    """
    if not isinstance(forecast, dict):
        return ""

    as_of = forecast.get("as_of")
    close = forecast.get("close")
    horizons = forecast.get("horizons") or {}
    ind = forecast.get("indicators") or {}

    if as_of is None or close is None or not horizons:
        return ""

    def _fmt_price(x) -> str:
        try:
            return f"{float(x):,.0f}"
        except Exception:
            return "N/A"

    # -----------------------
    # RSI / Stoch Full Signal Classification
    # -----------------------
    rsi_raw = ind.get("rsi_14")
    k_raw = ind.get("stoch_k_14")

    rsi_f = None
    k_f = None

    try:
        rsi_f = float(rsi_raw) if rsi_raw is not None else None
        k_f = float(k_raw) if k_raw is not None else None
    except (TypeError, ValueError):
        rsi_f = None
        k_f = None

    signal = "Signal: Normal"

    if rsi_f is not None and k_f is not None:

        # ---- Extreme Overbought (strong bearish risk) ----
        if rsi_f > 70.0 and k_f > 90.0:
            signal = "Signal: Extreme Overbought (strong bearish risk)"

        # ---- Extreme Oversold (strong bullish reversal risk) ----
        elif rsi_f < 30.0 and k_f < 10.0:
            signal = "Signal: Extreme Oversold (strong bullish reversal risk)"

        # ---- Moderate Overbought ----
        elif rsi_f > 70.0 and k_f > 70.0:
            signal = "Signal: Overbought (bearish bias)"

        # ---- Moderate Oversold ----
        elif rsi_f < 30.0 and k_f < 30.0:
            signal = "Signal: Oversold (bullish bias)"

        # ---- RSI Only Overbought ----
        elif rsi_f > 70.0:
            signal = "Signal: RSI Overbought (no Stoch confirmation)"

        # ---- Stoch Only Extreme Overbought ----
        elif k_f > 90.0:
            signal = "Signal: Stoch Extreme Overbought (no RSI confirmation)"

        # ---- RSI Only Oversold ----
        elif rsi_f < 30.0:
            signal = "Signal: RSI Oversold (no Stoch confirmation)"

        # ---- Stoch Only Extreme Oversold ----
        elif k_f < 10.0:
            signal = "Signal: Stoch Extreme Oversold (no RSI confirmation)"

        # ---- Mid-zone classification (optional but complete) ----
        elif 45.0 <= rsi_f <= 55.0 and 40.0 <= k_f <= 60.0:
            signal = "Signal: Neutral (balanced momentum)"

        else:
            signal = "Signal: Normal"


    # -----------------------
    # Momentum label (optional, separate from task)
    # -----------------------
    momentum = "Momentum: Neutral"
    if rsi_f is not None and k_f is not None:
        if rsi_f <= 45.0 and k_f <= 35.0:
            momentum = "Momentum: Weak"
        elif rsi_f >= 55.0 and k_f >= 65.0:
            momentum = "Momentum: Strong"

    # -----------------------
    # Monotonic-widening display bands
    # -----------------------
    ordered = ["5d", "10d", "21d", "42d", "63d"]
    disp = {}
    prev_lower = None
    prev_upper = None

    for h in ordered:
        d = horizons.get(h) or {}
        l = d.get("lower")
        u = d.get("upper")
        if l is None or u is None:
            continue

        try:
            l = float(l)
            u = float(u)
        except Exception:
            continue

        if prev_lower is not None:
            l = min(l, prev_lower)
        if prev_upper is not None:
            u = max(u, prev_upper)

        disp[h] = {"lower": l, "upper": u}
        prev_lower, prev_upper = l, u

    parts = []
    for h in ordered:
        d = disp.get(h)
        if not d:
            continue
        parts.append(f"{h} [{_fmt_price(d['lower'])} … {_fmt_price(d['upper'])}]")

    if not parts:
        return ""

    # -----------------------
    # Band skew (uses ORIGINAL bands, not clamped)
    # -----------------------
    bias = "Bands: Unknown"
    try:
        close_f = float(close)
        ups, dns = [], []
        for h in ordered:
            d = horizons.get(h) or {}
            u = d.get("upper")
            l = d.get("lower")
            if u is None or l is None:
                continue
            ups.append(float(u) - close_f)
            dns.append(close_f - float(l))

        if ups and dns:
            skew = (sum(ups) / len(ups)) - (sum(dns) / len(dns))
            if skew > 0:
                bias = "Bands: Upside-skew"
            elif skew < 0:
                bias = "Bands: Downside-skew"
            else:
                bias = "Bands: Balanced"
    except Exception:
        pass

    # -----------------------
    # Position within 5d band
    # -----------------------
    position = "Position: Unknown"
    try:
        close_f = float(close)
        d5 = disp.get("5d")
        if d5:
            l5 = d5["lower"]
            u5 = d5["upper"]
            if u5 > l5:
                pos = (close_f - l5) / (u5 - l5)
                if pos <= 0.2:
                    position = "Position: Near 5d lower"
                elif pos >= 0.8:
                    position = "Position: Near 5d upper"
                else:
                    position = "Position: Mid-range"
    except Exception:
        pass

    # -----------------------
    # Numeric indicator snapshot
    # -----------------------
    ind_txt = ""
    if rsi_f is not None and k_f is not None:
        ind_txt = f" | RSI14={rsi_f:.1f}, StochK14={k_f:.1f}"

    return (
        f"As of {as_of} close {_fmt_price(close)} | "
        f"{signal} | {momentum} | {bias} | {position} | "
        + "; ".join(parts)
        + ind_txt
    )


def build_forecast_line_safe(db_path: str = "") -> str:
    """
    Refresh yesterday candle (best effort), load history, run btc_range_forecast,
    and return a concise message. Returns "" on benign failure.

    The ``db_path`` parameter is retained for backward compatibility but
    is ignored: BTC OHLCV data lives in ``MARKET_DATA_DB`` and the
    helper functions resolve it themselves.
    """
    from .btc_ohlcv import _make_retry_session, upsert_btc_yday_from_deribit, load_btc_history_df
    from .stage_1 import btc_range_forecast
    from shared.db_paths import MARKET_DATA_DB

    market_db = str(MARKET_DATA_DB)

    try:
        sess = _make_retry_session(total=8, backoff_factor=0.8)
        upsert_btc_yday_from_deribit(db_path=market_db, session=sess)
    except Exception as e:
        log.warning("Deribit upsert failed (continuing with existing DB): %s", e)

    try:
        df_hist = load_btc_history_df(db_path=market_db)
    except Exception as e:
        log.exception("Failed to load btc history from DB: %s", e)
        return ""

    if df_hist is None or df_hist.empty:
        log.warning("BTC history is empty; cannot build forecast.")
        return ""

    required_cols = {"date", "open", "high", "low", "close", "volume"}
    missing = required_cols - set(df_hist.columns)
    if missing:
        log.warning("BTC history missing columns: %s", ", ".join(sorted(missing)))
        return ""

    try:
        df_hist = df_hist.dropna(subset=["open", "high", "low", "close"]).copy()
        try:
            df_hist["date"] = pd.to_datetime(df_hist["date"], errors="coerce", utc=True)
            df_hist = df_hist.sort_values("date")
        except Exception:
            pass

        forecast_obj = btc_range_forecast(daily_ohlc=df_hist)
        forecast_line = build_llm_range_message(forecast_obj)

        if not isinstance(forecast_line, str) or not forecast_line.strip():
            log.warning("Forecast returned empty message.")
            return ""

        log.info("Forecast: %s", forecast_line)
        return forecast_line.strip()

    except ModuleNotFoundError as e:
        log.warning("Forecast utilities not found: %s", e)
        return ""
    except Exception as e:
        log.error("Forecast failed: %s", e)
        log.debug("Traceback:\n%s", traceback.format_exc())
        return ""


# ---------- Run results persistence ----------
def get_results_table_name(model_label: str) -> str:
    clean = (
        model_label.lower()
        .replace(" ", "_")
        .replace("-", "_")
        .replace("(", "")
        .replace(")", "")
        .replace(".", "")
        .replace("mini_(test)", "mini_test")
        .replace("mini_(test)", "mini_test")
        .replace("mini_(test)", "mini_test")
    )
    clean = clean.replace("mini_(test)", "mini_test").replace("mini_(test)", "mini_test")
    clean = clean.replace("mini_(test)", "mini_test")
    clean = clean.replace("mini_(test)", "mini_test")
    clean = clean.replace("mini_(test)", "mini_test")
    clean = clean.replace("mini_(test)", "mini_test")
    clean = clean.replace("mini (test)", "mini_test")
    return f"{clean}_run_results"


def ensure_model_results_table(model_label: str) -> None:
    table = get_results_table_name(model_label)
    with _con() as con:
        cur = con.cursor()
        cur.execute(f"""
        CREATE TABLE IF NOT EXISTS {table} (
            id INTEGER PRIMARY KEY,
            model_label TEXT NOT NULL,
            provider TEXT NOT NULL,
            model_id TEXT NOT NULL,
            run_time_utc TEXT NOT NULL,
            close_sentence TEXT,
            open_sentence TEXT,
            fundamental_text TEXT,
            sentiment_text TEXT,
            margin_engine TEXT,
            created_at TEXT NOT NULL
        )
        """)
        con.commit()


def save_run_results(
    model_label: str,
    provider: str,
    model_id: str,
    now_utc: str,
    close_sentence: str,
    open_sentence: str,
    fund_text: str,
    sent_text: str,
    margin_json: str,
) -> None:
    ensure_model_results_table(model_label)
    table = get_results_table_name(model_label)
    with _con() as con:
        con.execute(
            f"""
            INSERT INTO {table}
            (model_label, provider, model_id, run_time_utc, close_sentence, open_sentence,
             fundamental_text, sentiment_text, margin_engine, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                model_label, provider, model_id, now_utc,
                close_sentence, open_sentence, fund_text, sent_text,
                margin_json, datetime.utcnow().isoformat(),
            ),
        )
        con.commit()


def insert_run_meta(
    model_label: str,
    provider: str,
    model_id: str,
    total_cost: float,
    run_time_utc_iso: str,
    run_time_cairo_iso: str,
) -> None:
    ensure_aux_tables()
    with _con() as con:
        con.execute(
            f"""
            INSERT INTO {RUN_META_TABLE}
            (model_label, provider, model_id, run_time_utc, run_time_cairo, total_cost_usd, created_at)
            VALUES (?,?,?,?,?,?,?)
            """,
            (
                model_label, provider, model_id,
                run_time_utc_iso, run_time_cairo_iso,
                float(total_cost), datetime.utcnow().isoformat(),
            ),
        )
        con.commit()
