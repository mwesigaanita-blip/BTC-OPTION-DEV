"""
Deribit BTC Options - 5-Minute Snapshot Pipeline (Greeks, IV, Prices)
=====================================================================
Fetches a full ticker snapshot for every active BTC option on Deribit,
validates, deduplicates, and writes daily-partitioned Parquet files.

Target path (inside container):
  /data/raw/cefi/options/snapshot/exchange=deribit/underlying=BTC/
      granularity=5m/year={Y}/month={MM}/{YYYY-MM-DD}.parquet

CLI usage:
  python -m multi_agent_system.snapshot_pipeline
  python -m multi_agent_system.snapshot_pipeline --validate-only
"""
from __future__ import annotations

import argparse
import json
import logging
import os
import time
from datetime import date, datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq

from .config import DATA_ROOT, CFG, DAYS_AHEAD

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------
log = logging.getLogger("snapshot_pipeline")

SNAPSHOT_BASE = (
    DATA_ROOT / "raw" / "cefi" / "options" / "snapshot"
    / "exchange=deribit" / "underlying=BTC" / "granularity=5m"
)
STATE_DIR = DATA_ROOT / "raw" / "cefi" / "options" / "snapshot" / "_state"
STATE_FILE = STATE_DIR / "deribit_btc_5m.json"
DEBUG_DIR = DATA_ROOT / "raw" / "cefi" / "options" / "snapshot" / "_debug"
DEBUG_KEEP = 48

# Columns that must be present in every snapshot row
REQUIRED_COLUMNS = [
    "snapshot_ts", "instrument_name", "expiration", "strike", "option_type",
    "mark_price", "bid_price", "ask_price", "mid_price",
    "mark_iv", "bid_iv", "ask_iv",
    "delta", "theta", "vega", "gamma", "rho",
    "volume", "open_interest", "last_price", "underlying_price",
    "bid_size", "ask_size",
    "qty_max_sell", "qty_max_buy", "qty",
    "min_trade_amount", "contract_multiplier",
    "premium_mark_btc", "premium_mid_btc",
    "premium_mark_usd", "premium_mid_usd",
    "theta_usd_per_day", "POP",
    "exchange", "underlying", "granularity",
]

# Dedup key
DEDUP_COLS = ["instrument_name", "snapshot_ts"]


# ---------------------------------------------------------------------------
# State management
# ---------------------------------------------------------------------------
_DEFAULT_STATE: Dict[str, Any] = {
    "last_run_at": None,
    "last_completed_date": None,
    "instruments_fetched": 0,
    "rows_written": 0,
}


def load_state() -> Dict[str, Any]:
    if STATE_FILE.exists():
        try:
            with open(STATE_FILE, "r", encoding="utf-8") as f:
                return {**_DEFAULT_STATE, **json.load(f)}
        except Exception as exc:
            log.warning("Failed to read snapshot state, using defaults: %s", exc)
    return dict(_DEFAULT_STATE)


def save_state(state: Dict[str, Any]) -> None:
    STATE_DIR.mkdir(parents=True, exist_ok=True)
    tmp = STATE_FILE.with_suffix(".tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(state, f, indent=2, default=str)
    tmp.replace(STATE_FILE)


# ---------------------------------------------------------------------------
# Partition path helpers
# ---------------------------------------------------------------------------
def get_snapshot_base_path() -> Path:
    return SNAPSHOT_BASE


def build_partition_path(dt: date) -> Path:
    return (
        SNAPSHOT_BASE
        / f"year={dt.year}"
        / f"month={dt.month:02d}"
        / f"{dt.isoformat()}.parquet"
    )


# ---------------------------------------------------------------------------
# Reader functions (replaces SQLite queries)
# ---------------------------------------------------------------------------
def read_snapshot_for_date(dt: date) -> pd.DataFrame:
    path = build_partition_path(dt)
    if not path.exists():
        return pd.DataFrame()
    try:
        return pd.read_parquet(path)
    except Exception as exc:
        log.warning("Failed to read snapshot %s: %s", path, exc)
        return pd.DataFrame()


def read_snapshot_range(
    start_date: date,
    end_date: date,
    columns: Optional[List[str]] = None,
) -> pd.DataFrame:
    """Read snapshot data across a date range. Replaces SQLite range queries."""
    frames = []
    dt = start_date
    while dt <= end_date:
        path = build_partition_path(dt)
        if path.exists():
            try:
                df = pd.read_parquet(path, columns=columns)
                frames.append(df)
            except Exception as exc:
                log.debug("Skip unreadable snapshot %s: %s", path, exc)
        dt += timedelta(days=1)

    if not frames:
        return pd.DataFrame()
    return pd.concat(frames, ignore_index=True)


def read_latest_snapshot() -> pd.DataFrame:
    """Read the most recent snapshot parquet file. Replaces CSV cache."""
    # Try today first, then yesterday
    today = datetime.now(timezone.utc).date()
    for offset in range(0, 7):
        dt = today - timedelta(days=offset)
        df = read_snapshot_for_date(dt)
        if not df.empty:
            return df
    return pd.DataFrame()


# ---------------------------------------------------------------------------
# Validation
# ---------------------------------------------------------------------------
def validate_snapshot(df: pd.DataFrame) -> Tuple[pd.DataFrame, List[str]]:
    issues: List[str] = []

    if df.empty:
        issues.append("Empty DataFrame - nothing to validate")
        return df, issues

    # snapshot_ts must exist
    if "snapshot_ts" not in df.columns:
        issues.append("Missing snapshot_ts column")
        return df, issues

    df["snapshot_ts"] = pd.to_datetime(df["snapshot_ts"], utc=True, errors="coerce")
    null_ts = df["snapshot_ts"].isna().sum()
    if null_ts > 0:
        issues.append(f"Dropped {null_ts} rows with null snapshot_ts")
        df = df.dropna(subset=["snapshot_ts"])

    # Coerce numeric columns
    numeric_cols = [
        "mark_price", "bid_price", "ask_price", "mid_price",
        "mark_iv", "bid_iv", "ask_iv",
        "delta", "theta", "vega", "gamma", "rho",
        "volume", "open_interest", "last_price", "underlying_price",
        "bid_size", "ask_size",
        "strike",
        "premium_mark_btc", "premium_mid_btc",
        "premium_mark_usd", "premium_mid_usd",
        "theta_usd_per_day", "POP",
    ]
    for col in numeric_cols:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce")

    # Add metadata
    df["exchange"] = "deribit"
    df["underlying"] = "BTC"
    df["granularity"] = "5m"

    # Dedup
    pre_len = len(df)
    df = df.drop_duplicates(subset=DEDUP_COLS, keep="last")
    dupes = pre_len - len(df)
    if dupes > 0:
        issues.append(f"Removed {dupes} duplicate rows (instrument_name + snapshot_ts)")

    return df, issues


# ---------------------------------------------------------------------------
# Parquet write (merge + dedup)
# ---------------------------------------------------------------------------
def write_snapshot_partitioned(df: pd.DataFrame) -> Dict[str, int]:
    if df.empty:
        return {}

    df["_utc_date"] = df["snapshot_ts"].dt.date
    file_counts: Dict[str, int] = {}

    for dt, grp in df.groupby("_utc_date"):
        grp = grp.drop(columns=["_utc_date"])
        path = build_partition_path(dt)
        path.parent.mkdir(parents=True, exist_ok=True)

        # Merge with existing
        if path.exists():
            try:
                existing = pd.read_parquet(path)
                grp = pd.concat([existing, grp], ignore_index=True)
                grp = grp.drop_duplicates(subset=DEDUP_COLS, keep="last")
            except Exception as exc:
                log.warning("Failed to read existing %s, overwriting: %s", path, exc)

        # Ensure datetime columns
        for col in ("snapshot_ts", "expiration"):
            if col in grp.columns:
                grp[col] = pd.to_datetime(grp[col], utc=True, errors="coerce")

        # Write atomically
        tmp_path = path.with_suffix(".parquet.tmp")
        grp.to_parquet(tmp_path, engine="pyarrow", compression="snappy", index=False)
        tmp_path.replace(path)

        date_str = dt.isoformat()
        file_counts[date_str] = len(grp)
        log.info("Wrote %d snapshot rows to %s", len(grp), path)

    return file_counts


# ---------------------------------------------------------------------------
# Debug dump
# ---------------------------------------------------------------------------
def write_debug_dump(summary: Dict[str, Any]) -> Path:
    DEBUG_DIR.mkdir(parents=True, exist_ok=True)
    ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    path = DEBUG_DIR / f"run_{ts}.json"

    with open(path, "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2, default=str)

    # Prune old files
    files = sorted(DEBUG_DIR.glob("run_*.json"), key=lambda p: p.stat().st_mtime)
    for old in files[:-DEBUG_KEEP]:
        try:
            old.unlink()
        except OSError:
            pass

    return path


# ---------------------------------------------------------------------------
# Validate existing files
# ---------------------------------------------------------------------------
def validate_existing_files(base_path: Path = SNAPSHOT_BASE) -> List[Dict[str, Any]]:
    results = []
    for pf in sorted(base_path.rglob("*.parquet")):
        entry: Dict[str, Any] = {"file": str(pf), "issues": []}
        try:
            df = pd.read_parquet(pf)
            entry["rows"] = len(df)

            if "instrument_name" in df.columns and "snapshot_ts" in df.columns:
                dupes = df.duplicated(subset=DEDUP_COLS).sum()
                if dupes > 0:
                    entry["issues"].append(f"{dupes} duplicate rows")

            # Check path matches data dates
            stem = pf.stem
            if "snapshot_ts" in df.columns:
                dates_in_data = pd.to_datetime(df["snapshot_ts"], utc=True, errors="coerce").dt.date.unique()
                for d in dates_in_data:
                    if d is not None and d.isoformat() != stem:
                        entry["issues"].append(f"Row date {d} doesn't match file {stem}")

        except Exception as exc:
            entry["issues"].append(f"Read error: {exc}")

        results.append(entry)
    return results


# ---------------------------------------------------------------------------
# Main pipeline orchestrator
# ---------------------------------------------------------------------------
def run_snapshot_pipeline(*, days_ahead: int = DAYS_AHEAD) -> Dict[str, Any]:
    run_start = datetime.now(timezone.utc)
    log.info("Starting snapshot pipeline (days_ahead=%d)", days_ahead)

    # Lazy import to avoid circular deps
    from .btc_options import fetch_all_btc_options_live_data

    # Fetch live snapshot
    try:
        df_raw = fetch_all_btc_options_live_data(CFG=CFG, days_ahead=days_ahead)
    except Exception as exc:
        log.error("Snapshot fetch failed: %s", exc)
        return {"error": str(exc), "run_start": run_start.isoformat()}

    if df_raw is None or df_raw.empty:
        log.warning("No snapshot data returned from Deribit")
        return {"error": "empty_response", "run_start": run_start.isoformat()}

    rows_fetched = len(df_raw)

    # Rename timestamp → snapshot_ts for clarity
    if "timestamp" in df_raw.columns:
        df_raw = df_raw.rename(columns={"timestamp": "snapshot_ts"})

    # Also add a snapshot_date column for backward compat with queries
    df_raw["snapshot_date"] = run_start.strftime("%Y-%m-%d")

    # Validate
    df, validation_issues = validate_snapshot(df_raw)
    rows_after_validation = len(df)
    duplicates_removed = rows_fetched - rows_after_validation

    # Write
    files_written = write_snapshot_partitioned(df)
    rows_written = sum(files_written.values()) if files_written else 0

    run_end = datetime.now(timezone.utc)

    # Update state
    state = load_state()
    state["last_run_at"] = run_end.isoformat()
    state["last_completed_date"] = run_end.strftime("%Y-%m-%d")
    state["instruments_fetched"] = rows_fetched
    state["rows_written"] = rows_written
    save_state(state)

    # Summary
    instruments_count = df["instrument_name"].nunique() if not df.empty else 0
    summary = {
        "run_start": run_start.isoformat(),
        "run_end": run_end.isoformat(),
        "duration_seconds": round((run_end - run_start).total_seconds(), 1),
        "instruments_total": instruments_count,
        "rows_fetched": rows_fetched,
        "rows_after_validation": rows_after_validation,
        "duplicates_removed": duplicates_removed,
        "files_written": files_written,
        "validation_failures": validation_issues,
    }

    debug_path = write_debug_dump(summary)
    log.info(
        "Snapshot pipeline complete: %d instruments, %d rows to %d files (debug: %s)",
        instruments_count, rows_written, len(files_written), debug_path,
    )

    return summary


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------
def main():
    parser = argparse.ArgumentParser(
        description="Deribit BTC Options Snapshot Pipeline (Greeks/IV/Prices)",
    )
    parser.add_argument(
        "--days-ahead", type=int, default=DAYS_AHEAD,
        help=f"How many days of expiry to include (default: {DAYS_AHEAD})",
    )
    parser.add_argument(
        "--validate-only", action="store_true",
        help="Validate existing parquet files without fetching",
    )
    args = parser.parse_args()

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
        handlers=[logging.StreamHandler()],
        force=True,
    )

    if args.validate_only:
        results = validate_existing_files()
        for r in results:
            status = "OK" if not r["issues"] else "ISSUES"
            print(f"[{status}] {r['file']} - {r.get('rows', '?')} rows")
            for issue in r.get("issues", []):
                print(f"        {issue}")
        return

    result = run_snapshot_pipeline(days_ahead=args.days_ahead)
    print(json.dumps(result, indent=2, default=str))


if __name__ == "__main__":
    main()
