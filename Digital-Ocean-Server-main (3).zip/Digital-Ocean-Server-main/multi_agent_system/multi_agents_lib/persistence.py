from __future__ import annotations

import json
import logging
import re
import sqlite3
from typing import Any, Dict, List, Optional

import pandas as pd

from .model_tables import normalize_model_tag
from shared.db_paths import MODELS_DB


logger = logging.getLogger(__name__)
print(f"[DB] Using {MODELS_DB} in {__file__}", flush=True)


def save_model_decisions_daily(
    *,
    decisions_df: pd.DataFrame,
    llm_provider: str,
    model_id: Optional[str],
    db_path: str,
    save_mode: str = "append",  # "append" | "skip" | "override"
) -> bool:
    """
    Save decisions into per-model table:
        decisions_{model_tag}_multi_agent

    - Creates table if missing
    - Adds missing columns via ALTER TABLE
    - Supports save_mode:
        - append: always insert
        - skip: if (decision_date, run_time_utc, symbol, action, side) exists, skip
        - override: delete same day+run_time rows then insert
    """
    import datetime as dt

    model_tag = normalize_model_tag(llm_provider, model_id)
    table = f"decisions_{model_tag}_multi_agent"

    if decisions_df is None or decisions_df.empty:
        logger.warning("save_model_decisions_daily: decisions_df is empty; nothing to save.")
        return False

    now_utc = dt.datetime.now(dt.timezone.utc)
    decision_date = now_utc.date().isoformat()
    run_time_utc = now_utc.isoformat()

    # Ensure required columns exist (DB schema)
    cols = [
        ("decision_date", "TEXT"),
        ("run_time_utc", "TEXT"),
        ("symbol", "TEXT"),
        ("action", "TEXT"),
        ("right", "TEXT"),
        ("side", "TEXT"),
        ("quantity", "INTEGER"),
        ("reason", "TEXT"),
        ("when_to_close", "TEXT"),
        ("POP", "REAL"),
        ("btc_price", "REAL"),
        ("avg_price_btc", "REAL"),
        ("avg_price_usd", "REAL"),
        ("mark_price_btc", "REAL"),
        ("mark_price_usd", "REAL"),
    ]
    col_names = [c[0] for c in cols]

    df = decisions_df.copy()

    # normalize/ensure columns
    if "quantity" not in df.columns and "qty" in df.columns:
        df["quantity"] = df["qty"]

    for c in col_names:
        if c not in df.columns:
            df[c] = None

    # write key fields
    df["decision_date"] = decision_date
    df["run_time_utc"] = run_time_utc

    # SQLite write
    # ``db_path`` is retained on the public API for backward compatibility
    # but ignored: every table this module writes lives in MODELS_DB.
    con = sqlite3.connect(str(MODELS_DB))
    try:
        con.execute("PRAGMA journal_mode=WAL;")
        con.execute("PRAGMA busy_timeout=30000;")
        cur = con.cursor()

        # create table
        cur.execute(
            f"""
            CREATE TABLE IF NOT EXISTS {table} (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                decision_date TEXT,
                run_time_utc TEXT,
                symbol TEXT,
                action TEXT,
                right TEXT,
                side TEXT,
                quantity INTEGER,
                reason TEXT,
                when_to_close TEXT,
                POP REAL,
                btc_price REAL,
                avg_price_btc REAL,
                avg_price_usd REAL,
                mark_price_btc REAL,
                mark_price_usd REAL
            )
            """
        )

        # add missing columns if schema evolved
        existing_cols = {r[1] for r in cur.execute(f"PRAGMA table_info({table})").fetchall()}
        for name, sql_type in cols:
            if name not in existing_cols:
                cur.execute(f"ALTER TABLE {table} ADD COLUMN {name} {sql_type}")

        # indices
        cur.execute(f"CREATE INDEX IF NOT EXISTS idx_{table}_decision_date ON {table}(decision_date)")
        cur.execute(f"CREATE INDEX IF NOT EXISTS idx_{table}_decision_date_run_time ON {table}(decision_date, run_time_utc)")
        cur.execute(f"CREATE INDEX IF NOT EXISTS idx_{table}_symbol ON {table}(symbol)")
        cur.execute(f"CREATE INDEX IF NOT EXISTS idx_{table}_action ON {table}(action)")
        cur.execute(f"CREATE INDEX IF NOT EXISTS idx_{table}_side ON {table}(side)")

        # save modes
        if save_mode == "override":
            cur.execute(f"DELETE FROM {table} WHERE decision_date = ? AND run_time_utc = ?", (decision_date, run_time_utc))

        # insert rows
        insert_sql = f"""
            INSERT INTO {table} ({",".join(col_names)})
            VALUES ({",".join(["?"] * len(col_names))})
        """

        inserted = 0
        for _, r in df[col_names].iterrows():
            row = [None if (pd.isna(v) if hasattr(pd, "isna") else False) else v for v in r.tolist()]

            if save_mode == "skip":
                # skip if same (date, run_time, symbol, action, side) exists
                sym, act, side = r.get("symbol"), r.get("action"), r.get("side")
                q = f"SELECT 1 FROM {table} WHERE decision_date=? AND run_time_utc=? AND symbol=? AND action=? AND side=? LIMIT 1"
                if cur.execute(q, (decision_date, run_time_utc, sym, act, side)).fetchone():
                    continue

            cur.execute(insert_sql, row)
            inserted += 1

        con.commit()
        logger.info("Saved %d decision rows into %s", inserted, table)
        return inserted > 0

    except Exception as e:
        con.rollback()
        logger.exception("save_model_decisions_daily failed: %s", e)
        return False
    finally:
        con.close()


def _open_trades_table_name(model_id: Optional[str]) -> str:
    raw = (model_id or "model").strip().lower()
    raw = re.sub(r"[^a-z0-9]+", "_", raw).strip("_")
    return f"open_trades_{raw or 'model'}"


def save_open_trades_daily(
    *,
    open_trades: List[Dict[str, Any]],
    llm_provider: str,
    model_id: Optional[str],
    db_path: str,
) -> bool:
    """
    Save top OPEN ideas (margin-enriched) as JSON blob to per-model table.
    """
    import datetime as dt

    table = _open_trades_table_name(model_id)
    run_ts = dt.datetime.now(dt.timezone.utc).isoformat()

    # ``db_path`` is retained on the public API for backward compatibility
    # but ignored: every table this module writes lives in MODELS_DB.
    con = sqlite3.connect(str(MODELS_DB))
    try:
        con.execute("PRAGMA journal_mode=WAL;")
        con.execute("PRAGMA busy_timeout=30000;")
        cur = con.cursor()

        cur.execute(
            f"""
            CREATE TABLE IF NOT EXISTS {table} (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                run_timestamp_utc TEXT NOT NULL,
                provider TEXT,
                model_id TEXT,
                open_trades_json TEXT
            )
            """
        )
        cur.execute(f"CREATE INDEX IF NOT EXISTS idx_{table}_run_ts ON {table}(run_timestamp_utc)")

        payload = json.dumps(open_trades or [], default=str)
        cur.execute(
            f"INSERT INTO {table} (run_timestamp_utc, provider, model_id, open_trades_json) VALUES (?, ?, ?, ?)",
            (run_ts, llm_provider, model_id, payload),
        )
        con.commit()
        logger.info("Saved open_trades into %s (run_timestamp_utc=%s)", table, run_ts)
        return True

    except Exception as e:
        con.rollback()
        logger.exception("save_open_trades_daily failed: %s", e)
        return False
    finally:
        con.close()


def save_mm_im_snapshot(
    *,
    db_path: str,
    run_time_utc_iso: str,
    provider: str,
    model_id: Optional[str],
    im_before: float,
    mm_before: float,
    im_after: float,
    mm_after: float,
    im_pct_mb_before: Optional[float],
    im_pct_mb_after: Optional[float],
    mm_pct_mb_before: Optional[float],
    mm_pct_mb_after: Optional[float],
) -> None:
    """
    Persist old/new IM/MM snapshot into MM_IM table (one row per pipeline run).
    """
    # ``db_path`` is retained on the public API for backward compatibility
    # but ignored: every table this module writes lives in MODELS_DB.
    con = sqlite3.connect(str(MODELS_DB))
    try:
        cur = con.cursor()
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS MM_IM (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                run_time_utc TEXT NOT NULL,
                provider TEXT,
                model_id TEXT,
                im_before_btc REAL,
                mm_before_btc REAL,
                im_after_btc REAL,
                mm_after_btc REAL,
                im_pct_mb_before REAL,
                im_pct_mb_after REAL,
                mm_pct_mb_before REAL,
                mm_pct_mb_after REAL
            )
            """
        )
        cur.execute(
            """
            INSERT INTO MM_IM (
                run_time_utc, provider, model_id,
                im_before_btc, mm_before_btc,
                im_after_btc, mm_after_btc,
                im_pct_mb_before, im_pct_mb_after,
                mm_pct_mb_before, mm_pct_mb_after
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                run_time_utc_iso,
                provider,
                model_id,
                float(im_before),
                float(mm_before),
                float(im_after),
                float(mm_after),
                None if im_pct_mb_before is None else float(im_pct_mb_before),
                None if im_pct_mb_after is None else float(im_pct_mb_after),
                None if mm_pct_mb_before is None else float(mm_pct_mb_before),
                None if mm_pct_mb_after is None else float(mm_pct_mb_after),
            ),
        )
        con.commit()
    except Exception as e:
        logger.warning("Failed to save MM/IM snapshot: %s", e)
    finally:
        con.close()
