from __future__ import annotations

import re
from typing import Optional


def pick_decisions_table_for_model(provider: str, model_id: Optional[str]) -> Optional[str]:
    """
    Map (LLM provider, model id) to the appropriate decisions_*_multi_agent table.
    This is used by the Historical Context Agent to know which table to read.
    """
    mid = (model_id or "").lower()
    prov = (provider or "").lower()

    # Order matters: check "mini" before generic "5"
    if prov == "openai" and ("5-mini" in mid or "gpt-5-mini" in mid or "gpt5-mini" in mid):
        return "decisions_gpt_5_mini_multi_agent"

    if prov == "openai" and ("4o" in mid):
        return "decisions_gpt_4o_multi_agent"

    if prov == "openai" and ("5" in mid or "gpt-5" in mid or "gpt5" in mid):
        return "decisions_gpt_5_multi_agent"

    if prov == "xai" and "grok" in mid:
        return "decisions_grok4_multi_agent"

    if prov == "anthropic" and "claude" in mid:
        return "decisions_claude_sonnet_multi_agent"

    return None


def normalize_model_tag(provider: str, model_id: Optional[str]) -> str:
    """
    Stable tag used for table naming / file naming.
    Mirrors your previous _normalize_model_tag behavior.
    """
    mid = (model_id or "").lower()
    prov = (provider or "").lower()

    if prov == "openai":
        if "5-mini" in mid or "gpt-5-mini" in mid or "gpt5-mini" in mid:
            return "gpt_5_mini"
        if "4o" in mid:
            return "gpt_4o"
        if "5" in mid or "gpt-5" in mid or "gpt5" in mid:
            return "gpt_5"

    if prov == "xai":
        if "grok4" in mid or "grok-4" in mid:
            return "grok4"
        if "grok3" in mid or "grok-3" in mid:
            return "grok3"
        if "grok" in mid:
            return "grok"

    if prov == "anthropic":
        if "sonnet" in mid:
            return "claude_sonnet"
        if "claude" in mid:
            return "claude"

    if "llama" in mid:
        return "llama"

    # fallback: safe slug
    raw = (model_id or prov or "model").strip().lower()
    raw = re.sub(r"[^a-z0-9]+", "_", raw).strip("_")
    return raw or "model"
