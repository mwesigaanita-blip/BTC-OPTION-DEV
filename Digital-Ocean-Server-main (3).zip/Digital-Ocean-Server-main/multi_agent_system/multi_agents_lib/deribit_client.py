from __future__ import annotations

import logging
import os
from typing import Any, Dict, List, Optional

from ..Deribit_margin import DeribitClient


logger = logging.getLogger(__name__)

_DERIBIT_CLIENT: Optional[DeribitClient] = None


def get_deribit_client() -> Optional[DeribitClient]:
    """
    Lazy-init DeribitClient using env vars:
      DERIBIT_CLIENT_ID, DERIBIT_CLIENT_SECRET, DERIBIT_BASE_URL (optional).
    If credentials are missing, returns None and margin simulation is skipped.
    """
    global _DERIBIT_CLIENT
    if _DERIBIT_CLIENT is not None:
        return _DERIBIT_CLIENT

    cid = os.getenv("DERIBIT_CLIENT_ID")
    csec = os.getenv("DERIBIT_CLIENT_SECRET")
    base_url = os.getenv("DERIBIT_BASE_URL", "https://www.deribit.com")

    if not cid or not csec:
        logger.warning(
            "Deribit credentials not set; Deribit simulate_portfolio margin disabled."
        )
        return None

    _DERIBIT_CLIENT = DeribitClient(client_id=cid, client_secret=csec, base_url=base_url)
    return _DERIBIT_CLIENT


def mm_pct(mm_btc: Optional[float], margin_balance_btc: Optional[float]) -> Optional[float]:
    """
    MM% of margin balance (Deribit UI style), capped at 100.
    """
    if mm_btc is None or margin_balance_btc is None:
        return None
    try:
        mb = float(margin_balance_btc)
        mm = float(mm_btc)
    except Exception:
        return None
    if mb <= 1e-12:
        return None
    return min(100.0, 100.0 * mm / mb)


def margin_explain_from_deribit_result(res: Optional[Dict[str, Any]]) -> str:
    """
    Compact explanation string from Deribit simulate_portfolio result.
    """
    if not isinstance(res, dict):
        return "Deribit simulate_portfolio: (no result)"

    try:
        mm = float(res.get("maintenance_margin") or 0.0)
        im = float(res.get("initial_margin") or 0.0)
        mb = float(res.get("margin_balance") or 0.0)
        mm_p = mm_pct(mm, mb)
        mm_p_s = f"{mm_p:.2f}%" if mm_p is not None else "N/A"
        return f"MM={mm:.6f} BTC | IM={im:.6f} BTC | MB={mb:.6f} BTC | MM%={mm_p_s}"
    except Exception:
        return "Deribit simulate_portfolio: (failed to parse result)"


def snapshot_to_deribit_positions(margin_snapshot: Optional[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """
    Convert your margin_snapshot shape into Deribit simulate_portfolio positions list:
      [{"instrument_name": "...", "amount": float}, ...]

    Supports both:
      - snapshot["options"] entries using "size"
      - snapshot["futures"] entries using "size"
    """
    if not isinstance(margin_snapshot, dict):
        return []

    out: List[Dict[str, Any]] = []

    for pos in (margin_snapshot.get("options") or []):
        try:
            inst = str(pos.get("instrument_name") or "").strip()
            amt = float(pos.get("size") or 0.0)
        except Exception:
            continue
        if inst:
            out.append({"instrument_name": inst, "amount": amt})

    for pos in (margin_snapshot.get("futures") or []):
        try:
            inst = str(pos.get("instrument_name") or "").strip()
            amt = float(pos.get("size") or 0.0)
        except Exception:
            continue
        if inst:
            out.append({"instrument_name": inst, "amount": amt})

    return out
