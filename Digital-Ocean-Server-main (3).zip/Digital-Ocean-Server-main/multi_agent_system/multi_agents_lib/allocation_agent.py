from __future__ import annotations

import json
import logging
from typing import Any, Dict, List, Optional, Tuple

from ..llm_io import LLMError

from .decision_parsing import extract_first_json_object
from .decision_parsing import validate_decisions  # your structural validator
from .instrument_utils import parse_deribit_option_symbol


logger = logging.getLogger(__name__)


def attach_open_explanations(
    *,
    enforced_open_legs: List[Dict[str, Any]],
    llm_open_by_symbol: Dict[str, Dict[str, Any]],
    open_scenarios: List[Dict[str, Any]],
    chosen_scenario_id: str,
    mm_after_close: float,
    im_after_close: float,
) -> List[Dict[str, Any]]:
    """
    Keep scenario enforcement (symbol/side/qty) but inject reason/when_to_close from LLM.
    If LLM didn't provide it for a symbol, build a non-static fallback using scenario metrics.
    """
    sid = (chosen_scenario_id or "").strip().upper()
    sc = None
    for s in (open_scenarios or []):
        if str(s.get("scenario_id") or "").strip().upper() == sid:
            sc = s
            break

    sc_mm_pct = sc.get("mm_pct_after") if isinstance(sc, dict) else None
    sc_mm_btc = sc.get("mm_after_btc") if isinstance(sc, dict) else None
    sc_theta = sc.get("_theta_eff_total") if isinstance(sc, dict) else None

    for leg in enforced_open_legs:
        sym = (leg.get("symbol") or "").strip().upper()
        if not sym:
            continue

        # 1) Prefer LLM explanation if available
        llm_d = llm_open_by_symbol.get(sym)
        if isinstance(llm_d, dict):
            r = (llm_d.get("reason") or "").strip()
            w = (llm_d.get("when_to_close") or "").strip()
            if r:
                leg["reason"] = r
            if w:
                leg["when_to_close"] = w
            continue

        # 2) Fallback: build a useful plan
        expiry, strike, right = parse_deribit_option_symbol(sym)
        side = (leg.get("side") or "").upper()

        dist_rule = ""
        if strike and right in ("CALL", "PUT"):
            if right == "CALL":
                dist_rule = f"prefer entry only if spot is meaningfully below strike ({strike:,.0f})"
            else:
                dist_rule = f"prefer entry only if spot is meaningfully above strike ({strike:,.0f})"

        reason_bits = [f"Chosen under scenario {sid} to keep margin within limits"]
        if sc_theta is not None:
            try:
                reason_bits.append(f"scenario theta_eff_total={float(sc_theta):.3f}")
            except Exception:
                pass
        if sc_mm_pct is not None:
            try:
                reason_bits.append(f"projected MM%_of_MB={float(sc_mm_pct):.2f}%")
            except Exception:
                pass
        if leg.get("POP") is not None:
            try:
                reason_bits.append(f"POP={float(leg.get('POP')):.2f}")
            except Exception:
                pass

        leg["reason"] = "; ".join(reason_bits) + "."

        plan = []
        if expiry:
            plan.append(f"Expiry={expiry}")
        if dist_rule:
            plan.append(f"Entry: {dist_rule}")
        if side == "SELL":
            plan.append("Take profit if premium decays ~50–70%; reduce/close if spot approaches strike or vol expands sharply.")
        else:
            plan.append("Cut loss if thesis invalidates; take profit into strong move; reduce if margin pressure increases.")
        if sc_mm_btc is not None and mm_after_close is not None:
            try:
                mm_delta = float(sc_mm_btc) - float(mm_after_close)
                plan.append(f"Margin: projected ΔMM≈{mm_delta:.6f} BTC vs after-close baseline.")
            except Exception:
                pass

        leg["when_to_close"] = " | ".join(plan)

    return enforced_open_legs


def _dummy_sentence(prefix: str) -> str:
    return f"[NO-LLM MODE] {prefix}: static placeholder output."


def run_allocation_llm(
    fundamental_text: str,
    sentiment_text: str,
    strategy: str,
    forcast_messsage: str,
    btc_price: float,
    account_info: dict | None,
    current_positions_text: str,
    open_context_txt: str,
    hist_summary_text: Optional[str],
    hist_rules_text: Optional[str],
    client,
    build_allocation_prompt_fn,
    allocation_spec: Dict[str, Any],
    debuge: bool = False,
    *,
    mm_cap_pct: float = 75.0,
    use_llm: bool = True,
    chosen_open_scenario_id: str = "NONE",
    curreent_positions_text: Optional[str] = None,
) -> Tuple[str, List[Dict[str, Any]], float, str]:
    """
    FINAL Allocation agent (drop-in compatible with your current multi_agents.py).

    Notes:
    - build_allocation_prompt_fn is injected from multi_agents.py to avoid circular imports.
      It must return (system_prompt, user_prompt).
    - allocation_spec is injected so this module is pure and doesn't import your config constants.
    """
    # ======== 1) Build prompt (this also writes the prompt txt file) ========
    system_prompt, user_prompt = build_allocation_prompt_fn(
        fundamental_text=fundamental_text,
        sentiment_text=sentiment_text,
        strategy=strategy,
        forcast_messsage=forcast_messsage,
        btc_price=btc_price,
        account_info=account_info,
        close_context_txt=current_positions_text,
        open_context_txt=open_context_txt,
        hist_summary_text=hist_summary_text,
        hist_rules_text=hist_rules_text,
        mm_cap_pct=float(mm_cap_pct),
    )

    # ======== 2) If not using LLM: stop here (prompt already saved) ========
    if not use_llm:
        sentence = _dummy_sentence("ALLOCATION")
        return sentence, [], 0.0, str(chosen_open_scenario_id or "NONE").strip().upper()

    # ======== 3) Call LLM (same signature you have now) ========
    resp = client(
        prompt=system_prompt + "\n\n" + user_prompt,
        temperature=0.05,
        retries=3,
        request_timeout=300,
        verbose=True,
    )
    cost = float(resp.get("usd_est", 0.0))

    # ======== 4) Parse JSON ========
    try:
        parsed = json.loads(resp.get("json_str") or "")
    except Exception:
        raw = resp.get("raw", "") or ""
        logging.warning("Allocation: primary JSON parse failed; attempting raw extraction…")
        parsed = extract_first_json_object(raw)
        if parsed is None:
            raise LLMError("No valid JSON found in allocation agent response (after fallback).")

    if not isinstance(parsed, dict):
        raise LLMError("Allocation agent response is not a JSON object.")

    chosen_open_scenario_id = str(parsed.get("chosen_open_scenario_id", "NONE") or "NONE").strip().upper()
    if not chosen_open_scenario_id:
        chosen_open_scenario_id = "NONE"

    sentence = str(parsed.get("sentence", "") or "").strip()
    decisions_raw = parsed.get("decisions", [])
    if not isinstance(decisions_raw, list):
        logging.warning("Allocation: `decisions` is not a list; coercing to empty list.")
        decisions_raw = []

    # ======== 5) Validate ========
    validated = validate_decisions(
        {"decisions": decisions_raw},
        allocation_spec,
        positions_side_qty=None,
    )

    # ======== 6) Quantity normalization ========
    cleaned: List[Dict[str, Any]] = []
    for d in validated:
        qty_raw = d.get("quantity", d.get("qty", 0))
        try:
            qty = int(qty_raw)
        except Exception:
            qty = 0
        if qty <= 0:
            qty = 1
        d["quantity"] = qty
        cleaned.append(d)

    if debuge:
        print("*" * 20, "ALLOCATION agent validated decisions:", "*" * 20)
        for row in cleaned:
            print(row)
        print("[ALLOCATION sentence]:", sentence)

    return sentence, cleaned, cost, chosen_open_scenario_id
