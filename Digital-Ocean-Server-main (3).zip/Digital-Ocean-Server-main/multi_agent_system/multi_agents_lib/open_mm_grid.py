from __future__ import annotations

import json
import logging
import os
from typing import Any, Dict, List, Optional, Tuple

import numpy as np

from ..Deribit_margin import (
    apply_allocation_decisions,
    calc_margin_for_positions,
)

from .deribit_client import get_deribit_client, mm_pct, margin_explain_from_deribit_result
from .instrument_utils import infer_right_from_symbol


logger = logging.getLogger(__name__)


def _norm_side(side: Any) -> str:
    s = str(side or "").strip().upper()
    if s in ("SHORT", "SELL", "S"):
        return "SELL"
    if s in ("LONG", "BUY", "B"):
        return "BUY"
    return s or "SELL"


def _infer_right(sym: str, right: Any) -> str:
    r = str(right or "").strip().upper()
    if r in ("CALL", "PUT"):
        return r
    inf = infer_right_from_symbol(sym)
    return inf or ""


def _to_float_or_none(x: Any) -> Optional[float]:
    try:
        v = float(x)
        if np.isfinite(v):
            return v
        return None
    except Exception:
        return None


def _scenario_leg_from_candidate(cand: Dict[str, Any], qty: int) -> Dict[str, Any]:
    sym = str(cand.get("symbol") or cand.get("instrument_name") or "").strip().upper()
    side = _norm_side(cand.get("side"))
    right = _infer_right(sym, cand.get("right"))
    pop = cand.get("POP")
    try:
        pop = float(pop) if pop not in (None, "", []) else None
    except Exception:
        pass

    leg = {
        "symbol": sym,
        "action": "OPEN",
        "side": side,
        "right": right,
        "quantity": max(1, int(qty)),
    }
    if pop is not None:
        leg["POP"] = pop

    # keep theta_eff if present
    if cand.get("_theta_eff") is not None:
        leg["_theta_eff"] = cand.get("_theta_eff")

    return leg


def pick_top_calls_puts_by_theta_eff(open_candidates: List[Dict[str, Any]], top_n: int = 5):
    """
    Splits candidates into CALL/PUT and sorts by:
      1) _theta_eff desc
      2) mm_delta_btc asc (if present)
      3) symbol asc
    """
    calls, puts = [], []
    for c in (open_candidates or []):
        sym = str(c.get("symbol") or "").upper()
        right = str(c.get("right") or infer_right_from_symbol(sym) or "").upper()
        if right == "CALL":
            calls.append(c)
        elif right == "PUT":
            puts.append(c)

    def _score(x):
        te = x.get("_theta_eff")
        try:
            te = float(te) if te is not None else -1e9
        except Exception:
            te = -1e9

        md = x.get("mm_delta_btc")
        try:
            md = float(md) if md is not None else 1e9
        except Exception:
            md = 1e9

        sym = str(x.get("symbol") or "")
        return (-te, md, sym)

    calls = sorted(calls, key=_score)[:top_n]
    puts = sorted(puts, key=_score)[:top_n]
    return calls, puts


def build_open_context_from_enriched_candidates(
    enriched: List[Dict[str, Any]],
    *,
    max_lines: int = 200,
) -> str:
    """
    Converts margin-enriched candidates into a strict OPEN universe text block.
    Sorts by cheapest mm_delta_btc first.
    """
    if not enriched:
        return "No MM-safe OPEN candidates."

    def _k(x):
        try:
            return float(x.get("mm_delta_btc") or 1e9)
        except Exception:
            return 1e9

    rows = sorted(enriched, key=_k)

    lines = []
    lines.append("=== MM-SAFE OPEN UNIVERSE (pre-filtered) ===")
    lines.append("Choose ONLY from these symbols/qty. Do NOT invent symbols or quantities.")
    lines.append("If choosing multiple new positions, pick ONE bundle (if provided later).")
    lines.append("")

    for i, r in enumerate(rows[:max_lines], start=1):
        sym = str(r.get("symbol") or "").strip().upper()
        if not sym:
            continue
        qty = r.get("quantity")
        try:
            qty = int(qty) if qty not in (None, "", []) else 1
        except Exception:
            qty = 1
        side = _norm_side(r.get("side"))
        right = _infer_right(sym, r.get("right"))

        mm_after = r.get("mm_after_btc")
        im_after = r.get("im_after_btc")
        mb_after = r.get("mb_after_btc")
        mm_p = r.get("mm_pct_after")
        dmm = r.get("mm_delta_btc")
        dim = r.get("im_delta_btc")

        pop = r.get("POP")
        te = r.get("_theta_eff")

        bits = [
            f"{i:03d}",
            sym,
            f"{side} {right}".strip(),
            f"qty={qty}",
            f"MM%={_to_float_or_none(mm_p):.2f}%" if _to_float_or_none(mm_p) is not None else "MM%=N/A",
            f"ΔMM={_to_float_or_none(dmm):.6f} BTC" if _to_float_or_none(dmm) is not None else "",
            f"ΔIM={_to_float_or_none(dim):.6f} BTC" if _to_float_or_none(dim) is not None else "",
        ]
        if pop is not None:
            try:
                bits.append(f"POP={float(pop):.2f}")
            except Exception:
                pass
        if te is not None:
            try:
                bits.append(f"theta_eff={float(te):.4f}")
            except Exception:
                pass

        # compact
        bits = [b for b in bits if b]
        lines.append(" | ".join(bits))

    if len(rows) > max_lines:
        lines.append(f"... truncated: showing {max_lines} of {len(rows)} candidates")

    return "\n".join(lines)


def build_open_mm_grid_for_candidates(
    *,
    positions_after_close: List[Dict[str, Any]],
    open_candidates: List[Dict[str, Any]],
    qty_grid: List[int],
    mm_cap_pct: float,
    currency: str = "BTC",
    debug_path: Optional[str] = None,
) -> List[Dict[str, Any]]:
    """
    True Deribit simulate_portfolio loop:
      - Baseline sim once (positions_after_close)
      - For each candidate + qty in grid:
          apply allocation leg
          simulate margins
          keep rows where mm_pct <= mm_cap_pct

    Returns rows with:
      mm/im/mb after, deltas vs baseline, explanation (raw Deribit response)
    """
    der = get_deribit_client()
    if der is None:
        logger.warning("Deribit client missing; cannot build MM grid.")
        return []

    if not open_candidates:
        return []

    baseline = calc_margin_for_positions(der, positions_after_close, currency=currency)
    mm0 = float(baseline.get("maintenance_margin") or 0.0)
    im0 = float(baseline.get("initial_margin") or 0.0)
    mb0 = float(baseline.get("margin_balance") or 0.0)
    mm0_pct = mm_pct(mm0, mb0)

    safe_rows: List[Dict[str, Any]] = []
    debug_dump = []

    for cand in open_candidates:
        for q in qty_grid:
            leg = _scenario_leg_from_candidate(cand, q)
            if not leg.get("symbol"):
                continue

            new_positions = apply_allocation_decisions(positions_after_close, [leg])
            sim = calc_margin_for_positions(der, new_positions, currency=currency)

            mm1 = float(sim.get("maintenance_margin") or 0.0)
            im1 = float(sim.get("initial_margin") or 0.0)
            mb1 = float(sim.get("margin_balance") or 0.0)
            mm1_pct = mm_pct(mm1, mb1)

            row = dict(leg)
            row.update(
                {
                    "mm_after_btc": mm1,
                    "im_after_btc": im1,
                    "mb_after_btc": mb1,
                    "mm_pct_after": mm1_pct,
                    "mm_delta_btc": mm1 - mm0,
                    "im_delta_btc": im1 - im0,
                    "explanation": sim,
                }
            )

            # keep theta_eff if any
            if cand.get("_theta_eff") is not None:
                row["_theta_eff"] = cand.get("_theta_eff")

            # enforce MM cap
            if mm1_pct is not None and mm1_pct <= float(mm_cap_pct):
                safe_rows.append(row)

            debug_dump.append(row)

    if debug_path:
        try:
            os.makedirs(debug_path, exist_ok=True)
            with open(os.path.join(debug_path, "open_mm_grid_debug.json"), "w", encoding="utf-8") as f:
                json.dump(debug_dump, f, indent=2, default=str)
        except Exception as e:
            logger.warning("Failed to write open_mm_grid debug: %s", e)

    # add explain summary for safe rows (optional string form)
    for r in safe_rows:
        r["explain_str"] = margin_explain_from_deribit_result(r.get("explanation"))

    return safe_rows
