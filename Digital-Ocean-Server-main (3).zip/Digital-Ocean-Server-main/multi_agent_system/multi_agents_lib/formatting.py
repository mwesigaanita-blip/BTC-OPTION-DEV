from __future__ import annotations
from typing import Any, Optional, Sequence, Union

import pandas as pd


def format_fundamental_for_llm(out) -> str:
    """
    Make a compact, LLM-friendly summary string from the fundamental agent output.
    Handles cases where `out` is already a string (or other non-dict types).

    Example:
      "bias:bullish | horizon_days:5 | key_signals:positive-macro,high-hashrate,elevated-tx-volume | red_flags:HEADLINE_NOISE,SUPPLY_NEAR_MAX | confidence:0.65 | pop_est:0.7 | rationale:... | recs:rec1; rec2"
    """

    def _kw(s: str) -> str:
        return (
            str(s)
            .strip()
            .lower()
            .replace("\n", " ")
            .replace("/", " ")
            .replace("_", " ")
            .replace("-", " ")
            .replace("|", "/")
            .replace("  ", " ")
            .replace(" ", "-")
        )

    def _clean_text(s: str) -> str:
        s = (s or "").replace("|", "/").replace("\n", " ").strip()
        while "  " in s:
            s = s.replace("  ", " ")
        return s

    # --- If out is a string (or not a dict), pass through safely ---
    if out is None:
        return "bias:unknown"
    if isinstance(out, str):
        # If it's already formatted, just sanitize separators/newlines.
        s = _clean_text(out)
        return s if s else "bias:unknown"
    if not isinstance(out, dict):
        # Best-effort stringify
        s = _clean_text(str(out))
        return s if s else "bias:unknown"

    # --- Normal dict path ---
    bias = _clean_text(out.get("bias") or "unknown").lower()
    horizon = out.get("horizon_days")
    confidence = out.get("confidence")
    metrics = out.get("metrics") or {}
    pop_est = metrics.get("pop_est")

    # key_signals → normalized, deduped, order-preserving
    seen = set()
    key_signals = []
    for x in (out.get("key_signals") or []):
        if isinstance(x, str) and x.strip():
            k = _kw(x)
            if k and k not in seen:
                key_signals.append(k)
                seen.add(k)

    # red_flags → codes only (fallback: accept strings too)
    red_flags = []
    for rf in (out.get("red_flags") or []):
        if isinstance(rf, dict) and rf.get("code"):
            red_flags.append(_clean_text(str(rf["code"])))
        elif isinstance(rf, str) and rf.strip():
            red_flags.append(_clean_text(rf))

    # rationale + recommendations
    rationale = _clean_text(out.get("rationale", ""))

    recs_raw = [r for r in (out.get("recommendations") or []) if isinstance(r, str) and r.strip()]
    recs_seen, recs = set(), []
    for r in recs_raw:
        c = _clean_text(r)
        if c and c not in recs_seen:
            recs.append(c)
            recs_seen.add(c)

    # avoid bloat
    if len(recs) > 3:
        recs = recs[:3] + ["…"]

    parts = [f"bias:{bias}"]

    if isinstance(horizon, (int, float)):
        parts.append(f"horizon_days:{int(horizon)}")

    if key_signals:
        parts.append("key_signals:" + ",".join(key_signals))

    if red_flags:
        parts.append("red_flags:" + ",".join(red_flags))

    if isinstance(confidence, (int, float)):
        parts.append(f"confidence:{round(float(confidence), 3)}")

    if isinstance(pop_est, (int, float)):
        parts.append(f"pop_est:{round(float(pop_est), 3)}")

    if rationale:
        parts.append(f"rationale:{rationale}")

    if recs:
        parts.append("recs:" + "; ".join(recs))

    return " | ".join(parts)

def format_sentiment_for_llm(out) -> str:
    """
    Make a compact, LLM-friendly summary string from the sentiment agent output.
    Safely handles cases where `out` is already a string or not a dict.
    """

    def _kw(s: str) -> str:
        return (
            str(s)
            .strip()
            .lower()
            .replace("\n", " ")
            .replace("/", " ")
            .replace("_", " ")
            .replace("-", " ")
            .replace("|", "/")
            .replace("  ", " ")
            .replace(" ", "-")
        )

    def _clean_text(s: str) -> str:
        s = (s or "").replace("|", "/").replace("\n", " ").strip()
        while "  " in s:
            s = s.replace("  ", " ")
        return s

    # --- Non-dict safety ---
    if out is None:
        return "bias:unknown"
    if isinstance(out, str):
        s = _clean_text(out)
        return s if s else "bias:unknown"
    if not isinstance(out, dict):
        s = _clean_text(str(out))
        return s if s else "bias:unknown"

    # --- Normal dict path ---
    bias = _clean_text(out.get("bias") or "unknown").lower()
    horizon = out.get("horizon_days")
    confidence = out.get("confidence")
    metrics = out.get("metrics") or {}
    pop_est = metrics.get("pop_est")

    # key_signals → normalized, deduped, order-preserving
    seen = set()
    key_signals = []
    for x in (out.get("key_signals") or []):
        if isinstance(x, str) and x.strip():
            k = _kw(x)
            if k and k not in seen:
                key_signals.append(k)
                seen.add(k)

    # red_flags → codes only (fallback: accept strings)
    red_flags = []
    for rf in (out.get("red_flags") or []):
        if isinstance(rf, dict) and rf.get("code"):
            red_flags.append(_clean_text(str(rf["code"])))
        elif isinstance(rf, str) and rf.strip():
            red_flags.append(_clean_text(rf))

    # rationale + recommendations
    rationale = _clean_text(out.get("rationale", ""))

    recs_raw = [r for r in (out.get("recommendations") or []) if isinstance(r, str) and r.strip()]
    recs_seen, recs = set(), []
    for r in recs_raw:
        c = _clean_text(r)
        if c and c not in recs_seen:
            recs.append(c)
            recs_seen.add(c)

    if len(recs) > 3:
        recs = recs[:3] + ["…"]

    parts = [f"bias:{bias}"]

    if isinstance(horizon, (int, float)):
        parts.append(f"horizon_days:{int(horizon)}")

    if key_signals:
        parts.append("key_signals:" + ",".join(key_signals))

    if red_flags:
        parts.append("red_flags:" + ",".join(red_flags))

    if isinstance(confidence, (int, float)):
        parts.append(f"confidence:{round(float(confidence), 3)}")

    if isinstance(pop_est, (int, float)):
        parts.append(f"pop_est:{round(float(pop_est), 3)}")

    if rationale:
        parts.append(f"rationale:{rationale}")

    if recs:
        parts.append("recs:" + "; ".join(recs))

    return " | ".join(parts)

def format_valuation_for_llm_from_out(
    out: Union[dict, pd.DataFrame, None],
    *,
    extra_note_cols: Optional[Sequence[str]] = ("rank","edge","reason","eligible_vega"),
) -> str:
    """
    Accepts either:
      - dict with keys: filtered_options_df, summary_text, metrics, (optional) current_positions_df
      - DataFrame directly (treated as filtered_options_df)
    Emits:
      'valuation_summary | n_final:.. | mean_spread_pct:.. | holdings:..\\n' + CSV
    """

    # Make the function self-contained to avoid NameError issues
    import os
    import re
    from io import StringIO
    from datetime import datetime
    import pandas as pd
    import numpy as np

    # -------- Robust input handling (dict or DataFrame) --------
    if isinstance(out, dict):
        summary_text = out.get("summary_text") or ""
        df = out.get("filtered_options_df")
        metrics = out.get("metrics") or {}
    elif isinstance(out, pd.DataFrame):
        summary_text = ""
        df = out
        metrics = {}
    else:
        summary_text, df, metrics = "", None, {}

    # -------- Summary line --------
    n_final = None
    mean_spread = None
    holdings = None

    if isinstance(metrics, dict):
        n_final = metrics.get("n_final")

    if n_final is None and isinstance(summary_text, str):
        m = re.search(r"Filtered to\s+(\d+)\s+candidate", summary_text, re.I)
        if m:
            n_final = int(m.group(1))
        m = re.search(r"Mean\s+bid/ask\s+spread\s*:\s*([\d\.]+)\s*% of mid", summary_text, re.I)
        if m:
            mean_spread = m.group(1)
        m = re.search(r"Currently holding\s+(\d+)\s+positions", summary_text, re.I)
        if m:
            holdings = m.group(1)

    parts = ["valuation_summary"]
    if isinstance(n_final, (int, float)):
        parts.append(f"n_final:{int(n_final)}")
    if mean_spread is not None:
        parts.append(f"mean_spread_pct:{mean_spread}")
    if holdings is not None:
        parts.append(f"holdings:{holdings}")
    summary_line = " | ".join(parts)

    # If no DF, write debug file with just the summary and return
    if df is None or getattr(df, "empty", True):
        # try:
        #     os.makedirs("debug_logs", exist_ok=True)
        #     with open(os.path.join("debug_logs", "format_valuation_output.txt"), "w", encoding="utf-8") as f:
        #         f.write(f"[{datetime.utcnow().isoformat()} UTC]\n")
        #         f.write(summary_line)
        #         f.write("\n")
        # except Exception as e:
        #     print(f"[WARN] Could not write debug file: {e}")
        return summary_line

    df = df.copy()

    # -------- Columns (includes premium/theta/pop for LLM visibility) --------
    base_cols = [
        "instrument_name","option_type","expiry","DTE","strike",

        # Pricing
        "mid_price","bid_price","ask_price",

        # POP + premium + theta (if present)
        "POP",
        "theta_usd_per_day",
        "premium_mark_usd",
        "premium_mid_usd",

        "open_interest","volume",
        "qty_max_sell","qty_max_buy","qty",

        # Existing Vega diagnostics
        "vega_bucket_code","vega_bucket_label",
        "share_bucket_now","share_bucket_proj","share_total_now","share_total_proj",
        "eligible_vega",
    ]

    existing = [c for c in base_cols if c in df.columns]

    # spread_pct
    if {"bid_price","ask_price","mid_price"}.issubset(df.columns):
        with pd.option_context("mode.use_inf_as_na", True):
            df["spread_pct"] = ((df["ask_price"] - df["bid_price"]) / df["mid_price"]) * 100.0
    else:
        df["spread_pct"] = np.nan

    final_cols: list[str] = []
    for c in existing:
        final_cols.append(c)
        if c == "ask_price":
            final_cols.append("spread_pct")
    if "spread_pct" not in final_cols:
        final_cols.append("spread_pct")

    # optional notes
    note_keys = [k for k in (extra_note_cols or []) if k in df.columns]
    if note_keys:
        def _mk_notes(row):
            parts = []
            for k in note_keys:
                v = row.get(k)
                # handle NaN / None cleanly
                if v is None:
                    continue
                if isinstance(v, float) and (np.isnan(v)):
                    continue
                parts.append(f"{k}:{v}")
            return "|".join(parts) if parts else ""
        df["notes"] = df[note_keys].apply(lambda r: _mk_notes(r), axis=1)
        final_cols.append("notes")

    # Reorder: preferred columns first, then any extra columns (no dropping)
    keep = [c for c in final_cols if c in df.columns]
    if keep:
        other_cols = [c for c in df.columns if c not in keep]
        df = df[keep + other_cols]

    # -------- Rounding --------
    def _round_series(s: pd.Series, nd: int) -> pd.Series:
        try:
            return pd.to_numeric(s, errors="coerce").round(nd)
        except Exception:
            return s

    for c in ("mid_price","bid_price","ask_price"):
        if c in df:
            df[c] = _round_series(df[c], 5)
    if "spread_pct" in df:
        df["spread_pct"] = _round_series(df["spread_pct"], 3)

    # POP, theta_usd_per_day, premiums
    if "POP" in df:
        df["POP"] = _round_series(df["POP"], 4)
    if "theta_usd_per_day" in df:
        df["theta_usd_per_day"] = _round_series(df["theta_usd_per_day"], 2)
    if "premium_mark_usd" in df:
        df["premium_mark_usd"] = _round_series(df["premium_mark_usd"], 2)
    if "premium_mid_usd" in df:
        df["premium_mid_usd"] = _round_series(df["premium_mid_usd"], 2)

    if "strike" in df:
        try:
            df["strike"] = pd.to_numeric(df["strike"], errors="coerce").round(2)
        except Exception:
            pass
    if "DTE" in df:
        try:
            df["DTE"] = pd.to_numeric(df["DTE"], errors="coerce").round(0).astype("Int64")
        except Exception:
            pass

    for c in ("open_interest","volume","qty_max_sell","qty_max_buy"):
        if c in df:
            try:
                numeric = pd.to_numeric(df[c], errors="coerce")
                # if all numeric are integers, cast to int
                if (numeric.dropna() % 1 == 0).all():
                    df[c] = numeric.astype("Int64")
                else:
                    df[c] = numeric.round(1)
            except Exception:
                pass

    if "qty" in df:
        try:
            df["qty"] = pd.to_numeric(df["qty"], errors="coerce").round(5)
        except Exception:
            pass

    buf = StringIO()
    df.to_csv(buf, index=False)
    csv_text = buf.getvalue().strip()

    result_str = summary_line + "\n" + csv_text


    return result_str
