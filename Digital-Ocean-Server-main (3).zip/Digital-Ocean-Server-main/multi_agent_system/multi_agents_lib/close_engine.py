from __future__ import annotations

import logging
import re
from typing import Any, Dict, List, Optional, Tuple

import numpy as np

from ..Deribit_margin import (
    apply_close_decisions,
    calc_margin_for_positions,
)

from .deribit_client import (
    get_deribit_client,
    margin_explain_from_deribit_result,
    mm_pct,
    snapshot_to_deribit_positions,
)
from .instrument_utils import (
    is_dated_future,
    is_option,
    is_perp,
    parse_symbol_strike,
)
import os
import datetime as dt
from pathlib import Path
import json

from .decision_parsing import extract_first_json_object, validate_decisions
from ..llm_io import LLMError

logger = logging.getLogger(__name__)

CLOSE_ONLY_SPEC = {
    "actions": {"CLOSE", "HOLD"},
    "sides": {"BUY", "SELL"},
    "rights": {"CALL", "PUT"},
    "required": ["symbol", "action", "side", "right"],
}

def _dump_prompt_txt(*, tag: str, system: str, user: str) -> None:
    try:
        out_dir = Path(os.getenv("MODEL_OUTPUT_DIR", "/data")) / "prompt_debug"
        out_dir.mkdir(parents=True, exist_ok=True)
        ts = dt.datetime.utcnow().strftime("%Y-%m-%d_%H-%M-%S")
        path = out_dir / f"{tag}_{ts}.txt"
        path.write_text("===== SYSTEM =====\n" + system + "\n\n===== USER =====\n" + user + "\n", encoding="utf-8")
        logger.info("Saved prompt debug file: %s", str(path))
    except Exception as e:
        logger.warning("Failed to write prompt debug txt: %s", e)

def _build_positions_lines_index(positions_text: str) -> Dict[str, str]:
    out: Dict[str, str] = {}
    if not positions_text:
        return out
    for line in positions_text.splitlines():
        line = line.strip()
        if not line:
            continue
        m = re.search(
            r"\bBTC-\d{1,2}[A-Z]{3}\d{2}-\d+-(?:P|C)\b",
            line,
            flags=re.IGNORECASE,
        )
        if m:
            sym = m.group(0).upper()
            out[sym] = line
    return out


def _extract_first_float(patterns: List[str], text: str) -> Optional[float]:
    if not text:
        return None
    for pat in patterns:
        m = re.search(pat, text, flags=re.IGNORECASE)
        if m:
            try:
                return float(m.group(1))
            except Exception:
                pass
    return None

def run_close_hold_deterministic(
    *,
    positions_text: str,
    positions_side_qty: Dict[str, Dict[str, Any]],
    btc_price: float,
    macro_now: float,
    account_info: Dict[str, Any],
    llm_model_id: str,
    provider: str,
    api_key: Optional[str],
    use_llm: bool,
    margin_snapshot: Optional[Dict[str, Any]] = None,
    currency: str = "BTC",
) -> Tuple[str, List[Dict[str, Any]], float, Dict[str, Any]]:
    """
    Deterministic (no-LLM) Close/Hold engine.

    Returns:
      sentence, validated_decisions, cost(=0.0), mm_im_calc bundle

    Notes:
    - This intentionally does NOT call LLM (keeps your "advisory close engine" behavior).
    - Uses Deribit simulate_portfolio to ensure "closing doesn't increase MM%" exception.
    """
    sentence = (
        "Deterministic CLOSE/HOLD engine (no LLM): closes only when clear profit/risk "
        "criteria met; otherwise holds."
    )

    if not positions_side_qty:
        return sentence, [], 0.0, {"skipped": True, "reason": "no positions_side_qty"}

    # Margin balance (BTC)
    mb_btc = None
    try:
        per = (account_info or {}).get("per_currency") or {}
        if isinstance(per, dict) and "BTC" in per:
            mb_btc = float(per["BTC"].get("margin_balance") or 0.0)
        if not mb_btc:
            mb_btc = float((account_info or {}).get("margin_balance") or 0.0)
    except Exception:
        mb_btc = None

    # Build current positions list for Deribit simulation
    current_positions_list: List[Dict[str, Any]] = []
    if margin_snapshot:
        current_positions_list = snapshot_to_deribit_positions(margin_snapshot)
    else:
        for sym, info in (positions_side_qty or {}).items():
            try:
                qty = float(info.get("qty") or 0.0)
                side = str(info.get("side") or "").upper()
                amt = qty if side == "BUY" else -qty
                if sym:
                    current_positions_list.append({"instrument_name": sym, "amount": amt})
            except Exception:
                continue

    # Baseline sim
    der = get_deribit_client()
    sim_before = None
    mm_before_btc = None
    im_before_btc = None
    mm_before_pct = None

    if der is not None:
        try:
            sim_before = calc_margin_for_positions(der, positions=current_positions_list, currency=currency)
            mm_before_btc = float(sim_before.get("maintenance_margin") or 0.0)
            im_before_btc = float(sim_before.get("initial_margin") or 0.0)
            mm_before_pct = mm_pct(mm_before_btc, mb_btc)
        except Exception as e:
            logger.warning("Baseline Deribit margin simulation failed: %s", e)

    # fallback to account_info percent if available
    if mm_before_pct is None:
        try:
            mm_before_pct = float(account_info.get("current_MM_percent_of_MB"))
        except Exception:
            mm_before_pct = None

    # Parse positions text lines (for pnl% and dte if present)
    line_index = _build_positions_lines_index(positions_text or "")

    decisions: List[Dict[str, Any]] = []

    spot = float(btc_price or 0.0)

    for sym, pos in positions_side_qty.items():
        symu = (sym or "").upper().strip()
        if not symu:
            continue

        side = str(pos.get("side") or "").upper().strip()
        qty = int(pos.get("qty") or 0) or 0
        if qty <= 0:
            continue

        # default hold
        action = "HOLD"

        # Extract pnl_pct and dte from positions_text line if possible
        line = line_index.get(symu, "")
        pnl_pct = _extract_first_float([r"pnl\s*%?\s*[:=]\s*([+-]?\d+(?:\.\d+)?)"], line)
        dte = _extract_first_float([r"\bDTE\s*[:=]\s*([0-9]+(?:\.[0-9]+)?)"], line)

        if is_option(symu):
            strike = parse_symbol_strike(symu)
            # a simple "in-range" heuristic for short options:
            in_range = False
            if strike is not None:
                try:
                    if symu.endswith("-C"):
                        in_range = spot >= 0.97 * strike
                    elif symu.endswith("-P"):
                        in_range = spot <= 1.03 * strike
                except Exception:
                    in_range = False

            # rules:
            # - if profit high -> close
            # - if short and getting in-range near expiry -> close/reduce
            if pnl_pct is not None and pnl_pct >= 50.0:
                action = "CLOSE"
            elif side == "SELL" and dte is not None and dte <= 7 and in_range:
                action = "CLOSE"
            else:
                action = "HOLD"

        elif is_perp(symu) or is_dated_future(symu):
            # futures/perp: conservative, only close if strong profit
            if pnl_pct is not None and pnl_pct >= 50.0:
                action = "CLOSE"
            else:
                action = "HOLD"

        # Build decision row
        right = "CALL" if symu.endswith("-C") else ("PUT" if symu.endswith("-P") else "")
        decisions.append(
            {
                "symbol": symu,
                "action": action,
                "side": side,
                "right": right,
                "quantity": qty,
                "reason": f"{action} decided by deterministic close rules (pnl_pct={pnl_pct}, dte={dte}).",
                "when_to_close": "Close if risk increases or nearing expiry with insufficient premium left.",
            }
        )

    # MM exception rule: If proposed CLOSE increases MM% (Deribit sim), flip all CLOSE->HOLD
    mm_im_calc: Dict[str, Any] = {}
    if der is not None and sim_before is not None and mm_before_pct is not None:
        try:
            close_only = [d for d in decisions if d.get("action") == "CLOSE"]
            after_positions = apply_close_decisions(current_positions_list, close_only)
            sim_after = calc_margin_for_positions(der, positions=after_positions, currency=currency)

            mm_after_btc = float(sim_after.get("maintenance_margin") or 0.0)
            im_after_btc = float(sim_after.get("initial_margin") or 0.0)
            mb_after_btc = float(sim_after.get("margin_balance") or 0.0)
            mm_after_pct = mm_pct(mm_after_btc, mb_btc)

            mm_im_calc = {
                "sim_before": sim_before,
                "sim_after": sim_after,
                "mm_before_btc": mm_before_btc,
                "im_before_btc": im_before_btc,
                "mm_before_pct": mm_before_pct,
                "mm_after_btc": mm_after_btc,
                "im_after_btc": im_after_btc,
                "mb_after_btc": mb_after_btc,
                "mm_after_pct": mm_after_pct,
                "explain_before": margin_explain_from_deribit_result(sim_before),
                "explain_after": margin_explain_from_deribit_result(sim_after),
            }

            if mm_after_pct is not None and mm_after_pct > mm_before_pct:
                # flip all CLOSE -> HOLD
                for d in decisions:
                    if d.get("action") == "CLOSE":
                        d["action"] = "HOLD"
                        d["reason"] = (
                            "HOLD due to MM exception: closing increased MM% in Deribit simulation."
                        )
        except Exception as e:
            logger.warning("MM exception simulation failed: %s", e)

    # Keep only HOLD/CLOSE decisions (already)
    return sentence, decisions, 0.0, mm_im_calc

def build_close_hold_prompt(
    *,
    fundamental_text: str,
    sentiment_text: str,
    strategy: str,
    forcast_messsage: str,
    btc_price: float,
    account_info: dict | None,
    positions_text: str,
    deterministic_text: str,
    mm_cap_pct: float = 75.0,
) -> Tuple[str, str]:
    """
    CLOSE/HOLD LLM prompt (Options only).
    - Default: follow deterministic engine recommendation
    - Override ONLY if emergency / "low probability of recovery" risk is high
    - PERP/Futures: HOLD by policy; do NOT output them
    """
    acc = account_info or {}
    cur = (str(acc.get("currency") or "")).upper() or "BTC"
    idx = float(acc.get("index_price_usd") or 0.0)
    eq_b = float(acc.get("equity") or 0.0)
    im_b = float(acc.get("initial_margin") or 0.0)
    mm_b = float(acc.get("maintenance_margin") or 0.0)
    mb_b = float(acc.get("margin_balance") or 0.0)

    mm_pct_before_close = acc.get("mm_pct_of_mb_before_close", None)
    mm_pct_after_close = acc.get("mm_pct_of_mb_after_close", None)

    def _to_float_or_none(x):
        try:
            return float(x)
        except Exception:
            return None

    mm_pct_before_close = _to_float_or_none(mm_pct_before_close)
    mm_pct_after_close = _to_float_or_none(mm_pct_after_close)

    mm_pct_computed = None
    if mb_b > 0:
        mm_pct_computed = 100.0 * float(mm_b) / float(mb_b)

    # For Close/Hold LLM, baseline is "current/before-close" (it is deciding what to close now).
    # Your pipeline later recomputes after-close via Deribit simulate_portfolio.
    mm_pct_baseline = (
        mm_pct_before_close
        if mm_pct_before_close is not None
        else (mm_pct_computed if mm_pct_computed is not None else 0.0)
    )

    before_txt = f"MM%_before_close={mm_pct_before_close:.2f}%" if mm_pct_before_close is not None else "MM%_before_close=NA"
    after_txt = f"MM%_after_close={mm_pct_after_close:.2f}%" if mm_pct_after_close is not None else "MM%_after_close=NA"

    mm_cap = float(mm_cap_pct)
    mm_buffer_pct = max(1.0, min(5.0, 0.10 * mm_cap))
    mm_target_pct = max(0.0, mm_cap - mm_buffer_pct)

    account_line = (
        f"ACCOUNT: currency={cur}, equity_btc={eq_b:.6f}, IM_btc={im_b:.6f}, MM_btc={mm_b:.6f}, "
        f"margin_balance_btc={mb_b:.6f}, BASELINE_MM%_of_MB(before_close)={mm_pct_baseline:.2f}%, "
        f"{before_txt}, {after_txt}, index_usd={idx:.2f}."
    )

    system = (
        "You are the CLOSE/HOLD DECISION AGENT for a BTC options portfolio on Deribit.\n"
        "You decide ONLY whether to CLOSE or HOLD EXISTING OPTION POSITIONS.\n"
        "You must NOT propose OPEN trades.\n"
        "PERPETUAL/FUTURES are HOLD by policy and must NOT appear in your JSON decisions.\n"
        "Never invent symbols. Only use symbols listed in POSITIONS.\n"
        "Return ONLY valid JSON with keys 'sentence' and 'decisions'. No markdown, no extra text.\n"
    )

    policy = (
        "=== CLOSE/HOLD RULEBOOK (STRICT) ===\n"
        "You are FINAL authority for CLOSE/HOLD on EXISTING OPTION POSITIONS ONLY.\n"
        "PERPETUAL/FUTURES are HOLD by policy and MUST NOT appear in decisions.\n\n"

        "=== OBJECTIVES (ORDERED) ===\n"
        "1) Capital protection: avoid liquidation / margin blow-ups.\n"
        f"2) Respect HARD_MM_CAP_PCT={mm_cap:.1f}% (risk mode when near cap).\n"
        "3) Minimal intervention: close the FEWEST legs possible.\n"
        "4) If not sure, HOLD.\n\n"

        "=== REQUIRED OUTPUT ===\n"
        "- Output exactly ONE decision per EXISTING OPTION symbol shown in POSITIONS.\n"
        "- action ∈ {HOLD, CLOSE} only.\n"
        "- quantity MUST equal the full current qty shown (no partial close).\n"
        "- reason MUST explicitly state:\n"
        "  (a) deterministic recommendation (follow/override), and\n"
        "  (b) why (profit-take / DTE / strike proximity / thesis / margin stress).\n"
        "- when_to_close MUST be specific and not generic.\n\n"

        "=== DETERMINISTIC ENGINE RULES (DEFAULT) ===\n"
        "The deterministic engine already applied these rules. DEFAULT: FOLLOW IT.\n"
        "Rule D1 (Take-profit): If pnl_pct >= +50% -> CLOSE.\n"
        "Rule D2 (Short danger near expiry): If side=SELL AND DTE <= 7 AND option is in/near-range -> CLOSE.\n"
        "Rule D3 (Otherwise): HOLD.\n\n"

        "=== DEFINITIONS (USE THESE) ===\n"
        "- In/near-range heuristic for SHORTS (danger zone):\n"
        "  • Short CALL danger if spot >= 0.97 * strike (spot near/above strike).\n"
        "  • Short PUT  danger if spot <= 1.03 * strike (spot near/below strike).\n"
        "- 'Thesis broken' means forecast/fundamental/sentiment materially contradicts the position direction.\n\n"

        "=== MM EXCEPTION (VERY IMPORTANT) ===\n"
        "Closing can sometimes INCREASE MM% due to portfolio margin offsets.\n"
        "If you are not confident a CLOSE reduces risk materially, prefer HOLD.\n"
        "If BASELINE_MM% is already high, prioritize closing the smallest set of legs that likely reduce MM stress.\n\n"

        "=== WHEN YOU MAY OVERRIDE THE DETERMINISTIC ENGINE (EMERGENCY ONLY) ===\n"
        "You may override ONLY if you believe the position has VERY LOW probability of recovery before expiry\n"
        "OR creates unacceptable tail risk. Only override if at least ONE condition below is clearly true:\n"
        "E1) Near-expiry + deep ITM short option: DTE <= 14 and short option is ITM (or very close) AND forecast suggests continuation against it.\n"
        "E2) Margin emergency: BASELINE_MM% is close to cap AND this leg is a major stress contributor (short, near-range, large qty).\n"
        "E3) Thesis invalidation: strategy/forecast strongly contradicts the position (e.g., short put while strong downside regime expected).\n"
        "E4) Crash-risk asymmetry: short option has convex downside risk (gamma/vega exposure implied by context) and the book cannot tolerate the tail.\n\n"

        "=== OVERRIDE DISCIPLINE ===\n"
        "- Do NOT override just because PnL is negative.\n"
        "- Do NOT mass-close. If emergency exists, close 1–2 highest-risk legs first.\n"
        "- If multiple legs are risky, choose the leg(s) with: (short) + (near-range) + (low DTE) + (largest qty).\n\n"

        "=== OUTPUT SANITY ===\n"
        "- Never output symbols not present in POSITIONS.\n"
        "- Never output BTC-PERPETUAL or futures.\n"
    )
    user = (
        "=== MARKET CONTEXT ===\n"
        f"BTC_USD: {float(btc_price or 0.0):.2f}\n"
        f"{account_line}\n"
        f"HARD_MM_CAP_PCT: {mm_cap:.1f}%\n"
        f"TARGET_MM_PCT: {mm_target_pct:.1f}%\n\n"
        "FUNDAMENTAL VIEW:\n"
        f"{str(fundamental_text).strip()}\n\n"
        "SENTIMENT (X / market):\n"
        f"{str(sentiment_text).strip()}\n\n"
        "STRATEGY (authoritative):\n"
        f"{str(strategy).strip()}\n\n"
        "FORECAST MESSAGE:\n"
        f"{str(forcast_messsage).strip()}\n\n"
        "=== POSITIONS (OPTIONS ONLY) ===\n"
        f"{str(positions_text).strip()}\n\n"
        "=== DETERMINISTIC ENGINE RECOMMENDATION (ADVISORY) ===\n"
        f"{str(deterministic_text).strip()}\n\n"
        f"{policy}\n"
        "=== STRICT JSON FORMAT (NO EXTRA TEXT) ===\n"
        "{\n"
        "  \"sentence\": \"string\",\n"
        "  \"decisions\": [\n"
        "    {\n"
        "      \"symbol\": \"string\",\n"
        "      \"action\": \"CLOSE\" | \"HOLD\",\n"
        "      \"right\": \"CALL\" | \"PUT\",\n"
        "      \"side\": \"BUY\" | \"SELL\",\n"
        "      \"quantity\": <int>,\n"
        "      \"reason\": \"string\",\n"
        "      \"when_to_close\": \"string\"\n"
        "    }\n"
        "  ]\n"
        "}\n"
    )

    return system, user

def run_close_hold_llm_agent(
    *,
    deterministic_decisions: List[Dict[str, Any]],
    fundamental_text: str,
    sentiment_text: str,
    strategy: str,
    forcast_messsage: str,
    btc_price: float,
    account_info: dict | None,
    positions_text: str,
    positions_side_qty: Dict[str, Dict[str, Any]],
    client,
    mm_cap_pct: float = 75.0,
    debug_dump: bool = True,
) -> Tuple[str, List[Dict[str, Any]], float]:
    """
    FINAL Close/Hold authority (Options only).
    - deterministic_decisions are passed as advisory context
    - validates output with CLOSE_ONLY_SPEC and enforces qty/side using positions_side_qty
    - excludes perps by not requiring them (and we will also filter them out)
    """
    # Build advisory deterministic text (compact)
    det_lines = []
    for d in (deterministic_decisions or []):
        sym = str(d.get("symbol") or "").strip().upper()
        act = str(d.get("action") or "").strip().upper()
        if not sym:
            continue
        det_lines.append(f"- {sym}: {act}")
    deterministic_text = "\n".join(det_lines) if det_lines else "(no deterministic recommendations)"

    system, user = build_close_hold_prompt(
        fundamental_text=fundamental_text,
        sentiment_text=sentiment_text,
        strategy=strategy,
        forcast_messsage=forcast_messsage,
        btc_price=btc_price,
        account_info=account_info,
        positions_text=positions_text,
        deterministic_text=deterministic_text,
        mm_cap_pct=float(mm_cap_pct),
    )

    if debug_dump:
        _dump_prompt_txt(tag="close_hold_prompt", system=system, user=user)

    resp = client(
        prompt=system + "\n\n" + user,
        temperature=0.05,
        retries=3,
        request_timeout=300,
        verbose=True,
    )
    cost = float(resp.get("usd_est", 0.0))

    # Parse
    try:
        parsed = json.loads(resp.get("json_str") or "")
    except Exception:
        raw = resp.get("raw", "") or ""
        logger.warning("Close/Hold: primary JSON parse failed; attempting raw extraction…")
        parsed = extract_first_json_object(raw)
        if parsed is None:
            raise LLMError("No valid JSON found in Close/Hold LLM response (after fallback).")

    if not isinstance(parsed, dict):
        raise LLMError("Close/Hold LLM response is not a JSON object.")

    sentence = str(parsed.get("sentence", "") or "").strip()
    decisions_raw = parsed.get("decisions", [])
    if not isinstance(decisions_raw, list):
        decisions_raw = []

    # Filter out perps/futures if LLM mistakenly includes them
    filtered_raw = []
    for r in decisions_raw:
        if not isinstance(r, dict):
            continue
        sym = str(r.get("symbol") or "").strip().upper()
        if "PERPETUAL" in sym or sym.endswith("-PERPETUAL"):
            continue
        # also skip obvious futures symbols if any pattern exists in your book
        filtered_raw.append(r)

    # Validate and enforce full qty/side for existing option symbols
    validated = validate_decisions(
        {"decisions": filtered_raw},
        CLOSE_ONLY_SPEC,
        positions_side_qty=positions_side_qty,
    )

    # Ensure every existing option symbol has a decision (fallback HOLD)
    decided = {str(d.get("symbol") or "").strip().upper() for d in validated}
    for sym, pos in (positions_side_qty or {}).items():
        sym_u = str(sym).strip().upper()
        if sym_u not in decided:
            validated.append({
                "symbol": sym_u,
                "action": "HOLD",
                "right": str(pos.get("right") or "CALL").upper(),
                "side": str(pos.get("side") or "").upper(),
                "quantity": int(pos.get("qty") or 1),
                "reason": "Auto-HOLD fallback (LLM omitted symbol).",
                "when_to_close": "Maintain unless thesis changes or margin stress increases.",
            })

    return sentence, validated, cost

def close_decisions_to_text(
    *,
    close_decisions: List[Dict[str, Any]],
    mm_before_pct: Optional[float] = None,
    mm_after_sim_pct: Optional[float] = None,
    debug_dump: bool = True,
) -> str:
    """
    Convert validated CLOSE/HOLD decisions into STRICT JSON text
    for the final Allocation (OPEN-only) LLM.

    Also saves the generated text to a .txt file for debugging.
    """

    import json
    import os
    from pathlib import Path
    import datetime as dt

    header_lines: List[str] = []
    header_lines.append("=== FINAL CLOSE/HOLD DECISIONS (LOCKED) ===")
    header_lines.append(
        "The following decisions are FINAL and MUST NOT be modified by the Allocation agent."
    )

    if mm_before_pct is not None:
        header_lines.append(f"MM% before close decisions: {mm_before_pct:.2f}%")
    if mm_after_sim_pct is not None:
        header_lines.append(f"MM% after simulated closes: {mm_after_sim_pct:.2f}%")

    header_lines.append("")
    header_lines.append("=== DECISIONS (STRICT JSON FORMAT) ===")

    structured: List[Dict[str, Any]] = []

    for d in (close_decisions or []):
        structured.append(
            {
                "symbol": str(d.get("symbol") or "").strip(),
                "action": str(d.get("action") or "").upper().strip(),
                "right": str(d.get("right") or "").upper().strip(),
                "side": str(d.get("side") or "").upper().strip(),
                "quantity": int(d.get("quantity") or 0),
                "reason": str(d.get("reason") or "").strip(),
                "when_to_close": str(d.get("when_to_close") or "").strip(),
            }
        )

    json_block = json.dumps(structured, indent=2)

    footer = (
        "\n\nRULE: Allocation agent may ONLY OPEN new trades. "
        "It MUST NOT change, remove, or override any CLOSE/HOLD decision above."
    )

    final_text = "\n".join(header_lines) + "\n" + json_block + footer

    # ==============================
    # Save to TXT file (debug)
    # ==============================
    if debug_dump:
        try:
            out_dir = Path(os.getenv("MODEL_OUTPUT_DIR", "/data")) / "prompt_debug"
            out_dir.mkdir(parents=True, exist_ok=True)

            ts = dt.datetime.utcnow().strftime("%Y-%m-%d_%H-%M-%S")
            path = out_dir / f"close_locked_decisions_{ts}.txt"

            path.write_text(final_text, encoding="utf-8")

        except Exception:
            pass

    return final_text



def _mm_pct(mm_btc: float, mb_btc: float) -> Optional[float]:
    try:
        if mb_btc is None or float(mb_btc) == 0.0:
            return None
        return (float(mm_btc) / float(mb_btc)) * 100.0
    except Exception:
        return None

def _safe_float(x: Any) -> Optional[float]:
    try:
        return float(x)
    except Exception:
        return None
    
    
def _extract_portfolio_greeks(sim: Dict[str, Any]) -> Dict[str, Optional[float]]:
    """
    Best-effort greek extraction (Deribit responses vary).
    Mirrors the key-hunting logic you used in MM_test.py.
    :contentReference[oaicite:2]{index=2}
    """
    def pick(keys: List[str]) -> Optional[float]:
        for k in keys:
            if k in sim and sim[k] is not None:
                return _safe_float(sim[k])
        for container_key in ("result", "portfolio", "risk", "greeks"):
            obj = sim.get(container_key)
            if isinstance(obj, dict):
                for k in keys:
                    if k in obj and obj[k] is not None:
                        return _safe_float(obj[k])
        return None

    return {
        "delta": pick(["delta", "portfolio_delta", "total_delta", "delta_total", "net_delta"]),
        "gamma": pick(["gamma", "portfolio_gamma", "total_gamma", "gamma_total", "net_gamma"]),
        "vega":  pick(["vega", "portfolio_vega", "total_vega", "vega_total", "net_vega"]),
    }

def build_simulated_positions_for_closes(
    *,
    positions_side_qty: Dict[str, Dict[str, Any]],
    close_decisions: List[Dict[str, Any]],
) -> Dict[str, float]:
    """
    Build Deribit simulated_positions dict for simulate_portfolio:
      simulated_positions[instrument] += (-current_amount)
    because we want to "virtually close" that position.

    NOTE: we ignore any symbol not found in positions_side_qty (safety).
    """
    simulated: Dict[str, float] = {}

    for d in (close_decisions or []):
        if str(d.get("action") or "").upper().strip() != "CLOSE":
            continue

        sym = str(d.get("symbol") or "").strip()
        if not sym:
            continue

        pos = positions_side_qty.get(sym)
        if not pos:
            # try upper key match
            pos = positions_side_qty.get(sym.upper())
        if not pos:
            continue

        qty = _safe_float(pos.get("qty"))
        if not qty or qty == 0.0:
            continue

        side = str(pos.get("side") or "").upper().strip()
        current_amount = float(qty) if side == "BUY" else -float(qty)

        # To close: add the negative of the current amount
        simulated[sym] = simulated.get(sym, 0.0) + (-current_amount)

    return simulated

def simulate_mm_im_after_close(
    *,
    deribit_client,
    currency: str,
    positions_side_qty: Dict[str, Dict[str, Any]],
    close_decisions: List[Dict[str, Any]],
) -> Dict[str, Any]:
    """
    Uses Deribit private/simulate_portfolio to compute BEFORE vs AFTER-close margin snapshot.

    Returns dict with:
      before: {im, mm, mb, mm_pct, greeks}
      after:  {im, mm, mb, mm_pct, greeks}
      simulated_positions: {...}
      raw_before, raw_after
    """
    currency = (currency or "BTC").upper().strip()

    # BEFORE: baseline portfolio
    base_sim = deribit_client._rpc("private/simulate_portfolio", {"currency": currency, "add_positions": True}) or {}
    base_mm = _safe_float(base_sim.get("maintenance_margin")) or 0.0
    base_im = _safe_float(base_sim.get("initial_margin")) or 0.0
    base_mb = _safe_float(base_sim.get("margin_balance")) or 0.0
    base_mm_pct = _mm_pct(base_mm, base_mb)
    base_g = _extract_portfolio_greeks(base_sim)

    # AFTER: apply simulated positions for closes
    simulated_positions = build_simulated_positions_for_closes(
        positions_side_qty=positions_side_qty,
        close_decisions=close_decisions,
    )

    params: Dict[str, Any] = {"currency": currency, "add_positions": True}
    if simulated_positions:
        params["simulated_positions"] = simulated_positions

    proj_sim = deribit_client._rpc("private/simulate_portfolio", params) or {}

    # Deribit sometimes returns projected_* keys
    proj_mm = _safe_float(proj_sim.get("projected_maintenance_margin"))
    if proj_mm is None:
        proj_mm = _safe_float(proj_sim.get("maintenance_margin")) or 0.0

    proj_im = _safe_float(proj_sim.get("projected_initial_margin"))
    if proj_im is None:
        proj_im = _safe_float(proj_sim.get("initial_margin")) or 0.0

    proj_mb = _safe_float(proj_sim.get("margin_balance")) or 0.0
    proj_mm_pct = _mm_pct(proj_mm, proj_mb)
    proj_g = _extract_portfolio_greeks(proj_sim)

    return {
        "currency": currency,
        "simulated_positions": simulated_positions,
        "before": {
            "initial_margin": base_im,
            "maintenance_margin": base_mm,
            "margin_balance": base_mb,
            "mm_pct_of_mb": base_mm_pct,
            "greeks": base_g,
        },
        "after": {
            "initial_margin": proj_im,
            "maintenance_margin": proj_mm,
            "margin_balance": proj_mb,
            "mm_pct_of_mb": proj_mm_pct,
            "greeks": proj_g,
        },
        "raw_before": base_sim,
        "raw_after": proj_sim,
        "diff": {
            "mm_abs": (proj_mm - base_mm),
            "im_abs": (proj_im - base_im),
            "mb_abs": (proj_mb - base_mb),
            "mm_pct_pp": (proj_mm_pct - base_mm_pct) if (proj_mm_pct is not None and base_mm_pct is not None) else None,
            "delta": (proj_g["delta"] - base_g["delta"]) if (proj_g["delta"] is not None and base_g["delta"] is not None) else None,
            "gamma": (proj_g["gamma"] - base_g["gamma"]) if (proj_g["gamma"] is not None and base_g["gamma"] is not None) else None,
            "vega":  (proj_g["vega"]  - base_g["vega"])  if (proj_g["vega"]  is not None and base_g["vega"]  is not None) else None,
        },
    }