from __future__ import annotations

import json
import logging
import os
import random
from typing import Any, Dict, List, Optional, Tuple

import numpy as np

from ..Deribit_margin import (
    apply_allocation_decisions,
    calc_margin_for_positions,
)

from .deribit_client import get_deribit_client, mm_pct
from .instrument_utils import infer_right_from_symbol, parse_deribit_option_symbol
import datetime as dt
from .decision_parsing import extract_first_json_object

logger = logging.getLogger(__name__)


def _norm_side(side: Any) -> str:
    s = str(side or "").strip().upper()
    if s in ("SHORT", "SELL", "S"):
        return "SELL"
    if s in ("LONG", "BUY", "B"):
        return "BUY"
    return s or "SELL"


def _infer_right(sym: str, right: Any) -> str:
    r = str(right or "").strip().upper()
    if r in ("CALL", "PUT"):
        return r
    inf = infer_right_from_symbol(sym)
    return inf or ""


def _safe_float(x: Any, default: float = 0.0) -> float:
    try:
        return float(x)
    except Exception:
        return default


def build_mm_safe_bundles_greedy(
    *,
    safe_rows: List[Dict[str, Any]],
    mm_cap_pct: float,
    max_legs_per_bundle: int = 4,
    max_bundles: int = 20,
    seed: int = 7,
    debug_path: Optional[str] = None,
) -> List[Dict[str, Any]]:
    """
    Greedy bundling algorithm using already-safe single-leg rows.

    It tries to build multi-leg bundles that remain under MM cap.
    Scoring favors:
      - high theta_eff
      - low abs(mm_pct_delta)

    Returns:
      list of scenarios with scenario_id like BND_01, legs, mm_pct_after, etc.
    """
    if not safe_rows:
        return []

    rnd = random.Random(seed)

    # de-dup by (symbol, qty, side) keeping best theta
    best_by_key: Dict[Tuple[str, int, str], Dict[str, Any]] = {}
    for r in safe_rows:
        sym = str(r.get("symbol") or "").strip().upper()
        qty = int(r.get("quantity") or 1)
        side = _norm_side(r.get("side"))
        key = (sym, qty, side)
        cur = best_by_key.get(key)
        te = _safe_float(r.get("_theta_eff"), 0.0)
        te_cur = _safe_float(cur.get("_theta_eff"), 0.0) if cur else -1e18
        if cur is None or te > te_cur:
            best_by_key[key] = r

    pool = list(best_by_key.values())

    # sort pool by theta desc, then mm_delta asc
    def _score_leg(x):
        te = _safe_float(x.get("_theta_eff"), 0.0)
        md = abs(_safe_float(x.get("mm_delta_btc"), 0.0))
        return (-te, md, str(x.get("symbol") or ""))

    pool.sort(key=_score_leg)

    der = get_deribit_client()
    if der is None:
        logger.warning("Deribit client missing; cannot build bundles.")
        return []

    # baseline is implied by each safe_row's "explanation" already being after adding it,
    # but we still need a baseline positions list in this function to validate combos.
    # Therefore we require each safe_row to carry "positions_after_close" signature? Not available here.
    # In your original code, you built bundles by re-simulating from AFTER-CLOSE positions.
    # We'll keep this function "pure greedy on safe rows" WITHOUT re-simulating combos unless
    # the caller passes debug_path with a baseline signature. For production, prefer generate_mm_acceptable_open_scenarios.
    #
    # => We will build bundles heuristically only (no combo resim) if baseline isn't available.
    # If you want strict combo sim here too, we can extend the signature to accept positions_after_close + currency.

    scenarios: List[Dict[str, Any]] = []
    used_symbols: set[str] = set()

    # heuristic bundle build: combine legs with unique symbols up to max_legs_per_bundle
    for bi in range(1, max_bundles + 1):
        bundle = []
        theta_total = 0.0

        # start from random among top 30
        start_candidates = pool[: min(30, len(pool))]
        if not start_candidates:
            break
        start = rnd.choice(start_candidates)
        sym0 = str(start.get("symbol") or "").upper()
        if sym0 in used_symbols:
            continue
        bundle.append(start)
        used_symbols.add(sym0)
        theta_total += _safe_float(start.get("_theta_eff"), 0.0) * int(start.get("quantity") or 1)

        # add more legs greedily
        for cand in pool:
            if len(bundle) >= max_legs_per_bundle:
                break
            sym = str(cand.get("symbol") or "").upper()
            if not sym or sym in used_symbols:
                continue
            bundle.append(cand)
            used_symbols.add(sym)
            theta_total += _safe_float(cand.get("_theta_eff"), 0.0) * int(cand.get("quantity") or 1)

        legs = []
        for r in bundle:
            legs.append(
                {
                    "symbol": str(r.get("symbol") or "").upper(),
                    "action": "OPEN",
                    "side": _norm_side(r.get("side")),
                    "right": _infer_right(str(r.get("symbol") or ""), r.get("right")),
                    "quantity": int(r.get("quantity") or 1),
                    "POP": r.get("POP"),
                    "_theta_eff": r.get("_theta_eff"),
                }
            )

        scenarios.append(
            {
                "scenario_id": f"BND_{bi:02d}",
                "legs": legs,
                "mm_pct_after": None,  # not simulated here
                "mm_pct_delta": None,
                "_theta_eff_total": theta_total,
                "score": theta_total,
                "explanation": {"note": "Heuristic bundle (no combo simulation). Prefer SCN_* scenarios for strict MM."},
            }
        )

    if debug_path:
        try:
            os.makedirs(debug_path, exist_ok=True)
            with open(os.path.join(debug_path, "bundles_greedy_debug.json"), "w", encoding="utf-8") as f:
                json.dump(scenarios, f, indent=2, default=str)
        except Exception as e:
            logger.warning("Failed writing greedy bundle debug: %s", e)

    return scenarios


def generate_mm_acceptable_open_scenarios(
    *,
    positions_after_close: List[Dict[str, Any]],
    open_candidates: List[Dict[str, Any]],
    mm_cap_pct: float,
    qty_grid: List[int],
    max_candidates: int = 50_000,
    preselect_k: int = 1_000,
    max_atomic_legs_per_side: int = 40,
    max_calls_legs: int = 2,
    max_puts_legs: int = 2,
    currency: str = "BTC",
    seed: int = 7,
    debug_path: Optional[str] = None,
) -> List[Dict[str, Any]]:
    """
    High-performance multi-leg scenario search engine (strict Deribit simulation).

    Steps:
      1) Atomic legs: best leg per symbol (by theta*qty)
      2) Random bundles: cheap heuristic scoring
      3) Preselect top K
      4) True simulate_portfolio for K
      5) Score by theta / mm_delta (or theta*10 if mm_delta<=0)

    Returns list of scenarios:
      {
        scenario_id: SCN_01,
        legs,
        mm_after_btc, im_after_btc, mb_after_btc,
        mm_pct_after, mm_pct_delta,
        score,
        explanation
      }
    """
    der = get_deribit_client()
    if der is None:
        logger.warning("Deribit client missing; cannot generate scenarios.")
        return []

    if not open_candidates:
        return []

    rnd = random.Random(seed)

    # baseline margin after close
    base = calc_margin_for_positions(der, currency=currency, positions=positions_after_close)
    mm0 = float(base.get("maintenance_margin") or 0.0)
    im0 = float(base.get("initial_margin") or 0.0)
    mb0 = float(base.get("margin_balance") or 0.0)
    mm0_pct = mm_pct(mm0, mb0)

    # ---- Build atomic best legs per symbol ----
    best_leg_per_symbol: Dict[str, Dict[str, Any]] = {}

    for c in open_candidates:
        sym = str(c.get("symbol") or c.get("instrument_name") or "").strip().upper()
        if not sym:
            continue

        side = _norm_side(c.get("side"))
        right = _infer_right(sym, c.get("right"))
        te = _safe_float(c.get("_theta_eff"), 0.0)

        for q in qty_grid:
            leg = {
                "symbol": sym,
                "action": "OPEN",
                "side": side,
                "right": right,
                "quantity": int(q),
                "POP": c.get("POP"),
                "_theta_eff": c.get("_theta_eff"),
            }
            score = te * int(q)
            cur = best_leg_per_symbol.get(sym)
            cur_score = _safe_float(cur.get("_theta_eff_total"), -1e18) if cur else -1e18
            if cur is None or score > cur_score:
                leg["_theta_eff_total"] = score
                best_leg_per_symbol[sym] = leg

    atomic = list(best_leg_per_symbol.values())

    # cap per side
    calls = [a for a in atomic if (a.get("right") == "CALL")]
    puts = [a for a in atomic if (a.get("right") == "PUT")]

    calls.sort(key=lambda x: -_safe_float(x.get("_theta_eff_total"), 0.0))
    puts.sort(key=lambda x: -_safe_float(x.get("_theta_eff_total"), 0.0))

    calls = calls[:max_atomic_legs_per_side]
    puts = puts[:max_atomic_legs_per_side]

    # ---- Generate random candidate bundles ----
    candidates = []
    for _ in range(max_candidates):
        n_calls = rnd.randint(1, max_calls_legs)
        n_puts = rnd.randint(1, max_puts_legs)

        legs = []
        if calls:
            legs.extend(rnd.sample(calls, k=min(n_calls, len(calls))))
        if puts:
            legs.extend(rnd.sample(puts, k=min(n_puts, len(puts))))

        # ensure unique symbols in bundle
        seen = set()
        uniq = []
        for l in legs:
            s = l["symbol"]
            if s in seen:
                continue
            seen.add(s)
            uniq.append(l)
        legs = uniq

        theta_total = sum(_safe_float(l.get("_theta_eff_total"), 0.0) for l in legs)
        candidates.append((theta_total, legs))

    # preselect top K by theta
    candidates.sort(key=lambda x: -x[0])
    candidates = candidates[: min(preselect_k, len(candidates))]

    # cache by positions signature to reduce calls
    cache: Dict[str, Dict[str, Any]] = {}

    scenarios = []
    for idx, (theta_total, legs) in enumerate(candidates, start=1):
        if not legs:
            continue

        # signature
        sig = "|".join(sorted([f"{l['symbol']}:{l['side']}:{l['quantity']}" for l in legs]))
        if sig in cache:
            sim = cache[sig]
        else:
            new_positions = apply_allocation_decisions(positions_after_close, legs)
            sim = calc_margin_for_positions(der, currency=currency, positions=new_positions)
            cache[sig] = sim

        mm1 = float(sim.get("maintenance_margin") or 0.0)
        im1 = float(sim.get("initial_margin") or 0.0)
        mb1 = float(sim.get("margin_balance") or 0.0)
        mm1_pct = mm_pct(mm1, mb1)

        if mm1_pct is None or mm1_pct > float(mm_cap_pct):
            continue

        mm_delta = mm1 - mm0
        if mm_delta <= 0:
            score = theta_total * 10.0
        else:
            score = theta_total / mm_delta

        scenarios.append(
            {
                "scenario_id": f"SCN_{idx:02d}",
                "legs": legs,
                "mm_after_btc": mm1,
                "im_after_btc": im1,
                "mb_after_btc": mb1,
                "mm_pct_after": mm1_pct,
                "mm_pct_delta": (None if mm0_pct is None else (mm1_pct - mm0_pct)),
                "_theta_eff_total": theta_total,
                "score": score,
                "explanation": sim,
            }
        )

    # sort by score desc
    scenarios.sort(key=lambda s: -_safe_float(s.get("score"), 0.0))

    if debug_path:
        try:
            os.makedirs(debug_path, exist_ok=True)
            with open(os.path.join(debug_path, "open_scenarios_debug.json"), "w", encoding="utf-8") as f:
                json.dump(scenarios, f, indent=2, default=str)
        except Exception as e:
            logger.warning("Failed writing scenarios debug: %s", e)

    return scenarios


def build_open_context_from_scenarios(
    scenarios: List[Dict[str, Any]],
    *,
    require_calls_and_puts: bool = False,
    max_lines: int = 100,
) -> str:
    """
    Converts scenario list -> LLM context.

    Enforces in prompt:
      - Must choose ONE scenario_id
      - Cannot invent symbols
      - Bundles already MM-cap safe (for SCN_* outputs)
    """
    if not scenarios:
        return "No MM-safe multi-leg scenarios."

    lines = []
    lines.append("=== MM-SAFE MULTI-LEG SCENARIOS ===")
    lines.append("Pick ONE scenario_id. Do NOT invent symbols or quantities.")
    lines.append("If multiple new positions, choose ONE scenario.")
    if require_calls_and_puts:
        lines.append("Chosen scenario MUST include at least one CALL and one PUT.")
    lines.append("")

    for s in scenarios[:max_lines]:
        sid = s.get("scenario_id")
        legs = s.get("legs") or []
        mm_p = s.get("mm_pct_after")
        mm_d = s.get("mm_pct_delta")
        te = s.get("_theta_eff_total")
        n = len(legs)

        # pretty legs snippet
        leg_bits = []
        for l in legs:
            leg_bits.append(
                f"{l.get('right')} {l.get('side')} {l.get('symbol')} qty={l.get('quantity')}"
            )
        legs_s = " | ".join(leg_bits)

        line = f"{sid} | legs={n}"
        if mm_p is not None:
            line += f" | MM%={float(mm_p):.2f}%"
        if mm_d is not None:
            line += f" ({float(mm_d):+.2f}%)"
        if te is not None:
            line += f" | theta_eff_total={float(te):.3f}"
        line += " | " + legs_s
        lines.append(line)

    if len(scenarios) > max_lines:
        lines.append(f"... truncated: showing {max_lines} of {len(scenarios)} scenarios")

    return "\n".join(lines)


def build_open_context_from_mm_grid_and_bundles(
    *,
    safe_rows: List[Dict[str, Any]],
    bundles: List[Dict[str, Any]],
    max_bundle_lines: int = 50,
    max_single_lines: int = 150,
) -> str:
    """
    Produces the final OPEN context:
      A) BUNDLES
      B) SINGLE-LEG SAFE choices

    Hard constraints:
      - Don’t invent symbols/qty
      - If multiple new positions -> pick ONE bundle
      - Else pick at most ONE single-leg
    """
    lines = []
    lines.append("=== OPEN CONTEXT (MM-GATED) ===")
    lines.append("You MUST NOT invent symbols or quantities. Choose ONLY from allowed items below.")
    lines.append("If opening multiple legs, pick exactly ONE bundle (BND_* or SCN_*).")
    lines.append("Otherwise, pick at most ONE single-leg.")
    lines.append("")

    if bundles:
        lines.append("---- BUNDLES ----")
        for b in bundles[:max_bundle_lines]:
            sid = b.get("scenario_id")
            te = b.get("_theta_eff_total")
            mm_p = b.get("mm_pct_after")
            legs = b.get("legs") or []
            leg_bits = []
            for l in legs:
                leg_bits.append(f"{l.get('right')} {l.get('side')} {l.get('symbol')} qty={l.get('quantity')}")
            legs_s = " | ".join(leg_bits)
            head = f"{sid}"
            if mm_p is not None:
                head += f" | MM%={float(mm_p):.2f}%"
            if te is not None:
                head += f" | theta_eff_total={float(te):.3f}"
            lines.append(head + " | " + legs_s)
        lines.append("")

    if safe_rows:
        lines.append("---- SINGLE-LEG MM-SAFE ----")
        # sort: lowest mm_pct_after then highest theta
        def _k(r):
            mm_p = r.get("mm_pct_after")
            try:
                mm_p = float(mm_p) if mm_p is not None else 1e9
            except Exception:
                mm_p = 1e9
            te = r.get("_theta_eff")
            try:
                te = float(te) if te is not None else -1e9
            except Exception:
                te = -1e9
            return (mm_p, -te)

        rows = sorted(safe_rows, key=_k)
        for r in rows[:max_single_lines]:
            sym = str(r.get("symbol") or "").upper()
            side = _norm_side(r.get("side"))
            right = _infer_right(sym, r.get("right"))
            qty = int(r.get("quantity") or 1)
            mm_p = r.get("mm_pct_after")
            te = r.get("_theta_eff")
            line = f"{sym} | {right} {side} qty={qty}"
            if mm_p is not None:
                line += f" | MM%={float(mm_p):.2f}%"
            if te is not None:
                line += f" | theta_eff={float(te):.4f}"
            lines.append(line)

        if len(rows) > max_single_lines:
            lines.append(f"... truncated: showing {max_single_lines} of {len(rows)} singles")

    if not bundles and not safe_rows:
        lines.append("No MM-safe options available.")

    return "\n".join(lines)


def scenario_id_to_open_legs(
    *,
    open_scenarios: List[Dict[str, Any]],
    scenario_id: str,
) -> List[Dict[str, Any]]:
    """
    Map scenario_id to its OPEN legs (normalized).
    """
    sid = (scenario_id or "").strip().upper()
    for s in (open_scenarios or []):
        if str(s.get("scenario_id") or "").strip().upper() == sid:
            legs = s.get("legs") or []
            out = []
            for l in legs:
                sym = str(l.get("symbol") or "").strip().upper()
                if not sym:
                    continue
                out.append(
                    {
                        "symbol": sym,
                        "action": "OPEN",
                        "side": _norm_side(l.get("side")),
                        "right": _infer_right(sym, l.get("right")),
                        "quantity": int(l.get("quantity") or 1),
                        "POP": l.get("POP"),
                        "_theta_eff": l.get("_theta_eff"),
                    }
                )
            return out
    return []


def normalize_bundle_id(x: Any) -> str:
    """
    Accepts:
      - "BND_02", "SCN_03" -> keep
      - "2" -> BND_02
      - 2 -> BND_02
    """
    if x is None:
        return ""
    s = str(x).strip().upper()
    if s.startswith("BND_") or s.startswith("SCN_"):
        return s
    # numeric -> BND
    try:
        n = int(float(s))
        return f"BND_{n:02d}"
    except Exception:
        return s


# =========================
# OPEN LLM Selector + MM Sim + Text Formatter
# =========================

def _dump_txt(*, tag: str, content: str) -> None:
    try:
        out_dir = os.path.join(os.getenv("MODEL_OUTPUT_DIR", "/data"), "prompt_debug")
        os.makedirs(out_dir, exist_ok=True)
        ts = dt.datetime.utcnow().strftime("%Y-%m-%d_%H-%M-%S")
        path = os.path.join(out_dir, f"{tag}_{ts}.txt")
        with open(path, "w", encoding="utf-8") as f:
            f.write(content)
    except Exception:
        pass


def build_open_selector_prompt(
    *,
    fundamental_text: str,
    sentiment_text: str,
    strategy: str,
    forcast_messsage: str,
    btc_price: float,
    account_info: Dict[str, Any] | None,
    close_locked_text: str,
    open_context_txt: str,
    mm_cap_pct: float = 75.0,
) -> Tuple[str, str]:
    """
    Prompt for OPEN selector LLM.
    - Chooses ONE scenario_id (SCN_*) or NONE (STRICT ONLY)
    - Does NOT touch CLOSE/HOLD (already locked)
    """
    acc = account_info or {}
    cur = (str(acc.get("currency") or "")).upper() or "BTC"
    idx = float(acc.get("index_price_usd") or 0.0)

    # This account_info should be AFTER-CLOSE baseline snapshot from pipeline
    mb_b = float(acc.get("margin_balance") or 0.0)
    mm_b = float(acc.get("maintenance_margin") or 0.0)
    mm_pct_after_close = None
    try:
        mm_pct_after_close = float(acc.get("mm_pct_of_mb_after_close"))
    except Exception:
        mm_pct_after_close = None
    if mm_pct_after_close is None:
        try:
            if mb_b > 0:
                mm_pct_after_close = 100.0 * mm_b / mb_b
        except Exception:
            mm_pct_after_close = 0.0

    mm_cap = float(mm_cap_pct)
    mm_buffer_pct = max(1.0, min(5.0, 0.10 * mm_cap))
    mm_target_pct = max(0.0, mm_cap - mm_buffer_pct)

    account_line = (
        f"ACCOUNT(after_close baseline): currency={cur}, "
        f"margin_balance_btc={mb_b:.6f}, MM_btc={mm_b:.6f}, "
        f"BASELINE_MM%_of_MB(after_close)={float(mm_pct_after_close or 0.0):.2f}%, "
        f"index_usd={idx:.2f}."
    )

    system = (
        "You are the OPEN SCENARIO SELECTION AGENT for a BTC options portfolio on Deribit.\n"
        "CLOSE/HOLD decisions are already FINAL and LOCKED.\n"
        "Your ONLY job is to pick the best ONE open scenario_id to OPEN now, or pick NONE.\n"
        "You must NOT output any CLOSE or HOLD actions.\n"
        "Never invent symbols: you may ONLY choose from the OPEN CONTEXT scenarios.\n"
        f"Hard rule: keep projected MM% <= {mm_cap:.1f}%.\n"
        f"Target ~{mm_target_pct:.1f}% to keep buffer.\n"
        "Return ONLY JSON with keys: 'sentence' and 'chosen_open_scenario_id'.\n"
        "No markdown, no extra text."
    )

    user = (
        "=== MARKET CONTEXT ===\n"
        f"BTC_USD: {float(btc_price or 0.0):.2f}\n"
        f"{account_line}\n"
        f"HARD_MM_CAP_PCT: {mm_cap:.1f}%\n"
        f"TARGET_MM_PCT: {mm_target_pct:.1f}%\n\n"
        "FUNDAMENTAL VIEW:\n"
        f"{str(fundamental_text).strip()}\n\n"
        "SENTIMENT (X / market):\n"
        f"{str(sentiment_text).strip()}\n\n"
        "STRATEGY (authoritative):\n"
        f"{str(strategy).strip()}\n\n"
        "FORECAST MESSAGE:\n"
        f"{str(forcast_messsage).strip()}\n\n"
        f"{str(close_locked_text).strip()}\n\n"
        "=== OPEN CONTEXT (CHOOSE ONE SCENARIO OR NONE) ===\n"
        f"{str(open_context_txt).strip()}\n\n"
        "=== RULES ===\n"
        "- Choose exactly ONE: a scenario_id shown above (SCN_*), OR 'NONE'.\n"
        "- You are NOT allowed to choose BND_* (bundles are not strictly simulated).\n"
        "- Prefer higher theta_eff_total with lower MM% (more buffer).\n"
        "- If baseline MM% is near the cap, pick NONE unless the chosen scenario is clearly margin-efficient.\n\n"
        "=== STRICT JSON FORMAT (NO EXTRA TEXT) ===\n"
        "{\n"
        "  \"sentence\": \"string\",\n"
        "  \"chosen_open_scenario_id\": \"SCN_01\" | \"NONE\"\n"
        "}\n"
    )

    return system, user


def run_open_selector_llm(
    *,
    fundamental_text: str,
    sentiment_text: str,
    strategy: str,
    forcast_messsage: str,
    btc_price: float,
    account_info: Dict[str, Any] | None,
    close_locked_text: str,
    open_context_txt: str,
    client,
    mm_cap_pct: float = 75.0,
    debug_dump: bool = True,
) -> Tuple[str, str, float]:
    """
    Calls LLM to pick ONE scenario_id or NONE.
    Returns: sentence, chosen_open_scenario_id, cost_usd
    """
    system, user = build_open_selector_prompt(
        fundamental_text=fundamental_text,
        sentiment_text=sentiment_text,
        strategy=strategy,
        forcast_messsage=forcast_messsage,
        btc_price=btc_price,
        account_info=account_info,
        close_locked_text=close_locked_text,
        open_context_txt=open_context_txt,
        mm_cap_pct=float(mm_cap_pct),
    )

    if debug_dump:
        _dump_txt(tag="open_selector_prompt", content="===== SYSTEM =====\n" + system + "\n\n===== USER =====\n" + user + "\n")

    resp = client(
        prompt=system + "\n\n" + user,
        temperature=0.05,
        retries=3,
        request_timeout=300,
        verbose=True,
    )
    cost = float(resp.get("usd_est", 0.0))

    try:
        parsed = json.loads(resp.get("json_str") or "")
    except Exception:
        raw = resp.get("raw", "") or ""
        logger.warning("Open selector: primary JSON parse failed; attempting raw extraction…")
        parsed = extract_first_json_object(raw)
        if parsed is None:
            raise RuntimeError("No valid JSON found in Open selector response.")

    if not isinstance(parsed, dict):
        raise RuntimeError("Open selector response is not a JSON object.")

    sentence = str(parsed.get("sentence") or "").strip()
    chosen = str(parsed.get("chosen_open_scenario_id") or "NONE").strip().upper()
    if not chosen:
        chosen = "NONE"

    # STRICT ONLY: allow only SCN_* or NONE
    if chosen != "NONE" and not chosen.startswith("SCN_"):
        logger.warning("Open selector returned non-strict id=%s; forcing NONE.", chosen)
        chosen = "NONE"

    return sentence, chosen, cost


def simulate_mm_im_after_open(
    *,
    positions_after_close: List[Dict[str, Any]],
    open_legs: List[Dict[str, Any]],
    currency: str = "BTC",
) -> Dict[str, Any]:
    """
    Strict MM/IM simulation AFTER opening a chosen scenario.
    Uses existing calc_margin_for_positions() (Deribit endpoint under the hood).

    Returns a bundle:
      before: margins for positions_after_close
      after:  margins for positions_after_close + open_legs
      diff:   deltas
    """
    der = get_deribit_client()
    if der is None:
        return {"skipped": True, "reason": "deribit_client_missing"}

    base = calc_margin_for_positions(der, currency=currency, positions=positions_after_close)
    mm0 = float(base.get("maintenance_margin") or 0.0)
    im0 = float(base.get("initial_margin") or 0.0)
    mb0 = float(base.get("margin_balance") or 0.0)
    mm0_pct = mm_pct(mm0, mb0)

    new_positions = apply_allocation_decisions(positions_after_close, open_legs)
    sim = calc_margin_for_positions(der, currency=currency, positions=new_positions)
    mm1 = float(sim.get("maintenance_margin") or 0.0)
    im1 = float(sim.get("initial_margin") or 0.0)
    mb1 = float(sim.get("margin_balance") or 0.0)
    mm1_pct = mm_pct(mm1, mb1)

    return {
        "currency": (currency or "BTC").upper(),
        "before": {
            "initial_margin": im0,
            "maintenance_margin": mm0,
            "margin_balance": mb0,
            "mm_pct_of_mb": mm0_pct,
        },
        "after": {
            "initial_margin": im1,
            "maintenance_margin": mm1,
            "margin_balance": mb1,
            "mm_pct_of_mb": mm1_pct,
        },
        "diff": {
            "im_abs": (im1 - im0),
            "mm_abs": (mm1 - mm0),
            "mb_abs": (mb1 - mb0),
            "mm_pct_pp": (mm1_pct - mm0_pct) if (mm1_pct is not None and mm0_pct is not None) else None,
        },
        "raw_before": base,
        "raw_after": sim,
    }


def open_legs_to_text(
    *,
    chosen_open_scenario_id: str,
    open_legs: List[Dict[str, Any]],
    mm_bundle: Optional[Dict[str, Any]] = None,
    debug_dump: bool = True,
) -> str:
    """
    Strict JSON text block for OPEN legs (to feed the final Allocation agent or logging).

    Schema per leg (same style as your system):
      {
        "symbol": "string",
        "action": "OPEN",
        "right": "CALL" | "PUT",
        "side": "BUY" | "SELL",
        "quantity": <int>,
        "reason": "string",
        "when_to_close": "string"
      }
    """
    import datetime as dt
    import json

    head = []
    head.append("=== FINAL OPEN DECISION (LOCKED BY OPEN SELECTOR) ===")
    head.append(f"chosen_open_scenario_id: {str(chosen_open_scenario_id or 'NONE').strip().upper()}")
    if mm_bundle and isinstance(mm_bundle, dict) and "after" in mm_bundle:
        try:
            mm_after = mm_bundle["after"].get("mm_pct_of_mb")
            if mm_after is not None:
                head.append(f"Projected MM% after open: {float(mm_after):.2f}%")
        except Exception:
            pass
    head.append("")
    head.append("=== DECISIONS (STRICT JSON FORMAT) ===")

    structured: List[Dict[str, Any]] = []
    for l in (open_legs or []):
        sym = str(l.get("symbol") or "").strip().upper()
        structured.append(
            {
                "symbol": sym,
                "action": "OPEN",
                "right": str(l.get("right") or "").strip().upper(),
                "side": _norm_side(l.get("side")),
                "quantity": int(l.get("quantity") or 1),
                "reason": str(l.get("reason") or "Selected from MM-gated scenario.").strip(),
                "when_to_close": str(l.get("when_to_close") or "Entry now; manage by premium targets, DTE, and MM stress.").strip(),
            }
        )

    text = "\n".join(head) + "\n" + json.dumps(structured, indent=2)

    if debug_dump:
        _dump_txt(tag="open_locked_decisions", content=text)

    return text


