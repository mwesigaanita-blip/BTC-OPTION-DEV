from __future__ import annotations

import logging


def setup_cli_logging(force: bool = True) -> None:
    """
    Force logs to stdout when running multi_agents.py directly.

    - force=True ensures you ALWAYS see logs, even if other code configured logging weirdly.
    """
    import sys

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
        handlers=[logging.StreamHandler(sys.stdout)],
        force=force,
    )
