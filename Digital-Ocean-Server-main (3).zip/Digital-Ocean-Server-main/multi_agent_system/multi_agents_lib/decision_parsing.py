from __future__ import annotations

import json
import logging
from typing import Any, Dict, List, Optional, Union
import re
from typing import Optional, List

logger = logging.getLogger(__name__)


def sanitize_for_console(s: str) -> str:
    if not isinstance(s, str):
        return s
    # Replace Unicode minus with ASCII minus; extend if needed.
    return s.replace("\u2212", "-")


def norm_decisions(x: Any) -> List[Dict[str, Any]]:
    """
    Normalize common LLM outputs into a list[dict].
    - {"decisions":[...]} -> [...]
    - [...] -> [...]
    - otherwise -> []
    """
    if isinstance(x, dict) and "decisions" in x and isinstance(x["decisions"], list):
        return [d for d in x["decisions"] if isinstance(d, dict)]
    if isinstance(x, list):
        return [d for d in x if isinstance(d, dict)]
    return []


def extract_first_json_object(text: str) -> Union[dict, list, None]:
    """
    Scan `text` and extract the first balanced top-level JSON object or array.
    Ignores code fences and leading noise. Returns parsed Python object or None.
    """
    if not text:
        return None
    t = text.strip()
    if t.startswith("```"):
        t = t.strip("` \n")

    start_obj = t.find("{")
    start_arr = t.find("[")

    # Prefer earliest valid start among { and [
    if start_obj == -1 and start_arr == -1:
        return None

    if start_arr != -1 and (start_obj == -1 or start_arr < start_obj):
        # array path: try from first '[' to end
        try:
            return json.loads(t[start_arr:])
        except Exception:
            return None

    # object path: balanced brace scan
    start = start_obj
    depth = 0
    for i in range(start, len(t)):
        ch = t[i]
        if ch == "{":
            depth += 1
        elif ch == "}":
            depth -= 1
            if depth == 0:
                candidate = t[start : i + 1]
                try:
                    return json.loads(candidate)
                except Exception:
                    return None
    return None


def validate_decisions(
    parsed: Any,
    spec: Dict[str, Any],
    positions_side_qty: Optional[Dict[str, Dict[str, Any]]] = None,
) -> List[Dict[str, Any]]:
    """
    Validation that does NOT check POP and does NOT drop rows due to POP or missing optional fields.

    The ONLY reasons a row may be rejected:
      • The row is not a dict.
      • Missing or invalid action.
      • Missing or invalid right.
      • Missing or invalid side (unless overridden by positions).
      • Missing required structural fields such as symbol/action.

    All text fields (reason, when_to_close) are auto-filled if missing.
    Quantity is auto-fixed to >= 1.

    spec shape expected:
      {
        "actions": {...},
        "sides": {...},
        "rights": {...},
        "required": [...]
      }
    """
    # LLM may wrap dict inside {"decisions": [...]}
    if isinstance(parsed, dict) and "decisions" in parsed:
        parsed = parsed["decisions"]

    out: List[Dict[str, Any]] = []
    sides_ok = spec.get("sides") or set()
    rights_ok = spec.get("rights") or set()
    required = spec.get("required") or []

    # Aliases the model sometimes outputs
    side_alias = {
        "BUY": "BUY",
        "SELL": "SELL",
        "B": "BUY",
        "S": "SELL",
        "LONG": "BUY",
        "SHORT": "SELL",
    }
    right_alias = {"CALL": "CALL", "PUT": "PUT", "C": "CALL", "P": "PUT"}

    rejects: List[str] = []

    for i, row in enumerate(parsed or []):
        if not isinstance(row, dict):
            rejects.append("not a dict")
            continue

        symbol = str(row.get("symbol", "")).strip()
        action = str(row.get("action", "")).upper().strip()
        side_in = str(row.get("side", "")).upper().strip()
        right_in = str(row.get("right", "")).upper().strip()

        # Infer CALL/PUT from symbol name if missing
        if not right_in and symbol.upper().endswith("-C"):
            right_in = "CALL"
        elif not right_in and symbol.upper().endswith("-P"):
            right_in = "PUT"

        side = side_alias.get(side_in, side_in)
        right = right_alias.get(right_in, right_in)

        # If validating CLOSE/HOLD: side & qty come from existing positions
        qty_from_pos = None
        if positions_side_qty and symbol in positions_side_qty:
            pos = positions_side_qty[symbol]
            side = str(pos.get("side", side or "")).upper().strip() or side
            qty_from_pos = pos.get("qty", None)

        # Structural validation only
        if action not in (spec.get("actions") or set()):
            rejects.append(f"invalid action {action}")
            continue

        if side not in sides_ok:
            rejects.append(f"invalid side {side_in}")
            continue

        if right not in rights_ok:
            rejects.append(f"invalid right {right_in}")
            continue

        missing = [k for k in required if row.get(k) in (None, "", [])]
        if missing:
            rejects.append(f"missing {missing}")
            continue

        clean: Dict[str, Any] = {
            "symbol": symbol,
            "action": action,
            "right": right,
            "side": side,
        }

        # POP optional (OPEN only)
        if action == "OPEN" and row.get("POP") not in (None, "", []):
            try:
                clean["POP"] = float(row.get("POP"))
            except Exception:
                clean["POP"] = row.get("POP")

        # Quantity
        if qty_from_pos is not None:
            try:
                clean["quantity"] = int(qty_from_pos)
            except Exception:
                clean["quantity"] = 1
        else:
            try:
                clean["quantity"] = max(1, int(row.get("quantity", 1)))
            except Exception:
                clean["quantity"] = 1

        # Auto-fill missing reason
        reason_raw = str(row.get("reason", "")).strip()
        if not reason_raw:
            reason_raw = (
                f"{action} {symbol}: auto-placeholder reason. "
                "LLM did not provide a reason."
            )
        clean["reason"] = " ".join(reason_raw.split())

        # Auto-fill missing when_to_close
        wtc_raw = str(row.get("when_to_close", "")).strip()
        if not wtc_raw:
            wtc_raw = (
                "Close if macro turns adverse, risk increases, "
                "or nearing expiry with insufficient premium left."
            )
        wtc_first_line = wtc_raw.splitlines()[0]
        clean["when_to_close"] = " ".join(wtc_first_line.split())

        # btc_price optional
        bp = row.get("btc_price")
        try:
            clean["btc_price"] = float(bp)
        except Exception:
            pass

        out.append(clean)

    if rejects:
        logger.warning(
            "Validator dropped %d row(s): %s",
            len(rejects),
            ", ".join(sorted(set(rejects)))[:300],
        )

    return out



def extract_first_float(patterns: List[str], text: str) -> Optional[float]:
    if not text:
        return None
    for pat in patterns:
        m = re.search(pat, text, flags=re.IGNORECASE)
        if m:
            try:
                return float(m.group(1))
            except Exception:
                pass
    return None

def extract_first_int(patterns: List[str], text: str) -> Optional[int]:
    v = extract_first_float(patterns, text)
    if v is None:
        return None
    try:
        return int(round(v))
    except Exception:
        return None
