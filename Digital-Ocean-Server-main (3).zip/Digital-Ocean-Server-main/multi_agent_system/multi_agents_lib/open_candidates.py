from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

import numpy as np
import pandas as pd

from .instrument_utils import infer_right_from_symbol


logger = logging.getLogger(__name__)


def _pick_symbol_col(df: pd.DataFrame) -> str:
    for c in ("symbol", "instrument_name"):
        if c in df.columns:
            return c
    return "symbol"


def build_open_candidates_from_valuation_df(
    valuation_df: Optional[pd.DataFrame],
    *,
    default_qty: int = 1,
) -> List[Dict[str, Any]]:
    """
    Transform filtered valuation dataframe -> OPEN candidate dict list.

    Output per candidate:
      {
        symbol,
        instrument_name,
        action="OPEN",
        side="BUY"/"SELL",
        right,
        quantity,
        POP,
        _theta_eff
      }
    """
    if valuation_df is None or getattr(valuation_df, "empty", True):
        return []

    df = valuation_df.copy()
    sym_col = _pick_symbol_col(df)

    out: List[Dict[str, Any]] = []

    for _, r in df.iterrows():
        sym = str(r.get(sym_col) or "").strip().upper()
        if not sym:
            continue

        # eligibility gating: if "eligible" exists, require eligible==1
        if "eligible" in df.columns:
            try:
                if int(r.get("eligible") or 0) != 1:
                    continue
            except Exception:
                continue

        # side normalization (default SELL if not specified)
        side_raw = str(r.get("side") or r.get("direction") or "SELL").strip().upper()
        if side_raw in ("SHORT", "S", "SELL"):
            side = "SELL"
        elif side_raw in ("LONG", "B", "BUY"):
            side = "BUY"
        else:
            side = "SELL"

        right = str(r.get("right") or "").strip().upper()
        if not right:
            inferred = infer_right_from_symbol(sym)
            if inferred:
                right = inferred

        # POP
        pop = r.get("POP")
        try:
            pop = float(pop) if pop not in (None, "", []) else None
        except Exception:
            pass

        # theta_eff: best-effort from common columns
        theta_eff = None
        for k in ("_theta_eff", "theta_eff", "theta_usd_per_day", "theta_per_day"):
            if k in df.columns and r.get(k) not in (None, "", []):
                theta_eff = r.get(k)
                break

        try:
            theta_eff = float(theta_eff) if theta_eff not in (None, "", []) else None
        except Exception:
            pass

        qty = r.get("quantity")
        try:
            qty_i = int(qty) if qty not in (None, "", []) else int(default_qty)
        except Exception:
            qty_i = int(default_qty)
        qty_i = max(1, qty_i)

        out.append(
            {
                "symbol": sym,
                "instrument_name": sym,
                "action": "OPEN",
                "side": side,
                "right": right,
                "quantity": qty_i,
                "POP": pop,
                "_theta_eff": theta_eff,
            }
        )

    return out


def ref_mm_per_contract_btc_calc(
    *,
    df_live: Optional[pd.DataFrame],
    margin_estimator=None,
    percentile: float = 0.75,
) -> float:
    """
    Samples live options to estimate reference MM per 1 contract (BTC).
    Filters by:
      - mark price valid
      - DTE 10–60
      - OI >= 10
      - |delta| between 0.1–0.4

    Two modes:
      - with margin_estimator: true simulate-based ΔMM
      - without: heuristic 1.2*premium + 0.003

    Returns percentile-based MM delta. Fallback: 0.02
    """
    if df_live is None or getattr(df_live, "empty", True):
        return 0.02

    df = df_live.copy()

    # defensive column names
    def _col(*names):
        for n in names:
            if n in df.columns:
                return n
        return None

    c_sym = _col("symbol", "instrument_name")
    c_mark = _col("mark_price_btc", "mark_price")
    c_dte = _col("dte", "DTE")
    c_oi = _col("open_interest", "oi")
    c_delta = _col("delta")

    if not c_sym or not c_mark:
        return 0.02

    rows = []
    for _, r in df.iterrows():
        try:
            mark = float(r.get(c_mark) or 0.0)
            if mark <= 0:
                continue

            dte = float(r.get(c_dte) or 0.0) if c_dte else 30.0
            oi = float(r.get(c_oi) or 0.0) if c_oi else 999.0
            delta = float(r.get(c_delta) or 0.0) if c_delta else 0.2

            if not (10 <= dte <= 60):
                continue
            if oi < 10:
                continue
            if not (0.1 <= abs(delta) <= 0.4):
                continue

            sym = str(r.get(c_sym) or "").strip().upper()
            if not sym:
                continue

            if margin_estimator:
                # margin_estimator should return mm delta in BTC for +1 contract
                mm_delta = margin_estimator(sym, 1)
            else:
                # heuristic
                mm_delta = 1.2 * mark + 0.003

            mm_delta = float(mm_delta)
            if np.isfinite(mm_delta) and mm_delta > 0:
                rows.append(mm_delta)
        except Exception:
            continue

    if not rows:
        return 0.02

    rows.sort()
    idx = int(round((len(rows) - 1) * float(percentile)))
    idx = max(0, min(len(rows) - 1, idx))
    return float(rows[idx])
