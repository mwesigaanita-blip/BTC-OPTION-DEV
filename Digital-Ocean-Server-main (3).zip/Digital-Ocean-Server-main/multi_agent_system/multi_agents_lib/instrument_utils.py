from __future__ import annotations

import re
from typing import Any, Optional


# -----------------------------
# Instrument classifiers/parsers
# -----------------------------

def is_option(sym: str) -> bool:
    s = (sym or "").upper()
    # e.g., BTC-25OCT25-90000-C / BTC-25OCT25-90000-P
    return bool(re.match(r"^BTC-\d{1,2}[A-Z]{3}\d{2}-\d+-(C|P)$", s))


def parse_option(sym: str):
    """
    BTC-25OCT25-90000-C -> ("BTC", 90000.0, "C")
    Returns (underlying, strike, right_code) or (None, None, None)
    """
    m = re.match(r"^(BTC)-\d{1,2}[A-Z]{3}\d{2}-(\d+)-([CP])$", (sym or "").upper())
    if not m:
        return None, None, None
    return m.group(1), float(m.group(2)), m.group(3)


def is_perp(sym: str) -> bool:
    s = (sym or "").upper()
    return s.endswith("-PERPETUAL") or s == "BTC-PERPETUAL"


def is_dated_future(sym: str) -> bool:
    s = (sym or "").upper()
    # e.g., BTC-27DEC25 (no strike / no C|P)
    return bool(re.match(r"^BTC-\d{1,2}[A-Z]{3}\d{2}$", s))


def infer_right_from_symbol(symbol: str) -> Optional[str]:
    """
    Returns CALL/PUT for option symbols, otherwise None.
    """
    s = (symbol or "").upper().strip()

    # Futures/perp are NOT CALL/PUT
    if is_perp(s) or is_dated_future(s):
        return None

    if s.endswith("-C"):
        return "CALL"
    if s.endswith("-P"):
        return "PUT"
    return None


def parse_symbol_strike(symbol: str) -> Optional[float]:
    """
    BTC-25OCT25-90000-C -> 90000.0
    """
    try:
        parts = str(symbol).upper().split("-")
        return float(parts[-2])
    except Exception:
        return None


def parse_deribit_option_symbol(sym: str):
    """
    Deribit option format commonly:
      BTC-30DEC25-100000-C
    Returns (expiry, strike, right) or (None, None, None)
    """
    try:
        parts = (sym or "").split("-")
        if len(parts) < 4:
            return None, None, None
        expiry = parts[1]
        strike = float(parts[2])
        right_code = parts[3].upper()
        right = "CALL" if right_code.startswith("C") else "PUT"
        return expiry, strike, right
    except Exception:
        return None, None, None


def mark_for(sym: str, mark_lookup: Any) -> Optional[float]:
    """
    Unified mark lookup helper.
    - mark_lookup can be callable(symbol)->value or dict[symbol]=value
    Returns None if mark is missing instead of raising.
    """
    sym_up = (sym or "").upper()

    if callable(mark_lookup):
        try:
            v = mark_lookup(sym_up)
            return float(v) if v is not None else None
        except Exception:
            return None

    if isinstance(mark_lookup, dict):
        v = mark_lookup.get(sym_up)
        try:
            return float(v) if v is not None else None
        except Exception:
            return None

    return None
