"""
multi_agents_lib package

This package contains modular components extracted from multi_agents.py:
- logging utilities
- instrument helpers
- decision parsing
- close/open engines
- allocation logic
- persistence helpers
- margin utilities
"""

__all__ = []
