from __future__ import annotations

import logging
from typing import Tuple

import numpy as np
import pandas as pd



logger = logging.getLogger(__name__)


def deribit_inverse_perp_pnl(
    *,
    side: str,
    qty_contracts: float,
    entry_price_usd: float,
    mark_price_usd: float,
    contract_value_usd: float = 10.0,
) -> Tuple[float, float]:
    """
    Compute inverse BTC perpetual/future PnL.
    Returns (pnl_btc, pnl_usd).

    Notes:
    - Deribit inverse contract PnL is in BTC; USD conversion uses mark_price_usd.
    - This function is defensive and returns (0,0) on bad inputs.
    """
    try:
        s = (side or "").upper()
        q = float(qty_contracts or 0.0)
        entry = float(entry_price_usd or 0.0)
        mark = float(mark_price_usd or 0.0)
        cv = float(contract_value_usd or 10.0)

        if q == 0 or entry <= 0 or mark <= 0 or cv <= 0:
            return 0.0, 0.0

        # For inverse contracts, PnL BTC = contract_value * qty * (1/entry - 1/mark)
        raw_btc = cv * q * (1.0 / entry - 1.0 / mark)

        # Flip sign for SELL/SHORT
        if s in ("SELL", "SHORT"):
            raw_btc = -raw_btc

        pnl_btc = float(raw_btc)
        pnl_usd = pnl_btc * mark
        return pnl_btc, pnl_usd
    except Exception:
        return 0.0, 0.0


def format_positions_for_llm(
    positions_df: pd.DataFrame | None,
    round_price: int = 6,
) -> str:
    """
    BTC positions formatter for LLM prompts (options + futures/perp safe).
    - NO destructive renames; keeps all existing columns intact.
    - Safely picks fields even if column names repeat.
    - Computes PnL% for OPTIONS from avg_btc vs mark_btc (signed by side).
    - FUTURES/PERP are handled in USD-contract units (Deribit-style) to avoid insane BTC notionals.
    - Writes raw CSV and human-readable TXT for audit.
    """
    import re
    from datetime import datetime, timezone
    import pandas as pd
    import numpy as np

    if positions_df is None or positions_df.empty:
        return "Open Positions: none."

    df = positions_df.copy()
    # df.to_csv("positions_summary_raw.csv", index=False)

    # --------------------------
    # helpers for dup columns
    # --------------------------
    def pick_series(name: str) -> pd.Series | None:
        if name not in df.columns:
            return None
        obj = df[name]
        if isinstance(obj, pd.DataFrame):
            return obj.iloc[:, 0]
        return obj

    def coalesce(cols: list[str]) -> pd.Series | None:
        candidates = []
        for c in cols:
            s = pick_series(c)
            if s is not None:
                candidates.append(s)
        if not candidates:
            return None
        if len(candidates) == 1:
            return candidates[0]
        aligned = pd.concat(candidates, axis=1)
        return aligned.bfill(axis=1).iloc[:, 0]

    def to_num(s: pd.Series | None) -> pd.Series:
        if s is None:
            return pd.Series([np.nan] * len(df), index=df.index)
        return pd.to_numeric(s, errors="coerce")

    # --------------------------
    # instrument classification
    # --------------------------
    def _is_perp(name: str) -> bool:
        s = (name or "").upper()
        return "PERPETUAL" in s or s.endswith("-PERPETUAL") or s == "BTC-PERPETUAL"

    def _is_option(name: str) -> bool:
        s = (name or "").upper()
        # Deribit options end with -C or -P
        return s.endswith("-C") or s.endswith("-P")

    def _is_future(name: str) -> bool:
        # crude but practical: BTC-30DEC25 (no strike/right) OR non-option non-perp future formats
        s = (name or "").upper()
        if _is_perp(s) or _is_option(s):
            return False
        # Typical dated future is like BTC-30DEC25 or BTC-30DEC25-???? (varies)
        # We'll treat non-option BTC-* that isn't perp as FUT candidate.
        return s.startswith("BTC-")

    # --------------------------
    # Pull canonical fields
    # --------------------------
    instr = coalesce(["instrument_name", "symbol", "instrument", "instrumentId"])
    right = coalesce(["right", "option_type", "type", "optionRight"])
    strike = coalesce(["strike"])
    qty = coalesce(["qty", "size", "quantity", "amount"])
    side = coalesce(["side", "direction"])

    avg_btc = coalesce(["avg_price_btc", "average_price_btc", "average_price"])
    mark_btc = coalesce(["mark_price_btc", "mark_price"])

    # These often exist and are what you WANT for perp/futures display:
    mark_usd = coalesce(["mark_price_usd", "mark_usd", "index_price", "mark_price"])
    avg_usd  = coalesce(["avg_price_usd", "average_price_usd"])

    expiration = coalesce(["expiration", "expiry", "maturity"])

    name_s = (instr.astype(str) if instr is not None else pd.Series(["NA"] * len(df), index=df.index))

    # --------------------------
    # Expiration parsing (options only)
    # --------------------------
    exp_txt = None
    if expiration is None:
        if instr is not None:
            pat = re.compile(r"BTC-(\d{2}[A-Z]{3}\d{2})-", re.IGNORECASE)
            month_map = {
                "JAN": "01", "FEB": "02", "MAR": "03", "APR": "04", "MAY": "05", "JUN": "06",
                "JUL": "07", "AUG": "08", "SEP": "09", "OCT": "10", "NOV": "11", "DEC": "12",
            }

            def parse_exp(s: str) -> str | None:
                m = pat.search(str(s))
                if not m:
                    return None
                token = m.group(1).upper()
                dd = token[:2]
                mmm = token[2:5]
                yy = token[5:]
                mm = month_map.get(mmm)
                if not mm:
                    return None
                yyyy = f"20{yy}"
                return f"{yyyy}-{mm}-{dd}"

            exp_txt = name_s.map(parse_exp)
        else:
            exp_txt = pd.Series([None] * len(df), index=df.index)
    else:
        try:
            exp_parsed = pd.to_datetime(expiration, utc=True, errors="coerce")
            exp_txt = exp_parsed.dt.strftime("%Y-%m-%d")
        except Exception:
            exp_txt = expiration.astype(str).str[:10]

    # --------------------------
    # normalize numeric fields
    # --------------------------
    qty_raw = to_num(qty)
    qty_abs = qty_raw.abs()

    strike_s = to_num(strike)
    avg_btc_s = to_num(avg_btc)
    mark_btc_s = to_num(mark_btc)

    avg_usd_s  = to_num(avg_usd)
    mark_usd_s = to_num(mark_usd)

    side_s = (side.astype(str).str.upper() if side is not None
              else pd.Series([""] * len(df), index=df.index))

    # --------------------------
    # signed qty (BUY +, SELL -)
    # --------------------------
    qty_signed = qty_abs.copy()
    sell_mask = side_s.isin(["SELL", "SHORT"])
    qty_signed[sell_mask] = -qty_signed[sell_mask]
    # --------------------------
    # Build compact CP tag
    #   - options: C/P
    #   - futures/perp: FUT
    # --------------------------
    cp = right.astype(str).str.upper() if right is not None else pd.Series([""] * len(df), index=df.index)
    cp = cp.str.replace("^CALL$", "C", regex=True).str.replace("^PUT$", "P", regex=True)
    cp = cp.str[0].where(cp.str[0].isin(["C", "P"]), "")

    # overwrite cp per row for perp/futures if needed
    cp_fixed = []
    for i in df.index:
        nm = str(name_s.at[i] or "")
        if _is_perp(nm) or _is_future(nm):
            cp_fixed.append("FUT")
        else:
            cp_fixed.append(cp.at[i] if pd.notna(cp.at[i]) and cp.at[i] else "?")
    cp_s = pd.Series(cp_fixed, index=df.index)

    # --------------------------
    # PnL%:
    #   - OPTIONS: use avg_btc vs mark_btc, signed for SELL
    #   - FUT/PERP: DO NOT compute from avg_btc/mark_btc (units differ);
    #              leave NA unless you have consistent avg_usd & mark_usd
    # --------------------------
    pnl_pct = pd.Series([np.nan] * len(df), index=df.index)

    # options pnl%
    opt_mask = name_s.map(_is_option)
    with np.errstate(divide="ignore", invalid="ignore"):
        raw_pct_opt = (mark_btc_s - avg_btc_s) / avg_btc_s * 100.0
    sell_mask = side_s.isin(["SELL", "SHORT"])
    pnl_opt = raw_pct_opt.copy()
    pnl_opt[sell_mask] = -raw_pct_opt[sell_mask]
    pnl_pct[opt_mask] = pnl_opt[opt_mask]

    # futures/perp pnl% (optional) if BOTH avg_usd & mark_usd present
    fut_mask = name_s.map(lambda x: _is_perp(x) or _is_future(x))
    if (avg_usd_s.notna().any() and mark_usd_s.notna().any()):
        with np.errstate(divide="ignore", invalid="ignore"):
            raw_pct_fut = (mark_usd_s - avg_usd_s) / avg_usd_s * 100.0
        pnl_fut = raw_pct_fut.copy()
        pnl_fut[sell_mask] = -raw_pct_fut[sell_mask]
        pnl_pct[fut_mask] = pnl_fut[fut_mask]

    # --------------------------
    # Notional / premium:
    #   - OPTIONS: premium_btc = mark_btc * abs(qty)
    #   - FUT/PERP: notional_usd = contracts * CONTRACT_USD
    #              notional_btc = notional_usd / btc_price_usd
    # --------------------------
    CONTRACT_USD = 10.0  # Deribit BTC futures/perp contract value (common)
    # BTC price to convert USD -> BTC for futures/perp notionals
    # Prefer mark_usd/index_price if present; else attempt from first valid mark_usd_s
    # If mark_usd_s is nonsense for options, this still works because we use it only in fut_mask rows.
    btc_price_usd_guess = None
    try:
        # if any row has a sensible mark_usd (e.g., ~80k), take median of fut rows
        fut_prices = mark_usd_s[fut_mask].dropna()
        if len(fut_prices) > 0:
            btc_price_usd_guess = float(np.nanmedian(fut_prices))
    except Exception:
        btc_price_usd_guess = None

    # totals for header
    premium_btc_opt = (mark_btc_s.fillna(0) * qty_abs.fillna(0))
    premium_btc_opt[~opt_mask] = 0.0
    total_premium_btc_opt = float(premium_btc_opt.sum()) if len(premium_btc_opt) else 0.0

    fut_notional_usd = pd.Series([0.0] * len(df), index=df.index)
    fut_notional_btc = pd.Series([0.0] * len(df), index=df.index)
    if btc_price_usd_guess and btc_price_usd_guess > 0:
        fut_notional_usd[fut_mask] = qty_abs[fut_mask].fillna(0) * float(CONTRACT_USD)
        fut_notional_btc[fut_mask] = fut_notional_usd[fut_mask] / float(btc_price_usd_guess)

    # --------------------------
    # Output header
    # --------------------------
    now = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    n_pos = len(df)
    avg_pnl = float(pnl_pct.mean(skipna=True)) if pnl_pct.notna().any() else None

    header = f"Open Positions ({n_pos}) as of {now}."
    if avg_pnl is not None:
        header += f" Avg PnL: {avg_pnl:.2f}%."
    if total_premium_btc_opt:
        header += f" Options Premium Notional ≈ {total_premium_btc_opt:.6f} BTC (mark_btc*qty)."
    if (fut_notional_usd.sum() > 0) and btc_price_usd_guess:
        header += f" Futures/Perp Notional ≈ ${float(fut_notional_usd.sum()):,.0f} (~{float(fut_notional_btc.sum()):.4f} BTC @ ${btc_price_usd_guess:,.0f})."

    # --------------------------
    # Row formatting helpers
    # --------------------------
    def fmt(x, nd=round_price):
        try:
            return f"{float(x):.{nd}f}"
        except Exception:
            return "NA"

    exp_s = (exp_txt if exp_txt is not None else pd.Series(["NA"] * len(df), index=df.index))

    lines = [header]

    tpl = coalesce(["total_profit_loss"])
    for i in df.index:
        name = name_s.at[i] if pd.notna(name_s.at[i]) else "NA"
        is_opt_i = _is_option(name)
        is_fut_i = _is_perp(name) or _is_future(name)

        side_i = side_s.at[i] if pd.notna(side_s.at[i]) else ""
        qty_txt = f"{qty_signed.at[i]:.4f}" if pd.notna(qty_signed.at[i]) else "NA"
        abs_txt = f"{qty_abs.at[i]:.4f}" if pd.notna(qty_abs.at[i]) else "NA"
        pnl_txt = f"{float(pnl_pct.at[i]):.2f}%" if pd.notna(pnl_pct.at[i]) else "NA"
        tpl_txt = "NA" if tpl is None or pd.isna(tpl.at[i]) else str(tpl.at[i])

        if is_opt_i:
            cp_i = cp_s.at[i]
            strike_txt = f"{int(strike_s.at[i])}" if pd.notna(strike_s.at[i]) else "NA"
            exp_txt_i = exp_s.at[i] if pd.notna(exp_s.at[i]) else "NA"
            avg_txt = fmt(avg_btc_s.at[i])
            mk_txt = fmt(mark_btc_s.at[i])

            lines.append(
                f"- {name} | {cp_i}{strike_txt} | exp {exp_txt_i} | side {side_i} | qty {qty_txt} (abs {abs_txt}) | avg_btc {avg_txt} | mark_btc {mk_txt} | PnL {pnl_txt} | total_PL {tpl_txt}"
            )

        elif is_fut_i:
            # For futures/perp: show mark in USD, and notional in USD/BTC (derived)
            mk_usd = mark_usd_s.at[i]
            mk_usd_txt = f"${float(mk_usd):,.2f}" if pd.notna(mk_usd) else "NA"

            not_usd = fut_notional_usd.at[i]
            not_btc = fut_notional_btc.at[i]
            not_txt = (
                f"${float(not_usd):,.0f} (~{float(not_btc):.4f} BTC)"
                if (pd.notna(not_usd) and float(not_usd) > 0 and btc_price_usd_guess)
                else "NA"
            )

            lines.append(
                f"- {name} | FUT | side {side_i} | contracts {qty_txt} | mark_usd {mk_usd_txt} | notional {not_txt} | PnL {pnl_txt} | total_PL {tpl_txt}"
            )

        else:
            # Unknown instrument type: safest minimal line
            lines.append(
                f"- {name} | ? | side {side_i} | qty {qty_txt} | PnL {pnl_txt} | total_PL {tpl_txt}"
            )

    final_summary_string = "\n".join(lines)
    with open("positions_summary.txt", "w", encoding="utf-8") as f:
        f.write(final_summary_string)

    return final_summary_string
