from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional, Tuple, Union

import numpy as np
import pandas as pd

from .instrument_utils import mark_for


logger = logging.getLogger(__name__)


def first(*vals: Any) -> Any:
    """
    Return the first non-null / non-empty / non-NaN value.
    """
    for v in vals:
        if v is None:
            continue
        if isinstance(v, float) and (np.isnan(v) or not np.isfinite(v)):
            continue
        if v == "":
            continue
        return v
    return None


def _norm_symbol(s: Any) -> str:
    return str(s or "").strip().upper()


def price_lookup_maps(
    *,
    positions_df: Optional[pd.DataFrame],
    live_options_df: Optional[pd.DataFrame],
    valuation_df: Optional[pd.DataFrame],
) -> Tuple[Dict[str, float], Dict[str, float], Dict[str, float], Dict[str, float]]:
    """
    Build 4 lookup maps:
      - pos_avg_map:   symbol -> avg_price_btc
      - live_mark_map: symbol -> mark_price_btc (with mid/bid/ask fallback)
      - val_mid_map:   symbol -> valuation mid price (btc)
      - val_mark_map:  symbol -> valuation mark price (btc)
    """
    pos_avg_map: Dict[str, float] = {}
    live_mark_map: Dict[str, float] = {}
    val_mid_map: Dict[str, float] = {}
    val_mark_map: Dict[str, float] = {}

    # ---- positions ----
    if positions_df is not None and not getattr(positions_df, "empty", True):
        dfp = positions_df.copy()
        sym_col = "instrument_name" if "instrument_name" in dfp.columns else ("symbol" if "symbol" in dfp.columns else None)
        if sym_col:
            for _, r in dfp.iterrows():
                sym = _norm_symbol(r.get(sym_col))
                if not sym:
                    continue
                # avg price commonly in BTC for options; for futures may still be useful
                avg_btc = r.get("average_price")
                try:
                    if avg_btc is not None and avg_btc != "":
                        pos_avg_map[sym] = float(avg_btc)
                except Exception:
                    pass

    # ---- live options ----
    if live_options_df is not None and not getattr(live_options_df, "empty", True):
        dfl = live_options_df.copy()
        if "symbol" in dfl.columns:
            for _, r in dfl.iterrows():
                sym = _norm_symbol(r.get("symbol"))
                if not sym:
                    continue
                mark = first(
                    r.get("mark_price_btc"),
                    r.get("mark_price"),
                    r.get("mid_price_btc"),
                    r.get("mid_price"),
                    r.get("bid_price_btc"),
                    r.get("bid_price"),
                    r.get("ask_price_btc"),
                    r.get("ask_price"),
                )
                try:
                    if mark is not None and mark != "":
                        live_mark_map[sym] = float(mark)
                except Exception:
                    pass

    # ---- valuation ----
    if valuation_df is not None and not getattr(valuation_df, "empty", True):
        dfv = valuation_df.copy()
        sym_col = "symbol" if "symbol" in dfv.columns else ("instrument_name" if "instrument_name" in dfv.columns else None)
        if sym_col:
            for _, r in dfv.iterrows():
                sym = _norm_symbol(r.get(sym_col))
                if not sym:
                    continue

                mid = first(r.get("mid_price_btc"), r.get("mid_btc"), r.get("mid_price"))
                mk = first(r.get("mark_price_btc"), r.get("mark_btc"), r.get("mark_price"))

                try:
                    if mid is not None and mid != "":
                        val_mid_map[sym] = float(mid)
                except Exception:
                    pass

                try:
                    if mk is not None and mk != "":
                        val_mark_map[sym] = float(mk)
                except Exception:
                    pass

    return pos_avg_map, live_mark_map, val_mid_map, val_mark_map


def enrich_decisions_with_prices(
    *,
    decisions: Union[List[Dict[str, Any]], "pd.DataFrame"],
    positions_df: Optional[pd.DataFrame],
    live_options_df: Optional[pd.DataFrame],
    valuation_df: Optional[pd.DataFrame],
    btc_price: float,
) -> pd.DataFrame:
    if hasattr(decisions, "to_dict"):
        decisions = decisions.to_dict("records")
    """
    Enrich decisions with:
      - avg_price_btc/usd
      - mark_price_btc/usd
      - btc_price
      - POP (if present)
      - theta_usd_per_day, premium_mark_usd, premium_mid_usd (if present in valuation/live)
    """
    pos_avg_map, live_mark_map, val_mid_map, val_mark_map = price_lookup_maps(
        positions_df=positions_df,
        live_options_df=live_options_df,
        valuation_df=valuation_df,
    )

    # optional extra maps (theta/premium/POP) from valuation/live, if available
    extra: Dict[str, Dict[str, Any]] = {}

    def _ingest_extras(df: pd.DataFrame):
        if df is None or getattr(df, "empty", True):
            return
        sym_col = "symbol" if "symbol" in df.columns else ("instrument_name" if "instrument_name" in df.columns else None)
        if not sym_col:
            return
        for _, r in df.iterrows():
            sym = _norm_symbol(r.get(sym_col))
            if not sym:
                continue
            d = extra.setdefault(sym, {})
            for k in ("POP", "theta_usd_per_day", "premium_mark_usd", "premium_mid_usd"):
                if k in df.columns and r.get(k) not in (None, "", []):
                    d[k] = r.get(k)

    if isinstance(valuation_df, pd.DataFrame):
        _ingest_extras(valuation_df)
    if isinstance(live_options_df, pd.DataFrame):
        _ingest_extras(live_options_df)

    rows: List[Dict[str, Any]] = []
    btc = float(btc_price or 0.0)

    for d in (decisions or []):
        sym = _norm_symbol(d.get("symbol"))
        action = str(d.get("action") or "").upper()
        row = dict(d)

        # attach btc price
        row["btc_price"] = btc

        # avg price
        avg_btc = None
        if action in ("HOLD", "CLOSE"):
            avg_btc = pos_avg_map.get(sym)
        elif action == "OPEN":
            # for opens, avg from valuation mid (or mark)
            avg_btc = first(val_mid_map.get(sym), val_mark_map.get(sym))

        if avg_btc is not None:
            try:
                row["avg_price_btc"] = float(avg_btc)
                row["avg_price_usd"] = float(avg_btc) * btc if btc > 0 else None
            except Exception:
                pass

        # mark price
        mk_btc = first(live_mark_map.get(sym), val_mark_map.get(sym))
        if mk_btc is not None:
            try:
                row["mark_price_btc"] = float(mk_btc)
                row["mark_price_usd"] = float(mk_btc) * btc if btc > 0 else None
            except Exception:
                pass

        # extras
        ex = extra.get(sym) or {}
        for k, v in ex.items():
            if k not in row or row.get(k) in (None, "", []):
                row[k] = v

        rows.append(row)

    df_out = pd.DataFrame(rows)
    return df_out


def fetch_mark_btc_public(*, deribit_client, instrument_name: str) -> Optional[float]:
    """
    Uses Deribit public/ticker to return BTC mark price (best-effort).
    """
    if deribit_client is None:
        return None
    try:
        res = deribit_client.public("get_ticker", {"instrument_name": instrument_name})
        if isinstance(res, dict):
            # handle both {"result": {...}} and direct result
            result = res.get("result") if "result" in res else res
            v = first(result.get("mark_price"), result.get("mark_price_btc"), result.get("mid_price"))
            try:
                return float(v) if v is not None else None
            except Exception:
                return None
    except Exception as e:
        logger.debug("fetch_mark_btc_public failed for %s: %s", instrument_name, e)
    return None


def build_close_to_open_context_string(
    *,
    close_decisions: List[Dict[str, Any]],
    positions_df: Optional[pd.DataFrame],
    btc_price: float,
    deribit_client=None,
    current_positions_map: Optional[Dict[str, int]] = None,
    # NEW:
    debug_dump: bool = True,
    debug_dir: Optional[str] = None,
    debug_tag: str = "close_to_open_context",
) -> str:
    """
    Generates LLM text context for OPEN agent based on CLOSE output.

    FIXES:
    - Uses TRUE qty from positions_df (or current_positions_map fallback), not the LLM decision qty.
    - Builds pos_map keyed by BOTH symbol and instrument_name to avoid mismatches.
    - Writes a debug txt artifact of the final context.
    """
    import os
    import datetime as _dt
    from pathlib import Path

    btc = float(btc_price or 0.0)

    def _safe_float(x, default=None):
        try:
            return float(x)
        except Exception:
            return default

    def _safe_int_abs(x, default=0):
        try:
            v = float(x)
            v = abs(v)
            return int(v) if v.is_integer() else int(round(v))
        except Exception:
            return default

    # quick lookup for position lines (avg/mark/pnl) from positions_df
    pos_map: Dict[str, Dict[str, Any]] = {}
    qty_map: Dict[str, int] = {}

    if positions_df is not None and not getattr(positions_df, "empty", True):
        dfp = positions_df.copy()
        # drop duplicate cols defensively
        dfp = dfp.loc[:, ~dfp.columns.duplicated()]

        for _, r in dfp.iterrows():
            sym_a = _norm_symbol(r.get("symbol"))
            sym_b = _norm_symbol(r.get("instrument_name"))

            # qty source of truth from df
            qty = _safe_int_abs(r.get("qty", r.get("size", r.get("quantity", r.get("amount", 0)))), default=0)

            payload = {
                "avg_btc": r.get("average_price"),
                "avg_usd": r.get("average_price_usd"),
                "mark_btc": r.get("mark_price"),
                "mark_usd": r.get("mark_price_usd"),
                "pnl_btc": r.get("pnl_btc_total_deribit") or r.get("pnl_btc_total"),
                "pnl_usd": r.get("pnl_usd_total_deribit") or r.get("pnl_usd_total"),
                "index_price": r.get("index_price"),
            }

            # Key by BOTH columns if present to prevent mismatches later
            if sym_a:
                pos_map[sym_a] = payload
                if qty > 0:
                    qty_map[sym_a] = qty
            if sym_b and sym_b not in pos_map:
                pos_map[sym_b] = payload
            if sym_b and sym_b not in qty_map and qty > 0:
                qty_map[sym_b] = qty

    # fallback qty map from caller (already built)
    if current_positions_map:
        for k, v in current_positions_map.items():
            kk = _norm_symbol(k)
            if not kk:
                continue
            if kk not in qty_map:
                try:
                    qty_map[kk] = int(v)
                except Exception:
                    pass

    lines: List[str] = []
    lines.append("=== CLOSE→OPEN CONTEXT ===")
    lines.append("Use CLOSE actions only to reduce risk or free margin. Do NOT reopen the same symbols you closed today.")
    lines.append("Zero trades is acceptable if nothing fits risk limits.")
    lines.append("")

    freed_usd = 0.0
    closed_syms = set()

    for d in (close_decisions or []):
        sym = _norm_symbol(d.get("symbol"))
        act = str(d.get("action") or "").upper()
        if act != "CLOSE" or not sym:
            continue

        closed_syms.add(sym)

        p = pos_map.get(sym) or {}
        mark_btc = p.get("mark_btc")
        pnl_usd = p.get("pnl_usd")
        idx = p.get("index_price") or btc

        # TRUE qty selection: df qty -> current_positions_map -> decision qty
        true_qty = qty_map.get(sym)
        if true_qty is None or int(true_qty) <= 0:
            true_qty = _safe_int_abs(d.get("quantity", d.get("qty", 0)), default=0)
        if true_qty <= 0:
            true_qty = 1  # last resort (should rarely happen)

        # best-effort mark fetch
        if (mark_btc in (None, "", 0) or (isinstance(mark_btc, float) and not np.isfinite(mark_btc))) and deribit_client is not None:
            mk = fetch_mark_btc_public(deribit_client=deribit_client, instrument_name=sym)
            if mk is not None:
                mark_btc = mk

        est_mark_usd = None
        try:
            if mark_btc not in (None, "", 0) and float(idx or 0) > 0:
                est_mark_usd = float(mark_btc) * float(idx)
        except Exception:
            est_mark_usd = None

        try:
            if est_mark_usd is not None:
                freed_usd += abs(est_mark_usd) * float(true_qty)
        except Exception:
            pass

        pnl_str = ""
        try:
            if pnl_usd not in (None, ""):
                pnl_str = f" | PnL≈{float(pnl_usd):+.2f} USD"
        except Exception:
            pnl_str = ""

        if est_mark_usd is not None:
            lines.append(f"- {sym} | CLOSE qty={true_qty} | est_mark≈{est_mark_usd:.2f} USD{pnl_str}")
        else:
            lines.append(f"- {sym} | CLOSE qty={true_qty}{pnl_str}")

    if freed_usd > 0:
        lines.append("")
        lines.append(f"Estimated freed premium/notional (rough): ≈ ${freed_usd:,.0f}")

    if closed_syms:
        lines.append("")
        lines.append("Closed symbols today (DO NOT reopen): " + ", ".join(sorted(closed_syms)))

    # existing positions list (optional reminder)
    if qty_map:
        lines.append("")
        lines.append("Existing open symbols (for context): " + ", ".join(sorted(qty_map.keys())))

    out_txt = "\n".join(lines)

    # ---------------- DEBUG ARTIFACT: write prompt/context ----------------
    if debug_dump:
        try:
            base = Path(debug_dir or os.getenv("MODEL_OUTPUT_DIR", "/data")) / "prompt_debug"
            base.mkdir(parents=True, exist_ok=True)
            ts = _dt.datetime.utcnow().strftime("%Y-%m-%d_%H-%M-%S")
            path = base / f"{debug_tag}_{ts}.txt"
            path.write_text(out_txt, encoding="utf-8")
            logging.info("Saved CLOSE→OPEN context debug file: %s", str(path))
        except Exception as e:
            logging.warning("Failed to write CLOSE→OPEN context debug txt: %s", e)

    return out_txt

def deribit_inverse_perp_pnl(
    *,
    qty_contracts: float,
    entry_price_usd: float,
    mark_price_usd: float,
    side: str,                     # "BUY"/"SELL" or "LONG"/"SHORT"
    contract_value_usd: float = 10.0,  # Deribit BTC-PERPETUAL is typically $10/contract
) -> tuple[float, float]:
    """
    Returns (pnl_btc, pnl_usd) for Deribit inverse perpetual/future.

    BUY/LONG profits when price rises.
    SELL/SHORT profits when price falls.
    """
    import math

    try:
        q = float(qty_contracts or 0.0)
        pe = float(entry_price_usd or 0.0)
        pm = float(mark_price_usd or 0.0)
        cv = float(contract_value_usd or 0.0)
    except Exception:
        return 0.0, 0.0

    if q == 0.0 or pe <= 0.0 or pm <= 0.0 or cv <= 0.0:
        return 0.0, 0.0

    s = (side or "").upper().strip()
    is_short = s in ("SELL", "SHORT")
    is_long  = s in ("BUY", "LONG")

    if not (is_short or is_long):
        # default: treat as short? better: no pnl
        return 0.0, 0.0

    if is_long:
        pnl_btc = q * cv * (1.0 / pe - 1.0 / pm)
    else:
        pnl_btc = q * cv * (1.0 / pm - 1.0 / pe)

    pnl_usd = pnl_btc * pm
    if not (math.isfinite(pnl_btc) and math.isfinite(pnl_usd)):
        return 0.0, 0.0

    return pnl_btc, pnl_usd
