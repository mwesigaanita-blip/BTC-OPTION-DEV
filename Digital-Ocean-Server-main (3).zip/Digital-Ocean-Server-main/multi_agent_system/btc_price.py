from .config import *  # noqa: F401,F403  (non-DB constants)
from shared.db_paths import MARKET_DATA_DB as DB_PATH

print(f"[DB] Using {DB_PATH} in {__file__}", flush=True)
import requests
import os

import logging

from tenacity import retry, stop_after_attempt, wait_exponential

import warnings

import sys

import os, logging

import sys

warnings.filterwarnings("ignore")
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
# Optional fallback if HF model isn't available

# Logging setup
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('Main_file_log.log'),
        logging.StreamHandler()
    ]
)




# This function fetches the current BTC price from Deribit.
def _create_retry_session(total=5, backoff=0.5):
    from urllib3.util.retry import Retry
    from requests.adapters import HTTPAdapter
    sess = requests.Session()
    retry_cfg = Retry(
        total=total,
        read=total,
        connect=total,
        backoff_factor=backoff,
        status_forcelist=(429, 500, 502, 503, 504),
        allowed_methods=frozenset(["GET", "POST"])
    )
    adapter = HTTPAdapter(max_retries=retry_cfg)
    sess.mount("http://", adapter)
    sess.mount("https://", adapter)
    # Keep timeouts small per request; we do multiple fallbacks
    sess.headers.update({"User-Agent": "btc-price-fetcher/1.0"})
    return sess

@retry(stop=stop_after_attempt(3), wait=wait_exponential(multiplier=1, min=2, max=10))
def get_btc_price() -> float:
    """
    Fetch current BTC price with multiple fallbacks and auto-save one daily value (UTC) to SQLite.

    Priority:
      1) Deribit public ticker (BTC-PERPETUAL)
      2) Deribit book summary (BTC-PERPETUAL)
      3) Deribit btc_usd index
      4) Coinbase
      5) Bitstamp
      6) DB last saved daily price (sqlite)
      7) ENV: DEFAULT_BTC_PRICE

    Side effect:
      Saves ONE row per UTC date to table btc_daily(date TEXT PRIMARY KEY, btc_price REAL, updated_at TEXT).
      Save mode via env BTC_SAVE_MODE: "override" (default) or "skip".
    """
    import os, logging, sqlite3, requests
    from datetime import datetime, timezone
    from typing import Optional

    sess = _create_retry_session()

    SAVE_MODE = (os.getenv("BTC_SAVE_MODE", "override") or "override").lower()  

    # Ensure table exists (and optionally reuse connection later for fallback/save)
    db_conn = None
    try:
        db_conn = sqlite3.connect(str(DB_PATH), timeout=30)
        cur = db_conn.cursor()
        cur.execute("PRAGMA journal_mode=WAL;")
        cur.execute("""
                CREATE TABLE IF NOT EXISTS btc_daily (
                    day_utc   TEXT PRIMARY KEY,
                    price_usd REAL NOT NULL,
                    ts_utc    TEXT NOT NULL
        """)
        db_conn.commit()
    except Exception as e:
        logging.warning("DB init (btc_daily) failed: %s", e)
        db_conn = None

    def _try_deribit_public_ticker(sess: requests.Session) -> Optional[float]:
        url = "https://www.deribit.com/api/v2/public/ticker"
        params = {"instrument_name": "BTC-PERPETUAL"}
        r = sess.get(url, params=params, timeout=8)
        r.raise_for_status()
        js = r.json()
        res = js.get("result") or {}
        for k in ("last_price", "mark_price", "index_price"):
            if k in res and res[k]:
                val = float(res[k])
                if val > 0:
                    return val
        bid, ask = res.get("best_bid_price"), res.get("best_ask_price")
        if bid and ask:
            mid = (float(bid) + float(ask)) / 2.0
            if mid > 0:
                return mid
        return None

    def _try_deribit_book_summary(sess: requests.Session) -> Optional[float]:
        url = "https://www.deribit.com/api/v2/public/get_book_summary_by_instrument"
        params = {"instrument_name": "BTC-PERPETUAL"}
        r = sess.get(url, params=params, timeout=8)
        r.raise_for_status()
        js = r.json()
        arr = js.get("result") or []
        if arr:
            row = arr[0]
            for k in ("last", "mark_price", "index_price"):
                if k in row and row[k]:
                    val = float(row[k])
                    if val > 0:
                        return val
        return None

    def _try_deribit_index(sess: requests.Session) -> Optional[float]:
        url = "https://www.deribit.com/api/v2/public/get_index_price"
        params = {"index_name": "btc_usd"}
        r = sess.get(url, params=params, timeout=8)
        r.raise_for_status()
        js = r.json()
        res = js.get("result") or {}
        ip = res.get("index_price")
        if ip:
            val = float(ip)
            return val if val > 0 else None
        return None

    def _try_coinbase(sess: requests.Session) -> Optional[float]:
        url = "https://api.exchange.coinbase.com/products/BTC-USD/ticker"
        r = sess.get(url, timeout=8)
        r.raise_for_status()
        js = r.json()
        p = js.get("price")
        if p:
            val = float(p)
            return val if val > 0 else None
        return None

    def _try_bitstamp(sess: requests.Session) -> Optional[float]:
        url = "https://www.bitstamp.net/api/v2/ticker/btcusd"
        r = sess.get(url, timeout=8)
        r.raise_for_status()
        js = r.json()
        p = js.get("last")
        if p:
            val = float(p)
            return val if val > 0 else None
        return None

    price = None
    source = None
    funcs = [
        ("deribit_public", _try_deribit_public_ticker),
        ("deribit_book",   _try_deribit_book_summary),
        ("deribit_index",  _try_deribit_index),
        ("coinbase",       _try_coinbase),
        ("bitstamp",       _try_bitstamp),
    ]

    # Try online sources
    for name, fn in funcs:
        try:
            val = fn(sess)
            if val and val > 0:
                price = float(val)
                source = name
                break
        except Exception as e:
            logging.warning("%s failed: %s", fn.__name__, e)

    # DB fallback (last saved daily price)
    if price is None and db_conn is not None:
        try:
            cur = db_conn.cursor()
            cur.execute("SELECT date, btc_price FROM btc_daily ORDER BY date DESC LIMIT 1;")
            row = cur.fetchone()
            if row and row[1] and float(row[1]) > 0:
                price = float(row[1])
                source = "db_daily_last"
                logging.warning("Using BTC price from DB last saved daily value (%s): %.2f", row[0], price)
        except Exception as e:
            logging.warning("DB fallback read failed: %s", e)

    # ENV fallback
    if price is None:
        env_val = os.getenv("DEFAULT_BTC_PRICE")
        if env_val:
            try:
                env_price = float(env_val)
                if env_price > 0:
                    logging.warning("Using DEFAULT_BTC_PRICE from environment.")
                    price = env_price
                    source = "env_default"
            except Exception:
                pass

    if price is None or not (price > 0):
        raise RuntimeError("Unable to fetch BTC price from all sources and no valid fallback found.")

    logging.info("BTC price fetched (%s): $%.2f", source or "unknown", price)

    try:
        if db_conn is None:
            db_conn = sqlite3.connect(str(DB_PATH), timeout=30)
            cur = db_conn.cursor()
            cur.execute("PRAGMA journal_mode=WAL;")
            cur.execute("""
                CREATE TABLE IF NOT EXISTS btc_daily (
                    day_utc   TEXT PRIMARY KEY,
                    price_usd REAL NOT NULL,
                    ts_utc    TEXT NOT NULL
                )
            """)
            cur.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_btc_daily_day_utc ON btc_daily(day_utc);")
            db_conn.commit()
        else:
            cur = db_conn.cursor()

        # use one naming convention everywhere
        day_utc = datetime.now(timezone.utc).date().isoformat()
        ts_utc  = datetime.now(timezone.utc).isoformat()

        if SAVE_MODE == "skip":
            cur.execute(
                "INSERT OR IGNORE INTO btc_daily(day_utc, price_usd, ts_utc) VALUES (?,?,?)",
                (day_utc, float(price), ts_utc)
            )
        else:  # override (default)
            cur.execute(
                """
                INSERT INTO btc_daily(day_utc, price_usd, ts_utc)
                VALUES (?, ?, ?)
                ON CONFLICT(day_utc) DO UPDATE SET
                    price_usd = excluded.price_usd,
                    ts_utc    = excluded.ts_utc
                """,
                (day_utc, float(price), ts_utc),
            )
        db_conn.commit()
        logging.info("Saved btc_daily[%s]=%.2f (mode=%s)", day_utc, float(price), SAVE_MODE)

    except Exception as e:
        logging.warning("Failed to save btc_daily to DB: %s", e)

    finally:
        try:
            if db_conn is not None:
                db_conn.close()
        except Exception:
            pass

    return float(price)
