import requests
import os
from .config import *
import logging
import time
import warnings
import sys
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
import json
import math
import joblib
import os, re, math, time, logging, sqlite3
import sys


warnings.filterwarnings("ignore")
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
# Optional fallback if HF model isn't available

# Logging setup
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('Main_file_log.log'),
        logging.StreamHandler()
    ]
)


def auth_retry_session(retries=5, backoff=0.8,status_forcelist=(408, 429, 500, 502, 503, 504, 522)):
    s = requests.Session()
    r = Retry(
        total=retries, connect=retries, read=retries,
        backoff_factor=backoff,
        status_forcelist=status_forcelist,
        allowed_methods=["GET"],
        raise_on_status=False
    )
    a = HTTPAdapter(max_retries=r, pool_connections=10, pool_maxsize=20)
    s.mount("https://", a); s.mount("http://", a)
    s.headers.update({"Connection":"keep-alive","Accept":"application/json"})
    return s

def get_access_token():
    try:
        sess = auth_retry_session()
        url = "https://www.deribit.com/api/v2/public/auth"
        params = {
            "grant_type": "client_credentials",
            "client_id": DERIBIT_CLIENT_ID,
            "client_secret": DERIBIT_CLIENT_SECRET
        }
        # manual outer retries with jitter on top of urllib3 retries
        for i in range(3):
            try:
                resp = sess.get(url, params=params, timeout=8)
                resp.raise_for_status()
                data = resp.json()
                token = data.get("result", {}).get("access_token")
                if not token:
                    raise RuntimeError(f"No access_token in response: {data}")
                logging.info("Access token fetched.")
                return token
            except (requests.exceptions.Timeout, requests.exceptions.ConnectionError) as e:
                wait = (1.6**i) + 0.3
                logging.warning(f"Auth attempt {i+1}/3 failed: {e}; retrying in {wait:.1f}s")
                time.sleep(wait)
        raise RuntimeError("Auth failed after retries.")
    except Exception as e:
        logging.error(f"Failed to fetch access token: {e}")
        # Graceful fallback: return None so callers can skip private calls
        return None
