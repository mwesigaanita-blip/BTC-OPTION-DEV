from __future__ import annotations

import os

import logging
import warnings
from pathlib import Path
from dotenv import load_dotenv

# -------------------------------------------------------------------
# Environment & encoding
# -------------------------------------------------------------------

warnings.filterwarnings("ignore")
os.environ.setdefault("TF_CPP_MIN_LOG_LEVEL", "2")

# -------------------------------------------------------------------
# Base paths (SINGLE SOURCE OF TRUTH)
# -------------------------------------------------------------------
# This file is at: Deployment/multi_agent_system/config.py
DEPLOYMENT_ROOT = Path(__file__).resolve().parents[1]  # Deployment/

# Load .env (local dev only). In cloud, use environment variables.
ENV_PATH = Path(os.getenv("ENV_PATH", DEPLOYMENT_ROOT / ".env"))
if ENV_PATH.exists():
    load_dotenv(ENV_PATH)

# Cloud-first data dir:
# - In Docker/Cloud: mount a persistent volume at /data
# - Locally: default to Deployment/data
IS_DOCKER = Path("/.dockerenv").exists() or os.getenv("CLOUD", "0") == "1"
DEFAULT_DATA_DIR = Path("/data") if IS_DOCKER else (DEPLOYMENT_ROOT / "data")
DATA_DIR = Path(os.getenv("DATA_DIR", str(DEFAULT_DATA_DIR))).resolve()
DATA_DIR.mkdir(parents=True, exist_ok=True)

# Data-lake root (for Parquet / raw data pipelines)
# In Docker: /data  |  Locally: same as DATA_DIR
DATA_ROOT = Path(os.getenv("DATA_ROOT", str(DATA_DIR))).resolve()

# Database path
DB_PATH = Path(os.getenv("DB_PATH", str(DATA_DIR / "btc_trading.sqlite"))).resolve()
DB_PATH.parent.mkdir(parents=True, exist_ok=True)

# Models / assets
MODELS_DIR = (Path(__file__).resolve().parent / "Models").resolve()

POP_SHORT_MODEL_PATH  = MODELS_DIR / "POP_Estimator_short.joblib"
POP_LONG_MODEL_PATH   = MODELS_DIR / "POP_Estimator_long.joblib"
POP_VOTING_MODEL_PATH = MODELS_DIR / "btc_options_voting_model.pkl"

# Live options cache directory
LIVE_OPTIONS_DIR = Path(os.getenv("LIVE_OPTIONS_DIR", str(DEPLOYMENT_ROOT / "live_options"))).resolve()
LIVE_OPTIONS_DIR.mkdir(parents=True, exist_ok=True)

# -------------------------------------------------------------------
# Logging (safe for API + Streamlit)
# -------------------------------------------------------------------
LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO").upper()

logging.basicConfig(
    level=LOG_LEVEL,
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
    handlers=[
        logging.FileHandler(DATA_DIR / "app.log", encoding="utf-8"),
    ],
    force=True,  # override uvicorn / streamlit logging
)

log = logging.getLogger("config")
log.info("Loaded config | DEPLOYMENT_ROOT=%s | DATA_DIR=%s | DB_PATH=%s", DEPLOYMENT_ROOT, DATA_DIR, DB_PATH)

# -------------------------------------------------------------------
# External endpoints / API keys
# -------------------------------------------------------------------
DERIBIT_TV_URL = "https://www.deribit.com/api/v2/public/get_tradingview_chart_data"

DERIBIT_CLIENT_ID = os.getenv("DERIBIT_CLIENT_ID")
DERIBIT_CLIENT_SECRET = os.getenv("DERIBIT_CLIENT_SECRET")

TOGETHER_API = os.getenv("TOGETHER_API_KEY")
XAI_API_KEY  = os.getenv("XAI_API_KEY")
XAI_BASE_URL = os.getenv("XAI_BASE_URL", "https://api.x.ai/v1")
GROK_MODEL_ID = os.getenv("GROK_MODEL_ID", "grok-3-mini")

OPENROUTER_API_KEY      = os.getenv("OPENROUTER_API_KEY")
OPENROUTER_BASE_URL     = os.getenv("OPENROUTER_BASE_URL", "https://openrouter.ai/api/v1")
OPENROUTER_HTTP_REFERER = os.getenv("OPENROUTER_HTTP_REFERER", "")
OPENROUTER_APP_NAME     = os.getenv("OPENROUTER_APP_NAME", "BTC Options Engine")

# STRICT_ENV:
# - local/dev can keep strict
# - cloud can set STRICT_ENV=0 while bootstrapping containers
STRICT_ENV = os.getenv("STRICT_ENV", "1") == "1"
if STRICT_ENV and (not DERIBIT_CLIENT_ID or not DERIBIT_CLIENT_SECRET):
    raise ValueError("DERIBIT_CLIENT_ID or DERIBIT_CLIENT_SECRET not set (STRICT_ENV=1).")

# -------------------------------------------------------------------
# Portfolio & Risk Management (your knobs)
# -------------------------------------------------------------------
MAX_MARGIN   = 0.5
MAX_DRAWDOWN = 0.1
MIN_POP      = 0.75
DAYS_AHEAD   = 1000

THETA_EFFICIENCY   = 0.2
PREMIUM_EFFICIENCY = 0.2
MM_CAP_RATIO       = 0.5

DECISION_MODE = os.getenv("DECISION_MODE", "llm").lower()
TOP_K         = int(os.getenv("TOP_K", "10"))
MIN_POP_OPEN  = float(os.getenv("MIN_POP_OPEN", "0.75"))

# ---- LLM switch & caps ----
LLM_PROVIDER   = os.getenv("LLM_PROVIDER", "llama")  # 'llama' | 'grok-3' | 'grok-4'
MODEL_ID_LLAMA = os.getenv("MODEL_ID", "meta-llama/Meta-Llama-3.1-70B-Instruct-Turbo")
MODEL_ID_GROK  = os.getenv("GROK_MODEL_ID", "grok-4")  # or 'grok-4-0709', 'grok-3'

# Grok caps (tight)
GROK_MAX_CAND_ROWS = int(os.getenv("GROK_MAX_CAND_ROWS", "100"))
GROK_MAX_POS_ROWS  = int(os.getenv("GROK_MAX_POS_ROWS",  "30"))
TOP_SHORT          = int(os.getenv("TOP_SHORT", "100"))
TOP_LONG           = int(os.getenv("TOP_LONG",  "50"))

# Llama caps (looser)
LLAMA_MAX_CAND_ROWS = int(os.getenv("LLAMA_MAX_CAND_ROWS", "200"))
LLAMA_MAX_POS_ROWS  = int(os.getenv("LLAMA_MAX_POS_ROWS",  "40"))

# ===================== USER CONFIG / KNOBS =====================
TARGET_MONTHLY_RETURN = 0.05

THETA_WEIGHT          = float(os.getenv("THETA_WEIGHT", "0.50"))
PREMIUM_WEIGHT        = float(os.getenv("PREMIUM_WEIGHT", "0.50"))
USE_VOTING_PREFILTER  = True

# === Claude (Anthropic) settings ===
USE_CLAUDE: bool = True
ANTHROPIC_API_KEY: str = os.getenv("ANTHROPIC_API_KEY", "")
CLAUDE_MODEL: str = os.getenv("CLAUDE_MODEL", "claude-3-5-sonnet-latest")

IVR_OPEN_THRESHOLD = 0.70

CLOSE_RULES = {
    "DTE_LE": 2,
    "DELTA_GT": 0.45,
    "IVR_CRUSH_LT": 0.30,
    "TAKE_PROFIT_MULT": 0.30,
    "STOP_LOSS_MULT": 2.00,
}

LLM_PROVIDER_DEFAULT = "llama"
LLM_MODEL_LLAMA      = os.getenv("MODEL_ID", "meta-llama/Meta-Llama-3.1-70B-Instruct-Turbo")
GROK_3_MODEL_ID      = os.getenv("GROK_MODEL_ID", "grok-3-mini")
GROK_4_MODEL_ID      = os.getenv("GROK_4_MODEL_ID", "grok-4-0709")

VOTING_MODEL_PATH = os.getenv("VOTING_MODEL_PATH", str(POP_VOTING_MODEL_PATH))

CONSOLE_WIDTH = 96
RESULTS_DIR = str((DATA_DIR / "results_ver_3").resolve())

# -------------------------------------------------------------------
# Deribit fetch (kept, but IMPORTANT: never call it at import-time)
# -------------------------------------------------------------------
def fetch_account_capital(
    client_id: str | None = DERIBIT_CLIENT_ID,
    client_secret: str | None = DERIBIT_CLIENT_SECRET,
    currency: str = "BTC",
    basis: str = "equity",
    timeout: float = 30.0,
) -> dict:
    import requests # type: ignore

    base = "https://www.deribit.com/api/v2"
    cid  = client_id or os.getenv("DERIBIT_CLIENT_ID")
    csec = client_secret or os.getenv("DERIBIT_CLIENT_SECRET")
    if not cid or not csec:
        raise RuntimeError("DERIBIT_CLIENT_ID / DERIBIT_CLIENT_SECRET required.")

    sess = requests.Session()

    # Auth
    try:
        r = sess.get(
            f"{base}/public/auth",
            params={"grant_type": "client_credentials", "client_id": cid, "client_secret": csec},
            timeout=timeout,
        )
        r.raise_for_status()
        token = r.json()["result"]["access_token"]
    except Exception as e:
        logging.error(f"Deribit auth failed: {e}")
        return {
            "currency": currency.upper(),
            "balance": 0.0, "equity": 0.0, "available_funds": 0.0,
            "initial_margin": 0.0, "maintenance_margin": 0.0,
            "index_price_usd": 0.0,
            "equity_usd": 0.0, "available_funds_usd": 0.0,
            "capital_basis": basis, "capital_usd": 0.0,
            "margin_balance": 0.0,
            "im_pct_of_equity": None, "mm_pct_of_equity": None,
            "im_pct_of_mb": None, "mm_pct_of_mb": None,
            "projected_initial_margin": 0.0,
            "projected_maintenance_margin": 0.0,
            "portfolio_vega": 0.0,
            "theta_btc": 0.0,
            "theta_usd": 0.0,
            "free_margin_btc": 0.0,
            "free_margin_ratio_of_equity": None,
            "free_margin_ratio_of_mb": None,
            "net_delta_btc": 0.0,
        }

    sess.headers.update({"Authorization": f"Bearer {token}"})

    proj_im = 0.0
    proj_mm = 0.0
    theta_btc = 0.0
    portfolio_vega = 0.0
    net_delta_btc = 0.0

    bal = eq = avail = im = mm = mb = 0.0
    try:
        r = sess.get(
            f"{base}/private/get_account_summary",
            params={"currency": currency.upper(), "extended": "true"},
            timeout=timeout,
        )
        r.raise_for_status()
        acc = r.json().get("result", {}) or {}
        bal   = float(acc.get("balance") or 0.0)
        eq    = float(acc.get("equity") or 0.0)
        avail = float(acc.get("available_funds") or 0.0)
        im    = float(acc.get("initial_margin") or 0.0)
        mm    = float(acc.get("maintenance_margin") or 0.0)
        mb    = float(acc.get("margin_balance") or 0.0)

        theta_btc      = float(acc.get("theta") or 0.0)
        portfolio_vega = float(acc.get("vega") or 0.0)

        if acc.get("delta_total") is not None:
            net_delta_btc = float(acc.get("delta_total") or 0.0)
        else:
            opt_d = float(acc.get("options_delta") or 0.0)
            fut_d = float(acc.get("futures_delta") or 0.0)
            net_delta_btc = opt_d + fut_d if (acc.get("futures_delta") is not None) else opt_d

        proj_im = float(acc.get("projected_initial_margin") or 0.0)
        proj_mm = float(acc.get("projected_maintenance_margin") or 0.0)
    except Exception as e:
        logging.warning(f"get_account_summary failed: {e}")

    index_price = 0.0
    try:
        idx_name = f"{currency.lower()}_usd"
        r = sess.get(f"{base}/public/get_index_price", params={"index_name": idx_name}, timeout=timeout)
        r.raise_for_status()
        index_price = float((r.json().get("result") or {}).get("index_price") or 0.0)
    except Exception as e:
        logging.warning(f"get_index_price failed: {e}")

    equity_usd  = eq * index_price if index_price > 0 else 0.0
    avail_usd   = avail * index_price if index_price > 0 else 0.0
    cap_basis   = basis.lower().strip()
    capital_usd = equity_usd if cap_basis == "equity" else avail_usd
    theta_usd   = theta_btc * index_price if index_price > 0 else 0.0

    free_margin_btc = avail
    free_margin_ratio_equity = (avail / eq) if eq > 0 else None
    free_margin_ratio_mb     = (avail / mb) if mb > 0 else None
    is_equity_valid = (currency.upper() == "BTC" and eq > 0)
    return {
        "currency": currency.upper(),
        "balance": bal,
        "equity": eq,
        "available_funds": avail,
        "initial_margin": im,
        "maintenance_margin": mm,
        "margin_balance": mb,
        "index_price_usd": index_price,
        "equity_usd": equity_usd,
        "available_funds_usd": avail_usd,
        "capital_basis": "equity" if cap_basis == "equity" else "available",
        "capital_usd": capital_usd,
        "im_pct_of_equity": (im / eq * 100.0) if is_equity_valid else None,
        "mm_pct_of_equity": (mm / eq * 100.0) if is_equity_valid else None,
        "im_pct_of_mb":     (im / mb * 100.0) if mb > 0 else None,
        "mm_pct_of_mb":     (mm / mb * 100.0) if mb > 0 else None,
        "projected_initial_margin": proj_im,
        "projected_maintenance_margin": proj_mm,
        "portfolio_vega": portfolio_vega,
        "theta_btc": theta_btc,
        "theta_usd": theta_usd,
        "free_margin_btc": free_margin_btc,
        "free_margin_ratio_of_equity": free_margin_ratio_equity,
        "free_margin_ratio_of_mb": free_margin_ratio_mb,
        "net_delta_btc": net_delta_btc,
    }

# -------------------------------------------------------------------
# Task 8: Vega Concentration Settings (preserved)
# -------------------------------------------------------------------
VEGA_BUCKETS = [
    (0, 30,   "B1", "0–30"),
    (31, 60,  "B2", "31–60"),
    (61, 120, "B3", "61–120"),
    (121, 99999, "B4", ">120"),
]

MAX_VEGA_SHARE_BUCKET = {"B1": 0.20, "B2": 0.20, "B3": 0.20, "B4": 0.15}
MAX_VEGA_SHARE_TOTAL  = 0.15

MIN_VEGA_THRESHOLD = {
    "B1":  40_000.0,
    "B2":  55_000.0,
    "B3":  90_000.0,
    "B4": 120_000.0,
    "TOTAL": 200_000.0,
}

DYNAMIC_VEGA_CAP_BOOST_ENABLE      = True
DYNAMIC_VEGA_CAP_TRIGGER_TOTAL     = 0.10
DYNAMIC_VEGA_CAP_BOOST_FACTOR      = 1.5

SOFT_FALLBACK_ENABLE               = True
SOFT_FALLBACK_BUCKET_BOOST         = 1.10
SOFT_FALLBACK_MIN_THR_SHRINK       = 0.90

AUTO_VEGA_TUNE_ENABLE              = True
TARGET_TOTAL_VEGA_SHARE            = 0.10
TARGET_BUCKET_VEGA_SHARE           = 0.12

MIN_THR_FLOOR                      = 20_000.0
MIN_THR_CEIL                       = 300_000.0
THR_PCT_OF_PLATFORM                = 0.015
THR_SAFETY_MULT                    = 1.15

CAP_BUCKET_MIN = 0.05; CAP_BUCKET_MAX = 0.40
CAP_TOTAL_MIN  = 0.05; CAP_TOTAL_MAX  = 0.30

# -------------------------------------------------------------------
# POP Interval Config (preserved)
# -------------------------------------------------------------------
POP_INTERVAL_METHOD   = "bootstrap_calibrator"
POP_BOOTSTRAP_B       = 100
POP_INTERVAL_ALPHA    = 0.10
POP_MIN               = 0.55
POP_DOWNSIZE_FACTOR   = 0.5
POP_BOOTSTRAP_SEED    = 42

CAL_DIR        = (MODELS_DIR / "pop_calibration")
CAL_LONG_PATH  = CAL_DIR / "POP_Calibrator_long.pkl"
CAL_SHORT_PATH = CAL_DIR / "POP_Calibrator_short.pkl"

GPT_MAX_POS_ROWS = int(os.getenv("GPT_MAX_POS_ROWS", "30"))

# Strategy bounds
POP_FLOOR   = float(os.getenv("POP_FLOOR", "0.20"))
POP_CEILING = float(os.getenv("POP_CEILING", "0.90"))

CFG = {
    "dte_min": 70,
    "dte_max": 360,
    "delta_abs_min": 0.15,
    "delta_abs_max": 0.30,
    "min_vol": 0.0001,
}

RISK_RULES = {
    "max_margin_usage":   0.86,
    "max_vega_allowed":  -8500.0,
    "min_pop":            0.79,
    "min_theta_per_marg": 120.0,
}

# Task-7 toggles (preserved)
ENABLE_REGIME_FEATURES: bool = False
ENABLE_ENSEMBLE: bool = False
TASK7_ENSEMBLE_CFG: str = "tasks/task_7/ensemble_config_task7.json"

REGIME_FEATURES = [
    "realized_vol_7d",
    "realized_vol_21d",
    "iv_slope_30_7",
    "market_regime_enc",
    "regime_missing_flag",
]

AUTO_RUN_DAILY_REGIME: bool = True

# -------------------------------------------------------------------
# IMPORTANT: derived budgets computed at runtime (not import time)
# -------------------------------------------------------------------
def get_account_and_budgets(basis: str = "equity", currency: str = "BTC") -> dict:
    """
    Returns a dict with:
      - account (from Deribit)
      - derived budgets (MAX_MM_BUDGET, MAX_DRAWDOWN_AMOUNT, TARGET_MONTHLY_PNL)
    Safe to call during a job/refresh, NOT at import time.
    """
    account = fetch_account_capital(currency=currency, basis=basis)

    capital = float(account.get("capital_usd") or 0.0)
    max_mm_budget       = capital * MM_CAP_RATIO
    max_drawdown_amount = capital * MAX_DRAWDOWN
    target_monthly_pnl  = capital * TARGET_MONTHLY_RETURN

    return {
        "account": account,
        "capital_usd": capital,
        "MAX_MM_BUDGET": max_mm_budget,
        "MAX_DRAWDOWN_AMOUNT": max_drawdown_amount,
        "TARGET_MONTHLY_PNL": target_monthly_pnl,
    }

# -------------------------------------------------------------------
# GPT strategy text (preserved intent; no import-time ACCOUNT usage)
# -------------------------------------------------------------------
def get_strategy_text(account: dict | None = None) -> str:
    account = account or {}
    currency = account.get("currency", "BTC")
    capital_basis = account.get("capital_basis", "equity")

    return (
        f"Account: capital managed on a {capital_basis} basis; margin and PnL in {currency}. "
        "Objective: steady BTC-options income with strict capital protection; maintenance margin must stay within cap. "
        "Venue: Deribit BTC options only. "
        "Approach: premium-first; sell options for income, hedge when needed; add directional/debit only if premium edge is weak and signals align. "
        "Signals: require agreement across Fundamental (macro/on-chain/headlines), Sentiment (funding/OI/social flow), and Valuation (liquidity, spreads, high PoP). Skip if conflicting. "
        "Structures: naked where justified and liquid; otherwise defined-risk (credit spreads, strangles/straddles, irons). "
        "Execution: prioritize liquid books, clean calendars, and tight spreads; avoid thin liquidity and widening markets. "
        "Risk: conservative sizing per trade; diversify across expiries and strikes; enforce aggregate margin cap at all times. "
        "Management: harvest winners once income is adequate; cut or reduce on thesis break, adverse vol expansion, poor liquidity, or near expiry; roll only if edge and thesis persist under the margin cap. "
        "Governance: log inputs, decisions, and rationale; human override allowed."
    )
