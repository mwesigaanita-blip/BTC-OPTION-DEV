# margin_engine.py
"""
Simple Deribit-style stress margin engine (≈ 90% approximation).

This module is SELF-CONTAINED.
No imports from your project (multi_agent, margins_calc, pandas, ...).

Core idea:
    - You pass a portfolio of BTC options / futures (or a simple snapshot dict).
    - We run a grid of stress scenarios on:
        * underlying index price (BTC-USD)
        * implied volatility (IV)
    - We compute PnL (in BTC) for each scenario.
    - Initial Margin (IM) = worst-case loss (most negative PnL) × im_multiplier
    - Maintenance Margin (MM) = IM × mm_ratio

Units:
    - All PnL, IM, MM are in BTC.
    - index_price & strike are in USD.
    - Option mark_price is in BTC.
    - Future/perp mark_price is in USD (we convert to BTC with stressed index).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Dict, Optional, Literal, Tuple
import math
import time


# ============================================================
# Types & Data Structures
# ============================================================

OptionKind = Literal["call", "put"]


@dataclass
class OptionPosition:
    """
    BTC option position.

    Attributes:
        instrument_name: Deribit symbol, e.g. "BTC-27JUN25-90000-C"
        kind: "call" or "put"
        strike: strike price in USD
        expiry_ts: UNIX timestamp (seconds) of option expiry
        size: signed position in BTC (positive = long, negative = short)
        mark_price: current option price in BTC
        index_price: current underlying index price in USD (BTC-USD)
        iv: implied volatility (annualized, e.g. 0.7 = 70%)
    """
    instrument_name: str
    kind: OptionKind
    strike: float
    expiry_ts: int
    size: float
    mark_price: float
    index_price: float
    iv: float


@dataclass
class FuturePosition:
    """
    BTC future / perpetual position.

    Attributes:
        instrument_name: e.g. "BTC-PERPETUAL"
        expiry_ts: UNIX timestamp of expiry (0 or far future for perp)
        size: signed position in BTC (positive = long, negative = short)
        mark_price: current futures price in USD
        index_price: current underlying index price in USD (BTC-USD)
    """
    instrument_name: str
    expiry_ts: int
    size: float
    mark_price: float
    index_price: float


@dataclass
class Portfolio:
    """
    Portfolio of BTC options + futures/perps.
    """
    options: List[OptionPosition] = field(default_factory=list)
    futures: List[FuturePosition] = field(default_factory=list)


@dataclass
class ScenarioDefinition:
    """
    Definition of a stress scenario in relative terms.
    """
    name: str
    spot_factor: float   # multiply base_index_price
    iv_factor: float     # multiply each option's base IV


@dataclass
class ScenarioResult:
    """
    Result of applying one stress scenario.
    """
    name: str
    stressed_index_price: float
    stressed_iv_factor: float
    pnl_btc: float       # total PnL (BTC) for the portfolio under this scenario


@dataclass
class MarginResult:
    """
    Final margin result for a portfolio.
    """
    im_btc: float
    mm_btc: float
    worst_scenario: ScenarioResult
    all_scenarios: List[ScenarioResult]


@dataclass
class StressConfig:
    """
    Configuration of the stress engine.
    You can tweak this grid to calibrate against real Deribit IM.

    spot_shocks: list of (name, factor) applied to base_index_price
    iv_shocks:   list of (name, factor) applied to option IV
    im_multiplier: multiplier applied to worst loss to get IM
    mm_ratio:      fraction of IM used for MM (e.g. 0.8 = 80%)
    min_iv:        floor for stressed IV
    """
    spot_shocks: List[Tuple[str, float]] = field(default_factory=lambda: [
        ("spot_down_big", 0.80),
        ("spot_down_med", 0.90),
        ("spot_flat",     1.00),
        ("spot_up_med",   1.10),
        ("spot_up_big",   1.20),
    ])
    iv_shocks: List[Tuple[str, float]] = field(default_factory=lambda: [
        ("iv_up",   1.30),
        ("iv_flat", 1.00),
        ("iv_down", 0.80),
    ])
    im_multiplier: float = 1.0
    mm_ratio: float = 0.8
    min_iv: float = 0.01

    @classmethod
    def default(cls) -> "StressConfig":
        return cls()


# ============================================================
# Black–Scholes Helpers
# ============================================================

def _norm_cdf(x: float) -> float:
    """Standard normal CDF via math.erf()."""
    return 0.5 * (1.0 + math.erf(x / math.sqrt(2.0)))


def _black_scholes_price_usd(
    kind: OptionKind,
    S: float,
    K: float,
    T_years: float,
    iv: float,
    r: float = 0.0,
) -> float:
    """
    Black–Scholes option price in **USD**.

    Inputs:
        kind: "call" or "put"
        S: spot in USD
        K: strike in USD
        T_years: time to expiry in years
        iv: volatility (annualized, e.g. 0.7 = 70%)
        r: risk-free rate (ignored -> 0)

    Returns:
        price in USD.
    """
    if T_years <= 0 or iv <= 0 or S <= 0 or K <= 0:
        # Expired / degenerate → intrinsic value
        intrinsic = max(0.0, S - K) if kind == "call" else max(0.0, K - S)
        return intrinsic

    sqrtT = math.sqrt(T_years)
    d1 = (math.log(S / K) + (r + 0.5 * iv * iv) * T_years) / (iv * sqrtT)
    d2 = d1 - iv * sqrtT

    if kind == "call":
        price = S * _norm_cdf(d1) - K * math.exp(-r * T_years) * _norm_cdf(d2)
    else:
        price = K * math.exp(-r * T_years) * _norm_cdf(-d2) - S * _norm_cdf(-d1)

    return max(price, 0.0)


def _time_to_expiry_years(expiry_ts: int, now_ts: Optional[int] = None) -> float:
    """
    Convert UNIX expiry timestamp into time to expiry in years.
    """
    if now_ts is None:
        now_ts = int(time.time())
    dt_seconds = max(0, expiry_ts - now_ts)
    return dt_seconds / (365.0 * 24.0 * 3600.0)


# ============================================================
# Scenario Generation
# ============================================================

def generate_stress_definitions(config: StressConfig) -> List[ScenarioDefinition]:
    """
    Build a list of ScenarioDefinition from StressConfig.
    """
    defs: List[ScenarioDefinition] = []
    for spot_name, spot_factor in config.spot_shocks:
        for iv_name, iv_factor in config.iv_shocks:
            name = f"{spot_name}_{iv_name}"
            defs.append(
                ScenarioDefinition(
                    name=name,
                    spot_factor=spot_factor,
                    iv_factor=iv_factor,
                )
            )
    return defs


# ============================================================
# PnL Calculations under a Scenario
# ============================================================

def _option_position_pnl_under_scenario(
    pos: OptionPosition,
    stressed_index_price: float,
    iv_factor: float,
    config: StressConfig,
    now_ts: Optional[int] = None,
) -> float:
    """
    Compute PnL in BTC for a single option position under a stress scenario.
    """
    # Time to expiry
    T = _time_to_expiry_years(pos.expiry_ts, now_ts=now_ts)

    # Stressed IV (floored)
    stressed_iv = max(config.min_iv, pos.iv * iv_factor)

    # Current value (BTC) = size * mark_price (mark_price already in BTC)
    current_value_btc = pos.size * pos.mark_price

    # Stressed value:
    #   - Price in USD via BS
    #   - Convert USD → BTC by dividing by stressed index
    bs_price_usd = _black_scholes_price_usd(
        kind=pos.kind,
        S=stressed_index_price,
        K=pos.strike,
        T_years=T,
        iv=stressed_iv,
        r=0.0,
    )
    stressed_price_btc = bs_price_usd / max(stressed_index_price, 1e-8)
    stressed_value_btc = pos.size * stressed_price_btc

    pnl_btc = stressed_value_btc - current_value_btc
    return pnl_btc


def _future_position_pnl_under_scenario(
    fut: FuturePosition,
    stressed_index_price: float,
) -> float:
    """
    Compute PnL in BTC for a single future/perp position under a scenario.

    Futures are quoted in USD:
        PnL_USD = size * (stressed_index_price - mark_price)
        PnL_BTC = PnL_USD / stressed_index_price
    """
    pnl_usd = fut.size * (stressed_index_price - fut.mark_price)
    pnl_btc = pnl_usd / max(stressed_index_price, 1e-8)
    return pnl_btc


def compute_portfolio_pnl_under_scenario(
    portfolio: Portfolio,
    stressed_index_price: float,
    iv_factor: float,
    config: Optional[StressConfig] = None,
    now_ts: Optional[int] = None,
) -> float:
    """
    Total portfolio PnL (BTC) under a given scenario.
    """
    if config is None:
        config = StressConfig.default()

    pnl_total = 0.0

    # Options
    for opt in portfolio.options:
        pnl_total += _option_position_pnl_under_scenario(
            opt,
            stressed_index_price=stressed_index_price,
            iv_factor=iv_factor,
            config=config,
            now_ts=now_ts,
        )

    # Futures / Perps
    for fut in portfolio.futures:
        pnl_total += _future_position_pnl_under_scenario(
            fut,
            stressed_index_price=stressed_index_price,
        )

    return pnl_total


# ============================================================
# Margin Calculation: IM & MM
# ============================================================

def compute_portfolio_margin(
    portfolio: Portfolio,
    base_index_price: float,
    base_iv: float,
    config: Optional[StressConfig] = None,
    now_ts: Optional[int] = None,
) -> MarginResult:
    """
    Main function:
        Given a Portfolio, base index price, base IV and a StressConfig,
        run all scenarios and compute IM and MM.

    Arguments:
        portfolio: Portfolio of options + futures.
        base_index_price: current BTC index price in USD.
        base_iv: baseline IV (for reference; per-option IV is still used).
        config: StressConfig (if None → StressConfig.default()).
        now_ts: current UNIX time (seconds). If None, uses time.time().

    Returns:
        MarginResult (im_btc, mm_btc, worst_scenario, all_scenarios).
    """
    if config is None:
        config = StressConfig.default()

    if base_index_price <= 0:
        # No sensible spot → zero margins.
        empty_scen = ScenarioResult(
            name="invalid_base_index",
            stressed_index_price=base_index_price,
            stressed_iv_factor=1.0,
            pnl_btc=0.0,
        )
        return MarginResult(
            im_btc=0.0,
            mm_btc=0.0,
            worst_scenario=empty_scen,
            all_scenarios=[empty_scen],
        )

    # Build scenario definitions
    scen_defs = generate_stress_definitions(config)

    scenario_results: List[ScenarioResult] = []
    worst_loss_btc = 0.0
    worst_result: Optional[ScenarioResult] = None

    # Run all scenarios
    for scen in scen_defs:
        stressed_spot = base_index_price * scen.spot_factor
        pnl_btc = compute_portfolio_pnl_under_scenario(
            portfolio=portfolio,
            stressed_index_price=stressed_spot,
            iv_factor=scen.iv_factor,
            config=config,
            now_ts=now_ts,
        )

        res = ScenarioResult(
            name=scen.name,
            stressed_index_price=stressed_spot,
            stressed_iv_factor=scen.iv_factor,
            pnl_btc=pnl_btc,
        )
        scenario_results.append(res)

        if pnl_btc < worst_loss_btc:
            worst_loss_btc = pnl_btc
            worst_result = res

    # If no loss anywhere, IM = MM = 0, but still return a "flat" scenario.
    if worst_result is None:
        worst_result = ScenarioResult(
            name="no_loss_flat",
            stressed_index_price=base_index_price,
            stressed_iv_factor=1.0,
            pnl_btc=0.0,
        )
        scenario_results.append(worst_result)

    im_btc = max(0.0, -worst_loss_btc) * config.im_multiplier
    mm_btc = im_btc * config.mm_ratio

    return MarginResult(
        im_btc=im_btc,
        mm_btc=mm_btc,
        worst_scenario=worst_result,
        all_scenarios=scenario_results,
    )


# ============================================================
# Snapshot Helpers (for easy integration from multi_agent)
# ============================================================

def build_portfolio_from_snapshot(
    snapshot: Dict,
    default_iv: Optional[float] = None,
) -> Tuple[Portfolio, float, float]:
    """
    Build a Portfolio from a simple dict snapshot.

    Expected snapshot shape (you will build this in multi_agent):

        snapshot = {
            "index_price": 100000.0,    # BTC-USD
            "base_iv": 0.70,            # optional, baseline IV
            "options": [
                {
                    "instrument_name": "BTC-27JUN25-90000-C",
                    "kind": "call",            # "call" or "put"
                    "strike": 90000.0,
                    "expiry_ts": 1767225600,
                    "size": -0.5,             # BTC
                    "mark_price": 0.02,       # BTC
                    "index_price": 100000.0,  # USD
                    "iv": 0.75,               # optional, if missing -> use base_iv / default_iv
                },
                ...
            ],
            "futures": [
                {
                    "instrument_name": "BTC-PERPETUAL",
                    "expiry_ts": 0,           # or some timestamp
                    "size": 0.1,             # BTC
                    "mark_price": 100500.0,  # USD
                    "index_price": 100000.0, # USD
                },
                ...
            ],
        }

    Returns:
        (portfolio, base_index_price, base_iv)
    """
    if "index_price" not in snapshot:
        raise ValueError("snapshot['index_price'] is required (BTC index price in USD).")

    base_index_price = float(snapshot["index_price"])
    base_iv = float(snapshot.get("base_iv") or (default_iv or 0.7))

    options_raw = snapshot.get("options", []) or []
    futures_raw = snapshot.get("futures", []) or []

    options: List[OptionPosition] = []
    futures: List[FuturePosition] = []

    for o in options_raw:
        iv = o.get("iv")
        if iv is None:
            iv = base_iv
        opt = OptionPosition(
            instrument_name=str(o["instrument_name"]),
            kind=str(o["kind"]).lower().strip(),  # "call" or "put"
            strike=float(o["strike"]),
            expiry_ts=int(o["expiry_ts"]),
            size=float(o["size"]),
            mark_price=float(o["mark_price"]),
            index_price=float(o.get("index_price", base_index_price)),
            iv=float(iv),
        )
        options.append(opt)

    for f in futures_raw:
        fut = FuturePosition(
            instrument_name=str(f["instrument_name"]),
            expiry_ts=int(f.get("expiry_ts", 0)),
            size=float(f["size"]),
            mark_price=float(f["mark_price"]),  # USD
            index_price=float(f.get("index_price", base_index_price)),  # USD
        )
        futures.append(fut)

    portfolio = Portfolio(options=options, futures=futures)
    return portfolio, base_index_price, base_iv


def compute_margin_from_snapshot(
    snapshot: Dict,
    config: Optional[StressConfig] = None,
    now_ts: Optional[int] = None,
) -> MarginResult:
    """
    Convenience function:
        snapshot (dict) → Portfolio → MarginResult

    This is what multi_agent will likely call.
    """
    portfolio, base_index_price, base_iv = build_portfolio_from_snapshot(snapshot)
    return compute_portfolio_margin(
        portfolio=portfolio,
        base_index_price=base_index_price,
        base_iv=base_iv,
        config=config,
        now_ts=now_ts,
    )


# ============================================================
# Explanation Helper (for the LLM)
# ============================================================

def explain_margin_result(
    margin_result: MarginResult,
    base_index_price: float,
    base_iv: float,
    config: Optional[StressConfig] = None,
) -> Dict:
    """
    Structured explanation that you can directly feed to the model
    so it "understands" how IM & MM were computed.

    It does NOT contain any project-specific logic (no MB%, no gating).
    """
    if config is None:
        config = StressConfig.default()

    return {
        "base_index_price": base_index_price,
        "base_iv": base_iv,
        "im_btc": margin_result.im_btc,
        "mm_btc": margin_result.mm_btc,
        "config": {
            "spot_shocks": config.spot_shocks,
            "iv_shocks": config.iv_shocks,
            "im_multiplier": config.im_multiplier,
            "mm_ratio": config.mm_ratio,
            "min_iv": config.min_iv,
        },
        "worst_scenario": {
            "name": margin_result.worst_scenario.name,
            "stressed_index_price": margin_result.worst_scenario.stressed_index_price,
            "stressed_iv_factor": margin_result.worst_scenario.stressed_iv_factor,
            "pnl_btc": margin_result.worst_scenario.pnl_btc,
        },
        "scenarios": [
            {
                "name": s.name,
                "stressed_index_price": s.stressed_index_price,
                "stressed_iv_factor": s.stressed_iv_factor,
                "pnl_btc": s.pnl_btc,
            }
            for s in margin_result.all_scenarios
        ],
    }
