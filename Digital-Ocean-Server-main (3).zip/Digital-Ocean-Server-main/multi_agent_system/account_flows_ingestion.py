#!/usr/bin/env python3
"""
account_flows_ingestion.py

Ingestion agent to sync Deribit deposits and withdrawals into
account_flows table in btc_options.sqlite3.

- Uses .env for config (DERIBIT_API_KEY, DERIBIT_API_SECRET, DERIBIT_TESTNET, BTC_DB_PATH, DAYS_BACK)
- Supports multiple currencies: BTC, USDT, USDC
- No CLI args needed: just `python account_flows_ingestion.py`
"""

import os
import sqlite3
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Iterable, List, Optional

import ccxt
from dotenv import load_dotenv

# Load environment variables
load_dotenv()


from shared.db_paths import TRADING_DB as DB_PATH

print(f"[DB] Using {DB_PATH} in {__file__}", flush=True)
# ============================================================================
# Config
# ============================================================================
CURRENCIES = ["BTC", "USDT", "USDC"]
DEFAULT_DAYS_BACK = int(os.getenv("DAYS_BACK", "90"))


# ============================================================================
# DB Helpers
# ============================================================================
def _get_con(db_path: str) -> sqlite3.Connection:
    return sqlite3.connect(db_path)


def _ensure_account_flows_table(con: sqlite3.Connection) -> None:
    """
    Ensure account_flows table exists.
    """
    con.execute(
        """
        CREATE TABLE IF NOT EXISTS account_flows (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ts_utc TEXT NOT NULL,
            type TEXT NOT NULL,
            amount_btc REAL NOT NULL,
            currency TEXT NOT NULL
        );
        """
    )
    con.commit()


def _get_last_flow_ts_utc(con: sqlite3.Connection) -> Optional[str]:
    """
    Get the latest timestamp we have in account_flows across ALL currencies.
    """
    row = con.execute(
        "SELECT MAX(ts_utc) FROM account_flows"
    ).fetchone()
    return row[0] if row and row[0] else None


def _parse_iso_utc(ts: str) -> datetime:
    dt = datetime.fromisoformat(ts.replace("Z", "+00:00"))
    return dt.astimezone(timezone.utc)


# ============================================================================
# Deribit API Setup
# ============================================================================
@dataclass
class DeribitConfig:
    api_key: str
    api_secret: str
    testnet: bool = False


def _load_deribit_config() -> DeribitConfig:
    key = os.getenv("DERIBIT_CLIENT_ID")
    secret = os.getenv("DERIBIT_CLIENT_SECRET")

    if not key or not secret:
        raise RuntimeError(
            "Missing DERIBIT_CLIENT_ID or DERIBIT_CLIENT_SECRET in .env"
        )

    testnet = os.getenv("DERIBIT_TESTNET", "").lower() in ("1", "true", "yes")

    return DeribitConfig(api_key=key, api_secret=secret, testnet=testnet)


def _make_deribit_exchange(cfg: DeribitConfig) -> "ccxt.deribit":
    exchange = ccxt.deribit({
        "apiKey": cfg.api_key,
        "secret": cfg.api_secret,
        "enableRateLimit": True,
    })
    exchange.set_sandbox_mode(cfg.testnet)
    return exchange


# ============================================================================
# Normalization
# ============================================================================
@dataclass
class FlowRow:
    ts_utc: str
    type: str          # 'deposit' / 'withdrawal'
    amount_btc: float  # signed
    currency: str      # 'BTC' / 'USDT' / 'USDC'


def _normalize_deposits(deposits: Iterable[dict], default_code: str) -> List[FlowRow]:
    rows: List[FlowRow] = []
    for tx in deposits:
        ts_ms = tx.get("timestamp")
        if ts_ms is None:
            continue

        ts_utc = datetime.fromtimestamp(ts_ms / 1000, tz=timezone.utc).isoformat()
        amount = float(tx.get("amount", 0))
        if amount == 0:
            continue

        # ccxt transactions usually have 'currency' or 'code'
        code = (tx.get("currency") or tx.get("code") or default_code).upper()

        # We only care about configured currencies; ignore others
        if code not in CURRENCIES:
            continue

        rows.append(
            FlowRow(
                ts_utc=ts_utc,
                type="deposit",
                amount_btc=amount,
                currency=code,
            )
        )
    return rows


def _normalize_withdrawals(withdrawals: Iterable[dict], default_code: str) -> List[FlowRow]:
    rows: List[FlowRow] = []
    for tx in withdrawals:
        ts_ms = tx.get("timestamp")
        if ts_ms is None:
            continue

        ts_utc = datetime.fromtimestamp(ts_ms / 1000, tz=timezone.utc).isoformat()
        amount = float(tx.get("amount", 0))
        if amount == 0:
            continue

        code = (tx.get("currency") or tx.get("code") or default_code).upper()
        if code not in CURRENCIES:
            continue

        # withdrawals are negative flows
        rows.append(
            FlowRow(
                ts_utc=ts_utc,
                type="withdrawal",
                amount_btc=-abs(amount),
                currency=code,
            )
        )
    return rows


# ============================================================================
# Insert
# ============================================================================
def _insert_flows(con: sqlite3.Connection, flows: List[FlowRow], dry_run: bool = False) -> int:
    if not flows:
        return 0

    _ensure_account_flows_table(con)

    inserted = 0
    for f in flows:
        exists = con.execute(
            """
            SELECT 1 FROM account_flows
            WHERE ts_utc = ? AND type = ? AND amount_btc = ? AND currency = ?
            """,
            (f.ts_utc, f.type, f.amount_btc, f.currency),
        ).fetchone()

        if exists:
            continue

        print(f"[INFO] Inserting flow: {f}")

        if not dry_run:
            con.execute(
                """
                INSERT INTO account_flows (ts_utc, type, amount_btc, currency)
                VALUES (?, ?, ?, ?)
                """,
                (f.ts_utc, f.type, f.amount_btc, f.currency),
            )
            inserted += 1

    if not dry_run:
        con.commit()

    return inserted


# ============================================================================
# Sync Routine
# ============================================================================
def sync_account_flows(db_path: str, days_back: int, dry_run: bool = False):
    cfg = _load_deribit_config()
    exchange = _make_deribit_exchange(cfg)

    with _get_con(db_path) as con:
        _ensure_account_flows_table(con)

        last_ts = _get_last_flow_ts_utc(con)

        if last_ts:
            last_dt = _parse_iso_utc(last_ts)
            since_dt = last_dt - timedelta(days=1)
            print(f"[INFO] Incremental sync from {since_dt.isoformat()}")
        else:
            since_dt = datetime.now(tz=timezone.utc) - timedelta(days=days_back)
            print(f"[INFO] First sync: last {days_back} days")

        since_ms = int(since_dt.timestamp() * 1000)

        all_flows: List[FlowRow] = []

        # Loop through all configured currencies
        for code in CURRENCIES:
            print(f"[INFO] Fetching deposits for {code} since {since_dt.isoformat()}...")
            deposits = exchange.fetch_deposits(code, since=since_ms, limit=1000)

            print(f"[INFO] Fetching withdrawals for {code} since {since_dt.isoformat()}...")
            withdrawals = exchange.fetch_withdrawals(code, since=since_ms, limit=1000)

            dep_rows = _normalize_deposits(deposits, default_code=code)
            wdr_rows = _normalize_withdrawals(withdrawals, default_code=code)

            all_flows.extend(dep_rows)
            all_flows.extend(wdr_rows)

        all_flows.sort(key=lambda x: x.ts_utc)

        print(f"[INFO] Found {len(all_flows)} flow events across {CURRENCIES}.")

        inserted = _insert_flows(con, all_flows, dry_run=dry_run)

        print(f"[INFO] {inserted} new rows inserted.")


# ============================================================================
# Main
# ============================================================================
def main():
    print("[INFO] Running account_flows_ingestion for BTC, USDT, USDC...")
    sync_account_flows(
        db_path=DB_PATH,
        days_back=DEFAULT_DAYS_BACK,
        dry_run=False,   # set to True if you want to test without writing
    )
    print("[INFO] Done.")


if __name__ == "__main__":
    main()
