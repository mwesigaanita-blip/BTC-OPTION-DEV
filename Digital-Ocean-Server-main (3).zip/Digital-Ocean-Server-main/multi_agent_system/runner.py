from __future__ import annotations

import json
import os
import time
import traceback
import logging
from typing import Any, Callable, Optional

import pandas as pd

# NOTE:
# This module must be UI-agnostic (no Streamlit imports).
# It is callable from FastAPI worker or any other backend.

log = logging.getLogger("multi_agent_runner")

def setup_console_logging(level=logging.INFO) -> None:
    import sys
    root = logging.getLogger()
    root.setLevel(level)

    # Avoid duplicate logs if setup runs multiple times
    if any(isinstance(h, logging.StreamHandler) for h in root.handlers):
        return

    handler = logging.StreamHandler(sys.stdout)
    handler.setLevel(level)
    handler.setFormatter(logging.Formatter(
        "%(asctime)s | %(levelname)s | %(name)s | %(message)s"
    ))
    root.addHandler(handler)
    
setup_console_logging(logging.INFO)

# ---------------------------
# Model map (same as Streamlit)
# ---------------------------
MODEL_MAP = {
    "GPT-5":             {"provider": "openai",    "model_id": "gpt-5",                    "table": "decisions_gpt_5_multi_agent"},
    "GPT-5-mini (Test)": {"provider": "openai",    "model_id": "gpt-5-mini",              "table": "decisions_gpt_5_mini_multi_agent"},
    "Claude 4 Sonnet":   {"provider": "anthropic", "model_id": "claude-sonnet-4-20250514","table": "decisions_claude_sonnet_multi_agent"},
    "GROK-4":            {"provider": "xai",       "model_id": "grok-4",                  "table": "decisions_grok4_multi_agent"},
}

# Provider id aliases -> UI labels
MODEL_ID_TO_LABEL = {
    "gpt-5": "GPT-5",
    "gpt-5-mini": "GPT-5-mini (Test)",
    "claude-sonnet-4-20250514": "Claude 4 Sonnet",
    "grok-4": "GROK-4",
}

# ---------------------------
# Helpers: progress + stop
# ---------------------------
ProgressFn = Callable[[str, int, str], None]
StopFn = Callable[[], bool]

def _default_progress(stage: str, pct: int, line: str) -> None:
    log.info("[%s] %s%% %s", stage, pct, line)

def _default_should_stop() -> bool:
    return False

def normalize_model_key(model_key: str) -> str:
    """
    Accepts either:
      - UI label: 'GPT-5', 'Claude 4 Sonnet', ...
      - provider model_id: 'gpt-5', 'gpt-5-mini', ...
    Returns UI label.
    """
    if not model_key:
        return ""
    mk = str(model_key).strip()
    if mk in MODEL_MAP:
        return mk
    # allow ALL
    if mk.upper() == "ALL":
        return "ALL"
    # map provider id -> label
    if mk in MODEL_ID_TO_LABEL:
        return MODEL_ID_TO_LABEL[mk]
    # allow case-insensitive match
    low = mk.lower()
    for k in MODEL_MAP.keys():
        if k.lower() == low:
            return k
    for mid, lbl in MODEL_ID_TO_LABEL.items():
        if mid.lower() == low:
            return lbl
    return mk  # will fail later with clear error

# ---------------------------
# Core runner (moved from Streamlit)
# ---------------------------
# ---------- X score helpers (existing table) ----------
from .config import DB_PATH, get_strategy_text, fetch_account_capital, DAYS_AHEAD
import datetime
from datetime import datetime, timezone
from .runner_db_helper import (
  get_today_x, get_strategy_pair, build_forecast_line_safe,
  save_run_results, insert_run_meta,
)

X_TABLE = "x_score"                         # existing
STRATEGY_TABLE = "strategy_text_store"      # new
RUN_META_TABLE = "model_run_meta"           # new

def run_one_model(
    model_key: str,
    progress: Optional[ProgressFn] = None,
    should_stop: Optional[StopFn] = None,
    params: Optional[dict[str, Any]] = None,
) -> dict[str, Any]:
    """
    Run one model end-to-end and persist results to DB (same behavior as Streamlit).
    Returns a small summary dict for API usage.

    This is extracted from Streamlit/pages/2_Models.py::_run_model_once
    """
    from .btc_options import load_or_fetch_live_options, fetch_current_deribit_positions
    from .multi_agents import run_multi_agent_pipeline
    from .sentiment import get_macro_sentiment_scores_llm
    from .btc_price import get_btc_price
    
    progress = progress or _default_progress
    should_stop = should_stop or _default_should_stop
    params = params or {}

    label = normalize_model_key(model_key)
    cfg = MODEL_MAP.get(label)
    if not cfg:
        progress("error", 1, f"Unknown model label: {label}")
        return {"ok": False, "error": f"Unknown model label: {label}", "model_label": label}

    try:
        progress("prepare", 3, f"Preparing run for {label}…")

        # --- X sentiment required ---
        from .runner_db_helper import get_x_for_run

        x_scores, x_warn = get_x_for_run()
        if x_warn:
            log.warning(x_warn)
            progress("prepare", 5, x_warn)

        xs_now  = x_scores.get("score_now")
        xs_7d   = x_scores.get("score_7d")
        xs_30d  = x_scores.get("score_30d")
        xsent   = x_scores.get("sentence")
        x_used_date = x_scores.get("date_utc")


        # Instead of failing, coerce safely
        def _f(v, default=0.0):
            try:
                return float(v)
            except Exception:
                return default

        xs_now = _f(xs_now, 0.0)
        xs_7d  = _f(xs_7d,  xs_now)
        xs_30d = _f(xs_30d, xs_now)

        xsent  = (xsent or "").strip()

        if not xsent:
            # sentence empty isn't fatal; warn + continue
            msg = f"X sentiment sentence is empty (x_score date: {x_used_date}) – continuing."
            log.warning(msg)
            progress("prepare", 6, msg)


        # --- Strategy text from DB ---
        active_strategy, _ = get_strategy_pair()
        strategy_text = active_strategy or (get_strategy_text() or "")
        progress("prepare", 7, f"Using strategy: {active_strategy or 'default'}")
        # --- Timestamps ---
        now_utc = datetime.now(timezone.utc)
        try:
            import zoneinfo
            now_cairo = now_utc.astimezone(zoneinfo.ZoneInfo("Africa/Cairo"))
        except Exception:
            now_cairo = datetime.now()

        # --- Live data ---
        if should_stop():
            progress("stopped", 5, "Run stopped before loading data.")
            return {"ok": False, "error": "stopped", "model_label": label}

        progress("data", 10, "Loading live options…")
        use_cache_bool = (cfg["model_id"] == "gpt-5-mini")
        live_options_df = load_or_fetch_live_options(days_ahead=DAYS_AHEAD, use_cache=use_cache_bool)

        if live_options_df is None or live_options_df.empty:
            progress("failed", 15, "Could not load live options (empty).")
            return {"ok": False, "error": "live_options empty", "model_label": label}

        if should_stop():
            progress("stopped", 15, "Run stopped after loading live options.")
            return {"ok": False, "error": "stopped", "model_label": label}

        progress("data", 20, "Fetching current positions…")
        positions_df = fetch_current_deribit_positions()

        progress("data", 25, "Fetching BTC price…")
        btc_px = get_btc_price()

        progress("data", 30, "Fetching account capital…")
        try:
            account_info = fetch_account_capital(
                client_id=os.getenv("DERIBIT_CLIENT_ID"),
                client_secret=os.getenv("DERIBIT_CLIENT_SECRET"),
                currency="BTC",
                basis="equity",
            )
        except Exception as e:
            logging.warning("fetch_account_capital failed: %s", e)
            account_info = {}

        try:
            capital = float(account_info.get("capital_usd") or 0.0)
            if capital <= 0:
                raise ValueError("capital_usd <= 0")
        except Exception:
            logging.warning("Invalid CAPITAL; using 100,000.0")
            capital = 100_000.0


        if should_stop():
            progress("stopped", 35, "Run stopped after loading account info.")
            return {"ok": False, "error": "stopped", "model_label": label}

        # --- Forecast (optional) ---
        progress("forecast", 40, "Building BTC range forecast…")
        try:
            forecast_line = build_forecast_line_safe(db_path=DB_PATH)
            progress("forecast", 45, "Forecast line : " + forecast_line)
        except Exception as e:
            logging.warning("Forecast failed: %s", e)
            forecast_line = ""

        # --- Macro sentiment ---
        progress("macro", 50, "Fetching macro sentiment…")
        try:
            macro_dic = get_macro_sentiment_scores_llm(provider=cfg["provider"], model_id=cfg["model_id"])
            macro_now  = macro_dic.get("score_now", 0.0)
            macro_7D   = macro_dic.get("score_7d", 0.0)
            macro_30D  = macro_dic.get("score_30d", 0.0)
            progress("macro", 53, f"Macro sentiment: now={macro_now} 7d={macro_7D} 30d={macro_30D}")
        except Exception as e:
            logging.warning("Macro sentiment failed (%s); using 0.0", e)
            macro_now = macro_7D = macro_30D = 0.0

        if should_stop():
            progress("stopped", 55, "Run stopped before LLM pipeline.")
            return {"ok": False, "error": "stopped", "model_label": label}

        # --- Multi-agent pipeline ---
        progress("multi_agents", 70, "Running multi-agent pipeline…")
        res = run_multi_agent_pipeline(
            live_options_df=live_options_df,
            positions_df=positions_df,
            account_capital_usd=capital,
            strategy_text=strategy_text,
            macro_now=macro_now,
            macro_7D=macro_7D,
            macro_30D=macro_30D,
            btc_price=btc_px,
            account_info=account_info,
            llm_model_id=cfg["model_id"],
            forecast_message=forecast_line,
            max_candidates=int(params.get("max_candidates", 50)),
            max_rows_to_llm=int(params.get("max_rows_to_llm", 50)),
            provider=cfg["provider"],
            debuge=bool(params.get("debuge", False)),
            x_score_now=xs_now,
            x_score_7D=xs_7d,
            x_score_30D=xs_30d,
            x_sentence_input=xsent,
        )

        progress("persist", 90, "Saving run meta to DB…")
        total_cost = 0.0
        if isinstance(res, dict) and "total_cost" in res:
            try:
                total_cost = float(res["total_cost"])
            except Exception:
                total_cost = 0.0

        close_sent = res.get("close_sentence", "") if isinstance(res, dict) else ""
        open_sent  = res.get("allocation_sentence", "") if isinstance(res, dict) else ""
        fund_text  = res.get("formatted_fundamental_text", "") if isinstance(res, dict) else ""
        sent_text  = res.get("formatted_sentiment_text", "") if isinstance(res, dict) else ""
        margin_json = json.dumps(res.get("margin_engine", {})) if isinstance(res, dict) else "{}"

        save_run_results(
            model_label=label, provider=cfg["provider"], model_id=cfg["model_id"],
            now_utc=now_utc.isoformat(),
            close_sentence=close_sent, open_sentence=open_sent,
            fund_text=fund_text, sent_text=sent_text, margin_json=margin_json
        )

        insert_run_meta(
            model_label=label,
            provider=cfg["provider"],
            model_id=cfg["model_id"],
            total_cost=total_cost,
            run_time_utc_iso=now_utc.isoformat(),
            run_time_cairo_iso=now_cairo.isoformat(),
        )

        progress("done", 99, f"Run for {label} completed. Decisions saved to DB.")
        return {"ok": True, "model_label": label, "provider": cfg["provider"], "model_id": cfg["model_id"], "total_cost": total_cost}

    except Exception as e:
        progress("failed", 99, f"Run failed for {label}: {e}")
        return {"ok": False, "error": str(e), "trace": traceback.format_exc(), "model_label": label}

def run_all_models(
    progress: Optional[ProgressFn] = None,
    should_stop: Optional[StopFn] = None,
    params: Optional[dict[str, Any]] = None,
) -> dict[str, Any]:
    progress = progress or _default_progress
    should_stop = should_stop or _default_should_stop
    params = params or {}

    model_sequence = ["GPT-5", "Claude 4 Sonnet", "GROK-4"]  # matches your Streamlit order :contentReference[oaicite:1]{index=1}
    total = len(model_sequence)
    results: dict[str, Any] = {}

    for idx, label in enumerate(model_sequence, start=1):
        if should_stop():
            progress("stopped", int((idx - 1) / total * 100), f"Stopping ALL-model run before {label}…")
            return {"ok": False, "error": "stopped", "results": results}

        progress("switch_model", int((idx - 1) / total * 100), f"Starting {label} ({idx}/{total})…")
        results[label] = run_one_model(label, progress=progress, should_stop=should_stop, params=params)

    return {"ok": True, "results": results}
