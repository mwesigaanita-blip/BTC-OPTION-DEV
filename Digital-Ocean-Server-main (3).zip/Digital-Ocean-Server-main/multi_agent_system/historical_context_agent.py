from __future__ import annotations

# historical_context_agent.py
"""
1. Implemented a Historical Context Agent that loads trade, margin, equity, and BTC-regime data from SQLite and computes deterministic performance/risk metrics per model over a configurable lookback window:

- For CLOSED trades:
  - Take entry price = avg_price_btc and exit price = mark_price_btc for each row with action == "CLOSE". 
  - Compute pnl_per_contract = (entry - mark) if side == "SELL", or (mark - entry) if side == "BUY"; win if pnl_per_contract > 0, loss if < 0. 

- For OPEN trades (50% hit-rate metric):
  - For each row with action == "OPEN", load all btc_live_options marks between decision_date and expiration for that symbol. 
  - Recompute unrealized PnL over time using the same BUY/SELL logic, convert to % of entry; if max profit >= +50% → WIN, if it never reaches +50% → LOSS, and if data is insufficient the trade is skipped from this metric.

2. Aggregated these metrics into a human-readable base summary plus a structured metrics dict, so other agents can consume this as standardized HISTORICAL_CONTEXT. 

3. Integrated a GPT-5-mini call through the existing LLM client wrapper to optionally turn the base summary + metrics into a concise narrative performance summary and a set of prescriptive trading rules.


note: we need to know the withdraws happen in the account 
note : how we can imporve the win rate 
"""


"""
Historical Context Agent

Computes model-specific historical performance and risk context over a recent window
using SQLite data, including:

- Closed-trade win rate (realized PnL proxy from decisions_<model>_multi_agent)
- OPEN suggestion "50% profit hit" statistics using btc_live_options daily marks
- Basic margin usage stats from MM_IM
- Simple equity and BTC regime summary

Then optionally calls a lightweight LLM (GPT-5-mini) to turn raw metrics into a
smarter narrative summary and prescriptive rules for future behavior.

Public entry point:
    build_historical_context(
        model_label,
        provider,
        model_id,
        decisions_table,
        days_back=60,
        db_path=DB_PATH,
        use_llm=True,
        temperature=0.1,
        max_tokens=512,
        verbose=False,
    )

Returns:
    {
        "summary_text": <LLM-enhanced or raw summary>,
        "rules_text": <LLM rules or None>,
        "metrics": { ... detailed numeric fields ... }
    }

You can feed summary_text / rules_text into other LLM agents as HISTORICAL_CONTEXT.
"""


import json
import sqlite3
from dataclasses import dataclass
from datetime import datetime, date, timedelta
from typing import Any, Dict, Optional

import pandas as pd
from shared.db_paths import (
    MODELS_DB,
    SNAPSHOTS_DB,
    TRADING_DB,
    MARKET_DATA_DB,
)

# Tables this module touches, by owning DB:
#   MODELS_DB:      model_quality_daily, MM_IM, decisions_*_multi_agent
#   SNAPSHOTS_DB:   account_snapshots
#   TRADING_DB:     account_flows
#   MARKET_DATA_DB: btc_prices
# The legacy ``DB_PATH`` symbol points at MODELS_DB (the primary domain
# of this file) for any external code that imported it from here.
DB_PATH = MODELS_DB
print(
    f"[DB] Using MODELS_DB={MODELS_DB}, SNAPSHOTS_DB={SNAPSHOTS_DB}, "
    f"TRADING_DB={TRADING_DB}, MARKET_DATA_DB={MARKET_DATA_DB} in {__file__}",
    flush=True,
)


try:
    from .llm_io import make_llm_client  # type: ignore
except ImportError:
    make_llm_client = None  # type: ignore

OPEN_TRADES_TABLE_MAP: Dict[str, str] = {
    "GPT-5": "open_trades_gpt_5",
    "GPT-5-mini (Test)": "open_trades_gpt_5_mini",
    "Claude 4 Sonnet": "open_trades_claude_sonnet_4_20250514",
    "GROK-4": "open_trades_grok_4",
}


@dataclass
class ClosedWinRate:
    total_closed: int
    wins: int
    losses: int
    win_rate: Optional[float]  # 0..1 or None if no closed trades


@dataclass
class Open50PctStats:
    evaluated: int
    wins: int
    losses: int
    hit_rate: Optional[float]  # 0..1 or None if no evaluated trades

@dataclass
class HoldDecisionStats:
    evaluated: int
    good: int
    bad: int
    good_rate: Optional[float]  # 0..1 or None if no evaluated HOLD decisions


@dataclass
class MarginStats:
    rows: int
    avg_mm_before: Optional[float]
    avg_mm_after: Optional[float]
    max_mm_after: Optional[float]


@dataclass
class EquityStats:
    rows: int
    equity_start: Optional[float]
    equity_end: Optional[float]
    pct_change: Optional[float]
    # New fields for flow-adjusted PnL
    net_flows_btc: Optional[float] = None
    trading_pnl_btc: Optional[float] = None
    trading_pnl_pct: Optional[float] = None
    # New: net flows for all currencies (BTC, USDT, USDC, etc.)
    net_flows_by_currency: Optional[Dict[str, float]] = None




@dataclass
class RegimeStats:
    rows: int
    pct_up_big: float
    pct_down_big: float
    pct_flat: float


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _con(db_path: str = "") -> sqlite3.Connection:
    """Open a connection.

    For backward compatibility ``db_path`` is still accepted: callers that
    pass a path get a connection to that path. With no argument the
    connection is opened against ``MODELS_DB`` (model_quality_daily and
    MM_IM live there).

    For the legitimate cross-DB tables this module touches
    (account_snapshots, account_flows, btc_prices) use the dedicated
    ``_con_snapshots`` / ``_con_trading`` / ``_con_market`` helpers
    below.
    """
    if not db_path:
        db_path = str(MODELS_DB)
    return sqlite3.connect(str(db_path), timeout=30)


def _con_snapshots() -> sqlite3.Connection:
    return sqlite3.connect(str(SNAPSHOTS_DB), timeout=30)


def _con_trading() -> sqlite3.Connection:
    return sqlite3.connect(str(TRADING_DB), timeout=30)


def _con_market() -> sqlite3.Connection:
    return sqlite3.connect(str(MARKET_DATA_DB), timeout=30)

# --- Add near the top of historical_context_agent.py (after imports / _con) ---
def ensure_column_exists(
    table: str,
    column: str,
    col_type: str,
    db_path: str = DB_PATH,
) -> None:
    """
    Ensure a column exists in a SQLite table.
    Safe to call multiple times.
    """
    with _con(db_path) as con:
        cur = con.execute(f"PRAGMA table_info({table});")
        cols = {row[1] for row in cur.fetchall()}  # row[1] = column name

        if column in cols:
            return  # already exists

        con.execute(
            f"ALTER TABLE {table} ADD COLUMN {column} {col_type};"
        )
        con.commit()

def ensure_model_quality_tables(db_path: str = DB_PATH) -> None:
    ddl = """
    CREATE TABLE IF NOT EXISTS model_quality_daily (
        asof_date_utc      TEXT NOT NULL,
        model_label        TEXT NOT NULL,
        provider           TEXT,
        model_id           TEXT,
        decisions_table    TEXT NOT NULL,
        days_back          INTEGER NOT NULL,

        closed_win_pct         REAL,
        open_50_hit_pct        REAL,
        hold_good_pct          REAL,
        model_accuracy_pct     REAL,

        closed_total           INTEGER,
        closed_wins            INTEGER,
        closed_losses          INTEGER,
        open_50_evaluated      INTEGER,
        open_50_wins           INTEGER,
        open_50_losses         INTEGER,
        hold_evaluated         INTEGER,
        hold_good              INTEGER,
        hold_bad               INTEGER,

        metrics_json       TEXT,
        updated_at_utc     TEXT NOT NULL,

        PRIMARY KEY (asof_date_utc, model_label, days_back)
    );
    """

    idx1 = """
    CREATE INDEX IF NOT EXISTS idx_model_quality_daily_lookup
    ON model_quality_daily(model_label, days_back, asof_date_utc);
    """

    idx2 = """
    CREATE INDEX IF NOT EXISTS idx_model_quality_daily_updated
    ON model_quality_daily(updated_at_utc);
    """

    with _con(db_path) as con:
        con.execute(ddl)
        con.execute(idx1)
        con.execute(idx2)
        con.commit()

    # ✅ NOW the table exists → safe to ALTER if needed
    ensure_column_exists(
        table="model_quality_daily",
        column="total_trades_assessed",
        col_type="INTEGER",
        db_path=db_path,
    )

    # (optional) ✅ backfill existing rows once
    with _con(db_path) as con:
        con.execute("""
            UPDATE model_quality_daily
            SET total_trades_assessed =
                  COALESCE(closed_total, 0)
                + COALESCE(open_50_evaluated, 0)
                + COALESCE(hold_evaluated, 0)
            WHERE total_trades_assessed IS NULL
        """)
        con.commit()


def upsert_model_quality_daily(
    *,
    asof_date_utc: str,
    model_label: str,
    provider: Optional[str],
    model_id: Optional[str],
    decisions_table: str,
    days_back: int,
    stats: Dict[str, Any],
    db_path: str = DB_PATH,
) -> None:
    """
    Upsert one cached row for a model/day/lookback.
    `stats` is the dict returned by get_model_decision_quality_for_website().
    """
    ensure_model_quality_tables(db_path=db_path)

    updated_at = datetime.utcnow().replace(microsecond=0).isoformat()
    metrics_json = json.dumps(stats, ensure_ascii=False)

    q = """
    INSERT INTO model_quality_daily (
        asof_date_utc, model_label, provider, model_id, decisions_table, days_back,
        closed_win_pct, open_50_hit_pct, hold_good_pct, model_accuracy_pct,
        total_trades_assessed,
        closed_total, closed_wins, closed_losses,
        open_50_evaluated, open_50_wins, open_50_losses,
        hold_evaluated, hold_good, hold_bad,
        metrics_json, updated_at_utc
    ) VALUES (
        ?, ?, ?, ?, ?, ?,
        ?, ?, ?, ?,
        ?,
        ?, ?, ?,
        ?, ?, ?,
        ?, ?, ?,
        ?, ?
    )
    ON CONFLICT(asof_date_utc, model_label, days_back) DO UPDATE SET
        provider=excluded.provider,
        model_id=excluded.model_id,
        decisions_table=excluded.decisions_table,

        closed_win_pct=excluded.closed_win_pct,
        open_50_hit_pct=excluded.open_50_hit_pct,
        hold_good_pct=excluded.hold_good_pct,
        model_accuracy_pct=excluded.model_accuracy_pct,

        total_trades_assessed=excluded.total_trades_assessed,

        closed_total=excluded.closed_total,
        closed_wins=excluded.closed_wins,
        closed_losses=excluded.closed_losses,
        open_50_evaluated=excluded.open_50_evaluated,
        open_50_wins=excluded.open_50_wins,
        open_50_losses=excluded.open_50_losses,
        hold_evaluated=excluded.hold_evaluated,
        hold_good=excluded.hold_good,
        hold_bad=excluded.hold_bad,

        metrics_json=excluded.metrics_json,
        updated_at_utc=excluded.updated_at_utc
    ;
    """


    def _g(key: str, default=None):
        return stats.get(key, default)

    with _con(db_path) as con:
        con.execute(
            q,
            (
                asof_date_utc, model_label, provider, model_id, decisions_table, int(days_back),
                _g("closed_win_pct"), _g("open_50_hit_pct"), _g("hold_good_pct"), _g("model_accuracy_pct"),
                _g("total_trades_assessed"),
                _g("closed_total"), _g("closed_wins"), _g("closed_losses"),
                _g("open_50_evaluated"), _g("open_50_wins"), _g("open_50_losses"),
                _g("hold_evaluated"), _g("hold_good"), _g("hold_bad"),
                metrics_json, updated_at
            ),
        )

        con.commit()


def get_cached_model_quality(
    *,
    model_label: str,
    days_back: int = 60,
    asof_date_utc: Optional[str] = None,
    db_path: str = DB_PATH,
) -> Optional[Dict[str, Any]]:
    """
    Fetch cached model quality for (today/model/days_back).
    Returns the decoded metrics dict (from metrics_json) plus metadata fields.
    """
    ensure_model_quality_tables(db_path=db_path)

    day = asof_date_utc or datetime.utcnow().date().isoformat()

    q = """
    SELECT asof_date_utc, model_label, provider, model_id, decisions_table, days_back,
           metrics_json, updated_at_utc
    FROM model_quality_daily
    WHERE asof_date_utc = ?
      AND model_label = ?
      AND days_back = ?
    LIMIT 1
    """
    with _con(db_path) as con:
        row = con.execute(q, (day, model_label, int(days_back))).fetchone()

    if not row:
        return None

    asof_date_utc, model_label, provider, model_id, decisions_table, days_back, metrics_json, updated_at_utc = row

    out: Dict[str, Any]
    try:
        out = json.loads(metrics_json) if metrics_json else {}
    except Exception:
        out = {}

    # attach metadata (useful for UI)
    out["_meta"] = {
        "asof_date_utc": asof_date_utc,
        "model_label": model_label,
        "provider": provider,
        "model_id": model_id,
        "decisions_table": decisions_table,
        "days_back": days_back,
        "updated_at_utc": updated_at_utc,
        "cached": True,
    }
    return out


def get_model_quality_cached_or_compute(
    *,
    model_label: str,
    decisions_table: str,
    provider: Optional[str] = None,
    model_id: Optional[str] = None,
    days_back: int = 60,
    db_path: str = DB_PATH,
    allow_compute_fallback: bool = True,
) -> Dict[str, Any]:
    """
    Streamlit-friendly helper:
      - Try cached row for today
      - If missing and allow_compute_fallback=True, compute now and upsert cache
    """
    cached = get_cached_model_quality(
        model_label=model_label,
        days_back=days_back,
        asof_date_utc=None,
        db_path=db_path,
    )
    if cached is not None:
        return cached

    if not allow_compute_fallback:
        return {"_meta": {"cached": False, "missing": True}}

    # Compute using your existing deterministic function
    stats = get_model_decision_quality_for_website(
        decisions_table=decisions_table,
        days_back=days_back,
        db_path=db_path,
    )

    # Save today’s cache
    upsert_model_quality_daily(
        asof_date_utc=datetime.utcnow().date().isoformat(),
        model_label=model_label,
        provider=provider,
        model_id=model_id,
        decisions_table=decisions_table,
        days_back=days_back,
        stats=stats,
        db_path=db_path,
    )

    stats["_meta"] = {
        "asof_date_utc": datetime.utcnow().date().isoformat(),
        "model_label": model_label,
        "provider": provider,
        "model_id": model_id,
        "decisions_table": decisions_table,
        "days_back": days_back,
        "updated_at_utc": datetime.utcnow().replace(microsecond=0).isoformat(),
        "cached": False,
        "computed_on_demand": True,
    }
    return stats


def recompute_and_cache_quality_for_models(
    *,
    models: list[dict],
    days_back: int = 60,
    db_path: str = DB_PATH,
) -> None:
    """
    Worker job entrypoint.
    `models` is a list like:
      [{"label":"GPT-5","provider":"openai","model_id":"gpt-5","decisions_table":"decisions_gpt_5_multi_agent"}, ...]
    """
    ensure_model_quality_tables(db_path=db_path)

    today = datetime.utcnow().date().isoformat()
    for m in models:
        label = str(m.get("label", "")).strip()
        decisions_table = str(m.get("decisions_table", "")).strip()
        provider = m.get("provider")
        model_id = m.get("model_id")

        if not label or not decisions_table:
            continue

        stats = get_model_decision_quality_for_website(
            decisions_table=decisions_table,
            days_back=days_back,
            db_path=db_path,
        )

        upsert_model_quality_daily(
            asof_date_utc=today,
            model_label=label,
            provider=str(provider) if provider is not None else None,
            model_id=str(model_id) if model_id is not None else None,
            decisions_table=decisions_table,
            days_back=days_back,
            stats=stats,
            db_path=db_path,
        )

def _parse_iso_date(d: str) -> date:
    """
    Parse a date or datetime string into date.
    Handles 'YYYY-MM-DD', 'YYYY-MM-DDTHH:MM:SS', and Z-suffixed.
    """
    if not d:
        raise ValueError("empty date string")
    d = d.replace("Z", "")
    for fmt in ("%Y-%m-%d", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M:%S"):
        try:
            return datetime.strptime(d, fmt).date()
        except ValueError:
            continue
    return pd.to_datetime(d, errors="coerce").date()  # type: ignore

def _load_decisions_last_n_days(
    decisions_table: str, days_back: int, db_path: str
) -> pd.DataFrame:
    cutoff = (datetime.utcnow().date() - timedelta(days=days_back)).isoformat()
    q = f"SELECT * FROM {decisions_table} WHERE decision_date >= ?"
    with _con(db_path) as con:
        df = pd.read_sql_query(q, con, params=(cutoff,))
    return df

def _compute_closed_win_rate(
    df_decisions: pd.DataFrame,
    db_path: str,
) -> ClosedWinRate:
    """
    Closed-trade win rate with "Option B" path-aware logic.

    - If a trade was CLOSED with positive realized PnL -> WIN.
    - If CLOSED with negative PnL:
        * Look at mark prices between decision_date and min(expiry, today).
        * If it NEVER recovers to a better PnL than at close -> WIN (good defensive close).
        * If it WOULD have recovered to a better / positive PnL -> LOSS (bad early close).
        * If there is not enough future data -> SKIP this trade (neither win nor loss).

    The win_rate is computed over (wins + losses), ignoring skipped trades.
    """

    if df_decisions.empty:
        return ClosedWinRate(total_closed=0, wins=0, losses=0, win_rate=None)

    required_cols = {"action", "side", "avg_price_btc", "mark_price_btc", "symbol", "decision_date"}
    if not required_cols.issubset(set(df_decisions.columns)):
        return ClosedWinRate(total_closed=0, wins=0, losses=0, win_rate=None)

    df_close = df_decisions[df_decisions["action"].str.upper() == "CLOSE"].copy()
    if df_close.empty:
        return ClosedWinRate(total_closed=0, wins=0, losses=0, win_rate=None)

    wins = 0
    losses = 0

    for _, row in df_close.iterrows():
        try:
            entry = float(row.get("avg_price_btc") or 0.0)
            mark = float(row.get("mark_price_btc") or 0.0)
        except Exception:
            continue
        if entry <= 0 or mark <= 0:
            # Can't meaningfully score this trade
            continue

        side = str(row.get("side", "")).upper()
        symbol = str(row.get("symbol", ""))
        decision_date_str = str(row.get("decision_date", ""))

        # PnL at the close moment
        if side == "SELL":
            pnl_close = entry - mark
        elif side == "BUY":
            pnl_close = mark - entry
        else:
            # Unknown side → skip from stats
            continue

        if pnl_close > 0:
            # Classic winner
            wins += 1
        elif pnl_close < 0:
            outcome = _eval_single_close_future_worse(
                symbol=symbol,
                decision_date_str=decision_date_str,
                side=side,
                entry_price=entry,
                close_mark_price=mark,
                db_path=db_path,
            )

            if outcome is True:
                # Never recovered to a better PnL than at close → GOOD defensive close.
                wins += 1
            elif outcome is False:
                # Would have recovered to better/positive PnL → BAD early close.
                losses += 1
            else:
                # outcome is None → insufficient future data, SKIP this trade
                # (do not increment wins or losses)
                continue
        # pnl_close == 0 → neutral; we can just skip it
        else:
            continue

    total_evaluated = wins + losses
    win_rate = (wins / total_evaluated) if total_evaluated > 0 else None

    return ClosedWinRate(
        total_closed=total_evaluated,
        wins=wins,
        losses=losses,
        win_rate=win_rate,
    )

def _get_expiration_for_symbol(symbol: str, db_path: str) -> Optional[date]:
    """
    Infer expiration for a Deribit option symbol by looking it up in snapshot Parquet files.
    Uses the earliest expiration row it finds.
    """
    from multi_agent_system.snapshot_pipeline import read_snapshot_range
    from datetime import timedelta

    # Search last 365 days of snapshots for this instrument
    today = date.today()
    df = read_snapshot_range(
        today - timedelta(days=365), today,
        columns=["instrument_name", "expiration"],
    )
    if df.empty:
        return None

    matched = df[df["instrument_name"] == symbol]
    if matched.empty:
        return None

    try:
        exp = matched["expiration"].dropna().iloc[0]
        return _parse_iso_date(str(exp))
    except Exception:
        return None

def _eval_single_close_future_worse(
    symbol: str,
    decision_date_str: str,
    side: str,
    entry_price: float,
    close_mark_price: float,
    db_path: str,
) -> Optional[bool]:
    """
    Option B logic for a CLOSED trade that had negative PnL at close.

    We assume this trade was CLOSED with pnl_close < 0.

    Returns:
        True  -> GOOD CLOSE (WIN):
                 After the close, between decision_date and min(expiry, today),
                 the trade NEVER recovers to a *better* PnL than at close.
                 i.e. holding would have been worse or still negative the whole time.
        False -> BAD CLOSE (LOSS):
                 At some later point before min(expiry, today),
                 PnL becomes clearly better than at close
                 (and can even go positive) – so closing was premature.
        None  -> insufficient data (no usable future marks, no expiry, etc.).
    """
    if entry_price <= 0:
        return None

    try:
        decision_d = _parse_iso_date(decision_date_str)
    except Exception:
        return None

    expiry_d = _get_expiration_for_symbol(symbol, db_path=db_path)
    if expiry_d is None:
        return None

    # Only use realized history: from close date up to min(expiry, today).
    today_d = date.today()
    end_d = min(expiry_d, today_d)
    if end_d <= decision_d:
        # No future window yet
        return None

    from multi_agent_system.snapshot_pipeline import read_snapshot_range
    _snap = read_snapshot_range(
        decision_d + timedelta(days=1), end_d,
        columns=["instrument_name", "snapshot_date", "mark_price"],
    )
    df = _snap[_snap["instrument_name"] == symbol][["snapshot_date", "mark_price"]].copy() if not _snap.empty else pd.DataFrame(columns=["snapshot_date", "mark_price"])
    df = df.sort_values("snapshot_date").reset_index(drop=True)

    if df.empty or "mark_price" not in df.columns:
        return None

    side_u = side.upper()

    # PnL at close
    if side_u == "SELL":
        pnl_close = entry_price - close_mark_price
    elif side_u == "BUY":
        pnl_close = close_mark_price - entry_price
    else:
        return None

    # Sanity: this helper is only supposed to be called if pnl_close < 0
    # but we won't enforce that here; caller enforces it.

    future_pnls: list[float] = []

    for _, row in df.iterrows():
        mp = row.get("mark_price")
        if mp is None:
            continue
        try:
            mp_f = float(mp)
        except Exception:
            continue
        if mp_f <= 0:
            continue

        if side_u == "SELL":
            pnl_t = entry_price - mp_f
        elif side_u == "BUY":
            pnl_t = mp_f - entry_price
        else:
            return None

        future_pnls.append(pnl_t)

    if not future_pnls:
        return None

    max_future_pnl = max(future_pnls)

    # Tiny epsilon to avoid float noise
    eps = 1e-9

    # If the trade *ever* recovers to a meaningfully better PnL than at close
    # (especially if it goes positive), treat it as a BAD early close -> LOSS.
    if max_future_pnl > pnl_close + eps:
        return False   # LOSS

    # Otherwise, it never does better than the close level (worse or flat/negative)
    # -> good defensive close -> WIN.
    return True

def _eval_single_open_50pct(
    symbol: str,
    decision_date_str: str,
    side: str,
    entry_price: float,
    db_path: str,
) -> Optional[bool]:
    """
    Evaluate a single OPEN suggestion: did it ever reach >= +50% profit
    between decision_date and expiration?

    Returns:
        True  -> would have hit 50% profit at some point (WIN)
        False -> never hit 50% (LOSS)
        None  -> insufficient data (no marks / no expiration)
    """
    if entry_price <= 0:
        return None

    try:
        decision_d = _parse_iso_date(decision_date_str)
    except Exception:
        return None

    expiry_d = _get_expiration_for_symbol(symbol, db_path=db_path)
    if expiry_d is None:
        return None

    from multi_agent_system.snapshot_pipeline import read_snapshot_range
    _snap = read_snapshot_range(
        decision_d, expiry_d,
        columns=["instrument_name", "snapshot_date", "mark_price"],
    )
    df = _snap[_snap["instrument_name"] == symbol][["snapshot_date", "mark_price"]].copy() if not _snap.empty else pd.DataFrame(columns=["snapshot_date", "mark_price"])
    df = df.sort_values("snapshot_date").reset_index(drop=True)

    if df.empty or "mark_price" not in df.columns:
        return None

    side_u = side.upper()
    prof_pcts = []
    for _, row in df.iterrows():
        mp = row.get("mark_price")
        if mp is None:
            continue
        try:
            mp_f = float(mp)
        except Exception:
            continue
        if mp_f <= 0:
            continue
        if side_u == "SELL":
            pnl_per = entry_price - mp_f
        elif side_u == "BUY":
            pnl_per = mp_f - entry_price
        else:
            return None
        pnl_pct = (pnl_per / entry_price) * 100.0
        prof_pcts.append(pnl_pct)

    if not prof_pcts:
        return None

    max_profit_pct = max(prof_pcts)
    return bool(max_profit_pct >= 50.0)

def _eval_single_hold_pathwise(
    symbol: str,
    decision_date_str: str,
    side: str,
    entry_price: float,
    hold_mark_price: float,
    db_path: str,
    giveback_tol: float = 0.25,
) -> Optional[bool]:
    """
    Evaluate a single HOLD decision by replaying the future path after the HOLD.

    Returns:
        True  -> HOLD judged beneficial vs closing at decision_date.
        False -> HOLD judged harmful (closing at decision_date would have been better).
        None  -> insufficient data (no marks / no expiration / etc.).
    """
    if entry_price <= 0 or hold_mark_price <= 0:
        return None

    try:
        decision_d = _parse_iso_date(decision_date_str)
    except Exception:
        return None

    expiry_d = _get_expiration_for_symbol(symbol, db_path=db_path)
    if expiry_d is None:
        return None

    today_d = date.today()
    end_d = min(expiry_d, today_d)
    if end_d <= decision_d:
        # No future window yet
        return None

    side_u = str(side).upper()
    if side_u == "SELL":
        pnl_hold = entry_price - hold_mark_price
    elif side_u == "BUY":
        pnl_hold = hold_mark_price - entry_price
    else:
        return None

    tiny = 1e-9
    if abs(pnl_hold) < tiny:
        # Essentially flat at HOLD; skip to keep the signal clean.
        return None

    from multi_agent_system.snapshot_pipeline import read_snapshot_range
    _snap = read_snapshot_range(
        decision_d + timedelta(days=1), end_d,
        columns=["instrument_name", "snapshot_date", "mark_price"],
    )
    df = _snap[_snap["instrument_name"] == symbol][["snapshot_date", "mark_price"]].copy() if not _snap.empty else pd.DataFrame(columns=["snapshot_date", "mark_price"])
    df = df.sort_values("snapshot_date").reset_index(drop=True)

    if df.empty or "mark_price" not in df.columns:
        return None

    future_pnls = []
    for _, row in df.iterrows():
        mp = row.get("mark_price")
        if mp is None:
            continue
        try:
            mp_f = float(mp)
        except Exception:
            continue
        if mp_f <= 0:
            continue

        if side_u == "SELL":
            pnl_per = entry_price - mp_f
        else:  # BUY
            pnl_per = mp_f - entry_price

        future_pnls.append(pnl_per)

    if not future_pnls:
        return None

    max_future = max(future_pnls)
    final_pnl = future_pnls[-1]

    # ---- Losing at HOLD: pnl_hold < 0 ----
    if pnl_hold < 0:
        # If we ever see better PnL than at HOLD, we consider the HOLD "good" –
        # it gave at least one chance to reduce the loss or flip.
        return bool(max_future > pnl_hold + tiny)

    # ---- Winning at HOLD: pnl_hold > 0 ----
    profit_at_hold = pnl_hold

    # If we end in a loss after having profit at HOLD -> bad HOLD.
    if final_pnl <= 0:
        return False

    # If final PnL is significantly worse than at HOLD (gave back too much), treat as bad.
    if final_pnl < (1.0 - giveback_tol) * profit_at_hold:
        return False

    # Otherwise HOLD is judged beneficial/acceptable.
    return True

def _compute_open_50pct_stats(
    df_decisions: pd.DataFrame,
    db_path: str,
) -> Open50PctStats:
    if df_decisions.empty:
        return Open50PctStats(evaluated=0, wins=0, losses=0, hit_rate=None)

    required_cols = {"symbol", "action", "side", "avg_price_btc", "decision_date"}
    if not required_cols.issubset(set(df_decisions.columns)):
        return Open50PctStats(evaluated=0, wins=0, losses=0, hit_rate=None)

    df_open = df_decisions[
        (df_decisions["action"].str.upper() == "OPEN")
        & df_decisions["avg_price_btc"].notna()
        & df_decisions["decision_date"].notna()
    ].copy()

    if df_open.empty:
        return Open50PctStats(evaluated=0, wins=0, losses=0, hit_rate=None)

    wins = 0
    losses = 0
    evaluated = 0

    for _, row in df_open.iterrows():
        symbol = str(row["symbol"])
        side = str(row["side"])
        decision_date_str = str(row["decision_date"])
        try:
            entry_price = float(row["avg_price_btc"])
        except Exception:
            continue

        outcome = _eval_single_open_50pct(
            symbol=symbol,
            decision_date_str=decision_date_str,
            side=side,
            entry_price=entry_price,
            db_path=db_path,
        )
        if outcome is None:
            continue

        evaluated += 1
        if outcome is True:
            wins += 1
        else:
            losses += 1

    hit_rate = (wins / evaluated) if evaluated > 0 else None
    return Open50PctStats(evaluated=evaluated, wins=wins, losses=losses, hit_rate=hit_rate)

def _compute_hold_stats(
    df_decisions: pd.DataFrame,
    db_path: str,
) -> HoldDecisionStats:
    """
    Compute HOLD decision quality stats using path-aware logic.

    - We only look at rows with action == 'HOLD'.
    - For each, we compare the future path vs closing at the HOLD mark.
    """
    if df_decisions.empty:
        return HoldDecisionStats(evaluated=0, good=0, bad=0, good_rate=None)

    required_cols = {"symbol", "action", "side", "avg_price_btc", "mark_price_btc", "decision_date"}
    if not required_cols.issubset(set(df_decisions.columns)):
        return HoldDecisionStats(evaluated=0, good=0, bad=0, good_rate=None)

    df_hold = df_decisions[df_decisions["action"].str.upper() == "HOLD"].copy()
    if df_hold.empty:
        return HoldDecisionStats(evaluated=0, good=0, bad=0, good_rate=None)

    evaluated = 0
    good = 0
    bad = 0

    for _, row in df_hold.iterrows():
        symbol = str(row["symbol"])
        side = str(row["side"])
        decision_date_str = str(row["decision_date"])

        try:
            entry_price = float(row["avg_price_btc"])
            hold_mark = float(row["mark_price_btc"])
        except Exception:
            continue

        outcome = _eval_single_hold_pathwise(
            symbol=symbol,
            decision_date_str=decision_date_str,
            side=side,
            entry_price=entry_price,
            hold_mark_price=hold_mark,
            db_path=db_path,
        )

        if outcome is None:
            continue

        evaluated += 1
        if outcome:
            good += 1
        else:
            bad += 1

    good_rate = (good / evaluated) if evaluated > 0 else None
    return HoldDecisionStats(evaluated=evaluated, good=good, bad=bad, good_rate=good_rate)

def _compute_overall_model_accuracy(
    closed_wr: ClosedWinRate,
    open_50: Open50PctStats,
    hold_stats: HoldDecisionStats,
) -> tuple[Optional[float], Optional[float]]:
    """
    Compute a single 'model_accuracy' metric by combining:
      - closed_win_rate
      - open_50 hit rate
      - hold_good_rate

    Weighted by the number of decisions in each bucket.
    Returns (rate_0_1, pct_0_100) or (None, None) if no data.
    """
    numer = 0.0
    denom = 0

    buckets = [
        (closed_wr.win_rate, closed_wr.total_closed),
        (open_50.hit_rate, open_50.evaluated),
        (hold_stats.good_rate, hold_stats.evaluated),
    ]

    for rate, count in buckets:
        if rate is None:
            continue
        try:
            n = int(count)
        except Exception:
            continue
        if n <= 0:
            continue
        numer += float(rate) * n
        denom += n

    if denom <= 0:
        return None, None

    acc = numer / denom
    return acc, acc * 100.0

def _load_margin_stats(
    provider: str, model_id: str, db_path: str
) -> MarginStats:
    q = """
        SELECT mm_pct_mb_before, mm_pct_mb_after
        FROM MM_IM
        WHERE provider = ?
          AND model_id = ?
        ORDER BY run_time_utc DESC
        LIMIT 500
    """
    with _con(db_path) as con:
        df = pd.read_sql_query(q, con, params=(provider, model_id))

    if df.empty:
        return MarginStats(rows=0, avg_mm_before=None, avg_mm_after=None, max_mm_after=None)

    avg_before = float(df["mm_pct_mb_before"].mean()) if df["mm_pct_mb_before"].notna().any() else None
    avg_after = float(df["mm_pct_mb_after"].mean()) if df["mm_pct_mb_after"].notna().any() else None
    max_after = float(df["mm_pct_mb_after"].max()) if df["mm_pct_mb_after"].notna().any() else None

    return MarginStats(
        rows=len(df),
        avg_mm_before=avg_before,
        avg_mm_after=avg_after,
        max_mm_after=max_after,
    )

def _get_net_flows_by_currency(
    con: sqlite3.Connection,
    start_d: date,
    end_d: date,
) -> Dict[str, float]:
    """
    Compute net flows per currency (BTC, USDT, USDC, etc.) between
    [start_d, end_d], inclusive, from account_flows.

    Returns:
        {"BTC": net_btc, "USDT": net_usdt, "USDC": net_usdc, ...}

    The ``con`` parameter is retained for backward compatibility but is
    ignored: ``account_flows`` lives in TRADING_DB and we open our own
    connection.
    """
    start_ts = datetime.combine(start_d, datetime.min.time()).isoformat()
    # exclusive upper bound: start of the day after end_d
    end_ts = (datetime.combine(end_d, datetime.min.time()) + timedelta(days=1)).isoformat()

    with _con_trading() as flows_con:
        cur = flows_con.execute(
            """
            SELECT currency, COALESCE(SUM(amount_btc), 0.0) AS net_amount
            FROM account_flows
            WHERE ts_utc >= ?
              AND ts_utc < ?
            GROUP BY currency
            """,
            (start_ts, end_ts),
        )
        rows = cur.fetchall() or []

    flows: Dict[str, float] = {}
    for currency, net_amount in rows:
        if net_amount is None:
            continue
        flows[str(currency).upper()] = float(net_amount)

    return flows

def _get_flows_and_btc_equivalent(
    con: sqlite3.Connection,
    start_d: date,
    end_d: date,
) -> tuple[Dict[str, float], float]:
    """
    Compute:
      - net flows per currency (sum of amount_btc for each currency)
      - total net flows in BTC-equivalent, using btc_prices for conversion.

    Assumptions:
      - account_flows.amount_btc is the numeric amount in that currency
        (BTC, USDT, USDC, etc.).
      - btc_prices has a BTC/USD-like price column, which may be named e.g.
        'price', 'close', 'btc_price_usd', etc.
      - USDT and USDC are ~1 USD.

    Returns:
        (flows_by_currency, net_flows_btc_equiv)
    """
    # ------------------------------------------------------------------
    # 1) Load BTC prices for the date range with a flexible price column
    #    (btc_prices lives in MARKET_DATA_DB)
    # ------------------------------------------------------------------
    price_q = """
        SELECT *
        FROM btc_prices
        WHERE date >= ?
          AND date <= ?
    """
    with _con_market() as price_con:
        price_cur = price_con.execute(price_q, (start_d.isoformat(), end_d.isoformat()))
        price_rows = price_cur.fetchall()
        cols = [desc[0] for desc in price_cur.description]

    # Try to guess the correct price column
    candidate_cols = ["price", "close", "btc_price_usd", "btc_usd", "spot"]
    price_col_name = None
    for c in candidate_cols:
        if c in cols:
            price_col_name = c
            break

    if price_col_name is None:
        # No obvious price column; we can't compute BTC-equivalent.
        # Fall back to treating non-BTC flows as having no BTC-equivalent impact.
        price_by_date: Dict[str, float] = {}
    else:
        price_idx = cols.index(price_col_name)
        date_idx = cols.index("date") if "date" in cols else 0

        price_by_date: Dict[str, float] = {}
        for row in price_rows:
            d_str = str(row[date_idx])
            try:
                p = row[price_idx]
                if p is None:
                    continue
                p_f = float(p)
                if p_f <= 0:
                    continue
            except Exception:
                continue
            d_key = d_str[:10]  # 'YYYY-MM-DD...'
            price_by_date[d_key] = p_f

    # ------------------------------------------------------------------
    # 2) Load all flows in the window
    # ------------------------------------------------------------------
    start_ts = datetime.combine(start_d, datetime.min.time()).isoformat()
    end_ts = (datetime.combine(end_d, datetime.min.time()) + timedelta(days=1)).isoformat()

    flow_q = """
        SELECT ts_utc, currency, amount_btc
        FROM account_flows
        WHERE ts_utc >= ?
          AND ts_utc < ?
    """
    # ``account_flows`` lives in TRADING_DB (not the same DB as btc_prices).
    with _con_trading() as flows_con:
        cur = flows_con.execute(flow_q, (start_ts, end_ts))
        rows = cur.fetchall() or []

    flows_by_ccy: Dict[str, float] = {}
    net_flows_btc_equiv: float = 0.0

    for ts_utc, ccy, amt in rows:
        if amt is None:
            continue
        try:
            amt_f = float(amt)
        except Exception:
            continue

        ccy_u = str(ccy).upper()
        flows_by_ccy[ccy_u] = flows_by_ccy.get(ccy_u, 0.0) + amt_f

        ts_str = str(ts_utc)
        d_key = ts_str[:10]  # 'YYYY-MM-DD...'

        # BTC flows: 1:1 BTC-equivalent
        if ccy_u == "BTC":
            net_flows_btc_equiv += amt_f
            continue

        # Stablecoins: treat as USD → convert using BTC/USD if we have it
        if ccy_u in ("USDT", "USDC"):
            price = price_by_date.get(d_key)
            if price is None or price <= 0:
                # No BTC price for that date; skip this flow from BTC-equivalent
                continue
            net_flows_btc_equiv += (amt_f / price)
            continue

        # Other currencies: currently ignored in BTC-equivalent calculation

    return flows_by_ccy, net_flows_btc_equiv

def _load_equity_stats(db_path: str, days_back: int) -> EquityStats:
    """
    Load raw equity stats from account_snapshots and compute
    flow-adjusted PnL using account_flows (if available).

    Flow-adjusted PnL:
        trading_pnl_btc = (equity_end - equity_start) - net_flows_btc

    The ``db_path`` parameter is retained for backward compatibility but
    is ignored here: ``account_snapshots`` lives in SNAPSHOTS_DB and the
    cross-DB flows lookup picks its own DBs.
    """
    cutoff = (datetime.utcnow().date() - timedelta(days=days_back)).isoformat()
    q = """
        SELECT date, payload_json
        FROM account_snapshots
        WHERE date >= ?
        ORDER BY date ASC
    """
    with _con_snapshots() as con:
        df = pd.read_sql_query(q, con, params=(cutoff,))

        if df.empty:
            return EquityStats(
                rows=0,
                equity_start=None,
                equity_end=None,
                pct_change=None,
                net_flows_btc=None,
                trading_pnl_btc=None,
                trading_pnl_pct=None,
            )

        equities = []
        dates: list[date] = []
        for _, row in df.iterrows():
            try:
                payload = json.loads(row["payload_json"])
            except Exception:
                continue
            eq = payload.get("equity") or payload.get("balance")
            try:
                equities.append(float(eq))
                dates.append(_parse_iso_date(str(row["date"])))
            except Exception:
                continue

        if not equities or not dates:
            return EquityStats(
                rows=0,
                equity_start=None,
                equity_end=None,
                pct_change=None,
                net_flows_btc=None,
                trading_pnl_btc=None,
                trading_pnl_pct=None,
            )

        equity_start = equities[0]
        equity_end = equities[-1]
        pct_change = (
            (equity_end - equity_start) / equity_start * 100.0
            if equity_start != 0
            else None
        )

        # Determine the actual start/end dates of the equity series
        first_d = min(dates)
        last_d = max(dates)

        # Compute net flows per currency AND BTC-equivalent net flows
        flows_by_ccy, net_flows_btc_equiv = _get_flows_and_btc_equivalent(
            con, first_d, last_d
        )

        # Flow-adjusted trading PnL (BTC-equivalent)
        raw_change_btc = equity_end - equity_start
        trading_pnl_btc = raw_change_btc - net_flows_btc_equiv

        # Simple denominator: starting equity plus positive BTC-equivalent flows
        denom = equity_start + max(net_flows_btc_equiv, 0.0)
        trading_pnl_pct = (
            (trading_pnl_btc / denom) * 100.0
            if denom > 0
            else None
        )


        return EquityStats(
            rows=len(equities),
            equity_start=equity_start,
            equity_end=equity_end,
            pct_change=pct_change,
            net_flows_btc=net_flows_btc_equiv,        # BTC-equivalent now
            trading_pnl_btc=trading_pnl_btc,
            trading_pnl_pct=trading_pnl_pct,
            net_flows_by_currency=flows_by_ccy,
        )

def _load_regime_stats(db_path: str, days_back: int) -> RegimeStats:
    """``btc_prices`` lives in MARKET_DATA_DB; ``db_path`` is ignored."""
    cutoff = (datetime.utcnow().date() - timedelta(days=days_back)).isoformat()
    q = """
        SELECT date, percent_change
        FROM btc_prices
        WHERE date >= ?
        ORDER BY date ASC
    """
    with _con_market() as con:
        df = pd.read_sql_query(q, con, params=(cutoff,))

    if df.empty or "percent_change" not in df.columns:
        return RegimeStats(rows=0, pct_up_big=0.0, pct_down_big=0.0, pct_flat=0.0)

    pc = df["percent_change"].astype(float)
    n = len(pc)
    if n == 0:
        return RegimeStats(rows=0, pct_up_big=0.0, pct_down_big=0.0, pct_flat=0.0)

    up_big = (pc > 3.0).sum() / n
    down_big = (pc < -3.0).sum() / n
    flat = ((pc > -1.0) & (pc < 1.0)).sum() / n

    return RegimeStats(rows=n, pct_up_big=up_big, pct_down_big=down_big, pct_flat=flat)


# ---------------------------------------------------------------------------
# LLM enrichment (GPT-5-mini only)
# ---------------------------------------------------------------------------

def _llm_enrich_historical_context(
    model_label: str,
    days_back: int,
    base_summary: str,
    metrics: Dict[str, Any],
    use_llm: bool = True,
    temperature: float = 0.1,
    max_tokens: int = 512,
    verbose: bool = False,
) -> Dict[str, Optional[str]]:
    """
    Use GPT-5-mini to turn raw metrics + base summary into a smarter summary + rules.

    Follows your project pattern:
        from llm_io import *
        client = make_llm_client(provider=provider, model=model) if use_llm else None
        resp = client(prompt, temperature=..., max_tokens=..., verbose=...)

    Here, resp is a dict like:
        {"json_str": "<JSON string>", "usage": {...}, "usd_est": ..., "raw": {...}}
    """
    if not use_llm or make_llm_client is None:
        return {"summary_text": base_summary, "rules_text": None}

    provider = "openai"
    model = "gpt-5-mini"

    try:
        client = make_llm_client(provider=provider, model=model) if use_llm else None
    except Exception:
        client = None

    if client is None:
        return {"summary_text": base_summary, "rules_text": None}

    prompt_payload = {
        "model_label": model_label,
        "lookback_days": days_back,
        "base_summary": base_summary,
        "metrics": metrics,
    }

    prompt = (
        "You are a risk-aware options trading performance analyst.\n\n"
        "You receive JSON data about how a trading model performed over a recent window.\n"
        "Your job is to:\n"
        "1) Write a concise, professional summary (2–4 sentences) describing the model's performance, risk usage,\n"
        "   and strengths/weaknesses. Refer to concrete numbers when useful but stay compact.\n"
        "2) Derive 3–7 prescriptive rules for how this model should adjust future behavior, especially for:\n"
        "   - Opening new trades (strike selection, DTE, POP, risk concentration).\n"
        "   - Managing margin usage and drawdowns.\n"
        "   - Taking profits or cutting losers.\n\n"
        "Format your response as pure JSON with two keys:\n"
        "{\n"
        '  \"summary\": \"<one short paragraph>\",\n'
        '  \"rules\": [\"bullet 1\", \"bullet 2\", ...]\n'
        "}\n"
        "Do not add any extra text outside this JSON.\n\n"
        "Here is the data:\n"
        f"{json.dumps(prompt_payload, ensure_ascii=False, indent=2)}\n"
    )

    try:
        # IMPORTANT: use retries=0 here to avoid multiple HTTP calls for this agent
        resp = client(
            prompt,
            temperature=temperature,
            max_tokens=max_tokens,
            retries=0,
            verbose=verbose,
        )
    except Exception:
        return {"summary_text": base_summary, "rules_text": None}

    # llm_io client returns a dict with "json_str"
    if isinstance(resp, dict) and "json_str" in resp:
        text = resp["json_str"]
    elif isinstance(resp, str):
        text = resp
    else:
        # Fallback: try a generic attribute or str()
        text = getattr(resp, "text", None) or str(resp)

    summary_text = base_summary
    rules_text: Optional[str] = None

    try:
        parsed = json.loads(text)
        summary_candidate = parsed.get("summary") or parsed.get("Summary")
        rules_list = parsed.get("rules") or parsed.get("Rules")
        if isinstance(summary_candidate, str) and summary_candidate.strip():
            summary_text = summary_candidate.strip()
        if isinstance(rules_list, list):
            rules_text = "\n".join(
                f"- {str(item).strip()}"
                for item in rules_list
                if str(item).strip()
            )
    except Exception:
        # If parsing fails, use whatever text we got as summary
        summary_text = text.strip() or base_summary
        rules_text = None

    return {"summary_text": summary_text, "rules_text": rules_text}

def get_model_decision_quality_for_website(
    decisions_table: str,
    days_back: int = 60,
    db_path: str = DB_PATH,
) -> Dict[str, Any]:
    """
    Lightweight helper for the website: returns OPEN / HOLD / CLOSE percentages
    and counts, plus an overall model accuracy, for the last `days_back` days.

    All heavy logic stays in this module; model.py just calls this function.
    """
    df_dec = _load_decisions_last_n_days(decisions_table, days_back, db_path)

    closed_wr = _compute_closed_win_rate(df_dec, db_path=db_path)
    open_50 = _compute_open_50pct_stats(df_dec, db_path=db_path)
    hold_stats = _compute_hold_stats(df_dec, db_path=db_path)
    overall_acc_rate, overall_acc_pct = _compute_overall_model_accuracy(
        closed_wr=closed_wr,
        open_50=open_50,
        hold_stats=hold_stats,
    )

    def pct(x: Optional[float]) -> Optional[float]:
        return round(x * 100.0, 1) if x is not None else None

    total_trades_assessed = (
        closed_wr.total_closed
        + open_50.evaluated
        + hold_stats.evaluated
    )
    return {
        # Percentages
        "closed_win_pct": pct(closed_wr.win_rate),
        "open_50_hit_pct": pct(open_50.hit_rate),
        "hold_good_pct": pct(hold_stats.good_rate),
        "model_accuracy_pct": round(overall_acc_pct, 1) if overall_acc_pct is not None else None,

        # Counts
        "closed_total": closed_wr.total_closed,
        "closed_wins": closed_wr.wins,
        "closed_losses": closed_wr.losses,

        "open_50_evaluated": open_50.evaluated,
        "open_50_wins": open_50.wins,
        "open_50_losses": open_50.losses,

        "hold_evaluated": hold_stats.evaluated,
        "hold_good": hold_stats.good,
        "hold_bad": hold_stats.bad,

        # ✅ NEW
        "total_trades_assessed": total_trades_assessed,
    }


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------

def build_historical_context(
    model_label: str,
    provider: str,
    model_id: str,
    decisions_table: str,
    days_back: int = 60,
    db_path: str = DB_PATH,
    use_llm: bool = True,
    temperature: float = 0.1,
    max_tokens: int = 512,
    verbose: bool = False,
) -> Dict[str, Any]:
    """
    Build a model-specific historical context summary over the last `days_back` days.

    If use_llm=True, enrich the raw numeric summary with GPT-5-mini to get
    a smarter narrative and prescriptive rules.
    """
    # 1) Decisions history (model-specific)
    df_dec = _load_decisions_last_n_days(decisions_table, days_back, db_path)

    closed_wr = _compute_closed_win_rate(df_dec, db_path=db_path)
    open_50 = _compute_open_50pct_stats(df_dec, db_path=db_path)
    hold_stats = _compute_hold_stats(df_dec, db_path=db_path)
    
    overall_acc_rate, overall_acc_pct = _compute_overall_model_accuracy(
        closed_wr=closed_wr,
        open_50=open_50,
        hold_stats=hold_stats,
    )

    # 2) Margin usage (model-specific)
    mm_stats = _load_margin_stats(provider=provider, model_id=model_id, db_path=db_path)


    # 3) Equity / BTC regimes (shared)
    eq_stats = _load_equity_stats(db_path=db_path, days_back=days_back)
    reg_stats = _load_regime_stats(db_path=db_path, days_back=days_back)

    # --- Build deterministic base summary text ---
    parts = []

    if closed_wr.total_closed > 0:
        wr_pct = f"{closed_wr.win_rate * 100:.1f}%" if closed_wr.win_rate is not None else "n/a"
        parts.append(
            f"Over the last {days_back} days, {model_label} closed {closed_wr.total_closed} trades, "
            f"with {closed_wr.wins} winners and {closed_wr.losses} losers, for a realized win rate of {wr_pct}."
        )
    else:
        parts.append(
            f"Over the last {days_back} days, {model_label} has no closed trades with sufficient data to compute a realized win rate."
        )

    if open_50.evaluated > 0:
        hit_pct = f"{open_50.hit_rate * 100:.1f}%" if open_50.hit_rate is not None else "n/a"
        parts.append(
            f"In the same window, {open_50.evaluated} OPEN suggestions had enough historical option data; "
            f"{open_50.wins} of them would have reached at least +50% profit before expiry, for a 50%-target hit rate of {hit_pct}."
        )
    else:
        parts.append(
            "Historical option marks were insufficient to evaluate the 50% profit target for recent OPEN suggestions."
        )

    if hold_stats.evaluated > 0:
        hold_pct = f"{hold_stats.good_rate * 100:.1f}%" if hold_stats.good_rate is not None else "n/a"
        parts.append(
            f"Over the same window, {hold_stats.evaluated} HOLD decisions had enough post-decision data; "
            f"{hold_stats.good} were judged beneficial versus closing immediately, "
            f"for a hold-quality rate of {hold_pct}."
        )
    else:
        parts.append(
            "Recent HOLD decisions did not have enough post-decision price history to evaluate their quality."
        )
        
    if overall_acc_pct is not None:
        parts.append(
            f"Combining CLOSE, OPEN, and HOLD outcomes, the volume-weighted overall decision-quality accuracy over this window is {overall_acc_pct:.1f}%."
        )

    if mm_stats.rows > 0 and mm_stats.avg_mm_after is not None:
        avg_mm = f"{mm_stats.avg_mm_after:.2f}%"
        max_mm = f"{mm_stats.max_mm_after:.2f}%" if mm_stats.max_mm_after is not None else "n/a"
        parts.append(
            f"Margin usage after runs averaged around {avg_mm} of maintenance, with a maximum observed level of {max_mm}, "
            f"based on {mm_stats.rows} recent MM_IM snapshots."
        )
    else:
        parts.append(
            "Recent MM_IM data for this model was too sparse to characterize typical margin usage."
        )

    if eq_stats.rows > 0 and eq_stats.trading_pnl_btc is not None:
        # Flow-adjusted PnL sentence
        pnl_str = f"{eq_stats.trading_pnl_btc:.4f} BTC"
        if eq_stats.trading_pnl_pct is not None:
            pnl_str += f" ({eq_stats.trading_pnl_pct:.1f}%)"

        # Build a human-readable flows string for all currencies
        flows_str: str
        if eq_stats.net_flows_by_currency:
            pieces = []
            for ccy, amt in eq_stats.net_flows_by_currency.items():
                pieces.append(f"{amt:.4f} {ccy}")
            flows_str = ", ".join(pieces) if pieces else "0.0000 BTC"
        else:
            # Fallback to BTC-only if dict is missing
            flows_str = (
                f"{eq_stats.net_flows_btc:.4f} BTC"
                if eq_stats.net_flows_btc is not None
                else "0.0000 BTC"
            )

        parts.append(
            f"Over the last {days_back} days, flow-adjusted PnL was {pnl_str}, "
            f"after accounting for net flows of {flows_str} from deposits, withdrawals, and transfers."
        )


        # Optional: also report raw equity movement for context
        if eq_stats.equity_start is not None and eq_stats.equity_end is not None and eq_stats.pct_change is not None:
            eq_pct = f"{eq_stats.pct_change:.1f}%"
            parts.append(
                f"Over the same window, raw account equity moved from {eq_stats.equity_start:.4f} BTC "
                f"to {eq_stats.equity_end:.4f} BTC, a net move of {eq_pct}."
            )


    if reg_stats.rows > 0:
        up_pct = f"{reg_stats.pct_up_big * 100:.1f}%"
        dn_pct = f"{reg_stats.pct_down_big * 100:.1f}%"
        fl_pct = f"{reg_stats.pct_flat * 100:.1f}%"
        parts.append(
            f"During this period, BTC saw {up_pct} large up days (>+3%), {dn_pct} large down days (<−3%), "
            f"and {fl_pct} relatively flat days, shaping the backdrop for these trades."
        )

    base_summary = " ".join(parts)

    metrics: Dict[str, Any] = {
        "closed_total": closed_wr.total_closed,
        "closed_wins": closed_wr.wins,
        "closed_losses": closed_wr.losses,
        "closed_win_rate": closed_wr.win_rate,
        "open_50_evaluated": open_50.evaluated,
        "open_50_wins": open_50.wins,
        "open_50_losses": open_50.losses,
        "open_50_hit_rate": open_50.hit_rate,
        "hold_evaluated": hold_stats.evaluated,
        "hold_good": hold_stats.good,
        "hold_bad": hold_stats.bad,
        "hold_good_rate": hold_stats.good_rate,
        "mm_rows": mm_stats.rows,
        "mm_avg_mm_before": mm_stats.avg_mm_before,
        "mm_avg_mm_after": mm_stats.avg_mm_after,
        "mm_max_mm_after": mm_stats.max_mm_after,
        "equity_rows": eq_stats.rows,
        "equity_start": eq_stats.equity_start,
        "equity_end": eq_stats.equity_end,
        "equity_pct_change": eq_stats.pct_change,
        # New metrics for flows and flow-adjusted PnL
        "equity_net_flows_btc": eq_stats.net_flows_btc,
        "equity_trading_pnl_btc": eq_stats.trading_pnl_btc,
        "equity_trading_pnl_pct": eq_stats.trading_pnl_pct,
        # New: full multi-currency flows dict
        "equity_net_flows_by_currency": eq_stats.net_flows_by_currency,
        "regime_rows": reg_stats.rows,
        "regime_pct_up_big": reg_stats.pct_up_big,
        "regime_pct_down_big": reg_stats.pct_down_big,
        "regime_pct_flat": reg_stats.pct_flat,
        "hold_evaluated": hold_stats.evaluated,
        "hold_good": hold_stats.good,
        "hold_bad": hold_stats.bad,
        "hold_good_rate": hold_stats.good_rate,
        "model_accuracy_rate": overall_acc_rate,
        "model_accuracy_pct": overall_acc_pct,

    }


    # LLM enrichment (GPT-5-mini only)
    llm_out = _llm_enrich_historical_context(
        model_label=model_label,
        days_back=days_back,
        base_summary=base_summary,
        metrics=metrics,
        use_llm=use_llm,
        temperature=temperature,
        max_tokens=max_tokens,
        verbose=verbose,
    )

    return {
        "summary_text": llm_out.get("summary_text", base_summary),
        "rules_text": llm_out.get("rules_text"),
        "metrics": metrics,
    }


# ---------------------------------------------------------------------------
# Static CLI test harness
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    # Static test configuration for quick local checks.
    TEST_MODEL_LABEL = "GPT-5"
    TEST_PROVIDER = "openai"
    TEST_MODEL_ID = "gpt-5"
    TEST_DECISIONS_TABLE = "decisions_gpt_5_multi_agent"
    TEST_DAYS_BACK = 60
    TEST_DB_PATH = DB_PATH  # or override with a hard-coded path if needed

    ctx = build_historical_context(
        model_label=TEST_MODEL_LABEL,
        provider=TEST_PROVIDER,
        model_id=TEST_MODEL_ID,
        decisions_table=TEST_DECISIONS_TABLE,
        days_back=TEST_DAYS_BACK,
        db_path=TEST_DB_PATH,
        use_llm=True,
        temperature=0.1,
        max_tokens=512,
        verbose=False,
    )
    print(ctx)
    print("\n==================== HISTORICAL CONTEXT SUMMARY (LLM) ==============\n")
    print(ctx["summary_text"])
    print("\n==================== RULES (LLM) ====================================\n")
    print(ctx["rules_text"] or "(no rules returned)")
    print("\n==================== METRICS (key -> value) =========================\n")
    for k, v in sorted(ctx["metrics"].items()):
        print(f"{k}: {v}")
    print()
