if __name__ == "__main__":
    import os
    import json
    from .sentiment import get_macro_sentiment_scores_llm

    # --- Configure environment for the test ---
    os.environ["LLM_PROVIDER"] = "openai"       # or "xai" if you prefer
    os.environ["LLM_MODEL"] = "gpt-4o-mini"      # use GPT-5-mini as requeste
    os.environ["MACRO_SAVE_MODE"] = "override"  # allow overwriting in DB

    print("Running LLM macro sentiment test using GPT-4o-mini...\n")

    # --- Run function with verbose settings ---
    scores, details = get_macro_sentiment_scores_llm(
        days_back=2,
        half_life_hours=24.0,
        max_articles=300,
        max_per_source=80,
        min_relevance=0.15,
        return_details=True,
    )

    print("\n===== LLM Output =====")
    print(json.dumps(scores, indent=2, ensure_ascii=False))

    print("\n===== Run Details =====")
    print(json.dumps({
        "asof_utc": details.get("asof_utc"),
        "provider": details.get("provider"),
        "model_id": details.get("model_id"),
        "n_articles": details.get("n_articles"),
        "n_used": details.get("n_used"),
        "by_source": details.get("by_source"),
        "examples": details.get("examples")[:3],
    }, indent=2, ensure_ascii=False))

    print("\n✅ Macro LLM sentiment test completed successfully.")
