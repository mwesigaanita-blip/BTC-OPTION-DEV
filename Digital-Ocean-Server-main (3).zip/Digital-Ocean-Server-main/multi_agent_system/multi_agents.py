# === Standard lib ===
from __future__ import annotations
import os, json, logging
import pandas as pd
from .fundemantal_agent import run_fundamental
from .Sentiment_agent import run_sentiment
from .Valuation_agent import run_valuation_filter_with_pop
from .config import *
from .llm_io import *
import datetime as dt 
from .btc_ta_summary import get_btc_ta_summary
from typing import Any, Dict, List, Optional, Tuple
from .llm_io import make_llm_client
import numpy as np
from .Deribit_margin import (
    calc_margin_for_positions,
    apply_close_decisions,
    apply_allocation_decisions
)
from .account_flows_ingestion import sync_account_flows
from .multi_agents_lib.logging_utils import setup_cli_logging
from .multi_agents_lib.decision_parsing import (
    sanitize_for_console as _sanitize_for_console,
    norm_decisions as _norm_decisions,
)
from .multi_agents_lib.deribit_client import (
    get_deribit_client,
)
from .multi_agents_lib.persistence import (
    save_model_decisions_daily,
    save_open_trades_daily,
)
from .multi_agents_lib.positions_formatting import (
    format_positions_for_llm,
)
from .multi_agents_lib.close_engine import run_close_hold_deterministic
from .multi_agents_lib.open_candidates import (
    build_open_candidates_from_valuation_df,
)
from .multi_agents_lib.formatting import (
    format_fundamental_for_llm,
    format_sentiment_for_llm,
    format_valuation_for_llm_from_out,
)
from .multi_agents_lib.close_engine import (
    run_close_hold_deterministic,
    run_close_hold_llm_agent,
    simulate_mm_im_after_close,
    close_decisions_to_text,
)

from .multi_agents_lib.open_scenarios import (
    generate_mm_acceptable_open_scenarios,
    build_open_context_from_scenarios,
    run_open_selector_llm,
    scenario_id_to_open_legs,
    simulate_mm_im_after_open,
    open_legs_to_text,
)


logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)
logger.propagate = True


OPEN_QTY_GRID_EVEN = [4, 6, 8, 10, 12, 14, 16, 18, 20]

# cap in % of margin balance (Deribit UI style)
OPEN_MM_CAP_PCT = 70  # <-- set here once

# limit candidates to avoid too many Deribit calls
OPEN_MAX_CANDIDATES_FOR_MM = 25   # start small for testing



def _dummy_sentence(prefix: str) -> str:
    return f"[NO-LLM MODE] {prefix}: static placeholder output."




def build_structurer_prompt(*, close_locked_text: str, open_locked_text: str) -> Tuple[str, str]:
    """
    NO-THINK STRUCTURER:
    - Must not change any symbols/actions/qty/reasons/when_to_close.
    - Only merges into one final JSON object.
    """
    system = (
        "You are a STRICT JSON STRUCTURER.\n"
        "You DO NOT make trading decisions.\n"
        "You MUST NOT change, rewrite, add, remove, or reinterpret any decision.\n"
        "You ONLY merge the provided CLOSE/HOLD list and the provided OPEN list into one final JSON output.\n"
        "Return ONLY valid JSON with keys: 'sentence' and 'decisions'. No markdown, no extra text."
    )

    user = (
        "=== INPUT 1: LOCKED CLOSE/HOLD DECISIONS (DO NOT CHANGE) ===\n"
        f"{(close_locked_text or '').strip()}\n\n"
        "=== INPUT 2: LOCKED OPEN DECISIONS (DO NOT CHANGE) ===\n"
        f"{(open_locked_text or '').strip()}\n\n"
        "=== OUTPUT RULES ===\n"
        "- Output JSON only.\n"
        "- 'decisions' must be ONE list that contains all CLOSE/HOLD decisions first, then OPEN decisions.\n"
        "- Every decision object must have EXACT keys:\n"
        "  symbol, action, right, side, quantity, reason, when_to_close\n"
        "- Do NOT invent or modify anything.\n\n"
        "=== STRICT JSON FORMAT ===\n"
        "{\n"
        "  \"sentence\": \"string\",\n"
        "  \"decisions\": [\n"
        "    {\n"
        "      \"symbol\": \"string\",\n"
        "      \"action\": \"CLOSE\" | \"HOLD\" | \"OPEN\",\n"
        "      \"right\": \"CALL\" | \"PUT\",\n"
        "      \"side\": \"BUY\" | \"SELL\",\n"
        "      \"quantity\": 1,\n"
        "      \"reason\": \"string\",\n"
        "      \"when_to_close\": \"string\"\n"
        "    }\n"
        "  ]\n"
        "}\n"
    )
    return system, user

def run_structurer_llm(*, client, close_locked_text: str, open_locked_text: str) -> Tuple[str, List[Dict[str, Any]], float]:
    import json
    from .multi_agents_lib.decision_parsing import extract_first_json_object

    system, user = build_structurer_prompt(
        close_locked_text=close_locked_text,
        open_locked_text=open_locked_text,
    )

    resp = client(
        prompt=system + "\n\n" + user,
        temperature=0.0,
        retries=2,
        request_timeout=120,
        verbose=True,
    )
    cost = float(resp.get("usd_est", 0.0))

    try:
        parsed = json.loads(resp.get("json_str") or "")
    except Exception:
        raw = resp.get("raw", "") or ""
        parsed = extract_first_json_object(raw)
        if parsed is None:
            raise RuntimeError("Structurer: no valid JSON found.")

    if not isinstance(parsed, dict):
        raise RuntimeError("Structurer: response is not a JSON object.")

    sentence = str(parsed.get("sentence") or "").strip()
    decisions = parsed.get("decisions") or []
    if not isinstance(decisions, list):
        decisions = []

    # Hard safety: do not allow missing qty (keep ints)
    cleaned: List[Dict[str, Any]] = []
    for d in decisions:
        if not isinstance(d, dict):
            continue
        q = d.get("quantity", 0)
        try:
            q = int(q)
        except Exception:
            q = 0
        if q <= 0:
            q = 1
        d["quantity"] = q
        cleaned.append(d)

    return sentence, cleaned, cost

def enrich_decisions_for_db(
    decisions_df: pd.DataFrame,
    *,
    btc_price: float,
    positions_df: Optional[pd.DataFrame],
    live_options_df: Optional[pd.DataFrame],
    valuation_df: Optional[pd.DataFrame],
) -> pd.DataFrame:
    """
    Adds/overwrites:
    - POP = 1 - abs(delta)  (best-effort from positions/live/valuation)
    - btc_price
    - avg_price_btc, avg_price_usd
    - mark_price_btc, mark_price_usd
    """
    df = decisions_df.copy()
    if df.empty:
        return df

    # Always set btc_price
    df["btc_price"] = float(btc_price or 0.0)

    # Normalize symbol key
    df["symbol"] = df["symbol"].astype(str).str.strip()
    sym_u = df["symbol"].str.upper()

    # Build lookup maps
    def _build_map(src: Optional[pd.DataFrame]) -> dict:
        if src is None or src.empty:
            return {}
        s = src.copy()
        # unify symbol column
        sym_col = "symbol" if "symbol" in s.columns else ("instrument_name" if "instrument_name" in s.columns else None)
        if not sym_col:
            return {}
        s["_sym"] = s[sym_col].astype(str).str.strip().str.upper()
        return s.set_index("_sym").to_dict(orient="index")

    pos_map = _build_map(positions_df)
    val_map = _build_map(valuation_df)
    live_map = _build_map(live_options_df)

    def pick_row(sym: str) -> dict:
        # priority: positions -> valuation -> live
        return pos_map.get(sym) or val_map.get(sym) or live_map.get(sym) or {}

    # Fill avg/mark prices
    avg_btc = []
    avg_usd = []
    mark_btc = []
    mark_usd = []
    pop_list = []

    for s in sym_u.tolist():
        row = pick_row(s)

        # avg/mark (try common keys)
        ab = row.get("average_price_btc", row.get("average_price", row.get("avg_price_btc", None)))
        au = row.get("average_price_usd", row.get("average_price_usd", row.get("avg_price_usd", None)))

        mb = row.get("mark_price_btc", row.get("mark_price", row.get("mark_btc", None)))
        mu = row.get("mark_price_usd", row.get("mark_price_usd", row.get("mark_usd", None)))

        # delta -> POP = 1 - abs(delta)
        # try common delta keys
        dlt = row.get("delta", row.get("delta_total", row.get("net_delta", None)))
        try:
            if dlt is None or dlt == "":
                pop = pd.NA
            else:
                pop = 1.0 - abs(float(dlt))
                # keep in [0,1] if delta noisy
                if pop < 0:
                    pop = 0.0
                if pop > 1:
                    pop = 1.0
        except Exception:
            pop = pd.NA

        avg_btc.append(ab if ab not in ("", None) else pd.NA)
        avg_usd.append(au if au not in ("", None) else pd.NA)
        mark_btc.append(mb if mb not in ("", None) else pd.NA)
        mark_usd.append(mu if mu not in ("", None) else pd.NA)
        pop_list.append(pop)

    df["avg_price_btc"] = avg_btc
    df["avg_price_usd"] = avg_usd
    df["mark_price_btc"] = mark_btc
    df["mark_price_usd"] = mark_usd
    df["POP"] = pop_list

    return df



def run_multi_agent_pipeline(
    live_options_df: pd.DataFrame,
    positions_df: pd.DataFrame,
    account_capital_usd: float,
    strategy_text: str,
    macro_now: float,
    macro_7D: float,
    macro_30D: float,
    btc_price: float,
    account_info: Optional[dict] = None,
    llm_model_id: Optional[str] = None,
    api_key: Optional[str] = None,
    forecast_message: Optional[str] = None,
    max_candidates: int = 120,
    max_rows_to_llm: Optional[int] = None,
    provider: str = "openai",
    debuge: bool = False,
    x_score_now: Optional[float] = 0.0,
    x_score_7D: Optional[float] = 0.0,
    x_score_30D: Optional[float] = 0.0,
    x_sentence_input: Optional[str] = "",
    use_llm: bool = True,
    save_data: bool = True,
):
    import csv, json, logging, datetime as dt, sqlite3
    from typing import Any, Dict, List, Optional
    import copy
    import os, logging
    from mm_alert_bot.api.telegram_client import TelegramClient
    import asyncio
    from pathlib import Path
    total_cost = 0.0
    
    # ============================================================
    # 0) SYNC ACCOUNT FLOWS (deposits / withdrawals / transfers)
    #    so Historical Context PnL uses fresh data.
    # ============================================================
    try:
        logging.info("Syncing Deribit account flows (BTC, USDT, USDC) into account_flows...")
        # Choice B: call ingestion automatically each pipeline run
        sync_account_flows(
            db_path=DB_PATH,
            days_back=90,
            dry_run=False,
        )
    except Exception as e:
        logging.warning("account_flows_ingestion failed; continuing with existing account_flows: %s", e)

    # --- Technical analysis summary (from btc_prices table) ---
    try:
        ta_summary = get_btc_ta_summary()
    except Exception as e:
        logging.warning("Failed to build BTC TA summary: %s", e)
        ta_summary = "Technical summary unavailable (error while computing indicators)."

    # ------------------------------------------------------------------
    # helper for margin_balance (prefer per_currency BTC, then top-level)
    # ------------------------------------------------------------------
    def _margin_balance_from_account(acc: Optional[dict]) -> float:
        if not isinstance(acc, dict):
            return 0.0

        # 1) multi-currency slice (preferred)
        pc = acc.get("per_currency")
        if isinstance(pc, dict):
            btc_slice = pc.get("BTC") or pc.get("btc")
            if isinstance(btc_slice, dict):
                mb = btc_slice.get("margin_balance")
                if mb is not None:
                    try:
                        return float(mb)
                    except Exception:
                        logging.warning("Failed to parse per_currency.BTC.margin_balance=%r", mb)

        # 2) top-level margin_balance
        mb = acc.get("margin_balance")
        if mb is not None:
            try:
                return float(mb)
            except Exception:
                logging.warning("Failed to parse account.margin_balance=%r", mb)

        # 3) fallback: equity (may differ from margin_balance)
        eq = acc.get("equity")
        if eq is not None:
            try:
                logging.warning(
                    "Using equity as fallback for margin_balance; Deribit UI MM%% may differ. equity=%r",
                    eq,
                )
                return float(eq)
            except Exception:
                logging.warning("Failed to parse equity=%r as float for margin_balance fallback", eq)

        # 4) ultimate fallback
        return 0.0

    # ============================================================
    # 1) FUNDAMENTAL
    # ============================================================
    if use_llm:
        fundamental_text, fund_cost = run_fundamental(
            model=llm_model_id, temperature=0, max_tokens=5000,
            macro_now=macro_now, marco_7D=macro_7D, macro_30D=macro_30D,
            use_llm=True, provider=provider, ta_summary=ta_summary
        )
        total_cost += float(fund_cost or 0.0)
    else:
        fundamental_text = _dummy_sentence("FUNDAMENTAL")
        fund_cost = 0.0

    formatted_fundamental_text = format_fundamental_for_llm(fundamental_text)

    # ============================================================
    # 2) SENTIMENT
    # ============================================================
    if use_llm:
        sentiment_text, sent_cost = run_sentiment(
            model=llm_model_id, temperature=0, max_tokens=5000,
            x_score_now=x_score_now, x_score_7D=x_score_7D, x_score_30D=x_score_30D,
            x_sentence=x_sentence_input, use_llm=True, provider=provider, ta_summary=ta_summary
        )
        total_cost += float(sent_cost or 0.0)
    else:
        sentiment_text = _dummy_sentence("SENTIMENT")
        sent_cost = 0.0

    formatted_sentiment_text = format_sentiment_for_llm(sentiment_text)


    # ============================================================
    # 3) VALUATION (with POP & eligibility)
    # ============================================================
    valutation = run_valuation_filter_with_pop(
        df_live=live_options_df,
        current_positions_df=positions_df,
        cfg=CFG,
        account_snapshot=account_info,
    )
    # valutation.to_csv("debug_logs/valuation_output.csv", index=False)
    valuation_text = format_valuation_for_llm_from_out(valutation)
    valuation_df = None
    try:
        if isinstance(valutation, dict) and "df" in valutation:
            valuation_df = valutation["df"]
        elif isinstance(valutation, pd.DataFrame):
            valuation_df = valutation
    except Exception:
        logging.warning("Failed to extract valuation_df from valutation output.")
        valuation_df = None

    if valuation_df is not None and not valuation_df.empty and "eligible" in valuation_df.columns:
        logging.info("Applying Task-5 eligibility gating to valuation_df for OPEN agent.")
        valuation_df = valuation_df[valuation_df["eligible"] == 1].copy()
        if isinstance(valutation, dict) and "filtered_options_df" in valutation:
            valutation["filtered_options_df"] = valuation_df
            valuation_text = format_valuation_for_llm_from_out(valutation)
    logging.info("valuation_df columns=%s", list(valuation_df.columns) if valuation_df is not None else None)
    if valuation_df is not None and not valuation_df.empty:
        logging.info("valuation_df sample (symbol/theta fields)=%s",
                    valuation_df[[c for c in ["symbol","instrument_name","theta","theta_btc","theta_usd","theta_eff","_theta_eff"] if c in valuation_df.columns]].head(5).to_dict("records"))

    # ============================================================
    # 4) BASELINE FROM DERIBIT (account IM/MM only; no local engine)
    # ============================================================
    margin_balance_btc = _margin_balance_from_account(account_info)

    if isinstance(account_info, dict):
        im_before_run = float(account_info.get("initial_margin") or 0.0)
        mm_before_run = float(account_info.get("maintenance_margin") or 0.0)
    else:
        im_before_run = 0.0
        mm_before_run = 0.0

    if margin_balance_btc > 0:
        mm_pct_start = min(100.0, 100.0 * mm_before_run / margin_balance_btc)
    else:
        mm_pct_start = 0.0

    # ============================================================
    # 5) CLOSE/HOLD - deterministic then LLM finalizer (OPTIONS only)
    # ============================================================
    current_positions_text = format_positions_for_llm(positions_df)

    client = None
    if use_llm:
        client = make_llm_client(provider=provider, model=llm_model_id)

    # Build positions_side_qty map from positions_df
    positions_side_qty: Dict[str, Dict[str, Any]] = {}
    if positions_df is not None and not positions_df.empty:
        for _, r in positions_df.iterrows():
            sym = str(r.get("symbol") or r.get("instrument_name") or "").strip()
            if not sym:
                continue
            sz = float(r.get("size") or r.get("qty") or 0.0)
            qty = int(abs(sz)) if float(abs(sz)).is_integer() else int(round(abs(sz)))
            if qty <= 0:
                continue
            positions_side_qty[sym] = {"side": "BUY" if sz > 0 else "SELL", "qty": qty}

    # A) deterministic close/hold suggestion
    close_det_sentence, close_det_decisions, close_det_cost, close_det_bundle = run_close_hold_deterministic(
        positions_text=current_positions_text,
        positions_side_qty=positions_side_qty,
        btc_price=btc_price,
        macro_now=macro_now,
        account_info=account_info,
        llm_model_id=llm_model_id,
        provider=provider,
        api_key=api_key,
        use_llm=False,         # deterministic
        currency="BTC",
    )

    # B) LLM final close/hold (locks decisions; excludes perps by policy inside close_engine)
    # Close/Hold LLM finalizer (Options only)
    if use_llm and client is not None:
        close_sentence, close_validated, close_cost = run_close_hold_llm_agent(
            deterministic_decisions=close_det_decisions,
            fundamental_text=formatted_fundamental_text,
            sentiment_text=formatted_sentiment_text,
            strategy=strategy_text,
            forcast_messsage=forecast_message or "",
            btc_price=btc_price,
            account_info=account_info or {},
            positions_text=current_positions_text,
            positions_side_qty=positions_side_qty,
            client=client,
            mm_cap_pct=float(OPEN_MM_CAP_PCT),
            debug_dump=True,
        )
    else:
        # fallback: deterministic only
        close_sentence = close_det_sentence
        close_validated = close_det_decisions
        close_cost = 0.0
        total_cost += float(close_cost or 0.0)

    # C) STRICT simulate MM/IM after closes (Deribit)
    deribit_client = get_deribit_client()
    close_mm_bundle = {}
    if deribit_client is not None:
        close_mm_bundle = simulate_mm_im_after_close(
            deribit_client=deribit_client,
            currency="BTC",
            positions_side_qty=positions_side_qty,
            close_decisions=close_validated,
        )

    # D) LOCKED close decisions text (saved to txt by the function)
    close_locked_text = close_decisions_to_text(
        close_decisions=close_validated,
        mm_before_pct=(close_mm_bundle.get("before", {}) or {}).get("mm_pct_of_mb"),
        mm_after_sim_pct=(close_mm_bundle.get("after", {}) or {}).get("mm_pct_of_mb"),
    )

    # Build positions_after_close list for OPEN baseline
    if positions_df is not None and not positions_df.empty:
        current_positions_list = positions_df[["instrument_name", "size"]].to_dict(orient="records")
    else:
        current_positions_list = []

    positions_after_close = apply_close_decisions(
        current_positions=current_positions_list,
        close_decisions=_norm_decisions(close_validated) or [],
    )

    # ============================================================
    # 6) OPEN - strict scenarios only (SCN_*) then selector LLM
    # ============================================================
    # Build SCN_* scenarios using strict margin sim
    # Build open candidates from valuation_df (you already have this helper)
    open_candidates_list = build_open_candidates_from_valuation_df(
        valuation_df=valuation_df,
        default_qty=1,
    )

    # Strict SCN_* scenario search (Deribit simulated)
    open_scenarios = generate_mm_acceptable_open_scenarios(
        positions_after_close=positions_after_close,
        open_candidates=open_candidates_list[: int(OPEN_MAX_CANDIDATES_FOR_MM)],
        mm_cap_pct=float(OPEN_MM_CAP_PCT),
        qty_grid=OPEN_QTY_GRID_EVEN,   # you already define this list in multi_agents.py
        currency="BTC",
        max_candidates=10_000,         # keep reasonable; your function default is huge
        preselect_k=500,               # keep reasonable
        max_calls_legs=2,
        max_puts_legs=2,
        debug_path=DATA_DIR,
    )
    open_context_txt = build_open_context_from_scenarios(
        scenarios=open_scenarios,
        max_lines=40,
    )
    # account_info AFTER-CLOSE baseline for the open selector prompt
    account_info_after_close = dict(account_info or {})
    try:
        after = (close_mm_bundle.get("after") or {})
        account_info_after_close["margin_balance"] = after.get("margin_balance", account_info_after_close.get("margin_balance"))
        account_info_after_close["maintenance_margin"] = after.get("maintenance_margin", account_info_after_close.get("maintenance_margin"))
        account_info_after_close["mm_pct_of_mb_after_close"] = after.get("mm_pct_of_mb")
    except Exception:
        pass

    open_sentence = ""
    chosen_open_scenario_id = "NONE"
    open_cost = 0.0
    if use_llm and client is not None:
        open_sentence, chosen_open_scenario_id, open_cost = run_open_selector_llm(
            fundamental_text=formatted_fundamental_text,
            sentiment_text=formatted_sentiment_text,
            strategy=strategy_text,
            forcast_messsage=forecast_message or "",
            btc_price=btc_price,
            account_info=account_info_after_close,
            close_locked_text=close_locked_text,
            open_context_txt=open_context_txt,
            client=client,
            mm_cap_pct=float(OPEN_MM_CAP_PCT),
            debug_dump=True,
        )
        total_cost += float(open_cost or 0.0)

    # Convert chosen SCN_* -> open legs
    scenario_open_legs = scenario_id_to_open_legs(
        scenario_id=chosen_open_scenario_id,
        open_scenarios=open_scenarios,
    )

    # Strict simulate MM after open (optional but useful before final)
    open_mm_bundle = simulate_mm_im_after_open(
        positions_after_close=positions_after_close,
        open_legs=scenario_open_legs,
        currency="BTC",
    )

    open_locked_text = open_legs_to_text(
        chosen_open_scenario_id=chosen_open_scenario_id,
        open_legs=scenario_open_legs,
        mm_bundle=open_mm_bundle,
        debug_dump=True,
    )

    # ============================================================
    # 7) STRUCTURER - merge locked CLOSE/HOLD + locked OPEN into final decisions
    # ============================================================
    struct_sentence = ""
    allocation_validated_list: List[Dict[str, Any]] = []

    if use_llm and client is not None:
        struct_sentence, allocation_validated_list, struct_cost = run_structurer_llm(
            client=client,
            close_locked_text=close_locked_text,
            open_locked_text=open_locked_text,
        )
        total_cost += float(struct_cost or 0.0)
    else:
        # No-LLM fallback: just combine deterministically
        allocation_validated_list = (_norm_decisions(close_validated) or []) + (scenario_open_legs or [])
        struct_sentence = "[NO-LLM MODE] merged locked close + open."

    decisions_df = pd.DataFrame(allocation_validated_list or [])
    decisions_df = enrich_decisions_for_db(
        decisions_df,
        btc_price=btc_price,
        positions_df=positions_df,
        live_options_df=live_options_df,
        valuation_df=valuation_df,
    )
    # --- AFTER CLOSE snapshot from strict simulate ---
    _after_close = (close_mm_bundle.get("after") or {}) if isinstance(close_mm_bundle, dict) else {}
    im_after_close = float(_after_close.get("initial_margin") or 0.0)
    mm_after_close = float(_after_close.get("maintenance_margin") or 0.0)
    mb_after_close = float(_after_close.get("margin_balance") or 0.0)
    mm_pct_after_close = _after_close.get("mm_pct_of_mb")
    try:
        mm_pct_after_close = float(mm_pct_after_close) if mm_pct_after_close is not None else 0.0
    except Exception:
        mm_pct_after_close = 0.0

    margin_expl_after_close = close_mm_bundle.get("raw_after") if isinstance(close_mm_bundle, dict) else None

    # ============================================================
    # 9) FINAL MARGIN AFTER OPEN using Deribit simulate_portfolio
    # ============================================================
    im_after_open = im_after_close
    mm_after_open = mm_after_close
    mm_pct_after_open = mm_pct_after_close
    mb_after_open = mb_after_close
    margin_expl_after_open = None  # raw Deribit response, optional

    if deribit_client is not None:
        try:
            # 1) Base positions from current account snapshot
            if positions_df is not None and not positions_df.empty:
                current_positions_list = positions_df[["instrument_name", "size"]].to_dict(orient="records")
            else:
                current_positions_list = []

            # 2) Normalize CLOSE and ALLOCATION decisions
            close_decisions_list = _norm_decisions(close_validated) or []
            allocation_decisions_list = allocation_validated_list or []

            # 3) Apply CLOSE decisions first (same logic as AFTER-CLOSE)
            positions_after_close = apply_close_decisions(
                current_positions=current_positions_list,
                close_decisions=close_decisions_list,
            )

            # 4) Apply ALLOCATION decisions on top of AFTER-CLOSE book
            positions_after_allocation = apply_allocation_decisions(
                current_positions=positions_after_close,
                allocation_decisions=allocation_decisions_list,
            )

            # 5) Ask Deribit for IM/MM of ONLY the final allocated positions
            res_after_open = calc_margin_for_positions(
                client=deribit_client,
                currency="BTC",
                positions=positions_after_allocation,
            )

            im_after_open = float(res_after_open.get("initial_margin") or im_after_close)
            mm_after_open = float(res_after_open.get("maintenance_margin") or mm_after_close)
            mb_after_open = float(res_after_open.get("margin_balance") or mb_after_close)

            if mb_after_open > 0:
                mm_pct_after_open = min(100.0, 100.0 * mm_after_open / mb_after_open)
            else:
                mm_pct_after_open = 0.0

            margin_expl_after_open = res_after_open

        except Exception as e:
            logging.warning("Deribit simulate_portfolio AFTER ALLOCATION failed: %s", e)


    # ============================================================
    # 10) Export CSV summary (margin_engine version) + TOP 10 OPEN IDEAS
    # ============================================================
    if save_data:
        out_dir = Path(os.getenv("MODEL_OUTPUT_DIR", "/data")) / "final_runs"
        out_dir.mkdir(parents=True, exist_ok=True)

        _ts = dt.datetime.utcnow().strftime("%Y-%m-%d_%H-%M-%S")
        _csv_path = str(out_dir / f"decisions_{_ts}_{llm_model_id}.csv")


        if not decisions_df.empty:
            decisions_df.to_csv(_csv_path, index=False)
            num_cols = decisions_df.shape[1]
            with open(_csv_path, "a", newline="", encoding="utf-8") as f:
                w = csv.writer(f)
                empty = [""] * num_cols

                def _pad_row(key, val=""):
                    return [key, val] + [""] * max(0, num_cols - 2)

                def _fmt_btc(v):
                    try:
                        return f"{float(v):.8f}"
                    except Exception:
                        return ""

                def _fmt_pct(v):
                    try:
                        return f"{float(v):.2f}%"
                    except Exception:
                        return ""

                # spacer
                for _ in range(2):
                    w.writerow(empty)

                # === MARGIN_ENGINE snapshots (simplified: BEFORE vs FINAL) ===
                # BEFORE = mm_before_run, mm_pct_start
                # FINAL  = mm_after_open, mm_pct_after_open
                w.writerow(_pad_row("MARGIN_BEFORE_MM_BTC", _fmt_btc(mm_before_run)))
                w.writerow(_pad_row("MARGIN_BEFORE_MM_%MB", _fmt_pct(mm_pct_start)))

                w.writerow(_pad_row("MARGIN_AFTER_FINAL_MM_BTC", _fmt_btc(mm_after_open)))
                w.writerow(_pad_row("MARGIN_AFTER_FINAL_MM_%MB", _fmt_pct(mm_pct_after_open)))

                # spacer then totals/timestamps/summaries
                for _ in range(2):
                    w.writerow(empty)
                w.writerow(_pad_row("TOTAL_LLM_COST_USD", f"{float(total_cost):.6f}"))

                now_utc = dt.datetime.now(dt.timezone.utc)

                def _fmt(ts: dt.datetime) -> str:
                    return ts.strftime("%Y/%m/%d    %I:%M %p")

                try:
                    from zoneinfo import ZoneInfo
                    rows = [
                        ["RUN_TIME_UTC", _fmt(now_utc)],
                        ["RUN_TIME_AFRICA_CAIRO", _fmt(now_utc.astimezone(ZoneInfo("Africa/Cairo")))]
                    ]
                except Exception:
                    rows = [["RUN_TIME_UTC", _fmt(now_utc)]]

                for r in rows:
                    w.writerow(r + [""] * max(0, num_cols - len(r)))
                    
                def _row_in_col_f(text: str):
                    """
                    Put text into column F (index 5), leave other columns empty.
                    Excel will wrap automatically because of embedded newlines.
                    """
                    row = [""] * num_cols
                    if num_cols > 5:
                        row[5] = (text or "").strip()
                    return row


                # spacer
                for _ in range(2):
                    w.writerow(empty)

                # CLOSE sentence in column F
                w.writerow(_row_in_col_f(
                    "CLOSE SENTENCE:\n" + (close_sentence or "").strip()
                ))

                # Allocation sentence in column F
                w.writerow(_row_in_col_f(
                    "ALLOCATION SENTENCE:\n" + (struct_sentence or "").strip()
                ))

                # spacer
                for _ in range(2):
                    w.writerow(empty)

                # Fundamental text in column F
                w.writerow(_row_in_col_f(
                    "FORMATTED FUNDAMENTAL TEXT:\n" +
                    format_fundamental_for_llm(fundamental_text)
                ))

                # spacer
                for _ in range(2):
                    w.writerow(empty)

                # Sentiment text in column F
                w.writerow(_row_in_col_f(
                    "FORMATTED SENTIMENT TEXT:\n" +
                    format_sentiment_for_llm(sentiment_text)
                ))


                # ---------- TOP 10 OPEN IDEAS from OPEN agent ----------
                for _ in range(2):
                    w.writerow(empty)
                
                headers = ["symbol", "side", "POP", "required_mm", "mm_delta", "required_im", "im_delta","quantity" ]
                w.writerow(headers + [""] * max(0, num_cols - len(headers)))
                def _fmt_3(v):
                    try:
                        return f"{float(v):.3f}"
                    except Exception:
                        return v
                open_with_margin_list = []
                for d in (open_with_margin_list or []):
                    row = [
                        d.get("symbol", d.get("instrument_name", "")),
                        d.get("side", ""),
                        _fmt_3(d.get("POP")),
                        _fmt_3(d.get("required_maintenance_margin")),
                        _fmt_3(d.get("mm_delta_btc")),
                        _fmt_3(d.get("required_initial_margin")),
                        _fmt_3(d.get("im_delta_btc")),
                        int(d.get("quantity", d.get("qty", 0))) if d.get("quantity") is not None else "",
                    ]
                    w.writerow(row + [""] * max(0, num_cols - len(row)))



            logging.info("Decisions saved to CSV: %s", _csv_path)
            import logging
            import os
            import time
            import requests # type: ignore


            def _send_telegram_document(bot_token: str, chat_id: str, file_path: str, caption: str) -> None:
                url = f"https://api.telegram.org/bot{bot_token}/sendDocument"
                with open(file_path, "rb") as f:
                    files = {"document": f}
                    data = {"chat_id": chat_id, "caption": caption}
                    r = requests.post(url, data=data, files=files, timeout=60)
                r.raise_for_status()


            def _send_telegram_message(bot_token: str, chat_id: str, text: str) -> None:
                url = f"https://api.telegram.org/bot{bot_token}/sendMessage"
                data = {"chat_id": chat_id, "text": text}
                r = requests.post(url, data=data, timeout=30)
                r.raise_for_status()


            def _get_telegram_chat_ids() -> list[str]:
                """
                Read all target chat IDs from TELEGRAM_CHAT_IDS (JSON in .env),
                remove empty values and duplicates.
                At least one valid ID is enough to continue.
                """
                import os
                import json

                raw = os.getenv("TELEGRAM_CHAT_IDS", "{}")

                try:
                    data = json.loads(raw)
                except Exception:
                    data = {}

                chat_ids: list[str] = []
                seen = set()

                for chat_id in data.values():
                    cid = str(chat_id).strip()

                    if cid and cid not in seen:
                        chat_ids.append(cid)
                        seen.add(cid)

                return chat_ids


            def _send_document_to_many(bot_token: str, chat_ids: list[str], file_path: str, caption: str) -> int:
                """
                Try sending to all chat IDs.
                If one fails, continue with the others.
                Return number of successful sends.
                """
                success_count = 0

                for cid in chat_ids:
                    try:
                        _send_telegram_document(bot_token, cid, file_path, caption)
                        success_count += 1
                        logging.info("Telegram CSV sent successfully to chat_id=%s", cid)
                    except Exception as e:
                        logging.warning("Telegram CSV send failed for chat_id=%s: %s", cid, e, exc_info=True)

                return success_count


            def _send_message_to_many(bot_token: str, chat_ids: list[str], text: str) -> int:
                """
                Try sending text to all chat IDs.
                If one fails, continue with the others.
                Return number of successful sends.
                """
                success_count = 0

                for cid in chat_ids:
                    try:
                        _send_telegram_message(bot_token, cid, text)
                        success_count += 1
                        logging.info("Telegram message sent successfully to chat_id=%s", cid)
                    except Exception as e:
                        logging.warning("Telegram message send failed for chat_id=%s: %s", cid, e, exc_info=True)

                return success_count


            # ------------------------------------------------------------------
            # CASE 1: decisions exist -> export CSV + send document to many IDs
            # ------------------------------------------------------------------
            if os.getenv("TELEGRAM_SEND_MODEL_CSV", "1") == "1":
                try:
                    bot_token = os.getenv("TELEGRAM_BOT_TOKEN", "").strip()
                    chat_ids = _get_telegram_chat_ids()

                    if bot_token and chat_ids:
                        mm_start_str = f"{float(mm_pct_start):.2f}%" if mm_pct_start is not None else "N/A"
                        mm_end_str = f"{float(mm_pct_after_open):.2f}%" if mm_pct_after_open is not None else "N/A"
                        cost_str = f"{float(total_cost):.6f}" if total_cost is not None else "N/A"

                        caption = (
                            f"Model: {llm_model_id}\n"
                            f"Cost (USD): {cost_str}\n"
                            f"MM%: {mm_start_str} → {mm_end_str}"
                        )

                        sent_count = _send_document_to_many(bot_token, chat_ids, _csv_path, caption)

                        if sent_count == 0:
                            logging.warning("Telegram CSV send failed for all configured chat IDs.")
                        else:
                            logging.info("Telegram CSV sent successfully to %s/%s recipients.", sent_count, len(chat_ids))

                        time.sleep(2)
                    else:
                        logging.warning("Telegram CSV enabled but TELEGRAM_BOT_TOKEN missing or no chat IDs configured.")
                except Exception as e:
                    logging.warning("Failed during Telegram CSV send flow: %s", e, exc_info=True)


            # ------------------------------------------------------------------
            # CASE 2: no decisions -> send text message to many IDs
            # ------------------------------------------------------------------
            else:
                logging.info("No decisions to save to CSV.")

                if os.getenv("TELEGRAM_SEND_MODEL_CSV", "0") == "1":
                    try:
                        bot_token = os.getenv("TELEGRAM_BOT_TOKEN", "").strip()
                        chat_ids = _get_telegram_chat_ids()

                        if bot_token and chat_ids:
                            msg = f"No decisions generated for model: {llm_model_id}"
                            sent_count = _send_message_to_many(bot_token, chat_ids, msg)

                            if sent_count == 0:
                                logging.warning("No 'No decisions' Telegram message was delivered to any configured chat ID.")
                            else:
                                logging.info(
                                    "'No decisions' Telegram message sent successfully to %s/%s recipients.",
                                    sent_count,
                                    len(chat_ids),
                                )

                            time.sleep(2)
                        else:
                            logging.warning("Telegram CSV enabled but TELEGRAM_BOT_TOKEN missing or no chat IDs configured.")
                    except Exception as e:
                        logging.warning("Failed to send 'No decisions' Telegram message: %s", e, exc_info=True)
                else:
                    logging.info("[save_data=False] Skipping CSV export + Telegram send.")
    # ============================================================
    # 11) DB SAVE & RETURN
    # ============================================================
    SAVE_COLS = [
        "symbol", "action", "right", "side", "quantity",
        "reason", "when_to_close", "POP", "btc_price",
        "avg_price_btc", "avg_price_usd", "mark_price_btc", "mark_price_usd",
    ]

    df_for_db = decisions_df.copy()
    if "quantity" not in df_for_db.columns and "qty" in df_for_db.columns:
        df_for_db["quantity"] = df_for_db["qty"]

    for c in SAVE_COLS:
        if c not in df_for_db.columns:
            df_for_db[c] = pd.NA
    df_for_db = df_for_db[SAVE_COLS].copy()

    # Save FINAL allocation decisions to the main decisions table (unchanged logic)
    saved_ok = None
    open_trades_saved_ok = None
    
    if save_data:
        saved_ok = save_model_decisions_daily(
            decisions_df=df_for_db,
            llm_provider=provider,
            model_id=llm_model_id,
            db_path=DB_PATH,
            save_mode="append",
        )

        # Save top 10 OPEN candidates (valuation + margin-enriched) if you still want that table
        open_trades_payload = (open_with_margin_list or [])
        open_trades_saved_ok = save_open_trades_daily(
            open_trades=open_trades_payload,
            llm_provider=provider,
            model_id=llm_model_id,
            db_path=DB_PATH,
        )
    else:
        logging.info("[save_data=False] Skipping DB saves (decisions + open_trades).")

    def _pick_decisions_table(provider: str, model_id: Optional[str]) -> Optional[str]:
        mid = (model_id or "").lower()
        prov = (provider or "").lower()
        if prov == "openai" and ("4o" in mid): return "decisions_gpt_4o_multi_agent"
        if prov == "openai" and ("5" in mid or "gpt-5" in mid or "gpt5" in mid): return "decisions_gpt_5_multi_agent"
        if prov == "openai" and ("5-mini" in mid or "gpt-5-mini" in mid or "gpt5-mini" in mid): return "decisions_gpt_5_mini_multi_agent"
        if prov == "xai" and ("grok" in mid): return "decisions_grok4_multi_agent"
        if prov == "anthropic" and ("claude" in mid): return "decisions_claude_sonnet_multi_agent"
        return None

    now_utc = dt.datetime.now(dt.timezone.utc)
    try:
        from zoneinfo import ZoneInfo as _ZoneInfo
        cairo_iso = now_utc.astimezone(_ZoneInfo("Africa/Cairo")).isoformat()
    except Exception:
        cairo_iso = dt.datetime.now().isoformat()

    try:
        preview = decisions_df.head(50).to_dict(orient="records")
    except Exception:
        preview = []

    # counts based on FINAL allocation decisions
    close_n_final = len(
        [d for d in (allocation_validated_list or []) if str(d.get("action", "")).upper() == "CLOSE"]
    )
    open_n_final = len(
        [d for d in (allocation_validated_list or []) if str(d.get("action", "")).upper() == "OPEN"]
    )
    
    # ------------------------------------------------------------
    # Helper: save old/new IM/MM snapshot into MM_IM table
    # ------------------------------------------------------------
    def _save_mm_im_row(
        run_time_utc: dt.datetime,
        provider: str,
        model_id: Optional[str],
        im_before: float,
        mm_before: float,
        im_after: float,
        mm_after: float,
        im_pct_mb_before: Optional[float],
        im_pct_mb_after: Optional[float],
        mm_pct_mb_before: Optional[float],
        mm_pct_mb_after: Optional[float],
    ) -> None:
        try:
            conn = sqlite3.connect(DB_PATH)
            cur = conn.cursor()

            # Create table once if it doesn't exist
            cur.execute(
                """
                CREATE TABLE IF NOT EXISTS MM_IM (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    run_time_utc TEXT NOT NULL,
                    provider TEXT,
                    model_id TEXT,
                    im_before_btc REAL,
                    mm_before_btc REAL,
                    im_after_btc REAL,
                    mm_after_btc REAL,
                    im_pct_mb_before REAL,
                    im_pct_mb_after REAL,
                    mm_pct_mb_before REAL,
                    mm_pct_mb_after REAL
                )
                """
            )

            # Insert one snapshot row per pipeline run
            cur.execute(
                """
                INSERT INTO MM_IM (
                    run_time_utc, provider, model_id,
                    im_before_btc, mm_before_btc,
                    im_after_btc, mm_after_btc,
                    im_pct_mb_before, im_pct_mb_after,
                    mm_pct_mb_before, mm_pct_mb_after
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    run_time_utc.isoformat(),
                    provider,
                    model_id,
                    float(im_before),
                    float(mm_before),
                    float(im_after),
                    float(mm_after),
                    None if im_pct_mb_before is None else float(im_pct_mb_before),
                    None if im_pct_mb_after  is None else float(im_pct_mb_after),
                    None if mm_pct_mb_before is None else float(mm_pct_mb_before),
                    None if mm_pct_mb_after  is None else float(mm_pct_mb_after),
                ),
            )

            conn.commit()
        except Exception as e:
            logging.warning("Failed to save MM/IM snapshot: %s", e)
        finally:
            try:
                conn.close()
            except Exception:
                pass

    # ============================================================
    # 11) Margin Preview object (for UI simple view)
    # ============================================================
    im_before = float(im_before_run)          # IM before any actions
    mm_before = float(mm_before_run)          # MM before any actions

    im_after  = float(im_after_open)
    mm_after  = float(mm_after_open)          # MM after final OPEN/ALLOCATION

    # Use real starting MB for "before" and simulated mb_after_open for "after"
    if margin_balance_btc and margin_balance_btc > 0:
        im_pct_start = 100.0 * im_before / margin_balance_btc
    else:
        im_pct_start = None

    if mb_after_open and mb_after_open > 0:
        im_pct_after = 100.0 * im_after / mb_after_open
    else:
        im_pct_after = None

    # These two are already computed earlier in the pipeline
    mm_pct_start_local = mm_pct_start          # MM% vs MB before
    mm_pct_after_local = mm_pct_after_open     # MM% vs MB after

    margin_preview = {
        "current": {
            "im_btc": im_before,
            "mm_btc": mm_before,
            "im_pct_mb": im_pct_start,
            "mm_pct_mb": mm_pct_start_local,
        },
        "new": {
            "im_btc": im_after,
            "mm_btc": mm_after,
            "im_pct_mb": im_pct_after,
            "mm_pct_mb": mm_pct_after_local,
        },
        "delta": {
            "im_btc": im_after - im_before,
            "mm_btc": mm_after - mm_before,
            "im_pct_mb": (
                im_pct_after - im_pct_start
                if (im_pct_after is not None and im_pct_start is not None)
                else None
            ),
            "mm_pct_mb": (
                mm_pct_after_local - mm_pct_start_local
                if (mm_pct_after_local is not None and mm_pct_start_local is not None)
                else None
            ),
        },
        # per-leg line items can be added later; UI handles empty list
        "lines": [],
    }

    # Persist old/new IM & MM snapshot in MM_IM table
    if save_data:
        _save_mm_im_row(
            run_time_utc=now_utc,
            provider=provider,
            model_id=llm_model_id,
            im_before=im_before,
            mm_before=mm_before,
            im_after=im_after,
            mm_after=mm_after,
            im_pct_mb_before=im_pct_start,
            im_pct_mb_after=im_pct_after,
            mm_pct_mb_before=mm_pct_start_local,
            mm_pct_mb_after=mm_pct_after_local,
        )
    else:
        logging.info("[save_data=False] Skipping MM_IM snapshot save.")
        
    return {
        "provider": provider,
        "model_id": llm_model_id,
        "decisions_table": _pick_decisions_table(provider, llm_model_id),
        "total_cost": float(total_cost),
        "run_time": {"utc_iso": now_utc.isoformat(), "africa_cairo_iso": cairo_iso},

        # margin engine snapshots
        "margin_engine": {
            "before_any_decision": {
                "im_btc": float(im_before_run),
                "mm_btc": float(mm_before_run),
                "mm_pct_of_mb": float(mm_pct_start),
                "explanation": None,
            },
            "after_close": {
                "im_btc": float(im_after_close),
                "mm_btc": float(mm_after_close),
                "mm_pct_of_mb": float(mm_pct_after_close),
                "explanation": margin_expl_after_close,
            },
            "after_open": {
                "im_btc": float(im_after_open),
                "mm_btc": float(mm_after_open),
                "mm_pct_of_mb": float(mm_pct_after_open) if mm_pct_after_open is not None else None,
                "explanation": margin_expl_after_open,
            },
        },

        "formatted_fundamental_text": format_fundamental_for_llm(fundamental_text),
        "formatted_sentiment_text": format_sentiment_for_llm(sentiment_text),
        "close_sentence": (close_sentence or "").strip(),
        "allocation_sentence":  (struct_sentence  or "").strip(),

        "counts": {
            "close_n": close_n_final,
            "open_n":  open_n_final,
            "total_n": len(allocation_validated_list or []),
        },
        "saved_to_db": bool(saved_ok) if saved_ok is not None else None,
        "decisions_preview": preview,

        "margin_preview": margin_preview,
        "artifacts": {
            "margin_preview_json": json.dumps(margin_preview, default=float),
        }
    }



       
if __name__ == "__main__":
    setup_cli_logging(force=True)

    import os
    import json
    import traceback

    try:
        # Local (package) imports - now work because of the bootstrap at top
        from .btc_options import load_or_fetch_live_options, fetch_current_deribit_positions
        from .sentiment import get_macro_sentiment_scores_llm
        from .btc_price import get_btc_price
        from .config import DB_PATH, fetch_account_capital, DAYS_AHEAD, get_strategy_text
        from .runner_db_helper import get_strategy_pair, build_forecast_line_safe, get_x_for_run

        # ---------- FIXED MODEL ----------
        provider = "openai"
        llm_model_id = "gpt-5-mini"
        api_key = os.getenv("OPENAI_API_KEY")

        logger.info("=== multi_agents.py DIRECT SMOKE TEST ===")
        logger.info("provider=%s model=%s DB_PATH=%s DAYS_AHEAD=%s", provider, llm_model_id, DB_PATH, DAYS_AHEAD)

        if not api_key:
            logger.warning("OPENAI_API_KEY is not set. OpenAI calls will fail unless it is set.")

        # ---------- Build required inputs ----------
        logger.info("Loading live options (days_ahead=%s)...", DAYS_AHEAD)
        live_options_df = load_or_fetch_live_options(days_ahead=DAYS_AHEAD, use_cache=True)
        if live_options_df is None or getattr(live_options_df, "empty", True):
            raise RuntimeError("live_options_df is empty; cannot run pipeline.")

        logger.info("Fetching current positions...")
        positions_df = fetch_current_deribit_positions()
        if positions_df is None:
            logger.warning("positions_df is None; continuing with empty.")
        elif getattr(positions_df, "empty", False):
            logger.warning("positions_df is empty; continuing (no positions).")

        logger.info("Fetching BTC price...")
        btc_price = float(get_btc_price() or 0.0)
        logger.info("BTC price=%s", btc_price)

        # Strategy
        try:
            active, default = get_strategy_pair()
            strategy_text = (active or "").strip() or (default or "").strip()
        except Exception as e:
            logger.warning("get_strategy_pair failed: %s (falling back to get_strategy_text)", e)
            strategy_text = (get_strategy_text() or "").strip()

        if not strategy_text:
            strategy_text = "Sell BTC option premium with risk-aware rules (PoP, IVR, DTE, MM cap)."
            logger.warning("strategy_text empty -> using fallback strategy_text.")

        # Forecast (optional)
        try:
            forecast_message = build_forecast_line_safe(db_path=DB_PATH)
        except Exception as e:
            logger.warning("build_forecast_line_safe failed: %s", e)
            forecast_message = ""

        # Account info / capital
        try:
            account_info = fetch_account_capital(
                client_id=os.getenv("DERIBIT_CLIENT_ID"),
                client_secret=os.getenv("DERIBIT_CLIENT_SECRET"),
                currency="BTC",
                basis="equity",
            ) or {}
        except Exception as e:
            logger.warning("fetch_account_capital failed: %s", e)
            account_info = {}

        try:
            account_capital_usd = float(account_info.get("capital_usd") or 0.0)
        except Exception:
            account_capital_usd = 0.0

        if account_capital_usd <= 0:
            # safe fallback so you can still test LLM/logging flow
            account_capital_usd = float(os.getenv("SMOKE_CAPITAL_USD", "100000"))
            logger.warning("capital_usd invalid -> using fallback account_capital_usd=%s", account_capital_usd)

        # Macro sentiment
        try:
            macro_dic = get_macro_sentiment_scores_llm(provider=provider, model_id=llm_model_id) or {}
            macro_now = float(macro_dic.get("score_now") or 0.0)
            macro_7D = float(macro_dic.get("score_7d") or 0.0)
            macro_30D = float(macro_dic.get("score_30d") or 0.0)
        except Exception as e:
            logger.warning("get_macro_sentiment_scores_llm failed: %s -> using zeros", e)
            macro_now = macro_7D = macro_30D = 0.0

        # X sentiment (your system wants these)
        try:
            x_scores, x_warn = get_x_for_run()
            if x_warn:
                logger.warning("X warning: %s", x_warn)

            def _f(v, d=0.0):
                try:
                    return float(v)
                except Exception:
                    return float(d)

            x_score_now = _f((x_scores or {}).get("score_now"), 0.0)
            x_score_7D = _f((x_scores or {}).get("score_7d"), x_score_now)
            x_score_30D = _f((x_scores or {}).get("score_30d"), x_score_now)
            x_sentence_input = str((x_scores or {}).get("sentence") or "")
        except Exception as e:
            logger.warning("get_x_for_run failed: %s -> using zeros", e)
            x_score_now = x_score_7D = x_score_30D = 0.0
            x_sentence_input = ""

        logger.info("Calling run_multi_agent_pipeline() directly...")
        result = run_multi_agent_pipeline(
            live_options_df=live_options_df,
            positions_df=positions_df,
            account_capital_usd=account_capital_usd,
            strategy_text=strategy_text,
            macro_now=macro_now,
            macro_7D=macro_7D,
            macro_30D=macro_30D,
            btc_price=btc_price,
            account_info=account_info,
            llm_model_id=llm_model_id,
            api_key=api_key,
            forecast_message=forecast_message,
            max_candidates=int(os.getenv("SMOKE_MAX_CANDIDATES", "120")),
            max_rows_to_llm=int(os.getenv("SMOKE_MAX_ROWS_TO_LLM", "60")),
            provider=provider,
            debuge=True,
            x_score_now=x_score_now,
            x_score_7D=x_score_7D,
            x_score_30D=x_score_30D,
            x_sentence_input=x_sentence_input,
            use_llm=False,  # smoke test without LLM calls
            save_data=False,  # smoke test without DB writes
        )

        logger.info("DONE. Printing compact result summary...")
        if isinstance(result, dict):
            summary = {
                "ok": result.get("ok"),
                "provider": result.get("provider"),
                "model_id": result.get("model_id"),
                "total_cost": result.get("total_cost"),
                "saved_to_db": result.get("saved_to_db"),
                "counts": result.get("counts"),
            }
            print(json.dumps(summary, indent=2, default=str))
        else:
            print(result)

    except Exception as e:
        logger.exception("Smoke test failed: %s", e)
        print(traceback.format_exc())
        raise
