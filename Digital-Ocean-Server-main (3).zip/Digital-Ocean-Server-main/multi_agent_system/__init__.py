# multi_agent_system/__init__.py
import sys as _sys
from . import config as _config

# Backward-compatible alias: allows legacy `import config` to work
_sys.modules.setdefault("config", _config)
