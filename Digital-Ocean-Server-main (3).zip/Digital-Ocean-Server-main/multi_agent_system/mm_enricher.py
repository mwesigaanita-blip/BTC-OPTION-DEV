from __future__ import annotations

from typing import Dict, Optional
import logging
logging.basicConfig(level=logging.INFO, encoding="utf-8")


from .Deribit_margin import DeribitClient



def get_trade_margin_requirements(
    *,
    client: DeribitClient,
    currency: str,
    trade: Dict,
) -> Dict[str, float]:
    """
    Given a single trade, call Deribit's margin simulation and return
    ONLY the required Initial Margin (IM) and Maintenance Margin (MM).

    Under the hood we use private/simulate_portfolio, via DeribitClient.simulate_portfolio,
    by building a one-position portfolio that contains only this trade.

    Args:
        client:
            Authenticated DeribitClient.
        currency:
            Margin currency, e.g. "BTC".
        trade:
            Dict with at least:
                - "instrument_name" or "symbol"
                - "quantity" or "qty"
                - "side" / "direction"  ("buy"/"sell" or "long"/"short")

    Returns:
        {
            "initial_margin": float,
            "maintenance_margin": float,
        }

        If something goes wrong, both will be 0.0.
    """
    if client is None:
        raise ValueError("get_trade_margin_requirements: client must not be None")

    instrument = trade.get("instrument_name") or trade.get("symbol")
    if not instrument:
        raise ValueError(
            "get_trade_margin_requirements: trade must contain 'instrument_name' or 'symbol'"
        )

    # Quantity
    raw_qty = 1
    if raw_qty is None:
        raise ValueError(
            "get_trade_margin_requirements: trade must contain 'quantity' or 'qty'"
        )

    try:
        qty = float(raw_qty)
    except Exception as e:
        raise ValueError(f"get_trade_margin_requirements: invalid quantity {raw_qty!r}") from e

    # Direction -> signed amount (positive long, negative short)
    side = (trade.get("side") or trade.get("direction") or "").lower()
    if side in ("buy", "long"):
        amount = qty
    elif side in ("sell", "short"):
        amount = -qty
    else:
        raise ValueError(
            f"get_trade_margin_requirements: unknown side/direction {side!r}, expected buy/sell or long/short"
        )

    # Build a one-position portfolio for this trade
    positions = [
        {
            "instrument_name": instrument,
            "amount": amount,  # Deribit expects positive for long, negative for short
        }
    ]

    try:
        # This calls private/simulate_portfolio under the hood
        res = client.simulate_portfolio(
            currency=currency,
            positions=positions,
            add_positions=True,  # add on top of existing live positions
        )

        im = float(
            res.get("initial_margin")
            or res.get("projected_initial_margin")
            or 0.0
        )
        mm = float(
            res.get("maintenance_margin")
            or res.get("projected_maintenance_margin")
            or 0.0
        )

        return {
            "initial_margin": im,
            "maintenance_margin": mm,
        }

    except Exception as e:
        logging.warning(
            "get_trade_margin_requirements: failed to get margin for %s: %s",
            instrument,
            e,
        )
        return {
            "initial_margin": 0.0,
            "maintenance_margin": 0.0,
        }


if __name__ == "__main__":
    """
    Simple test harness for mm_enricher.py.

    It tests the REAL function get_trade_margin_requirements().
    Swap MockDeribitClient for your real DeribitClient if you want
    to hit the real Deribit API.
    """

    import pprint

    print("\n=== SINGLE TRADE MARGIN TEST ===\n")

    # ------------------------------------------------------------
    # MOCK DERIBIT CLIENT FOR OFFLINE LOGIC TEST
    # ------------------------------------------------------------
    class MockDeribitClient:
        """
        Minimal mock implementing simulate_portfolio so we can test
        get_trade_margin_requirements() without calling Deribit.
        """

        def simulate_portfolio(self, currency: str, add_positions: bool, simulated_positions: dict):
            # You can tweak these numbers to see different outputs.
            # We only return the fields our function needs.
            return {
                "initial_margin": 0.05,
                "maintenance_margin": 0.04,
            }

    # 👉 To hit the REAL Deribit API instead, replace the two lines below with:
    #
    #   from Deribit_margin import get_deribit_client
    #   client = get_deribit_client()
    #
    client = MockDeribitClient()

    # Example trade (SELL 1x BTC option)
    test_trade = {
        "instrument_name": "BTC-30JAN26-115000-C",
        "side": "SELL",
        "quantity": 1,
    }

    margin = get_trade_margin_requirements(
        client=client,
        currency="BTC",
        trade=test_trade,
    )

    print("Trade:")
    pprint.pp(test_trade)

    print("\nRequired margin (IM & MM only):")
    pprint.pp(margin)

    print("\n=== TEST COMPLETE ===")

