import os
import time
import logging
from typing import List, Dict, Any, Optional

import requests
from dotenv import load_dotenv

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def _is_session_not_found(payload: dict) -> bool:
    try:
        err = (payload or {}).get("error") or {}
        if int(err.get("code") or 0) != 13009:
            return False
        data = err.get("data") or {}
        reason = str(data.get("reason") or "").lower()
        msg = str(err.get("message") or "").lower()
        return ("session_not_found" in reason) or ("unauthorized" in msg)
    except Exception:
        return False

class DeribitClient:
    """
    Minimal Deribit HTTP JSON-RPC client for using private/simulate_portfolio.
    Uses client_credentials auth via /public/auth.
    """

    def __init__(
        self,
        client_id: str,
        client_secret: str,
        base_url: str = "https://www.deribit.com",  # or "https://test.deribit.com"
    ) -> None:
        self.client_id = client_id
        self.client_secret = client_secret
        self.base_url = base_url.rstrip("/")
        self.session = requests.Session()
        self.access_token: Optional[str] = None
        self.token_expiry_ts: float = 0.0

    # ------------------------------------------------------------------ #
    # Auth
    # ------------------------------------------------------------------ #
    def _auth(self, force: bool = False) -> None:
        """
        Authenticate with client_credentials and cache the access_token.
        """ 
        now = time.time()
        if (not force) and self.access_token and now < (self.token_expiry_ts - 30):
            return  # still valid
        url = f"{self.base_url}/api/v2/public/auth"
        payload = {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "public/auth",
            "params": {
                "grant_type": "client_credentials",
                "client_id": self.client_id,
                "client_secret": self.client_secret,
            },
        }
        resp = self.session.post(url, json=payload, timeout=10)
        resp.raise_for_status()
        data = resp.json()
        if "result" not in data:
            raise RuntimeError(f"Auth failed: {data}")
        result = data["result"]
        self.access_token = result["access_token"]
        expires_in = float(result.get("expires_in", 3600))
        self.token_expiry_ts = time.time() + 0.9 * expires_in  # refresh slightly early
        logger.info("Authenticated with Deribit, token expires in %.0f seconds", expires_in)

    def _ensure_auth(self) -> None:
        if self.access_token is None or time.time() >= self.token_expiry_ts:
            self._auth()

    # ------------------------------------------------------------------ #
    # JSON-RPC helper
    # ------------------------------------------------------------------ #
    def _rpc(self, method: str, params: dict | None = None) -> dict:
        params = params or {}

        # Only attach token for private methods (recommended)
        if method.startswith("private/"):
            self._ensure_auth()
            params["access_token"] = self.access_token

        payload = {
            "jsonrpc": "2.0",
            "id": int(time.time() * 1000),
            "method": method,
            "params": params,
        }

        for attempt in range(2):
            r = requests.post(f"{self.base_url}/api/v2", json=payload, timeout=20)

            # Try parse json always (Deribit returns JSON for errors too)
            try:
                data = r.json()
            except Exception:
                data = None

            # Handle session_not_found unauthorized
            if r.status_code in (400, 401) and isinstance(data, dict) and _is_session_not_found(data):
                logger.warning("Deribit auth invalid (13009 session_not_found). Re-auth and retrying once.")
                self._auth(force=True)

                # refresh token in payload for retry
                if method.startswith("private/"):
                    payload["params"]["access_token"] = self.access_token
                continue

            # Normal error handling
            r.raise_for_status()
            if isinstance(data, dict) and data.get("error"):
                # If Deribit returns JSON-RPC error but HTTP 200
                if _is_session_not_found(data):
                    logger.warning("Deribit auth invalid (13009). Re-auth and retrying once.")
                    self._auth(force=True)
                    if method.startswith("private/"):
                        payload["params"]["access_token"] = self.access_token
                    continue
                raise RuntimeError(f"Deribit RPC error: {data['error']}")

            return data.get("result") if isinstance(data, dict) else data

        raise RuntimeError("Deribit RPC failed after re-auth retry.")


    
    def get_account_summary(self, currency: str) -> Dict[str, Any]:
        """
        Fetch live account summary from Deribit.
        We use this when the hypothetical portfolio is empty (no positions).
        """
        params = {
            "currency": currency.upper(),
            "extended": True,
        }
        return self._rpc("private/get_account_summary", params)

    def get_positions(
        self,
        currency: str,
        *,
        kind: Optional[str] = None,  # "option" | "future" | None
    ) -> List[Dict[str, Any]]:
        params: Dict[str, Any] = {"currency": currency.upper()}
        if kind:
            params["kind"] = str(kind).lower()
        res = self._rpc("private/get_positions", params)
        return res or []
    
    def simulate_portfolio(
        self,
        currency: str,
        positions: List[Dict[str, Any]],
        add_positions: bool = False,
    ) -> Dict[str, Any]:
        simulated_positions = {
            p["instrument_name"]: float(p["amount"])
            for p in positions
        }

        params = {
            "currency": currency.upper(),
            "simulated_positions": simulated_positions,
            "add_positions": bool(add_positions),
        }

        logger.info(
            "Simulating portfolio: currency=%s, n_positions=%d, add_positions=%s",
            currency, len(simulated_positions), add_positions
        )
        return self._rpc("private/simulate_portfolio", params)


# ---------------------------------------------------------------------- #
# Helper: build position lists for simulate_portfolio
# ---------------------------------------------------------------------- #
def build_positions_from_current(
    current_positions: List[Dict[str, Any]],
    *,
    currency: str = "BTC",
) -> List[Dict[str, Any]]:
    """
    Normalize positions into Deribit simulate_portfolio format:
      [{"instrument_name": str, "amount": float}, ...]

    - Aggregates duplicates by instrument_name
    - Drops invalid/empty names
    - Drops NaN/inf/near-zero
    - Filters instruments that don't match currency prefix (e.g., "BTC-")
    """
    import math, logging

    pref = f"{(currency or '').upper()}-"
    agg: Dict[str, float] = {}

    for row in (current_positions or []):
        inst = str(row.get("instrument_name") or row.get("symbol") or "").strip().upper()
        if not inst:
            continue

        # Filter out wrong currency instruments early (prevents 400)
        if pref and not inst.startswith(pref):
            continue

        raw = row.get("amount")
        if raw is None:
            raw = row.get("size", row.get("qty", row.get("quantity", 0.0)))

        try:
            amt = float(raw or 0.0)
        except Exception:
            continue

        if math.isnan(amt) or math.isinf(amt):
            continue

        # drop dust
        if abs(amt) < 1e-9:
            continue

        agg[inst] = agg.get(inst, 0.0) + amt

    out: List[Dict[str, Any]] = []
    for inst, amt in agg.items():
        if abs(amt) < 1e-9:
            continue
        out.append({"instrument_name": inst, "amount": float(amt)})

    out.sort(key=lambda x: x["instrument_name"])
    logging.info("build_positions_from_current: in=%d out=%d (currency=%s)", len(current_positions or []), len(out), currency)
    return out


def apply_close_decisions(
    current_positions: list[dict],
    close_decisions: list[dict],
) -> list[dict]:
    """
    Build a hypothetical 'after CLOSE' position list.

    current_positions: list of dicts with:
        {"instrument_name": "...", "amount": float}
      (or legacy keys symbol/size/qty will be tolerated)

    close_decisions: list of dicts with:
        {"symbol": "...", "action": "CLOSE"|"HOLD", ...}

    Any symbol with action == CLOSE will be removed (amount=0).
    """
    # Map symbol -> should_close?
    symbols_to_close = {
        str(d.get("symbol", "")).strip().upper()
        for d in (close_decisions or [])
        if str(d.get("action", "")).upper() == "CLOSE"
    }

    out: list[dict] = []
    for row in (current_positions or []):
        inst = str(row.get("instrument_name") or row.get("symbol") or "").strip()
        if not inst:
            continue
        inst_up = inst.upper()

        # If we close it -> remove from output
        if inst_up in symbols_to_close:
            continue

        # size/amount handling (amount is canonical)
        size = (
            row.get("amount")
            if row.get("amount") is not None
            else row.get("size", row.get("qty", 0.0))
        )
        try:
            size = float(size or 0.0)
        except Exception:
            size = 0.0

        if abs(size) < 1e-12:
            continue

        out.append({"instrument_name": inst_up, "amount": float(size)})

    return out


def apply_allocation_decisions(
    current_positions: List[Dict[str, Any]],
    allocation_decisions: List[Dict[str, Any]],
) -> List[Dict[str, Any]]:
    """
    Build a hypothetical position list AFTER applying the final allocation decisions.

    allocation_decisions: list of dicts like:
        {
          "symbol": "BTC-26DEC25-85000-P",
          "action": "CLOSE" | "OPEN" | "HOLD",
          "side": "BUY" | "SELL",
          "quantity": int,
          ...
        }

    Logic:
      - CLOSE => set position in that symbol to zero.
      - OPEN  => adjust amount by +qty (BUY) or -qty (SELL).
      - HOLD  => leave as is.
    """
    # Start from a map symbol -> amount from current positions
    pos_map: Dict[str, float] = {}
    for row in current_positions:
        inst = str(row.get("instrument_name") or row.get("symbol") or "").strip()
        if not inst:
            continue
        size = (
            row.get("amount")
            if row.get("amount") is not None
            else row.get("size", row.get("qty", 0.0))
        )
        try:
            size = float(size or 0.0)
        except Exception:
            size = 0.0
        if abs(size) < 1e-12:
            size = 0.0
        pos_map[inst.upper()] = size

    # Apply allocation decisions
    for d in allocation_decisions:
        sym = str(d.get("symbol") or d.get("instrument_name") or "").strip()
        if not sym:
            continue
        sym_up = sym.upper()
        action = str(d.get("action", "")).upper()

        if action == "CLOSE":
            pos_map[sym_up] = 0.0
            continue

        if action == "OPEN":
            side = str(d.get("side") or "SELL").upper().strip()
            if side not in ("BUY", "SELL"):
                side = "SELL"

            qty_raw = d.get("quantity", d.get("qty", 0))
            try:
                qty = float(qty_raw or 0.0)
            except Exception:
                qty = 0.0

            # Force integer contracts for options (safer for Deribit simulate)
            # If you *really* need fractional, remove int() but expect 400 sometimes.
            qty = int(round(abs(qty)))

            if qty <= 0:
                continue

            delta = qty if side == "BUY" else -qty
            pos_map[sym_up] = pos_map.get(sym_up, 0.0) + float(delta)


        # HOLD -> nothing to change

    # Convert back to list for simulate_portfolio
    out: List[Dict[str, Any]] = []
    for sym_up, amt in pos_map.items():
        if abs(amt) < 1e-12:
            continue
        out.append(
            {
                "instrument_name": sym_up,
                "amount": amt,
            }
        )

    return out

def _log_deribit_http_error(e: Exception, sim_positions: list) -> None:
    import logging, json
    resp = getattr(e, "response", None)
    if resp is None:
        logging.warning("simulate_portfolio error (no HTTP response): %r", e)
        return

    try:
        body = resp.text
    except Exception:
        body = "<no text>"

    logging.warning("simulate_portfolio HTTP %s: %s", getattr(resp, "status_code", None), body[:2000])

    # Log the positions payload safely (truncate)
    try:
        payload_preview = json.dumps(sim_positions[:50], default=str)  # first 50 only
        logging.warning("simulate_portfolio positions payload preview (first 50): %s", payload_preview[:4000])
        logging.warning("simulate_portfolio positions payload count=%d", len(sim_positions))
    except Exception as ex:
        logging.warning("Failed to dump sim_positions: %s", ex)



import time
import random
import threading
from typing import Any, Dict, List

# One-at-a-time guard across threads/process (within this Python process)
_DERIBIT_SIM_LOCK = threading.Lock()

# Optional: enforce a minimum gap between simulate calls (seconds)
_DERIBIT_LAST_SIM_TS = 0.0

DERIBIT_TOO_MANY_CODE = 10028


def _extract_deribit_too_many_wait_seconds(exc: Exception) -> int | None:
    """
    If this is Deribit JSON-RPC error 10028 (too_many_requests),
    return the server-suggested wait seconds, else None.
    """
    resp = getattr(exc, "response", None)
    if resp is None:
        return None

    try:
        data = resp.json()
    except Exception:
        return None

    err = (data or {}).get("error") or {}
    if err.get("code") != DERIBIT_TOO_MANY_CODE:
        return None

    try:
        return int((err.get("data") or {}).get("wait", 1))
    except Exception:
        return 1


def calc_margin_for_positions(
    client,  # DeribitClient
    currency: str,
    positions: List[Dict[str, Any]],
    *,
    max_retries: int = 10,
    min_spacing_s: float = 0.12,   # tune: 0.10–0.20 is usually safe
) -> Dict[str, Any]:
    """
    Delta-map method with add_positions=True.

    We interpret incoming `positions` as the TARGET final book (instrument -> amount).
    We fetch the LIVE book from Deribit, compute:
        delta_map = target_amount - live_amount
    Then call:
        simulate_portfolio(add_positions=True, positions=delta_list)
    """

    def _inst(row: Dict[str, Any]) -> str:
        return str(row.get("instrument_name") or row.get("symbol") or "").strip().upper()

    def _amt(row: Dict[str, Any]) -> float:
        v = row.get("amount")
        if v is None:
            v = row.get("size", row.get("qty", 0.0))
        try:
            x = float(v or 0.0)
        except Exception:
            x = 0.0
        if abs(x) < 1e-12:
            x = 0.0
        return x

    # 1) Normalize TARGET positions -> target_map
    target_positions = build_positions_from_current(positions, currency=currency)
    target_map: Dict[str, float] = {}
    bad_rows: List[Dict[str, Any]] = []

    for p in target_positions:
        nm = _inst(p)
        if not nm:
            bad_rows.append(p)
            continue
        if "amount" not in p:
            # build_positions_from_current should set "amount"
            bad_rows.append(p)
            continue
        amt = _amt(p)
        if abs(amt) < 1e-12:
            continue
        target_map[nm] = target_map.get(nm, 0.0) + amt

    if bad_rows:
        logger.warning(
            "calc_margin_for_positions: invalid target rows=%d sample=%r",
            len(bad_rows),
            bad_rows[:10],
        )

    if not target_map:
        logger.info("calc_margin_for_positions: empty target -> zero IM/MM.")
        return {
            "initial_margin": 0.0,
            "maintenance_margin": 0.0,
            "margin_balance": 0.0,
            "equity": 0.0,
            "total_equity_usd": 0.0,
            "total_initial_margin_usd": 0.0,
            "total_maintenance_margin_usd": 0.0,
        }

    # 2) Fetch LIVE positions (now supported on DeribitClient)
    live_positions = client.get_positions(currency=currency)
    live_positions_norm = build_positions_from_current(live_positions, currency=currency)

    live_map: Dict[str, float] = {}
    for p in live_positions_norm:
        nm = _inst(p)
        if not nm:
            continue
        amt = _amt(p)
        if abs(amt) < 1e-12:
            continue
        live_map[nm] = live_map.get(nm, 0.0) + amt

    # 3) Compute delta_map = target - live
    delta_map: Dict[str, float] = {}
    all_keys = set(live_map.keys()) | set(target_map.keys())

    for k in all_keys:
        delta = float(target_map.get(k, 0.0)) - float(live_map.get(k, 0.0))
        if abs(delta) < 1e-12:
            continue
        delta_map[k] = delta

    # Convert delta map to list for client.simulate_portfolio signature
    delta_list = [{"instrument_name": k, "amount": v} for k, v in delta_map.items()]

    global _DERIBIT_LAST_SIM_TS

    # 4) Serialize + throttle + retry 10028
    with _DERIBIT_SIM_LOCK:
        for attempt in range(int(max_retries)):
            now = time.time()
            gap = now - float(_DERIBIT_LAST_SIM_TS)
            if gap < float(min_spacing_s):
                time.sleep(float(min_spacing_s) - gap)

            try:
                _DERIBIT_LAST_SIM_TS = time.time()

                return client.simulate_portfolio(
                    currency=currency,
                    positions=delta_list,   # delta overlay list
                    add_positions=True,     # start from LIVE book
                )

            except Exception as e:
                wait_s = _extract_deribit_too_many_wait_seconds(e)
                if wait_s is None:
                    _log_deribit_http_error(e, {"delta_list": delta_list[:50], "n": len(delta_list)})
                    raise

                exp = min(8.0, 0.25 * (2 ** attempt))  # 0.25,0.5,1,2,4,8...
                sleep_s = max(float(wait_s), exp) + random.random() * 0.25

                logger.warning(
                    "Deribit rate limit (10028 too_many_requests). "
                    "Sleeping %.2fs then retrying (%d/%d).",
                    sleep_s, attempt + 1, int(max_retries)
                )
                time.sleep(sleep_s)

        raise RuntimeError("Deribit simulate_portfolio retry limit exceeded (10028 too_many_requests).") 
    
    