import sqlite3
from .config import DB_PATH  # or replace with the full path e.g. "btc_trading.sqlite"

def delete_last_row_from_x_score():
    conn = sqlite3.connect(DB_PATH)
    try:
        cur = conn.cursor()

        # Find the most recent row based on timestamp or auto ID
        cur.execute("SELECT rowid, * FROM x_score ORDER BY rowid DESC LIMIT 1;")
        last = cur.fetchone()
        if not last:
            print("⚠️ No rows found in x_score table.")
            return

        last_rowid = last[0]
        print(f"Deleting last row (rowid={last_rowid}) ...")

        cur.execute("DELETE FROM x_score WHERE rowid = ?;", (last_rowid,))
        conn.commit()
        print("✅ Last row deleted successfully.")

    except Exception as e:
        print(f"❌ Error deleting last row: {e}")
    finally:
        conn.close()

if __name__ == "__main__":
    delete_last_row_from_x_score()
