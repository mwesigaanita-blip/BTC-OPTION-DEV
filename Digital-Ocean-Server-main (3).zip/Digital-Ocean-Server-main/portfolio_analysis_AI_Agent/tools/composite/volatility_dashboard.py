"""Tool: composite.volatility_dashboard

Builds the Hedgeye-style BTC volatility dashboard payload. Assembles:

- 30-day & 90-day rolling RVOL time series (computed from BTC closes).
- 30-day RVOL & 90-day RVOL summary stats (latest, 3M & 1Y percentile,
  1Y min/max/quartiles for the box-plot tile).
- 30-day IVOL (DVOL) time series from the existing HV/IV pipeline.
- 30-day IVOL premium time series, defined as ``(IVOL/RVOL_30 − 1)``
  in percentage points.
- BTC snapshot block: latest RVOL_30, IVOL_30, IVOL premium.

Output shape (truncated for readability)::

    {
      asof: "YYYY-MM-DD",
      lookback_days: 365,
      btc: {rvol_30d, ivol_30d, ivol_premium_pct},
      rvol_30d_stats:  {latest, pct_3m, pct_1y, min_1y, p25_1y, median_1y, p75_1y, max_1y, mean_1y, ...},
      rvol_90d_stats:  {latest, pct_3m, pct_1y, ...},
      series: {
        rvol_30d:       [{date, value}, ...],
        rvol_90d:       [{date, value}, ...],
        ivol_30d:       [{date, value}, ...],
        ivol_premium:   [{date, value}, ...],
      },
      fetched_at: int,
    }
"""
from __future__ import annotations

import json
import time
from typing import Optional

import pandas as pd

from portfolio_analysis_AI_Agent.tools.analysis.compute_realized_volatility import (
    compute_realized_volatility,
)
from portfolio_analysis_AI_Agent.tools.analysis.compute_volatility_stats import (
    compute_volatility_stats,
)
from portfolio_analysis_AI_Agent.tools.composite.hv_iv_series import hv_iv_series
from portfolio_analysis_AI_Agent.tools.datafetch.market.get_quant_close_series import (
    get_quant_close_series,
)


def _trim_series(rows: list[dict], cutoff_iso: Optional[str], value_key: str) -> list[dict]:
    if cutoff_iso is None:
        return rows
    return [
        {"date": r["date"], "value": r[value_key]}
        for r in rows if r["date"] >= cutoff_iso and r.get(value_key) is not None
    ]


def volatility_dashboard(lookback_days: int = 365) -> dict:
    # --- 1. BTC closes -> rolling RVOL series ------------------------------
    btc_rows = get_quant_close_series("BTC")["rows"]
    rvol_30 = compute_realized_volatility(btc_rows, window=30)
    rvol_90 = compute_realized_volatility(btc_rows, window=90)

    # --- 2. IVOL series from the existing HV/IV pipeline -------------------
    # Pull enough history that 1Y percentile + chart range work nicely.
    try:
        hv_iv = hv_iv_series(days=int(lookback_days), resolution="1D")
        iv_rows_raw = hv_iv.get("rows") or []
    except Exception:
        iv_rows_raw = []

    ivol_rows: list[dict] = []
    for r in iv_rows_raw:
        if r.get("iv_pct") is None:
            continue
        # Normalise the timestamp to YYYY-MM-DD (matches RVOL rows).
        ts_utc = str(r.get("ts_utc") or "")[:10]
        if not ts_utc:
            continue
        ivol_rows.append({"date": ts_utc, "value": float(r["iv_pct"])})

    # --- 3. IVOL premium series: (IVOL / RVOL_30 - 1) ---------------------
    rvol30_by_date = {r["date"]: r["rvol_pct"] for r in rvol_30["rows"]
                      if r.get("rvol_pct") is not None}
    premium_rows: list[dict] = []
    for r in ivol_rows:
        rv = rvol30_by_date.get(r["date"])
        if rv is None or rv == 0:
            continue
        premium_rows.append({
            "date": r["date"],
            "value": (float(r["value"]) / float(rv) - 1.0) * 100.0,
        })

    # --- 4. Latest snapshot block ------------------------------------------
    last_rvol30 = rvol_30["latest"]
    last_ivol30 = ivol_rows[-1]["value"] if ivol_rows else None
    last_premium = None
    if last_rvol30 and last_ivol30:
        last_premium = (last_ivol30 / last_rvol30 - 1.0) * 100.0

    # --- 5. Stats blocks ---------------------------------------------------
    rvol_30_stats = compute_volatility_stats(rvol_30["rows"], value_key="rvol_pct")
    rvol_90_stats = compute_volatility_stats(rvol_90["rows"], value_key="rvol_pct")

    # --- 6. Trim each series to the requested lookback window --------------
    asof = rvol_30_stats.get("asof") or (ivol_rows[-1]["date"] if ivol_rows else None)
    cutoff_iso: Optional[str] = None
    if asof:
        cutoff_iso = (pd.Timestamp(asof) - pd.Timedelta(days=int(lookback_days))).strftime("%Y-%m-%d")

    rvol_30_series = _trim_series(rvol_30["rows"], cutoff_iso, "rvol_pct")
    rvol_90_series = _trim_series(rvol_90["rows"], cutoff_iso, "rvol_pct")
    ivol_series = [r for r in ivol_rows if (cutoff_iso is None or r["date"] >= cutoff_iso)]
    premium_series = [r for r in premium_rows if (cutoff_iso is None or r["date"] >= cutoff_iso)]

    return {
        "asof": asof,
        "lookback_days": int(lookback_days),
        "btc": {
            "rvol_30d": last_rvol30,
            "ivol_30d": last_ivol30,
            "ivol_premium_pct": last_premium,
        },
        "rvol_30d_stats": rvol_30_stats,
        "rvol_90d_stats": rvol_90_stats,
        "series": {
            "rvol_30d":     rvol_30_series,
            "rvol_90d":     rvol_90_series,
            "ivol_30d":     ivol_series,
            "ivol_premium": premium_series,
        },
        "fetched_at": int(time.time()),
    }


if __name__ == "__main__":
    out = volatility_dashboard(lookback_days=180)
    summary = {
        "asof": out["asof"],
        "lookback_days": out["lookback_days"],
        "btc": out["btc"],
        "rvol_30d_stats": out["rvol_30d_stats"],
        "rvol_90d_stats": out["rvol_90d_stats"],
        "series_counts": {k: len(v) for k, v in out["series"].items()},
    }
    print(json.dumps(summary, indent=2, default=str))

# Run from Digital-Ocean-Server:
#   python -m portfolio_analysis_AI_Agent.tools.composite.volatility_dashboard
