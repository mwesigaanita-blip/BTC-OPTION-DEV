"""Tool: composite.liquidation_flow

Composite - scans recent BTC-PERPETUAL trades for the `liquidation`
flag and aggregates by side (long vs short liquidations) in $-notional.

Deribit marks liquidation prints on the perpetual trade tape. We page
back from the latest until we cover `window_hours` or hit `max_pages`.
"""

from __future__ import annotations

import json
import time
from typing import Any

import requests

from portfolio_analysis_AI_Agent.tools._auth import rpc_url


def _f(x: Any, default: float = 0.0) -> float:
    try:
        return float(x) if x is not None else default
    except (TypeError, ValueError):
        return default


def _fetch_trades_page(instrument: str, count: int, end_seq: int | None) -> dict:
    params: dict = {"instrument_name": instrument, "count": int(count), "sorting": "desc"}
    if end_seq is not None:
        params["end_seq"] = int(end_seq)
    payload = {"jsonrpc": "2.0", "id": 1, "method": "public/get_last_trades_by_instrument", "params": params}
    r = requests.post(rpc_url(), json=payload, timeout=15)
    body = r.json()
    if body.get("error"):
        raise RuntimeError(f"Deribit error: {body['error']}")
    return body.get("result") or {}


def liquidation_flow(
    currency: str = "BTC",
    window_hours: int = 24,
    page_size: int = 1000,
    max_pages: int = 5,
) -> dict:
    """Returns {long_usd, short_usd, asymmetry_flag, count, fetched_at}."""
    instrument = f"{currency.upper()}-PERPETUAL"
    horizon_ms = int((time.time() - window_hours * 3600) * 1000)

    long_usd = short_usd = 0.0
    long_count = short_count = 0
    examples: list[dict] = []
    end_seq: int | None = None
    pages = 0
    earliest_ts = None

    while pages < max_pages:
        res = _fetch_trades_page(instrument, page_size, end_seq)
        trades = res.get("trades") or []
        if not trades:
            break
        pages += 1

        any_in_window = False
        for t in trades:
            ts = int(t.get("timestamp") or 0)
            earliest_ts = ts if earliest_ts is None else min(earliest_ts, ts)
            if ts < horizon_ms:
                continue
            any_in_window = True
            liq = t.get("liquidation")
            if not liq:
                continue
            amt = _f(t.get("amount"))  # USD notional for perpetual
            direction = str(t.get("direction") or "")
            # 'liquidation': 'M' (maker) | 'T' (taker) | 'MT' - the taker side is the liquidated side
            taker_side = direction  # for a perpetual trade, 'direction' is the taker side
            if "T" in str(liq):
                if taker_side == "buy":
                    short_usd += amt  # short liquidated → had to buy back
                    short_count += 1
                else:
                    long_usd += amt
                    long_count += 1
            elif "M" in str(liq):
                if taker_side == "buy":
                    long_usd += amt
                    long_count += 1
                else:
                    short_usd += amt
                    short_count += 1

            if len(examples) < 10:
                examples.append({
                    "ts_ms": ts,
                    "price": t.get("price"),
                    "amount_usd": amt,
                    "direction": direction,
                    "liquidation": liq,
                })

            end_seq_candidate = t.get("trade_seq")
            if end_seq_candidate is not None:
                end_seq = int(end_seq_candidate) - 1

        if earliest_ts is not None and earliest_ts < horizon_ms:
            break
        if not any_in_window:
            break

    total = long_usd + short_usd
    if total == 0:
        flag = "none"
    elif long_usd > short_usd * 1.5:
        flag = "long_capitulation"
    elif short_usd > long_usd * 1.5:
        flag = "short_squeeze"
    else:
        flag = "balanced"

    return {
        "instrument": instrument,
        "window_hours": window_hours,
        "pages_fetched": pages,
        "count_long_liq": long_count,
        "count_short_liq": short_count,
        "long_usd": round(long_usd, 2),
        "short_usd": round(short_usd, 2),
        "total_usd": round(total, 2),
        "asymmetry_flag": flag,
        "sample": examples,
        "fetched_at": int(time.time()),
    }


if __name__ == "__main__":
    print(json.dumps(liquidation_flow(), indent=2, default=str))

# Run from Digital-Ocean-Server:
#   python -m portfolio_analysis_AI_Agent.tools.composite.liquidation_flow
