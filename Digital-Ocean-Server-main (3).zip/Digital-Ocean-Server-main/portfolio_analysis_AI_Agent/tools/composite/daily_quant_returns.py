"""Tool: composite.daily_quant_returns

Build a returns matrix for the Daily Quant dashboard. Default set of
assets matches the Hedgeye sheet (BTC + 8 peers); pass ``assets`` to
narrow it.

Output::

    {as_of, horizons: [...], rows: {ASSET: {1D, 5D, 1M, 3M, 6M, 1Y, QTD, YTD,
                                            52W_HIGH_PCT, 52W_LOW_PCT}}}
"""
from __future__ import annotations

import json
import time
from typing import Iterable

from portfolio_analysis_AI_Agent.tools.analysis.compute_period_returns import (
    HORIZON_KEYS,
    compute_period_returns,
)
from portfolio_analysis_AI_Agent.tools.datafetch.market.get_quant_close_series import (
    get_quant_close_series,
)


DEFAULT_ASSETS = ["BTC", "ETH", "SOL", "AVAX", "ZEC", "MSTR", "MARA", "RIOT", "COIN"]


def daily_quant_returns(assets: Iterable[str] | None = None) -> dict:
    asset_list = [a.strip().upper() for a in (assets or DEFAULT_ASSETS) if a and a.strip()]

    rows: dict[str, dict] = {}
    latest_date: str | None = None
    for a in asset_list:
        series = get_quant_close_series(a)
        rows[a] = compute_period_returns(series["rows"])
        if series["rows"]:
            d = series["rows"][-1]["date"]
            if latest_date is None or d > latest_date:
                latest_date = d

    return {
        "as_of": latest_date,
        "horizons": HORIZON_KEYS,
        "assets": asset_list,
        "rows": rows,
        "fetched_at": int(time.time()),
    }


if __name__ == "__main__":
    out = daily_quant_returns(["BTC", "ETH"])
    print(json.dumps(out, indent=2, default=str))

# Run from Digital-Ocean-Server:
#   python -m portfolio_analysis_AI_Agent.tools.composite.daily_quant_returns
