"""Tool: composite.daily_quant_snapshot

BTC stats strip for the Daily Quant dashboard:

    {as_of, price, market_cap, circulating_supply, change_1d_pct,
     usd_vol_dd_pct, coin_vol_dd_pct, rvol_1m, ivol_1m, ivol_premium_pct,
     fetched_at}

Reads from ``MARKET_DATA_DB.btc_prices`` for price/volume and reuses the
existing :func:`hv_iv_series` composite to derive 1M RVOL and 1M IVOL.
"""
from __future__ import annotations

import json
import logging
import sqlite3
import time
from typing import Optional

from shared.db_paths import MARKET_DATA_DB
from portfolio_analysis_AI_Agent.tools.composite.hv_iv_series import hv_iv_series


log = logging.getLogger("tools.composite.daily_quant_snapshot")

# Hardcoded BTC circulating supply. Refresh quarterly from
# https://www.coingecko.com/en/coins/bitcoin (or any CoinGecko mirror).
BTC_CIRCULATING_SUPPLY = 19_780_000.0


def _last_two_rows() -> list[tuple]:
    """Return ``[(date, close, volume), ...]`` for the 2 most recent days."""
    with sqlite3.connect(str(MARKET_DATA_DB)) as con:
        return con.execute(
            "SELECT date, close, volume FROM btc_prices "
            "ORDER BY date DESC LIMIT 2"
        ).fetchall()


def daily_quant_snapshot() -> dict:
    rows = _last_two_rows()
    if not rows:
        raise RuntimeError("btc_prices table is empty - run the BTC OHLCV fetcher first")

    as_of, last_close, last_vol = rows[0]
    last_close = float(last_close)
    last_vol = float(last_vol or 0.0)

    change_1d_pct: Optional[float] = None
    coin_vol_dd_pct: Optional[float] = None
    usd_vol_dd_pct: Optional[float] = None

    if len(rows) >= 2:
        _, prev_close, prev_vol = rows[1]
        prev_close = float(prev_close or 0.0)
        prev_vol = float(prev_vol or 0.0)
        if prev_close:
            change_1d_pct = (last_close / prev_close - 1.0) * 100.0
        if prev_vol:
            coin_vol_dd_pct = (last_vol / prev_vol - 1.0) * 100.0
        if prev_vol and prev_close:
            usd_prev = prev_vol * prev_close
            usd_last = last_vol * last_close
            if usd_prev:
                usd_vol_dd_pct = (usd_last / usd_prev - 1.0) * 100.0

    rvol_1m: Optional[float] = None
    ivol_1m: Optional[float] = None
    ivol_premium_pct: Optional[float] = None
    try:
        s = hv_iv_series(days=30, resolution="1D")
        for r in reversed(s.get("rows") or []):
            if rvol_1m is None and r.get("hv_pct") is not None:
                rvol_1m = float(r["hv_pct"])
            if ivol_1m is None and r.get("iv_pct") is not None:
                ivol_1m = float(r["iv_pct"])
            if rvol_1m is not None and ivol_1m is not None:
                break
        if rvol_1m and ivol_1m:
            ivol_premium_pct = (ivol_1m / rvol_1m - 1.0) * 100.0
    except Exception:
        log.warning("hv_iv_series failed for snapshot", exc_info=True)

    return {
        "as_of": str(as_of),
        "price": last_close,
        "market_cap": last_close * BTC_CIRCULATING_SUPPLY,
        "circulating_supply": BTC_CIRCULATING_SUPPLY,
        "change_1d_pct": change_1d_pct,
        "usd_vol_dd_pct": usd_vol_dd_pct,
        "coin_vol_dd_pct": coin_vol_dd_pct,
        "rvol_1m": rvol_1m,
        "ivol_1m": ivol_1m,
        "ivol_premium_pct": ivol_premium_pct,
        "fetched_at": int(time.time()),
    }


if __name__ == "__main__":
    print(json.dumps(daily_quant_snapshot(), indent=2, default=str))

# Run from Digital-Ocean-Server:
#   python -m portfolio_analysis_AI_Agent.tools.composite.daily_quant_snapshot
