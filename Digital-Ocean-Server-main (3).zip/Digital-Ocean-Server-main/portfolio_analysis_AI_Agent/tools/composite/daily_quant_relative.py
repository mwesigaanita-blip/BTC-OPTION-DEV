"""Tool: composite.daily_quant_relative

Relative-performance matrix for the Daily Quant dashboard.

Two modes:

- ``base`` and ``vs`` lists (default ``base=BTC``, ``vs=SPX,GOLD,DXY``):
  returns each ``vs`` asset as ``base_return - vs_return`` per horizon.
  This drives the "BTC: RELATIVE PERFORMANCE" block.
- ``vs_btc_assets``: convenience wrapper -- returns each asset's returns
  minus BTC's, driving the "vs BTC" block at the bottom of the sheet.

Output::

    {base, horizons: [...], rows: {ASSET: {horizon: pct}}, fetched_at}
"""
from __future__ import annotations

import json
import time
from typing import Iterable

from portfolio_analysis_AI_Agent.tools.analysis.compute_period_returns import (
    HORIZON_KEYS,
    compute_period_returns,
    relative_returns,
)
from portfolio_analysis_AI_Agent.tools.datafetch.market.get_quant_close_series import (
    get_quant_close_series,
)


DEFAULT_BENCHMARKS = ["SPX", "GOLD", "DXY"]
DEFAULT_VS_BTC_ASSETS = ["ETH", "SOL", "AVAX", "ZEC", "MSTR", "MARA", "RIOT", "COIN"]


def _returns_for(asset: str) -> dict:
    series = get_quant_close_series(asset)
    return compute_period_returns(series["rows"])


def daily_quant_relative(
    base: str = "BTC",
    vs: Iterable[str] | None = None,
) -> dict:
    """``base_return - vs_return`` per horizon for each ``vs`` asset."""
    base_u = base.strip().upper()
    vs_list = [v.strip().upper() for v in (vs or DEFAULT_BENCHMARKS) if v and v.strip()]

    base_ret = _returns_for(base_u)
    rows: dict[str, dict] = {v: relative_returns(base_ret, _returns_for(v)) for v in vs_list}

    return {
        "base": base_u,
        "horizons": HORIZON_KEYS,
        "rows": rows,
        "fetched_at": int(time.time()),
    }


def daily_quant_vs_btc(assets: Iterable[str] | None = None) -> dict:
    """Each ``asset``'s return minus BTC's, per horizon."""
    asset_list = [a.strip().upper() for a in (assets or DEFAULT_VS_BTC_ASSETS)
                  if a and a.strip() and a.strip().upper() != "BTC"]
    btc_ret = _returns_for("BTC")
    rows: dict[str, dict] = {a: relative_returns(_returns_for(a), btc_ret) for a in asset_list}
    return {
        "base": "BTC",
        "horizons": HORIZON_KEYS,
        "rows": rows,
        "fetched_at": int(time.time()),
    }


if __name__ == "__main__":
    print("--- daily_quant_relative(base=BTC, vs=SPX,GOLD,DXY) ---")
    print(json.dumps(daily_quant_relative(), indent=2, default=str))
    print("--- daily_quant_vs_btc(ETH) ---")
    print(json.dumps(daily_quant_vs_btc(["ETH"]), indent=2, default=str))

# Run from Digital-Ocean-Server:
#   python -m portfolio_analysis_AI_Agent.tools.composite.daily_quant_relative
