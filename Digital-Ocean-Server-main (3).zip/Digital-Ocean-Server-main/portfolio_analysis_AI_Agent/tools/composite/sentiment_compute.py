"""Tool: composite.sentiment_compute

Composite - combines funding, OI breakdown, max-pain, liquidations,
and vol regime into one composite directional score in [-1, +1], plus
per-signal sub-scores.

Each individual signal is also returned as-is so the LLM and dashboard
can show them side-by-side.

Note: a separate `put_call` signal was removed because it was a
redundant view of the same call/put OI imbalance already captured by
`oi_breakdown` - the two are co-monotonic on the same underlying data
and double-counting them inflated the OI signal's effective weight.
"""

from __future__ import annotations

import json
import time
from typing import Any

from portfolio_analysis_AI_Agent.tools.datafetch.market.get_funding_rate import get_funding_rate
from portfolio_analysis_AI_Agent.tools.datafetch.market.get_book_summary import get_book_summary
from portfolio_analysis_AI_Agent.tools.datafetch.market.get_historical_volatility import get_historical_volatility
from portfolio_analysis_AI_Agent.tools.datafetch.market.get_dvol import get_dvol
from portfolio_analysis_AI_Agent.tools.datafetch.market.get_index_price import get_index_price
from portfolio_analysis_AI_Agent.tools.composite.open_interest_breakdown import open_interest_breakdown
from portfolio_analysis_AI_Agent.tools.composite.liquidation_flow import liquidation_flow
from portfolio_analysis_AI_Agent.tools.composite.skew_term_structure import skew_term_structure
from portfolio_analysis_AI_Agent.tools.composite.trade_activity_24h import trade_activity_24h
from portfolio_analysis_AI_Agent.tools.analysis.max_pain import max_pain
from portfolio_analysis_AI_Agent.tools.analysis.volatility_compute import volatility_compute


DEFAULT_WEIGHTS = {
    "funding": 0.11,
    "oi_breakdown": 0.11,
    "max_pain": 0.04,
    "liquidations": 0.11,
    "vol_regime": 0.08,
    "iv_richness": 0.08,
    "funding_trend": 0.04,
    "skew_25d": 0.18,
    "term_structure": 0.10,
    "flow_imbalance": 0.15,
}


def _clamp(x: float, lo: float = -1.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, x))


def _f(x: Any, default: float = 0.0) -> float:
    try:
        return float(x) if x is not None else default
    except (TypeError, ValueError):
        return default


def _label_composite(score: float) -> str:
    # between 0.2 and 0.6 → "bullish"; above 0.6 → "strong_bull". Symmetric on the bear side.
    if score >= 0.6:
        return "STRONG_BULL"
    if score >= 0.2:
        return "BULLISH"
    # between -0.2 and 0.2 → "neutral"
    if score > -0.2:
        return "NEUTRAL"
    # between -0.2 and -0.6 → "bearish"; below -0.6 → "strong_bear". Symmetric on the bull side.
    if score > -0.6:
        return "BEARISH_LEANING"
    # between -0.2 and -0.6 → "bearish"; below -0.6 → "strong_bear". Symmetric on the bull side.
    return "STRONG_BEAR"


def sentiment_compute(currency: str = "BTC", weights: dict | None = None) -> dict:
    """Returns composite_score + composite_label + per-signal breakdown."""
    w = {**DEFAULT_WEIGHTS, **(weights or {})}
    signals: dict[str, dict] = {}

    # 1) Funding
    try:
        fr = get_funding_rate(currency=currency)
        cur = _f(fr.get("current"))
        score = _clamp(cur * 20000.0)  # 0.00005 per period maps to ~1.0
        signals["funding"] = {"value": cur, "score": round(score, 4),
                              "label": fr.get("bias"), "weight": w["funding"]}
        trend = fr.get("trend")
        trend_score = 0.3 if trend == "rising" else -0.3 if trend == "falling" else 0.0
        signals["funding_trend"] = {"value": trend, "score": trend_score,
                                    "label": trend, "weight": w["funding_trend"]}
    except Exception as e:
        signals["funding"] = {"error": str(e), "score": 0.0, "weight": 0.0}
        signals["funding_trend"] = {"error": str(e), "score": 0.0, "weight": 0.0}

    # 2) OI breakdown - net call/put bias across all expiries
    try:
        oi = open_interest_breakdown(currency=currency)
        total_c = sum(_f(e.get("call_oi")) for e in oi.get("by_expiry_call_put") or [])
        total_p = sum(_f(e.get("put_oi")) for e in oi.get("by_expiry_call_put") or [])
        denom = total_c + total_p
        bias = (total_c - total_p) / denom if denom > 0 else 0.0
        signals["oi_breakdown"] = {"value": {"call_oi": total_c, "put_oi": total_p},
                                   "score": round(_clamp(bias * 2.0), 4),
                                   "label": "call_heavy" if bias > 0.1 else "put_heavy" if bias < -0.1 else "balanced",
                                   "weight": w["oi_breakdown"]}
    except Exception as e:
        signals["oi_breakdown"] = {"error": str(e), "score": 0.0, "weight": 0.0}

    # 3) Max pain vs spot
    try:
        spot_info = get_index_price(f"{currency.lower()}_usd")
        spot = _f(spot_info.get("index_price"))
        mp = max_pain(get_book_summary(currency=currency, kind="option"), btc_spot=spot, top_expiries=1)
        first = (mp.get("expiries") or [{}])[0]
        dist_pct = _f(first.get("spot_distance_pct"))
        score = _clamp(dist_pct / 5.0)  # spot 5% above max-pain → +1
        signals["max_pain"] = {"value": first.get("max_pain_strike"), "score": round(score, 4),
                               "label": "max_pain_below_spot" if dist_pct < -0.5 else
                                        "max_pain_above_spot" if dist_pct > 0.5 else "near_spot",
                               "weight": w["max_pain"]}
    except Exception as e:
        signals["max_pain"] = {"error": str(e), "score": 0.0, "weight": 0.0}

    # 4) Liquidations
    try:
        liq = liquidation_flow(currency=currency)
        long_usd = _f(liq.get("long_usd"))
        short_usd = _f(liq.get("short_usd"))
        denom = long_usd + short_usd
        # long liq > short → bearish; the score is symmetric.
        score = ((short_usd - long_usd) / denom) if denom > 0 else 0.0
        signals["liquidations"] = {"value": {"long_usd": long_usd, "short_usd": short_usd},
                                   "score": round(_clamp(score), 4),
                                   "label": liq.get("asymmetry_flag"),
                                   "weight": w["liquidations"]}
    except Exception as e:
        signals["liquidations"] = {"error": str(e), "score": 0.0, "weight": 0.0}

    # 5) Vol regime + IV richness
    try:
        hv = get_historical_volatility(currency=currency)
        dvol = get_dvol(currency=currency)
        vc = volatility_compute(hv, dvol)
        regime = vc.get("regime")
        regime_score = {"EXTREME": -0.4, "HIGH": -0.2, "NORMAL": 0.0, "LOW": 0.1}.get(regime, 0.0)
        signals["vol_regime"] = {"value": regime, "score": regime_score,
                                 "label": regime, "weight": w["vol_regime"]}
        richness = vc.get("richness")
        richness_score = {"RICH": -0.2, "FAIR": 0.0, "CHEAP": 0.1}.get(richness, 0.0)
        signals["iv_richness"] = {"value": richness, "score": richness_score,
                                  "label": richness, "weight": w["iv_richness"]}
    except Exception as e:
        signals["vol_regime"] = {"error": str(e), "score": 0.0, "weight": 0.0}
        signals["iv_richness"] = {"error": str(e), "score": 0.0, "weight": 0.0}

    # 6) Skew (25d) + term-structure shape — derived in one network call.
    try:
        sk = skew_term_structure(currency=currency)
        front_skew = sk.get("front_skew_25d")
        # Skew in IV points. A 5pt put-over-call skew already signals real fear.
        skew_score = _clamp(-front_skew / 5.0) if front_skew is not None else 0.0
        signals["skew_25d"] = {
            "value": front_skew,
            "score": round(skew_score, 4),
            "label": sk.get("front_skew_label"),
            "weight": w["skew_25d"],
        }
        shape = (sk.get("term_structure") or {}).get("shape")
        # Backwardation = near-term stress (bearish); contango = calm (mildly bullish).
        shape_score = {"BACKWARDATION": -0.4, "FLAT": 0.0, "CONTANGO": 0.1}.get(shape, 0.0)
        signals["term_structure"] = {
            "value": shape,
            "score": shape_score,
            "label": shape,
            "weight": w["term_structure"],
        }
    except Exception as e:
        signals["skew_25d"] = {"error": str(e), "score": 0.0, "weight": 0.0}
        signals["term_structure"] = {"error": str(e), "score": 0.0, "weight": 0.0}

    # 7) Flow imbalance — net signed delta from 24h aggressor flow.
    # Normalize by gross contracts so the score is comparable across days.
    # Positive net delta = aggregate delta-buying (bullish); negative = delta-selling (bearish).
    try:
        flow = trade_activity_24h(currency=currency, top_instruments=15, trades_per_inst=50)
        ag = flow.get("aggressor") or {}
        fg = flow.get("flow_greeks") or {}
        gross = _f(ag.get("buy_amount")) + _f(ag.get("sell_amount"))
        net_delta = _f(fg.get("net_delta"))
        # net_delta/gross typically in [-1, +1]; scale modestly so a fully one-sided book pins ~1.
        delta_ratio = (net_delta / gross) if gross > 0 else 0.0
        score = _clamp(delta_ratio * 1.5)
        signals["flow_imbalance"] = {
            "value": {
                "net_delta": net_delta,
                "net_vega_per_ivpt": _f(fg.get("net_vega_per_ivpt")),
                "net_premium_usd": _f(ag.get("net_premium_usd")),
                "premium_buy_pct": ag.get("premium_buy_pct"),
            },
            "score": round(score, 4),
            "label": (
                "DELTA_BUYING" if delta_ratio > 0.05 else
                "DELTA_SELLING" if delta_ratio < -0.05 else "BALANCED"
            ),
            "weight": w["flow_imbalance"],
        }
    except Exception as e:
        signals["flow_imbalance"] = {"error": str(e), "score": 0.0, "weight": 0.0}

    # Composite
    num = sum(s.get("score", 0.0) * s.get("weight", 0.0) for s in signals.values())
    wsum = sum(s.get("weight", 0.0) for s in signals.values())
    composite = num / wsum if wsum > 0 else 0.0
    composite = round(_clamp(composite), 4)

    return {
        "composite_score": composite,
        "composite_label": _label_composite(composite),
        "signals": signals,
        "weights_version": "v2_with_skew_flow",
        "fetched_at": int(time.time()),
    }


if __name__ == "__main__":
    out = sentiment_compute()
    print(json.dumps(out, indent=2, default=str))

# Run from Digital-Ocean-Server:
#   python -m portfolio_analysis_AI_Agent.tools.composite.sentiment_compute
