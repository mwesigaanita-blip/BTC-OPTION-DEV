"""Tool: composite.dealer_gamma

Dealer-gamma / GEX proxy from a single `get_book_summary` call. For each
option (under a max-DTE filter, since dealer hedging matters most for
near-dated expiries) we compute Black-Scholes gamma locally using the
row's `mark_iv` (no per-instrument ticker calls).

Two views are returned because the dealer-direction assumption is
unsettled in crypto:

  - **Per-strike dollar gamma** (unsigned). This is the pin-risk view:
    the strike with the most total gamma is where hedging flow gets
    most reflexive near expiry, regardless of sign.

  - **GEX (SpotGamma convention)**: dealers assumed *long calls,
    short puts*. Net GEX = call_gex - put_gex.
      * positive GEX => dealers buy dips / sell rips => suppressed vol
      * negative GEX => dealers chase moves => amplified vol
      * zero-gamma flip strike => regime change pivot

Dollar gamma is reported per 1% spot move, per contract:
    gamma_per_1pct = OI * BS_gamma * spot^2 * 0.01
"""

from __future__ import annotations

import json
import math
import time
from datetime import datetime, timezone
from typing import Any

from portfolio_analysis_AI_Agent.tools.datafetch.market.get_book_summary import get_book_summary
from portfolio_analysis_AI_Agent.tools.datafetch.market.get_index_price import get_index_price


_MONTHS = {"JAN": 1, "FEB": 2, "MAR": 3, "APR": 4, "MAY": 5, "JUN": 6,
           "JUL": 7, "AUG": 8, "SEP": 9, "OCT": 10, "NOV": 11, "DEC": 12}


def _f(x: Any, default: float = 0.0) -> float:
    try:
        return float(x) if x is not None else default
    except (TypeError, ValueError):
        return default


def _parse_name(name: str) -> tuple[str | None, float | None, str | None]:
    parts = (name or "").split("-")
    if len(parts) < 4:
        return None, None, None
    try:
        return parts[1], float(parts[2]), ("C" if name.endswith("-C") else "P" if name.endswith("-P") else None)
    except ValueError:
        return parts[1], None, None


def _expiry_to_years(exp: str, now: datetime) -> float | None:
    if not exp or len(exp) < 6:
        return None
    try:
        if len(exp) == 6:
            d = int(exp[0:1]); mon = exp[1:4]; y = int(exp[4:6])
        else:
            d = int(exp[0:2]); mon = exp[2:5]; y = int(exp[5:7])
        m = _MONTHS.get(mon.upper())
        if not m:
            return None
        dt = datetime(2000 + y, m, d, 8, 0, 0, tzinfo=timezone.utc)
        years = (dt - now).total_seconds() / (86400.0 * 365.0)
        return max(years, 1e-6)
    except (ValueError, IndexError):
        return None


def _bs_gamma(spot: float, strike: float, T: float, iv_pct: float) -> float:
    if spot <= 0 or strike <= 0 or T <= 0 or iv_pct <= 0:
        return 0.0
    sigma = iv_pct / 100.0
    d1 = (math.log(spot / strike) + 0.5 * sigma * sigma * T) / (sigma * math.sqrt(T))
    pdf = math.exp(-0.5 * d1 * d1) / math.sqrt(2.0 * math.pi)
    return pdf / (spot * sigma * math.sqrt(T))


def dealer_gamma(currency: str = "BTC", max_dte_days: float = 60.0, top_pins: int = 5) -> dict:
    bs = get_book_summary(currency=currency, kind="option")
    rows = bs.get("rows") or []

    spot_info = get_index_price(f"{currency.lower()}_usd")
    spot = _f(spot_info.get("index_price"))
    if spot <= 0:
        return {"error": "no_spot_price", "currency": currency, "fetched_at": int(time.time())}

    now = datetime.now(timezone.utc)
    spot2_pct = spot * spot * 0.01  # $ gamma per 1% move, per unit OI×gamma

    by_strike: dict[float, dict] = {}
    n_considered = 0
    n_skipped = 0
    for r in rows:
        name = str(r.get("instrument_name") or "")
        exp, strike, typ = _parse_name(name)
        if not exp or strike is None or not typ:
            n_skipped += 1
            continue
        T_years = _expiry_to_years(exp, now)
        if T_years is None:
            n_skipped += 1
            continue
        dte = T_years * 365.0
        if dte > max_dte_days:
            continue
        oi = _f(r.get("open_interest"))
        iv = _f(r.get("mark_iv"))
        if oi <= 0 or iv <= 0:
            continue

        g = _bs_gamma(spot, strike, T_years, iv)
        dollar_gamma = oi * g * spot2_pct  # $ per 1% move
        bucket = by_strike.setdefault(strike, {"call_gex_usd": 0.0, "put_gex_usd": 0.0,
                                                "call_oi": 0.0, "put_oi": 0.0})
        if typ == "C":
            bucket["call_gex_usd"] += dollar_gamma
            bucket["call_oi"] += oi
        else:
            bucket["put_gex_usd"] += dollar_gamma
            bucket["put_oi"] += oi
        n_considered += 1

    if not by_strike:
        return {"error": "no_options_in_window", "max_dte_days": max_dte_days,
                "currency": currency, "fetched_at": int(time.time())}

    rows_out = []
    total_call_gex = total_put_gex = 0.0
    for k in sorted(by_strike.keys()):
        b = by_strike[k]
        # SpotGamma convention: dealers long calls, short puts
        net_gex = b["call_gex_usd"] - b["put_gex_usd"]
        total_gamma = b["call_gex_usd"] + b["put_gex_usd"]
        total_call_gex += b["call_gex_usd"]
        total_put_gex += b["put_gex_usd"]
        rows_out.append({
            "strike": k,
            "call_gex_usd": round(b["call_gex_usd"], 2),
            "put_gex_usd": round(b["put_gex_usd"], 2),
            "net_gex_usd": round(net_gex, 2),
            "total_dollar_gamma": round(total_gamma, 2),
            "call_oi": b["call_oi"],
            "put_oi": b["put_oi"],
        })

    pin_strikes = sorted(rows_out, key=lambda r: -r["total_dollar_gamma"])[:top_pins]
    total_net_gex = total_call_gex - total_put_gex

    # Zero-gamma flip: find adjacent strikes where cumulative-from-low net_gex crosses zero,
    # or equivalently the strike that minimises |sum of (k > flip) net_gex - sum of (k < flip) net_gex|.
    # Simple approach: walk and find sign change in per-strike net_gex weighted by distance from spot.
    flip = None
    cum = 0.0
    sorted_rows = rows_out  # already sorted by strike
    prev_strike = None
    prev_cum = 0.0
    for r in sorted_rows:
        cum += r["net_gex_usd"]
        if prev_strike is not None and prev_cum != 0.0 and (prev_cum * cum) < 0:
            # linear interpolation
            t = prev_cum / (prev_cum - cum)
            flip = prev_strike + t * (r["strike"] - prev_strike)
            break
        prev_strike = r["strike"]
        prev_cum = cum

    if total_net_gex > 0:
        regime = "POSITIVE_GAMMA"      # dealers dampen vol
    elif total_net_gex < 0:
        regime = "NEGATIVE_GAMMA"      # dealers amplify vol
    else:
        regime = "FLAT"

    # Distance from flip => "near" if within 2% of spot
    flip_distance_pct = ((flip - spot) / spot * 100.0) if flip else None

    return {
        "currency": currency,
        "spot": spot,
        "max_dte_days": max_dte_days,
        "instruments_considered": n_considered,
        "strikes": len(rows_out),
        "totals": {
            "call_gex_usd": round(total_call_gex, 2),
            "put_gex_usd": round(total_put_gex, 2),
            "net_gex_usd": round(total_net_gex, 2),
            "total_dollar_gamma": round(total_call_gex + total_put_gex, 2),
        },
        "regime": regime,
        "zero_gamma_flip_strike": round(flip, 2) if flip else None,
        "flip_distance_from_spot_pct": round(flip_distance_pct, 3) if flip_distance_pct is not None else None,
        "pin_strikes_top": pin_strikes,
        "by_strike": rows_out,
        "convention_note": "SpotGamma: dealers long calls, short puts. Sign may invert in crypto where retail also buys puts.",
        "fetched_at": int(time.time()),
    }


if __name__ == "__main__":
    out = dealer_gamma()
    # Trim by_strike for readability
    trimmed = {**out, "by_strike": f"<{len(out.get('by_strike', []))} strikes omitted>"}
    print(json.dumps(trimmed, indent=2, default=str))

# Run from Digital-Ocean-Server:
#   python -m portfolio_analysis_AI_Agent.tools.composite.dealer_gamma
