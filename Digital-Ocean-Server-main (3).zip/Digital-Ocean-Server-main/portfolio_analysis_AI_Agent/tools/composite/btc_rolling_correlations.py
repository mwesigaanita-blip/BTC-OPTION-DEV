"""Tool: composite.btc_rolling_correlations

Build the time-series payload for the "BTC: Rolling 30D Price Correlations"
chart (Hedgeye style). For each partner asset (default SPX / DXY / GOLD)
returns a series of rolling N-day Pearson correlation between BTC's
daily returns and that partner's daily returns.

Output dict::

    {
      base: "BTC",
      window: int,
      partners: ["SPX", "DXY", "GOLD"],
      history_days: int,
      series: {
        "SPX":  {dates: [...], values: [float|null, ...], stats: {...}},
        "DXY":  {...},
        "GOLD": {...},
      },
      asof: "YYYY-MM-DD"|null,
      fetched_at: int,
    }

The flat ``dates`` + ``values`` arrays (rather than [{date,corr}, ...])
are sized for Recharts: the React side passes them directly through
``useMemo`` into a multi-line chart.
"""
from __future__ import annotations

import json
import time
from datetime import date
from typing import Iterable, Optional

import pandas as pd

from portfolio_analysis_AI_Agent.tools.analysis.compute_rolling_correlation import (
    compute_rolling_correlation,
)
from portfolio_analysis_AI_Agent.tools.datafetch.market.get_quant_close_series import (
    get_quant_close_series,
)


# Hedgeye chart default partners.
DEFAULT_PARTNERS: list[str] = ["SPX", "DXY", "GOLD"]


def _series_from_rows(rows: list[dict]) -> pd.Series:
    if not rows:
        return pd.Series(dtype=float)
    s = pd.Series(
        [float(r["close"]) for r in rows],
        index=pd.to_datetime([r["date"] for r in rows]),
        dtype=float,
    )
    return s.sort_index()


def btc_rolling_correlations(
    partners: Iterable[str] | None = None,
    window: int = 30,
    history_days: int = 365,
    asof: Optional[date | str] = None,
) -> dict:
    partner_list = [p.strip().upper() for p in (partners or DEFAULT_PARTNERS)
                    if p and p.strip()]

    btc_series = _series_from_rows(get_quant_close_series("BTC")["rows"])

    asof_ts: Optional[pd.Timestamp] = None
    if asof is not None:
        asof_ts = pd.Timestamp(asof) if isinstance(asof, str) else pd.Timestamp(asof)
    elif not btc_series.empty:
        asof_ts = btc_series.index[-1]

    cutoff: Optional[pd.Timestamp] = None
    if asof_ts is not None and history_days and history_days > 0:
        cutoff = asof_ts - pd.Timedelta(days=int(history_days))

    series_out: dict[str, dict] = {}
    for p in partner_list:
        partner_rows = get_quant_close_series(p)["rows"]
        partner_series = _series_from_rows(partner_rows)
        full = compute_rolling_correlation(btc_series, partner_series, window=int(window))

        rows = full["rows"]
        if cutoff is not None:
            rows = [r for r in rows if pd.Timestamp(r["date"]) >= cutoff]
        non_null = [r["corr"] for r in rows if r["corr"] is not None]
        stats = {
            "min":  min(non_null) if non_null else None,
            "max":  max(non_null) if non_null else None,
            "mean": (sum(non_null) / len(non_null)) if non_null else None,
            "latest": non_null[-1] if non_null else None,
        }
        series_out[p] = {
            "dates":  [r["date"] for r in rows],
            "values": [r["corr"] for r in rows],
            "stats":  stats,
        }

    return {
        "base": "BTC",
        "window": int(window),
        "partners": partner_list,
        "history_days": int(history_days),
        "series": series_out,
        "asof": str(asof_ts.date()) if asof_ts is not None else None,
        "fetched_at": int(time.time()),
    }


if __name__ == "__main__":
    out = btc_rolling_correlations()
    summary = {
        "base": out["base"],
        "window": out["window"],
        "partners": out["partners"],
        "history_days": out["history_days"],
        "asof": out["asof"],
        "stats_per_partner": {p: out["series"][p]["stats"] for p in out["partners"]},
        "sample_per_partner": {
            p: {"first": (out["series"][p]["dates"][:2], out["series"][p]["values"][:2]),
                "last":  (out["series"][p]["dates"][-2:], out["series"][p]["values"][-2:])}
            for p in out["partners"] if out["series"][p]["dates"]
        },
    }
    print(json.dumps(summary, indent=2, default=str))

# Run from Digital-Ocean-Server:
#   python -m portfolio_analysis_AI_Agent.tools.composite.btc_rolling_correlations
