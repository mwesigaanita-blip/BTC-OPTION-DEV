"""Tool: composite.btc_etf_flows_panel

Read-side composite for the BTC ETF Flows panel. Serves the matrix
required by both the Hedgeye-style table (top "Total" cumulative row +
last N daily rows) and the bottom bar chart (full daily history).

Reads from ``MARKET_DATA_DB.btc_etf_flows`` populated by
:mod:`portfolio_analysis_AI_Agent.tools.jobs.refresh_market_data`. No
upstream network calls happen on the request path.

Output dict::

    {
      tickers: ["IBIT", ..., "BTC"],           # 12 fund tickers (no TOTAL)
      rows: [{date, flows: {TICKER: float|None}, total: float|None}, ...],
      totals: {TICKER: float, "TOTAL": float}, # cumulative since inception
      history: [{date, total}, ...],           # full series for the bar chart
      count: int,
      fetched_at: int,
    }
"""
from __future__ import annotations

import json
import logging
import sqlite3
import time
from typing import Optional

from shared.db_paths import MARKET_DATA_DB

log = logging.getLogger("tools.composite.btc_etf_flows_panel")

# Canonical column order matches the Farside source / Hedgeye image.
DEFAULT_TICKERS: list[str] = [
    "IBIT", "FBTC", "BITB", "ARKB", "BTCO", "EZBC",
    "BRRR", "HODL", "BTCW", "MSBT", "GBTC", "BTC",
]


def _connect() -> sqlite3.Connection:
    return sqlite3.connect(str(MARKET_DATA_DB), timeout=30)


def btc_etf_flows_panel(
    days: int = 10,
    history_days: Optional[int] = 180,
) -> dict:
    """Daily-flows matrix from SQLite.

    ``days`` controls the size of the daily rows panel (default 10 to
    match the Hedgeye sheet). ``history_days`` controls the bar-chart
    series length (``None`` = full history).
    """
    rows_by_date: dict[str, dict[str, Optional[float]]] = {}
    totals: dict[str, float] = {}
    history: list[dict] = []

    try:
        with _connect() as con:
            # Pull every row, build the date->ticker map in Python — the
            # table is small (a few thousand rows), so cost is negligible.
            cur = con.execute(
                "SELECT date, ticker, flow_usd_m FROM btc_etf_flows ORDER BY date ASC, ticker ASC"
            )
            for d, t, v in cur.fetchall():
                rows_by_date.setdefault(d, {})[t] = (None if v is None else float(v))
    except sqlite3.OperationalError:
        # Table missing — refresh job hasn't been run yet.
        return {
            "tickers": DEFAULT_TICKERS,
            "rows": [],
            "totals": {},
            "history": [],
            "count": 0,
            "fetched_at": int(time.time()),
        }

    # Derive cumulative totals per ticker from the full history.
    for d, by_ticker in rows_by_date.items():
        for tkr, v in by_ticker.items():
            if v is None:
                continue
            totals[tkr] = totals.get(tkr, 0.0) + float(v)

    sorted_dates = sorted(rows_by_date)
    for d in sorted_dates:
        per = rows_by_date[d]
        history.append({"date": d, "total": per.get("TOTAL")})

    if history_days is not None and history_days > 0:
        history = history[-int(history_days):]

    # Daily rows for the top table (last N), with explicit None for any
    # missing ticker so the React grid can render a placeholder dash.
    daily_rows: list[dict] = []
    for d in sorted_dates[-int(days):] if days > 0 else sorted_dates:
        per = rows_by_date[d]
        daily_rows.append({
            "date": d,
            "flows": {t: per.get(t) for t in DEFAULT_TICKERS},
            "total": per.get("TOTAL"),
        })

    return {
        "tickers": DEFAULT_TICKERS,
        "rows": daily_rows,
        "totals": {
            **{t: round(totals.get(t, 0.0), 1) for t in DEFAULT_TICKERS},
            "TOTAL": round(totals.get("TOTAL", 0.0), 1),
        },
        "history": history,
        "count": len(daily_rows),
        "fetched_at": int(time.time()),
    }


if __name__ == "__main__":
    out = btc_etf_flows_panel(days=5, history_days=10)
    print(json.dumps(out, indent=2, default=str))

# Run from Digital-Ocean-Server:
#   python -m portfolio_analysis_AI_Agent.tools.composite.btc_etf_flows_panel
