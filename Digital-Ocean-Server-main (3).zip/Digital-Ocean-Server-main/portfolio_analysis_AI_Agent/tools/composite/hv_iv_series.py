"""Tool: composite.hv_iv_series

Orchestrator: assembles a unified HV vs IV time series for charting.

Priority order per bucket (UTC-aligned, sized by ``resolution``):

1. **Saved snapshot** from ``vol_ticks`` — the value Deribit returned at the
   moment the worker captured it. This is what we want long-term: a real,
   audit-grade record that grows every 5 min the worker is alive.
2. **Live Deribit HV** for the most recent ~16 days (used to fill buckets
   newer than the worker has written yet, or where the saved value is stale).
3. **Computed HV** (rolling 30-day stdev of BTC perp closes) — only as a
   crutch for buckets older than when the worker started saving. As the
   worker accumulates history, the computed segment shrinks toward zero.

Output rows::

    {ts_ms, ts_utc, hv_pct, hv_source, iv_pct, iv_source}

where ``hv_source ∈ {"saved", "deribit", "computed", None}`` and
``iv_source ∈ {"saved", "deribit", None}``.
"""

from __future__ import annotations

import json
import time
from datetime import datetime, timezone
from typing import Literal

from portfolio_analysis import storage
from portfolio_analysis_AI_Agent.tools.analysis.compute_hv_series import (
    compute_hv_from_deribit,
)
from portfolio_analysis_AI_Agent.tools.datafetch.market.get_dvol_full_history import (
    get_dvol_full_history,
)
from portfolio_analysis_AI_Agent.tools.datafetch.market.get_historical_volatility import (
    get_historical_volatility,
)


Resolution = Literal["1D", "1H"]

# Map our API resolutions to the underlying tool conventions.
_HV_RES = {"1D": "1D", "1H": "60"}
_IV_RES = {"1D": "1D", "1H": "3600"}
_BUCKET_MS = {"1D": 86_400_000, "1H": 3_600_000}


def _bucket(ms: int, size_ms: int) -> int:
    return (int(ms) // size_ms) * size_ms


def _iso(ms: int) -> str:
    return datetime.fromtimestamp(ms / 1000, tz=timezone.utc).strftime(
        "%Y-%m-%dT%H:%M:%SZ"
    )


def hv_iv_series(*, days: int, resolution: Resolution = "1D") -> dict:
    """Returns the unified series ready for the chart / CSV export."""
    if resolution not in ("1D", "1H"):
        raise ValueError(f"unsupported resolution: {resolution!r}")
    bucket_ms = _BUCKET_MS[resolution]

    now_ms = int(time.time() * 1000)
    from_ms = now_ms - int(days * 86_400_000)

    # --- 1. Saved snapshots from vol_ticks (always preferred) -------------
    try:
        saved = storage.read_vol_ticks_bucketed(
            from_ms=from_ms, to_ms=now_ms, bucket_ms=bucket_ms,
        )
    except Exception:
        saved = {}

    # --- 2. IV: fill un-saved buckets from live DVOL ----------------------
    iv_by_bucket: dict[int, tuple[float, str]] = {
        b: (v["iv30"], "saved") for b, v in saved.items() if v.get("iv30") is not None
    }
    # If any bucket in [from_ms, now_ms] lacks IV, fetch the missing window from Deribit.
    saved_iv_buckets = set(iv_by_bucket)
    expected_buckets = _expected_buckets(from_ms, now_ms, bucket_ms)
    missing_iv = expected_buckets - saved_iv_buckets
    if missing_iv:
        try:
            iv = get_dvol_full_history(days=days, resolution=_IV_RES[resolution])
            for ts_ms, close in iv["samples"]:
                b = _bucket(ts_ms, bucket_ms)
                if b not in iv_by_bucket:
                    iv_by_bucket[b] = (float(close), "deribit")
        except Exception:
            pass  # leave gaps; chart will render them as gaps

    # --- 3. HV: saved → Deribit (16d) → computed --------------------------
    hv_by_bucket: dict[int, tuple[float, str]] = {
        b: (v["hv30"], "saved") for b, v in saved.items() if v.get("hv30") is not None
    }

    # Fill recent gaps from Deribit's 16-day HV endpoint.
    if expected_buckets - set(hv_by_bucket):
        try:
            hv_d_raw = get_historical_volatility("BTC")
            for row in hv_d_raw.get("samples") or []:
                if isinstance(row, (list, tuple)) and len(row) >= 2:
                    b = _bucket(int(row[0]), bucket_ms)
                    if b not in hv_by_bucket:
                        hv_by_bucket[b] = (float(row[1]), "deribit")
        except Exception:
            pass

    # Fill the remaining (older) gaps with self-computed HV.
    if expected_buckets - set(hv_by_bucket):
        try:
            hv_computed_rows = compute_hv_from_deribit(
                days=days, resolution=_HV_RES[resolution],
            )
            for row in hv_computed_rows:
                b = _bucket(int(row["ts_ms"]), bucket_ms)
                if b not in hv_by_bucket:
                    hv_by_bucket[b] = (float(row["hv_pct"]), "computed")
        except Exception:
            pass

    # --- 4. Merge on the union of buckets ---------------------------------
    all_buckets = sorted(set(iv_by_bucket) | set(hv_by_bucket))
    rows: list[dict] = []
    for b in all_buckets:
        hv = hv_by_bucket.get(b)
        iv = iv_by_bucket.get(b)
        rows.append({
            "ts_ms": b,
            "ts_utc": _iso(b),
            "hv_pct":    hv[0] if hv else None,
            "hv_source": hv[1] if hv else None,
            "iv_pct":    iv[0] if iv else None,
            "iv_source": iv[1] if iv else None,
        })

    # --- 5. Trim to overlap where BOTH series have data -------------------
    # Chart axis should span [first bucket with both HV+IV] to [last bucket
    # with both]. Buckets between with one side missing stay (chart shows
    # a gap), but we don't pad either edge with one-sided rows.
    first_both = next(
        (i for i, r in enumerate(rows)
         if r["hv_pct"] is not None and r["iv_pct"] is not None),
        None,
    )
    last_both = next(
        (i for i, r in enumerate(reversed(rows))
         if r["hv_pct"] is not None and r["iv_pct"] is not None),
        None,
    )
    if first_both is not None and last_both is not None:
        # last_both is index from end - convert to forward index
        last_both = len(rows) - 1 - last_both
        rows = rows[first_both : last_both + 1]
    else:
        rows = []  # no overlap at all - return nothing

    return {
        "resolution": resolution,
        "from_ms": rows[0]["ts_ms"] if rows else None,
        "to_ms":   rows[-1]["ts_ms"] if rows else None,
        "rows": rows,
        "fetched_at": int(time.time()),
    }


def _expected_buckets(from_ms: int, to_ms: int, bucket_ms: int) -> set[int]:
    """All bucket starts in ``[from_ms, to_ms]`` aligned to ``bucket_ms``."""
    start = _bucket(from_ms, bucket_ms)
    end = _bucket(to_ms, bucket_ms)
    return {start + i * bucket_ms for i in range((end - start) // bucket_ms + 1)}


if __name__ == "__main__":
    out = hv_iv_series(days=30, resolution="1D")
    sources_hv: dict = {}
    sources_iv: dict = {}
    for r in out["rows"]:
        sources_hv[r["hv_source"]] = sources_hv.get(r["hv_source"], 0) + 1
        sources_iv[r["iv_source"]] = sources_iv.get(r["iv_source"], 0) + 1
    print(json.dumps({
        "resolution": out["resolution"],
        "n": len(out["rows"]),
        "hv_sources": sources_hv,
        "iv_sources": sources_iv,
        "first": out["rows"][0] if out["rows"] else None,
        "last":  out["rows"][-1] if out["rows"] else None,
    }, indent=2))

# Run from Digital-Ocean-Server:
#   python -m portfolio_analysis_AI_Agent.tools.composite.hv_iv_series
