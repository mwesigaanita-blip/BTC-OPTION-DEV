"""Tool: composite.eom_options_live

Live per-instrument BTC option chain across the next N **end-of-month**
(monthly) expiries on Deribit. Designed to give the agent everything
needed for option-trade reasoning in one call: prices, IV, full Greeks,
top-of-book sizing, premium in BTC and USD, theta-USD, and a
probability-of-profit estimate.

Pipeline (mirrors `multi_agent_system.btc_options.fetch_all_btc_options_live_data`,
extended with EOM-selection and portfolio-extension logic):

  1. `get_instruments(currency, kind="option")` → metadata
     (expiration_timestamp, strike, option_type, settlement_period,
     min_trade_amount, tick_size, block_trade_minimum).

  2. Select the next `n_eom_expiries` expiries with
     `settlement_period == "month"`. Deribit lists months sparsely
     (e.g. M5 / M6 / M7 / M9 / M12), so this is "next 5 *available*",
     not "next 5 calendar months".

  3. If `extend_for_portfolio=True`, inspect
     `get_positions(currency, kind="option")`. If any held option's
     expiry is beyond the last selected EOM, every additional EOM up
     to and including that expiry is appended.

  4. Pre-filter instruments by `dte_min` / `dte_max` (cheap; needs no
     ticker call).

  5. Sequential REST fan-out to `public/ticker` (same retry-session +
     50 ms sleep pattern as `fetch_all_btc_options_live_data`).

  6. Apply post-filters that need ticker data: `min_vol`,
     `delta_abs_min` / `delta_abs_max`.

  7. Per-row derived fields:
        - qty_max_sell = floor(best_bid_amount)
        - qty_max_buy  = floor(best_ask_amount)
        - qty          = max(0, min(qty_max_sell, qty_max_buy))
        - mid_price    = (bid + ask) / 2 when both present
        - premium_mark_btc, premium_mid_btc, premium_mark_usd, premium_mid_usd
        - theta_btc_per_day = theta / 100         (keeps the /100 convention)
        - theta_usd_per_day = theta_btc_per_day * underlying_price
        - POP             = clamp(1 - |delta|, 0, 1)
"""

from __future__ import annotations

import json
import logging
import math
import sys
import time
from datetime import datetime, timezone
from typing import Any, Iterable, Optional

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

# Optional CLI progress bar - only renders when stderr is a TTY, so agent /
# service callers never get noise in their logs.
try:
    from tqdm import tqdm as _tqdm
except Exception:  # tqdm not installed; fall back to identity wrapper.
    _tqdm = None


def _progress(it: Iterable, *, total: Optional[int] = None, desc: str = "") -> Iterable:
    if _tqdm is None or not sys.stderr.isatty():
        return it
    return _tqdm(it, total=total, desc=desc)

from portfolio_analysis_AI_Agent.tools.datafetch.market.get_instruments import get_instruments
from portfolio_analysis_AI_Agent.tools.datafetch.positions.get_positions import get_positions

log = logging.getLogger(__name__)

# Deribit public REST base - same URL the reference function uses.
_REST_BASE = "https://www.deribit.com/api/v2"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _f(x: Any, default: float = 0.0) -> float:
    try:
        return float(x) if x is not None else default
    except (TypeError, ValueError):
        return default


def _clamp(x: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, x))


def _expiry_label(ts_ms: int) -> str:
    """Deribit-style label from a ms timestamp, e.g. 30MAY26."""
    dt = datetime.fromtimestamp(ts_ms / 1000, tz=timezone.utc)
    return f"{dt.day}{dt.strftime('%b').upper()}{dt.strftime('%y')}"


def _create_retry_session(
    retries: int = 5,
    backoff_factor: float = 1.0,
    status_forcelist: tuple[int, ...] = (500, 502, 503, 504),
) -> requests.Session:
    """Match the retry session shape from `fetch_all_btc_options_live_data`."""
    session = requests.Session()
    retry = Retry(
        total=retries,
        read=retries,
        connect=retries,
        backoff_factor=backoff_factor,
        status_forcelist=status_forcelist,
        allowed_methods=["GET"],
    )
    adapter = HTTPAdapter(max_retries=retry)
    session.mount("https://", adapter)
    session.mount("http://", adapter)
    return session


_MONTHS = {"JAN":1,"FEB":2,"MAR":3,"APR":4,"MAY":5,"JUN":6,
           "JUL":7,"AUG":8,"SEP":9,"OCT":10,"NOV":11,"DEC":12}


def _expiry_ms_from_name(name: str) -> Optional[int]:
    """Parse `BTC-DDMMMYY-K-C/P` → expiry ms (08:00 UTC), used as a fallback
    when the position payload doesn't carry an explicit
    `expiration_timestamp`."""
    parts = (name or "").split("-")
    if len(parts) != 4:
        return None
    exp_str = parts[1]
    if len(exp_str) < 6:
        return None
    try:
        day = int(exp_str[:-5])
        month = _MONTHS.get(exp_str[-5:-2].upper())
        year = 2000 + int(exp_str[-2:])
        if month is None:
            return None
        dt = datetime(year, month, day, 8, 0, 0, tzinfo=timezone.utc)
        return int(dt.timestamp() * 1000)
    except (ValueError, KeyError):
        return None


# ---------------------------------------------------------------------------
# Step 2 + 3 - pick EOM expiries (+ portfolio extension)
# ---------------------------------------------------------------------------


def _pick_eom_expiries(
    instruments: list[dict],
    n: int,
    now_ms: int,
    portfolio_expiries_ms: Optional[set[int]] = None,
) -> tuple[list[int], bool]:
    """Return (ascending list of selected expiry_ms, extended_for_portfolio).

    "Next 5 *available*" - Deribit may list M5/M6/M7/M9/M12; we sort the
    monthly expiries that lie in the future and take the first `n`.
    """
    monthly_future = sorted({
        int(i.get("expiration_timestamp") or 0)
        for i in instruments
        if (
            str(i.get("settlement_period") or "").lower() == "month"
            and int(i.get("expiration_timestamp") or 0) > now_ms
        )
    })
    selected = monthly_future[:n]
    extended = False

    if portfolio_expiries_ms:
        max_selected = selected[-1] if selected else 0
        max_held = max(portfolio_expiries_ms)
        if max_held > max_selected:
            extra = [t for t in monthly_future if max_selected < t <= max_held]
            if extra:
                selected = sorted(set(selected) | set(extra))
                extended = True
    return selected, extended


def _collect_portfolio_expiries(currency: str) -> set[int]:
    """Best-effort. Returns the set of `expiration_timestamp` values for
    held option positions. Empty set on any error (so this never blocks
    the main flow)."""
    try:
        pos = get_positions(currency=currency, kind="option")
    except Exception as e:
        log.warning("eom_options_live: get_positions failed - proceeding without portfolio extension. %s", e)
        return set()

    out: set[int] = set()
    for p in (pos.get("positions") or []):
        ts = p.get("expiration_timestamp")
        if not ts:
            ts = _expiry_ms_from_name(str(p.get("instrument_name") or ""))
        if ts:
            try:
                out.add(int(ts))
            except (TypeError, ValueError):
                continue
    return out


# ---------------------------------------------------------------------------
# Step 5 - REST ticker fan-out (same pattern as btc_options.py)
# ---------------------------------------------------------------------------


def _fetch_tickers_rest(
    instrument_names: list[str],
    session: requests.Session,
    per_call_timeout: int = 10,
    sleep_between_calls: float = 0.05,
) -> dict[str, dict]:
    """Sequential REST loop. Returns {instrument_name: ticker_result_dict}.

    Failed instruments are absent from the result (matching the original's
    `try/except + continue` behavior).
    """
    out: dict[str, dict] = {}
    url = f"{_REST_BASE}/public/ticker"
    for name in _progress(instrument_names, total=len(instrument_names), desc="Fetching option tickers"):
        try:
            r = session.get(url, params={"instrument_name": name}, timeout=per_call_timeout)
            r.raise_for_status()
            data = r.json().get("result") or {}
            if isinstance(data, dict) and data:
                out[name] = data
        except Exception as e:
            log.warning("eom_options_live: ticker fetch failed for %s: %s", name, e)
            continue
        if sleep_between_calls:
            time.sleep(sleep_between_calls)
    return out


# ---------------------------------------------------------------------------
# Step 7 - derive per-row fields
# ---------------------------------------------------------------------------


def _build_row(meta: dict, ticker: dict, now_ms: int) -> dict:
    name = str(meta.get("instrument_name") or ticker.get("instrument_name") or "")
    expiry_ms = int(meta.get("expiration_timestamp") or 0)
    dte_float = ((expiry_ms - now_ms) / 86400_000) if expiry_ms else None

    greeks = ticker.get("greeks") or {}
    stats = ticker.get("stats") or {}

    bid = ticker.get("best_bid_price")
    ask = ticker.get("best_ask_price")
    bid_amt = ticker.get("best_bid_amount")
    ask_amt = ticker.get("best_ask_amount")
    mid = (bid + ask) / 2.0 if (bid is not None and ask is not None) else None

    underlying = _f(ticker.get("underlying_price"))
    mark_btc = ticker.get("mark_price")

    # Top-of-book integer caps (same logic as btc_options.py)
    try:
        qty_max_sell = int(math.floor(_f(bid_amt)))
    except Exception:
        qty_max_sell = 0
    try:
        qty_max_buy = int(math.floor(_f(ask_amt)))
    except Exception:
        qty_max_buy = 0
    qty = int(max(0, min(qty_max_sell, qty_max_buy)))

    # Greeks
    delta = ticker.get("delta") if "delta" in ticker else greeks.get("delta")
    pop = _clamp(1.0 - abs(_f(delta))) if delta is not None else None

    theta_raw = greeks.get("theta")
    theta_btc_per_day = _f(theta_raw) / 100.0 if theta_raw is not None else None
    theta_usd_per_day = (
        theta_btc_per_day * underlying
        if (theta_btc_per_day is not None and underlying)
        else None
    )

    premium_mark_btc = _f(mark_btc) if mark_btc is not None else None
    premium_mid_btc = mid
    premium_mark_usd = (
        premium_mark_btc * underlying
        if (premium_mark_btc is not None and underlying)
        else None
    )
    premium_mid_usd = (
        premium_mid_btc * underlying
        if (premium_mid_btc is not None and underlying)
        else None
    )

    return {
        "instrument_name": name,
        "expiration_ms": expiry_ms or None,
        "expiry_label": _expiry_label(expiry_ms) if expiry_ms else None,
        "dte": round(dte_float, 4) if dte_float is not None else None,
        "strike": _f(meta.get("strike")) or None,
        "option_type": meta.get("option_type"),

        # Prices
        "mark_price": mark_btc,
        "mid_price": mid,
        "bid_price": bid,
        "ask_price": ask,
        "last_price": ticker.get("last_price"),
        "underlying_price": underlying or None,

        # IV
        "mark_iv": ticker.get("mark_iv"),
        "bid_iv": ticker.get("bid_iv"),
        "ask_iv": ticker.get("ask_iv"),

        # Greeks
        "delta": delta,
        "gamma": greeks.get("gamma"),
        "vega": greeks.get("vega"),
        "theta": theta_raw,
        "rho": greeks.get("rho"),

        # Liquidity / sizing
        "volume": stats.get("volume"),
        "open_interest": ticker.get("open_interest"),
        "bid_size": bid_amt,
        "ask_size": ask_amt,
        "qty_max_sell": qty_max_sell,
        "qty_max_buy": qty_max_buy,
        "qty": qty,

        # Contract metadata
        "min_trade_amount": meta.get("min_trade_amount"),
        "tick_size": meta.get("tick_size"),
        "block_trade_minimum": meta.get("block_trade_minimum"),
        "contract_multiplier": 1,  # Deribit BTC options = 1 BTC/contract

        # Derived
        "premium_mark_btc": premium_mark_btc,
        "premium_mid_btc": premium_mid_btc,
        "premium_mark_usd": round(premium_mark_usd, 2) if premium_mark_usd is not None else None,
        "premium_mid_usd":  round(premium_mid_usd, 2)  if premium_mid_usd  is not None else None,
        "theta_btc_per_day": theta_btc_per_day,
        "theta_usd_per_day": round(theta_usd_per_day, 4) if theta_usd_per_day is not None else None,
        "POP": round(pop, 4) if pop is not None else None,
    }


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------


def eom_options_live(
    currency: str = "BTC",
    n_eom_expiries: int = 5,
    dte_min: int = 0,
    dte_max: int = 10_000,
    delta_abs_min: float = 0.0,
    delta_abs_max: float = 1.0,
    min_vol: float = 0.0,
    extend_for_portfolio: bool = True,
    per_call_timeout: int = 10,
    sleep_between_calls: float = 0.05,
) -> dict:
    """Return live option-chain rows across the next N EOM expiries.

    Filter knobs (applied in pipeline order):
        dte_min / dte_max          - pre-ticker (cheap; from metadata).
        min_vol                    - post-ticker (uses ticker.stats.volume).
        delta_abs_min / _abs_max   - post-ticker (uses ticker Greeks).

    Args:
        currency: 'BTC' (default) or 'ETH'.
        n_eom_expiries: how many *available* monthly expiries to include.
        extend_for_portfolio: if True, append more EOMs when held options
            expire beyond the default window.
        per_call_timeout: per-ticker REST timeout in seconds.
        sleep_between_calls: pause between ticker calls (same as the
            reference fetch - 50 ms).

    Returns:
        {
          as_of, currency,
          expiries: [{label, timestamp_ms, dte}],
          extended_for_portfolio: bool,
          counts: {total_options, in_selected_expiries, after_dte_filter,
                   tickers_received, final},
          rows: [...],
          filters_applied: {...},
          fetched_at,
        }
    """
    now_ms = int(time.time() * 1000)
    insts = get_instruments(currency=currency, kind="option")
    all_instruments = insts.get("instruments") or []
    log.info("eom_options_live: fetched %d %s option instruments", len(all_instruments), currency)

    portfolio_expiries = _collect_portfolio_expiries(currency) if extend_for_portfolio else set()
    selected_expiries_ms, extended = _pick_eom_expiries(
        all_instruments, n_eom_expiries, now_ms,
        portfolio_expiries_ms=portfolio_expiries,
    )
    selected_set = set(selected_expiries_ms)
    log.info(
        "eom_options_live: selected %d EOM expiries (extended_for_portfolio=%s)",
        len(selected_expiries_ms), extended,
    )

    # Step 4 - pre-filter on expiry membership + DTE.
    candidates: list[dict] = []
    for inst in all_instruments:
        ts = int(inst.get("expiration_timestamp") or 0)
        if ts not in selected_set:
            continue
        dte = (ts - now_ms) / 86400_000
        if dte < dte_min or dte > dte_max:
            continue
        candidates.append(inst)

    count_in_selected = sum(
        1 for i in all_instruments
        if int(i.get("expiration_timestamp") or 0) in selected_set
    )
    log.info(
        "eom_options_live: %d candidates after DTE filter [%d, %d]",
        len(candidates), dte_min, dte_max,
    )

    # Step 5 - REST ticker fan-out.
    session = _create_retry_session()
    candidate_names = [
        str(i.get("instrument_name") or "") for i in candidates if i.get("instrument_name")
    ]
    tickers = _fetch_tickers_rest(
        candidate_names, session,
        per_call_timeout=per_call_timeout,
        sleep_between_calls=sleep_between_calls,
    )

    # Step 6 + 7 - apply post-filters and build rows.
    rows: list[dict] = []
    for inst in candidates:
        name = str(inst.get("instrument_name") or "")
        ticker = tickers.get(name)
        if not ticker:
            continue

        stats = ticker.get("stats") or {}
        vol = _f(stats.get("volume"))
        if vol < min_vol:
            continue

        greeks = ticker.get("greeks") or {}
        delta = ticker.get("delta") if "delta" in ticker else greeks.get("delta")
        if delta is None:
            continue
        delta_abs = abs(_f(delta))
        if delta_abs < delta_abs_min or delta_abs > delta_abs_max:
            continue

        rows.append(_build_row(inst, ticker, now_ms))

    expiry_summary = [
        {
            "label": _expiry_label(t),
            "timestamp_ms": t,
            "dte": round((t - now_ms) / 86400_000, 4),
        }
        for t in selected_expiries_ms
    ]

    log.info("eom_options_live: %d rows after all filters", len(rows))

    return {
        "as_of": now_ms,
        "currency": currency,
        "expiries": expiry_summary,
        "extended_for_portfolio": extended,
        "counts": {
            "total_options": len(all_instruments),
            "in_selected_expiries": count_in_selected,
            "after_dte_filter": len(candidates),
            "tickers_received": len(tickers),
            "final": len(rows),
        },
        "rows": rows,
        "filters_applied": {
            "n_eom_expiries": n_eom_expiries,
            "dte_min": dte_min,
            "dte_max": dte_max,
            "delta_abs_min": delta_abs_min,
            "delta_abs_max": delta_abs_max,
            "min_vol": min_vol,
        },
        "fetched_at": int(time.time()),
    }


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    out = eom_options_live(
        n_eom_expiries=3,
        dte_min=1,
        delta_abs_min=0.20,
        delta_abs_max=0.40,
    )
    sample = out["rows"][:3]
    print(json.dumps({**out, "rows": sample, "sample_size": len(sample)}, indent=2, default=str))
# python -m portfolio_analysis_AI_Agent.tools.composite.eom_options_live

# Run from Digital-Ocean-Server:
#   python -m portfolio_analysis_AI_Agent.tools.composite.eom_options_live
