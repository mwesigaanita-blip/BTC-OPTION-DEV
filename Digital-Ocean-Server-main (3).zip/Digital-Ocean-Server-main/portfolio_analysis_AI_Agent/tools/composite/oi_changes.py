"""Tool: composite.oi_changes

Diffs the latest OI snapshot against a baseline snapshot (default ~24h
prior) and returns where new positions came on and where positions were
unwound. Reads from ``snapshots.sqlite.oi_snapshots`` which is
populated by ``tools.jobs.snapshot_oi``.

If no baseline within the lookback window exists, falls back to the
oldest snapshot available and reports the actual lookback in seconds.

Returns:
  - biggest_additions  (top instruments where OI grew)
  - biggest_reductions (top instruments where OI shrank)
  - by_expiry_delta    (net OI change per expiry)
  - call_vs_put_delta  (directional positioning shift)
  - totals
"""

from __future__ import annotations

import json
import sqlite3
import time
from typing import Any

from shared.db_paths import SNAPSHOTS_DB, get_connection


def _f(x: Any, default: float = 0.0) -> float:
    try:
        return float(x) if x is not None else default
    except (TypeError, ValueError):
        return default


def _pick_snapshot_ts(conn: sqlite3.Connection, currency: str, target_ts: int) -> int | None:
    """Return the snapshot_ts <= target_ts that is closest to it, else None."""
    row = conn.execute(
        "SELECT MAX(snapshot_ts) FROM oi_snapshots WHERE currency=? AND snapshot_ts<=?",
        (currency, target_ts),
    ).fetchone()
    return row[0] if row and row[0] is not None else None


def _load_snapshot(conn: sqlite3.Connection, currency: str, ts: int) -> dict[str, dict]:
    """Returns {instrument_name: {oi, expiry, strike, type}}."""
    cur = conn.execute(
        "SELECT instrument_name, expiry, strike, type, open_interest "
        "FROM oi_snapshots WHERE currency=? AND snapshot_ts=?",
        (currency, ts),
    )
    out: dict[str, dict] = {}
    for r in cur.fetchall():
        out[r["instrument_name"]] = {
            "expiry": r["expiry"],
            "strike": r["strike"],
            "type": r["type"],
            "oi": _f(r["open_interest"]),
        }
    return out


def oi_changes(currency: str = "BTC", lookback_hours: float = 24.0, top_n: int = 10) -> dict:
    """Diff latest OI snapshot vs a baseline ~lookback_hours older."""
    conn = get_connection(SNAPSHOTS_DB)
    try:
        # Check table exists; if not, return a clean "no history" response.
        tbl = conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='oi_snapshots'"
        ).fetchone()
        if not tbl:
            return {"error": "oi_snapshots table missing — run jobs.snapshot_oi first",
                    "currency": currency, "fetched_at": int(time.time())}

        latest_row = conn.execute(
            "SELECT MAX(snapshot_ts) FROM oi_snapshots WHERE currency=?",
            (currency,),
        ).fetchone()
        latest_ts = latest_row[0] if latest_row else None
        if not latest_ts:
            return {"error": "no snapshots found",
                    "currency": currency, "fetched_at": int(time.time())}

        target_baseline = latest_ts - int(lookback_hours * 3600)
        baseline_ts = _pick_snapshot_ts(conn, currency, target_baseline)
        fallback_used = False
        if baseline_ts is None or baseline_ts == latest_ts:
            # No earlier snapshot at requested lookback — try oldest available.
            oldest_row = conn.execute(
                "SELECT MIN(snapshot_ts) FROM oi_snapshots WHERE currency=? AND snapshot_ts<?",
                (currency, latest_ts),
            ).fetchone()
            baseline_ts = oldest_row[0] if oldest_row else None
            fallback_used = True

        if baseline_ts is None:
            return {
                "currency": currency,
                "latest_ts": latest_ts,
                "baseline_ts": None,
                "warning": "only one snapshot available — run snapshot_oi again later to enable diffs",
                "fetched_at": int(time.time()),
            }

        actual_lookback_s = latest_ts - baseline_ts
        latest = _load_snapshot(conn, currency, latest_ts)
        baseline = _load_snapshot(conn, currency, baseline_ts)
    finally:
        conn.close()

    instruments = set(latest) | set(baseline)
    deltas: list[dict] = []
    by_exp: dict[str, float] = {}
    call_d = put_d = 0.0
    new_listings = 0
    delisted = 0

    for name in instruments:
        a = baseline.get(name)
        b = latest.get(name)
        if a is None:
            # newly listed instrument in the latest snapshot
            new_listings += 1
            meta = b
            delta = _f(b.get("oi"))
        elif b is None:
            delisted += 1
            meta = a
            delta = -_f(a.get("oi"))
        else:
            meta = b
            delta = _f(b.get("oi")) - _f(a.get("oi"))

        if abs(delta) < 1e-9:
            continue

        deltas.append({
            "instrument": name,
            "expiry": meta.get("expiry"),
            "strike": meta.get("strike"),
            "type": meta.get("type"),
            "oi_before": _f((a or {}).get("oi")) if a else 0.0,
            "oi_after": _f((b or {}).get("oi")) if b else 0.0,
            "delta": round(delta, 4),
        })
        by_exp[meta.get("expiry") or "?"] = by_exp.get(meta.get("expiry") or "?", 0.0) + delta
        if meta.get("type") == "C":
            call_d += delta
        elif meta.get("type") == "P":
            put_d += delta

    additions = sorted([d for d in deltas if d["delta"] > 0], key=lambda d: -d["delta"])[:top_n]
    reductions = sorted([d for d in deltas if d["delta"] < 0], key=lambda d: d["delta"])[:top_n]

    by_exp_list = [
        {"expiry": e, "oi_delta": round(v, 4)}
        for e, v in sorted(by_exp.items(), key=lambda kv: -abs(kv[1]))
    ]

    total_delta = sum(d["delta"] for d in deltas)
    bias = "call_buildup" if call_d > abs(put_d) * 1.2 else \
           "put_buildup" if put_d > abs(call_d) * 1.2 else "balanced"

    return {
        "currency": currency,
        "latest_ts": latest_ts,
        "baseline_ts": baseline_ts,
        "lookback_seconds": actual_lookback_s,
        "lookback_hours_actual": round(actual_lookback_s / 3600.0, 3),
        "fallback_used": fallback_used,
        "totals": {
            "total_oi_delta": round(total_delta, 4),
            "call_oi_delta": round(call_d, 4),
            "put_oi_delta": round(put_d, 4),
            "directional_bias": bias,
            "new_listings": new_listings,
            "delisted": delisted,
            "instruments_changed": len(deltas),
        },
        "biggest_additions": additions,
        "biggest_reductions": reductions,
        "by_expiry_delta": by_exp_list,
        "fetched_at": int(time.time()),
    }


if __name__ == "__main__":
    out = oi_changes()
    print(json.dumps(out, indent=2, default=str))

# Run from Digital-Ocean-Server:
#   python -m portfolio_analysis_AI_Agent.tools.composite.oi_changes
