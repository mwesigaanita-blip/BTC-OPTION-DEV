"""Tool: composite.open_interest_breakdown

Composite - calls datafetch.market.get_book_summary, then slices OI:
  - by expiry
  - by strike (top-N concentrations a.k.a. "OI walls")
  - by call/put per expiry

Composite tools may import sibling data tools (per the plan).
"""

from __future__ import annotations

import json
import time
from typing import Any

from portfolio_analysis_AI_Agent.tools.datafetch.market.get_book_summary import get_book_summary


def _f(x: Any, default: float = 0.0) -> float:
    try:
        return float(x) if x is not None else default
    except (TypeError, ValueError):
        return default


def _parse_name(name: str) -> tuple[str | None, float | None, str | None]:
    parts = (name or "").split("-")
    if len(parts) < 4:
        return None, None, None
    exp = parts[1]
    try:
        strike = float(parts[2])
    except ValueError:
        strike = None
    typ = "C" if name.endswith("-C") else "P" if name.endswith("-P") else None
    return exp, strike, typ


def open_interest_breakdown(currency: str = "BTC", top_walls: int = 5) -> dict:
    """Returns {by_expiry[], by_strike_walls[], by_expiry_cp{}, totals, fetched_at}."""
    bs = get_book_summary(currency=currency, kind="option")
    rows = bs.get("rows") or []

    by_exp: dict[str, float] = {}
    by_strike: dict[float, float] = {}
    by_exp_cp: dict[str, dict[str, float]] = {}
    total_oi = 0.0

    for r in rows:
        name = str(r.get("instrument_name") or "")
        exp, strike, typ = _parse_name(name)
        if not exp or strike is None or not typ:
            continue
        oi = _f(r.get("open_interest"))
        if oi <= 0:
            continue
        total_oi += oi
        by_exp[exp] = by_exp.get(exp, 0.0) + oi
        by_strike[strike] = by_strike.get(strike, 0.0) + oi
        cp = by_exp_cp.setdefault(exp, {"call": 0.0, "put": 0.0})
        cp["call" if typ == "C" else "put"] += oi

    by_expiry_list = [
        {"expiry": e, "open_interest": v, "share_pct": round(v / total_oi * 100, 4) if total_oi else 0.0}
        for e, v in sorted(by_exp.items(), key=lambda kv: -kv[1])
    ]
    walls = [
        {"strike": k, "open_interest": v, "share_pct": round(v / total_oi * 100, 4) if total_oi else 0.0}
        for k, v in sorted(by_strike.items(), key=lambda kv: -kv[1])[:top_walls]
    ]
    by_exp_cp_list = [
        {"expiry": e,
         "call_oi": v["call"],
         "put_oi": v["put"],
         "bias": "call_heavy" if v["call"] > v["put"] * 1.2 else "put_heavy" if v["put"] > v["call"] * 1.2 else "balanced"}
        for e, v in sorted(by_exp_cp.items())
    ]

    return {
        "currency": currency,
        "totals": {
            "total_oi": total_oi,
            "row_count": len(rows),
            "expiry_count": len(by_exp),
            "strike_count": len(by_strike),
        },
        "by_expiry": by_expiry_list,
        "by_strike_walls_top": walls,
        "by_expiry_call_put": by_exp_cp_list,
        "fetched_at": int(time.time()),
    }


if __name__ == "__main__":
    out = open_interest_breakdown()
    # Trim long lists
    print(json.dumps({
        **out,
        "by_expiry": out["by_expiry"][:5],
        "by_expiry_call_put": out["by_expiry_call_put"][:5],
    }, indent=2, default=str))

# Run from Digital-Ocean-Server:
#   python -m portfolio_analysis_AI_Agent.tools.composite.open_interest_breakdown
