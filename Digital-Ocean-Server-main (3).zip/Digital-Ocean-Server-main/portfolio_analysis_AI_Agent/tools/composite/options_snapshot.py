"""Tool: composite.options_snapshot

Composite - builds the LLM-grounding BTC options snapshot per
Implementation_Plan.md §"Options Market Snapshot":
  - 5 next end-of-month (EOM) expiries (configurable)
  - skip dailies/weeklies (settlement_period != 'month' implies non-monthly)
  - full strike chain per expiry from book_summary (calls + puts)
  - per-expiry aggregates: total OI, total 24h volume, ATM IV, P/C ratio
  - expiry-independent fields: spot, DVOL, perp funding, vol regime label
"""

from __future__ import annotations

import json
import time
from typing import Any

from portfolio_analysis_AI_Agent.tools.datafetch.market.get_instruments import get_instruments
from portfolio_analysis_AI_Agent.tools.datafetch.market.get_book_summary import get_book_summary
from portfolio_analysis_AI_Agent.tools.datafetch.market.get_index_price import get_index_price
from portfolio_analysis_AI_Agent.tools.datafetch.market.get_dvol import get_dvol
from portfolio_analysis_AI_Agent.tools.datafetch.market.get_funding_rate import get_funding_rate
from portfolio_analysis_AI_Agent.tools.datafetch.market.get_historical_volatility import get_historical_volatility
from portfolio_analysis_AI_Agent.tools.analysis.volatility_compute import volatility_compute


def _f(x: Any, default: float = 0.0) -> float:
    try:
        return float(x) if x is not None else default
    except (TypeError, ValueError):
        return default


def _select_eom_expiries(instruments: list[dict], n: int = 5) -> list[int]:
    """Return ascending list of `n` EOM expiry timestamps (ms)."""
    monthly_ts = sorted({
        int(i.get("expiration_timestamp") or 0)
        for i in instruments
        if str(i.get("settlement_period") or "").lower() == "month"
    })
    now_ms = int(time.time() * 1000)
    future = [t for t in monthly_ts if t > now_ms]
    return future[:n]


def options_snapshot(currency: str = "BTC", n_expiries: int = 5) -> dict:
    """Returns the structured EOM snapshot for LLM grounding."""
    insts = get_instruments(currency=currency, kind="option")
    expiry_ms = _select_eom_expiries(insts.get("instruments") or [], n=n_expiries)
    expiry_names_by_ts: dict[int, str] = {}
    for i in insts.get("instruments") or []:
        ts = int(i.get("expiration_timestamp") or 0)
        if ts in expiry_ms:
            # The Deribit expiry-label is the YYMMDD-ish part of the name.
            name_parts = str(i.get("instrument_name") or "").split("-")
            if len(name_parts) >= 2:
                expiry_names_by_ts[ts] = name_parts[1]

    bs = get_book_summary(currency=currency, kind="option")
    rows = bs.get("rows") or []

    spot = _f(get_index_price(f"{currency.lower()}_usd").get("index_price"))

    per_expiry: dict[int, dict] = {ts: {"label": expiry_names_by_ts.get(ts), "strikes": []} for ts in expiry_ms}
    label_to_ts = {v: k for k, v in expiry_names_by_ts.items()}

    for row in rows:
        name = str(row.get("instrument_name") or "")
        parts = name.split("-")
        if len(parts) < 4:
            continue
        exp_label = parts[1]
        ts = label_to_ts.get(exp_label)
        if ts is None:
            continue
        try:
            strike = float(parts[2])
        except ValueError:
            continue
        opt_type = "C" if name.endswith("-C") else "P" if name.endswith("-P") else None
        if not opt_type:
            continue
        per_expiry[ts]["strikes"].append({
            "instrument_name": name,
            "strike": strike,
            "type": opt_type,
            "mark_price": _f(row.get("mark_price")),
            "mark_iv": _f(row.get("mark_iv")),
            "bid": _f(row.get("bid_price")),
            "ask": _f(row.get("ask_price")),
            "open_interest": _f(row.get("open_interest")),
            "volume_24h": _f(row.get("volume")),
        })

    # Per-expiry aggregates
    expiries_out = []
    for ts, payload in per_expiry.items():
        rows_e = payload["strikes"]
        if not rows_e:
            continue
        total_oi = sum(r["open_interest"] for r in rows_e)
        total_vol = sum(r["volume_24h"] for r in rows_e)
        call_oi = sum(r["open_interest"] for r in rows_e if r["type"] == "C")
        put_oi = sum(r["open_interest"] for r in rows_e if r["type"] == "P")

        atm_iv = None
        if spot > 0 and rows_e:
            nearest = min(rows_e, key=lambda r: abs(r["strike"] - spot))
            atm_iv = nearest.get("mark_iv")

        expiries_out.append({
            "expiry_label": payload["label"],
            "expiration_ts_ms": ts,
            "strike_count": len(rows_e),
            "total_oi": total_oi,
            "total_volume_24h": total_vol,
            "atm_iv": atm_iv,
            "call_oi": call_oi,
            "put_oi": put_oi,
            "pcr_oi": round(put_oi / call_oi, 4) if call_oi > 0 else None,
            "strikes": sorted(rows_e, key=lambda r: (r["strike"], r["type"])),
        })

    expiries_out.sort(key=lambda e: e["expiration_ts_ms"])

    # Expiry-independent macro fields
    funding = get_funding_rate(currency=currency)
    dvol = get_dvol(currency=currency)
    hv = get_historical_volatility(currency=currency)
    vol = volatility_compute(hv, dvol)

    return {
        "currency": currency,
        "spot_index_price": spot,
        "dvol_close": dvol.get("latest_close"),
        "vol_regime": vol.get("regime"),
        "iv_richness": vol.get("richness"),
        "perp_funding_current": funding.get("current"),
        "perp_funding_bias": funding.get("bias"),
        "expiries": expiries_out,
        "selected_count": len(expiries_out),
        "fetched_at": int(time.time()),
    }


if __name__ == "__main__":
    out = options_snapshot(n_expiries=5)
    # Trim per-expiry strikes for readable smoke output
    trimmed = {
        **out,
        "expiries": [
            {**e, "strikes": e["strikes"][:3], "strikes_shown": 3}
            for e in out["expiries"]
        ],
    }
    print(json.dumps(trimmed, indent=2, default=str))

# Run from Digital-Ocean-Server:
#   python -m portfolio_analysis_AI_Agent.tools.composite.options_snapshot
