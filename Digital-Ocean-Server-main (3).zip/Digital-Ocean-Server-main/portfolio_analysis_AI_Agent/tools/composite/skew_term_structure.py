"""Tool: composite.skew_term_structure

Builds the IV skew + term-structure surface from a single
`get_book_summary` call. Per expiry:
  - ATM IV  (mid of nearest call+put to spot)
  - 25-delta-proxy call IV and put IV, using vol-scaled moneyness
    K_25d = S * exp(+/- 0.25 * sigma_atm * sqrt(T))
    (Brenner-Subrahmanyam style approx; avoids per-instrument greeks
    calls. The 0.25 here is delta, not a fixed %.)
  - skew_25d = IV(put_25d) - IV(call_25d)  (positive => fear)
  - risk_reversal_25d = IV(call_25d) - IV(put_25d)  (negative => fear)

Term-structure summary:
  - front_atm_iv / back_atm_iv
  - slope_per_day  (IV pts per day-to-expiry)
  - shape: "contango" | "backwardation" | "flat"

Pure Python, no scipy. One network call.
"""

from __future__ import annotations

import json
import math
import time
from datetime import datetime, timezone
from typing import Any

from portfolio_analysis_AI_Agent.tools.datafetch.market.get_book_summary import get_book_summary
from portfolio_analysis_AI_Agent.tools.datafetch.market.get_index_price import get_index_price


_MONTHS = {"JAN": 1, "FEB": 2, "MAR": 3, "APR": 4, "MAY": 5, "JUN": 6,
           "JUL": 7, "AUG": 8, "SEP": 9, "OCT": 10, "NOV": 11, "DEC": 12}


def _f(x: Any, default: float = 0.0) -> float:
    try:
        return float(x) if x is not None else default
    except (TypeError, ValueError):
        return default


def _parse_name(name: str) -> tuple[str | None, float | None, str | None]:
    parts = (name or "").split("-")
    if len(parts) < 4:
        return None, None, None
    try:
        return parts[1], float(parts[2]), ("C" if name.endswith("-C") else "P" if name.endswith("-P") else None)
    except ValueError:
        return parts[1], None, None


def _expiry_to_days(exp: str, now: datetime) -> float | None:
    """Parse Deribit expiry token like '27JUN25' -> days from `now` (UTC, 08:00 settle)."""
    if not exp or len(exp) < 6:
        return None
    try:
        if len(exp) == 6:      # e.g. 5JUN25
            d = int(exp[0:1]); mon = exp[1:4]; y = int(exp[4:6])
        else:                  # e.g. 27JUN25
            d = int(exp[0:2]); mon = exp[2:5]; y = int(exp[5:7])
        m = _MONTHS.get(mon.upper())
        if not m:
            return None
        dt = datetime(2000 + y, m, d, 8, 0, 0, tzinfo=timezone.utc)
        return max((dt - now).total_seconds() / 86400.0, 0.0)
    except (ValueError, IndexError):
        return None


def _nearest(rows: list[dict], target_strike: float) -> dict | None:
    """Return row whose strike is closest to target, ignoring rows with no mark_iv."""
    best = None
    best_d = float("inf")
    for r in rows:
        k = r.get("_strike")
        iv = r.get("mark_iv")
        if k is None or iv is None:
            continue
        d = abs(k - target_strike)
        if d < best_d:
            best_d, best = d, r
    return best


def _shape(slope_per_day: float | None) -> str:
    if slope_per_day is None:
        return "UNKNOWN"
    if slope_per_day > 0.01:   # ~+1 IV pt per 100 days = contango
        return "CONTANGO"
    if slope_per_day < -0.01:
        return "BACKWARDATION"
    return "FLAT"


def skew_term_structure(currency: str = "BTC", min_dte: float = 0.5) -> dict:
    """Returns per-expiry skew + term-structure summary."""
    bs = get_book_summary(currency=currency, kind="option")
    rows = bs.get("rows") or []

    spot_info = get_index_price(f"{currency.lower()}_usd")
    spot = _f(spot_info.get("index_price"))
    if spot <= 0:
        return {"error": "no_spot_price", "currency": currency, "fetched_at": int(time.time())}

    now = datetime.now(timezone.utc)
    by_exp: dict[str, dict] = {}
    for r in rows:
        name = str(r.get("instrument_name") or "")
        exp, strike, typ = _parse_name(name)
        if not exp or strike is None or typ not in ("C", "P"):
            continue
        bucket = by_exp.setdefault(exp, {"calls": [], "puts": []})
        enriched = {**r, "_strike": strike, "_type": typ}
        (bucket["calls"] if typ == "C" else bucket["puts"]).append(enriched)

    out_expiries: list[dict] = []
    for exp, bucket in by_exp.items():
        dte = _expiry_to_days(exp, now)
        if dte is None or dte < min_dte:
            continue
        T = dte / 365.0

        atm_call = _nearest(bucket["calls"], spot)
        atm_put = _nearest(bucket["puts"], spot)
        if not atm_call and not atm_put:
            continue
        ivs_atm = [_f(x.get("mark_iv")) for x in (atm_call, atm_put) if x and x.get("mark_iv") is not None]
        atm_iv = sum(ivs_atm) / len(ivs_atm) if ivs_atm else None
        if not atm_iv:
            continue

        # mark_iv is in vol *points* (e.g. 55 -> 55%). Convert to decimal for the moneyness scaling.
        sigma = atm_iv / 100.0
        shift = 0.25 * sigma * math.sqrt(T) if T > 0 else 0.0
        k_call_25d = spot * math.exp(+shift)
        k_put_25d = spot * math.exp(-shift)

        c25 = _nearest(bucket["calls"], k_call_25d)
        p25 = _nearest(bucket["puts"], k_put_25d)
        iv_c25 = _f(c25.get("mark_iv")) if c25 else None
        iv_p25 = _f(p25.get("mark_iv")) if p25 else None

        skew_25d = (iv_p25 - iv_c25) if (iv_p25 and iv_c25) else None
        rr_25d = (iv_c25 - iv_p25) if (iv_p25 and iv_c25) else None

        out_expiries.append({
            "expiry": exp,
            "dte": round(dte, 3),
            "atm_iv": round(atm_iv, 4),
            "atm_call_strike": atm_call.get("_strike") if atm_call else None,
            "atm_put_strike": atm_put.get("_strike") if atm_put else None,
            "call_25d": {
                "target_strike": round(k_call_25d, 2),
                "picked_strike": c25.get("_strike") if c25 else None,
                "iv": round(iv_c25, 4) if iv_c25 else None,
            },
            "put_25d": {
                "target_strike": round(k_put_25d, 2),
                "picked_strike": p25.get("_strike") if p25 else None,
                "iv": round(iv_p25, 4) if iv_p25 else None,
            },
            "skew_25d": round(skew_25d, 4) if skew_25d is not None else None,
            "risk_reversal_25d": round(rr_25d, 4) if rr_25d is not None else None,
            "skew_label": (
                "FEAR" if skew_25d is not None and skew_25d > 3 else
                "GREED" if skew_25d is not None and skew_25d < -3 else
                "NEUTRAL" if skew_25d is not None else "UNKNOWN"
            ),
        })

    out_expiries.sort(key=lambda x: x["dte"])

    term: dict[str, Any] = {"shape": "UNKNOWN"}
    if len(out_expiries) >= 2:
        front, back = out_expiries[0], out_expiries[-1]
        d_dte = back["dte"] - front["dte"]
        d_iv = back["atm_iv"] - front["atm_iv"]
        slope = (d_iv / d_dte) if d_dte > 0 else None
        term = {
            "front_expiry": front["expiry"], "front_dte": front["dte"], "front_atm_iv": front["atm_iv"],
            "back_expiry": back["expiry"], "back_dte": back["dte"], "back_atm_iv": back["atm_iv"],
            "slope_per_day": round(slope, 5) if slope is not None else None,
            "shape": _shape(slope),
        }

    front_skew = out_expiries[0]["skew_25d"] if out_expiries else None
    summary = {
        "currency": currency,
        "spot": spot,
        "expiry_count": len(out_expiries),
        "front_skew_25d": front_skew,
        "front_skew_label": out_expiries[0]["skew_label"] if out_expiries else "UNKNOWN",
        "term_structure": term,
    }

    return {
        **summary,
        "expiries": out_expiries,
        "fetched_at": int(time.time()),
    }


if __name__ == "__main__":
    out = skew_term_structure()
    trimmed = {**out, "expiries": out.get("expiries", [])[:6]}
    print(json.dumps(trimmed, indent=2, default=str))

# Run from Digital-Ocean-Server:
#   python -m portfolio_analysis_AI_Agent.tools.composite.skew_term_structure
