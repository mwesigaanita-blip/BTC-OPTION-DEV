"""Tool: composite.trade_activity_24h

Composite - walks the top-N most-active option instruments (by 24h
volume from book_summary), pulls recent trades for each, and aggregates:

  - volume by expiry
  - volume by OTM/ATM/ITM moneyness bucket
  - aggressor buy vs sell split (contracts AND USD premium)
  - **signed premium / delta / vega flow** — uses approx BS greeks
    computed locally from the row's `mark_iv` (no per-instrument
    ticker calls). Sign = +amount on aggressor buys, -amount on sells.
  - block-trade and liquidation trade isolation
  - top-10 prints by USD notional

Full-coverage caching is a Phase-5 worker concern; this is a snapshot.
"""

from __future__ import annotations

import json
import math
import time
from datetime import datetime, timezone
from typing import Any

from portfolio_analysis_AI_Agent.tools.datafetch.market.get_book_summary import get_book_summary
from portfolio_analysis_AI_Agent.tools.datafetch.market.get_last_trades import get_last_trades
from portfolio_analysis_AI_Agent.tools.datafetch.market.get_index_price import get_index_price


_MONTHS = {"JAN": 1, "FEB": 2, "MAR": 3, "APR": 4, "MAY": 5, "JUN": 6,
           "JUL": 7, "AUG": 8, "SEP": 9, "OCT": 10, "NOV": 11, "DEC": 12}


def _f(x: Any, default: float = 0.0) -> float:
    try:
        return float(x) if x is not None else default
    except (TypeError, ValueError):
        return default


def _parse_name(name: str) -> tuple[str | None, float | None, str | None]:
    parts = (name or "").split("-")
    if len(parts) < 4:
        return None, None, None
    try:
        return parts[1], float(parts[2]), ("C" if name.endswith("-C") else "P" if name.endswith("-P") else None)
    except ValueError:
        return parts[1], None, None


def _expiry_to_years(exp: str, now: datetime) -> float | None:
    if not exp or len(exp) < 6:
        return None
    try:
        if len(exp) == 6:
            d = int(exp[0:1]); mon = exp[1:4]; y = int(exp[4:6])
        else:
            d = int(exp[0:2]); mon = exp[2:5]; y = int(exp[5:7])
        m = _MONTHS.get(mon.upper())
        if not m:
            return None
        dt = datetime(2000 + y, m, d, 8, 0, 0, tzinfo=timezone.utc)
        years = (dt - now).total_seconds() / (86400.0 * 365.0)
        return max(years, 1e-6)
    except (ValueError, IndexError):
        return None


def _norm_cdf(x: float) -> float:
    return 0.5 * (1.0 + math.erf(x / math.sqrt(2.0)))


def _norm_pdf(x: float) -> float:
    return math.exp(-0.5 * x * x) / math.sqrt(2.0 * math.pi)


def _bs_greeks(spot: float, strike: float, T: float, iv_pct: float, typ: str) -> tuple[float, float]:
    """Returns (delta, vega_per_vol_point). r=0, dividend=0 (standard Deribit conv)."""
    if spot <= 0 or strike <= 0 or T <= 0 or iv_pct <= 0:
        return 0.0, 0.0
    sigma = iv_pct / 100.0
    d1 = (math.log(spot / strike) + 0.5 * sigma * sigma * T) / (sigma * math.sqrt(T))
    delta = _norm_cdf(d1) if typ == "C" else _norm_cdf(d1) - 1.0
    vega_per_unit = spot * math.sqrt(T) * _norm_pdf(d1)  # per 1.0 change in sigma
    return delta, vega_per_unit / 100.0  # per 1 IV point


def _bucket_for(strike: float, spot: float, typ: str) -> str:
    if spot <= 0:
        return "?"
    diff_pct = (strike - spot) / spot * 100.0
    if abs(diff_pct) <= 5.0:
        return "ATM"
    if typ == "C":
        return "OTM" if diff_pct > 0 else "ITM"
    return "OTM" if diff_pct < 0 else "ITM"


def trade_activity_24h(currency: str = "BTC", top_instruments: int = 15, trades_per_inst: int = 50) -> dict:
    bs = get_book_summary(currency=currency, kind="option")
    rows = bs.get("rows") or []
    rows.sort(key=lambda r: _f(r.get("volume")), reverse=True)
    active = [r for r in rows if _f(r.get("volume")) > 0][:top_instruments]

    spot_info = get_index_price(f"{currency.lower()}_usd")
    spot = _f(spot_info.get("index_price"))
    now = datetime.now(timezone.utc)
    cutoff_ms = int((time.time() - 24 * 3600) * 1000)

    vol_by_expiry: dict[str, float] = {}
    vol_by_bucket: dict[str, float] = {"OTM": 0.0, "ATM": 0.0, "ITM": 0.0}
    buy_amt = sell_amt = 0.0
    buy_prem_usd = sell_prem_usd = 0.0
    net_delta = 0.0  # signed by aggressor
    net_vega = 0.0
    cp_split = {"C": {"buy": 0.0, "sell": 0.0}, "P": {"buy": 0.0, "sell": 0.0}}
    block_prints: list[dict] = []
    liquidation_prints: list[dict] = []
    all_prints: list[dict] = []
    fetched_instruments = 0

    for r in active:
        name = str(r.get("instrument_name") or "")
        exp, strike, typ = _parse_name(name)
        if not exp or strike is None or not typ:
            continue
        T = _expiry_to_years(exp, now)
        if T is None:
            continue
        row_iv = _f(r.get("mark_iv"))
        fetched_instruments += 1
        try:
            tr = get_last_trades(name, count=trades_per_inst)
        except Exception:
            continue

        for t in tr.get("trades", []):
            ts_ms = int(t.get("ts_ms") or 0)
            if ts_ms and ts_ms < cutoff_ms:
                continue
            amt = _f(t.get("amount"))
            price_btc = _f(t.get("price"))
            side = str(t.get("direction") or "")
            iv_pct = _f(t.get("iv")) or row_iv  # trade IV preferred, fall back to row mark_iv
            delta, vega = _bs_greeks(spot, strike, T, iv_pct, typ)

            premium_usd = amt * price_btc * spot if spot else 0.0
            sign = +1.0 if side == "buy" else (-1.0 if side == "sell" else 0.0)

            vol_by_expiry[exp] = vol_by_expiry.get(exp, 0.0) + amt
            b = _bucket_for(strike, spot, typ)
            vol_by_bucket[b] = vol_by_bucket.get(b, 0.0) + amt

            if side == "buy":
                buy_amt += amt
                buy_prem_usd += premium_usd
                cp_split[typ]["buy"] += amt
            elif side == "sell":
                sell_amt += amt
                sell_prem_usd += premium_usd
                cp_split[typ]["sell"] += amt

            net_delta += sign * amt * delta
            net_vega += sign * amt * vega

            print_row = {
                "instrument": name,
                "ts_ms": ts_ms,
                "price_btc": price_btc,
                "amount": amt,
                "premium_usd": round(premium_usd, 2) if premium_usd else None,
                "notional_usd": amt * spot if spot else None,
                "direction": side,
                "iv": t.get("iv"),
                "delta": round(delta, 4),
                "vega_per_ivpt": round(vega, 4),
                "block_trade_id": t.get("block_trade_id"),
                "combo_id": t.get("combo_id"),
                "liquidation": t.get("liquidation"),
            }
            all_prints.append(print_row)
            if t.get("block_trade_id"):
                block_prints.append(print_row)
            if t.get("liquidation"):
                liquidation_prints.append(print_row)

    all_prints.sort(key=lambda p: (p.get("premium_usd") or p.get("notional_usd") or 0), reverse=True)
    total_amt = buy_amt + sell_amt
    total_prem = buy_prem_usd + sell_prem_usd
    aggressor_buy_pct = round(buy_amt / total_amt * 100, 4) if total_amt else None
    premium_buy_pct = round(buy_prem_usd / total_prem * 100, 4) if total_prem else None
    net_premium_usd = buy_prem_usd - sell_prem_usd

    # flow_imbalance in [-1, +1]: net premium / total premium
    flow_imbalance = (net_premium_usd / total_prem) if total_prem > 0 else 0.0

    return {
        "currency": currency,
        "btc_spot": spot,
        "instruments_fetched": fetched_instruments,
        "volume_by_expiry": [
            {"expiry": e, "volume": v}
            for e, v in sorted(vol_by_expiry.items(), key=lambda kv: -kv[1])
        ],
        "volume_by_moneyness": vol_by_bucket,
        "aggressor": {
            "buy_amount": buy_amt,
            "sell_amount": sell_amt,
            "buy_pct": aggressor_buy_pct,
            "buy_premium_usd": round(buy_prem_usd, 2),
            "sell_premium_usd": round(sell_prem_usd, 2),
            "premium_buy_pct": premium_buy_pct,
            "net_premium_usd": round(net_premium_usd, 2),
            "flow_imbalance": round(flow_imbalance, 4),
        },
        "call_put_aggressor": {
            "call_buy": cp_split["C"]["buy"], "call_sell": cp_split["C"]["sell"],
            "put_buy": cp_split["P"]["buy"], "put_sell": cp_split["P"]["sell"],
        },
        "flow_greeks": {
            "net_delta": round(net_delta, 4),
            "net_vega_per_ivpt": round(net_vega, 4),
        },
        "block_trades": {
            "count": len(block_prints),
            "buy_premium_usd": round(sum(p["premium_usd"] or 0 for p in block_prints if p.get("direction") == "buy"), 2),
            "sell_premium_usd": round(sum(p["premium_usd"] or 0 for p in block_prints if p.get("direction") == "sell"), 2),
            "top": sorted(block_prints, key=lambda p: -(p.get("premium_usd") or 0))[:5],
        },
        "liquidation_trades": {
            "count": len(liquidation_prints),
            "top": liquidation_prints[:5],
        },
        "top_prints": all_prints[:10],
        "fetched_at": int(time.time()),
    }


if __name__ == "__main__":
    out = trade_activity_24h(top_instruments=8, trades_per_inst=20)
    print(json.dumps(out, indent=2, default=str))

# Run from Digital-Ocean-Server:
#   python -m portfolio_analysis_AI_Agent.tools.composite.trade_activity_24h
