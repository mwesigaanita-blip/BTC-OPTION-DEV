"""Tool: composite.correlation_matrix

Read close-price series from SQLite for a set of assets, compute daily
% returns, and build the Pearson correlation matrix over one or more
calendar-day windows. Default windows are 1-month and 3-month (matching
the Hedgeye macro-crypto sheet).

Output dict::

    {
      assets: [...],
      windows: [{label, window_days, asof, matrix, sample_counts}, ...],
      fetched_at: int,
    }
"""
from __future__ import annotations

import json
import time
from typing import Iterable

from portfolio_analysis_AI_Agent.tools.analysis.compute_correlation_matrix import (
    compute_correlation_matrix,
)
from portfolio_analysis_AI_Agent.tools.datafetch.market.get_quant_close_series import (
    get_quant_close_series,
)


# Order matches the Hedgeye sheet: macro/crypto interleaved.
DEFAULT_ASSETS: list[str] = [
    "BTC", "SPX", "VIX", "DXY", "GOLD", "TIPS", "ETH", "SOL", "AVAX", "DOGE",
]

# label -> calendar-day lookback
DEFAULT_WINDOWS: list[tuple[str, int]] = [
    ("1M", 30),
    ("3M", 91),
]


def correlation_matrix(
    assets: Iterable[str] | None = None,
    windows: Iterable[tuple[str, int]] | None = None,
) -> dict:
    asset_list = [a.strip().upper() for a in (assets or DEFAULT_ASSETS) if a and a.strip()]
    window_list = list(windows or DEFAULT_WINDOWS)

    series_by_asset: dict[str, list[dict]] = {}
    for a in asset_list:
        series = get_quant_close_series(a)
        series_by_asset[a] = series["rows"]

    out_windows: list[dict] = []
    for label, days in window_list:
        result = compute_correlation_matrix(series_by_asset, window_days=int(days))
        out_windows.append({"label": label, **result})

    return {
        "assets": asset_list,
        "windows": out_windows,
        "fetched_at": int(time.time()),
    }


if __name__ == "__main__":
    out = correlation_matrix()
    # Trim the dump so the standalone output stays readable.
    summary = {
        "assets": out["assets"],
        "windows": [
            {
                "label": w["label"],
                "window_days": w["window_days"],
                "asof": w["asof"],
                "sample_size_BTC_SPX": w["sample_counts"]["BTC"].get("SPX"),
                "btc_correlations": {k: v for k, v in w["matrix"]["BTC"].items() if k != "BTC"},
            }
            for w in out["windows"]
        ],
    }
    print(json.dumps(summary, indent=2, default=str))

# Run from Digital-Ocean-Server:
#   python -m portfolio_analysis_AI_Agent.tools.composite.correlation_matrix
