"""Tool: composite.crypto_volume_panel

Build the Hedgeye-style VOLUME table: for each crypto asset, return
coin-volume and USD-volume metrics (D/D, vs 1M Avg, vs 3M Avg, Y/Y
Qtrly) suitable for the React grid.

Default asset list matches the Hedgeye sheet (BTC + four alts that
trade on Binance with reliable daily volume).

Output dict::

    {
      assets: ["BTC", "ETH", "SOL", "AVAX", "XRP"],
      metrics: ["dd_pct", "vs_1m_pct", "vs_3m_pct", "yy_qtrly_pct"],
      rows: {
        BTC: {
          asof: "...",
          coin: {dd_pct, vs_1m_pct, vs_3m_pct, yy_qtrly_pct},
          usd:  {...},
          coin_today, usd_today,
        },
        ...
      },
      asof: "..." (max across assets),
      fetched_at: int,
    }
"""
from __future__ import annotations

import json
import time
from typing import Iterable

from portfolio_analysis_AI_Agent.tools.analysis.compute_volume_metrics import (
    compute_volume_metrics,
)
from portfolio_analysis_AI_Agent.tools.datafetch.market.get_quant_ohlcv_series import (
    get_quant_ohlcv_series,
)


DEFAULT_ASSETS: list[str] = ["BTC", "ETH", "SOL", "AVAX", "XRP"]

METRIC_KEYS: list[str] = ["dd_pct", "vs_1m_pct", "vs_3m_pct", "yy_qtrly_pct"]


def crypto_volume_panel(assets: Iterable[str] | None = None) -> dict:
    asset_list = [a.strip().upper() for a in (assets or DEFAULT_ASSETS) if a and a.strip()]

    rows: dict[str, dict] = {}
    latest_asof: str | None = None
    for a in asset_list:
        try:
            series = get_quant_ohlcv_series(a)
        except ValueError:
            rows[a] = {"error": f"no volume series for {a}"}
            continue
        m = compute_volume_metrics(series["rows"])
        rows[a] = m
        if m.get("asof") and (latest_asof is None or m["asof"] > latest_asof):
            latest_asof = m["asof"]

    return {
        "assets": asset_list,
        "metrics": METRIC_KEYS,
        "rows": rows,
        "asof": latest_asof,
        "fetched_at": int(time.time()),
    }


if __name__ == "__main__":
    out = crypto_volume_panel()
    print(json.dumps(out, indent=2, default=str))

# Run from Digital-Ocean-Server:
#   python -m portfolio_analysis_AI_Agent.tools.composite.crypto_volume_panel
