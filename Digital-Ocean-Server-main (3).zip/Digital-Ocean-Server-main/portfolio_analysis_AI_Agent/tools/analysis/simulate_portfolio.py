"""Tool: analysis.simulate_portfolio

Calls Deribit `private/simulate_portfolio` to reprice the portfolio with
a user-supplied set of hypothetical positions added or substituted.

Deribit's PME does NOT support synthetic BTC/IV price shocks - those are
done client-side (Black-Scholes reprice) in `analysis.stress_scenarios`.
This tool answers "what if I added/changed these positions?" questions
against the current market state.
"""

from __future__ import annotations

import json
import time
from typing import Optional

import requests

from portfolio_analysis_AI_Agent.tools._auth import get_access_token, rpc_url


def simulate_portfolio(
    simulated_positions: Optional[dict[str, float]] = None,
    currency: str = "BTC",
    add_positions: bool = True,
) -> dict:
    """Reprice the portfolio under a hypothetical position set.

    Args:
        simulated_positions: {instrument_name: signed_qty}. Empty/None reprices
            the current portfolio as-is (sanity check).
        currency: account currency.
        add_positions: True = treat simulated_positions as additions on top of
            existing book; False = replace book entirely.

    Returns scenario echo + key portfolio metrics + raw response.
    """
    sim = dict(simulated_positions or {})
    payload = {
        "jsonrpc": "2.0",
        "id": 1,
        "method": "private/simulate_portfolio",
        "params": {
            "currency": currency,
            "add_positions": bool(add_positions),
            "simulated_positions": sim,
        },
    }
    headers = {"Authorization": f"Bearer {get_access_token()}"}
    r = requests.post(rpc_url(), json=payload, headers=headers, timeout=20)
    body = r.json()
    if body.get("error"):
        raise RuntimeError(f"Deribit error: {body['error']}")
    res = body.get("result") or {}

    return {
        "scenario": {
            "simulated_positions": sim,
            "add_positions": bool(add_positions),
            "currency": currency,
        },
        "equity": res.get("equity"),
        "balance": res.get("balance"),
        "available_funds": res.get("available_funds"),
        "initial_margin": res.get("initial_margin"),
        "maintenance_margin": res.get("maintenance_margin"),
        "margin_balance": res.get("margin_balance"),
        "delta_total": res.get("delta_total"),
        "options_pl": res.get("options_pl"),
        "futures_pl": res.get("futures_pl"),
        "total_pl": res.get("total_pl"),
        "projected_initial_margin": res.get("projected_initial_margin"),
        "projected_maintenance_margin": res.get("projected_maintenance_margin"),
        "raw": res,
        "fetched_at": int(time.time()),
    }


if __name__ == "__main__":
    # Baseline reprice (no simulated positions) - sanity check.
    base = simulate_portfolio()
    print("=== Baseline (no simulated positions) ===")
    print(json.dumps({k: v for k, v in base.items() if k != "raw"}, indent=2, default=str))

    # Example what-if: add 1 BTC-PERPETUAL contract short.
    whatif = simulate_portfolio(simulated_positions={"BTC-PERPETUAL": -1.0})
    print("\n=== What-if: short 1 BTC-PERPETUAL ===")
    print(json.dumps({k: v for k, v in whatif.items() if k != "raw"}, indent=2, default=str))

# Run from Digital-Ocean-Server:
#   python -m portfolio_analysis_AI_Agent.tools.analysis.simulate_portfolio
