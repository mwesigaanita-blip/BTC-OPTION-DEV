"""Tool: analysis.put_call_ratio

Pure-math. Consumes the output of datafetch.market.get_book_summary (option
rows) and returns put/call ratios by volume (24h) and by open interest,
plus per-expiry breakdown.

Instrument name suffix convention: '-C' for calls, '-P' for puts.
"""

from __future__ import annotations

import json
import time
from typing import Any


def _f(x: Any, default: float = 0.0) -> float:
    try:
        return float(x) if x is not None else default
    except (TypeError, ValueError):
        return default


def _expiry_from_name(name: str) -> str:
    # BTC-12MAY26-71000-C → 12MAY26
    parts = (name or "").split("-")
    return parts[1] if len(parts) >= 4 else "unknown"


def put_call_ratio(book_summary: dict) -> dict:
    """Returns aggregate + per-expiry PCRs."""
    rows = (book_summary or {}).get("rows") or []

    call_vol = put_vol = 0.0
    call_oi = put_oi = 0.0
    per_exp: dict[str, dict[str, float]] = {}

    for row in rows:
        name = str(row.get("instrument_name") or "")
        if not name:
            continue
        is_call = name.endswith("-C")
        is_put = name.endswith("-P")
        if not (is_call or is_put):
            continue

        vol = _f(row.get("volume"))
        oi = _f(row.get("open_interest"))
        exp = _expiry_from_name(name)
        bucket = per_exp.setdefault(exp, {"call_vol": 0.0, "put_vol": 0.0, "call_oi": 0.0, "put_oi": 0.0})

        if is_call:
            call_vol += vol
            call_oi += oi
            bucket["call_vol"] += vol
            bucket["call_oi"] += oi
        else:
            put_vol += vol
            put_oi += oi
            bucket["put_vol"] += vol
            bucket["put_oi"] += oi

    def _safe_ratio(num: float, den: float) -> float | None:
        return round(num / den, 4) if den > 0 else None

    by_expiry = []
    for exp, b in sorted(per_exp.items()):
        by_expiry.append({
            "expiry": exp,
            "pcr_volume": _safe_ratio(b["put_vol"], b["call_vol"]),
            "pcr_oi": _safe_ratio(b["put_oi"], b["call_oi"]),
            "call_vol": b["call_vol"],
            "put_vol": b["put_vol"],
            "call_oi": b["call_oi"],
            "put_oi": b["put_oi"],
        })

    return {
        "pcr_volume_24h": _safe_ratio(put_vol, call_vol),
        "pcr_open_interest": _safe_ratio(put_oi, call_oi),
        "totals": {
            "call_vol": call_vol,
            "put_vol": put_vol,
            "call_oi": call_oi,
            "put_oi": put_oi,
        },
        "by_expiry": by_expiry,
        "sample_count": len(rows),
        "computed_at": int(time.time()),
    }


if __name__ == "__main__":
    sample = {"rows": [
        {"instrument_name": "BTC-12MAY26-70000-C", "volume": 2.0, "open_interest": 50.0},
        {"instrument_name": "BTC-12MAY26-70000-P", "volume": 3.0, "open_interest": 80.0},
        {"instrument_name": "BTC-30MAY26-80000-C", "volume": 5.0, "open_interest": 200.0},
        {"instrument_name": "BTC-30MAY26-80000-P", "volume": 4.0, "open_interest": 220.0},
    ]}
    print(json.dumps(put_call_ratio(sample), indent=2, default=str))

# Run from Digital-Ocean-Server:
#   python -m portfolio_analysis_AI_Agent.tools.analysis.put_call_ratio
