"""Tool: analysis.compute_volatility_stats

Pure computation: descriptive statistics (latest value, 3M & 1Y
percentiles, min/max/quartiles) for a volatility time series. Drives
the Hedgeye-style summary tiles on the BTC Volatility page.

Percentile semantics: the percentile rank of the LATEST value vs the
trailing-N-day window. 100% = highest in the window; 0% = lowest.

Output dict::

    {
      latest: float|None,
      asof: "YYYY-MM-DD"|None,
      pct_3m: float|None,
      pct_1y: float|None,
      min_1y:  float|None,
      p25_1y:  float|None,
      median_1y: float|None,
      p75_1y:  float|None,
      max_1y:  float|None,
      mean_1y: float|None,
      count: int,
    }
"""
from __future__ import annotations

import json
from typing import Any, Iterable, Mapping, Optional

import numpy as np
import pandas as pd


def _to_series(data: Any, value_key: str = "value") -> pd.Series:
    """Like other tools' helper but accepts a configurable value-column name.

    For the vol tools the rows look like ``{date, rvol_pct}`` — pass
    ``value_key='rvol_pct'`` to extract them.
    """
    if isinstance(data, pd.Series):
        s = data.copy()
    elif isinstance(data, Mapping):
        s = pd.Series(dict(data), dtype=float)
    elif isinstance(data, Iterable):
        items = list(data)
        if not items:
            return pd.Series(dtype=float)
        if isinstance(items[0], Mapping):
            s = pd.Series(
                [None if r.get(value_key) is None else float(r[value_key]) for r in items],
                index=[r["date"] for r in items],
                dtype=float,
            )
        else:
            raise TypeError("iterable must contain {date, value} dicts")
    else:
        raise TypeError(f"unsupported series input: {type(data).__name__}")

    if not isinstance(s.index, pd.DatetimeIndex):
        s.index = pd.to_datetime(s.index, errors="coerce")
    return s.dropna().sort_index()


def _pct_rank(series: pd.Series, value: float) -> Optional[float]:
    if series.empty:
        return None
    # Percentile = share of observations <= value.
    leq = (series <= value).sum()
    return float(leq) / float(len(series)) * 100.0


def compute_volatility_stats(
    rows: Any,
    value_key: str = "rvol_pct",
    asof: Optional[str] = None,
    pct_3m_days: int = 90,
    pct_1y_days: int = 365,
) -> dict:
    """Summary stats for the LATEST value in a vol series.

    ``rows`` is the same shape produced by
    :func:`compute_realized_volatility` — a list of
    ``{date, rvol_pct}`` dicts — but can also be a Series or mapping.
    """
    s = _to_series(rows, value_key=value_key)

    out = {
        "latest": None,
        "asof": None,
        "pct_3m": None,
        "pct_1y": None,
        "min_1y": None,
        "p25_1y": None,
        "median_1y": None,
        "p75_1y": None,
        "max_1y": None,
        "mean_1y": None,
        "count": 0,
    }
    if s.empty:
        return out

    asof_ts = pd.Timestamp(asof) if asof else s.index[-1]
    s_to_now = s.loc[s.index <= asof_ts]
    if s_to_now.empty:
        return out

    latest = float(s_to_now.iloc[-1])
    out["latest"] = latest
    out["asof"] = str(s_to_now.index[-1].date())
    out["count"] = int(len(s_to_now))

    window_3m = s_to_now.loc[s_to_now.index > asof_ts - pd.Timedelta(days=int(pct_3m_days))]
    window_1y = s_to_now.loc[s_to_now.index > asof_ts - pd.Timedelta(days=int(pct_1y_days))]

    out["pct_3m"] = _pct_rank(window_3m, latest)
    out["pct_1y"] = _pct_rank(window_1y, latest)

    if not window_1y.empty:
        out["min_1y"]    = float(window_1y.min())
        out["max_1y"]    = float(window_1y.max())
        out["mean_1y"]   = float(window_1y.mean())
        out["p25_1y"]    = float(np.percentile(window_1y.values, 25))
        out["median_1y"] = float(np.percentile(window_1y.values, 50))
        out["p75_1y"]    = float(np.percentile(window_1y.values, 75))

    return out


if __name__ == "__main__":
    # Synthetic demo
    idx = pd.date_range("2025-05-23", "2026-05-23", freq="D")
    rng = np.random.default_rng(0)
    s = pd.Series(40.0 + rng.standard_normal(len(idx)) * 8, index=idx).clip(lower=10)
    rows = [{"date": d.strftime("%Y-%m-%d"), "rvol_pct": float(v)} for d, v in s.items()]
    print(json.dumps(compute_volatility_stats(rows), indent=2, default=str))

# Run from Digital-Ocean-Server:
#   python -m portfolio_analysis_AI_Agent.tools.analysis.compute_volatility_stats
