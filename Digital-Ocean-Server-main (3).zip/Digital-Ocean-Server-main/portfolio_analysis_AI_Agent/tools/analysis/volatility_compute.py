"""Tool: analysis.volatility.compute

Pure-math regime classifier. Given HV and DVOL/IV samples (already
fetched by data tools), labels the vol regime as LOW / NORMAL / HIGH /
EXTREME and flags IV-HV richness/cheapness.

Inputs are dicts shaped like the outputs of:
- datafetch.market.get_historical_volatility
- datafetch.market.get_dvol
"""

from __future__ import annotations

import json
import statistics
import time
from typing import Any

DEFAULT_THRESHOLDS = {
    "dvol_percentile": {"low": 25.0, "normal": 75.0, "high": 90.0},
    "iv_hv_spread_rich_pct": 5.0,
    "iv_hv_spread_cheap_pct": -5.0,
}


def _f(x: Any, default: float = 0.0) -> float:
    try:
        return float(x) if x is not None else default
    except (TypeError, ValueError):
        return default


def _percentile_rank(value: float, sample: list[float]) -> float | None:
    if not sample:
        return None
    below = sum(1 for x in sample if x < value)
    return round(100.0 * below / len(sample), 2)


def volatility_compute(
    hv: dict | None = None,
    dvol: dict | None = None,
    thresholds: dict | None = None,
) -> dict:
    """Compute vol regime + IV-HV richness."""
    t = {**DEFAULT_THRESHOLDS, **(thresholds or {})}

    hv_latest = _f((hv or {}).get("latest")) if hv else 0.0
    hv_mean = _f((hv or {}).get("mean")) if hv else 0.0

    dvol_close = _f((dvol or {}).get("latest_close")) if dvol else 0.0
    dvol_samples = []
    for row in (dvol or {}).get("ohlc", []):
        if isinstance(row, (list, tuple)) and len(row) >= 5:
            dvol_samples.append(_f(row[4]))

    dvol_pct = _percentile_rank(dvol_close, dvol_samples) if dvol_close and dvol_samples else None

    if dvol_pct is None:
        regime = "UNKNOWN"
    elif dvol_pct >= t["dvol_percentile"]["high"]:
        regime = "EXTREME"
    elif dvol_pct >= t["dvol_percentile"]["normal"]:
        regime = "HIGH"
    elif dvol_pct >= t["dvol_percentile"]["low"]:
        regime = "NORMAL"
    else:
        regime = "LOW"

    iv_hv_spread = dvol_close - hv_latest if (dvol_close and hv_latest) else None
    if iv_hv_spread is None:
        richness = "UNKNOWN"
    elif iv_hv_spread >= t["iv_hv_spread_rich_pct"]:
        richness = "RICH"
    elif iv_hv_spread <= t["iv_hv_spread_cheap_pct"]:
        richness = "CHEAP"
    else:
        richness = "FAIR"

    return {
        "regime": regime,
        "richness": richness,
        "metrics": {
            "hv_latest": hv_latest or None,
            "hv_mean": hv_mean or None,
            "dvol_close": dvol_close or None,
            "dvol_percentile": dvol_pct,
            "iv_hv_spread": round(iv_hv_spread, 4) if iv_hv_spread is not None else None,
            "dvol_sample_count": len(dvol_samples),
        },
        "thresholds_used": t,
        "computed_at": int(time.time()),
    }


if __name__ == "__main__":
    hv_sample = {"latest": 31.0, "mean": 33.0}
    dvol_sample = {
        "latest_close": 38.5,
        "ohlc": [[0, 0, 0, 0, v] for v in [40, 39, 38, 37, 35, 33, 31, 30, 32, 34, 36, 38]],
    }
    print(json.dumps(volatility_compute(hv_sample, dvol_sample), indent=2, default=str))

# Run from Digital-Ocean-Server:
#   python -m portfolio_analysis_AI_Agent.tools.analysis.volatility_compute
