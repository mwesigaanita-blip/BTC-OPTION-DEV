"""Tool: analysis.risk.compute

Classifier. Given an account-summary-like dict, computes margin %,
leverage, liquidation distance %, and multi-window equity changes
(1d/3d/7d/30d/90d/180d/365d/YTD). Produces a single SAFE / WARNING /
DANGEROUS / CRITICAL classification with per-metric sub-classifications.

Equity history is fetched automatically from
`snapshots.sqlite::account_snapshots` via
`datafetch.history.get_equity_history` - the same source the
`Positions_History` Streamlit page reads from. Callers can still inject
an explicit `equity_history` list for testing or to skip the DB read.
"""

from __future__ import annotations

import json
import logging
import time
from datetime import datetime, timezone
from typing import Any, Iterable, Optional

DEFAULT_THRESHOLDS: dict[str, dict[str, float]] = {
    "margin_pct": {"warning": 40.0, "dangerous": 60.0, "critical": 80.0},
    "recent_loss_pct": {"warning": 5.0, "dangerous": 10.0, "critical": 20.0},  # worst short-window loss
    "liquidation_distance_pct": {"warning": 30.0, "dangerous": 15.0, "critical": 7.0},
    "leverage": {"warning": 2.0, "dangerous": 4.0, "critical": 6.0},
}

# Windows reported in `changes` block. Short windows (≤ 7d) feed the
# `recent_loss_pct` classifier; longer ones are context for the LLM.
DEFAULT_WINDOWS_DAYS: tuple[int, ...] = (1, 3, 7, 30, 90, 180, 365)
SHORT_WINDOWS_DAYS: tuple[int, ...] = (1, 3, 7)


def _f(x: Any, default: float = 0.0) -> float:
    try:
        return float(x) if x is not None else default
    except (TypeError, ValueError):
        return default


def _classify_high(value: float, t: dict[str, float]) -> str:
    if value >= t["critical"]:
        return "CRITICAL"
    if value >= t["dangerous"]:
        return "DANGEROUS"
    if value >= t["warning"]:
        return "WARNING"
    return "SAFE"


def _classify_low(value: float, t: dict[str, float]) -> str:
    if value <= t["critical"]:
        return "CRITICAL"
    if value <= t["dangerous"]:
        return "DANGEROUS"
    if value <= t["warning"]:
        return "WARNING"
    return "SAFE"


def _normalize_history(history: Iterable[dict] | None) -> list[tuple[int, float]]:
    """Returns ascending-sorted [(ts_ms, equity_usd), ...]. Skips bad rows."""
    if not history:
        return []
    out: list[tuple[int, float]] = []
    for row in history:
        if not isinstance(row, dict):
            continue
        ts = row.get("ts") or row.get("timestamp") or row.get("ts_ms")
        eq = row.get("equity_usd") or row.get("total_equity_usd") or row.get("equity")
        try:
            ts_ms = int(ts)
            eq_f = float(eq)
        except (TypeError, ValueError):
            continue
        # Heuristic: if ts looks like seconds, scale to ms.
        if ts_ms < 10**12:
            ts_ms *= 1000
        if eq_f > 0:
            out.append((ts_ms, eq_f))
    out.sort(key=lambda x: x[0])
    return out


def _value_at_or_before(history: list[tuple[int, float]], target_ms: int) -> float | None:
    """Latest equity at or before `target_ms`. Falls back to the earliest
    available row if history doesn't reach that far back (matches the
    Positions_History page behavior)."""
    if not history:
        return None
    prior = [v for ts, v in history if ts <= target_ms]
    if prior:
        return prior[-1]
    return history[0][1]


def _compute_changes(history: list[tuple[int, float]], windows_days: tuple[int, ...]) -> dict:
    """Returns {"1d": {pct, abs, ref_equity_usd}, ..., "ytd": {...}}."""
    if not history:
        return {}
    latest_ts, latest_val = history[-1]
    latest_dt = datetime.fromtimestamp(latest_ts / 1000, tz=timezone.utc)
    DAY_MS = 86400 * 1000

    changes: dict = {}
    for d in windows_days:
        ref_val = _value_at_or_before(history, latest_ts - d * DAY_MS)
        if ref_val is None or ref_val == 0:
            changes[f"{d}d"] = {"pct": None, "abs": None, "ref_equity_usd": None}
            continue
        changes[f"{d}d"] = {
            "pct": round((latest_val - ref_val) / ref_val * 100.0, 4),
            "abs": round(latest_val - ref_val, 2),
            "ref_equity_usd": round(ref_val, 2),
        }

    # YTD - Jan 1 of the latest sample's year.
    ytd_target_ms = int(datetime(latest_dt.year, 1, 1, tzinfo=timezone.utc).timestamp() * 1000)
    ref_val = _value_at_or_before(history, ytd_target_ms)
    if ref_val and ref_val > 0:
        changes["ytd"] = {
            "pct": round((latest_val - ref_val) / ref_val * 100.0, 4),
            "abs": round(latest_val - ref_val, 2),
            "ref_equity_usd": round(ref_val, 2),
        }
    else:
        changes["ytd"] = {"pct": None, "abs": None, "ref_equity_usd": None}

    return changes


def _worst_short_loss_pct(changes: dict, short_windows_days: tuple[int, ...] = SHORT_WINDOWS_DAYS) -> tuple[float | None, str | None]:
    """Most negative pct among the short-window changes. Returns (pct, window_key)."""
    worst_pct: float | None = None
    worst_key: str | None = None
    for d in short_windows_days:
        key = f"{d}d"
        pct = (changes.get(key) or {}).get("pct")
        if pct is None:
            continue
        if worst_pct is None or pct < worst_pct:
            worst_pct = pct
            worst_key = key
    return worst_pct, worst_key


def risk_compute(
    account_summary: dict,
    equity_history: Optional[Iterable[dict]] = None,
    thresholds: Optional[dict[str, dict[str, float]]] = None,
    windows_days: tuple[int, ...] = DEFAULT_WINDOWS_DAYS,
) -> dict:
    """Classify account risk.

    Args:
        account_summary: shape from `datafetch.account.get_account_summary`.
        equity_history: optional ascending-sorted iterable of equity
            snapshots. Each row needs at least a timestamp (ms or sec,
            field `ts` / `timestamp` / `ts_ms`) and an equity USD value
            (field `equity_usd` / `total_equity_usd` / `equity`). When
            omitted, the `changes` block is empty and `recent_loss_pct`
            sub-classification is UNKNOWN.
        thresholds: optional override map; missing keys fall back to defaults.
        windows_days: which lookback windows to report (default 1/3/7/30/90/180/365 + YTD).

    Returns structured classification + per-metric sub-classifications +
    multi-window equity changes.
    """
    t = {**DEFAULT_THRESHOLDS, **(thresholds or {})}

    # Per-currency raw fields (BTC-denominated when focus_currency=BTC).
    equity = _f(account_summary.get("equity"))
    margin_balance = _f(account_summary.get("margin_balance"))
    initial_margin = _f(account_summary.get("initial_margin"))
    maintenance_margin = _f(account_summary.get("maintenance_margin"))
    available_funds = _f(account_summary.get("available_funds"))

    # Cross-margin USD totals (when input came from get_account_summaries).
    # These sum across BTC + USDT + USDC + ... so the margin ratios reflect
    # the *real* portfolio, not just one currency's slice.
    total_equity_usd = _f(account_summary.get("total_equity_usd"))
    total_im_usd = _f(account_summary.get("total_initial_margin_usd"))
    total_mm_usd = _f(account_summary.get("total_maintenance_margin_usd"))

    if total_equity_usd > 0 and total_im_usd >= 0 and total_mm_usd >= 0:
        # Cross-margin path - ratios computed in USD across all collateral.
        margin_pct = (total_im_usd / total_equity_usd * 100.0)
        mm_pct = (total_mm_usd / total_equity_usd * 100.0)
        leverage = (total_im_usd / total_equity_usd)
        margin_source = "cross_margin_usd"
    else:
        # Single-currency fallback (BTC-only).
        margin_pct = (initial_margin / equity * 100.0) if equity > 0 else 0.0
        mm_pct = (maintenance_margin / equity * 100.0) if equity > 0 else 0.0
        leverage = (initial_margin / equity) if equity > 0 else 0.0
        margin_source = "currency_only"

    # Liquidation distance: prefer Deribit's estimated_liquidation_ratio;
    # fall back to (available_funds/equity).
    elr = account_summary.get("estimated_liquidation_ratio")
    if elr is not None:
        liquidation_distance_pct = max(0.0, (_f(elr) - 1.0) * 100.0)
    elif equity > 0:
        liquidation_distance_pct = max(0.0, available_funds / equity * 100.0)
    else:
        liquidation_distance_pct = 0.0

    # Multi-window equity changes (replaces single-value drawdown).
    # If the caller didn't pass a history, fetch it from snapshots.sqlite.
    if equity_history is None:
        try:
            from portfolio_analysis_AI_Agent.tools.datafetch.history.get_equity_history import get_equity_history
            equity_history = get_equity_history(days=400).get("history") or []
        except Exception:
            equity_history = []
            logging.exception("Failed to fetch equity history for risk_compute; proceeding with empty history.")
    history = _normalize_history(equity_history)
    changes = _compute_changes(history, windows_days)
    worst_loss_pct, worst_loss_window = _worst_short_loss_pct(changes)

    # Classify recent loss using the *magnitude* of the worst short-window
    # drop. Gains never trigger a warning.
    if worst_loss_pct is None:
        recent_loss_sub = "UNKNOWN"
        recent_loss_magnitude = 0.0
    else:
        recent_loss_magnitude = max(0.0, -worst_loss_pct)  # convert -7% → 7
        recent_loss_sub = _classify_high(recent_loss_magnitude, t["recent_loss_pct"])

    sub = {
        "margin_pct": _classify_high(margin_pct, t["margin_pct"]),
        "recent_loss_pct": recent_loss_sub,
        "liquidation_distance_pct": _classify_low(liquidation_distance_pct, t["liquidation_distance_pct"]),
        "leverage": _classify_high(leverage, t["leverage"]),
    }
    rank = {"SAFE": 0, "WARNING": 1, "DANGEROUS": 2, "CRITICAL": 3, "UNKNOWN": 0}
    overall = max(sub.values(), key=lambda v: rank[v])

    return {
        "classification": overall,
        "metrics": {
            "equity": equity,
            "margin_balance": margin_balance,
            "initial_margin": initial_margin,
            "maintenance_margin": maintenance_margin,
            "available_funds": available_funds,
            "total_equity_usd": total_equity_usd or None,
            "total_initial_margin_usd": total_im_usd or None,
            "total_maintenance_margin_usd": total_mm_usd or None,
            "margin_source": margin_source,
            "margin_pct": round(margin_pct, 4),
            "mm_pct": round(mm_pct, 4),
            "leverage": round(leverage, 4),
            "liquidation_distance_pct": round(liquidation_distance_pct, 4),
            "recent_loss_pct": round(recent_loss_magnitude, 4) if worst_loss_pct is not None else None,
            "worst_loss_window": worst_loss_window,
        },
        "changes": changes,
        "sub_classifications": sub,
        "thresholds_used": t,
        "history_sample_count": len(history),
        "computed_at": int(time.time()),
    }


if __name__ == "__main__":
    sample = {
        "equity": 1.008,
        "margin_balance": 1.387,
        "initial_margin": 0.228,
        "maintenance_margin": 0.176,
        "available_funds": 1.159,
        "estimated_liquidation_ratio": 1.45,
    }
    now_ms = int(time.time() * 1000)
    DAY = 86400 * 1000
    sample_history = [
        {"ts": now_ms - 400 * DAY, "equity_usd": 70000},
        {"ts": now_ms - 200 * DAY, "equity_usd": 76000},
        {"ts": now_ms - 90 * DAY,  "equity_usd": 84000},
        {"ts": now_ms - 30 * DAY,  "equity_usd": 88000},
        {"ts": now_ms - 7 * DAY,   "equity_usd": 86000},
        {"ts": now_ms - 3 * DAY,   "equity_usd": 83000},
        {"ts": now_ms - 1 * DAY,   "equity_usd": 81500},
        {"ts": now_ms,             "equity_usd": 81000},
    ]
    print(json.dumps(risk_compute(sample, equity_history=sample_history), indent=2, default=str))

# Run from Digital-Ocean-Server:
#   python -m portfolio_analysis_AI_Agent.tools.analysis.risk_compute
