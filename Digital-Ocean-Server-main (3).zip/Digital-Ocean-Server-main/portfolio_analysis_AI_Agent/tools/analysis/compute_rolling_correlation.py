"""Tool: analysis.compute_rolling_correlation

Pure computation: rolling Pearson correlation of daily % returns between
two close-price series. Powers the "BTC Rolling 30D Price Correlations"
time-series chart (vs SPX, $USD, GOLD, ...) and is reusable by the AI
agent for any pair of assets.

Output dict::

    {
      window: int,                  # rolling window in calendar days
      rows: [{date, corr}, ...],    # ASC by date; corr is None until the
                                    # first valid window has filled
      count: int,
      latest: float|None,
      stats: {min, max, mean},      # over the returned rows (corr != None)
    }

Notes:
- Inputs accept the same flexible shapes as compute_correlation_matrix:
  ``pandas.Series`` indexed by datetime, list of ``{date, close}`` dicts,
  or ``{date: close}`` mappings.
- Series with mismatched calendars (e.g. BTC trades weekends, SPX does
  not) are joined inner — the rolling window operates on the dates where
  BOTH have a daily return.
"""
from __future__ import annotations

import json
from typing import Any, Iterable, Mapping, Optional

import pandas as pd


def _to_series(data: Any) -> pd.Series:
    if isinstance(data, pd.Series):
        s = data.copy()
    elif isinstance(data, Mapping):
        s = pd.Series(dict(data), dtype=float)
    elif isinstance(data, Iterable):
        items = list(data)
        if not items:
            return pd.Series(dtype=float)
        if isinstance(items[0], Mapping):
            s = pd.Series(
                [float(r["close"]) for r in items],
                index=[r["date"] for r in items],
                dtype=float,
            )
        else:
            raise TypeError("iterable must contain {date, close} dicts")
    else:
        raise TypeError(f"unsupported series input: {type(data).__name__}")

    if not isinstance(s.index, pd.DatetimeIndex):
        s.index = pd.to_datetime(s.index, errors="coerce")
    return s.dropna().sort_index()


def compute_rolling_correlation(
    a: Any,
    b: Any,
    window: int = 30,
    min_periods: Optional[int] = None,
) -> dict:
    """Rolling Pearson correlation of daily % returns over ``window`` days.

    ``window`` is in observations (typically days). ``min_periods``
    defaults to ``max(2, window // 2)`` so the curve starts a bit faster
    than waiting for a full window — matches Hedgeye-style charts that
    begin with a partial window.
    """
    sa = _to_series(a)
    sb = _to_series(b)
    if sa.empty or sb.empty:
        return {
            "window": int(window),
            "rows": [],
            "count": 0,
            "latest": None,
            "stats": {"min": None, "max": None, "mean": None},
        }

    if min_periods is None:
        min_periods = max(2, int(window) // 2)

    # Inner-join the two return series so missing days don't pollute the
    # rolling correlation with NaNs that pandas would otherwise propagate.
    df = pd.DataFrame({"a": sa.pct_change(), "b": sb.pct_change()}).dropna()
    if df.empty or len(df) < min_periods:
        return {
            "window": int(window),
            "rows": [],
            "count": 0,
            "latest": None,
            "stats": {"min": None, "max": None, "mean": None},
        }

    corr = df["a"].rolling(window=int(window), min_periods=int(min_periods)).corr(df["b"])

    rows = [
        {"date": ts.strftime("%Y-%m-%d"), "corr": None if pd.isna(v) else float(v)}
        for ts, v in corr.items()
    ]

    non_null = [r["corr"] for r in rows if r["corr"] is not None]
    stats = {
        "min":  min(non_null) if non_null else None,
        "max":  max(non_null) if non_null else None,
        "mean": (sum(non_null) / len(non_null)) if non_null else None,
    }

    return {
        "window": int(window),
        "rows": rows,
        "count": len(rows),
        "latest": non_null[-1] if non_null else None,
        "stats": stats,
    }


if __name__ == "__main__":
    # Demo: two synthetic series with shifting correlation.
    import math, random
    random.seed(0)
    idx = pd.date_range("2025-01-01", "2026-05-23", freq="D")
    base = [100.0]
    for _ in range(len(idx) - 1):
        base.append(base[-1] * (1.0 + 0.01 * (random.random() - 0.5)))
    a = pd.Series(base, index=idx)
    # b: correlated for first half, anti-correlated for second half
    half = len(idx) // 2
    b_vals = []
    for i, x in enumerate(base):
        sign = 1.0 if i < half else -1.0
        b_vals.append(50 + sign * (x - 100) + 0.5 * math.sin(i / 7.0))
    b = pd.Series(b_vals, index=idx)
    out = compute_rolling_correlation(a, b, window=30)
    print(json.dumps({**out, "rows": out["rows"][:3] + ["…"] + out["rows"][-3:]},
                     indent=2, default=str))

# Run from Digital-Ocean-Server:
#   python -m portfolio_analysis_AI_Agent.tools.analysis.compute_rolling_correlation
