"""Tool: analysis.stress_scenarios

Pure-math stress engine. For each scenario reprice the book and report
USD PnL plus % of equity. Three shock dimensions: **BTC spot**, **IV**,
and **time forward** (theta decay). Dashboard-ready output: every
scenario is tagged with `kind`, `display_label`, and `severity`; the
top-level `summary` block has the per-kind grouping, severity counts,
and worst/best shortcuts.

Pricing strategy:
- **Options** - Black-Scholes reprice. Strike, expiry and type are
  parsed from the Deribit instrument name (`BTC-26DEC25-100000-C`).
  IV is taken from `position.mark_iv` if present, otherwise implied
  from `position.mark_price` (USD = mark_price_btc × spot) via Newton.
  Time advance shrinks T = max(1e-6, T − days_forward/365.25); if T
  hits 0 BS returns intrinsic - the option has expired in the scenario
  and is realized at its settlement payout.
  If IV can't be obtained (zero mark, expired, or solver blow-up) we
  fall back to a Taylor approximation that includes a theta term for
  the time component.
- **Futures / perpetuals / unparseable names** - linear `delta × dS`.
  IV and time shocks have no effect (no vega, no theta).

For position-change what-ifs (no market shocks, but real Deribit-side
re-margining) see `analysis.simulate_portfolio`.
"""

from __future__ import annotations

import json
import math
import time
from datetime import datetime, timezone
from typing import Any, Optional


# ---------------------------------------------------------------------------
# Scenario set
# ---------------------------------------------------------------------------

STANDARD_SCENARIOS = [
    # kind="spot" - pure BTC moves, instantaneous (no time/IV change)
    {"name": "btc_+5",          "btc_pct":  5.0, "iv_points":   0.0, "days_forward":  0,
     "kind": "spot",       "display_label": "BTC +5%"},
    {"name": "btc_-5",          "btc_pct": -5.0, "iv_points":   0.0, "days_forward":  0,
     "kind": "spot",       "display_label": "BTC -5%"},
    {"name": "btc_+10",         "btc_pct": 10.0, "iv_points":   0.0, "days_forward":  0,
     "kind": "spot",       "display_label": "BTC +10%"},
    {"name": "btc_-10",         "btc_pct":-10.0, "iv_points":   0.0, "days_forward":  0,
     "kind": "spot",       "display_label": "BTC -10%"},
    # kind="iv" - pure IV moves, instantaneous
    {"name": "iv_+20",          "btc_pct":  0.0, "iv_points":  20.0, "days_forward":  0,
     "kind": "iv",         "display_label": "IV +20pts"},
    {"name": "iv_-20",          "btc_pct":  0.0, "iv_points": -20.0, "days_forward":  0,
     "kind": "iv",         "display_label": "IV -20pts"},
    # kind="combo" - instantaneous spot+IV moves (panic / rally-crush)
    {"name": "btc_-10_iv_+20",  "btc_pct":-10.0, "iv_points":  20.0, "days_forward":  0,
     "kind": "combo",      "display_label": "BTC -10% & IV +20pts (panic)"},
    {"name": "btc_+10_iv_-20",  "btc_pct": 10.0, "iv_points": -20.0, "days_forward":  0,
     "kind": "combo",      "display_label": "BTC +10% & IV -20pts (rally crush)"},
    # kind="time" - pure time advance, no spot/IV move (isolates theta)
    {"name": "time_+1d",        "btc_pct":  0.0, "iv_points":   0.0, "days_forward":  1,
     "kind": "time",       "display_label": "+1 day forward"},
    {"name": "time_+7d",        "btc_pct":  0.0, "iv_points":   0.0, "days_forward":  7,
     "kind": "time",       "display_label": "+1 week forward"},
    {"name": "time_+30d",       "btc_pct":  0.0, "iv_points":   0.0, "days_forward": 30,
     "kind": "time",       "display_label": "+1 month forward"},
    # kind="time_combo" - slow grind scenarios mixing time with one other dimension
    {"name": "btc_-5_time_+7d", "btc_pct": -5.0, "iv_points":   0.0, "days_forward":  7,
     "kind": "time_combo", "display_label": "BTC -5% slowly over 1 week"},
    {"name": "iv_-20_time_+7d", "btc_pct":  0.0, "iv_points": -20.0, "days_forward":  7,
     "kind": "time_combo", "display_label": "IV -20pts crush over 1 week"},
]


# Severity bands (applied to loss magnitude - gains are always SAFE).
SEVERITY_THRESHOLDS_PCT = {
    "WARNING":   5.0,
    "DANGEROUS": 10.0,
    "CRITICAL":  20.0,
}


def _classify_severity(pnl_pct_equity: Optional[float]) -> str:
    if pnl_pct_equity is None:
        return "UNKNOWN"
    loss = max(0.0, -pnl_pct_equity)  # only losses count
    if loss >= SEVERITY_THRESHOLDS_PCT["CRITICAL"]:
        return "CRITICAL"
    if loss >= SEVERITY_THRESHOLDS_PCT["DANGEROUS"]:
        return "DANGEROUS"
    if loss >= SEVERITY_THRESHOLDS_PCT["WARNING"]:
        return "WARNING"
    return "SAFE"


# ---------------------------------------------------------------------------
# Black-Scholes core
# ---------------------------------------------------------------------------

_SQRT_2 = math.sqrt(2.0)
_SQRT_2PI = math.sqrt(2.0 * math.pi)


def _f(x: Any, default: float = 0.0) -> float:
    try:
        return float(x) if x is not None else default
    except (TypeError, ValueError):
        return default


def _norm_cdf(x: float) -> float:
    return 0.5 * (1.0 + math.erf(x / _SQRT_2))


def _norm_pdf(x: float) -> float:
    return math.exp(-0.5 * x * x) / _SQRT_2PI


def _bs_price(S: float, K: float, T: float, sigma: float, opt_type: str, r: float = 0.0) -> float:
    """Black-Scholes premium in USD (S and K in USD, sigma annualized fraction)."""
    if T <= 0 or sigma <= 0 or S <= 0 or K <= 0:
        return max(S - K, 0.0) if opt_type == "C" else max(K - S, 0.0)
    sqrtT = math.sqrt(T)
    d1 = (math.log(S / K) + (r + 0.5 * sigma * sigma) * T) / (sigma * sqrtT)
    d2 = d1 - sigma * sqrtT
    if opt_type == "C":
        return S * _norm_cdf(d1) - K * math.exp(-r * T) * _norm_cdf(d2)
    return K * math.exp(-r * T) * _norm_cdf(-d2) - S * _norm_cdf(-d1)


def _bs_vega(S: float, K: float, T: float, sigma: float, r: float = 0.0) -> float:
    """∂Price/∂σ in BS units (per 1.00 change in sigma, i.e. per 100 vol points)."""
    if T <= 0 or sigma <= 0 or S <= 0 or K <= 0:
        return 0.0
    sqrtT = math.sqrt(T)
    d1 = (math.log(S / K) + (r + 0.5 * sigma * sigma) * T) / (sigma * sqrtT)
    return S * sqrtT * _norm_pdf(d1)


def _imply_iv(
    target_price: float,
    S: float, K: float, T: float, opt_type: str,
    r: float = 0.0,
    guess: float = 0.6,
    iters: int = 50,
    tol: float = 1e-6,
) -> Optional[float]:
    """Newton-Raphson implied volatility. Returns sigma as a fraction (e.g. 0.55 = 55%).
    Returns None if target is below intrinsic or solver fails."""
    intrinsic = max(S - K, 0.0) if opt_type == "C" else max(K - S, 0.0)
    if target_price < intrinsic - 1e-6 or T <= 0 or S <= 0 or K <= 0:
        return None
    sigma = max(0.01, guess)
    for _ in range(iters):
        price = _bs_price(S, K, T, sigma, opt_type, r)
        diff = price - target_price
        if abs(diff) < tol:
            return sigma
        vega = _bs_vega(S, K, T, sigma, r)
        if vega < 1e-9:
            break
        sigma -= diff / vega
        if sigma <= 0:
            sigma = 1e-4
        if sigma > 5.0:  # 500% IV cap
            sigma = 5.0
    # accept current sigma if reasonably close
    if abs(_bs_price(S, K, T, sigma, opt_type, r) - target_price) < target_price * 0.01:
        return sigma
    return None


# ---------------------------------------------------------------------------
# Position parsing
# ---------------------------------------------------------------------------

_MONTHS = {"JAN":1, "FEB":2, "MAR":3, "APR":4, "MAY":5, "JUN":6,
           "JUL":7, "AUG":8, "SEP":9, "OCT":10, "NOV":11, "DEC":12}


def _parse_option_name(name: str) -> Optional[dict]:
    """Parse `BTC-26DEC25-100000-C` → {strike, expiry_ms, type}. Returns None
    if the name is not an option (perp / future)."""
    parts = (name or "").split("-")
    if len(parts) != 4:
        return None
    _sym, exp_str, strike_str, typ = parts
    if typ not in ("C", "P"):
        return None
    if len(exp_str) < 6:
        return None
    try:
        day = int(exp_str[:-5])
        month = _MONTHS.get(exp_str[-5:-2].upper())
        year = 2000 + int(exp_str[-2:])
        K = float(strike_str)
        if month is None:
            return None
        # Deribit settles at 08:00 UTC.
        expiry_dt = datetime(year, month, day, 8, 0, 0, tzinfo=timezone.utc)
        return {"strike": K, "expiry_ms": int(expiry_dt.timestamp() * 1000), "type": typ}
    except (ValueError, KeyError):
        return None


def _signed_size(p: dict) -> float:
    """Resolve signed contract count regardless of whether Deribit puts the
    sign on `size` or splits it into size + direction."""
    size = _f(p.get("size"))
    direction = str(p.get("direction") or "").lower()
    if size > 0 and direction == "sell":
        return -size
    return size


def _position_iv_fraction(
    p: dict, S: float, K: float, T: float, opt_type: str,
) -> tuple[Optional[float], str]:
    """Returns (sigma_fraction, source) where source ∈ {"position", "implied", "none"}.

    Sigma is recovered under TODAY'S actual rate (`r = 0` for Deribit BTC) so
    that any scenario rate slider only affects the *forward* repricing, not
    the baseline IV inferred from current marks.
    """
    # Try direct fields first.
    for key in ("mark_iv", "iv", "implied_volatility"):
        v = p.get(key)
        if v is not None:
            f = _f(v)
            if f > 0:
                # mark_iv is in percent on Deribit (e.g. 50.5).
                return f / 100.0, "position"
    # Imply from mark_price (BTC quote → USD).
    mark_btc = _f(p.get("mark_price"))
    if mark_btc > 0 and S > 0:
        mark_usd = mark_btc * S
        sigma = _imply_iv(mark_usd, S, K, T, opt_type, r=0.0)
        if sigma is not None and sigma > 0:
            return sigma, "implied"
    return None, "none"


# ---------------------------------------------------------------------------
# Per-position PnL under one scenario
# ---------------------------------------------------------------------------

def _position_pnl(
    p: dict,
    spot: float,
    new_S: float,
    btc_pct: float,
    iv_pts: float,
    now_ms: int,
    days_forward: float = 0.0,
    r: float = 0.0,
    iv_pct_shift: float = 0.0,
) -> dict:
    """Reprice one position under a scenario.

    Args:
        p: Deribit position dict (instrument_name, size, direction,
            mark_price, delta/gamma/vega/theta, optionally mark_iv).
        spot: current BTC index price.
        new_S: shocked spot at scenario time.
        btc_pct: spot shock (% of current spot, signed).
        iv_pts: IV shock in vol-points (signed).
        now_ms: current timestamp ms (T = expiry − now).
        days_forward: time advance in days (default 0 = same instant).

    Returns a row with:
        instrument_name, pricing_method, size,
        old_price_usd, new_price_usd, pnl_usd

    For non-options (perp/future) and Taylor fallbacks, per-unit prices
    aren't well-defined under the model used, so `old_price_usd` /
    `new_price_usd` are reported as None and only `pnl_usd` is filled.
    """
    name = str(p.get("instrument_name") or "")
    size = _signed_size(p)
    parsed = _parse_option_name(name)

    # Non-option (perp / future / spot) - linear delta × dS. Time has no
    # effect (perps carry no theta in this model).
    if parsed is None:
        delta = _f(p.get("delta"))
        return {
            "instrument_name": name,
            "pricing_method": "linear",
            "size": size,
            "old_price_usd": None,
            "new_price_usd": None,
            "pnl_usd": round(delta * (new_S - spot), 2),
        }

    # Option - try BS.
    K = parsed["strike"]
    opt_type = parsed["type"]
    T = max(1e-6, (parsed["expiry_ms"] - now_ms) / 1000.0 / (365.25 * 86400))
    # T at the future date - if it hits zero the option has expired
    # within the scenario; _bs_price returns intrinsic in that case. Clamp at
    # 0.0 (not 1e-6) so the dynamic curve lands EXACTLY on intrinsic when the
    # time slider crosses each leg's expiry - matches the static expiration
    # curve to floating-point precision. `days_forward` is a float so the
    # timeline slider can land precisely on any per-leg expiry.
    T_new = max(0.0, T - float(days_forward) / 365.25)

    old_sigma, iv_source = _position_iv_fraction(p, spot, K, T, opt_type)
    if old_sigma is None:
        # Fall back to Taylor for this position. The theta term is the
        # only piece that picks up the time advance here.
        delta = _f(p.get("delta"))
        gamma = _f(p.get("gamma"))
        vega = _f(p.get("vega"))
        theta = _f(p.get("theta"))
        dS = new_S - spot
        # Deribit reports theta as option-price change per 1 day.
        theta_pnl = theta * float(days_forward)
        # Multiplicative IV shift -> approximate per-point bump using a 60%
        # sigma proxy (we couldn't imply sigma in this branch). Combined with
        # any additive `iv_pts` bump from canned scenarios.
        sigma_proxy = 0.60
        iv_pts_pct = sigma_proxy * 100.0 * (iv_pct_shift / 100.0)
        return {
            "instrument_name": name,
            "pricing_method": "taylor_fallback",
            "size": size,
            "old_price_usd": None,
            "new_price_usd": None,
            "pnl_usd": round(
                delta * dS + 0.5 * gamma * dS * dS
                + vega * (iv_pts + iv_pts_pct) + theta_pnl,
                2,
            ),
        }

    # Multiplicative percentage shift first, then additive vol-points on top.
    # Whatif uses iv_pct_shift only; canned scenarios use iv_pts only.
    sigma_after_pct = old_sigma * (1.0 + iv_pct_shift / 100.0)
    new_sigma = max(1e-4, sigma_after_pct + iv_pts / 100.0)
    # Baseline always at r = 0 ("today as observed"). The rate slider only
    # bites the forward (new) state. This matches `_position_pnl_at_expiry`'s
    # r = 0 baseline so the dynamic curve lands EXACTLY on the static curve
    # at full time decay regardless of the rate slider position.
    old_price = _bs_price(spot,  K, T,     old_sigma, opt_type, r=0.0)
    new_price = _bs_price(new_S, K, T_new, new_sigma, opt_type, r=r)
    return {
        "instrument_name": name,
        "pricing_method": f"bs_{iv_source}",
        "size": size,
        "old_price_usd": round(old_price, 2),
        "new_price_usd": round(new_price, 2),
        "pnl_usd": round((new_price - old_price) * size, 2),
    }


def _position_pnl_at_expiry(
    p: dict,
    spot: float,
    new_S: float,
    now_ms: int,
) -> dict:
    """Reprice one position at its own expiration (T_new = 0, intrinsic only).

    Mirrors `_position_pnl` but is fully invariant to the dynamic-curve
    sliders: IV / time / rate shifts have no effect. The baseline `old_price`
    uses BS at today's T with `r = 0` so the static line is the same shape
    regardless of where the rate slider sits. Returns the same row shape as
    `_position_pnl`.
    """
    name = str(p.get("instrument_name") or "")
    size = _signed_size(p)
    parsed = _parse_option_name(name)

    if parsed is None:
        delta = _f(p.get("delta"))
        return {
            "instrument_name": name,
            "pricing_method": "linear_at_expiry",
            "size": size,
            "old_price_usd": None,
            "new_price_usd": None,
            "pnl_usd": round(delta * (new_S - spot), 2),
        }

    K = parsed["strike"]
    opt_type = parsed["type"]
    T = max(1e-6, (parsed["expiry_ms"] - now_ms) / 1000.0 / (365.25 * 86400))

    old_sigma, iv_source = _position_iv_fraction(p, spot, K, T, opt_type)
    intrinsic = max(new_S - K, 0.0) if opt_type == "C" else max(K - new_S, 0.0)
    if old_sigma is None:
        # No reliable BS baseline - quote the leg as raw expiration payoff
        # minus the per-contract mark (BTC) we have on hand. If even that is
        # missing the row is best-effort intrinsic only.
        mark_btc = _f(p.get("mark_price"))
        old_price = mark_btc * spot if (mark_btc > 0 and spot > 0) else 0.0
        return {
            "instrument_name": name,
            "pricing_method": "intrinsic_taylor_fallback",
            "size": size,
            "old_price_usd": round(old_price, 2),
            "new_price_usd": round(intrinsic, 2),
            "pnl_usd": round((intrinsic - old_price) * size, 2),
        }

    old_price = _bs_price(spot, K, T, old_sigma, opt_type, r=0.0)
    return {
        "instrument_name": name,
        "pricing_method": f"intrinsic_{iv_source}",
        "size": size,
        "old_price_usd": round(old_price, 2),
        "new_price_usd": round(intrinsic, 2),
        "pnl_usd": round((intrinsic - old_price) * size, 2),
    }


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------

def run_scenario(
    positions: list[dict],
    btc_index_price: float,
    btc_pct: float = 0.0,
    iv_points: float = 0.0,
    days_forward: float = 0.0,
    equity_usd: Optional[float] = None,
    label: Optional[str] = None,
    name: Optional[str] = None,
    kind: str = "custom",
    now_ms: Optional[int] = None,
    r: float = 0.0,
    iv_pct_shift: float = 0.0,
) -> dict:
    """Run a single ad-hoc scenario across the three shock dimensions.

    Returns the same shape as one entry in
    `stress_scenarios()['scenarios']`, so dashboards / LLMs can render it
    with the same logic as a canned scenario.

    Used by the dashboard's custom-scenario form (sliders for spot/IV/time).
    """
    spot = _f(btc_index_price)
    now_ms = int(now_ms or time.time() * 1000)
    new_S = spot * (1.0 + btc_pct / 100.0)

    total = 0.0
    position_rows: list[dict] = []
    for p in positions or []:
        row = _position_pnl(
            p, spot, new_S, btc_pct, iv_points, now_ms,
            days_forward=float(days_forward), r=r, iv_pct_shift=iv_pct_shift,
        )
        total += row["pnl_usd"]
        position_rows.append(row)
    position_rows.sort(key=lambda r: -abs(r["pnl_usd"]))

    pct = (total / equity_usd * 100.0) if equity_usd else None
    new_equity_usd = (
        round(equity_usd + total, 2) if equity_usd is not None else None
    )

    auto_label = (
        label
        or f"BTC {btc_pct:+g}% · IV {iv_points:+g}pts · +{int(days_forward)}d"
    )
    auto_name = (
        name
        or f"custom_btc{btc_pct:+g}_iv{iv_points:+g}_t{int(days_forward)}d"
    )

    return {
        "name": auto_name,
        "kind": kind,
        "display_label": auto_label,
        "btc_pct": btc_pct,
        "iv_points": iv_points,
        "days_forward": int(days_forward),
        "new_btc_index_price": round(new_S, 2),
        "pnl_usd": round(total, 2),
        "pnl_pct_equity": round(pct, 4) if pct is not None else None,
        "new_equity_usd": new_equity_usd,
        "severity": _classify_severity(round(pct, 4) if pct is not None else None),
        "positions": position_rows,
    }


def stress_scenarios(
    positions: list[dict],
    btc_index_price: float,
    equity_usd: Optional[float] = None,
    now_ms: Optional[int] = None,
) -> dict:
    """Run the 13 standard scenarios across BTC, IV, and time dimensions.

    BS-reprices each option (with time advance if the scenario carries
    `days_forward > 0`); linear `delta × dS` for non-options. Output is
    dashboard-ready: per-scenario `kind`/`display_label`/`severity`,
    sorted-by-impact `positions[]`, and a top-level `summary` block with
    grouping + counts + worst/best shortcuts.
    """
    spot = _f(btc_index_price)
    now_ms = int(now_ms or time.time() * 1000)
    scenarios: list[dict] = []

    # Per-position pricing source counters (computed once on the first scenario
    # since the choice is scenario-independent).
    pricing_counts = {"bs_position": 0, "bs_implied": 0, "linear": 0, "taylor_fallback": 0}
    sample_size = len(positions or [])

    for i, sc in enumerate(STANDARD_SCENARIOS):
        new_S = spot * (1.0 + sc["btc_pct"] / 100.0)
        days_forward = int(sc.get("days_forward", 0))
        total = 0.0
        position_rows: list[dict] = []
        for p in positions or []:
            row = _position_pnl(
                p, spot, new_S, sc["btc_pct"], sc["iv_points"], now_ms,
                days_forward=days_forward,
            )
            total += row["pnl_usd"]
            position_rows.append(row)
            if i == 0:
                pricing_counts[row["pricing_method"]] = (
                    pricing_counts.get(row["pricing_method"], 0) + 1
                )

        # Sort positions by absolute PnL desc - biggest movers first
        # (the UI will surface these as the "drivers" of the scenario).
        position_rows.sort(key=lambda r: -abs(r["pnl_usd"]))

        pct = (total / equity_usd * 100.0) if equity_usd else None
        new_equity_usd = (
            round(equity_usd + total, 2) if equity_usd is not None else None
        )
        scenarios.append({
            "name": sc["name"],
            "kind": sc["kind"],
            "display_label": sc["display_label"],
            "btc_pct": sc["btc_pct"],
            "iv_points": sc["iv_points"],
            "days_forward": days_forward,
            "new_btc_index_price": round(new_S, 2),
            "pnl_usd": round(total, 2),
            "pnl_pct_equity": round(pct, 4) if pct is not None else None,
            "new_equity_usd": new_equity_usd,
            "severity": _classify_severity(round(pct, 4) if pct is not None else None),
            "positions": position_rows,
        })

    # ---- Summary block for dashboard consumers --------------------------
    worst_loss = min(
        (s for s in scenarios if s["pnl_pct_equity"] is not None),
        key=lambda s: s["pnl_pct_equity"],
        default=None,
    )
    best_gain = max(
        (s for s in scenarios if s["pnl_pct_equity"] is not None),
        key=lambda s: s["pnl_pct_equity"],
        default=None,
    )

    def _slim(sc: Optional[dict]) -> Optional[dict]:
        if sc is None:
            return None
        return {
            "name": sc["name"],
            "display_label": sc["display_label"],
            "kind": sc["kind"],
            "pnl_usd": sc["pnl_usd"],
            "pnl_pct_equity": sc["pnl_pct_equity"],
            "new_equity_usd": sc["new_equity_usd"],
            "severity": sc["severity"],
        }

    by_kind: dict[str, list[str]] = {}
    severity_counts: dict[str, int] = {
        "SAFE": 0, "WARNING": 0, "DANGEROUS": 0, "CRITICAL": 0, "UNKNOWN": 0,
    }
    for s in scenarios:
        by_kind.setdefault(s["kind"], []).append(s["name"])
        severity_counts[s["severity"]] = severity_counts.get(s["severity"], 0) + 1

    summary = {
        "worst_loss": _slim(worst_loss),
        "best_gain": _slim(best_gain),
        "by_kind": by_kind,
        "severity_counts": severity_counts,
    }

    return {
        "scenarios": scenarios,
        "summary": summary,
        # Kept for backward-compat with earlier consumers.
        "worst_case": {
            "name": worst_loss["name"] if worst_loss else None,
            "pnl_pct_equity": worst_loss["pnl_pct_equity"] if worst_loss else None,
        },
        "context": {
            "btc_index_price": spot,
            "equity_usd": equity_usd,
            "position_count": sample_size,
            "as_of_ms": now_ms,
            "scenario_count": len(scenarios),
            "severity_thresholds_pct": SEVERITY_THRESHOLDS_PCT,
        },
        "pricing": pricing_counts,
        "computed_at": int(time.time()),
    }


if __name__ == "__main__":
    # Live smoke against the real Deribit account: pull positions + spot +
    # cross-margin equity, run all scenarios, print a compact summary then JSON.
    from portfolio_analysis_AI_Agent.tools.datafetch.positions.get_positions import get_positions
    from portfolio_analysis_AI_Agent.tools.datafetch.account.get_account_summaries import get_account_summaries
    from portfolio_analysis_AI_Agent.tools.datafetch.market.get_index_price import get_index_price

    pos = get_positions()
    summary = get_account_summaries()
    spot = float(get_index_price()["index_price"])
    equity_btc = float(summary.get("equity") or 0.0)
    # Cross-margin total when available (BTC + USDT + USDC + ...).
    # Falls back to BTC-only × spot for single-currency accounts.
    equity_usd = summary.get("total_equity_usd")
    if not equity_usd:
        equity_usd = equity_btc * spot if (equity_btc and spot) else None

    eq_str = f"${equity_usd:,.2f}" if equity_usd else "unknown"
    src = summary.get("cross_totals_source", "n/a")
    print(f"positions: {pos['count']}   spot: ${spot:,.2f}   "
          f"BTC equity: {equity_btc:.6f}   total equity: {eq_str}  "
          f"(source: {src}, currencies: {len(summary.get('cross_totals_factors') or {})})")

    out = stress_scenarios(
        positions=pos["positions"],
        btc_index_price=spot,
        equity_usd=equity_usd,
    )

    print(f"\npricing: {out['pricing']}")
    print(f"severity counts: {out['summary']['severity_counts']}")
    if out["summary"]["worst_loss"]:
        wl = out["summary"]["worst_loss"]
        print(f"worst loss: {wl['display_label']:35s}  "
              f"{wl['pnl_pct_equity']:+.2f}%  ({wl['severity']})")
    if out["summary"]["best_gain"]:
        bg = out["summary"]["best_gain"]
        print(f"best gain:  {bg['display_label']:35s}  "
              f"{bg['pnl_pct_equity']:+.2f}%")

    # Per-scenario table, grouped by kind for a dashboard-style view.
    print()
    hdr = f"{'scenario':35s} {'new_spot':>11s} {'pnl_usd':>12s} {'pnl_%eq':>9s} {'new_eq_usd':>13s}  severity"
    print(hdr)
    print("-" * len(hdr))
    for kind, names in out["summary"]["by_kind"].items():
        print(f"--- kind: {kind} ---")
        for name in names:
            sc = next(s for s in out["scenarios"] if s["name"] == name)
            pct = f"{sc['pnl_pct_equity']:+8.4f}%" if sc['pnl_pct_equity'] is not None else "     -    "
            neq = f"${sc['new_equity_usd']:>11,.2f}" if sc['new_equity_usd'] is not None else "     -      "
            print(f"{sc['display_label']:35s} ${sc['new_btc_index_price']:>10,.2f} "
                  f"{sc['pnl_usd']:+12,.2f} {pct:>9s} {neq:>13s}  {sc['severity']}")

    # Full JSON dump (trim per-scenario positions to first 3 for readability).
    print("\nfull output (positions trimmed to 3/scenario):")
    trimmed = {
        **out,
        "scenarios": [
            {**sc, "positions": sc["positions"][:3], "positions_shown": 3,
             "positions_total": len(sc["positions"])}
            for sc in out["scenarios"]
        ],
    }
    print(json.dumps(trimmed, indent=2, default=str))

# Run from Digital-Ocean-Server:
#   python -m portfolio_analysis_AI_Agent.tools.analysis.stress_scenarios
