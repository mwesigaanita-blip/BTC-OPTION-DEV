"""Tool: analysis.compute_realized_volatility

Pure computation: rolling annualized realized volatility (RVOL) from a
daily close-price series. Used by the BTC Volatility dashboard to
generate the 30-day and 90-day realized-vol time series that feed the
RVOL-vs-IVOL chart and the IVOL-premium chart.

Method:
- Daily log returns: ``ln(P_t / P_{t-1})``
- Rolling sample stdev over ``window`` observations
- Annualize by ``sqrt(365)`` for crypto (24/7 calendar) — matches Deribit
  historical-vol convention.

Output dict::

    {
      window: int,
      annualization_days: int,
      rows: [{date, rvol_pct: float|None}, ...],   # ASC by date
      count: int,
      latest: float|None,
    }
"""
from __future__ import annotations

import json
from typing import Any, Iterable, Mapping, Optional

import numpy as np
import pandas as pd


def _to_series(data: Any) -> pd.Series:
    if isinstance(data, pd.Series):
        s = data.copy()
    elif isinstance(data, Mapping):
        s = pd.Series(dict(data), dtype=float)
    elif isinstance(data, Iterable):
        items = list(data)
        if not items:
            return pd.Series(dtype=float)
        if isinstance(items[0], Mapping):
            s = pd.Series(
                [float(r["close"]) for r in items],
                index=[r["date"] for r in items],
                dtype=float,
            )
        else:
            raise TypeError("iterable must contain {date, close} dicts")
    else:
        raise TypeError(f"unsupported series input: {type(data).__name__}")

    if not isinstance(s.index, pd.DatetimeIndex):
        s.index = pd.to_datetime(s.index, errors="coerce")
    return s.dropna().sort_index()


def compute_realized_volatility(
    closes: Any,
    window: int = 30,
    annualization_days: int = 365,
    min_periods: Optional[int] = None,
) -> dict:
    """Rolling annualized realized vol (in %) from daily closes."""
    s = _to_series(closes)
    if s.empty or len(s) < 2:
        return {
            "window": int(window),
            "annualization_days": int(annualization_days),
            "rows": [],
            "count": 0,
            "latest": None,
        }

    if min_periods is None:
        min_periods = max(2, int(window) // 2)

    log_ret = np.log(s / s.shift(1))
    rolling_std = log_ret.rolling(window=int(window), min_periods=int(min_periods)).std()
    rvol_pct = rolling_std * (float(annualization_days) ** 0.5) * 100.0

    rows = [
        {
            "date": ts.strftime("%Y-%m-%d"),
            "rvol_pct": None if pd.isna(v) else float(v),
        }
        for ts, v in rvol_pct.items()
    ]
    non_null = [r["rvol_pct"] for r in rows if r["rvol_pct"] is not None]

    return {
        "window": int(window),
        "annualization_days": int(annualization_days),
        "rows": rows,
        "count": len(rows),
        "latest": non_null[-1] if non_null else None,
    }


if __name__ == "__main__":
    # Tiny synthetic demo
    idx = pd.date_range("2026-01-01", periods=120, freq="D")
    rng = np.random.default_rng(0)
    s = 100.0 * np.exp(np.cumsum(rng.standard_normal(120) * 0.02))
    out = compute_realized_volatility(pd.Series(s, index=idx), window=30)
    print(json.dumps({**out, "rows": out["rows"][:3] + ["…"] + out["rows"][-3:]},
                     indent=2, default=str))

# Run from Digital-Ocean-Server:
#   python -m portfolio_analysis_AI_Agent.tools.analysis.compute_realized_volatility
