"""Tool: analysis.greeks.compute

Pure-math classifier. Reads the **account-level** Greeks from a Deribit
account-summary payload (the source of truth - Deribit applies
portfolio-margin offsets/netting that simple per-position sums do NOT
reproduce) and classifies the book per Greek.

Inputs are shaped like the output of `datafetch.account.get_account_summary`:
    {
      "equity": <BTC>,
      "delta_total":  <full book delta, options + futures>,
      "options_delta":<options-only delta>,
      "options_gamma":<options gamma>,
      "options_vega": <options vega>,
      "options_theta":<options theta>,
      ...
    }

Output convention:
- delta is reported both in BTC units (raw) and USD equivalent.
- gamma/vega/theta classifications use percent-of-equity if equity > 0,
  else absolute bands.
"""

from __future__ import annotations

import json
import time
from typing import Any

DEFAULT_THRESHOLDS: dict[str, dict[str, float]] = {
    "delta_usd_abs_per_equity_usd": {"warning": 0.5, "dangerous": 1.0, "critical": 2.0},
    "gamma_abs": {"warning": 0.001, "dangerous": 0.005, "critical": 0.01},
    "vega_abs_pct_equity": {"warning": 10.0, "dangerous": 30.0, "critical": 60.0},
    "theta_pct_equity_daily": {"warning": 0.5, "dangerous": 1.0, "critical": 2.0},
}


def _f(x: Any, default: float = 0.0) -> float:
    try:
        return float(x) if x is not None else default
    except (TypeError, ValueError):
        return default


def _band(value: float, t: dict[str, float]) -> str:
    if value >= t["critical"]:
        return "CRITICAL"
    if value >= t["dangerous"]:
        return "DANGEROUS"
    if value >= t["warning"]:
        return "WARNING"
    return "SAFE"


def greeks_compute(
    account_summary: dict,
    btc_index_price: float | None = None,
    thresholds: dict[str, dict[str, float]] | None = None,
) -> dict:
    """Classify the account's Greeks exposure.

    Args:
        account_summary: shape from `datafetch.account.get_account_summary`.
            Must contain at least `equity` and the `delta_total` /
            `options_gamma` / `options_vega` / `options_theta` fields.
        btc_index_price: current BTC index price; needed for the USD-delta
            classification. If None, the delta band falls back to the
            absolute BTC threshold (treated as USD-per-equity = 0).
        thresholds: optional override map; missing keys fall back to
            defaults.

    Returns:
        Structured classification + per-Greek sub-classifications:
          {"totals": {"delta_btc", "delta_usd", "gamma", "vega", "theta"},
           "context": {..., "equity_usd": ...}, ...}
    """
    t = {**DEFAULT_THRESHOLDS, **(thresholds or {})}
    acct = account_summary or {}

    # Account-level Greeks (the reference).
    delta_btc = _f(acct.get("delta_total"))           # full book (options + futures)
    options_delta = _f(acct.get("options_delta"))      # options-only, kept for context
    gamma = _f(acct.get("options_gamma"))              # futures contribute zero gamma
    vega = _f(acct.get("options_vega"))                # futures contribute zero vega
    theta = _f(acct.get("options_theta"))              # futures contribute zero theta

    equity_btc = _f(acct.get("equity"))
    idx = _f(btc_index_price)
    # Cross-margin first: when the input came from `get_account_summaries`,
    # `total_equity_usd` is the real account equity in USD across all
    # collateral currencies (BTC + USDT + USDC + ...). Single-currency
    # `equity × spot` underreports a cross-margin account.
    total_equity_usd = _f(acct.get("total_equity_usd"))
    if total_equity_usd > 0:
        equity_usd = total_equity_usd
        equity_source = "cross_margin_usd"
    else:
        equity_usd = equity_btc * idx if equity_btc and idx else 0.0
        equity_source = "currency_equity_times_spot"

    delta_usd = delta_btc * idx if idx else 0.0
    delta_usd_per_equity = (abs(delta_usd) / equity_usd) if equity_usd > 0 else 0.0

    gamma_abs = abs(gamma)
    vega_abs_pct_eq = (abs(vega) / equity_usd * 100.0) if equity_usd > 0 else 0.0
    theta_abs_pct_eq = (abs(theta) / equity_usd * 100.0) if equity_usd > 0 else 0.0

    sub = {
        "delta": _band(delta_usd_per_equity, t["delta_usd_abs_per_equity_usd"]),
        "gamma": _band(gamma_abs, t["gamma_abs"]),
        "vega": _band(vega_abs_pct_eq, t["vega_abs_pct_equity"]),
        "theta": _band(theta_abs_pct_eq, t["theta_pct_equity_daily"]),
    }
    rank = {"SAFE": 0, "WARNING": 1, "DANGEROUS": 2, "CRITICAL": 3}
    overall = max(sub.values(), key=lambda v: rank[v])

    return {
        "classification": overall,
        "totals": {
            "delta_btc": round(delta_btc, 6),
            "delta_usd": round(delta_usd, 2),
            "gamma": round(gamma, 6),
            "vega": round(vega, 4),
            "theta": round(theta, 4),
        },
        "context": {
            "source": "account_summary",
            "equity_source": equity_source,
            "btc_index_price": idx or None,
            "equity_btc": equity_btc or None,
            "equity_usd": round(equity_usd, 2) if equity_usd else None,
            "options_delta": round(options_delta, 6),
            "futures_delta_implied": round(delta_btc - options_delta, 6),
            "delta_usd_per_equity": round(delta_usd_per_equity, 4),
            "gamma_abs": round(gamma_abs, 6),
            "vega_abs_pct_equity": round(vega_abs_pct_eq, 4),
            "theta_abs_pct_equity": round(theta_abs_pct_eq, 4),
        },
        "sub_classifications": sub,
        "thresholds_used": t,
        "computed_at": int(time.time()),
    }


if __name__ == "__main__":
    sample_account = {
        "equity": 1.008,
        "delta_total": 0.32,
        "options_delta": 0.18,
        "options_gamma": -3e-5,
        "options_vega": -670,
        "options_theta": 72,
    }
    print(json.dumps(greeks_compute(sample_account, btc_index_price=81000.0), indent=2, default=str))

# Run from Digital-Ocean-Server:
#   python -m portfolio_analysis_AI_Agent.tools.analysis.greeks_compute
