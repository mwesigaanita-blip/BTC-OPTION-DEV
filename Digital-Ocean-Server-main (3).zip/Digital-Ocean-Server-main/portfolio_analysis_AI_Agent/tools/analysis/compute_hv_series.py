"""Tool: analysis.compute_hv_series

Rolling annualized historical-volatility from a close-price series.

Two flavours:

* :func:`compute_hv_series` - pure math; takes ``closes`` + ``ticks_ms`` and
  returns ``[(ts_ms, hv_pct), ...]``.
* :func:`compute_hv_from_deribit` - convenience wrapper: pulls BTC perp
  candles with :func:`get_btc_index_candles` and returns hourly or daily
  rolling-30d HV.

HV definition: stdev of natural-log returns over ``window_bars`` bars,
multiplied by ``sqrt(bars_per_year)`` and 100 (so the output is in
annualized percent, matching Deribit's HV scale).

Known bias: using ``BTC-PERPETUAL`` closes rather than the multi-exchange
BTC index gives a measured +2 pp mean bias vs Deribit's HV series (max
~6 pp single-point). Acceptable for charting purposes; the hybrid strategy
in :mod:`hv_iv_series` uses Deribit's authoritative HV for the most recent
~16 days and falls back to this for older history.
"""

from __future__ import annotations

import json
import math
from typing import Sequence

from portfolio_analysis_AI_Agent.tools.datafetch.market.get_btc_index_candles import (
    get_btc_index_candles,
)
from datetime import datetime, timezone


_BARS_PER_YEAR = {
    "60": 24.0 * 365.0,
    "1D": 365.0,
}


def compute_hv_series(
    closes: Sequence[float],
    ticks_ms: Sequence[int],
    *,
    window_bars: int,
    bars_per_year: float,
) -> list[tuple[int, float]]:
    """Rolling annualized stdev of log returns (returns annualized %).

    Output length is ``max(0, len(closes) - window_bars)`` - first
    ``window_bars`` bars are the warm-up.
    """
    if len(closes) != len(ticks_ms):
        raise ValueError("closes and ticks_ms must be the same length")
    n = len(closes)
    if n <= window_bars:
        return []

    log_ret: list[float] = [0.0] * (n - 1)
    for i in range(1, n):
        c0, c1 = float(closes[i - 1]), float(closes[i])
        if c0 > 0 and c1 > 0:
            log_ret[i - 1] = math.log(c1 / c0)

    factor = math.sqrt(bars_per_year) * 100.0
    out: list[tuple[int, float]] = []
    # Rolling stdev (population-corrected, ddof=1) over `window_bars` returns.
    # Window covers log_ret indices [i-window_bars : i], producing the HV
    # value timestamped at ticks_ms[i].
    for i in range(window_bars, n):
        window = log_ret[i - window_bars : i]
        mean = sum(window) / window_bars
        var = sum((r - mean) ** 2 for r in window) / (window_bars - 1)
        sd = math.sqrt(var) if var > 0 else 0.0
        out.append((int(ticks_ms[i]), sd * factor))
    return out


def _compute_daily_hv_from_db(days: int) -> list[dict]:
    """Rolling 30-day HV derived from ``btc_prices`` daily closes.

    The table is the canonical BTC price history (back to ~2010, pre-Deribit
    portion is real spot/index data). It has gaps - some days are missing -
    so a naive close-to-close stdev across all rows treats a 7-day gap as a
    1-day return and overstates volatility by 20+ percentage points.

    Fix: only count log returns between rows that are **exactly one
    calendar day apart**. Other transitions are dropped. The rolling
    window of 30 then represents "30 consecutive-day returns", which on
    a dense series is the same as "30 calendar days". The annualization
    factor (sqrt(365)) is left as-is - the empirical bias against
    Deribit's HV on the overlap window is ~0.2pp, well within chart
    resolution.
    """
    from shared.data_service import get_btc_prices_full

    df = get_btc_prices_full()
    if df.empty:
        return []
    df = df.sort_values("date").reset_index(drop=True)
    keep_n = min(len(df), days + 90)  # extra warmup pad to absorb gaps
    df = df.tail(keep_n)

    # Parse rows -> (date, ts_ms, close)
    parsed: list[tuple[datetime, int, float]] = []
    for date_str, close in zip(df["date"].tolist(), df["close"].tolist()):
        try:
            d = datetime.fromisoformat(str(date_str)).replace(tzinfo=timezone.utc)
            c = float(close)
        except (TypeError, ValueError):
            continue
        if c > 0:
            parsed.append((d, int(d.timestamp() * 1000), c))

    # Gap-aware log returns: only valid where today and yesterday are
    # consecutive calendar days.
    valid_log_ret: list[tuple[int, float]] = []  # (ts_ms_of_today, log_ret)
    for i in range(1, len(parsed)):
        d_prev, _, c_prev = parsed[i - 1]
        d_cur,  ts_cur, c_cur = parsed[i]
        if (d_cur.date() - d_prev.date()).days != 1:
            continue
        valid_log_ret.append((ts_cur, math.log(c_cur / c_prev)))

    # Rolling 30-bar stdev over the cleaned returns. Each HV point is
    # timestamped at the most recent return in its window.
    window = 30
    factor = math.sqrt(365.0) * 100.0
    out: list[dict] = []
    for i in range(window, len(valid_log_ret) + 1):
        win = [r for _, r in valid_log_ret[i - window : i]]
        m = sum(win) / window
        var = sum((r - m) ** 2 for r in win) / (window - 1)
        sd = math.sqrt(var) if var > 0 else 0.0
        ts_ms = valid_log_ret[i - 1][0]
        out.append({"ts_ms": ts_ms, "hv_pct": sd * factor})
    return out


def compute_hv_from_deribit(
    *, days: int, resolution: str = "60",
) -> list[dict]:
    """Convenience: return ``days`` of rolling-30d HV.

    For daily resolution (``"1D"``), reads BTC closes from the
    ``btc_prices`` DB table - much deeper history (back to ~2010) and no
    Deribit calls. The historical portion of that table is real spot,
    which materially reduces the bias vs Deribit's index-based HV.

    For hourly resolution (``"60"``), falls back to Deribit perp candles
    (the DB is daily-only). Adds a 30-day warm-up internally so the
    returned series starts at ``now - days``.

    Returns ``[{ts_ms, hv_pct}, ...]`` chronologically.
    """
    if resolution not in _BARS_PER_YEAR:
        raise ValueError(f"unsupported resolution: {resolution!r} (use '60' or '1D')")

    if resolution == "1D":
        # Gap-aware HV from btc_prices DB. The table has occasional missing
        # days locally; on the server `btc_prices` is dense so this path
        # produces a continuous daily HV with ~1pp bias vs Deribit.
        return _compute_daily_hv_from_db(days)

    # Hourly path - keep using perp candles (DB is daily-only).
    window_bars = 30 * 24
    warmup_days = 32
    candles = get_btc_index_candles(resolution=resolution, days=days + warmup_days)
    series = compute_hv_series(
        candles["close"], candles["ticks_ms"],
        window_bars=window_bars,
        bars_per_year=_BARS_PER_YEAR[resolution],
    )
    return [{"ts_ms": t, "hv_pct": v} for t, v in series]


if __name__ == "__main__":
    rows = compute_hv_from_deribit(days=30, resolution="60")
    print(json.dumps({
        "n": len(rows),
        "first": rows[0] if rows else None,
        "last":  rows[-1] if rows else None,
    }, indent=2))

# Run from Digital-Ocean-Server:
#   python -m portfolio_analysis_AI_Agent.tools.analysis.compute_hv_series
