"""Tool: analysis.max_pain

Pure-math. Consumes datafetch.market.get_book_summary output and computes the
max-pain strike for the next N expiries - the strike where the most
open-interest value would expire worthless.

For each candidate strike K of an expiry:
    pain(K) = Σ_calls OI_call * max(K - strike_call, 0)
            + Σ_puts  OI_put  * max(strike_put - K, 0)
The strike minimizing pain is the max-pain point.
"""

from __future__ import annotations

import json
import time
from typing import Any


def _f(x: Any, default: float = 0.0) -> float:
    try:
        return float(x) if x is not None else default
    except (TypeError, ValueError):
        return default


def _expiry_from_name(name: str) -> str:
    parts = (name or "").split("-")
    return parts[1] if len(parts) >= 4 else "unknown"


def _strike_from_name(name: str) -> float | None:
    parts = (name or "").split("-")
    if len(parts) < 4:
        return None
    try:
        return float(parts[2])
    except ValueError:
        return None


def _option_type_from_name(name: str) -> str | None:
    if name.endswith("-C"):
        return "C"
    if name.endswith("-P"):
        return "P"
    return None


def max_pain(book_summary: dict, btc_spot: float | None = None, top_expiries: int = 3, pin_window_pct: float = 2.0) -> dict:
    """Returns per-expiry max-pain strike + global summary."""
    rows = (book_summary or {}).get("rows") or []

    by_exp: dict[str, list[tuple[float, str, float]]] = {}  # exp -> [(strike, C/P, oi)]
    for row in rows:
        name = str(row.get("instrument_name") or "")
        opt_type = _option_type_from_name(name)
        strike = _strike_from_name(name)
        if not opt_type or strike is None:
            continue
        oi = _f(row.get("open_interest"))
        if oi <= 0:
            continue
        exp = _expiry_from_name(name)
        by_exp.setdefault(exp, []).append((strike, opt_type, oi))

    spot = _f(btc_spot) if btc_spot is not None else None
    results: list[dict] = []

    for exp, entries in by_exp.items():
        strikes = sorted({s for s, _, _ in entries})
        if len(strikes) < 2:
            continue
        best_K = None
        best_pain = None
        for K in strikes:
            pain = 0.0
            for s, typ, oi in entries:
                if typ == "C":
                    pain += oi * max(K - s, 0.0)
                else:
                    pain += oi * max(s - K, 0.0)
            if best_pain is None or pain < best_pain:
                best_pain = pain
                best_K = K

        dist_pct = None
        pin_flag = False
        if spot and best_K is not None and spot > 0:
            dist_pct = (best_K - spot) / spot * 100.0
            pin_flag = abs(dist_pct) <= pin_window_pct

        results.append({
            "expiry": exp,
            "max_pain_strike": best_K,
            "pain_value": best_pain,
            "spot_distance_pct": round(dist_pct, 4) if dist_pct is not None else None,
            "pinning_risk_flag": pin_flag,
            "strike_count": len(strikes),
        })

    # Sort by expiry string (alphabetic isn't temporal-correct, but kept simple); cap to top_expiries
    results.sort(key=lambda x: x["expiry"])
    results = results[:top_expiries]

    return {
        "btc_spot": spot,
        "pin_window_pct": pin_window_pct,
        "expiries": results,
        "computed_at": int(time.time()),
    }


if __name__ == "__main__":
    sample = {"rows": [
        {"instrument_name": "BTC-30MAY26-70000-C", "open_interest": 100},
        {"instrument_name": "BTC-30MAY26-80000-C", "open_interest": 200},
        {"instrument_name": "BTC-30MAY26-90000-C", "open_interest": 50},
        {"instrument_name": "BTC-30MAY26-70000-P", "open_interest": 80},
        {"instrument_name": "BTC-30MAY26-80000-P", "open_interest": 150},
        {"instrument_name": "BTC-30MAY26-90000-P", "open_interest": 30},
    ]}
    print(json.dumps(max_pain(sample, btc_spot=81000), indent=2, default=str))

# Run from Digital-Ocean-Server:
#   python -m portfolio_analysis_AI_Agent.tools.analysis.max_pain
