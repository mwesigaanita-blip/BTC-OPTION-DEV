"""Tool: analysis.compute_period_returns

Pure computation: multi-horizon % returns for a single asset's close
series. Used by every grid of the Daily Quant dashboard and reusable by
the AI agent for ad-hoc "how did X do over Y" questions.

Horizons (calendar-day lookbacks; the closest available close on or
before ``asof - days`` is used, which gracefully handles weekend gaps
for equities):

    1D, 5D, 1M (≈30d), 3M (≈91d), 6M (≈182d), 1Y (≈365d), QTD, YTD,
    plus 52W_HIGH_PCT and 52W_LOW_PCT distances.

Input is flexible:
  - a pandas ``Series`` indexed by datetime, OR
  - a list of ``{"date": "YYYY-MM-DD", "close": float}`` dicts, OR
  - a mapping ``{"YYYY-MM-DD": float}``.
"""
from __future__ import annotations

import json
from datetime import date
from typing import Any, Iterable, Optional

import pandas as pd


HORIZON_DAYS: dict[str, int] = {
    "1D":  1,
    "5D":  5,
    "1M":  30,
    "3M":  91,
    "6M":  182,
    "1Y":  365,
}

HORIZON_KEYS: list[str] = list(HORIZON_DAYS.keys()) + [
    "QTD", "YTD", "52W_HIGH_PCT", "52W_LOW_PCT",
]


def _to_series(data: Any) -> pd.Series:
    if isinstance(data, pd.Series):
        s = data.copy()
    elif isinstance(data, dict):
        s = pd.Series(data, dtype=float)
    elif isinstance(data, Iterable):
        items = list(data)
        if not items:
            return pd.Series(dtype=float)
        if isinstance(items[0], dict):
            s = pd.Series(
                [float(r["close"]) for r in items],
                index=[r["date"] for r in items],
                dtype=float,
            )
        else:
            raise TypeError("iterable must contain {date, close} dicts")
    else:
        raise TypeError(f"unsupported series input: {type(data).__name__}")

    if not isinstance(s.index, pd.DatetimeIndex):
        s.index = pd.to_datetime(s.index, errors="coerce")
    return s.dropna().sort_index()


def _pct(curr: float, ref: Optional[float]) -> Optional[float]:
    if ref is None or pd.isna(ref) or ref == 0:
        return None
    if curr is None or pd.isna(curr):
        return None
    return (float(curr) / float(ref) - 1.0) * 100.0


def _closest_on_or_before(series: pd.Series, target: pd.Timestamp) -> Optional[float]:
    if series.empty:
        return None
    sub = series.loc[series.index <= target]
    if sub.empty:
        return None
    return float(sub.iloc[-1])


def _quarter_start(d: date) -> date:
    q_month = ((d.month - 1) // 3) * 3 + 1
    return date(d.year, q_month, 1)


def compute_period_returns(
    series: Any,
    asof: Optional[date | str] = None,
) -> dict[str, Optional[float]]:
    """Return ``{horizon: pct_change}`` for ``series`` as of ``asof``.

    ``asof`` defaults to the series' last date. Pass a ``date`` or an
    ISO ``YYYY-MM-DD`` string. Missing/insufficient data yields ``None``
    (never raises) so a grid can render the cell as empty.
    """
    out: dict[str, Optional[float]] = {k: None for k in HORIZON_KEYS}

    s = _to_series(series)
    if s.empty:
        return out

    if asof is None:
        asof_ts = s.index[-1]
    elif isinstance(asof, str):
        asof_ts = pd.Timestamp(asof)
    else:
        asof_ts = pd.Timestamp(asof)

    curr = _closest_on_or_before(s, asof_ts)
    if curr is None:
        return out

    for label, days in HORIZON_DAYS.items():
        out[label] = _pct(curr, _closest_on_or_before(s, asof_ts - pd.Timedelta(days=days)))

    asof_d = asof_ts.date()
    q_start = _quarter_start(asof_d)
    out["QTD"] = _pct(curr, _closest_on_or_before(s, pd.Timestamp(q_start) - pd.Timedelta(days=1)))
    y_start = date(asof_d.year, 1, 1)
    out["YTD"] = _pct(curr, _closest_on_or_before(s, pd.Timestamp(y_start) - pd.Timedelta(days=1)))

    window = s.loc[(s.index <= asof_ts) & (s.index > asof_ts - pd.Timedelta(days=365))]
    if not window.empty:
        out["52W_HIGH_PCT"] = _pct(curr, float(window.max()))
        out["52W_LOW_PCT"]  = _pct(curr, float(window.min()))

    return out


def relative_returns(
    base: dict[str, Optional[float]],
    vs: dict[str, Optional[float]],
) -> dict[str, Optional[float]]:
    """Subtract two return dicts horizon-by-horizon. ``None`` propagates."""
    out: dict[str, Optional[float]] = {}
    for k in base:
        a, b = base.get(k), vs.get(k)
        out[k] = None if (a is None or b is None) else (float(a) - float(b))
    return out


if __name__ == "__main__":
    demo = [
        {"date": "2025-05-24", "close": 100.0},
        {"date": "2025-12-31", "close": 130.0},
        {"date": "2026-03-31", "close": 140.0},
        {"date": "2026-05-23", "close": 152.0},
        {"date": "2026-05-24", "close": 150.0},
    ]
    print(json.dumps(compute_period_returns(demo), indent=2))

# Run from Digital-Ocean-Server:
#   python -m portfolio_analysis_AI_Agent.tools.analysis.compute_period_returns
