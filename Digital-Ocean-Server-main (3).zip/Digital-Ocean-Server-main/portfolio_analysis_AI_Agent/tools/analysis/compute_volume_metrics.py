"""Tool: analysis.compute_volume_metrics

Pure computation: aggregate volume metrics for a single asset, matching
the Hedgeye-style "VOLUME" panel:

- **D/D %**       = today vs yesterday
- **vs 1M Avg**   = today vs the 30-day trailing mean
- **vs 3M Avg**   = today vs the 90-day trailing mean
- **Y/Y (Qtrly)** = last 90d trailing mean vs the same 90d window one year ago

Each metric is computed twice: once on raw coin volume, once on
``close * volume`` (USD volume). Both are reported as % changes.

Input shape (a list of dicts), produced by ``get_quant_close_series`` or
similar pipelines::

    [{"date": "YYYY-MM-DD", "close": float, "volume": float}, ...]

Output dict::

    {
      asof: "YYYY-MM-DD",
      coin: {dd_pct, vs_1m_pct, vs_3m_pct, yy_qtrly_pct},
      usd:  {dd_pct, vs_1m_pct, vs_3m_pct, yy_qtrly_pct},
      coin_today, usd_today,
      count: int,
    }
"""
from __future__ import annotations

import json
from typing import Iterable, Mapping, Optional

import pandas as pd


def _build_frame(rows: Iterable[Mapping]) -> pd.DataFrame:
    items = list(rows)
    if not items:
        return pd.DataFrame(columns=["close", "volume", "usd_volume"])
    df = pd.DataFrame(items)
    if "date" not in df.columns or "close" not in df.columns:
        return pd.DataFrame(columns=["close", "volume", "usd_volume"])
    df["date"] = pd.to_datetime(df["date"], errors="coerce")
    df = df.dropna(subset=["date"]).sort_values("date").set_index("date")
    # Ensure numeric.
    df["close"] = pd.to_numeric(df.get("close"), errors="coerce")
    if "volume" in df.columns:
        df["volume"] = pd.to_numeric(df["volume"], errors="coerce")
    else:
        df["volume"] = 0.0
    df = df.dropna(subset=["close"])
    df["volume"] = df["volume"].fillna(0.0)
    df["usd_volume"] = df["close"] * df["volume"]
    return df


def _pct(curr: Optional[float], ref: Optional[float]) -> Optional[float]:
    if curr is None or ref is None or pd.isna(curr) or pd.isna(ref):
        return None
    if ref == 0:
        return None
    return (float(curr) / float(ref) - 1.0) * 100.0


def _metrics_for(series: pd.Series) -> dict:
    """Compute the four headline metrics for one volume series (date-indexed)."""
    out = {"dd_pct": None, "vs_1m_pct": None, "vs_3m_pct": None, "yy_qtrly_pct": None}
    if series.empty:
        return out

    today = float(series.iloc[-1])
    if today == 0 or pd.isna(today):
        return out

    if len(series) >= 2:
        prev = float(series.iloc[-2])
        out["dd_pct"] = _pct(today, prev)

    # Trailing means over the last 30 / 90 calendar days (inclusive of today).
    last_date = series.index[-1]
    last_30 = series.loc[series.index > last_date - pd.Timedelta(days=30)]
    last_90 = series.loc[series.index > last_date - pd.Timedelta(days=90)]
    if not last_30.empty:
        out["vs_1m_pct"] = _pct(today, float(last_30.mean()))
    if not last_90.empty:
        out["vs_3m_pct"] = _pct(today, float(last_90.mean()))

    # Y/Y (Qtrly): current 90d avg vs the 90d window ending one year ago.
    a_year_ago = last_date - pd.Timedelta(days=365)
    yoy_window = series.loc[
        (series.index <= a_year_ago) & (series.index > a_year_ago - pd.Timedelta(days=90))
    ]
    if not last_90.empty and not yoy_window.empty:
        out["yy_qtrly_pct"] = _pct(float(last_90.mean()), float(yoy_window.mean()))

    return out


def compute_volume_metrics(rows: Iterable[Mapping]) -> dict:
    """Compute coin + USD volume metrics from a daily OHLCV series."""
    df = _build_frame(rows)
    if df.empty:
        return {
            "asof": None,
            "coin": {"dd_pct": None, "vs_1m_pct": None, "vs_3m_pct": None, "yy_qtrly_pct": None},
            "usd":  {"dd_pct": None, "vs_1m_pct": None, "vs_3m_pct": None, "yy_qtrly_pct": None},
            "coin_today": None,
            "usd_today": None,
            "count": 0,
        }

    coin = _metrics_for(df["volume"])
    usd = _metrics_for(df["usd_volume"])

    return {
        "asof": df.index[-1].strftime("%Y-%m-%d"),
        "coin": coin,
        "usd":  usd,
        "coin_today": float(df["volume"].iloc[-1]),
        "usd_today":  float(df["usd_volume"].iloc[-1]),
        "count": int(len(df)),
    }


if __name__ == "__main__":
    import numpy as np
    rng = np.random.default_rng(0)
    idx = pd.date_range("2025-05-23", "2026-05-23", freq="D")
    closes = 80_000 + np.cumsum(rng.standard_normal(len(idx)) * 800)
    volumes = 20_000 + rng.standard_normal(len(idx)) * 4_000
    rows = [
        {"date": d.strftime("%Y-%m-%d"), "close": float(c), "volume": float(v)}
        for d, c, v in zip(idx, closes, volumes)
    ]
    print(json.dumps(compute_volume_metrics(rows), indent=2, default=str))

# Run from Digital-Ocean-Server:
#   python -m portfolio_analysis_AI_Agent.tools.analysis.compute_volume_metrics
