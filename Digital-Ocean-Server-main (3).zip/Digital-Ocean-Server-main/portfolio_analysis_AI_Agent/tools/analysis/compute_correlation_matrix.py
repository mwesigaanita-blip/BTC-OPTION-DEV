"""Tool: analysis.compute_correlation_matrix

Pure computation: Pearson correlation of daily % returns across a set of
assets over a calendar-day lookback. Powers the macro-crypto correlation
matrix on the BTC Prices page and is reusable by the AI agent for ad-hoc
"how correlated is X with Y over Z days" questions.

Pairwise NaN handling: when two assets trade on different calendars
(e.g. BTC trades weekends, SPX does not), the correlation is computed
on the intersection of dates where BOTH have a return. Pandas'
``DataFrame.corr()`` does this natively.

Input is flexible. Each per-asset series can be:
  - a pandas ``Series`` indexed by datetime, OR
  - a list of ``{"date": "YYYY-MM-DD", "close": float}`` dicts, OR
  - a mapping ``{"YYYY-MM-DD": float}``.

Output dict::

    {
      assets: [...],                # ordered list (same as input order)
      window_days: int,             # calendar-day lookback used
      asof: "YYYY-MM-DD"|None,      # last date considered
      matrix: {a: {b: float|None}}, # correlations (-1.0..+1.0), diagonal = 1.0
      sample_counts: {a: {b: int}}, # overlapping observations per pair
    }
"""
from __future__ import annotations

import json
from datetime import date
from typing import Any, Iterable, Mapping, Optional

import pandas as pd


def _to_series(data: Any) -> pd.Series:
    if isinstance(data, pd.Series):
        s = data.copy()
    elif isinstance(data, Mapping):
        s = pd.Series(dict(data), dtype=float)
    elif isinstance(data, Iterable):
        items = list(data)
        if not items:
            return pd.Series(dtype=float)
        if isinstance(items[0], Mapping):
            s = pd.Series(
                [float(r["close"]) for r in items],
                index=[r["date"] for r in items],
                dtype=float,
            )
        else:
            raise TypeError("iterable must contain {date, close} dicts")
    else:
        raise TypeError(f"unsupported series input: {type(data).__name__}")

    if not isinstance(s.index, pd.DatetimeIndex):
        s.index = pd.to_datetime(s.index, errors="coerce")
    return s.dropna().sort_index()


def compute_correlation_matrix(
    series_by_asset: Mapping[str, Any],
    window_days: int = 30,
    asof: Optional[date | str] = None,
) -> dict:
    """Pearson correlation of daily % returns over ``window_days``."""
    assets = list(series_by_asset.keys())
    parsed: dict[str, pd.Series] = {a: _to_series(s) for a, s in series_by_asset.items()}

    # Determine the global as-of date (max last-date across assets).
    if asof is None:
        asof_ts = max((s.index[-1] for s in parsed.values() if not s.empty), default=None)
    elif isinstance(asof, str):
        asof_ts = pd.Timestamp(asof)
    else:
        asof_ts = pd.Timestamp(asof)

    matrix: dict[str, dict[str, Optional[float]]] = {}
    counts: dict[str, dict[str, int]] = {}

    if asof_ts is None:
        # No data at all — return identity-ish skeleton.
        for a in assets:
            matrix[a] = {b: (1.0 if a == b else None) for b in assets}
            counts[a] = {b: 0 for b in assets}
        return {
            "assets": assets,
            "window_days": int(window_days),
            "asof": None,
            "matrix": matrix,
            "sample_counts": counts,
        }

    window_start = asof_ts - pd.Timedelta(days=int(window_days))

    # Compute % returns and trim each to the window.
    returns: dict[str, pd.Series] = {}
    for a, s in parsed.items():
        if s.empty:
            returns[a] = pd.Series(dtype=float)
            continue
        # Slice closes to the window plus one prior day so pct_change has a reference.
        prior_mask = s.index <= window_start
        prior = s.loc[prior_mask]
        # First in-window observation = first index strictly after window_start.
        in_window = s.loc[(s.index > window_start) & (s.index <= asof_ts)]
        if prior.empty and len(in_window) >= 2:
            base = in_window
        elif not prior.empty:
            base = pd.concat([prior.iloc[[-1]], in_window])
        else:
            base = in_window
        returns[a] = base.pct_change().dropna()

    # Build a single DataFrame so .corr() does pairwise overlap correctly.
    df = pd.DataFrame({a: r for a, r in returns.items()})
    corr = df.corr()

    for a in assets:
        matrix[a] = {}
        counts[a] = {}
        for b in assets:
            if a == b:
                matrix[a][b] = 1.0
                counts[a][b] = int(returns[a].dropna().shape[0])
                continue
            sub = df[[a, b]].dropna()
            n = int(sub.shape[0])
            counts[a][b] = n
            if n < 2 or a not in corr.columns or b not in corr.columns:
                matrix[a][b] = None
                continue
            v = corr.at[a, b]
            matrix[a][b] = None if pd.isna(v) else float(v)

    return {
        "assets": assets,
        "window_days": int(window_days),
        "asof": str(asof_ts.date()),
        "matrix": matrix,
        "sample_counts": counts,
    }


if __name__ == "__main__":
    import math
    n = 80
    idx = pd.date_range("2026-01-01", periods=n, freq="D")
    # synthetic: A noisy, B = A + noise, C = -A + noise
    import random
    random.seed(0)
    a = [100.0]
    for _ in range(n - 1):
        a.append(a[-1] * (1.0 + 0.01 * (random.random() - 0.5)))
    b = [x * (1.0 + 0.002 * (random.random() - 0.5)) for x in a]
    c = [100.0 * math.exp(-math.log(x / 100.0)) for x in a]
    s_a = pd.Series(a, index=idx)
    s_b = pd.Series(b, index=idx)
    s_c = pd.Series(c, index=idx)
    out = compute_correlation_matrix({"A": s_a, "B": s_b, "C": s_c}, window_days=30)
    print(json.dumps({**out, "sample_counts": "<omitted>"}, indent=2, default=str))

# Run from Digital-Ocean-Server:
#   python -m portfolio_analysis_AI_Agent.tools.analysis.compute_correlation_matrix
