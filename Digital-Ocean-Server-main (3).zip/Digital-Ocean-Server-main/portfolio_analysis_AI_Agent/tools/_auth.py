"""Shared Deribit auth for AI agent tools.

The ONLY module that other tool files are allowed to import from.
Exposes a cached `get_access_token()` plus `base_url()` and `rpc_url()`.
"""

from __future__ import annotations

import json
import os
import time
from typing import Optional

import requests
from dotenv import load_dotenv

load_dotenv()


class DeribitAuthError(RuntimeError):
    pass


_token: Optional[str] = None
_expires_at: float = 0.0


def base_url() -> str:
    return os.getenv("DERIBIT_BASE_URL", "https://www.deribit.com").rstrip("/")


def rpc_url() -> str:
    return f"{base_url()}/api/v2"


def _token_valid() -> bool:
    return bool(_token) and time.time() < (_expires_at - 15.0)


def invalidate_token() -> None:
    global _token, _expires_at
    _token = None
    _expires_at = 0.0


def get_access_token() -> str:
    """Return a cached Deribit access token (client_credentials flow).

    Refreshes 15s before expiry. Raises DeribitAuthError on failure.
    """
    global _token, _expires_at
    if _token_valid():
        return _token  # type: ignore[return-value]

    client_id = os.getenv("DERIBIT_CLIENT_ID", "").strip()
    client_secret = os.getenv("DERIBIT_CLIENT_SECRET", "").strip()
    if not client_id or not client_secret:
        raise DeribitAuthError(
            "Missing DERIBIT_CLIENT_ID / DERIBIT_CLIENT_SECRET in env"
        )

    payload = {
        "jsonrpc": "2.0",
        "id": 1,
        "method": "public/auth",
        "params": {
            "grant_type": "client_credentials",
            "client_id": client_id,
            "client_secret": client_secret,
        },
    }
    r = requests.post(rpc_url(), json=payload, timeout=10)
    try:
        body = r.json()
    except Exception as e:
        raise DeribitAuthError(f"Auth response not JSON: {r.status_code} {r.text[:200]}") from e

    if body.get("error"):
        raise DeribitAuthError(f"Auth RPC error: {body['error']}")

    result = body.get("result") or {}
    tok = str(result.get("access_token") or "")
    exp = float(result.get("expires_in") or 0)
    if not tok or exp <= 0:
        raise DeribitAuthError(f"Auth result missing token/expires_in: {result}")

    _token = tok
    _expires_at = time.time() + exp
    return tok


# Deribit error codes that mean "the token you presented is dead" - the
# cached token must be dropped and a fresh one obtained before retrying.
_INVALID_TOKEN_CODES = (13009, 13004)


def rpc_call(
    method: str,
    params: Optional[dict] = None,
    *,
    auth: bool = True,
    timeout: float = 15.0,
) -> object:
    """Make a Deribit JSON-RPC call and return its `result`.

    On an invalid-token error (13009 `session_not_found` / 13004) the cached
    token is dropped, a fresh one is fetched, and the call is retried once.
    Any other Deribit error raises `RuntimeError("Deribit error: {...}")`.
    """
    payload = {"jsonrpc": "2.0", "id": 1, "method": method, "params": params or {}}
    for attempt in range(2):
        headers = {}
        if auth:
            headers["Authorization"] = f"Bearer {get_access_token()}"
        r = requests.post(rpc_url(), json=payload, headers=headers, timeout=timeout)
        try:
            body = r.json()
        except Exception as e:
            raise RuntimeError(
                f"Deribit response not JSON: {r.status_code} {r.text[:200]}"
            ) from e

        err = body.get("error")
        if err:
            try:
                code = int(err.get("code") or 0)
            except (TypeError, ValueError):
                code = 0
            msg = str(err.get("message") or "").lower()
            invalid_token = auth and (code in _INVALID_TOKEN_CODES or "invalid_token" in msg)
            if invalid_token and attempt == 0:
                invalidate_token()
                continue
            raise RuntimeError(f"Deribit error: {err}")

        return body.get("result")

    raise RuntimeError("Deribit error: invalid-token retry exhausted")


if __name__ == "__main__":
    tok = get_access_token()
    print(json.dumps({
        "base_url": base_url(),
        "token_prefix": tok[:8] + "..." if tok else None,
        "expires_in_s": int(_expires_at - time.time()),
    }, indent=2))
