"""Tool: datafetch.account.get_account_summary

Calls Deribit `private/get_account_summary` (extended). Returns equity,
balance, margins, PnL, delta-total, and other portfolio-level scalars.
"""

from __future__ import annotations

import json
import time

import requests

from portfolio_analysis_AI_Agent.tools._auth import get_access_token, rpc_url


def get_account_summary(currency: str = "BTC", extended: bool = True) -> dict:
    """Returns the flattened account summary dict + fetched_at."""
    payload = {
        "jsonrpc": "2.0",
        "id": 1,
        "method": "private/get_account_summary",
        "params": {"currency": currency, "extended": bool(extended)},
    }
    headers = {"Authorization": f"Bearer {get_access_token()}"}
    r = requests.post(rpc_url(), json=payload, headers=headers, timeout=15)
    body = r.json()
    if body.get("error"):
        raise RuntimeError(f"Deribit error: {body['error']}")
    res = body.get("result") or {}

    keys = [
        "currency", "type", "equity", "balance", "available_funds",
        "available_withdrawal_funds", "initial_margin", "maintenance_margin",
        "margin_balance", "delta_total", "options_delta", "options_gamma",
        "options_vega", "options_theta", "options_pl", "options_value",
        "options_session_rpl", "options_session_upl", "futures_pl",
        "futures_session_rpl", "futures_session_upl", "session_rpl",
        "session_upl", "total_pl", "projected_initial_margin",
        "projected_maintenance_margin", "estimated_liquidation_ratio",
        "limits", "deposit_address",
    ]
    flat = {k: res.get(k) for k in keys}
    return {**flat, "raw": res, "fetched_at": int(time.time())}


if __name__ == "__main__":
    out = get_account_summary()
    # Drop heavy raw blob for readable smoke output
    print(json.dumps({k: v for k, v in out.items() if k != "raw"}, indent=2, default=str))

# Run from Digital-Ocean-Server:
#   python -m portfolio_analysis_AI_Agent.tools.datafetch.account.get_account_summary
