"""Tool: datafetch.account.get_account_summaries

Calls Deribit `private/get_account_summaries` (plural) and returns the
**cross-margin USD totals** alongside the per-currency summaries.

This is the canonical equity/margin endpoint for accounts that hold
multiple currencies (BTC + USDT + USDC, etc.) under cross collateral.
The singular `private/get_account_summary` only ever returns one
currency, so building risk metrics off it underreports total equity.

Output shape merges three pieces:
  1. Per-currency block for the **focus currency** (default BTC) -
     the trading book's Greeks, balance, margins live here.
  2. Cross-margin USD totals - `total_equity_usd`,
     `total_initial_margin_usd`, `total_maintenance_margin_usd`,
     `total_margin_balance_usd`, `total_delta_total_usd`. Deribit
     populates these at the response root for some accounts but **not
     all** - when they're missing we compute them locally by summing
     each currency's `equity / initial_margin / ...` converted to USD
     (stablecoins ≈ 1.0; non-stables via `public/get_index_price`).
     The `cross_totals_source` field tells you which path was used
     ('deribit' vs 'computed_locally').
  3. Account metadata and the full per-currency list (`summaries_by_currency`).

Analysis tools that need equity_usd should read `total_equity_usd`
when present and fall back to `<focus>.equity × spot` otherwise.
"""

from __future__ import annotations

import json
import time
from typing import Optional

from portfolio_analysis_AI_Agent.tools._auth import rpc_call


# Per-currency keys we copy to the top-level (using the focus currency's row).
# These are the fields downstream tools (greeks_compute, risk_compute) read
# directly without going through `summaries_by_currency[<ccy>]`.
_PER_CURRENCY_FIELDS = [
    "currency", "type", "equity", "balance", "available_funds",
    "available_withdrawal_funds", "initial_margin", "maintenance_margin",
    "margin_balance", "delta_total", "options_delta", "options_gamma",
    "options_vega", "options_theta", "options_pl", "options_value",
    "options_session_rpl", "options_session_upl", "futures_pl",
    "futures_session_rpl", "futures_session_upl", "session_rpl",
    "session_upl", "total_pl", "projected_initial_margin",
    "projected_maintenance_margin", "estimated_liquidation_ratio",
    "portfolio_margining_enabled", "cross_collateral_enabled",
    "margin_model",
]

# Cross-margin USD totals at the top of the `result` payload.
_CROSS_USD_FIELDS = [
    "total_equity_usd", "total_initial_margin_usd",
    "total_maintenance_margin_usd", "total_margin_balance_usd",
    "total_delta_total_usd",
]

# Currencies treated as USD-pegged for cross-margin conversion. They
# trade ~$1; close enough for portfolio-equity arithmetic.
_STABLECOINS = {"USDT", "USDC", "USD", "USDE", "PYUSD", "DAI", "TUSD", "FDUSD"}


def _currency_to_usd_factor(currency: str, _cache: dict | None = None) -> float:
    """Return how many USD one unit of `currency` is worth.

    Stablecoins: assumed 1.0. Non-stables: looked up via Deribit's
    `<lower>_usd` index price. Unknown / no-index → 0.0 (the currency is
    then effectively excluded from cross totals - we'd rather underreport
    a tiny stray balance than make up a number).
    """
    if _cache is None:
        _cache = {}
    c = (currency or "").upper()
    if c in _cache:
        return _cache[c]
    if c in _STABLECOINS:
        _cache[c] = 1.0
        return 1.0
    try:
        from portfolio_analysis_AI_Agent.tools.datafetch.market.get_index_price import get_index_price
        idx = get_index_price(f"{c.lower()}_usd")
        price = float(idx.get("index_price") or 0)
        factor = price if price > 0 else 0.0
    except Exception:
        factor = 0.0
    _cache[c] = factor
    return factor


def _compute_cross_totals_locally(summaries: list[dict]) -> dict:
    """Sum per-currency margin/equity/delta fields converted to USD.

    Only currencies with non-zero equity are processed (avoids a flurry of
    index-price calls for empty rows on accounts that show ~15 listed
    currencies but only hold 2).
    """
    fields = ["equity", "initial_margin", "maintenance_margin", "margin_balance", "delta_total"]
    totals = {f: 0.0 for f in fields}
    factors: dict[str, float] = {}
    cache: dict[str, float] = {}

    for s in summaries:
        try:
            eq = float(s.get("equity") or 0)
        except (TypeError, ValueError):
            eq = 0.0
        if eq <= 0:
            continue
        c = str(s.get("currency") or "").upper()
        factor = _currency_to_usd_factor(c, _cache=cache)
        if factor <= 0:
            continue
        factors[c] = factor
        for f in fields:
            try:
                v = float(s.get(f) or 0)
            except (TypeError, ValueError):
                v = 0.0
            totals[f] += v * factor

    return {
        "total_equity_usd": round(totals["equity"], 2),
        "total_initial_margin_usd": round(totals["initial_margin"], 2),
        "total_maintenance_margin_usd": round(totals["maintenance_margin"], 2),
        "total_margin_balance_usd": round(totals["margin_balance"], 2),
        "total_delta_total_usd": round(totals["delta_total"], 6),
        "conversion_factors": factors,
    }


def get_account_summaries(
    focus_currency: str = "BTC",
    extended: bool = True,
    subaccount_id: Optional[int] = None,
) -> dict:
    """Fetch cross-margin account state.

    Args:
        focus_currency: which per-currency block to surface at the top
            level (default 'BTC' - that's where BTC-options Greeks live).
        extended: pass-through to Deribit (adds account_id / username / etc.).
        subaccount_id: optional subaccount target.

    Returns a flat dict combining: focus-currency fields,
    cross-margin USD totals, and the full per-currency list.
    """
    params: dict = {"extended": bool(extended)}
    if subaccount_id is not None:
        params["subaccount_id"] = int(subaccount_id)

    res = rpc_call("private/get_account_summaries", params) or {}
    summaries = res.get("summaries") or []
    by_currency = {str(s.get("currency") or "").upper(): s for s in summaries}

    focus_key = (focus_currency or "BTC").upper()
    focus = by_currency.get(focus_key) or {}

    # Copy focus-currency per-currency fields up to the top.
    out: dict = {k: focus.get(k) for k in _PER_CURRENCY_FIELDS}
    # Add the cross-margin USD totals (may be None - handled below).
    for k in _CROSS_USD_FIELDS:
        out[k] = res.get(k)

    # Determine whether cross-margin is actually in use for this account.
    cross_enabled = bool(
        out.get("cross_collateral_enabled")
        or any(s.get("cross_collateral_enabled") for s in summaries)
        or out.get("total_equity_usd") is not None
    )

    # If Deribit didn't populate the cross-margin totals, compute them
    # locally by summing per-currency equity/margins × USD conversion.
    # The user's account is `cross_pm` but the response omits these
    # fields - without this fallback `total_equity_usd` is just None.
    if cross_enabled and all(out.get(k) is None for k in _CROSS_USD_FIELDS):
        locally = _compute_cross_totals_locally(summaries)
        for k in _CROSS_USD_FIELDS:
            out[k] = locally[k]
        out["cross_totals_source"] = "computed_locally"
        out["cross_totals_factors"] = locally["conversion_factors"]
    else:
        out["cross_totals_source"] = "deribit" if out.get("total_equity_usd") is not None else "none"
        out["cross_totals_factors"] = None

    out.update({
        "focus_currency": focus_key,
        "cross_margin_enabled": cross_enabled,
        "currencies_held": sorted(by_currency.keys()),
        "summaries_by_currency": by_currency,
        "account_id": res.get("id"),
        "username": res.get("username"),
        "email": res.get("email"),
        "account_type": res.get("type"),
        "fetched_at": int(time.time()),
    })
    return out


if __name__ == "__main__":
    out = get_account_summaries()
    # Trim per-currency raw blocks to one for readable output.
    trimmed = {
        **out,
        "summaries_by_currency": {
            k: {kk: vv for kk, vv in v.items() if kk in (
                "currency", "equity", "balance", "available_funds",
                "initial_margin", "maintenance_margin", "delta_total",
                "options_delta", "options_gamma", "options_vega", "options_theta",
                "estimated_liquidation_ratio",
            )}
            for k, v in (out.get("summaries_by_currency") or {}).items()
        },
    }
    print(json.dumps(trimmed, indent=2, default=str))


# Run from Digital-Ocean-Server:
#   python -m portfolio_analysis_AI_Agent.tools.datafetch.account.get_account_summaries
