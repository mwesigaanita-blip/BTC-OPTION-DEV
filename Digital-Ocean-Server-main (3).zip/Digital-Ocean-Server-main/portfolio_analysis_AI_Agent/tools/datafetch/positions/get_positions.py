"""Tool: datafetch.positions.get_positions

Calls Deribit `private/get_positions`. Returns all open positions for the
currency (options + futures + perpetual unless filtered by `kind`).
"""

from __future__ import annotations

import json
import time
from typing import Optional

from portfolio_analysis_AI_Agent.tools._auth import rpc_call


def get_positions(currency: str = "BTC", kind: Optional[str] = None) -> dict:
    """Returns {currency, kind, count, positions[], totals, fetched_at}.

    `kind`: 'option' | 'future' | 'spot' | None (all).
    Each position carries Deribit's native fields plus a derived `net_delta`.
    """
    params: dict = {"currency": currency}
    if kind:
        params["kind"] = kind

    rows = rpc_call("private/get_positions", params) or []

    positions = []
    sum_delta = sum_gamma = sum_vega = sum_theta = 0.0
    for p in rows:
        delta = float(p.get("delta") or 0.0)
        gamma = float(p.get("gamma") or 0.0)
        vega = float(p.get("vega") or 0.0)
        theta = float(p.get("theta") or 0.0)
        sum_delta += delta
        sum_gamma += gamma
        sum_vega += vega
        sum_theta += theta
        positions.append({**p, "net_delta": delta})

    return {
        "currency": currency,
        "kind": kind,
        "count": len(positions),
        "positions": positions,
        "totals": {
            "delta": sum_delta,
            "gamma": sum_gamma,
            "vega": sum_vega,
            "theta": sum_theta,
        },
        "fetched_at": int(time.time()),
    }


if __name__ == "__main__":
    out = get_positions()
    # Trim positions for readable smoke output
    sample = out["positions"][:3]
    print(json.dumps({**out, "positions": sample, "sample_size": len(sample)}, indent=2, default=str))

# Run from Digital-Ocean-Server:
#   python -m portfolio_analysis_AI_Agent.tools.datafetch.positions.get_positions
