"""Tool: datafetch.market.get_binance_daily

Daily OHLCV from Binance public klines (no API key required) for any
spot symbol. Used by the Daily Quant dashboard to cover non-BTC crypto
(ETH/SOL/AVAX/ZEC) since Deribit only carries BTC + ETH derivatives.

Endpoint: GET https://api.binance.com/api/v3/klines?symbol=...&interval=1d
Today's partial candle is excluded so returns/aggregations are stable.

Output dict:
    {symbol, interval, lookback_days, rows: [{date, open, high, low, close, volume}], fetched_at}
"""
from __future__ import annotations

import json
import logging
import time
from datetime import datetime, timezone

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry


log = logging.getLogger("tools.market.get_binance_daily")

_BASE_URL = "https://api.binance.com/api/v3/klines"
_MAX_LIMIT = 1000  # Binance hard cap per request

# Labels (caller-facing) -> Binance USDT spot symbols.
ALT_SYMBOLS: dict[str, str] = {
    "ETH":  "ETHUSDT",
    "SOL":  "SOLUSDT",
    "AVAX": "AVAXUSDT",
    "ZEC":  "ZECUSDT",
    "DOGE": "DOGEUSDT",
    "XRP":  "XRPUSDT",
}


def _session() -> requests.Session:
    s = requests.Session()
    retry = Retry(
        total=5, connect=5, read=5, status=5,
        backoff_factor=0.5,
        status_forcelist=(429, 500, 502, 503, 504),
        allowed_methods=frozenset(["GET"]),
        raise_on_status=False,
    )
    s.mount("https://", HTTPAdapter(max_retries=retry, pool_connections=4, pool_maxsize=4))
    s.headers.update({"User-Agent": "btc-daily-quant/1.0"})
    return s


def get_binance_daily(symbol: str, lookback_days: int = 800) -> dict:
    """Returns daily OHLCV rows for ``symbol`` over the last ``lookback_days``.

    ``symbol`` is a Binance spot symbol like ``ETHUSDT``. Pass an
    ``ALT_SYMBOLS`` value if you want a known mapping.
    """
    sess = _session()
    end_ms = int(datetime.now(timezone.utc).timestamp() * 1000)
    start_ms = end_ms - int(lookback_days) * 86_400_000

    raw_rows: list[list] = []
    cursor = start_ms
    while cursor < end_ms:
        params = {
            "symbol": symbol,
            "interval": "1d",
            "startTime": cursor,
            "endTime": end_ms,
            "limit": _MAX_LIMIT,
        }
        r = sess.get(_BASE_URL, params=params, timeout=(3.05, 20))
        r.raise_for_status()
        chunk = r.json()
        if not chunk:
            break
        raw_rows.extend(chunk)
        last_open = int(chunk[-1][0])
        next_cursor = last_open + 86_400_000
        if next_cursor <= cursor:
            break
        cursor = next_cursor
        if len(chunk) < _MAX_LIMIT:
            break
        time.sleep(0.1)

    today_iso = datetime.now(timezone.utc).date().isoformat()
    seen: set[str] = set()
    rows: list[dict] = []
    for k in raw_rows:
        d = datetime.utcfromtimestamp(int(k[0]) / 1000).strftime("%Y-%m-%d")
        if d >= today_iso or d in seen:
            continue
        seen.add(d)
        rows.append({
            "date": d,
            "open":  float(k[1]),
            "high":  float(k[2]),
            "low":   float(k[3]),
            "close": float(k[4]),
            "volume": float(k[5]),
        })
    rows.sort(key=lambda r: r["date"])

    return {
        "symbol": symbol,
        "interval": "1d",
        "lookback_days": int(lookback_days),
        "rows": rows,
        "count": len(rows),
        "fetched_at": int(time.time()),
    }


if __name__ == "__main__":
    out = get_binance_daily("ETHUSDT", lookback_days=10)
    print(json.dumps({**out, "rows": out["rows"][:3] + ["…"] + out["rows"][-3:]}, indent=2, default=str))

# Run from Digital-Ocean-Server:
#   python -m portfolio_analysis_AI_Agent.tools.datafetch.market.get_binance_daily
