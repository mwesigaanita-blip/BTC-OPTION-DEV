"""Tool: datafetch.market.get_btc_index_candles

Paginated BTC candle fetcher (Deribit `public/get_tradingview_chart_data`).

Deribit has no clean historical *index* price endpoint, so we use
`BTC-PERPETUAL` closes as the spot proxy. The per-call cap is ~5000 bars,
so for long lookbacks we chunk backwards and stitch.

Resolutions supported here: ``"60"`` (1h) and ``"1D"``. Add others if
needed; the bars-per-day math just needs to match.
"""

from __future__ import annotations

import json
import time
from typing import Optional

import requests

from portfolio_analysis_AI_Agent.tools._auth import rpc_url

_INSTRUMENT = "BTC-PERPETUAL"
_PER_CALL_BAR_LIMIT = 5000  # Deribit's documented per-response cap


def _bars_per_day(resolution: str) -> int:
    if resolution == "60":
        return 24
    if resolution == "1D":
        return 1
    raise ValueError(f"unsupported resolution: {resolution!r} (use '60' or '1D')")


def _one_call(start_ms: int, end_ms: int, resolution: str) -> dict:
    payload = {
        "jsonrpc": "2.0", "id": 1,
        "method": "public/get_tradingview_chart_data",
        "params": {
            "instrument_name": _INSTRUMENT,
            "start_timestamp": start_ms,
            "end_timestamp": end_ms,
            "resolution": resolution,
        },
    }
    r = requests.post(rpc_url(), json=payload, timeout=30)
    body = r.json()
    if body.get("error"):
        raise RuntimeError(f"Deribit error: {body['error']}")
    return body.get("result") or {}


def get_btc_index_candles(
    *,
    resolution: str = "60",
    days: int = 30,
    end_ms: Optional[int] = None,
) -> dict:
    """Returns ``{resolution, ticks_ms[], close[], open[], high[], low[], volume[], fetched_at}``.

    Series is chronological, deduped on ``ticks_ms``. May chunk across
    multiple Deribit calls when the requested window exceeds 5000 bars.
    """
    bpd = _bars_per_day(resolution)
    end = int(end_ms or time.time() * 1000)
    start = end - int(days * 86_400_000)

    chunk_ms = int((_PER_CALL_BAR_LIMIT / bpd) * 86_400_000 * 0.9)  # 10% safety margin

    merged: dict[int, tuple[float, float, float, float, float]] = {}
    cur_end = end
    while cur_end > start:
        cur_start = max(start, cur_end - chunk_ms)
        result = _one_call(cur_start, cur_end, resolution)
        ticks = result.get("ticks") or []
        if not ticks:
            break
        closes = result.get("close") or []
        opens = result.get("open") or []
        highs = result.get("high") or []
        lows = result.get("low") or []
        vols = result.get("volume") or []
        for i, t in enumerate(ticks):
            try:
                ts = int(t)
            except (TypeError, ValueError):
                continue
            merged[ts] = (
                float(opens[i]) if i < len(opens) else 0.0,
                float(highs[i]) if i < len(highs) else 0.0,
                float(lows[i]) if i < len(lows) else 0.0,
                float(closes[i]) if i < len(closes) else 0.0,
                float(vols[i]) if i < len(vols) else 0.0,
            )
        # Step back. The oldest tick we just received becomes the new end.
        oldest = min(int(t) for t in ticks)
        if oldest >= cur_end:  # no progress; bail to avoid infinite loop
            break
        cur_end = oldest

    sorted_ts = sorted(merged.keys())
    return {
        "resolution": resolution,
        "instrument": _INSTRUMENT,
        "ticks_ms": sorted_ts,
        "open":  [merged[t][0] for t in sorted_ts],
        "high":  [merged[t][1] for t in sorted_ts],
        "low":   [merged[t][2] for t in sorted_ts],
        "close": [merged[t][3] for t in sorted_ts],
        "volume": [merged[t][4] for t in sorted_ts],
        "fetched_at": int(time.time()),
    }


if __name__ == "__main__":
    out = get_btc_index_candles(resolution="1D", days=400)
    print(json.dumps({
        "resolution": out["resolution"],
        "bars": len(out["ticks_ms"]),
        "first_ts_ms": out["ticks_ms"][0] if out["ticks_ms"] else None,
        "last_ts_ms":  out["ticks_ms"][-1] if out["ticks_ms"] else None,
    }, indent=2))

# Run from Digital-Ocean-Server:
#   python -m portfolio_analysis_AI_Agent.tools.datafetch.market.get_btc_index_candles
