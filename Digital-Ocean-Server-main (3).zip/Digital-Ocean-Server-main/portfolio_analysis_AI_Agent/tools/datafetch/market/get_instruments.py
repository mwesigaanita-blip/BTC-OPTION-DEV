"""Tool: datafetch.market.get_instruments

Calls Deribit `public/get_instruments`. Returns the active instrument list
(filterable by currency / kind / expired flag).
"""

from __future__ import annotations

import json
import time
from typing import Optional

import requests

from portfolio_analysis_AI_Agent.tools._auth import rpc_url


def get_instruments(
    currency: str = "BTC",
    kind: Optional[str] = "option",
    expired: bool = False,
) -> dict:
    """Returns {count, currency, kind, expired, instruments[], fetched_at}.

    `kind`: 'option' | 'future' | 'spot' | None (all).
    Each instrument row is the raw Deribit shape (instrument_name, expiration_timestamp,
    strike, option_type, settlement_period, ...).
    """
    params: dict = {"currency": currency, "expired": bool(expired)}
    if kind:
        params["kind"] = kind

    payload = {"jsonrpc": "2.0", "id": 1, "method": "public/get_instruments", "params": params}
    r = requests.post(rpc_url(), json=payload, timeout=15)
    body = r.json()
    if body.get("error"):
        raise RuntimeError(f"Deribit error: {body['error']}")
    rows = body.get("result") or []
    return {
        "currency": currency,
        "kind": kind,
        "expired": bool(expired),
        "count": len(rows),
        "instruments": rows,
        "fetched_at": int(time.time()),
    }


if __name__ == "__main__":
    out = get_instruments()
    # Trim instrument list for readable smoke output
    sample = out["instruments"][:3]
    print(json.dumps({**out, "instruments": sample, "sample_size": len(sample)}, indent=2, default=str))

# Run from Digital-Ocean-Server:
#   python -m portfolio_analysis_AI_Agent.tools.datafetch.market.get_instruments
