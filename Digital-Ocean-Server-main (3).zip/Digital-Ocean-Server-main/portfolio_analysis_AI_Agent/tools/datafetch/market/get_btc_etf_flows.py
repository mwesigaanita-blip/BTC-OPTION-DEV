"""Tool: datafetch.market.get_btc_etf_flows

Daily net creation/redemption flows for the US spot Bitcoin ETFs,
scraped from Farside Investors (the de-facto public source for this
data). All figures are in USD millions.

Source: https://farside.co.uk/bitcoin-etf-flow-all-data/

Farside serves the table HTML directly; the page is gated by a basic
bot check so we use ``curl_cffi`` (Chrome TLS impersonation) — already
in this repo's requirements for Yahoo Finance.

Output dict::

    {
      tickers: ["IBIT", "FBTC", ..., "BTC"],     # 12 fund tickers
      rows: [                                     # daily rows (ASC by date)
        {date: "YYYY-MM-DD", flows: {TICKER: float|None}, total: float|None},
        ...
      ],
      totals: {TICKER: float, "TOTAL": float},    # cumulative since inception
      count: int,
      fetched_at: int,
    }

Cell encoding from Farside:
- ``-``           -> ``None`` (fund did not exist yet / no report)
- ``(123.4)``     -> ``-123.4`` (accounting parens for negatives)
- ``1,234.5``     -> ``1234.5`` (thousands separators stripped)
"""
from __future__ import annotations

import json
import logging
import re
import time
from datetime import datetime
from typing import Any, Optional

log = logging.getLogger("tools.market.get_btc_etf_flows")

_URL = "https://farside.co.uk/bitcoin-etf-flow-all-data/"

_MONTHS = {
    "Jan": 1, "Feb": 2, "Mar": 3, "Apr": 4, "May": 5, "Jun": 6,
    "Jul": 7, "Aug": 8, "Sep": 9, "Oct": 10, "Nov": 11, "Dec": 12,
}

_session_cache: list[Any] = []


def _session():
    if _session_cache:
        return _session_cache[0]
    try:
        from curl_cffi import requests as curl_requests  # type: ignore
    except ImportError as e:
        raise RuntimeError(
            "curl_cffi not installed - Farside blocks plain requests. "
            "Install with: pip install curl_cffi"
        ) from e
    s = curl_requests.Session(impersonate="chrome")
    _session_cache.append(s)
    return s


def _strip_tags(s: str) -> str:
    return re.sub(r"<[^>]+>", "", s).strip().replace("\xa0", " ").replace("&nbsp;", " ").replace("&amp;", "&")


def _parse_cell(text: str) -> Optional[float]:
    """Convert a Farside cell to a float in $M, or None when no data."""
    t = text.strip()
    if not t or t in {"-", "—"}:
        return None
    neg = False
    if t.startswith("(") and t.endswith(")"):
        neg = True
        t = t[1:-1]
    t = t.replace(",", "").replace("$", "").strip()
    try:
        v = float(t)
    except ValueError:
        return None
    return -v if neg else v


def _parse_date(text: str) -> Optional[str]:
    """Farside format: ``11 Jan 2024`` -> ``2024-01-11``."""
    parts = text.strip().split()
    if len(parts) != 3:
        return None
    try:
        d = int(parts[0])
        m = _MONTHS.get(parts[1][:3])
        y = int(parts[2])
        if not m:
            return None
        return f"{y:04d}-{m:02d}-{d:02d}"
    except (ValueError, KeyError):
        return None


def parse_farside_html(html: str) -> dict:
    """Pure parser — split out so unit tests can feed in fixture HTML."""
    tables = re.findall(r"<table[^>]*>.*?</table>", html, flags=re.S)
    if not tables:
        raise RuntimeError("no <table> element in Farside response")
    # The data table is by far the largest on the page.
    data_table = max(tables, key=len)

    raw_rows = re.findall(r"<tr[^>]*>(.*?)</tr>", data_table, flags=re.S)
    if len(raw_rows) < 2:
        raise RuntimeError("Farside table has fewer than 2 rows")

    def split_cells(row_html: str) -> list[str]:
        return [_strip_tags(c) for c in re.findall(r"<t[hd][^>]*>(.*?)</t[hd]>", row_html, flags=re.S)]

    header = split_cells(raw_rows[0])
    if not header or header[0].lower() != "date":
        raise RuntimeError(f"unexpected Farside header: {header!r}")

    tickers = [c for c in header[1:-1]]  # drop "Date" and trailing "Total"
    if not tickers or header[-1].lower() != "total":
        raise RuntimeError(f"unexpected Farside header tail: {header!r}")

    rows: list[dict] = []
    totals_row: Optional[dict] = None

    for raw in raw_rows[1:]:
        cells = split_cells(raw)
        if len(cells) != len(header):
            continue
        first = cells[0].strip()
        # Cumulative-since-inception row at the bottom.
        if first.lower() in {"total", "totals"}:
            totals_row = {
                **{t: _parse_cell(cells[1 + i]) for i, t in enumerate(tickers)},
                "TOTAL": _parse_cell(cells[-1]),
            }
            continue
        date = _parse_date(first)
        if not date:
            continue
        rows.append({
            "date": date,
            "flows": {t: _parse_cell(cells[1 + i]) for i, t in enumerate(tickers)},
            "total": _parse_cell(cells[-1]),
        })

    rows.sort(key=lambda r: r["date"])

    return {
        "tickers": tickers,
        "rows": rows,
        "totals": totals_row or {},
        "count": len(rows),
    }


def get_btc_etf_flows(days: Optional[int] = None) -> dict:
    """Daily BTC ETF flows from Farside (all funds, $M).

    Pass ``days`` to truncate to the most recent N rows (matches the
    Hedgeye-style ~10-row daily flows panel). Cumulative ``totals`` is
    returned regardless.
    """
    sess = _session()
    r = sess.get(_URL, timeout=30)
    if r.status_code != 200:
        raise RuntimeError(f"Farside HTTP {r.status_code}")
    parsed = parse_farside_html(r.text)
    if days is not None and days > 0:
        parsed["rows"] = parsed["rows"][-int(days):]
        parsed["count"] = len(parsed["rows"])
    parsed["fetched_at"] = int(time.time())
    return parsed


if __name__ == "__main__":
    out = get_btc_etf_flows(days=5)
    print(json.dumps(out, indent=2, default=str))

# Run from Digital-Ocean-Server:
#   python -m portfolio_analysis_AI_Agent.tools.datafetch.market.get_btc_etf_flows
