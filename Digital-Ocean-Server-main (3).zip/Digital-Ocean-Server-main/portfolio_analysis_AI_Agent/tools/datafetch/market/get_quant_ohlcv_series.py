"""Tool: datafetch.market.get_quant_ohlcv_series

Read a single asset's daily ``date / close / volume`` series from SQLite.
Sister tool to ``get_quant_close_series`` — same dispatch rules but
keeps the ``volume`` column so volume-aggregate tools (e.g.
``compute_volume_metrics``) can run downstream.

Output dict::

    {asset, source_table, rows: [{date, close, volume}], count, fetched_at}
"""
from __future__ import annotations

import json
import sqlite3
import time

from shared.db_paths import MARKET_DATA_DB

_ALT_LABELS = {"ETH", "SOL", "AVAX", "ZEC", "DOGE", "XRP"}


def _resolve(asset: str) -> tuple[str, str | None, str | None]:
    a = asset.strip().upper()
    if a == "BTC":
        return ("btc_prices", None, None)
    if a in _ALT_LABELS:
        return ("alt_prices", "symbol", a)
    raise ValueError(f"asset {asset!r} has no volume series in this pipeline")


def get_quant_ohlcv_series(asset: str) -> dict:
    table, key_col, key_val = _resolve(asset)
    if key_col is None:
        sql = "SELECT date, close, volume FROM btc_prices ORDER BY date ASC"
        params: tuple = ()
    else:
        sql = (
            f"SELECT date, close, volume FROM {table} "
            f"WHERE {key_col} = ? ORDER BY date ASC"
        )
        params = (key_val,)

    rows: list[dict] = []
    try:
        with sqlite3.connect(str(MARKET_DATA_DB)) as con:
            for d, c, v in con.execute(sql, params).fetchall():
                if d is None or c is None:
                    continue
                rows.append({
                    "date": str(d),
                    "close": float(c),
                    "volume": float(v or 0.0),
                })
    except sqlite3.OperationalError:
        rows = []

    return {
        "asset": asset.strip().upper(),
        "source_table": table,
        "rows": rows,
        "count": len(rows),
        "fetched_at": int(time.time()),
    }


if __name__ == "__main__":
    out = get_quant_ohlcv_series("BTC")
    sample = out["rows"][:2] + ["…"] + out["rows"][-2:] if out["count"] > 4 else out["rows"]
    print(json.dumps({**out, "rows": sample}, indent=2, default=str))

# Run from Digital-Ocean-Server:
#   python -m portfolio_analysis_AI_Agent.tools.datafetch.market.get_quant_ohlcv_series
