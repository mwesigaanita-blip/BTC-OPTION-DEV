"""Tool: datafetch.market.get_last_trades

Calls Deribit `public/get_last_trades_by_instrument`. Returns the most
recent trades for a single instrument (size-aggressor-price-iv-ts).
"""

from __future__ import annotations

import json
import time
from typing import Optional

import requests

from portfolio_analysis_AI_Agent.tools._auth import rpc_url


def get_last_trades(
    instrument_name: str = "BTC-PERPETUAL",
    count: int = 50,
    start_seq: Optional[int] = None,
) -> dict:
    """Returns {instrument, count, has_more, trades[], fetched_at}.

    Each trade: {trade_id, ts_ms, price, amount, direction, iv}.
    """
    params: dict = {"instrument_name": instrument_name, "count": int(count)}
    if start_seq is not None:
        params["start_seq"] = int(start_seq)

    payload = {
        "jsonrpc": "2.0",
        "id": 1,
        "method": "public/get_last_trades_by_instrument",
        "params": params,
    }
    r = requests.post(rpc_url(), json=payload, timeout=15)
    body = r.json()
    if body.get("error"):
        raise RuntimeError(f"Deribit error: {body['error']}")
    res = body.get("result") or {}
    trades_raw = res.get("trades") or []

    trades = []
    for t in trades_raw:
        trades.append({
            "trade_id": t.get("trade_id"),
            "ts_ms": t.get("timestamp"),
            "price": t.get("price"),
            "amount": t.get("amount"),
            "direction": t.get("direction"),
            "iv": t.get("iv"),
            "index_price": t.get("index_price"),
            "mark_price": t.get("mark_price"),
            "instrument_name": t.get("instrument_name"),
            "block_trade_id": t.get("block_trade_id"),
            "combo_id": t.get("combo_id"),
            "combo_trade_id": t.get("combo_trade_id"),
            "liquidation": t.get("liquidation"),
            "tick_direction": t.get("tick_direction"),
        })

    return {
        "instrument": instrument_name,
        "count": len(trades),
        "has_more": bool(res.get("has_more")),
        "trades": trades,
        "fetched_at": int(time.time()),
    }


if __name__ == "__main__":
    out = get_last_trades(count=10)
    print(json.dumps(out, indent=2, default=str))

# Run from Digital-Ocean-Server:
#   python -m portfolio_analysis_AI_Agent.tools.datafetch.market.get_last_trades
