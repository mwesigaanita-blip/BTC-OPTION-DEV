"""Tool: datafetch.market.get_dvol

Calls Deribit `public/get_volatility_index_data` for the DVOL index
(BTCDVOL or ETHDVOL). Returns the latest value and a small OHLC sample.
"""

from __future__ import annotations

import json
import time

import requests

from portfolio_analysis_AI_Agent.tools._auth import rpc_url


def get_dvol(currency: str = "BTC", resolution: str = "3600", days: int = 7) -> dict:
    """Returns {index_name, latest_close, latest_ts_ms, ohlc[], fetched_at}.

    resolution: '60' | '3600' | '43200' | '1D' (Deribit allowed values).
    """
    index_name = f"{currency.upper()}DVOL"
    end_ms = int(time.time() * 1000)
    start_ms = end_ms - int(days * 24 * 3600 * 1000)

    payload = {
        "jsonrpc": "2.0",
        "id": 1,
        "method": "public/get_volatility_index_data",
        "params": {
            "currency": currency.upper(),
            "start_timestamp": start_ms,
            "end_timestamp": end_ms,
            "resolution": resolution,
        },
    }
    r = requests.post(rpc_url(), json=payload, timeout=15)
    body = r.json()
    if body.get("error"):
        raise RuntimeError(f"Deribit error: {body['error']}")
    res = body.get("result") or {}
    data = res.get("data") or []
    latest = data[-1] if data else None

    return {
        "index_name": index_name,
        "resolution": resolution,
        "latest_ts_ms": int(latest[0]) if latest else None,
        "latest_open": float(latest[1]) if latest else None,
        "latest_high": float(latest[2]) if latest else None,
        "latest_low": float(latest[3]) if latest else None,
        "latest_close": float(latest[4]) if latest else None,
        "sample_count": len(data),
        "ohlc": data,
        "fetched_at": int(time.time()),
    }


if __name__ == "__main__":
    out = get_dvol()
    print(json.dumps({**out, "ohlc": out["ohlc"][:3]}, indent=2, default=str))

# Run from Digital-Ocean-Server:
#   python -m portfolio_analysis_AI_Agent.tools.datafetch.market.get_dvol
