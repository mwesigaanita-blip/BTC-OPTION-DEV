"""Tool: datafetch.market.get_historical_volatility

Calls Deribit `public/get_historical_volatility`. Returns realized BTC
volatility samples (annualized %, last ~15 days).
"""

from __future__ import annotations

import json
import statistics
import time

import requests

from portfolio_analysis_AI_Agent.tools._auth import rpc_url


def get_historical_volatility(currency: str = "BTC") -> dict:
    """Returns {currency, latest, mean, min, max, sample_count, samples[], fetched_at}.

    samples[] is a list of [ts_ms, hv_pct] pairs as returned by Deribit.
    """
    payload = {
        "jsonrpc": "2.0",
        "id": 1,
        "method": "public/get_historical_volatility",
        "params": {"currency": currency},
    }
    r = requests.post(rpc_url(), json=payload, timeout=15)
    body = r.json()
    if body.get("error"):
        raise RuntimeError(f"Deribit error: {body['error']}")
    rows = body.get("result") or []

    values = [float(r[1]) for r in rows if isinstance(r, (list, tuple)) and len(r) >= 2]
    latest = values[-1] if values else None
    mean_v = float(statistics.fmean(values)) if values else None
    min_v = min(values) if values else None
    max_v = max(values) if values else None

    return {
        "currency": currency,
        "latest": latest,
        "mean": mean_v,
        "min": min_v,
        "max": max_v,
        "sample_count": len(values),
        "samples": rows,
        "fetched_at": int(time.time()),
    }


if __name__ == "__main__":
    out = get_historical_volatility()
    print(json.dumps({**out, "samples": out["samples"][:3]}, indent=2, default=str))

# Run from Digital-Ocean-Server:
#   python -m portfolio_analysis_AI_Agent.tools.datafetch.market.get_historical_volatility
