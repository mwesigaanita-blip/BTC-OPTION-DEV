"""Tool: datafetch.market.get_book_summary

Calls Deribit `public/get_book_summary_by_currency`. Returns one row per
active instrument with bid/ask/IV/OI/volume - the workhorse for sentiment,
PCR, max-pain, and OI breakdown tools.
"""

from __future__ import annotations

import json
import time
from typing import Optional

import requests

from portfolio_analysis_AI_Agent.tools._auth import rpc_url


def get_book_summary(currency: str = "BTC", kind: Optional[str] = "option") -> dict:
    """Returns {count, currency, kind, rows[], fetched_at}.

    `kind`: 'option' | 'future' | None (all).
    """
    params: dict = {"currency": currency}
    if kind:
        params["kind"] = kind

    payload = {
        "jsonrpc": "2.0",
        "id": 1,
        "method": "public/get_book_summary_by_currency",
        "params": params,
    }
    r = requests.post(rpc_url(), json=payload, timeout=15)
    body = r.json()
    if body.get("error"):
        raise RuntimeError(f"Deribit error: {body['error']}")
    rows = body.get("result") or []
    return {
        "currency": currency,
        "kind": kind,
        "count": len(rows),
        "rows": rows,
        "fetched_at": int(time.time()),
    }


if __name__ == "__main__":
    out = get_book_summary()
    sample = out["rows"][:2]
    print(json.dumps({**out, "rows": sample, "sample_size": len(sample)}, indent=2, default=str))

# Run from Digital-Ocean-Server:
#   python -m portfolio_analysis_AI_Agent.tools.datafetch.market.get_book_summary
