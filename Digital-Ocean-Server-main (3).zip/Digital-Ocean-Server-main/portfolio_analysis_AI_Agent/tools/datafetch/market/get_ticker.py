"""Tool: datafetch.market.get_ticker

Calls Deribit `public/ticker` for a single instrument and returns a flat
structured summary (price, IV, OI, greeks if option).
"""

from __future__ import annotations

import json
import time

import requests

from portfolio_analysis_AI_Agent.tools._auth import rpc_url


def get_ticker(instrument_name: str = "BTC-PERPETUAL") -> dict:
    """Returns a flat ticker snapshot for `instrument_name`."""
    payload = {
        "jsonrpc": "2.0",
        "id": 1,
        "method": "public/ticker",
        "params": {"instrument_name": instrument_name},
    }
    r = requests.post(rpc_url(), json=payload, timeout=10)
    body = r.json()
    if body.get("error"):
        raise RuntimeError(f"Deribit error: {body['error']}")
    res = body.get("result") or {}
    greeks = res.get("greeks") or {}
    return {
        "instrument_name": res.get("instrument_name") or instrument_name,
        "state": res.get("state"),
        "mark_price": res.get("mark_price"),
        "last_price": res.get("last_price"),
        "best_bid_price": res.get("best_bid_price"),
        "best_ask_price": res.get("best_ask_price"),
        "best_bid_amount": res.get("best_bid_amount"),
        "best_ask_amount": res.get("best_ask_amount"),
        "mark_iv": res.get("mark_iv"),
        "bid_iv": res.get("bid_iv"),
        "ask_iv": res.get("ask_iv"),
        "open_interest": res.get("open_interest"),
        "underlying_price": res.get("underlying_price"),
        "index_price": res.get("index_price"),
        "delta": greeks.get("delta"),
        "gamma": greeks.get("gamma"),
        "vega": greeks.get("vega"),
        "theta": greeks.get("theta"),
        "rho": greeks.get("rho"),
        "stats_volume": (res.get("stats") or {}).get("volume"),
        "stats_high": (res.get("stats") or {}).get("high"),
        "stats_low": (res.get("stats") or {}).get("low"),
        "stats_price_change": (res.get("stats") or {}).get("price_change"),
        "timestamp_ms": res.get("timestamp"),
        "fetched_at": int(time.time()),
    }


if __name__ == "__main__":
    print(json.dumps(get_ticker(), indent=2, default=str))

# Run from Digital-Ocean-Server:
#   python -m portfolio_analysis_AI_Agent.tools.datafetch.market.get_ticker
