"""Tool: datafetch.market.get_index_price

Calls Deribit `public/get_index_price` for a given index name
(default `btc_usd`). Returns the current index price.
"""

from __future__ import annotations

import json
import time

from portfolio_analysis_AI_Agent.tools._auth import rpc_call


def get_index_price(index_name: str = "btc_usd") -> dict:
    """Returns {index_name, index_price, fetched_at}."""
    res = rpc_call(
        "public/get_index_price",
        {"index_name": index_name},
        auth=False,
        timeout=10,
    ) or {}
    return {
        "index_name": index_name,
        "index_price": float(res.get("index_price") or 0.0),
        "estimated_delivery_price": float(res.get("estimated_delivery_price") or 0.0),
        "fetched_at": int(time.time()),
    }


if __name__ == "__main__":
    print(json.dumps(get_index_price(), indent=2))

# Run from Digital-Ocean-Server:
#   python -m portfolio_analysis_AI_Agent.tools.datafetch.market.get_index_price
