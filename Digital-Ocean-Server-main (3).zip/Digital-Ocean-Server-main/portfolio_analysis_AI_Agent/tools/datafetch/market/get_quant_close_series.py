"""Tool: datafetch.market.get_quant_close_series

Read a single asset's daily close-price series from the Daily Quant
SQLite tables in ``MARKET_DATA_DB``:

- ``BTC``                        -> ``btc_prices`` (existing table).
- ``ETH`` / ``SOL`` / ``AVAX`` / ``ZEC``  -> ``alt_prices``.
- ``MSTR`` / ``MARA`` / ``RIOT`` / ``COIN`` -> ``equity_prices``.
- ``SPX`` / ``GOLD`` / ``DXY``    -> ``benchmark_prices``.

These tables are populated by
:mod:`portfolio_analysis_AI_Agent.tools.jobs.refresh_market_data` and
consumed by the composite Daily Quant tools.

Output dict::

    {asset, source_table, rows: [{date, close}], count, fetched_at}
"""
from __future__ import annotations

import json
import sqlite3
import time

from shared.db_paths import MARKET_DATA_DB

# Imported lazily to avoid a circular import surface; these labels are
# just sets, kept here so the routing logic is self-contained.
_ALT_LABELS = {"ETH", "SOL", "AVAX", "ZEC", "DOGE", "XRP"}
_EQUITY_LABELS = {"MSTR", "MARA", "RIOT", "COIN"}
_BENCHMARK_LABELS = {"SPX", "GOLD", "DXY", "VIX", "TIPS"}


def _resolve(asset: str) -> tuple[str, str | None, str | None]:
    """Return ``(table, key_column, key_value)`` for ``asset``."""
    a = asset.strip().upper()
    if a == "BTC":
        return ("btc_prices", None, None)
    if a in _ALT_LABELS:
        return ("alt_prices", "symbol", a)
    if a in _EQUITY_LABELS:
        return ("equity_prices", "ticker", a)
    if a in _BENCHMARK_LABELS:
        return ("benchmark_prices", "ticker", a)
    raise ValueError(f"Unknown Daily Quant asset: {asset!r}")


def get_quant_close_series(asset: str) -> dict:
    table, key_col, key_val = _resolve(asset)
    if key_col is None:
        sql = "SELECT date, close FROM btc_prices ORDER BY date ASC"
        params: tuple = ()
    else:
        sql = f"SELECT date, close FROM {table} WHERE {key_col} = ? ORDER BY date ASC"
        params = (key_val,)

    rows: list[dict] = []
    try:
        with sqlite3.connect(str(MARKET_DATA_DB)) as con:
            for d, c in con.execute(sql, params).fetchall():
                if c is None or d is None:
                    continue
                rows.append({"date": str(d), "close": float(c)})
    except sqlite3.OperationalError:
        # Table doesn't exist yet (refresh job hasn't run) -> empty series.
        rows = []

    return {
        "asset": asset.strip().upper(),
        "source_table": table,
        "rows": rows,
        "count": len(rows),
        "fetched_at": int(time.time()),
    }


if __name__ == "__main__":
    out = get_quant_close_series("BTC")
    sample = out["rows"][:3] + ["…"] + out["rows"][-3:] if out["count"] > 6 else out["rows"]
    print(json.dumps({**out, "rows": sample}, indent=2, default=str))

# Run from Digital-Ocean-Server:
#   python -m portfolio_analysis_AI_Agent.tools.datafetch.market.get_quant_close_series
