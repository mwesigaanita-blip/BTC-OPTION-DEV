"""Tool: datafetch.market.get_funding_rate

Calls Deribit `public/get_funding_rate_history` for BTC-PERPETUAL and
returns the current rate plus 24h/7d/30d statistics and a directional bias.
"""

from __future__ import annotations

import json
import statistics
import time

import requests

from portfolio_analysis_AI_Agent.tools._auth import rpc_url


def _mean(xs: list[float]) -> float | None:
    return float(statistics.fmean(xs)) if xs else None


def _percentile_rank(value: float, sample: list[float]) -> float | None:
    if not sample:
        return None
    below = sum(1 for x in sample if x < value)
    return round(100.0 * below / len(sample), 2)


def get_funding_rate(currency: str = "BTC", days: int = 30) -> dict:
    """Returns {current, mean_24h, mean_7d, mean_30d, percentile, trend, bias, fetched_at}."""
    instrument = f"{currency.upper()}-PERPETUAL"
    end_ms = int(time.time() * 1000)
    start_ms = end_ms - int(days * 24 * 3600 * 1000) #  Deribit's max lookback is 30d, so this should fetch all available data for the instrument.

    payload = {
        "jsonrpc": "2.0",
        "id": 1,
        "method": "public/get_funding_rate_history",
        "params": {
            "instrument_name": instrument,
            "start_timestamp": start_ms,
            "end_timestamp": end_ms,
        },
    }
    r = requests.post(rpc_url(), json=payload, timeout=15)
    body = r.json()
    if body.get("error"):
        raise RuntimeError(f"Deribit error: {body['error']}")
    rows = body.get("result") or []

    rates: list[tuple[int, float]] = []
    for row in rows:
        ts = int(row.get("timestamp") or 0)
        rate = float(row.get("interest_8h") or row.get("interest_1h") or 0.0)
        if ts:
            rates.append((ts, rate))
    rates.sort(key=lambda x: x[0])

    all_vals = [v for _, v in rates]
    h24 = [v for ts, v in rates if ts >= end_ms - 24 * 3600 * 1000]
    d7 = [v for ts, v in rates if ts >= end_ms - 7 * 24 * 3600 * 1000]

    current = rates[-1][1] if rates else None
    mean_24h = _mean(h24)
    mean_7d = _mean(d7)
    mean_30d = _mean(all_vals)
    pct = _percentile_rank(current, all_vals) if current is not None else None

    if len(rates) >= 12:
        half = len(rates) // 2
        first_mean = _mean([v for _, v in rates[:half]]) or 0.0
        second_mean = _mean([v for _, v in rates[half:]]) or 0.0
        diff = second_mean - first_mean
        trend = "rising" if diff > 1e-6 else "falling" if diff < -1e-6 else "flat"
    else:
        trend = "unknown"

    if mean_30d is None:
        bias = "unknown"
    elif mean_30d > 0.00005:
        bias = "bullish"
    elif mean_30d < -0.00005:
        bias = "bearish"
    else:
        bias = "neutral"

    return {
        "instrument": instrument,
        "current": current,
        "mean_24h": mean_24h,
        "mean_7d": mean_7d,
        "mean_30d": mean_30d,
        "percentile_30d": pct,
        "trend": trend,
        "bias": bias,
        "sample_count": len(rates),
        "fetched_at": int(time.time()),
    }


if __name__ == "__main__":
    print(json.dumps(get_funding_rate(), indent=2, default=str))

# Run from Digital-Ocean-Server:
#   python -m portfolio_analysis_AI_Agent.tools.datafetch.market.get_funding_rate
