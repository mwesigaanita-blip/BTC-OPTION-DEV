"""Tool: datafetch.history.get_settlements

Calls Deribit `public/get_last_settlements_by_currency`. Returns recent
settlement events (delivery / settlement / bankruptcy) for the currency.
"""

from __future__ import annotations

import json
import time
from typing import Optional

import requests

from portfolio_analysis_AI_Agent.tools._auth import rpc_url


def get_settlements(
    currency: str = "BTC",
    type: Optional[str] = "settlement",
    count: int = 50,
) -> dict:
    """Returns {currency, type, count, settlements[], fetched_at}.

    `type`: 'settlement' | 'delivery' | 'bankruptcy' | None.
    """
    params: dict = {"currency": currency, "count": int(count)}
    if type:
        params["type"] = type

    payload = {
        "jsonrpc": "2.0",
        "id": 1,
        "method": "public/get_last_settlements_by_currency",
        "params": params,
    }
    r = requests.post(rpc_url(), json=payload, timeout=15)
    body = r.json()
    if body.get("error"):
        raise RuntimeError(f"Deribit error: {body['error']}")
    res = body.get("result") or {}
    rows = res.get("settlements") or []
    return {
        "currency": currency,
        "type": type,
        "count": len(rows),
        "continuation": res.get("continuation"),
        "settlements": rows,
        "fetched_at": int(time.time()),
    }


if __name__ == "__main__":
    out = get_settlements(count=5)
    print(json.dumps(out, indent=2, default=str))

# Run from Digital-Ocean-Server:
#   python -m portfolio_analysis_AI_Agent.tools.datafetch.market.get_settlements
