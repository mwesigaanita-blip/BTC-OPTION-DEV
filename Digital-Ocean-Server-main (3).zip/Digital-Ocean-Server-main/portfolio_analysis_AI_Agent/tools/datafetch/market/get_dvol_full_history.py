"""Tool: datafetch.market.get_dvol_full_history

Paginated DVOL (BTC implied-vol index) fetcher. Deribit's
``public/get_volatility_index_data`` caps a single call at 1000 samples
but accepts ``start_timestamp``/``end_timestamp``, so we walk backwards
in fixed-size windows until we have ``days`` covered (or Deribit returns
an empty page = we've hit DVOL inception).

Resolutions supported: ``"3600"`` (1h), ``"43200"`` (12h), ``"1D"``.
"""

from __future__ import annotations

import json
import time

import requests

from portfolio_analysis_AI_Agent.tools._auth import rpc_url


_PER_CALL_LIMIT = 1000
_RES_TO_MS = {
    "3600": 3_600_000,
    "43200": 43_200_000,
    "1D": 86_400_000,
}


def _one_call(start_ms: int, end_ms: int, resolution: str) -> list[list]:
    payload = {
        "jsonrpc": "2.0", "id": 1,
        "method": "public/get_volatility_index_data",
        "params": {
            "currency": "BTC",
            "start_timestamp": start_ms,
            "end_timestamp": end_ms,
            "resolution": resolution,
        },
    }
    r = requests.post(rpc_url(), json=payload, timeout=30)
    body = r.json()
    if body.get("error"):
        raise RuntimeError(f"Deribit error: {body['error']}")
    return (body.get("result") or {}).get("data") or []


def get_dvol_full_history(*, days: int, resolution: str = "1D") -> dict:
    """Returns ``{resolution, samples[(ts_ms, close_pct)], sample_count, fetched_at}``.

    Walks backwards in 1000-sample windows until ``days`` covered.
    """
    if resolution not in _RES_TO_MS:
        raise ValueError(
            f"unsupported resolution: {resolution!r} (use '3600','43200','1D')"
        )
    bar_ms = _RES_TO_MS[resolution]
    end_ms = int(time.time() * 1000)
    target_start = end_ms - int(days * 86_400_000)
    window_ms = _PER_CALL_LIMIT * bar_ms

    merged: dict[int, float] = {}
    cur_end = end_ms
    while cur_end > target_start:
        cur_start = max(target_start, cur_end - window_ms)
        rows = _one_call(cur_start, cur_end, resolution)
        if not rows:
            break  # hit DVOL inception or empty page
        progressed = False
        for row in rows:
            # row = [ts_ms, open, high, low, close]
            if isinstance(row, (list, tuple)) and len(row) >= 5:
                ts = int(row[0])
                if ts not in merged:
                    progressed = True
                merged[ts] = float(row[4])
        if not progressed:
            break  # all rows already seen - prevents infinite loop
        oldest = min(int(r[0]) for r in rows if isinstance(r, (list, tuple)))
        if oldest >= cur_end:
            break
        cur_end = oldest

    samples = sorted(merged.items())
    return {
        "resolution": resolution,
        "samples": samples,
        "sample_count": len(samples),
        "fetched_at": int(time.time()),
    }


if __name__ == "__main__":
    out = get_dvol_full_history(days=1800, resolution="1D")
    print(json.dumps({
        "resolution": out["resolution"],
        "n": out["sample_count"],
        "first": out["samples"][0] if out["samples"] else None,
        "last":  out["samples"][-1] if out["samples"] else None,
    }, indent=2))

# Run from Digital-Ocean-Server:
#   python -m portfolio_analysis_AI_Agent.tools.datafetch.market.get_dvol_full_history
