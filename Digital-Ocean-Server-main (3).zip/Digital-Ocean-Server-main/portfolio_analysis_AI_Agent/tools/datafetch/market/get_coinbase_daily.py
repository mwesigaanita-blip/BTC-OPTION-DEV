"""Tool: datafetch.market.get_coinbase_daily

Daily OHLCV from Coinbase Exchange public candles endpoint (no API key).
Used as a fallback for Binance, which returns HTTP 451 from many cloud
datacenter IPs (Digital Ocean included).

Endpoint: GET https://api.exchange.coinbase.com/products/{product}/candles
    ?granularity=86400&start=ISO&end=ISO

Coinbase returns at most 300 candles per request, in DESCENDING time
order, each as ``[time, low, high, open, close, volume]`` with ``time``
in unix seconds. Today's partial candle is excluded for stability.

Output dict matches ``get_binance_daily`` so the two are drop-in
substitutes:
    {symbol, interval, lookback_days, rows: [{date, open, high, low, close, volume}], fetched_at}
"""
from __future__ import annotations

import json
import logging
import time
from datetime import datetime, timedelta, timezone

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry


log = logging.getLogger("tools.market.get_coinbase_daily")

_BASE_URL = "https://api.exchange.coinbase.com/products/{product}/candles"
_MAX_CANDLES = 300  # Coinbase hard cap per request
_DAY_SEC = 86_400

# Labels (caller-facing) -> Coinbase product ids. ZEC was delisted from
# Coinbase Exchange in 2023; fetches will 404 and the caller logs the gap.
ALT_PRODUCTS: dict[str, str] = {
    "BTC":  "BTC-USD",
    "ETH":  "ETH-USD",
    "SOL":  "SOL-USD",
    "AVAX": "AVAX-USD",
    "ZEC":  "ZEC-USD",
    "DOGE": "DOGE-USD",
    "XRP":  "XRP-USD",
}


def _session() -> requests.Session:
    s = requests.Session()
    retry = Retry(
        total=5, connect=5, read=5, status=5,
        backoff_factor=0.5,
        status_forcelist=(429, 500, 502, 503, 504),
        allowed_methods=frozenset(["GET"]),
        raise_on_status=False,
    )
    s.mount("https://", HTTPAdapter(max_retries=retry, pool_connections=4, pool_maxsize=4))
    s.headers.update({"User-Agent": "btc-daily-quant/1.0"})
    return s


def _binance_to_coinbase(symbol: str) -> str:
    """Translate a Binance symbol like ``ETHUSDT`` to ``ETH-USD``.

    Pass-through if already a Coinbase product id.
    """
    if "-" in symbol:
        return symbol
    s = symbol.upper()
    for quote in ("USDT", "USDC", "USD"):
        if s.endswith(quote):
            return f"{s[:-len(quote)]}-USD"
    return s


def get_coinbase_daily(symbol: str, lookback_days: int = 800) -> dict:
    """Returns daily OHLCV rows for ``symbol`` over the last ``lookback_days``.

    ``symbol`` may be a Coinbase product id (``ETH-USD``) or a Binance
    symbol (``ETHUSDT``); the latter is translated automatically.
    """
    product = _binance_to_coinbase(symbol)
    sess = _session()

    end = datetime.now(timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0)
    start = end - timedelta(days=int(lookback_days))

    raw_rows: list[list] = []
    cursor_end = end
    # Coinbase caps at 300 candles, so paginate backwards in 300-day chunks.
    while cursor_end > start:
        cursor_start = max(start, cursor_end - timedelta(days=_MAX_CANDLES))
        params = {
            "granularity": _DAY_SEC,
            "start": cursor_start.isoformat().replace("+00:00", "Z"),
            "end": cursor_end.isoformat().replace("+00:00", "Z"),
        }
        url = _BASE_URL.format(product=product)
        r = sess.get(url, params=params, timeout=(3.05, 20))
        r.raise_for_status()
        chunk = r.json() or []
        if not chunk:
            break
        raw_rows.extend(chunk)
        # Step the window further back; subtract one day to avoid overlap.
        cursor_end = cursor_start
        if len(chunk) < _MAX_CANDLES:
            break
        time.sleep(0.15)

    today_iso = datetime.now(timezone.utc).date().isoformat()
    seen: set[str] = set()
    rows: list[dict] = []
    for k in raw_rows:
        # Coinbase row: [time_sec, low, high, open, close, volume]
        d = datetime.utcfromtimestamp(int(k[0])).strftime("%Y-%m-%d")
        if d >= today_iso or d in seen:
            continue
        seen.add(d)
        rows.append({
            "date": d,
            "open":  float(k[3]),
            "high":  float(k[2]),
            "low":   float(k[1]),
            "close": float(k[4]),
            "volume": float(k[5]),
        })
    rows.sort(key=lambda r: r["date"])

    return {
        "symbol": product,
        "interval": "1d",
        "lookback_days": int(lookback_days),
        "rows": rows,
        "count": len(rows),
        "fetched_at": int(time.time()),
    }


if __name__ == "__main__":
    out = get_coinbase_daily("ETHUSDT", lookback_days=10)
    print(json.dumps({**out, "rows": out["rows"][:3] + ["..."] + out["rows"][-3:]}, indent=2, default=str))

# Run from Digital-Ocean-Server:
#   python -m portfolio_analysis_AI_Agent.tools.datafetch.market.get_coinbase_daily
