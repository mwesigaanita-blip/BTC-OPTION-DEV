"""Tool: datafetch.market.get_yahoo_daily

Daily OHLCV directly from Yahoo Finance's public chart endpoint, using
``curl_cffi`` for browser TLS impersonation. No ``yfinance`` dependency
(avoids the ``websockets>=13`` conflict with this repo's
``websockets==12`` pin) and no API key.

Endpoint: ``https://query1.finance.yahoo.com/v8/finance/chart/{ticker}``

Yahoo began TLS-fingerprinting Python's stdlib ``requests`` traffic in
2025 and replies with empty/HTML for blocked clients. A ``curl_cffi``
session impersonating Chrome's JA3 fingerprint passes through cleanly.

Used by the Daily Quant dashboard for crypto-mining equities
(MSTR / MARA / RIOT / COIN) and macro benchmarks (S&P 500 ``^GSPC``,
front-month gold futures ``GC=F``, dollar index ``DX-Y.NYB``).

Output dict::

    {ticker, range, rows: [{date, open, high, low, close, volume}], fetched_at}
"""
from __future__ import annotations

import json
import logging
import time
from datetime import datetime, timezone
from typing import Any


log = logging.getLogger("tools.market.get_yahoo_daily")


_BASE_URL = "https://query1.finance.yahoo.com/v8/finance/chart/{ticker}"

EQUITY_TICKERS: list[str] = ["MSTR", "MARA", "RIOT", "COIN"]

# Caller label -> Yahoo ticker.
BENCHMARK_TICKERS: dict[str, str] = {
    "SPX":  "^GSPC",
    "GOLD": "GC=F",
    "DXY":  "DX-Y.NYB",
    "VIX":  "^VIX",
    "TIPS": "TIP",     # iShares TIPS Bond ETF — daily-priced TIPS proxy
}


_session_cache: list[Any] = []


def _browser_session():
    """Return a cached ``curl_cffi`` Chrome-impersonating session."""
    if _session_cache:
        return _session_cache[0]
    try:
        from curl_cffi import requests as curl_requests  # type: ignore
    except ImportError as e:
        raise RuntimeError(
            "curl_cffi not installed - Yahoo Finance blocks plain requests. "
            "Install with: pip install curl_cffi"
        ) from e
    s = curl_requests.Session(impersonate="chrome")
    _session_cache.append(s)
    return s


def _parse_chart(payload: dict) -> list[dict]:
    """Parse Yahoo's v8 chart JSON into ``[{date, open, high, low, close, volume}]``."""
    chart = (payload or {}).get("chart") or {}
    err = chart.get("error")
    if err:
        raise RuntimeError(f"Yahoo chart error: {err}")
    result = (chart.get("result") or [None])[0]
    if not result:
        return []
    timestamps = result.get("timestamp") or []
    indicators = result.get("indicators") or {}
    quote = (indicators.get("quote") or [{}])[0]
    opens   = quote.get("open")   or []
    highs   = quote.get("high")   or []
    lows    = quote.get("low")    or []
    closes  = quote.get("close")  or []
    volumes = quote.get("volume") or []

    rows: list[dict] = []
    today_iso = datetime.now(timezone.utc).date().isoformat()
    for i, ts in enumerate(timestamps):
        c = closes[i] if i < len(closes) else None
        if c is None:
            continue
        d = datetime.fromtimestamp(int(ts), tz=timezone.utc).date().isoformat()
        if d >= today_iso:  # skip the partial in-progress candle
            continue

        def _f(v):
            try:
                return None if v is None else float(v)
            except (TypeError, ValueError):
                return None

        rows.append({
            "date":   d,
            "open":   _f(opens[i])   if i < len(opens)   else None,
            "high":   _f(highs[i])   if i < len(highs)   else None,
            "low":    _f(lows[i])    if i < len(lows)    else None,
            "close":  float(c),
            "volume": _f(volumes[i]) if i < len(volumes) else 0.0,
        })

    rows.sort(key=lambda r: r["date"])
    # Drop duplicate dates (Yahoo occasionally repeats the most recent bar).
    dedup: dict[str, dict] = {r["date"]: r for r in rows}
    return [dedup[d] for d in sorted(dedup)]


def get_yahoo_daily(
    ticker: str,
    range_: str = "2y",
    max_attempts: int = 3,
) -> dict:
    """Daily OHLCV for ``ticker``.

    ``range_`` uses Yahoo syntax: ``1mo``, ``3mo``, ``6mo``, ``1y``, ``2y``,
    ``5y``, ``10y``, ``ytd``, ``max``. Retries on transient failures.
    """
    sess = _browser_session()
    url = _BASE_URL.format(ticker=ticker)
    params = {"range": range_, "interval": "1d", "includePrePost": "false"}

    last_err: Exception | None = None
    for attempt in range(1, max_attempts + 1):
        try:
            r = sess.get(url, params=params, timeout=30)
            if r.status_code != 200:
                raise RuntimeError(f"HTTP {r.status_code}: {r.text[:120]}")
            data = r.json()
            rows = _parse_chart(data)
            if rows:
                return {
                    "ticker": ticker,
                    "range": range_,
                    "rows": rows,
                    "count": len(rows),
                    "fetched_at": int(time.time()),
                }
            last_err = RuntimeError("Yahoo returned no rows")
        except Exception as e:
            last_err = e
            log.warning("yahoo %s attempt %d/%d failed: %s", ticker, attempt, max_attempts, e)
        if attempt < max_attempts:
            time.sleep(0.5 * (2 ** (attempt - 1)))

    log.error("yahoo %s exhausted retries: %s", ticker, last_err)
    return {
        "ticker": ticker,
        "range": range_,
        "rows": [],
        "count": 0,
        "fetched_at": int(time.time()),
        "error": str(last_err) if last_err else "unknown",
    }


if __name__ == "__main__":
    out = get_yahoo_daily("GOLD", range_="1mo")
    sample = out["rows"][:3] + ["…"] + out["rows"][-3:] if out["count"] > 6 else out["rows"]
    print(json.dumps({**out, "rows": sample}, indent=2, default=str))

# Run from Digital-Ocean-Server:
#   python -m portfolio_analysis_AI_Agent.tools.datafetch.market.get_yahoo_daily
