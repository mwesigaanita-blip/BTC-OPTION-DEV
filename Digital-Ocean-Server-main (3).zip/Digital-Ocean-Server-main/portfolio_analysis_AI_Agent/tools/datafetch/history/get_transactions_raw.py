"""Tool: datafetch.history.get_transactions_raw

Calls Deribit `private/get_transaction_log`. Returns raw transaction rows
for the given currency over a time window.
"""

from __future__ import annotations

import json
import time
from typing import Optional

import requests

from portfolio_analysis_AI_Agent.tools._auth import get_access_token, rpc_url


def get_transactions_raw(
    currency: str = "BTC",
    days: int = 7,
    count: int = 100,
    query: Optional[str] = None,
) -> dict:
    """Returns {currency, count, has_more, logs[], fetched_at}.

    Window defaults to the last `days` days ending now.
    `query` is an optional substring filter (Deribit's native).
    """
    end_ms = int(time.time() * 1000)
    start_ms = end_ms - int(days * 24 * 3600 * 1000)

    params: dict = {
        "currency": currency,
        "start_timestamp": start_ms,
        "end_timestamp": end_ms,
        "count": int(count),
    }
    if query:
        params["query"] = query

    payload = {
        "jsonrpc": "2.0",
        "id": 1,
        "method": "private/get_transaction_log",
        "params": params,
    }
    headers = {"Authorization": f"Bearer {get_access_token()}"}
    r = requests.post(rpc_url(), json=payload, headers=headers, timeout=15)
    body = r.json()
    if body.get("error"):
        raise RuntimeError(f"Deribit error: {body['error']}")
    res = body.get("result") or {}
    logs = res.get("logs") or []
    return {
        "currency": currency,
        "days": days,
        "count": len(logs),
        "continuation": res.get("continuation"),
        "logs": logs,
        "fetched_at": int(time.time()),
    }


if __name__ == "__main__":
    out = get_transactions_raw(count=5)
    print(json.dumps(out, indent=2, default=str))

# Run from Digital-Ocean-Server:
#   python -m portfolio_analysis_AI_Agent.tools.datafetch.history.get_transactions_raw
