"""Tool: datafetch.history.get_account_settlements

Calls Deribit `private/get_transaction_log` three times (one per type:
`settlement`, `delivery`, `liquidation`) and merges the results into a
single chronologically sorted list of account-level settlement events.

Deribit's `query` parameter accepts only one keyword per call, so we
issue three sequential calls and merge. This is the account-specific
counterpart to `datafetch.market.get_settlements`, which returns market-wide
settlements.
"""

from __future__ import annotations

import json
import time
from typing import Iterable, Optional

import requests

from portfolio_analysis_AI_Agent.tools._auth import get_access_token, rpc_url


ALLOWED_TYPES = ("settlement", "delivery", "liquidation")


def _fetch_one(
    currency: str,
    query: str,
    start_ms: int,
    end_ms: int,
    count: int,
    token: str,
) -> list[dict]:
    payload = {
        "jsonrpc": "2.0",
        "id": 1,
        "method": "private/get_transaction_log",
        "params": {
            "currency": currency,
            "start_timestamp": start_ms,
            "end_timestamp": end_ms,
            "query": query,
            "count": int(count),
        },
    }
    headers = {"Authorization": f"Bearer {token}"}
    r = requests.post(rpc_url(), json=payload, headers=headers, timeout=15)
    body = r.json()
    if body.get("error"):
        raise RuntimeError(f"Deribit error ({query}): {body['error']}")
    return (body.get("result") or {}).get("logs") or []


def get_account_settlements(
    currency: str = "BTC",
    days: int = 30,
    count: int = 100,
    types: Optional[Iterable[str]] = None,
) -> dict:
    """Returns merged account-settlement events within the last `days`.

    Args:
        currency: e.g. "BTC".
        days: lookback window ending now.
        count: max rows fetched per type (Deribit cap: 250). Final merged
            list may be larger (up to ~3*count before sort/dedup).
        types: subset of ALLOWED_TYPES; defaults to all three.

    Returns:
        {
          currency, days, count,
          types: [...],
          counts_by_type: {settlement: N, delivery: N, liquidation: N},
          logs: [...],   # merged, sorted desc by timestamp
          fetched_at,
        }
    """
    selected = tuple(types) if types else ALLOWED_TYPES
    bad = [t for t in selected if t not in ALLOWED_TYPES]
    if bad:
        raise ValueError(f"Unsupported settlement types: {bad}. Allowed: {ALLOWED_TYPES}")

    end_ms = int(time.time() * 1000)
    start_ms = end_ms - int(days * 24 * 3600 * 1000)
    token = get_access_token()

    merged: list[dict] = []
    counts_by_type: dict[str, int] = {}
    for t in selected:
        rows = _fetch_one(currency, t, start_ms, end_ms, count, token)
        counts_by_type[t] = len(rows)
        merged.extend(rows)

    # Dedup on (id, type) - Deribit rows carry a unique `id`; same row should
    # not return for multiple query types, but guard anyway.
    seen: set[tuple] = set()
    deduped: list[dict] = []
    for row in merged:
        key = (row.get("id"), row.get("type"))
        if key in seen:
            continue
        seen.add(key)
        deduped.append(row)

    deduped.sort(key=lambda x: int(x.get("timestamp") or 0), reverse=True)

    return {
        "currency": currency,
        "days": days,
        "count": len(deduped),
        "types": list(selected),
        "counts_by_type": counts_by_type,
        "logs": deduped,
        "fetched_at": int(time.time()),
    }


if __name__ == "__main__":
    out = get_account_settlements(days=30, count=50)
    sample = out["logs"][:5]
    print(json.dumps({**out, "logs": sample, "sample_size": len(sample)}, indent=2, default=str))

# Run from Digital-Ocean-Server:
#   python -m portfolio_analysis_AI_Agent.tools.datafetch.history.get_account_settlements
