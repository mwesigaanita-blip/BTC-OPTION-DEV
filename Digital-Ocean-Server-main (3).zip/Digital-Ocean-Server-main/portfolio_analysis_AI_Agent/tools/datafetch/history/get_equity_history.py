"""Tool: datafetch.history.get_equity_history

Reads the equity time-series from `snapshots.sqlite::account_snapshots`
- the same source the `Streamlit/pages/Positions_History.py` page reads
from. Returns ascending-sorted `[{ts, ts_ms, date, equity_usd,
equity_btc}]` rows ready to feed into `analysis.risk_compute`.

The `account_snapshots` row shape is `(date TEXT, payload_json TEXT)`
where the JSON carries `total_equity_usd` (preferred), with legacy
fallbacks `capital_usd` / `equity_usd`. The BTC index price is pulled
from `payload.per_currency.BTC.index_price_usd` (with fallbacks).
"""

from __future__ import annotations

import json
import sqlite3
import time
from datetime import datetime, timezone
from typing import Optional


def _import_snapshots_db_path() -> str:
    """Import the canonical snapshots DB path. Falls back to ``data/snapshots.sqlite``
    relative to the repo root if `shared.db_paths` is not on sys.path."""
    try:
        from shared.db_paths import SNAPSHOTS_DB
        return str(SNAPSHOTS_DB)
    except Exception:
        from pathlib import Path
        repo = Path(__file__).resolve().parents[4]
        return str(repo / "data" / "snapshots.sqlite")


def _parse_date_to_ms(date_str: str) -> Optional[int]:
    """Parse the `date` column ('YYYY-MM-DD' or ISO-ish) → UTC midnight ms."""
    if not date_str:
        return None
    s = str(date_str).strip().replace("T", " ").replace("Z", "")
    for fmt in ("%Y-%m-%d", "%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M:%S.%f"):
        try:
            dt = datetime.strptime(s.split(".")[0] if "%f" not in fmt else s, fmt)
            return int(dt.replace(tzinfo=timezone.utc).timestamp() * 1000)
        except ValueError:
            continue
    try:
        return int(datetime.fromisoformat(s).replace(tzinfo=timezone.utc).timestamp() * 1000)
    except Exception:
        return None


def _row_to_record(date_str: str, payload_json: str) -> Optional[dict]:
    try:
        data = json.loads(payload_json) if isinstance(payload_json, str) else (payload_json or {})
    except Exception:
        return None

    eq_usd = data.get("total_equity_usd")
    if eq_usd is None or float(eq_usd or 0) <= 0:
        eq_usd = data.get("capital_usd") or data.get("equity_usd") or 0
    try:
        eq_usd = float(eq_usd)
    except (TypeError, ValueError):
        return None
    if eq_usd <= 0:
        return None

    per_cur = data.get("per_currency") or {}
    btc_acc = per_cur.get("BTC") or {}
    idx_raw = (
        btc_acc.get("index_price_usd")
        or (data.get("btc_changes") or {}).get("index_price_usd")
        or data.get("index_price_usd")
        or 0
    )
    try:
        idx = float(idx_raw)
    except (TypeError, ValueError):
        idx = 0.0

    eq_btc = round(eq_usd / idx, 6) if idx > 0 else None
    ts_ms = _parse_date_to_ms(date_str)
    if ts_ms is None:
        return None

    return {
        "ts": ts_ms // 1000,
        "ts_ms": ts_ms,
        "date": date_str,
        "equity_usd": round(eq_usd, 2),
        "equity_btc": eq_btc,
        "index_price_usd": idx if idx > 0 else None,
    }


def get_equity_history(days: Optional[int] = 400, db_path: Optional[str] = None) -> dict:
    """Return ascending equity history snapshots.

    Args:
        days: lookback window ending now. None = no limit. Default 400
            comfortably covers 1y windows + YTD.
        db_path: explicit snapshots.sqlite path. None = resolve via
            `shared.db_paths.SNAPSHOTS_DB`.

    Returns:
        {currency_focus, count, history: [...], fetched_at}.
    """
    path = db_path or _import_snapshots_db_path()

    with sqlite3.connect(path) as conn:
        rows = conn.execute(
            "SELECT date, payload_json FROM account_snapshots ORDER BY date ASC"
        ).fetchall()

    records: list[dict] = []
    for date_str, payload in rows:
        rec = _row_to_record(date_str, payload)
        if rec:
            records.append(rec)

    # De-dupe by date - keep last snapshot per day (matches Positions_History
    # which does .groupby("date").last()).
    by_date: dict[str, dict] = {}
    for r in records:
        by_date[r["date"]] = r
    records = sorted(by_date.values(), key=lambda r: r["ts_ms"])

    if days is not None and days > 0 and records:
        cutoff_ms = int(time.time() * 1000) - days * 86400 * 1000
        records = [r for r in records if r["ts_ms"] >= cutoff_ms]

    return {
        "source": "snapshots.sqlite::account_snapshots",
        "db_path": str(path),
        "days": days,
        "count": len(records),
        "history": records,
        "fetched_at": int(time.time()),
    }


if __name__ == "__main__":
    out = get_equity_history(days=90)
    sample = out["history"][-5:]
    print(json.dumps({**out, "history": sample, "sample_size": len(sample)}, indent=2, default=str))

# Run from Digital-Ocean-Server:
#   python -m portfolio_analysis_AI_Agent.tools.datafetch.history.get_equity_history
