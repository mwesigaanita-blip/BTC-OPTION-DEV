"""Tool: jobs.vol_tick

Periodic HV / IV / spot collector. One call = one DB row's worth of data.

Reuses the existing Deribit datafetch helpers:

* HV30  -> public/get_historical_volatility (latest sample, %)
* IV30  -> public/get_volatility_index_data DVOL (latest hourly close, %)
* spot  -> public/get_index_price (btc_usd)

Also exposes ``backfill_vol_history(days)`` for the one-shot seed run when
the ``vol_ticks`` table is empty.
"""

from __future__ import annotations

import time
from datetime import datetime, timezone
from typing import Optional

import requests

from portfolio_analysis_AI_Agent.tools._auth import rpc_url
from portfolio_analysis_AI_Agent.tools.datafetch.market.get_dvol import get_dvol
from portfolio_analysis_AI_Agent.tools.datafetch.market.get_historical_volatility import (
    get_historical_volatility,
)
from portfolio_analysis_AI_Agent.tools.datafetch.market.get_index_price import (
    get_index_price,
)


def _iso(ms: Optional[int] = None) -> str:
    dt = (
        datetime.fromtimestamp(ms / 1000.0, tz=timezone.utc)
        if ms is not None
        else datetime.now(timezone.utc)
    )
    return dt.strftime("%Y-%m-%dT%H:%M:%S.%f") + "Z"


def collect_vol_tick() -> Optional[dict]:
    """Single live tick. Returns ``{ts_utc, hv30, iv30, btc_price}``.

    On hard failure returns ``None`` (caller logs + continues).
    """
    try:
        hv = get_historical_volatility("BTC")
        dvol = get_dvol("BTC", resolution="3600", days=1)
        spot = get_index_price("btc_usd")
    except (requests.RequestException, RuntimeError):
        return None

    hv30 = hv.get("latest")
    iv30 = dvol.get("latest_close")
    px = spot.get("index_price")
    if hv30 is None and iv30 is None:
        return None

    return {
        "ts_utc": _iso(),
        "hv30": float(hv30) if hv30 is not None else None,
        "iv30": float(iv30) if iv30 is not None else None,
        "btc_price": float(px) if px else None,
    }


# ---------------------------------------------------------------------------
# Backfill
# ---------------------------------------------------------------------------

def _fetch_dvol_window(days: int) -> list[tuple[int, float]]:
    """Hourly DVOL closes for the last ``days`` days. Returns [(ts_ms, iv_pct), ...]."""
    end_ms = int(time.time() * 1000)
    start_ms = end_ms - int(days * 86_400_000)
    payload = {
        "jsonrpc": "2.0", "id": 1,
        "method": "public/get_volatility_index_data",
        "params": {
            "currency": "BTC",
            "start_timestamp": start_ms,
            "end_timestamp": end_ms,
            "resolution": "3600",
        },
    }
    r = requests.post(rpc_url(), json=payload, timeout=30)
    body = r.json()
    if body.get("error"):
        raise RuntimeError(f"Deribit error: {body['error']}")
    data = (body.get("result") or {}).get("data") or []
    out: list[tuple[int, float]] = []
    for row in data:
        # row = [ts_ms, open, high, low, close]
        if isinstance(row, (list, tuple)) and len(row) >= 5:
            out.append((int(row[0]), float(row[4])))
    return out


def _fetch_hv_window() -> list[tuple[int, float]]:
    """All HV samples Deribit will give us (~15 days hourly). [(ts_ms, hv_pct)]."""
    hv = get_historical_volatility("BTC")
    out: list[tuple[int, float]] = []
    for row in hv.get("samples") or []:
        if isinstance(row, (list, tuple)) and len(row) >= 2:
            out.append((int(row[0]), float(row[1])))
    return out


def backfill_vol_history(days: int = 90) -> list[dict]:
    """Build hourly-aligned vol rows for the last ``days`` days.

    Returns a list of ``{ts_utc, hv30, iv30, btc_price=None}`` dicts, one per
    hourly UTC bucket. Where one series is missing for a bucket the other side
    is preserved with NULL on the missing one. Spot is left NULL (cheap to
    recompute later if anyone wants it).

    Raises on Deribit/network failure - the caller is expected to swallow it
    and proceed to forward collection.
    """
    iv_pairs = _fetch_dvol_window(days)
    hv_pairs = _fetch_hv_window()

    HOUR_MS = 3_600_000

    def _bucket(ms: int) -> int:
        return (ms // HOUR_MS) * HOUR_MS

    iv_by_bucket: dict[int, float] = {}
    for ms, v in iv_pairs:
        iv_by_bucket[_bucket(ms)] = v

    hv_by_bucket: dict[int, float] = {}
    for ms, v in hv_pairs:
        hv_by_bucket[_bucket(ms)] = v

    all_buckets = sorted(set(iv_by_bucket) | set(hv_by_bucket))
    rows: list[dict] = []
    for b in all_buckets:
        rows.append({
            "ts_utc": _iso(b),
            "hv30": hv_by_bucket.get(b),
            "iv30": iv_by_bucket.get(b),
            "btc_price": None,
        })
    return rows


if __name__ == "__main__":
    import json
    print(json.dumps(collect_vol_tick(), indent=2))

# Run from Digital-Ocean-Server:
#   python -m portfolio_analysis_AI_Agent.tools.jobs.vol_tick
