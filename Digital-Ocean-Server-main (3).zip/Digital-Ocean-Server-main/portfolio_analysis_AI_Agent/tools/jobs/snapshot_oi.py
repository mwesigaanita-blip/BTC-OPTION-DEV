"""Tool: jobs.snapshot_oi

Persists an open-interest snapshot of every active option to
``snapshots.sqlite`` so downstream tools can diff OI across time
(new positions vs unwinds). Idempotent on (snapshot_ts, instrument_name);
re-runs at the same second silently overwrite.

Schedule this from cron / the existing worker at 1-24 hour cadence.
Recommended: hourly on the server, with the reader picking the closest
prior snapshot to the requested lookback.

Run from Digital-Ocean-Server:
    python -m portfolio_analysis_AI_Agent.tools.jobs.snapshot_oi
"""

from __future__ import annotations

import json
import sqlite3
import time
from typing import Any

from shared.db_paths import SNAPSHOTS_DB, get_connection
from portfolio_analysis_AI_Agent.tools.datafetch.market.get_book_summary import get_book_summary


_DDL = """
CREATE TABLE IF NOT EXISTS oi_snapshots (
    snapshot_ts     INTEGER NOT NULL,
    currency        TEXT    NOT NULL,
    instrument_name TEXT    NOT NULL,
    expiry          TEXT,
    strike          REAL,
    type            TEXT,
    open_interest   REAL,
    volume_24h      REAL,
    mark_iv         REAL,
    PRIMARY KEY (snapshot_ts, instrument_name)
);
"""

_IDX_BY_CT = "CREATE INDEX IF NOT EXISTS idx_oi_snapshots_ct ON oi_snapshots(currency, snapshot_ts);"
_IDX_BY_INST = "CREATE INDEX IF NOT EXISTS idx_oi_snapshots_inst ON oi_snapshots(instrument_name, snapshot_ts);"


def _f(x: Any, default: float | None = None) -> float | None:
    try:
        return float(x) if x is not None else default
    except (TypeError, ValueError):
        return default


def _parse_name(name: str) -> tuple[str | None, float | None, str | None]:
    parts = (name or "").split("-")
    if len(parts) < 4:
        return None, None, None
    try:
        return parts[1], float(parts[2]), ("C" if name.endswith("-C") else "P" if name.endswith("-P") else None)
    except ValueError:
        return parts[1], None, None


def _ensure_schema(conn: sqlite3.Connection) -> None:
    conn.execute(_DDL)
    conn.execute(_IDX_BY_CT)
    conn.execute(_IDX_BY_INST)
    conn.commit()


def snapshot_oi(currency: str = "BTC", snapshot_ts: int | None = None) -> dict:
    """Pull a book_summary and write one row per option to oi_snapshots."""
    ts = int(snapshot_ts) if snapshot_ts is not None else int(time.time())
    bs = get_book_summary(currency=currency, kind="option")
    rows = bs.get("rows") or []

    conn = get_connection(SNAPSHOTS_DB)
    try:
        _ensure_schema(conn)

        written = 0
        batch: list[tuple] = []
        for r in rows:
            name = str(r.get("instrument_name") or "")
            exp, strike, typ = _parse_name(name)
            if not exp or strike is None or not typ:
                continue
            batch.append((
                ts,
                currency,
                name,
                exp,
                strike,
                typ,
                _f(r.get("open_interest")),
                _f(r.get("volume")),
                _f(r.get("mark_iv")),
            ))
        if batch:
            conn.executemany(
                "INSERT OR REPLACE INTO oi_snapshots "
                "(snapshot_ts, currency, instrument_name, expiry, strike, type, open_interest, volume_24h, mark_iv) "
                "VALUES (?,?,?,?,?,?,?,?,?)",
                batch,
            )
            written = len(batch)
            conn.commit()

        return {
            "snapshot_ts": ts,
            "currency": currency,
            "instruments_written": written,
            "rows_seen": len(rows),
            "db": str(SNAPSHOTS_DB),
        }
    finally:
        conn.close()


if __name__ == "__main__":
    print(json.dumps(snapshot_oi(), indent=2, default=str))
