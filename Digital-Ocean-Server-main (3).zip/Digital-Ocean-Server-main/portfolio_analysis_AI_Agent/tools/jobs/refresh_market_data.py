"""Tool: jobs.refresh_market_data

Nightly refresh for the Daily Quant dashboard. Pulls daily candles for
alt-crypto (Binance), equities and macro benchmarks (yfinance) and
upserts them into ``MARKET_DATA_DB`` alongside the existing
``btc_prices`` table.

Schedule daily, just after 00:30 UTC:

Linux cron::

    30 0 * * * cd /opt/btc_app && \
        python -m portfolio_analysis_AI_Agent.tools.jobs.refresh_market_data \
        >> /var/log/quant_refresh.log 2>&1

Windows Task Scheduler: same command, daily 00:30 UTC.

Run from Digital-Ocean-Server (manual):
    python -m portfolio_analysis_AI_Agent.tools.jobs.refresh_market_data
"""
from __future__ import annotations

import json
import logging
import sqlite3
import sys
import time
from typing import Any, Iterable

from shared.db_paths import MARKET_DATA_DB
from portfolio_analysis_AI_Agent.tools.datafetch.market.get_binance_daily import (
    ALT_SYMBOLS,
)
from portfolio_analysis_AI_Agent.tools.datafetch.market.get_coinbase_daily import (
    get_coinbase_daily,
)
from portfolio_analysis_AI_Agent.tools.datafetch.market.get_btc_etf_flows import (
    get_btc_etf_flows,
)
from portfolio_analysis_AI_Agent.tools.datafetch.market.get_yahoo_daily import (
    BENCHMARK_TICKERS,
    EQUITY_TICKERS,
    get_yahoo_daily,
)


log = logging.getLogger("tools.jobs.refresh_market_data")


def _backfill_btc_prices_from_binance(lookback_days: int) -> int:
    """Fill any missing dates in ``btc_prices`` from Coinbase BTC-USD.

    The existing Deribit-driven pipeline occasionally drops days; this
    additive backfill makes the table dense without overwriting any
    row that already exists. Coinbase is used (not Binance) since
    Binance geo-blocks US datacenter IPs.
    """
    try:
        fetched = get_coinbase_daily("BTCUSDT", lookback_days=lookback_days)
    except Exception:
        log.exception("BTCUSDT backfill fetch failed")
        return 0

    rows = fetched.get("rows") or []
    if not rows:
        return 0

    sql = (
        "INSERT INTO btc_prices(date, open, high, low, close, change, percent_change, volume) "
        "VALUES (?, ?, ?, ?, ?, NULL, NULL, ?) "
        "ON CONFLICT(date) DO NOTHING"
    )
    params = [
        (r["date"], float(r["open"]), float(r["high"]), float(r["low"]),
         float(r["close"]), float(r.get("volume") or 0.0))
        for r in rows
    ]

    with _connect() as con:
        before = int(con.execute("SELECT COUNT(*) FROM btc_prices").fetchone()[0] or 0)
        con.executemany(sql, params)
        con.commit()
        after = int(con.execute("SELECT COUNT(*) FROM btc_prices").fetchone()[0] or 0)
    return after - before


_DDL = [
    """
    CREATE TABLE IF NOT EXISTS alt_prices (
        symbol  TEXT NOT NULL,
        date    TEXT NOT NULL,
        open    REAL NOT NULL,
        high    REAL NOT NULL,
        low     REAL NOT NULL,
        close   REAL NOT NULL,
        volume  REAL,
        PRIMARY KEY (symbol, date)
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS equity_prices (
        ticker  TEXT NOT NULL,
        date    TEXT NOT NULL,
        open    REAL,
        high    REAL,
        low     REAL,
        close   REAL NOT NULL,
        volume  REAL,
        PRIMARY KEY (ticker, date)
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS benchmark_prices (
        ticker  TEXT NOT NULL,
        date    TEXT NOT NULL,
        close   REAL NOT NULL,
        PRIMARY KEY (ticker, date)
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS btc_etf_flows (
        date         TEXT NOT NULL,
        ticker       TEXT NOT NULL,   -- ETF symbol or 'TOTAL'
        flow_usd_m   REAL,            -- nullable: '-' in source = no data
        PRIMARY KEY (date, ticker)
    )
    """,
]


def _connect() -> sqlite3.Connection:
    con = sqlite3.connect(str(MARKET_DATA_DB), timeout=30)
    con.execute("PRAGMA journal_mode=WAL;")
    con.execute("PRAGMA synchronous=NORMAL;")
    return con


def ensure_schema() -> None:
    with _connect() as con:
        for sql in _DDL:
            con.execute(sql)
        con.commit()


def _upsert(table: str, key_col: str, key_val: str, rows: list[dict]) -> int:
    if not rows:
        return 0
    if table == "alt_prices":
        sql = (
            "INSERT INTO alt_prices(symbol, date, open, high, low, close, volume) "
            "VALUES (?, ?, ?, ?, ?, ?, ?) "
            "ON CONFLICT(symbol, date) DO UPDATE SET "
            "open=excluded.open, high=excluded.high, low=excluded.low, "
            "close=excluded.close, volume=excluded.volume"
        )
        params: Iterable[tuple] = [
            (key_val, r["date"], float(r["open"]), float(r["high"]),
             float(r["low"]), float(r["close"]), float(r.get("volume") or 0.0))
            for r in rows
        ]
    elif table == "equity_prices":
        sql = (
            "INSERT INTO equity_prices(ticker, date, open, high, low, close, volume) "
            "VALUES (?, ?, ?, ?, ?, ?, ?) "
            "ON CONFLICT(ticker, date) DO UPDATE SET "
            "open=excluded.open, high=excluded.high, low=excluded.low, "
            "close=excluded.close, volume=excluded.volume"
        )
        def _f(v):
            return None if v is None else float(v)
        params = [
            (key_val, r["date"], _f(r.get("open")), _f(r.get("high")),
             _f(r.get("low")), float(r["close"]), _f(r.get("volume")) or 0.0)
            for r in rows
        ]
    elif table == "benchmark_prices":
        sql = (
            "INSERT INTO benchmark_prices(ticker, date, close) VALUES (?, ?, ?) "
            "ON CONFLICT(ticker, date) DO UPDATE SET close=excluded.close"
        )
        params = [(key_val, r["date"], float(r["close"])) for r in rows]
    elif table == "btc_etf_flows":
        # rows: list of {date, ticker, flow_usd_m}; key_col/key_val unused.
        sql = (
            "INSERT INTO btc_etf_flows(date, ticker, flow_usd_m) VALUES (?, ?, ?) "
            "ON CONFLICT(date, ticker) DO UPDATE SET flow_usd_m=excluded.flow_usd_m"
        )
        params = [(r["date"], r["ticker"], r["flow_usd_m"]) for r in rows]
    else:
        raise ValueError(f"unknown table: {table}")

    with _connect() as con:
        con.executemany(sql, params)
        con.commit()
    return len(rows) if isinstance(params, list) else sum(1 for _ in params)


def table_counts() -> dict[str, int]:
    out: dict[str, int] = {}
    with _connect() as con:
        for t in ("alt_prices", "equity_prices", "benchmark_prices", "btc_etf_flows"):
            try:
                out[t] = int(con.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0] or 0)
            except sqlite3.OperationalError:
                out[t] = 0
    return out


def refresh_market_data(
    lookback_days: int = 800,
    equity_range: str = "2y",
) -> dict[str, Any]:
    """Pull all configured sources and upsert into MARKET_DATA_DB."""
    ensure_schema()
    summary: dict[str, Any] = {
        "alts": {}, "equities": {}, "benchmarks": {}, "etf_flows": 0,
        "btc_backfill": 0,
        "errors": [], "started_at": int(time.time()),
    }

    try:
        n = _backfill_btc_prices_from_binance(lookback_days)
        summary["btc_backfill"] = n
        log.info("btc_prices backfill: +%d rows", n)
    except Exception as e:
        log.exception("btc backfill failed")
        summary["errors"].append(f"btc_backfill:{e}")

    for label, sym in ALT_SYMBOLS.items():
        try:
            fetched = get_coinbase_daily(sym, lookback_days=lookback_days)
            n = _upsert("alt_prices", "symbol", label, fetched["rows"])
            summary["alts"][label] = n
            log.info("alt %s (%s) -> %d rows", label, sym, n)
        except Exception as e:
            log.exception("alt %s failed", label)
            summary["errors"].append(f"alt:{label}:{e}")

    for ticker in EQUITY_TICKERS:
        try:
            fetched = get_yahoo_daily(ticker, range_=equity_range)
            n = _upsert("equity_prices", "ticker", ticker, fetched["rows"])
            summary["equities"][ticker] = n
            log.info("equity %s -> %d rows", ticker, n)
        except Exception as e:
            log.exception("equity %s failed", ticker)
            summary["errors"].append(f"equity:{ticker}:{e}")

    for label, ticker in BENCHMARK_TICKERS.items():
        try:
            fetched = get_yahoo_daily(ticker, range_=equity_range)
            rows = [{"date": r["date"], "close": r["close"]} for r in fetched["rows"]]
            n = _upsert("benchmark_prices", "ticker", label, rows)
            summary["benchmarks"][label] = n
            log.info("benchmark %s (%s) -> %d rows", label, ticker, n)
        except Exception as e:
            log.exception("benchmark %s failed", label)
            summary["errors"].append(f"benchmark:{label}:{e}")

    try:
        flows = get_btc_etf_flows()
        rows: list[dict] = []
        for r in flows["rows"]:
            for tkr, v in r["flows"].items():
                rows.append({"date": r["date"], "ticker": tkr, "flow_usd_m": v})
            rows.append({"date": r["date"], "ticker": "TOTAL", "flow_usd_m": r["total"]})
        n = _upsert("btc_etf_flows", "", "", rows)
        summary["etf_flows"] = n
        log.info("etf_flows -> %d rows (%d days x %d funds)",
                 n, flows["count"], len(flows["tickers"]))
    except Exception as e:
        log.exception("etf_flows fetch failed")
        summary["errors"].append(f"etf_flows:{e}")

    summary["table_counts"] = table_counts()
    summary["finished_at"] = int(time.time())
    return summary


if __name__ == "__main__":
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(name)s | %(message)s",
        stream=sys.stdout,
    )
    out = refresh_market_data()
    print(json.dumps(out, indent=2, default=str))
    sys.exit(0 if not out["errors"] else 1)

# Run from Digital-Ocean-Server:
#   python -m portfolio_analysis_AI_Agent.tools.jobs.refresh_market_data
