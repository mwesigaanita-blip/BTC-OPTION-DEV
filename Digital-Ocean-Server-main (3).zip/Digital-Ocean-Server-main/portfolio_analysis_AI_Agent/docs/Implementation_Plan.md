# Portfolio Analysis AI Agent - Implementation Plan (V1)

## Context

Phase A research (`portfolio_analysis_AI_Agent/docs/Portfolio_Analysis_AI_Agent_Documentation.md`) is finalized for trader needs / risk / Greeks / volatility / stress / hedge concepts but left ~30 architecture decisions open. The user has now answered all of them. This plan converts those answers + a codebase inventory into an executable Phase B+C plan for V1.

**Goal of V1:** an answer-only, read-only AI agent that lets the trader ask questions about their Deribit BTC options portfolio via Telegram and the Streamlit dashboard, plus a daily AI summary auto-pushed to Telegram. No execution, no proactive monitoring beyond the daily push.

---

## Locked Decisions

| Topic | Decision |
|---|---|
| Agent framework | LangChain **OpenAI Tools Agent** pattern (works with Claude via `langchain-anthropic` tool-calling too) |
| Proactivity | Answer-only, plus 1×/day scheduled AI summary |
| Actions | **Read-only forever** (no order placement) |
| AI cadence | Daily summary + on-demand |
| Data sourcing | DB-first; live Deribit only when DB stale/missing |
| Memory | Conversation + portfolio context, SQLite-backed (no vector DB in V1) |
| Channels | Shared backend, separate threads per channel |
| Tool layering | Separate data tools / analysis tools / AI reasoning tools |
| Telegram input | Natural language + a few `/commands` |
| Telegram style | Short + actionable, expand on request |
| Dashboard | **Status/info page only in V1** (no chat). Telegram is the only interaction channel. |
| LLM provider | **Multi-provider with `/setmodel`** (Claude Sonnet 4.6, Opus 4.7, Haiku 4.5, GPT-4o/4.1, Grok-4) |
| Model scope | Per-user, persisted in SQLite |
| Telegram auth | Allowlist of chat IDs in env |
| Daily push | Auto-push to allowlist + on-demand `/summary` |
| Code location | New top-level `portfolio_analysis_AI_Agent/` package |
| Telegram bot | **New separate bot** (new token, distinct from existing portfolio bot) |
| Market endpoints | Adopt full §3.3 list as-is |

---

## Existing Assets to Reuse (do NOT reimplement)

| Asset | Path | Reuse for |
|---|---|---|
| Deribit client w/ retry/backoff | `hedge_engine/data/deribit_client.py` | All account + market calls. Extend only for missing endpoints. |
| Snapshot DBs | `data/realtime.sqlite`, `data/market_data.sqlite`, `data/hedge_engine.sqlite`, `data/portfolio_analysis.sqlite` | DB-first reads (positions, account, ticker, HV/IV, alerts) |
| Centralized DB paths | `shared/db_paths.py` | Path resolution |
| Telegram polling pattern | `portfolio_analysis/bot/server.py`, `portfolio_analysis/bot/commands.py` | Copy structure for new AI bot |
| Streamlit auth + page layout | `Streamlit/app.py`, `shared/streamlit_auth.py` | New chat page slot |
| Worker thread pattern | `portfolio_analysis/scheduler.py` (`DailyReportWorker`) | Daily AI summary worker |
| Dotenv loading convention | every module top: `load_dotenv()` | New env keys |
| Already-installed libs | `requirements.txt`: `langchain`, `langchain-anthropic`, `langchain-openai`, `anthropic`, `openai` | No new deps; use OpenAI-compatible Grok endpoint |

---

## Endpoints To Add to Deribit Client

Missing wrappers needed for V1 (extend `hedge_engine/data/deribit_client.py` or wrap in agent's data layer):

- `private/get_transaction_log`
- `private/get_user_trades_by_currency`
- `private/get_subaccounts`, `private/get_subaccounts_details`
- `private/get_open_orders_by_currency`, `private/get_order_history_by_currency`
- `private/get_user_locks`, `private/get_order_state`
- `public/get_tradingview_chart_data`
- `public/get_mark_price_history`
- `public/get_last_settlements_by_currency`
- `public/get_funding_rate_history`
- `public/get_delivery_prices`
- `public/get_index_price_names`, `public/get_supported_index_names`
- `public/get_time`

---

## Target Package Layout

```
portfolio_analysis_AI_Agent/
├── docs/                          # already exists
├── agent/
│   ├── __init__.py
│   ├── core.py                    # build_agent(), AgentExecutor wiring
│   ├── llm_router.py              # /setmodel resolver: provider+model -> ChatModel instance
│   ├── prompts.py                 # system prompt + per-tool descriptions
│   └── memory.py                  # SQLite chat history + portfolio context store
├── tools/
│   ├── __init__.py                # registry: TOOLS = [...]
│   ├── data/                      # DB-first, fall back to Deribit
│   │   ├── account.py             # get_account_summary, get_subaccounts*
│   │   ├── positions.py           # get_positions, open_orders, trades
│   │   ├── market.py              # ticker, order_book, HV/IV, funding, indices
│   │   └── history.py             # transaction_log, settlements, mark_price_history
│   ├── analysis/
│   │   ├── risk.py                # margin %, drawdown, leverage, classify SAFE/WARNING/...
│   │   ├── greeks.py              # net delta/gamma/vega/theta + classifications
│   │   ├── volatility.py          # HV vs IV, regime LOW/NORMAL/HIGH/EXTREME
│   │   ├── stress.py              # BTC ±5/±10, vol expansion/crush; reuse pme/simulate
│   │   └── hedge.py               # hedge suggestion logic (read-only, suggest only)
│   └── reasoning/
│       ├── summarize.py           # AI portfolio summary
│       ├── explain.py             # AI explanation of state/changes
│       └── daily_report.py        # composes the daily AI summary
├── db/
│   ├── schema.sql                 # ai_agent.sqlite tables (see below)
│   └── store.py                   # thin DAL: chat_messages, user_prefs, daily_reports
├── telegram_bot/
│   ├── server.py                  # long-poll loop (mirror portfolio_analysis/bot/server.py)
│   ├── commands.py                # /start /help /summary /risk /greeks /setmodel /models /reset
│   ├── auth.py                    # chat-ID allowlist check
│   └── formatter.py               # truncation + "expand" follow-ups
├── dashboard/
│   └── status_page.py             # Streamlit status/info page (no chat); auto-refresh 30s
├── scheduler/
│   └── daily_summary_worker.py    # background thread; runs once/day; pushes to allowlist
├── deribit_extras.py              # wrappers for the missing endpoints listed above
├── config.py                      # env var loading (one place)
└── tests/
    ├── test_tools_data.py
    ├── test_tools_analysis.py
    ├── test_llm_router.py
    └── test_telegram_commands.py
```

---

## New SQLite DB: `data/ai_agent.sqlite`

```sql
CREATE TABLE chat_messages (
  id INTEGER PRIMARY KEY,
  channel TEXT NOT NULL,            -- 'telegram' | 'dashboard'
  user_key TEXT NOT NULL,           -- telegram_chat_id or streamlit_username
  thread_id TEXT NOT NULL,
  role TEXT NOT NULL,               -- 'user' | 'assistant' | 'tool'
  content TEXT NOT NULL,
  tool_name TEXT,
  ts TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX idx_chat_thread ON chat_messages(channel, user_key, thread_id, ts);

CREATE TABLE user_prefs (
  user_key TEXT NOT NULL,
  channel TEXT NOT NULL,
  provider TEXT NOT NULL,           -- 'anthropic' | 'openai' | 'xai'
  model TEXT NOT NULL,              -- 'claude-sonnet-4-6' | 'gpt-4o' | 'grok-4' | ...
  verbosity TEXT DEFAULT 'short',
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  PRIMARY KEY (channel, user_key)
);

CREATE TABLE portfolio_context (
  user_key TEXT PRIMARY KEY,
  prefs_json TEXT NOT NULL,         -- risk tolerance, hedge style, notes
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE daily_reports (
  id INTEGER PRIMARY KEY,
  run_date TEXT NOT NULL,           -- 'YYYY-MM-DD'
  model_used TEXT NOT NULL,
  content_md TEXT NOT NULL,
  pushed_chat_ids TEXT,             -- json array
  status TEXT NOT NULL,
  ts TEXT NOT NULL DEFAULT (datetime('now'))
);
```

---

## LLM Router (`agent/llm_router.py`)

Single function `get_chat_model(provider, model) -> BaseChatModel`:

| Provider | Backend | Models offered via `/setmodel` |
|---|---|---|
| `anthropic` | `langchain_anthropic.ChatAnthropic` | `claude-sonnet-4-6`, `claude-opus-4-7`, `claude-haiku-4-5-20251001` |
| `openai` | `langchain_openai.ChatOpenAI` | `gpt-4o`, `gpt-4.1` |
| `xai` (Grok) | `ChatOpenAI` with `base_url="https://api.x.ai/v1"`, `api_key=$XAI_API_KEY` | `grok-4` |

All three support OpenAI-style tool calling, so the same `AgentExecutor` works for every choice.

`/setmodel` opens a **wizard with inline buttons** showing the full model table (provider + model name shown on each button). User taps a button → choice persisted in `user_prefs`. **No model-ID typing required.** Default = `claude-sonnet-4-6`.

`/models` is a read-only view of the same table showing the user's current selection highlighted.

---

## Telegram Commands (V1)

| Command | Behavior |
|---|---|
| `/start`, `/help` | Welcome + command list |
| `/summary` | On-demand daily AI summary (re-uses last cached if <1h old) |
| `/risk` | Quick risk classification (SAFE/WARNING/DANGEROUS/CRITICAL) |
| `/greeks` | Net delta/gamma/vega/theta + classification |
| `/vol` | Current volatility regime |
| `/models` | Show model table with current selection highlighted (read-only view) |
| `/setmodel` | Open inline-button wizard; user taps the model they want; choice persisted to `user_prefs` |
| `/reset` | Clear current thread's conversation memory |
| *free text* | Routed to LangChain agent |

Auth: `AI_AGENT_TG_ALLOWLIST` env var = comma-separated chat IDs. Reject all others with a one-line message.

---

## Daily Summary Worker

- New thread inside a process (mirror `DailyReportWorker` pattern in `portfolio_analysis/scheduler.py`).
- Run-time controlled by `AI_AGENT_DAILY_RUN_UTC` (HH:MM, default `06:00`).
- On fire: gather risk + Greeks + vol regime + 24h change → call `tools.reasoning.daily_report` → store in `daily_reports` → POST to every allowlisted chat ID.
- Idempotent per `run_date` (skip if already produced + pushed).

---

## Dashboard Status Page (no chat in V1)

V1 keeps the dashboard simple - **read-only status/info page only.** All interaction happens through Telegram.

- New file `Streamlit/pages/AI_Agent_Status.py` gated by `require_login()`.
- Auto-refresh every 30s via `st.autorefresh`.

**Page sections:**
1. **Bot health** - Telegram bot process status (running/stopped), last successful poll timestamp, recent errors. Daily-summary worker + snapshot worker status. Read from worker heartbeat rows.
2. **Live portfolio state** - current risk classification, Greeks classification, vol regime, worst stress scenario. Reads latest row from `agent_metric_snapshots`.
3. **Latest daily AI summary** - most recent `daily_reports` row rendered as markdown.
4. **Recent agent activity log** - last N rows of `chat_messages` (user question + bot answer pairs) for audit/transparency.

No chat input, no streaming. Trader uses Telegram for Q&A.

---

## New Env Vars (add to `.env.example`)

```
# AI Agent
AI_AGENT_TG_BOT_TOKEN=
AI_AGENT_TG_ALLOWLIST=             # comma-separated chat IDs
AI_AGENT_DEFAULT_PROVIDER=anthropic
AI_AGENT_DEFAULT_MODEL=claude-sonnet-4-6
AI_AGENT_DAILY_RUN_UTC=06:00
AI_AGENT_DRY_RUN=1                 # flip to 0 for live push
XAI_API_KEY=                       # for Grok-4
```

(`ANTHROPIC_API_KEY`, `OPENAI_API_KEY`, `DERIBIT_*` already exist.)

---

## Implementation Order (suggested PRs)

1. **Skeleton + DB + config** - package layout, `ai_agent.sqlite` schema, `config.py`, `.env.example` updates.
2. **Deribit extras** - wrap missing endpoints in `deribit_extras.py` with thin tests.
3. **Data tools** - DB-first readers w/ live fallback; unit-tested with fixture DBs.
4. **Analysis tools** - risk / greeks / volatility / stress / hedge (deterministic, unit-tested).
5. **LLM router + agent core** - OpenAI Tools Agent; multi-provider; conversation memory.
6. **Reasoning tools + prompts** - summarize / explain / daily_report.
7. **Telegram bot** - server, commands, allowlist, formatter; mirror existing pattern.
8. **Daily summary worker** - scheduler thread + idempotency.
9. **Dashboard status page** - Streamlit read-only status/info page (no chat).
10. **End-to-end smoke test** - DRY_RUN=1 → real chat → DRY_RUN=0 push.

---

## Verification Plan

- **Unit:** `pytest portfolio_analysis_AI_Agent/tests/` - DB-first fallback, analysis classifications, llm_router resolution.
- **Manual Telegram (DRY_RUN=1 first):**
  - `/setmodel claude-sonnet-4-6` → confirm persisted in `user_prefs`.
  - "What's my current risk?" → routes through agent → returns classification + 1-line reason.
  - `/summary` → returns same content the daily worker would push.
  - Non-allowlisted chat ID → polite refusal.
- **Daily worker:** set `AI_AGENT_DAILY_RUN_UTC` 2 min ahead, `DRY_RUN=1`, watch logs + `daily_reports` row; flip `DRY_RUN=0` and confirm Telegram delivery.
- **Dashboard:** open `AI_Agent_Status` page after login → confirm bot health, live portfolio state, latest daily summary, and recent activity log all render and auto-refresh.
- **Pre-deploy reminder:** before live deploy, set `AI_AGENT_TG_BOT_TOKEN` and flip `AI_AGENT_DRY_RUN=1 → 0`.

---

## Threshold Overrides (User-Tunable Risk Bands)

All classification thresholds in the analysis tools (Risk, Greeks, Volatility, Stress) are **user-overridable** via the existing **portfolio_analysis Telegram bot**. The AI agent reads the same overrides - single source of truth.

### Storage
- **Reuse** `threshold_overrides` table in `data/portfolio_analysis.sqlite`.
- Add new metric keys for AI-agent thresholds (namespaced, e.g. `ai_agent.risk.margin_critical`, `ai_agent.greeks.short_gamma_dangerous`, `ai_agent.stress.btc_crash_combo_pct`).
- Schema reuse: `metric_key`, `value`, `set_at`, `expires_at`, `set_by_user`, `note`.

### Scope & Defaults
- **Global** scope (one shared profile for all allowlisted users - single-trader/team model).
- **Default TTL: 24 hours** if user doesn't specify. Always temporary; auto-expires.
- AI agent reads override → falls back to hardcoded default if expired/unset.

### Tunable Categories
1. **Risk bands** - margin %, drawdown %, liquidation distance bounds for SAFE/WARNING/DANGEROUS/CRITICAL.
2. **Greeks bands** - delta-USD/equity, short gamma %, short vega % cutoffs.
3. **Volatility bands** - DVOL percentile cutoffs (LOW/NORMAL/HIGH/EXTREME) + IV-HV rich/cheap thresholds.
4. **Stress thresholds + scenario shifts** - loss-% bands AND the scenario shift sizes themselves (e.g. change "BTC -10%" to "BTC -15%").

### Telegram Commands (added to `portfolio_analysis/bot/commands.py`)

| Command | Behavior |
|---|---|
| `/setthreshold` | **Wizard with inline buttons.** Step 1: pick category (Risk/Greeks/Vol/Stress). Step 2: pick metric. Step 3: type new value. Step 4: pick TTL (24h / 7d / custom). Confirm → write to DB. |
| `/thresholds` | Show full table: metric, current value, default value, TTL countdown. |
| `/resetthreshold <metric>` | Clear a single override → revert to default. |
| `/resetthresholds` | Clear ALL active overrides. |

### Expiry Notifications
- On expiry, bot sends one Telegram message: *"Override on `<metric>` expired → reverted to default `<value>`."*
- No pre-warning notifications in V1.

### AI-Agent Threshold Suggestions
- When the AI detects a condition that warrants a threshold change (e.g. vol regime EXTREME → suggest tightening risk bands), it **proposes** in chat - never auto-applies.
- Suggestion includes the recommended value + rationale. User must run `/setthreshold` wizard to apply.
- Read-only philosophy preserved.

### Implementation Notes
- Add `ai_agent_thresholds.py` helper in `portfolio_analysis_AI_Agent/agent/` that wraps `threshold_overrides` reads with namespaced keys + default fallback.
- Analysis tools call `get_threshold("ai_agent.risk.margin_critical")` instead of using hardcoded constants.
- Existing portfolio_analysis bot's wizard logic in `commands.py` extended with new metric registry (one place adds the new namespaced keys).

---

## Question Catalog & Tool Flow

The agent answers questions by calling structured tools. Tool selection is **LLM-driven** via LangChain's OpenAI Tools Agent pattern: each tool exposes a JSON schema + description; the model emits `tool_calls` in its response; `AgentExecutor` runs them and feeds results back; the model loops until it has enough to answer. We don't write routing logic - we write strong tool descriptions.

All analysis tools return **structured JSON**, never prose. The LLM only writes the final natural-language explanation. This keeps numbers deterministic and auditable.

### 10 Question Categories

#### 1. Portfolio status - "How am I doing?"
**Phrasings:** "status", "summary", "am I safe right now?"
**Tools called:**
- `datafetch.account.get_account_summary`
- `datafetch.positions.get_positions`
- `analysis.risk.classify`
- `analysis.greeks.classify`
- `analysis.volatility.compute`
- `analysis.sentiment.compute` (composite market sentiment score)
- `reasoning.summarize`

#### 2. Risk - "What's my risk?"
**Phrasings:** "risk level", "close to liquidation?", "margin?", "drawdown?"
**Tools called:**
- `datafetch.account.get_account_summary`
- `datafetch.positions.get_positions`
- `datafetch.account.get_equity_history` (from `realtime.sqlite`)
- `analysis.risk.compute` (reads active threshold overrides)

#### 3. Greeks - "What's my delta/gamma/vega/theta?"
**Phrasings:** "delta", "short gamma?", "show Greeks", "theta?"
**Tools called:**
- `datafetch.positions.get_positions`
- `datafetch.market.get_index_price`
- `analysis.greeks.compute`

#### 4. Market state - "What's BTC/the market doing?"
**Phrasings:** "BTC?", "IV expensive?", "vol regime?", "skew?", "is the market bullish?", "what's funding doing?", "where's the OI?", "biggest trades today?"
**Tools called (LLM picks subset based on the specific question):**
- `datafetch.market.get_ticker`
- `datafetch.market.get_historical_volatility`
- `datafetch.market.get_dvol`
- `datafetch.market.get_book_summary` (for skew + IV surface)
- `datafetch.market.get_funding_rate` (current + 30d)
- `datafetch.market.get_open_interest_breakdown` (by expiry / strike / call-put / 24h delta)
- `datafetch.market.get_trade_activity` (volume by expiry, by strike range, aggressor split, top-10 prints)
- `datafetch.market.get_put_call_ratio`
- `datafetch.market.get_max_pain`
- `datafetch.market.get_long_short_ratio`
- `datafetch.market.get_liquidation_flow`
- `analysis.volatility.compute` (vol regime)
- `analysis.sentiment.compute` (composite bull/bear score with all signals + weights)

#### 5. Stress / "what if" - scenarios
**Phrasings:** "BTC -10%?", "vol spike?", "worst case?", "what if BTC 60k IV doubles?"
**Tools called:**
- Standard 8 scenarios: cached layer-A analytic stress (Greeks Taylor expansion)
- **Custom free-form scenarios**: LLM extracts shifts from natural language → `analysis.stress.run_custom(btc_pct, iv_shift)` → uses `private/pme/simulate` for accuracy
- Optionally enriched with `analysis.sentiment.compute` so the response can frame "this scenario is more/less likely given current sentiment is X"

#### 6. Why / explanation queries
**Phrasings:** "why is risk high?", "why short gamma?", "what changed in last hour?"
**Tools called:**
- Current classifications (tools 2/3/4)
- `data.snapshots.get_metric_snapshot(time_offset)` (5-min snapshot history)
- `reasoning.explain` (LLM compares before/after, names drivers)

#### 7. Advisory - "What should I do?" (market-state-aware)
**Phrasings:** "how do I hedge?", "should I buy puts?", "safest move?", "what's the smart play right now?"
**Tools called (always combines portfolio + market sentiment):**
- ALL portfolio analysis tools (`analysis.risk`, `analysis.greeks`)
- ALL market analysis tools (`analysis.volatility.compute`, `analysis.sentiment.compute`)
- Individual sentiment signals as needed: `get_funding_rate`, `get_open_interest_breakdown`, `get_trade_activity`, `get_put_call_ratio`, `get_max_pain`, `get_long_short_ratio`, `get_liquidation_flow`
- `analysis.stress.run_standard`
- `analysis.hedge.suggest` → returns **top 5 ranked** hedge ideas (rules now condition on composite sentiment + vol regime + portfolio classifications)
- For each suggestion: `private/pme/simulate` re-prices the hedged portfolio → projected metric deltas (risk class change, stress loss change, margin change)
- `reasoning.explain` frames in plain English, **always flagging opportunities** alongside risks

**Default time horizon:** intraday + next 24h.
**Always flag opportunities** alongside risks (e.g. "IV rich, sellers favored - but your short vega makes this risky").

#### 8. Daily summary
**Trigger:** scheduled daily worker OR `/summary` command (re-uses cached if <1h old).
**Tools called:**
- All four portfolio analysis tools (`risk`, `greeks`, `volatility`, `stress`)
- `analysis.sentiment.compute` (composite + every individual signal - funding, OI breakdown, trade activity, P/C ratio, max pain, long/short, liquidations)
- `data.snapshots.get_metric_snapshot(24h_ago)` for day-over-day diffs (incl. sentiment-score delta)
- `reasoning.daily_report` (multi-section markdown - adds a "Market Sentiment" section listing each signal + composite score + day-over-day shift)

#### 9. History / lookup queries
**Phrasings:** "trades today?", "fees this week?", "settlements last week"
**Tools called (both raw + aggregated available):**
- `datafetch.history.get_transactions_raw(filters)` → raw rows for "show me each trade"
- `datafetch.history.get_transaction_summary(period)` → totals/counts/group-by
- LLM picks the right tool from question wording

#### 10. Threshold management (meta)
**Phrasings:** "what are my thresholds?", "make me more conservative today"
**Tools called:**
- `data.thresholds.get_active` (reads `threshold_overrides` table)
- For natural-language threshold-change requests, agent **suggests** in chat; user must run `/setthreshold` wizard to apply (no auto-apply).

---

### Tool Selection - How the LLM Decides

The LLM receives in its system prompt:
- Each tool's name, JSON schema, and a description like:
  ```
  analysis.risk.compute: Computes margin %, drawdown %, leverage, liquidation
  distance, and SAFE/WARNING/DANGEROUS/CRITICAL classification.
  Call when user asks about risk level, margin usage, drawdown, or liquidation.
  Reads active threshold overrides automatically.
  ```
- Conversation memory (recent N messages from `chat_messages`)
- Portfolio context (user's stored risk preferences from `portfolio_context`)
- The user's current message

The model emits `tool_calls`; `AgentExecutor` runs them; results feed back into context; model loops until it produces a final answer. The model can call **multiple tools in parallel** when independent, and chain them when one depends on another.

Failure modes we mitigate:
- **Wrong tool picked** → tighten descriptions; add examples in prompt.
- **Tool loop / hallucination** → `AgentExecutor` `max_iterations` cap (default 10).
- **Stale data** → every data tool stamps a `fetched_at` timestamp; reasoning tools include freshness in output.

---

### Snapshot Worker

A new worker thread inside the agent process writes computed classifications to `agent_metric_snapshots` (in `ai_agent.sqlite`) **every 5 minutes**:

```sql
CREATE TABLE agent_metric_snapshots (
  id INTEGER PRIMARY KEY,
  ts TEXT NOT NULL DEFAULT (datetime('now')),
  risk_classification TEXT,
  greeks_json TEXT,
  vol_regime TEXT,
  stress_worst_pct REAL,
  metrics_json TEXT
);
CREATE INDEX idx_metric_snapshots_ts ON agent_metric_snapshots(ts);
```

This powers all "what changed in the last X" queries without recomputing history.

---

## Market Sentiment Tools

Beyond `volatility.compute`, V1 includes a **market sentiment layer** combining funding, OI, trade flow, and positioning into a composite directional read. All tools are DB-first; cached in `market_data.sqlite`. Every individual signal is exposed as its own tool AND fed into a composite score - the LLM can call either.

### `datafetch.market.get_funding_rate`
- **Source:** `public/get_funding_rate_history` for BTC-PERPETUAL.
- **Window:** current 8h funding + 30-day history.
- **Returns:** current rate, 24h/7d/30d means, percentile (current vs 30d), trend (rising/falling/flat), bias label (bullish if persistently positive, bearish if negative).

### `datafetch.market.get_open_interest_breakdown`
- **Source:** `get_book_summary` rows + 24h-prior cached snapshot for delta.
- **Slices returned:**
  - **By expiry** - total OI per expiry date (timeline distribution)
  - **By strike** - OI heatmap; identify "OI walls" (top concentrations)
  - **By call/put per expiry** - directional bias per maturity
  - **24h delta per expiry/strike** - what's being added/closed
- **Returns:** structured JSON with all four slices + flags (e.g., `oi_wall_at: 70000`, `bias_30d_expiry: call_heavy`).

### `datafetch.market.get_trade_activity`
- **Source:** `public/get_last_trades_by_instrument` across all active BTC option expiries; cached last 24h in `market_data.sqlite`.
- **Aggregations returned:**
  - **Volume by expiry** (last 24h)
  - **Volume by strike range** - OTM (>5% away from spot), ATM (±5%), ITM
  - **Buy vs sell aggressor split** (taker side breakdown) per expiry
  - **Top 10 prints** in last 24h: instrument, side, size, price, IV, timestamp
- **Refresh:** on demand if cache >5 min stale.

### `datafetch.market.get_put_call_ratio`
- **Source:** computed from `get_book_summary` + `get_trade_activity`.
- **Returns:** PCR by **volume** (24h) and PCR by **open interest**, each with 30d percentile context.

### `datafetch.market.get_max_pain`
- **Source:** computed from `get_book_summary`.
- **Returns:** max-pain strike for the **next 3 expiries** (where most OI value expires worthless), distance from spot, and a `pinning_risk_flag` if spot is within 2% of max pain in next 48h.

### `datafetch.market.get_long_short_ratio`
- **Source:** Deribit positioning stats (via `book_summary` aggregates if direct endpoint unavailable; fallback to derived metric).
- **Returns:** current ratio, 24h change, bias label.

### `datafetch.market.get_liquidation_flow`
- **Source:** `public/get_last_settlements_by_currency` + recent forced-close prints from trade activity.
- **Window:** last 24h.
- **Returns:** total liquidation $-volume, long-side vs short-side split, asymmetry flag (`long_capitulation` if long liq >>>, `short_squeeze` if short liq >>>).

### `analysis.sentiment.compute` (composite score)

Combines all signals above into one structured output. Every individual signal is also returned as-is so the LLM and dashboard can show them side-by-side.

**Returned JSON shape:**
```python
{
  "composite_score": -0.35,              # range [-1, +1]; negative = bearish
  "composite_label": "BEARISH_LEANING",   # STRONG_BULL / BULLISH / NEUTRAL / BEARISH_LEANING / STRONG_BEAR
  "signals": {
    "funding":      {"value": -0.0008, "score": -0.4, "label": "bearish",       "weight": 0.15},
    "oi_breakdown": {"value": {...},   "score": -0.2, "label": "put_heavy_30d", "weight": 0.15},
    "trade_flow":   {"value": {...},   "score": -0.5, "label": "sellers_aggressive", "weight": 0.20},
    "put_call":     {"value": 1.42,    "score": -0.6, "label": "elevated_pcr",  "weight": 0.15},
    "max_pain":     {"value": 65500,   "score": -0.1, "label": "max_pain_below_spot", "weight": 0.05},
    "long_short":   {"value": 0.78,    "score": -0.3, "label": "shorts_heavier", "weight": 0.10},
    "liquidations": {"value": {...},   "score": -0.4, "label": "long_capitulation", "weight": 0.10},
    "vol_regime":   {"value": "HIGH",  "score": -0.2, "label": "fear_pricing",  "weight": 0.10}
  },
  "weights_version": "v1_default",       # weights are user-overridable via threshold system
  "fetched_at": "2026-05-08T14:22:31Z"
}
```

**Scoring rules (defaults, all overridable via threshold system):**
- Each signal mapped to [-1, +1] via deterministic rules.
- Weighted sum → composite score.
- Composite labels: `[-1.0, -0.6]` STRONG_BEAR, `[-0.6, -0.2]` BEARISH_LEANING, `[-0.2, +0.2]` NEUTRAL, `[+0.2, +0.6]` BULLISH, `[+0.6, +1.0]` STRONG_BULL.
- Weights tunable via `/setthreshold` wizard under category "sentiment_weights".

### Caching

All sentiment tools cache to `market_data.sqlite`. New tables added:
```sql
CREATE TABLE oi_snapshots          -- per (instrument, fetched_at)
CREATE TABLE trade_activity_24h    -- rolling window
CREATE TABLE funding_history       -- daily aggregates
CREATE TABLE liquidation_events    -- from settlements
```

### Question Catalog Updates

The advisory question category (#7 in the catalog above) now also calls `analysis.sentiment.compute` to combine portfolio + market sentiment + vol regime. The "What's the market doing?" category (#4) gains all individual sentiment tools as available calls.

---

## Options Market Snapshot for LLM

The agent must always be able to ground its reasoning in a **recent BTC options market snapshot**. This snapshot is built once per refresh cycle, cached in `market_data.sqlite`, and injected into the LLM context (via tool call, not prompt prefix) whenever a question touches market state, sentiment, stress, or advisory.

### Expiry Selection Rule

- **End-of-month expiries only.** Skip dailies and weeklies - they add noise and are mostly irrelevant for portfolio-level views.
- **Next 5 EOM expiries currently listed on Deribit**, in chronological order of their actual expiration timestamps - **not calendar-sequential month numbers.**
- Deribit's listed months are not always contiguous. Example: if today is May and Deribit currently lists EOM expiries for months `[5, 6, 8, 10, 12]`, the snapshot fetches those five - even though July, September, November are missing.
- Configurable via `AI_AGENT_SNAPSHOT_EOM_COUNT` (default `5`).

### Selection Algorithm

1. Call `public/get_instruments` for `currency=BTC, kind=option, expired=false`.
2. Filter to instruments whose expiration date == last Friday of their expiry month (Deribit's EOM convention) - drop weeklies/dailies.
3. Deduplicate to one expiry-date per month, sort ascending by `expiration_timestamp`.
4. Take the first `N` (default 5).

### Snapshot Contents (per selected expiry)

For each of the 5 selected expiries the snapshot stores:
- Full strike chain (calls + puts): mark price, IV, delta, gamma, vega, theta, OI, 24h volume.
- Per-expiry aggregates: total OI, total 24h volume, ATM IV, 25-delta skew, P/C ratio.
- Top-of-book bid/ask for each strike.

Plus expiry-independent fields: BTC index price, DVOL, perpetual funding rate, current vol regime label.

### Refresh & Caching

- Stored in new table `options_market_snapshot` keyed by `(snapshot_ts, instrument_name)`.
- Default refresh: **every 5 minutes** by the snapshot worker (Phase 5).
- LLM tool `datafetch.market.get_options_snapshot()` returns the latest snapshot row set as structured JSON; the LLM never sees raw Deribit responses.

### Integration Points

- **Phase 2** - `deribit_extras.py` adds `list_eom_option_instruments(n=5)` helper using the algorithm above.
- **Phase 4** - `tools/datafetch/market.py` exposes `get_options_snapshot()` tool; analysis tools (`volatility`, `sentiment`, `stress`) consume the snapshot rather than refetching.
- **Phase 5** - snapshot worker writes a fresh snapshot every 5 min.
- **Phase 7** - validation notebook must include a sample snapshot row set proving correct EOM filtering and the "non-contiguous months" case.

---

## Out of Scope for V1 (explicit)

- Order execution / hedge placement
- Vector RAG / semantic memory
- Dashboard chat interface (Telegram only in V1)
- Inline chart rendering in dashboard
- Voice notes
- Multi-agent collaboration
- LangGraph migration (left as future path)
- Proactive event-driven AI alerts beyond the single daily push

---

## Project Phases

Execution roadmap for V1. Ordering is deliberate: **infrastructure and data first, validation before AI, LLM layer last.** No LangChain, agent, or LLM code is written until Phase 7 passes.

### Phase 1 - Infrastructure & Skeleton
- Create `portfolio_analysis_AI_Agent/` package layout (folders only, empty modules).
- Add `data/ai_agent.sqlite` schema (`chat_messages`, `user_prefs`, `portfolio_context`, `daily_reports`, `agent_metric_snapshots`).
- `config.py` env loader; update `.env.example` with new keys.
- Wire logging + DB path resolution via existing `shared/db_paths.py`.

### Phase 2 - Data Collection (Deribit Extras)
- Implement `deribit_extras.py` wrappers for the missing endpoints listed in this plan (transaction log, user trades, subaccounts, orders, mark-price history, settlements, funding history, indices, etc.).
- Extend caching into `market_data.sqlite` (new tables: `oi_snapshots`, `trade_activity_24h`, `funding_history`, `liquidation_events`).
- Background fetchers populate these tables on a schedule.

### Phase 3 - Database Structure & DAL
- Finalize all SQLite schemas (AI-agent DB + market-data extensions).
- Thin DAL in `db/store.py` (CRUD only, no business logic).
- Migration / bootstrap script that creates every table idempotently.

### Phase 4 - Data & Analysis Tools (no LLM yet)
- `tools/datafetch/*` - DB-first readers with live Deribit fallback (account, positions, market, history).
- `tools/analysis/*` - deterministic computations: risk classify, Greeks classify, volatility regime, stress (analytic + `pme/simulate`), hedge suggestions, sentiment composite.
- All tools return **structured JSON** with `fetched_at` stamps. Unit-tested against fixture DBs.

### Phase 5 - Backend Services
- Snapshot worker (5-min cadence) writing to `agent_metric_snapshots`.
- Threshold-overrides integration (read namespaced `ai_agent.*` keys from existing `threshold_overrides` table).
- Daily-summary worker scaffold (no LLM call yet - emits structured JSON payload).

### Phase 6 - Dashboard / UI (read-only status page)
- `Streamlit/pages/AI_Agent_Status.py`: bot health, live portfolio state, latest metrics, recent activity log.
- Auto-refresh 30s. Gated by `require_login()`.
- No chat input in V1 - purely a visibility surface for the data pipeline built in Phases 2–5.

### Phase 7 - Data Validation Notebook (gate before AI work)
Create `portfolio_analysis_AI_Agent/notebooks/data_validation.ipynb` containing:
- Sample rows from every table (`ai_agent.sqlite` + new `market_data.sqlite` tables).
- Sample outputs from each data tool (`tools/datafetch/*`) and each analysis tool (`tools/analysis/*`).
- Example processed market data (sentiment composite, vol regime, OI breakdown).
- Example portfolio/risk data (risk classify, Greeks, stress scenarios).

**Purpose:** verify data quality, confirm structure is suitable for LLM consumption, and catch missing fields, bad formatting, or stale caches **before** any AI layer is built. This phase is a hard gate - Phase 8 does not start until the notebook is reviewed and signed off.

### Phase 8 - LLM Router & Agent Core
- `agent/llm_router.py` - multi-provider resolver (Anthropic / OpenAI / xAI).
- `agent/core.py` - LangChain OpenAI Tools Agent wiring.
- `agent/memory.py` - SQLite-backed conversation + portfolio context.
- Tools from Phase 4 registered with strong descriptions; no new business logic.

### Phase 9 - Reasoning Tools & Prompts
- `tools/reasoning/{summarize,explain,daily_report}.py`.
- System prompt + per-tool descriptions in `agent/prompts.py`.
- Daily-summary worker upgraded from Phase 5 to invoke `reasoning.daily_report`.

### Phase 10 - Telegram Bot
- `telegram_bot/{server,commands,auth,formatter}.py`, mirroring existing `portfolio_analysis/bot/` pattern.
- Allowlist auth, `/setmodel` wizard, command handlers, free-text → agent routing.

### Phase 11 - End-to-End Validation & Live Cutover
- DRY_RUN=1 smoke tests via Telegram + dashboard.
- Daily-worker dry run; verify `daily_reports` rows + scheduled push.
- Flip `AI_AGENT_DRY_RUN=0`, set `AI_AGENT_TG_BOT_TOKEN`, deploy.
