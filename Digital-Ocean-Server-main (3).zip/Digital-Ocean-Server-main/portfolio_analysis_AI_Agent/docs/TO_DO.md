# Portfolio Analysis AI Agent - TODO

---

# Phase A - Research & Planning

## Portfolio Analysis
- ### [✅] Define what portfolio analysis means
 #### Definition - Portfolio Analysis

Portfolio analysis is the process of analyzing a trading portfolio to understand its current state, risk exposure, performance, and sensitivity to market conditions.

In crypto options trading, portfolio analysis includes:
- Greeks analysis
- Margin analysis
- Drawdown monitoring
- Volatility analysis
- PnL analysis
- Market exposure analysis
- Stress testing
- Hedge analysis

The purpose of portfolio analysis is to:
- protect capital
- reduce risk
- detect dangerous conditions early
- improve trading decisions
- optimize portfolio positioning
- identify hedge opportunities

The AI agent should convert raw market and portfolio data into actionable insights, alerts, explanations, and recommendations.

---

- ### [✅] Define trader needs and outputs
#### Trader Needs

The trader needs to understand:
- current portfolio condition
- current market condition
- current risk exposure
- current margin state
- current Greeks exposure
- recent market changes
- portfolio performance
- liquidation risk
- hedge requirements
- abnormal market behavior

The trader also needs:
- realtime monitoring
- smart alerts
- historical comparisons
- AI explanations
- fast decision support
- scenario analysis

#### Expected Outputs

The system should generate outputs such as:
- bullish / bearish market state
- portfolio risk level
- margin warnings
- volatility regime
- Greeks summary
- drawdown analysis
- stress test results
- hedge suggestions
- portfolio summaries
- anomaly alerts
- AI-generated explanations

Outputs should be:
- clear
- brief
- actionable
- severity-based
- easy to understand

--- 

- ### [✅] Define risk analysis features
#### Risk Analysis Features

The system should analyze:

- portfolio drawdown
- maintenance margin %
- liquidation risk
- unrealized PnL
- realized PnL
- portfolio leverage
- directional exposure
- portfolio concentration
- short gamma risk
- short volatility risk
- portfolio sensitivity to BTC movement
- portfolio sensitivity to volatility changes

#### Risk Monitoring

The system should monitor:
- current risk state
- risk trend over time
- abnormal risk increases
- rapid portfolio changes
- dangerous exposure buildup

#### Risk Classification

The system should classify risk levels such as:
- SAFE
- WARNING
- DANGEROUS
- CRITICAL

#### Risk Scenarios

The system should estimate portfolio impact for scenarios like:
- BTC -5%
- BTC -10%
- BTC +5%
- volatility expansion
- volatility crush
- large overnight moves

#### Expected Outputs

Examples:
- "Portfolio risk increased sharply in last 2 hours."
- "Maintenance margin approaching dangerous level."
- "Portfolio highly exposed to downside volatility expansion."
- "Short gamma exposure is dangerous near current BTC price."

---

- ### [✅] Define Greeks analysis
#### Greeks Analysis

The system should monitor:

- Delta
- Gamma
- Vega
- Theta
- optional: Rho

#### Delta Analysis

Measures directional exposure to BTC movement.

The system should:
- monitor net delta
- detect delta drift
- classify bullish/bearish exposure
- detect dangerous directional imbalance

#### Gamma Analysis

Measures how fast delta changes.

The system should:
- detect short gamma danger
- detect expiry-related risk
- detect rapid exposure changes
- monitor near-strike exposure

#### Vega Analysis

Measures sensitivity to implied volatility changes.

The system should:
- monitor long/short volatility exposure
- detect dangerous short vega
- detect volatility expansion risk
- detect volatility crush risk

#### Theta Analysis

Measures time decay impact.

The system should:
- estimate daily decay
- monitor premium decay
- compare theta gains vs risk

#### Greeks Monitoring

The system should:
- monitor Greeks in realtime
- track Greeks changes over time
- compare Greeks historically
- classify Greeks risk levels
- generate Greeks alerts

#### Expected Outputs

Examples:
- "Portfolio currently net bullish with high positive delta."
- "Short gamma exposure becoming dangerous near expiry."
- "Portfolio highly exposed to volatility expansion."
- "Theta income is strong but risk increased significantly."

---

- ### [✅] Define volatility analysis
#### Volatility Analysis

The system should analyze:

- historical volatility (HV)
- implied volatility (IV)
- realized volatility
- IV vs HV spread
- volatility trends
- volatility spikes
- volatility crush events

#### Historical Volatility

The system should:
- calculate HV for multiple periods
- compare current HV vs historical values
- detect abnormal movement regimes

#### Implied Volatility

The system should:
- monitor ATM IV
- monitor term structure
- monitor IV skew
- detect expensive/cheap options environments

#### IV vs HV Analysis

The system should:
- compare implied volatility against realized volatility
- detect overpricing/underpricing conditions
- detect volatility premium expansion

#### Volatility Regimes

The system should classify regimes such as:
- LOW VOLATILITY
- NORMAL VOLATILITY
- HIGH VOLATILITY
- EXTREME VOLATILITY

#### Volatility Monitoring

The system should:
- track volatility changes over time
- detect sudden volatility spikes
- detect volatility compression
- monitor volatility momentum

#### Expected Outputs

Examples:
- "BTC volatility entered high volatility regime."
- "Implied volatility significantly overpriced relative to HV."
- "Volatility expansion risk increased sharply."
- "Current market conditions favor option sellers."

---

- ### [✅] Define stress testing
#### Stress Testing

The system should simulate abnormal market scenarios and estimate their impact on:

- portfolio equity
- unrealized PnL
- maintenance margin %
- liquidation risk
- Greeks exposure
- drawdown

#### Stress Scenarios

The system should simulate scenarios such as:

- BTC +5%
- BTC -5%
- BTC +10%
- BTC -10%
- volatility expansion
- volatility crush
- rapid intraday movement
- overnight gaps
- expiry-related movement

#### Stress Engine

The system should:
- estimate projected losses
- estimate projected margin usage
- estimate projected Greeks changes
- identify portfolio breaking points
- identify liquidation danger zones

#### Stress Classification

The system should classify outcomes such as:
- SAFE
- WARNING
- DANGEROUS
- CRITICAL

#### Stress Monitoring

The system should:
- run stress tests continuously
- compare current vs previous stress states
- detect rapid deterioration
- trigger alerts for dangerous scenarios

#### Expected Outputs

Examples:
- "Portfolio could lose 12% if BTC drops 10%."
- "Maintenance margin may exceed dangerous level under volatility expansion."
- "Current short gamma exposure becomes critical during fast BTC movement."
- "Portfolio remains stable under all tested scenarios."

---

- ### [✅] Define hedge suggestions
#### Hedge Suggestions

The system should generate hedge suggestions based on:

- portfolio Greeks
- volatility regime
- market direction
- drawdown state
- margin usage
- stress test results

#### Hedge Goals

The system should help:
- reduce liquidation risk
- reduce directional exposure
- reduce short gamma risk
- reduce short vega risk
- stabilize portfolio behavior
- protect portfolio during high volatility

#### Hedge Types

The system may suggest:
- perpetual hedges
- long call protection
- long put protection
- spread structures
- position reduction
- exposure balancing
- volatility hedges

#### Hedge Logic

The system should:
- explain why the hedge is needed
- estimate hedge impact
- estimate risk reduction
- estimate margin impact
- estimate cost of protection

#### Hedge Monitoring

The system should:
- monitor hedge effectiveness
- detect failed hedges
- suggest hedge adjustments
- detect over-hedging

#### Expected Outputs

Examples:
- "Portfolio delta exposure is too bullish; consider partial BTC hedge."
- "Short vega exposure is dangerous during current volatility regime."
- "Adding long puts may reduce downside stress risk."
- "Current hedge protection is weak under high volatility scenarios."

---

- ### [ ] Define alert system
#### AI Analysis Layer

The AI agent should not replace the existing realtime alert system.

Existing system:
- realtime alerts
- margin alerts
- liquidation alerts
- fast risk monitoring

AI layer:
- smarter analysis
- portfolio summaries
- market reasoning
- trend explanations
- hedge insights
- strategic observations

The AI analysis can run:
- every 6h
- every 12h
- daily
- or after major market events

Examples:
- "Portfolio risk increased due to rising short gamma exposure."
- "Market shifted into high volatility regime."
- "Current positioning is too directional for current market conditions."

---

## Deribit Research
- ### [✅] Identify portfolio endpoints
- private/get_account_summary
  - Main portfolio overview endpoint
  - Params:
    - currency
    - extended=true
  - Returns:
    - equity
    - available funds
    - margins
    - liquidation ratio
    - Greeks
    - PnL
  - Used for:
    - portfolio monitoring
    - risk analysis
    - margin analysis
    - Greeks analysis
    - AI summaries
  - Polling:
    - every 5-15 sec
  - Cache:
    - save snapshots to DB

- private/get_positions
  - Main positions endpoint
  - Params:
    - currency
    - kind
      - future
      - option
  - Returns:
    - instrument name
    - size
    - direction
    - average price
    - mark price
    - liquidation price
    - margins
    - delta
    - gamma
    - theta
    - vega
    - floating PnL
    - realized PnL
    - total PnL
  - Used for:
    - positions monitoring
    - Greeks analysis
    - options risk analysis
    - leverage analysis
    - liquidation analysis
    - hedge analysis
    - AI portfolio analysis
  - Polling:
    - every 5-15 sec
  - Cache:
    - save all snapshots to DB

- private/get_transaction_log
  - Main account activity history endpoint
  - Params:
    - currency
    - start_timestamp
    - end_timestamp
    - count
    - continuation
  - Returns:
    - trades
    - settlements
    - deposits
    - withdrawals
    - transfers
    - fees
    - balance changes
    - cashflow
    - equity history
  - Used for:
    - historical portfolio analysis
    - account activity tracking
    - PnL analysis
    - cashflow analysis
    - trader behavior analysis
    - AI historical summaries
  - Polling:
    - on demand
    - every few minutes for sync
  - Cache:
    - save permanently to DB

- private/get_user_trades_by_currency
  - Main user trades history endpoint
  - Params:
    - currency
    - kind
    - start_timestamp
    - end_timestamp
    - historical=true
  - Returns:
    - instrument name
    - buy/sell direction
    - amount
    - price
    - IV
    - fees
    - liquidity type
    - realized profit/loss
    - order type
    - timestamps
  - Used for:
    - trade history analysis
    - trader behavior analysis
    - realized PnL analysis
    - volatility analysis
    - AI trade summaries
    - strategy analysis
  - Polling:
    - on demand
    - periodic sync
  - Cache:
    - save permanently to DB

- private/get_subaccounts
  - Main subaccounts overview endpoint
  - Params:
    - with_portfolio=true
  - Returns:
    - subaccounts list
    - balances
    - equity
    - margins
    - available funds
    - margin model
    - account type
  - Used for:
    - multi-account monitoring
    - portfolio aggregation
    - account comparison
    - global risk analysis
    - AI portfolio summaries
  - Polling:
    - every few minutes
  - Cache:
    - save snapshots to DB

- private/get_subaccounts_details
  - Detailed subaccounts positions endpoint
  - Params:
    - currency
  - Returns:
    - subaccount positions
    - instrument names
    - size
    - direction
    - leverage
    - margins
    - liquidation price
    - delta
    - PnL
  - Used for:
    - multi-account positions monitoring
    - aggregated portfolio analysis
    - subaccount risk analysis
    - global Greeks analysis
    - AI portfolio summaries
  - Polling:
    - every 15-60 sec
  - Cache:
    - save snapshots to DB

- private/pme/simulate
  - Main portfolio margin simulation endpoint
  - Params:
    - currency
  - Returns:
    - stress scenarios
    - risk vectors
    - projected margins
    - worst-case scenarios
    - liquidation-related risk
    - portfolio exposure simulations
  - Used for:
    - stress testing
    - liquidation analysis
    - portfolio risk simulation
    - hedge analysis
    - AI risk reasoning
    - advanced portfolio analysis
  - Polling:
    - on demand
    - every few minutes if needed
  - Cache:
    - save simulation results to DB

- private/get_margins
  - Margin estimation endpoint
  - Params:
    - instrument_name
    - amount
    - price
  - Returns:
    - buy margin
    - sell margin
    - min price
    - max price
  - Used for:
    - pre-trade risk analysis
    - hedge simulations
    - position sizing
    - margin estimation
    - AI trade reasoning
  - Polling:
    - on demand
  - Cache:
    - no caching needed

- private/get_account_summaries
  - Multi-currency portfolio overview endpoint
  - Params:
    - extended=true
  - Returns:
    - summaries for all currencies
    - balances
    - equity
    - margins
    - Greeks
    - liquidation ratios
    - PnL
  - Used for:
    - global portfolio monitoring
    - multi-currency risk analysis
    - portfolio summaries
    - AI portfolio analysis
  - Polling:
    - every 5-15 sec
  - Cache:
    - save snapshots to DB

- private/get_open_orders_by_currency
  - Open orders monitoring endpoint
  - Params:
    - currency
    - kind
    - type
  - Returns:
    - instrument name
    - order price
    - amount
    - direction
    - filled amount
    - order state
    - order type
    - timestamps
  - Used for:
    - open orders monitoring
    - pending exposure analysis
    - risk analysis
    - hedge monitoring
    - AI portfolio analysis
  - Polling:
    - every 5-15 sec
  - Cache:
    - save snapshots to DB

- private/get_order_history_by_currency
  - Orders history endpoint
  - Params:
    - currency
    - kind
    - historical=true
    - include_old=true
  - Returns:
    - filled orders
    - canceled orders
    - order states
    - order prices
    - amounts
    - timestamps
    - order types
  - Used for:
    - order history analysis
    - execution analysis
    - trading behavior analysis
    - strategy analysis
    - AI historical summaries
  - Polling:
    - on demand
    - periodic sync
  - Cache:
    - save permanently to DB

- private/get_user_locks
  - Account lock status endpoint
  - Params:
    - none
  - Returns:
    - currencies
    - locked/unlocked status
  - Used for:
    - account monitoring
    - system health checks
    - operational alerts
  - Polling:
    - low frequency
  - Cache:
    - optional

- private/get_order_state
  - Single order status endpoint
  - Params:
    - order_id
  - Returns:
    - order status
    - filled amount
    - order price
    - order state
    - timestamps
  - Used for:
    - order tracking
    - hedge execution monitoring
    - debugging
    - Telegram order checks
  - Polling:
    - on demand
  - Cache:
    - no caching needed


- ### [ ] Identify market endpoints
- public/ticker
  - Main realtime market data endpoint
  - Params:
    - instrument_name
  - Returns:
    - mark price
    - bid/ask prices
    - open interest
    - volume
    - funding rate
    - implied volatility
    - option Greeks
    - index price
    - underlying price
  - Used for:
    - realtime market monitoring
    - volatility analysis
    - Greeks analysis
    - funding analysis
    - sentiment analysis
    - AI market analysis
  - Polling:
    - every 1-5 sec
  - Cache:
    - save realtime snapshots to DB
- public/get_order_book
  - Main market depth endpoint
  - Params:
    - instrument_name
    - depth
  - Returns:
    - bids
    - asks
    - market depth
    - liquidity
    - spread
    - mark price
    - IV
    - Greeks
    - open interest
  - Used for:
    - liquidity analysis
    - spread analysis
    - market pressure analysis
    - options flow analysis
    - AI market analysis
  - Polling:
    - every 1-5 sec
  - Cache:
    - save realtime snapshots to DB

- public/get_book_summary_by_currency
  - Bulk market summary endpoint
  - Params:
    - currency
    - kind
  - Returns:
    - all instruments summary
    - prices
    - IV
    - volume
    - open interest
    - bid/ask
    - mark prices
  - Used for:
    - full market scanning
    - volatility surface analysis
    - options flow analysis
    - unusual activity detection
    - AI market regime analysis
    - strike comparison
  - Polling:
    - every 10-30 sec
  - Cache:
    - save snapshots to DB

- public/get_book_summary_by_instrument
  - Single instrument market summary endpoint
  - Params:
    - instrument_name
  - Returns:
    - mark price
    - bid/ask
    - IV
    - open interest
    - volume
    - price changes
    - underlying price
  - Used for:
    - single option analysis
    - strike analysis
    - volatility analysis
    - AI trade reasoning
    - hedge analysis
  - Polling:
    - every 5-15 sec
  - Cache:
    - save snapshots to DB

- public/get_instruments
  - Instruments discovery endpoint
  - Params:
    - currency
    - kind
    - expired
  - Returns:
    - all instruments
    - strikes
    - expirations
    - option type
    - tick size
    - contract size
    - active status
  - Used for:
    - option chain building
    - strike discovery
    - expiration analysis
    - volatility surface building
    - AI market scanning
    - instrument filtering
  - Polling:
    - every 5-30 min
  - Cache:
    - save instruments to DB

- public/get_tradingview_chart_data
  - Historical OHLCV market data endpoint
  - Params:
    - instrument_name
    - start_timestamp
    - end_timestamp
    - resolution
  - Returns:
    - OHLC candles
    - volume
    - timestamps
    - cost
  - Used for:
    - historical analysis
    - volatility analysis
    - trend analysis
    - AI pattern detection
    - backtesting
    - signal generation
  - Polling:
    - on demand
  - Cache:
    - save permanently to DB

- public/get_historical_volatility
  - Historical volatility endpoint
  - Params:
    - currency
  - Returns:
    - volatility values
    - timestamps
  - Used for:
    - volatility regime detection
    - market risk analysis
    - stress analysis
    - IV vs HV analysis
    - AI market regime analysis
    - hedge logic
  - Polling:
    - every 5-30 min
  - Cache:
    - save permanently to DB

- public/get_last_trades_by_instrument
  - Single instrument trades flow endpoint
  - Params:
    - instrument_name
    - start_timestamp
    - end_timestamp
    - count
    - sorting
  - Returns:
    - trades
    - prices
    - trade direction
    - IV
    - amounts
    - mark price
    - timestamps
  - Used for:
    - single option flow analysis
    - strike activity analysis
    - aggressive buyers/sellers detection
    - unusual trades analysis
    - AI trade reasoning
  - Polling:
    - every 1-5 sec
  - Cache:
    - save realtime trades to DB

- public/get_volatility_index_data
  - VIX-style volatility index endpoint
  - Params:
    - currency
    - start_timestamp
    - end_timestamp
    - resolution
  - Returns:
    - volatility candles
    - OHLC volatility data
    - timestamps
  - Used for:
    - volatility regime detection
    - fear/greed analysis
    - market stress analysis
    - volatility trend analysis
    - AI market sentiment analysis
    - hedge timing
  - Polling:
    - every 1-15 min
  - Cache:
    - save permanently to DB

- public/get_index_price
  - Current index price endpoint
  - Params:
    - index_name
  - Returns:
    - index price
    - estimated delivery price
  - Used for:
    - BTC reference price
    - portfolio valuation
    - stress analysis
    - mark price comparison
    - AI market analysis
    - hedge calculations
  - Polling:
    - every 1-5 sec
  - Cache:
    - save realtime snapshots to DB

- public/get_index_price_names
  - Available indexes discovery endpoint
  - Params:
    - extended
  - Returns:
    - available index names
    - combo support info
  - Used for:
    - dynamic market discovery
    - supported assets detection
    - system configuration
    - AI market scanner setup
  - Polling:
    - every few hours
  - Cache:
    - save permanently to DB

- public/get_delivery_prices
  - Historical settlement prices endpoint
  - Params:
    - index_name
    - offset
    - count
  - Returns:
    - historical delivery prices
    - settlement dates
  - Used for:
    - expiry analysis
    - settlement behavior analysis
    - volatility studies
    - historical options analysis
    - AI market research
  - Polling:
    - on demand
  - Cache:
    - save permanently to DB

- public/get_funding_rate_history
  - Historical funding rates endpoint
  - Params:
    - instrument_name
    - start_timestamp
    - end_timestamp
  - Returns:
    - funding rates
    - index prices
    - timestamps
    - 1h interest
    - 8h interest
  - Used for:
    - market sentiment analysis
    - long/short pressure analysis
    - perp market analysis
    - funding trend analysis
    - AI regime analysis
    - hedge timing
  - Polling:
    - every 1h
  - Cache:
    - save permanently to DB

- public/get_last_settlements_by_currency
  - Historical settlements endpoint
  - Params:
    - currency
    - type
    - count
    - continuation
  - Returns:
    - settlements
    - deliveries
    - bankruptcy events
    - funding settlements
    - PnL
    - timestamps
  - Used for:
    - expiry event analysis
    - liquidation analysis
    - market stress analysis
    - funding settlement analysis
    - AI historical market analysis
  - Polling:
    - on demand
  - Cache:
    - save permanently to DB

- public/get_mark_price_history
  - Historical mark prices endpoint
  - Params:
    - instrument_name
    - start_timestamp
    - end_timestamp
  - Returns:
    - historical mark prices
    - timestamps
  - Used for:
    - portfolio valuation analysis
    - margin analysis
    - options pricing analysis
    - volatility analysis
    - AI historical analysis
  - Polling:
    - on demand
  - Cache:
    - save permanently to DB

- public/get_time
  - Server time endpoint
  - Params:
    - none
  - Returns:
    - Deribit server timestamp
  - Used for:
    - time synchronization
    - polling coordination
    - latency calculations
    - realtime system checks
  - Polling:
    - every few minutes
  - Cache:
    - no caching needed

- public/get_supported_index_names
  - Supported indexes discovery endpoint
  - Params:
    - type
  - Returns:
    - supported index names
    - available market indexes
  - Used for:
    - dynamic system configuration
    - supported assets discovery
    - AI market scanner setup
    - market initialization
  - Polling:
    - every few hours
  - Cache:
    - save permanently to DB

## Agent Architecture
- ### [ ] Select LangChain architecture

Possible Architectures:

- ReAct Agent
  - Description:
    - The LLM thinks step-by-step and decides which tools to use dynamically

  - Pros:
    - Very flexible
    - Easy to prototype
    - Good conversational behavior
    - Simple to start with
    - Works well for chatbot-style systems

  - Cons:
    - Can become messy with many tools
    - Less predictable execution
    - Harder to debug
    - May loop or hallucinate tool usage

- OpenAI Tools Agent
  - Description:
    - Uses structured tool/function calling with predefined schemas

  - Pros:
    - More stable
    - Production-friendly
    - Better tool control
    - Easier debugging
    - Cleaner outputs

  - Cons:
    - Less flexible reasoning
    - More rigid workflow
    - Less autonomous exploration

- Multi-Agent System
  - Description:
    - Multiple specialized AI agents collaborate together

  - Pros:
    - Better specialization
    - More scalable
    - Cleaner responsibility separation
    - Can handle very complex systems

  - Cons:
    - High complexity
    - Hard orchestration
    - Expensive
    - Difficult debugging
    - Complex memory sharing

- Planner + Executor
  - Description:
    - One component creates plans while another executes them

  - Pros:
    - Better workflow control
    - Good for long tasks
    - Reduces hallucinations
    - More organized execution

  - Cons:
    - Slower execution
    - More components to maintain
    - Higher architecture complexity

- LangGraph
  - Description:
    - Graph/state-machine architecture for advanced AI workflows

  - Pros:
    - Very strong execution control
    - Persistent memory support
    - Retry/checkpoint support
    - Best scalability
    - Ideal for complex production systems

  - Cons:
    - Highest complexity
    - Harder learning curve
    - Longer development time
    - Overkill for small/simple systems

Questions for Discussion:
- Do we need a simple chatbot or a complete AI workflow platform?
- Is V1 mainly conversational or analytical?
- How complex do we expect the future system to become?
- Do we want faster development or stronger scalability?
- Do we need persistent memory and advanced workflow control from the beginning?

Current Recommendation:
- Start simple in V1
- ReAct or OpenAI Tools Agent may be enough initially
- Keep migration path open toward LangGraph or Multi-Agent architecture later

---

- ### [ ] Define agent workflow

Possible Workflow:

1. User sends message
   - Telegram bot
   - Dashboard chatbot

2. Agent receives request
   - Understand user intent
   - Identify required tools/data

3. Fetch data
   - Deribit APIs
   - SQLite databases
   - Portfolio snapshots
   - Market data
   - Historical data

4. Analysis phase
   - Portfolio analysis
   - Risk analysis
   - Greeks analysis
   - Volatility analysis
   - Market analysis

5. AI reasoning phase
   - Explain portfolio state
   - Detect problems
   - Detect opportunities
   - Generate hedge ideas
   - Generate market insights

6. Generate response
   - Human-readable explanation
   - Risk summary
   - Suggested actions
   - Charts/tables later if needed

7. Send response
   - Telegram
   - Dashboard chatbot UI

Possible Future Additions:
- Multi-step workflows
- Long-term memory
- Autonomous monitoring agent
- Scheduled AI reports
- Multi-agent collaboration
- Voice support

Questions for Discussion:
- Should the AI only answer questions or also proactively monitor?
- Should the AI be allowed to execute actions later?
- Should analysis be realtime or DB-driven only?
- Should reasoning always use live data?
- Do we want autonomous workflows later?

---

- ### [ ] Define memory system

Possible Memory Types:

- Conversation Memory
  - Store recent chat history
  - Helps maintain context during conversations
  - Useful for follow-up questions

- Portfolio Context Memory
  - Store portfolio-related context
  - Current positions
  - Risk preferences
  - Current strategies
  - Previous hedge discussions

- Market Context Memory
  - Store recent market conditions
  - Volatility regime
  - Market sentiment
  - Recent important events

- Long-Term Memory
  - Save important historical insights
  - Previous AI analyses
  - Portfolio behavior patterns
  - User preferences

- Vector Database Memory
  - Semantic memory/search
  - Store embeddings of conversations and reports
  - Useful for RAG systems later

Possible Technologies:
- SQLite
- PostgreSQL
- Redis
- ChromaDB
- FAISS
- Pinecone

Questions for Discussion:
- Do we really need long-term memory in V1?
- Should memory be local only or cloud-based?
- How much conversation history should be stored?
- Should memory be shared between Telegram and Dashboard?
- Do we need semantic search/RAG later?

Current Recommendation:
- Keep memory simple in V1
- Start with conversation memory + portfolio context
- SQLite may be enough initially
- Add vector memory later only if needed

---

- ### [ ] Define tools structure

Possible Tool Categories:

- Portfolio Tools
  - Get account summary
  - Get positions
  - Get open orders
  - Get trades history
  - Get margin data
  - Get Greeks exposure

- Market Tools
  - Get ticker data
  - Get order book
  - Get volatility data
  - Get funding rates
  - Get OHLCV/history
  - Get options chain

- Analysis Tools
  - Risk analysis
  - Greeks analysis
  - Volatility analysis
  - Stress testing
  - Hedge analysis
  - Market regime detection

- Database Tools
  - Read snapshots
  - Read historical data
  - Store AI reports
  - Store conversations
  - Query analytics data

- AI/Reasoning Tools
  - Summarization
  - Market explanation
  - Portfolio explanation
  - Trade reasoning
  - Report generation

- Notification Tools
  - Telegram sender
  - Alert formatter
  - Daily AI reports
  - Scheduled summaries

Possible Structure:
- One tool per responsibility
- Clear input/output schemas
- Async support
- Shared DB/API clients
- Logging/debug support

Questions for Discussion:
- Should tools call APIs directly or read from DB only?
- Should realtime tools be separated from historical tools?
- Do we need tool permissions/restrictions?
- Should tools return raw data or processed data?
- Should AI tools and data tools remain separated?

Current Recommendation:
- Keep tools modular and small
- Separate:
  - data fetching
  - analysis
  - AI reasoning
- Prefer DB-first architecture when possible
- Use live API only when necessary

---

- ### [ ] Define Telegram workflow

Possible Workflow:

1. User sends message to Telegram bot
2. Bot sends request to AI agent backend
3. Agent understands request
4. Agent calls required tools
5. Agent analyzes data
6. Agent generates response
7. Bot sends response back to Telegram

Possible Features:
- Portfolio Q&A
- Risk explanations
- Hedge suggestions
- Market analysis
- Daily AI summaries
- Smart AI alerts
- Voice notes later
- Image/chart support later

Questions for Discussion:
- Should Telegram use live APIs or DB-only mode?
- Should responses be short or detailed?
- Should the AI proactively message the user?
- Should Telegram support commands or natural language only?

Current Recommendation:
- Keep Telegram lightweight in V1
- Use DB-first architecture
- Allow live API calls only when needed
- Keep responses concise and actionable

---

- ### [ ] Define dashboard chatbot workflow

Possible Workflow:

1. User opens dashboard chatbot page
2. User sends message/question
3. Frontend sends request to backend API
4. AI agent processes request
5. Agent fetches required data/tools
6. Agent generates analysis
7. Dashboard displays response

Possible Features:
- Chat history
- Portfolio summaries
- Charts/tables
- Interactive analysis
- AI-generated reports
- Suggested follow-up questions
- Portfolio snapshots
- Multi-tab analysis later

Questions for Discussion:
- Should chatbot stream responses live?
- Should dashboard support charts/images?
- Should users inspect raw AI tool outputs?
- Should chatbot share memory with Telegram?
- Should dashboard allow advanced analysis mode?

Current Recommendation:
- Keep dashboard chatbot simple in V1
- Shared backend with Telegram
- Add charts/tables later
- Focus first on stable AI analysis workflows

---

## Documentation
- [ ] Create research notes
- [ ] Create architecture plan
- [ ] Generate final .md file
- [ ] Generate final .docx file


---

# Phase B - Core Infrastructure

## Deribit Integration
- [ ] Build API wrapper
- [ ] Build websocket manager
- [ ] Build retry handling

## Database
- [ ] Design DB structure
- [ ] Create portfolio tables
- [ ] Create market tables
- [ ] Create alerts tables

## Data Collection
- [ ] Build realtime collectors
- [ ] Build historical collectors
- [ ] Build schedulers

## Analysis Engine
- [ ] Build Greeks engine
- [ ] Build volatility engine
- [ ] Build stress testing engine
- [ ] Build risk engine

---

# Phase C - AI Agent

## LangChain
- [ ] Setup LangChain
- [ ] Connect LLM
- [ ] Register tools
- [ ] Build prompts
- [ ] Build reasoning workflow

## Agent Features
- [ ] Portfolio analysis
- [ ] Market analysis
- [ ] Risk analysis
- [ ] Alert explanations
- [ ] Hedge suggestions
- [ ] AI summaries

## Alerts
- [ ] Smart alerts
- [ ] Risk notifications
- [ ] Telegram notifications

---

# Phase D - Dashboard & Deployment

## Telegram Bot
- [ ] Build Telegram bot
- [ ] Connect AI agent
- [ ] Add commands
- [ ] Add alerts

## Dashboard
- [ ] Create chatbot page
- [ ] Connect AI agent
- [ ] Add realtime widgets
- [ ] Add reports

## Deployment
- [ ] Dockerize services
- [ ] Deploy on server
- [ ] Setup monitoring
- [ ] Final testing

---