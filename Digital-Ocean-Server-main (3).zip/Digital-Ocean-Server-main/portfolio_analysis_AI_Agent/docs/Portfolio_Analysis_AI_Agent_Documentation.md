# Portfolio Analysis AI Agent
## Research & Architecture Documentation

**Phase A - Research Consolidation (Living Document)**

---

> **DOCUMENT STATUS**
>
> The **final implementation plan is PENDING.**
> All sections marked **OPEN QUESTION**, **NEEDS TEAM DISCUSSION**, **PENDING DECISION**, or **PENDING CONFIRMATION** must be resolved and team-agreed before Phase B (Core Infrastructure) begins.
>
> No unresolved discussion in this document should be treated as a final decision.

---

## Table of Contents

1. [Executive Summary](#1-executive-summary)
2. [Portfolio Analysis Foundations](#2-portfolio-analysis-foundations)
3. [Deribit API Research](#3-deribit-api-research)
4. [Agent Architecture - Discussions](#4-agent-architecture--discussions)
5. [Open Questions Summary](#5-open-questions-summary)
6. [Next Steps](#6-next-steps)
7. [Appendix A - Deribit Docs Index](#appendix-a--deribit-docs-index)
8. [Appendix B - Document Status Legend](#appendix-b--document-status-legend)

---

## 1. Executive Summary

This document consolidates Phase A (Research & Planning) for the **Portfolio Analysis AI Agent**, a system that augments the existing realtime BTC options trading infrastructure with AI-driven analysis, explanation, and reasoning capabilities.

| Field | Value |
|---|---|
| Phase | A - Research & Planning |
| Document type | Living research consolidation |
| Status | Research partially finalized; architecture decisions pending |
| Implementation status | **Not started** - Phases B, C, D blocked on open questions |

**Scope of this document**
- Definitions of portfolio analysis features and trader needs (finalized)
- Catalogue of Deribit API endpoints required for the agent
- Architecture options under discussion (LangChain, workflow, memory, tools, channels)
- A consolidated list of open questions awaiting team decision

**Out of scope of this document**
- Final architecture decisions
- Implementation plans for Phases B / C / D
- Detailed Deribit endpoint parameter documentation (kept in `Deribit_docs/` - see [Appendix A](#appendix-a--deribit-docs-index))

---

## 2. Portfolio Analysis Foundations

> **Status: FINALIZED.** Sections 2.1 through 2.7 represent agreed research outcomes.

### 2.1 Definition - Portfolio Analysis

Portfolio analysis is the process of analyzing a trading portfolio to understand its current state, risk exposure, performance, and sensitivity to market conditions.

In crypto options trading, portfolio analysis includes:
- Greeks analysis
- Margin analysis
- Drawdown monitoring
- Volatility analysis
- PnL analysis
- Market exposure analysis
- Stress testing
- Hedge analysis

**Purpose**

The purpose of portfolio analysis is to:
- protect capital
- reduce risk
- detect dangerous conditions early
- improve trading decisions
- optimize portfolio positioning
- identify hedge opportunities

The AI agent should convert raw market and portfolio data into actionable insights, alerts, explanations, and recommendations.

---

### 2.2 Trader Needs & Expected Outputs

**Trader needs to understand:**
- current portfolio condition
- current market condition
- current risk exposure
- current margin state
- current Greeks exposure
- recent market changes
- portfolio performance
- liquidation risk
- hedge requirements
- abnormal market behavior

**Trader also needs:**
- realtime monitoring
- smart alerts
- historical comparisons
- AI explanations
- fast decision support
- scenario analysis

**Expected system outputs:**
- bullish / bearish market state
- portfolio risk level
- margin warnings
- volatility regime
- Greeks summary
- drawdown analysis
- stress test results
- hedge suggestions
- portfolio summaries
- anomaly alerts
- AI-generated explanations

**Output requirements:** clear, brief, actionable, severity-based, easy to understand.

---

### 2.3 Risk Analysis Features

**Metrics to analyze:**
- portfolio drawdown
- maintenance margin %
- liquidation risk
- unrealized PnL
- realized PnL
- portfolio leverage
- directional exposure
- portfolio concentration
- short gamma risk
- short volatility risk
- portfolio sensitivity to BTC movement
- portfolio sensitivity to volatility changes

**Risk monitoring**
- current risk state
- risk trend over time
- abnormal risk increases
- rapid portfolio changes
- dangerous exposure buildup

**Risk classification levels:** `SAFE` · `WARNING` · `DANGEROUS` · `CRITICAL`

**Risk scenarios:** BTC -5%, BTC -10%, BTC +5%, volatility expansion, volatility crush, large overnight moves.

**Example outputs**
- "Portfolio risk increased sharply in last 2 hours."
- "Maintenance margin approaching dangerous level."
- "Portfolio highly exposed to downside volatility expansion."
- "Short gamma exposure is dangerous near current BTC price."

---

### 2.4 Greeks Analysis

**Greeks monitored:** Delta · Gamma · Vega · Theta · (optional: Rho)

**Delta - directional exposure to BTC movement**
- monitor net delta
- detect delta drift
- classify bullish/bearish exposure
- detect dangerous directional imbalance

**Gamma - rate of delta change**
- detect short gamma danger
- detect expiry-related risk
- detect rapid exposure changes
- monitor near-strike exposure

**Vega - sensitivity to implied volatility**
- monitor long/short volatility exposure
- detect dangerous short vega
- detect volatility expansion risk
- detect volatility crush risk

**Theta - time-decay impact**
- estimate daily decay
- monitor premium decay
- compare theta gains vs risk

**Greeks monitoring**
- realtime tracking
- changes over time
- historical comparison
- risk-level classification
- Greeks alerts

**Example outputs**
- "Portfolio currently net bullish with high positive delta."
- "Short gamma exposure becoming dangerous near expiry."
- "Portfolio highly exposed to volatility expansion."
- "Theta income is strong but risk increased significantly."

---

### 2.5 Volatility Analysis

**Metrics analyzed:** historical volatility (HV), implied volatility (IV), realized volatility, IV vs HV spread, volatility trends, volatility spikes, volatility crush events.

**Historical volatility**
- calculate HV for multiple periods
- compare current HV vs historical values
- detect abnormal movement regimes

**Implied volatility**
- monitor ATM IV
- monitor term structure
- monitor IV skew
- detect expensive/cheap option environments

**IV vs HV analysis**
- compare implied vs realized
- detect overpricing/underpricing
- detect volatility premium expansion

**Volatility regimes:** `LOW` · `NORMAL` · `HIGH` · `EXTREME`

**Volatility monitoring**
- track changes over time
- detect sudden spikes
- detect compression
- monitor momentum

**Example outputs**
- "BTC volatility entered high volatility regime."
- "Implied volatility significantly overpriced relative to HV."
- "Volatility expansion risk increased sharply."
- "Current market conditions favor option sellers."

---

### 2.6 Stress Testing

The system simulates abnormal market scenarios and estimates impact on:
- portfolio equity
- unrealized PnL
- maintenance margin %
- liquidation risk
- Greeks exposure
- drawdown

**Stress scenarios:** BTC +/-5%, BTC +/-10%, volatility expansion, volatility crush, rapid intraday movement, overnight gaps, expiry-related movement.

**Stress engine outputs**
- projected losses
- projected margin usage
- projected Greeks changes
- portfolio breaking points
- liquidation danger zones

**Stress classification:** `SAFE` · `WARNING` · `DANGEROUS` · `CRITICAL`

**Stress monitoring**
- continuous testing
- compare current vs previous stress states
- detect rapid deterioration
- alert on dangerous scenarios

**Example outputs**
- "Portfolio could lose 12% if BTC drops 10%."
- "Maintenance margin may exceed dangerous level under volatility expansion."
- "Current short gamma exposure becomes critical during fast BTC movement."
- "Portfolio remains stable under all tested scenarios."

---

### 2.7 Hedge Suggestions

The system generates hedge suggestions based on portfolio Greeks, volatility regime, market direction, drawdown state, margin usage, and stress test results.

**Hedge goals**
- reduce liquidation risk
- reduce directional exposure
- reduce short gamma risk
- reduce short vega risk
- stabilize portfolio behavior
- protect portfolio during high volatility

**Hedge types**
- perpetual hedges
- long call protection
- long put protection
- spread structures
- position reduction
- exposure balancing
- volatility hedges

**Hedge logic outputs**
- explain why the hedge is needed
- estimate hedge impact
- estimate risk reduction
- estimate margin impact
- estimate cost of protection

**Hedge monitoring**
- monitor effectiveness
- detect failed hedges
- suggest adjustments
- detect over-hedging

**Example outputs**
- "Portfolio delta exposure is too bullish; consider partial BTC hedge."
- "Short vega exposure is dangerous during current volatility regime."
- "Adding long puts may reduce downside stress risk."
- "Current hedge protection is weak under high volatility scenarios."

---

## 3. Deribit API Research

> **Status:**
> - Portfolio / account endpoints - **FINALIZED**
> - Market data endpoints - **PENDING CONFIRMATION** (parent task in `TO_DO.md` not yet checked off)

### 3.1 Reference Note

This section is intentionally **brief and implementation-oriented**. Full parameter definitions, request/response schemas, behavior notes, and usage edge cases live in:

- [`Deribit_docs/Deribit_account_managment_endpoints.md`](../../Deribit_docs/Deribit_account_managment_endpoints.md)
- [`Deribit_docs/Deribit_Auth_endpoints.md`](../../Deribit_docs/Deribit_Auth_endpoints.md)
- [`Deribit_docs/Deribit_Market_data_endpoints.md`](../../Deribit_docs/Deribit_Market_data_endpoints.md)

**Implementation must reference those documents** rather than duplicating endpoint details here.

---

### 3.2 Portfolio / Account Endpoints - Status: FINALIZED

| Endpoint | Short Purpose | Where Used in System | Polling | Cache |
|---|---|---|---|---|
| `private/get_account_summary` | Main portfolio overview | Portfolio monitoring · risk · margin · Greeks · AI summaries | 5–15 s | Snapshots to DB |
| `private/get_positions` | Positions list with Greeks/PnL | Positions monitoring · Greeks · options risk · leverage · liquidation · hedge · AI analysis | 5–15 s | Snapshots to DB |
| `private/get_transaction_log` | Account activity history | Historical analysis · PnL · cashflow · trader behavior · AI summaries | On demand / minutes | Persisted |
| `private/get_user_trades_by_currency` | User trade history | Trade history · realized PnL · volatility · AI trade summaries · strategy | On demand / sync | Persisted |
| `private/get_subaccounts` | Subaccount overview | Multi-account monitoring · aggregation · global risk · AI summaries | Few minutes | Snapshots to DB |
| `private/get_subaccounts_details` | Subaccount positions detail | Multi-account positions · aggregated risk · global Greeks · AI summaries | 15–60 s | Snapshots to DB |
| `private/pme/simulate` | Portfolio margin simulation | Stress testing · liquidation analysis · hedge analysis · AI risk reasoning | On demand / minutes | Results to DB |
| `private/get_margins` | Margin estimation per trade | Pre-trade risk · hedge simulations · sizing · AI trade reasoning | On demand | None |
| `private/get_account_summaries` | Multi-currency overview | Global portfolio · multi-currency risk · AI portfolio analysis | 5–15 s | Snapshots to DB |
| `private/get_open_orders_by_currency` | Open orders monitor | Pending exposure · risk · hedge monitoring · AI analysis | 5–15 s | Snapshots to DB |
| `private/get_order_history_by_currency` | Order history | Execution analysis · trading behavior · strategy · AI summaries | On demand / sync | Persisted |
| `private/get_user_locks` | Account lock status | Account monitoring · health checks · operational alerts | Low frequency | Optional |
| `private/get_order_state` | Single order status | Order tracking · hedge execution · debugging · Telegram checks | On demand | None |

---

### 3.3 Market Data Endpoints - Status: PENDING CONFIRMATION

> The endpoints below have been drafted but the parent research task is **not yet finalized** in `TO_DO.md`. Treat as a **proposed list - needs team confirmation**.

| Endpoint | Short Purpose | Where Used in System | Polling | Cache |
|---|---|---|---|---|
| `public/ticker` | Realtime market data | Realtime monitoring · volatility · Greeks · funding · sentiment · AI market analysis | 1–5 s | Snapshots to DB |
| `public/get_order_book` | Market depth | Liquidity · spread · pressure · options flow · AI market analysis | 1–5 s | Snapshots to DB |
| `public/get_book_summary_by_currency` | Bulk market summary | Market scan · vol surface · options flow · unusual activity · AI regime · strikes | 10–30 s | Snapshots to DB |
| `public/get_book_summary_by_instrument` | Single-instrument summary | Single-option analysis · strikes · volatility · AI trade reasoning · hedge | 5–15 s | Snapshots to DB |
| `public/get_instruments` | Instrument discovery | Option-chain build · strikes · expirations · vol surface · AI scanning · filtering | 5–30 min | Persisted |
| `public/get_tradingview_chart_data` | Historical OHLCV | Historical · volatility · trend · AI patterns · backtesting · signals | On demand | Persisted |
| `public/get_historical_volatility` | Historical volatility | Vol regime · risk · stress · IV vs HV · AI regime · hedge logic | 5–30 min | Persisted |
| `public/get_last_trades_by_instrument` | Single-instrument trade flow | Option flow · strike activity · aggressors · unusual trades · AI reasoning | 1–5 s | Realtime to DB |
| `public/get_volatility_index_data` | VIX-style vol index | Vol regime · fear/greed · stress · trend · AI sentiment · hedge timing | 1–15 min | Persisted |
| `public/get_index_price` | Current index price | BTC reference · valuation · stress · mark comparison · AI · hedge calcs | 1–5 s | Snapshots to DB |
| `public/get_index_price_names` | Available indexes | Dynamic discovery · supported assets · system config · AI scanner setup | Few hours | Persisted |
| `public/get_delivery_prices` | Historical settlement prices | Expiry · settlement behavior · vol studies · historical options · AI research | On demand | Persisted |
| `public/get_funding_rate_history` | Historical funding rates | Sentiment · long/short pressure · perp · funding trend · AI regime · hedge timing | 1 h | Persisted |
| `public/get_last_settlements_by_currency` | Historical settlements | Expiry events · liquidation · stress · funding settlement · AI history | On demand | Persisted |
| `public/get_mark_price_history` | Historical mark prices | Valuation · margin · option pricing · volatility · AI history | On demand | Persisted |
| `public/get_time` | Server time | Time sync · polling coordination · latency · system checks | Few minutes | None |
| `public/get_supported_index_names` | Supported indexes | Dynamic config · supported assets · AI scanner setup · market init | Few hours | Persisted |

---

## 4. Agent Architecture - Discussions

> **Status: PENDING DECISION.** All subsections in §4 are **under discussion**. Working recommendations recorded here are **non-binding** and will be revisited with the team before implementation.

---

### 4.1 LangChain Architecture - Status: OPEN QUESTION

| Architecture | Description | Pros | Cons |
|---|---|---|---|
| **ReAct Agent** | LLM thinks step-by-step and dynamically picks tools | Flexible · easy to prototype · good conversational behavior · simple start · chatbot-friendly | Messy with many tools · less predictable · harder to debug · may loop/hallucinate |
| **OpenAI Tools Agent** | Structured tool/function calling with predefined schemas | Stable · production-friendly · better tool control · easier debugging · cleaner outputs | Less flexible reasoning · more rigid · less autonomous |
| **Multi-Agent System** | Specialized AI agents collaborating | Better specialization · scalable · clean separation · handles complex systems | High complexity · hard orchestration · expensive · hard to debug · complex memory sharing |
| **Planner + Executor** | One component plans, another executes | Better workflow control · good for long tasks · reduces hallucinations · organized | Slower · more components · higher complexity |
| **LangGraph** | Graph/state-machine workflow | Strong execution control · persistent memory · retry/checkpoint · best scalability · ideal for production | Highest complexity · steep learning curve · longer dev · overkill for small systems |

**Questions for Discussion**
- Do we need a simple chatbot or a complete AI workflow platform?
      a system to help us make better decison in portfolio managment depending on our goals with the portfolio
- Is V1 mainly conversational or analytical?
- How complex do we expect the system to become?
- Do we want faster development or stronger scalability?
- Do we need persistent memory and advanced workflow control from the beginning?

**Working recommendation (non-binding):** Start simple in V1 with ReAct or OpenAI Tools Agent; keep migration path open toward LangGraph or Multi-Agent later.

---

### 4.2 Agent Workflow - Status: NEEDS TEAM DISCUSSION

**Proposed workflow**
1. User sends message (Telegram or dashboard chatbot)
2. Agent receives request - understand intent, identify required tools/data
3. Fetch data (Deribit APIs · SQLite · portfolio snapshots · market data · history)
4. Analysis phase (portfolio · risk · Greeks · volatility · market)
5. AI reasoning phase (explain state · detect problems/opportunities · hedge ideas · market insights)
6. Generate response (human-readable · risk summary · suggested actions · charts/tables later)
7. Send response (Telegram · dashboard chatbot UI)

**Possible future additions**
- Multi-step workflows · long-term memory · autonomous monitoring · scheduled AI reports · multi-agent collaboration · voice support

**Questions for Discussion**
- Should the AI only answer questions or also proactively monitor?
- Should the AI be allowed to execute actions later?
- Should analysis be realtime or DB-driven only?
- Should reasoning always use live data?
- Do we want autonomous workflows later?

---

### 4.3 Memory System - Status: PENDING DECISION

**Possible memory types**
- **Conversation memory** - recent chat history · context · follow-ups
- **Portfolio context memory** - positions · risk preferences · current strategies · prior hedge discussions
- **Market context memory** - vol regime · sentiment · recent events
- **Long-term memory** - historical insights · prior AI analyses · behavior patterns · user preferences
- **Vector database memory** - semantic search · embeddings · RAG-ready

**Possible technologies:** SQLite · PostgreSQL · Redis · ChromaDB · FAISS · Pinecone

**Questions for Discussion**
- Do we really need long-term memory in V1?
- Local-only or cloud-based?
- How much conversation history?
- Should memory be shared between Telegram and Dashboard?
- Do we need semantic search/RAG later?

**Working recommendation (non-binding):** Keep memory simple in V1 - conversation memory + portfolio context, SQLite-backed. Add vector memory only if needed.

---

### 4.4 Tools Structure - Status: PENDING DECISION

**Possible tool categories**
- **Portfolio Tools** - account summary · positions · open orders · trades history · margins · Greeks
- **Market Tools** - ticker · order book · volatility · funding · OHLCV · option chain
- **Analysis Tools** - risk · Greeks · volatility · stress · hedge · regime detection
- **Database Tools** - read snapshots · read history · store reports · store conversations · query analytics
- **AI / Reasoning Tools** - summarization · market explanation · portfolio explanation · trade reasoning · report generation
- **Notification Tools** - Telegram sender · alert formatter · daily AI reports · scheduled summaries

**Proposed structure**
- One tool per responsibility · clear I/O schemas · async support · shared DB/API clients · logging/debug

**Questions for Discussion**
- Should tools call APIs directly or read from DB only?
- Should realtime tools be separated from historical tools?
- Do we need tool permissions/restrictions?
- Should tools return raw or processed data?
- Should AI tools and data tools remain separated?

**Working recommendation (non-binding):** Modular and small tools; separate data fetching, analysis, and AI reasoning. Prefer DB-first; use live APIs only when necessary.

---

### 4.5 Telegram Workflow - Status: PENDING DECISION

**Proposed workflow**
1. User sends message to Telegram bot
2. Bot forwards to AI agent backend
3. Agent understands request, calls tools, analyzes, responds
4. Bot sends response back

**Possible features**
- Portfolio Q&A · risk explanations · hedge suggestions · market analysis · daily AI summaries · smart AI alerts · voice notes (later) · charts (later)

**Questions for Discussion**
- Live API or DB-only mode?
- Short or detailed responses?
- Should AI proactively message?
- Commands or natural language only?

**Working recommendation (non-binding):** Lightweight Telegram in V1 · DB-first · live API only when needed · concise actionable responses.

---

### 4.6 Dashboard Chatbot Workflow - Status: PENDING DECISION

**Proposed workflow**
1. User opens chatbot page
2. Sends message
3. Frontend calls backend API
4. AI agent processes, fetches data/tools, analyzes
5. Dashboard displays response

**Possible features**
- Chat history · portfolio summaries · charts/tables · interactive analysis · AI reports · suggested follow-ups · portfolio snapshots · multi-tab analysis (later)

**Questions for Discussion**
- Stream responses live?
- Charts/images supported?
- Expose raw AI tool outputs?
- Share memory with Telegram?
- Allow advanced analysis mode?

**Working recommendation (non-binding):** Simple V1 · shared backend with Telegram · charts/tables later · prioritize stable AI workflows first.

---

### 4.7 Alert System / AI Analysis Layer - Status: OPEN QUESTION

**The AI agent does NOT replace the existing realtime alert system.**

**Existing system continues to handle:**
- realtime alerts · margin alerts · liquidation alerts · fast risk monitoring

**AI layer adds:**
- smarter analysis · portfolio summaries · market reasoning · trend explanations · hedge insights · strategic observations

**Possible AI-layer cadence:** every 6 h · every 12 h · daily · or after major market events.

**Examples**
- "Portfolio risk increased due to rising short gamma exposure."
- "Market shifted into high volatility regime."
- "Current positioning is too directional for current market conditions."

**Status:** AI alert/analysis layer **not yet finalized** - needs team confirmation on cadence, triggers, and interaction with the existing alert system.

---

## 5. Open Questions Summary

A consolidated checklist of every open discussion item. Implementation cannot begin until these are resolved.

### LangChain Architecture (§4.1)
- [ ] Simple chatbot vs. full AI workflow platform?
- [ ] V1 mainly conversational or analytical?
- [ ] How complex will the system become?
- [ ] Faster development or stronger scalability?
- [ ] Need persistent memory & advanced workflow control from day one?

### Agent Workflow (§4.2)
- [ ] AI answer-only vs. proactive monitoring?
- [ ] Should AI execute actions later?
- [ ] Realtime analysis vs. DB-driven only?
- [ ] Always use live data for reasoning?
- [ ] Autonomous workflows later?

### Memory System (§4.3)
- [ ] Long-term memory needed in V1?
- [ ] Local-only or cloud-based?
- [ ] How much chat history?
- [ ] Memory shared between Telegram and Dashboard?
- [ ] Semantic search / RAG required later?

### Tools Structure (§4.4)
- [ ] Tools call APIs directly or DB-only?
- [ ] Realtime vs. historical tool separation?
- [ ] Tool permissions/restrictions needed?
- [ ] Raw vs. processed data returned?
- [ ] AI tools vs. data tools - separated?

### Telegram Workflow (§4.5)
- [ ] Live API or DB-only mode?
- [ ] Short or detailed responses?
- [ ] Proactive AI messaging?
- [ ] Commands vs. natural language?

### Dashboard Chatbot Workflow (§4.6)
- [ ] Stream responses live?
- [ ] Charts/images supported?
- [ ] Expose raw tool outputs?
- [ ] Shared memory with Telegram?
- [ ] Advanced analysis mode?

### Alert System / AI Analysis Layer (§4.7)
- [ ] Cadence (6 h / 12 h / daily / event-driven)?
- [ ] Triggers for AI-layer activation?
- [ ] Interaction with existing alert system?

### Deribit Market Data Endpoints (§3.3)
- [ ] Confirm proposed market data endpoint list?
- [ ] Add or remove any endpoints?

---

## 6. Next Steps

1. **Resolve all open questions** in §5 with team review.
2. **Finalize Deribit market data endpoint list** (§3.3).
3. **Lock the architecture decision** for §4.1 – §4.7.
4. **Only then**, proceed to Phase B (Core Infrastructure) - currently *Out of Scope* for this document.

### Future Work (Out of Scope)

For reference only - these phases from `TO_DO.md` will be planned in detail in follow-up documents once Phase A is closed:

- **Phase B - Core Infrastructure:** Deribit integration · Database · Data collection · Analysis engine
- **Phase C - AI Agent:** LangChain setup · Agent features · Alerts
- **Phase D - Dashboard & Deployment:** Telegram bot · Dashboard · Deployment

---

## Appendix A - Deribit Docs Index

Primary reference for endpoint parameters, behavior, and edge cases. Implementation must use these documents rather than re-deriving the API surface.

| Document | Scope |
|---|---|
| [Deribit_account_managment_endpoints.md](../../Deribit_docs/Deribit_account_managment_endpoints.md) | Account, portfolio, positions, orders, transactions, margin |
| [Deribit_Auth_endpoints.md](../../Deribit_docs/Deribit_Auth_endpoints.md) | Authentication & session management |
| [Deribit_Market_data_endpoints.md](../../Deribit_docs/Deribit_Market_data_endpoints.md) | Public market data, instruments, volatility, settlements, indexes |

---

## Appendix B - Document Status Legend

| Marker | Meaning |
|---|---|
| **FINALIZED** | Research outcome is agreed and stable. Safe to use as input for implementation planning. |
| **OPEN QUESTION** | Topic raised; no decision yet; multiple options on the table. |
| **NEEDS TEAM DISCUSSION** | Draft proposal exists but requires team alignment before adoption. |
| **PENDING DECISION** | Options analyzed; awaiting a final call. |
| **PENDING CONFIRMATION** | Drafted content not yet checked off in source `TO_DO.md`. |
| **OUT OF SCOPE** | Belongs to a later phase; not planned in this document. |

---

*Source of truth for this document:* [`portfolio_analysis_AI_Agent/docs/TO_DO.md`](TO_DO.md)
*Document type:* Living research consolidation - will be updated as open questions are resolved.
