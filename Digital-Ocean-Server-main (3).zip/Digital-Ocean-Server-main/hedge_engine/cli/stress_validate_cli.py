# hedge_engine/cli/stress_validate_cli.py
"""
Phase 7: CLI for validating the stress foundation.

Usage:
  python -m hedge_engine.cli.stress_validate_cli --mode synthetic
  python -m hedge_engine.cli.stress_validate_cli --mode live --db data/btc_trading.sqlite

Modes:
  synthetic  - Run stress on a hardcoded test portfolio (no Deribit needed)
  live       - Run stress on the latest live snapshot from DB
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from datetime import datetime, timezone


def _synthetic_validation():
    """Run full stress validation on a synthetic portfolio."""
    from hedge_engine.risk.stress.stress_fast import run_stress_fast, to_json_dict
    from hedge_engine.risk.stress.stress_deep import deep_reprice, DeepStressConfig
    from hedge_engine.risk.stress.calibration import calibrate_scenarios, get_active_scenarios_with_calibration
    from hedge_engine.settings.config import EngineConfig

    cfg = EngineConfig()

    SPOT = 87_000.0
    EQUITY = 100_000.0
    HWM = 105_000.0

    print("=" * 60)
    print("STRESS FOUNDATION VALIDATION - SYNTHETIC MODE")
    print("=" * 60)

    # ── Step 1: Calibration ──
    print("\n--- Step 1: Scenario Calibration ---")
    cal = calibrate_scenarios(
        our_scenarios=cfg.stress_scenarios,
        pme_raw=None,
        hv_30d_pct=48.0,
    )
    print(f"  PME available: {cal.pme_available}")
    print(f"  Our worst downside: {cal.our_worst_down_pct:.0%}")
    print(f"  Our worst upside: {cal.our_worst_up_pct:.0%}")
    print(f"  Our max IV bump: {cal.our_max_iv_bump:.0f} vol pts")
    print(f"  Extreme recommended: {cal.extreme_scenario_recommended}")

    active_scenarios = get_active_scenarios_with_calibration(
        base_scenarios=cfg.stress_scenarios,
        calibration=cal,
    )
    print(f"  Active scenarios: {len(active_scenarios)}")

    # ── Step 2: Fast stress ──
    print("\n--- Step 2: Fast Stress (Greeks-based) ---")
    portfolios = {
        "long_delta_short_vega": {
            "delta_btc": 1.5, "gamma": -0.0005, "vega": -1800.0,
        },
        "hedged_neutral": {
            "delta_btc": 0.1, "gamma": -0.0002, "vega": -500.0,
        },
        "heavy_short_gamma": {
            "delta_btc": 0.5, "gamma": -0.002, "vega": -3000.0,
        },
    }

    for name, greeks in portfolios.items():
        fast = run_stress_fast(
            equity_usd=EQUITY,
            hwm_usd=HWM,
            spot_index_usd=SPOT,
            delta_btc=greeks["delta_btc"],
            gamma=greeks["gamma"],
            vega_usd_per_vol=greeks["vega"],
            scenarios=list(active_scenarios),
            dd_override_threshold=cfg.FAST_STRESS_OVERRIDE_DD,
            regime="NORMAL",
        )
        fast_d = to_json_dict(fast)
        worst_dd = min(
            (s.get("projected_dd_worst", 0) or 0 for s in fast_d["scenarios"].values()),
            default=0,
        )
        worst_name = min(
            fast_d["scenarios"].items(),
            key=lambda x: x[1].get("projected_dd_worst", 0) or 0,
        )[0]
        print(f"\n  Portfolio: {name}")
        print(f"    Worst DD: {worst_dd:.2%} (scenario: {worst_name})")
        print(f"    Override: {fast.stress_override}")
        for sname, sresult in fast_d["scenarios"].items():
            pnl = sresult.get("pnl_total_usd", 0)
            dd = sresult.get("projected_dd_worst", 0)
            print(f"      {sname:20s}  PnL={pnl:>+12,.0f}  DD={dd:>+8.2%}" if dd else
                  f"      {sname:20s}  PnL={pnl:>+12,.0f}  DD=N/A")

    # ── Step 3: Deep stress ──
    print("\n--- Step 3: Deep Stress (Position-level B-S repricing) ---")
    positions = [
        {
            "instrument_name": "BTC-PERPETUAL",
            "kind": "perpetual",
            "size": 44_000.0,
            "index_price": SPOT,
            "delta": 0.5,
        },
        {
            "instrument_name": "BTC-28MAR26-80000-P",
            "kind": "option",
            "option_type": "P",
            "right": "P",
            "size": -3.0,
            "strike": 80000.0,
            "dte_days": 30.0,
            "mark_price_usd": 1200.0,
            "index_price": SPOT,
        },
        {
            "instrument_name": "BTC-28MAR26-95000-C",
            "kind": "option",
            "option_type": "C",
            "right": "C",
            "size": 2.0,
            "strike": 95000.0,
            "dte_days": 30.0,
            "mark_price_usd": 1800.0,
            "index_price": SPOT,
        },
    ]

    deep_cfg = DeepStressConfig(
        scenarios={s.name: (s.spot_shock_pct, s.iv_bump_vol, s.apply_skew_bump) for s in active_scenarios},
        iv_floor=cfg.iv_floor,
        iv_cap=3.0,
        r=0.0,
    )
    deep = deep_reprice(
        positions=positions,
        equity_usd=EQUITY,
        hwm_usd=HWM,
        spot_index_usd=SPOT,
        cfg=deep_cfg,
    )

    print(f"  Positions: {len(positions)}")
    for sname, sresult in deep["scenarios"].items():
        pnl_opt = sresult.get("pnl_options_usd", 0)
        pnl_lin = sresult.get("pnl_linear_usd", 0)
        pnl_tot = sresult.get("pnl_total_usd", 0)
        eq = sresult.get("projected_equity_usd", 0)
        dd = sresult.get("projected_dd_worst")
        dd_str = f"{dd:>+8.2%}" if dd is not None else "N/A"
        counts = sresult.get("debug", {}).get("counts", {})
        print(
            f"    {sname:20s}  "
            f"PnL_opt={pnl_opt:>+10,.0f}  PnL_lin={pnl_lin:>+10,.0f}  "
            f"PnL_tot={pnl_tot:>+10,.0f}  Eq={eq:>12,.0f}  DD={dd_str}  "
            f"opt_priced={counts.get('opt_priced', '?')}"
        )

    # ── Step 4: Save debug dump ──
    os.makedirs("logs", exist_ok=True)
    ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    dump_path = f"logs/stress_validate_synthetic_{ts}.json"
    dump = {
        "mode": "synthetic",
        "ts_utc": ts,
        "spot": SPOT,
        "equity": EQUITY,
        "hwm": HWM,
        "calibration": cal.to_dict(),
        "active_scenarios": [s.name for s in active_scenarios],
        "deep_result": deep,
    }
    with open(dump_path, "w") as f:
        json.dump(dump, f, indent=2, default=str)
    print(f"\n  Debug dump saved: {dump_path}")
    print("\n[OK] Validation complete.")


def _live_validation(db_path: str):
    """Run stress on the latest live snapshot from DB - with full reconciliation."""
    import sqlite3
    from hedge_engine.core.snapshot_builder import (
        build_engine_inputs_from_engine_db,
        _latest_tick_list,
        T_POS,
    )
    from hedge_engine.risk.stress.stress_runner import compute_stress_artifact
    from hedge_engine.risk.stress.stress_runner import min_projected_dd_from_scenarios
    from hedge_engine.risk.stress.stress_truth import extract_worst_dd, reconcile_fast_deep
    from hedge_engine.risk.risk_checks import compute_flags, RiskFlags
    from hedge_engine.settings.config import EngineConfig
    import logging

    cfg = EngineConfig()
    logger = logging.getLogger("stress_validate")
    logger.setLevel(logging.WARNING)

    print("=" * 60)
    print("STRESS FOUNDATION VALIDATION - LIVE MODE")
    print(f"DB: {db_path}")
    print("=" * 60)

    con = sqlite3.connect(db_path)
    try:
        result = build_engine_inputs_from_engine_db(con=con, logger=logger)
    except Exception as e:
        print(f"ERROR: Could not build engine inputs: {e}")
        return

    inputs = result.inputs
    print(f"\n  Equity:     ${inputs.total_equity_usd:,.2f}")
    print(f"  HWM:        ${inputs.hwm_usd:,.2f}")
    print(f"  DD:         {inputs.dd:.2%}")
    print(f"  MM%:        {inputs.mm_pct:.1f}%")
    print(f"  Spot:       ${inputs.spot_index_usd:,.2f}")
    print(f"  Delta:      {inputs.portfolio_delta_btc:.4f} BTC")
    print(f"  Gamma:      {inputs.portfolio_gamma:.6f}")
    print(f"  Vega:       {inputs.portfolio_vega:.2f} USD/vol")

    positions = _latest_tick_list(con, T_POS) or []
    print(f"  Positions:  {len(positions)}")

    print(f"\n  Calibration caps:")
    print(f"    gamma_cap: {cfg.FAST_STRESS_GAMMA_PNL_CAP_EQUITY_PCT:.0%} of equity")
    print(f"    vega_cap:  {cfg.FAST_STRESS_VEGA_PNL_CAP_EQUITY_PCT:.0%} of equity")
    print(f"    loss_floor:{cfg.FAST_STRESS_TOTAL_LOSS_FLOOR_EQUITY_PCT:.0%} of equity")

    # Build a minimal snapshot for compute_stress_artifact
    snapshot = {
        "spot_index_usd": inputs.spot_index_usd,
        "equity_usd": inputs.total_equity_usd,
        "mm_pct": inputs.mm_pct,
        "portfolio_delta_btc": inputs.portfolio_delta_btc,
        "portfolio_gamma": inputs.portfolio_gamma,
        "portfolio_vega": inputs.portfolio_vega,
        "hv_30d_pct": inputs.hv_30d_pct,
        "iv_atm_30d_pct": inputs.iv_atm_30d_pct,
        "iv_minus_hv_30d_pp": inputs.iv_minus_hv_30d_pp,
        "positions": positions,
    }
    state = {"hwm_usd": inputs.hwm_usd, "dd": inputs.dd}
    flags = {"speed_trigger": False, "vega_breach": False, "gamma_budget_breach": False}

    # Run full stress pipeline (fast + deep)
    artifact = compute_stress_artifact(
        snapshot=snapshot, state=state, flags=flags, cfg=cfg, force_deep=True,
    )

    fast = artifact.get("fast") or {}
    deep = artifact.get("deep")

    # ── Fast stress ──
    print("\n--- Fast Stress (calibrated) ---")
    fast_scenarios = fast.get("scenarios", {})
    for sname, sr in fast_scenarios.items():
        pnl = sr.get("pnl_total_usd", 0)
        dd = sr.get("projected_dd_worst")
        dd_str = f"{dd:>+8.2%}" if dd is not None else "N/A"
        print(f"    {sname:20s}  PnL={pnl:>+12,.0f}  DD={dd_str}")
    fast_worst = min_projected_dd_from_scenarios(fast)
    print(f"  Fast worst DD: {fast_worst:.2%}")

    # ── Deep stress ──
    if deep:
        print("\n--- Deep Stress (B-S repricing) ---")
        deep_scenarios = deep.get("scenarios", {})
        for sname, sr in deep_scenarios.items():
            pnl = sr.get("pnl_total_usd", 0)
            dd = sr.get("projected_dd_worst") or sr.get("projected_dd")
            dd_str = f"{dd:>+8.2%}" if dd is not None else "N/A"
            print(f"    {sname:20s}  PnL={pnl:>+12,.0f}  DD={dd_str}")
        deep_worst = min_projected_dd_from_scenarios(deep)
        print(f"  Deep worst DD: {deep_worst:.2%}")
    else:
        print("\n  [Deep stress not available]")

    # ── Truth source ──
    worst_dd, source = extract_worst_dd(artifact, fallback_dd=inputs.dd)
    print(f"\n--- Decision Truth ---")
    print(f"  Worst DD used:  {worst_dd:.2%}")
    print(f"  Source:          {source}")
    print(f"  Override:        {artifact.get('stress_override', False)}")

    # ── Reconciliation ──
    recon = reconcile_fast_deep(artifact)
    if recon.get("n_scenarios_compared", 0) > 0:
        print(f"\n--- Fast vs Deep Reconciliation ---")
        print(f"  {'Scenario':20s}  {'Fast PnL':>12s}  {'Deep PnL':>12s}  {'Diff':>12s}  {'Fast DD':>9s}  {'Deep DD':>9s}  Truth")
        for r in recon["scenarios"]:
            fp = f"{r['fast_pnl']:>+12,.0f}" if r["fast_pnl"] is not None else f"{'N/A':>12s}"
            dp = f"{r['deep_pnl']:>+12,.0f}" if r["deep_pnl"] is not None else f"{'N/A':>12s}"
            diff = f"{r['pnl_diff']:>+12,.0f}" if r["pnl_diff"] is not None else f"{'N/A':>12s}"
            fdd = f"{r['fast_dd']:>+8.2%}" if r["fast_dd"] is not None else f"{'N/A':>8s}"
            ddd = f"{r['deep_dd']:>+8.2%}" if r["deep_dd"] is not None else f"{'N/A':>8s}"
            print(f"  {r['scenario']:20s}  {fp}  {dp}  {diff}  {fdd}  {ddd}  {r['truth_used']}")
        print(f"\n  Max |PnL diff|: ${recon.get('max_abs_pnl_diff', 0):,.0f}")

    # ── Save debug dump ──
    os.makedirs("logs", exist_ok=True)
    ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    dump_path = f"logs/stress_validate_live_{ts}.json"
    dump = {
        "mode": "live",
        "ts_utc": ts,
        "inputs": {
            "equity": inputs.total_equity_usd,
            "hwm": inputs.hwm_usd,
            "dd": inputs.dd,
            "mm_pct": inputs.mm_pct,
            "spot": inputs.spot_index_usd,
            "delta": inputs.portfolio_delta_btc,
            "gamma": inputs.portfolio_gamma,
            "vega": inputs.portfolio_vega,
            "n_positions": len(positions),
        },
        "worst_dd": worst_dd,
        "truth_source": source,
        "reconciliation": recon,
    }
    with open(dump_path, "w") as f:
        json.dump(dump, f, indent=2, default=str)
    print(f"\n  Debug dump: {dump_path}")

    con.close()
    print("\n[OK] Live validation complete.")


def main():
    parser = argparse.ArgumentParser(description="Stress foundation validation CLI")
    parser.add_argument("--mode", choices=["synthetic", "live"], default="synthetic")
    parser.add_argument("--db", default="data/btc_trading.sqlite")
    args = parser.parse_args()

    if args.mode == "synthetic":
        _synthetic_validation()
    else:
        _live_validation(args.db)


if __name__ == "__main__":
    main()
