import json
import os
import time
from pathlib import Path
from typing import Any, Dict, List

from hedge_engine.data.deribit_client import DeribitClient

from dotenv import load_dotenv
load_dotenv()


def _safe_float(x: Any, default: float = 0.0) -> float:
    try:
        if x is None:
            return default
        return float(x)
    except Exception:
        return default


def _classify_instrument(instrument_name: str) -> str:
    s = (instrument_name or "").upper()
    if s.endswith("-PERPETUAL"):
        return "perpetual"
    if s.endswith("-C") or s.endswith("-P"):
        return "option"
    if "-" in s:
        return "future"
    return "unknown"


def _group_positions(positions: List[Dict[str, Any]]) -> Dict[str, List[Dict[str, Any]]]:
    out: Dict[str, List[Dict[str, Any]]] = {"perpetual": [], "future": [], "option": [], "unknown": []}
    for p in positions:
        name = str(p.get("instrument_name", "") or "")
        out[_classify_instrument(name)].append(p)
    return out


def _aggregate_greeks_btc(positions: List[Dict[str, Any]]) -> Dict[str, float]:
    # NOTE: In Deribit positions, greeks can appear in different shapes.
    # We sum whatever is present: delta / gamma / vega at position level.
    delta = 0.0
    gamma = 0.0
    vega = 0.0
    theta = 0.0

    for p in positions:
        delta += _safe_float(p.get("delta"))
        gamma += _safe_float(p.get("gamma"))
        vega += _safe_float(p.get("vega"))
        theta += _safe_float(p.get("theta"))

    return {
        "delta_total_btc": float(delta),
        "gamma_total": float(gamma),
        "vega_total": float(vega),
        "theta_total": float(theta),
    }


def _derive_margins(acct: Dict[str, Any]) -> Dict[str, Any]:
    mb = _safe_float(acct.get("margin_balance"))
    mm = _safe_float(acct.get("maintenance_margin"))
    im = _safe_float(acct.get("initial_margin"))

    mm_pct = (mm / mb * 100.0) if mb > 0 else 0.0
    im_pct = (im / mb * 100.0) if mb > 0 else 0.0

    # USD totals (best for cross-portfolio)
    mb_usd = _safe_float(acct.get("total_margin_balance_usd"))
    mm_usd = _safe_float(acct.get("total_maintenance_margin_usd"))
    im_usd = _safe_float(acct.get("total_initial_margin_usd"))

    mm_pct_usd = (mm_usd / mb_usd * 100.0) if mb_usd > 0 else 0.0
    im_pct_usd = (im_usd / mb_usd * 100.0) if mb_usd > 0 else 0.0

    return {
        "margin_balance": mb,
        "maintenance_margin": mm,
        "initial_margin": im,
        "mm_pct_of_mb": mm_pct,
        "im_pct_of_mb": im_pct,
        "total_margin_balance_usd": mb_usd,
        "total_maintenance_margin_usd": mm_usd,
        "total_initial_margin_usd": im_usd,
        "mm_pct_of_mb_usd": mm_pct_usd,
        "im_pct_of_mb_usd": im_pct_usd,
    }


def cmd_deribit_dump_all(out_path: str = "logs/deribit_dump_all.json") -> None:
    os.makedirs("logs", exist_ok=True)

    t0 = time.time()
    c = DeribitClient.from_env()

    # RAW pulls (keep everything)
    acct = c.get_account_summary(currency="BTC", extended=True)
    positions = c.get_positions(currency="BTC")
    spot = c.get_index_price("btc_usd")

    # Funding (perp)
    # Your client currently has signature get_funding_rate(instrument_name="BTC-PERP")
    # so we call with perp instrument name explicitly to avoid any mismatch.
    funding = c.get_funding_rate("BTC-PERPETUAL")

    grouped = _group_positions(positions)
    agg_all = _aggregate_greeks_btc(positions)
    agg_opts = _aggregate_greeks_btc(grouped["option"])
    agg_perp = _aggregate_greeks_btc(grouped["perpetual"])
    agg_fut = _aggregate_greeks_btc(grouped["future"])

    margins = _derive_margins(acct)

    payload: Dict[str, Any] = {
        "meta": {
            "ts_utc": int(time.time()),
            "elapsed_s": round(time.time() - t0, 3),
            "base_url": os.getenv("DERIBIT_BASE_URL", "https://www.deribit.com"),
            "note": "FULL RAW + derived metrics for deterministic debugging",
        },
        "spot_index_usd": spot,

        # Derived (engine-friendly)
        "derived": {
            "counts": {k: len(v) for k, v in grouped.items()},
            "margins": margins,
            "greeks_agg_all": agg_all,
            "greeks_agg_options": agg_opts,
            "greeks_agg_perpetual": agg_perp,
            "greeks_agg_futures": agg_fut,
        },

        # RAW (full detail)
        "raw": {
            "account_summary": acct,
            "positions": positions,
            "positions_grouped": grouped,
            "funding_book_summary": funding,
        },
    }

    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2, ensure_ascii=False)

    print(f"[OK] wrote {out_path}")


if __name__ == "__main__":
    cmd_deribit_dump_all()
    
    
# python -m hedge_engine.cli.Deribit_client_cli