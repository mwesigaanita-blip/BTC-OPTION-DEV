# hedge_engine/cli/reset_hwm_cli.py
from __future__ import annotations

import argparse
import json
from datetime import datetime, timezone
from typing import Any

from hedge_engine.data.state_store import open_sqlite, ensure_state_tables
from hedge_engine.data.deribit_client import DeribitClient

from dotenv import load_dotenv # type: ignore
load_dotenv()

HWM_KEY = "hwm_usd"
RISK_MODE_KEY = "risk_mode"


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _loads_json_safe(raw: str | None, default: dict[str, Any] | None = None) -> dict[str, Any]:
    if default is None:
        default = {}
    if not raw:
        return dict(default)
    try:
        obj = json.loads(raw)
        return obj if isinstance(obj, dict) else dict(default)
    except Exception:
        return dict(default)


def get_state_value(con, key: str) -> tuple[dict[str, Any], str | None]:
    row = con.execute(
        """
        SELECT value_json, updated_at_utc
        FROM hedge_engine_state
        WHERE key = ?
        LIMIT 1
        """,
        (key,),
    ).fetchone()

    if not row:
        return {}, None

    value_json, updated_at_utc = row
    return _loads_json_safe(value_json, {}), updated_at_utc


def upsert_state_value(con, key: str, value_obj: dict[str, Any], updated_at_utc: str) -> None:
    con.execute(
        """
        INSERT INTO hedge_engine_state (key, value_json, updated_at_utc)
        VALUES (?, ?, ?)
        ON CONFLICT(key) DO UPDATE SET
            value_json = excluded.value_json,
            updated_at_utc = excluded.updated_at_utc
        """,
        (key, json.dumps(value_obj), updated_at_utc),
    )


def get_current_hwm_usd(con) -> float:
    obj, _ = get_state_value(con, HWM_KEY)
    return float(obj.get("hwm_usd", 0.0) or 0.0)


def get_last_known_equity_usd_from_db(con) -> float:
    """
    Optional helper if later you decide to store a key like:
      key = 'last_equity_usd'
      value_json = {"equity_usd": 12345.67}
    """
    obj, _ = get_state_value(con, "last_equity_usd")
    return float(obj.get("equity_usd", 0.0) or 0.0)


def fetch_equity_usd_from_deribit() -> float:
    """
    Recalculate total equity in USD from Deribit account summaries.

    Current implementation:
    - BTC equity converted using BTC index price
    - USDT / USDC treated as ~1 USD
    - tries ETH too if available
    - silently skips currencies not available on the account

    You can extend this later for more currencies if needed.
    """
    client = DeribitClient.from_env()

    total_equity_usd = 0.0

    currency_price_map: dict[str, float] = {
        "USDT": 1.0,
        "USDC": 1.0,
    }

    # Try to enrich FX/index prices for coin margined balances
    try:
        currency_price_map["BTC"] = float(client.get_index_price("btc_usd"))
    except Exception:
        pass

    try:
        currency_price_map["ETH"] = float(client.get_index_price("eth_usd"))
    except Exception:
        pass

    for currency in ("BTC", "ETH", "USDT", "USDC"):
        try:
            summary = client.get_account_summary(currency=currency, extended=True)
        except Exception:
            continue

        if not isinstance(summary, dict):
            continue

        equity_ccy = float(summary.get("equity", 0.0) or 0.0)
        if equity_ccy == 0.0:
            continue

        fx = float(currency_price_map.get(currency, 0.0) or 0.0)
        if fx <= 0:
            continue

        total_equity_usd += equity_ccy * fx

    if total_equity_usd <= 0:
        raise RuntimeError("Failed to recalculate equity_usd from Deribit.")

    return float(total_equity_usd)


def ensure_hwm_reset_table(con) -> None:
    con.execute(
        """
        CREATE TABLE IF NOT EXISTS hwm_resets (
            ts_utc TEXT PRIMARY KEY,
            prev_hwm_usd REAL,
            new_hwm_usd REAL,
            source_equity_usd REAL,
            source_type TEXT,
            reason TEXT,
            state_updated_at_utc TEXT
        )
        """
    )


def main() -> int:
    ap = argparse.ArgumentParser(description="Reset Hedge Engine High Water Mark (HWM)")
    ap.add_argument("--db", required=True, help="Path to btc_trading.sqlite")
    ap.add_argument(
        "--mode",
        choices=["set", "set-to-current-db", "recalc-from-deribit", "clear"],
        default="recalc-from-deribit",
        help=(
            "set: set HWM to provided value\n"
            "set-to-current-db: set HWM using stored DB equity key last_equity_usd\n"
            "recalc-from-deribit: fetch fresh account equity from Deribit and use it as HWM\n"
            "clear: set HWM to 0 (NOT recommended)"
        ),
    )
    ap.add_argument("--hwm-usd", type=float, default=None, help="Required when --mode set")
    ap.add_argument("--reason", type=str, default="manual_reset", help="Audit reason")
    args = ap.parse_args()

    con = open_sqlite(args.db)
    ensure_state_tables(con)
    ensure_hwm_reset_table(con)

    prev_hwm_obj, prev_updated_at = get_state_value(con, HWM_KEY)
    prev_hwm_usd = float(prev_hwm_obj.get("hwm_usd", 0.0) or 0.0)

    source_equity_usd = 0.0
    source_type = ""

    if args.mode == "set":
        if args.hwm_usd is None:
            raise SystemExit("ERROR: --hwm-usd is required when --mode set")
        new_hwm_usd = float(args.hwm_usd)
        source_equity_usd = new_hwm_usd
        source_type = "manual"

    elif args.mode == "set-to-current-db":
        source_equity_usd = get_last_known_equity_usd_from_db(con)
        if source_equity_usd <= 0:
            raise SystemExit(
                "ERROR: No valid last_equity_usd found in DB state. "
                "Store key='last_equity_usd' with {'equity_usd': ...} or use --mode recalc-from-deribit."
            )
        new_hwm_usd = float(source_equity_usd)
        source_type = "db_state"

    elif args.mode == "recalc-from-deribit":
        source_equity_usd = fetch_equity_usd_from_deribit()
        new_hwm_usd = float(source_equity_usd)
        source_type = "deribit"

    elif args.mode == "clear":
        new_hwm_usd = 0.0
        source_equity_usd = 0.0
        source_type = "clear"

    else:
        raise SystemExit(f"Unknown mode: {args.mode}")

    now = utc_now_iso()

    # Update HWM key in hedge_engine_state
    upsert_state_value(
        con,
        HWM_KEY,
        {"hwm_usd": new_hwm_usd},
        now,
    )
    
    upsert_state_value(
        con,
        RISK_MODE_KEY,
        {
            "mode": "NORMAL",
            "safe_streak": 0,
            "last_change_ts_utc": now,
            "last_reason": "manual_hwm_reset",
        },
        now,
    )
    # Optional: if you later store dd state separately, reset it here as well.
    # Example:
    # upsert_state_value(con, "dd_state", {"last_dd_worst": 0.0}, now)

    con.execute(
        """
        INSERT OR REPLACE INTO hwm_resets (
            ts_utc,
            prev_hwm_usd,
            new_hwm_usd,
            source_equity_usd,
            source_type,
            reason,
            state_updated_at_utc
        ) VALUES (?, ?, ?, ?, ?, ?, ?)
        """,
        (
            now,
            prev_hwm_usd,
            new_hwm_usd,
            source_equity_usd,
            source_type,
            args.reason,
            prev_updated_at or "",
        ),
    )

    con.commit()
    con.close()

    print(json.dumps({
        "event": "HWM_RESET",
        "ts_utc": now,
        "db": args.db,
        "mode": args.mode,
        "prev_hwm_usd": prev_hwm_usd,
        "new_hwm_usd": new_hwm_usd,
        "source_equity_usd": source_equity_usd,
        "source_type": source_type,
        "reason": args.reason,
    }, indent=2))

    return 0


if __name__ == "__main__":
    raise SystemExit(main())


# best mode: fetch fresh equity from Deribit and set HWM to it
# python -m hedge_engine.cli.reset_hwm_cli --db data/btc_trading.sqlite --mode recalc-from-deribit --reason "new_cycle"

# manual override
# python -m hedge_engine.cli.reset_hwm_cli --db data/btc_trading.sqlite --mode set --hwm-usd 110000 --reason "manual_override"

# only if you later store last_equity_usd in hedge_engine_state
# python -m hedge_engine.cli.reset_hwm_cli --db data/btc_trading.sqlite --mode set-to-current-db --reason "db_equity_reset"