# hedge_engine/cli/phase4_stress_deep_cli.py
from __future__ import annotations

import argparse
import json
import logging
import os
import sqlite3
from typing import Any, Dict, List, Optional, Tuple
from dotenv import load_dotenv # type: ignore
load_dotenv()

def _latest_tick_list(con: sqlite3.Connection, table: str) -> List[Dict[str, Any]]:
    """
    Reads latest payload_json from an engine tick table where payload_json is a JSON list.
    Table schema expected: (ts_utc TEXT, payload_json TEXT, ...)
    """
    row = con.execute(
        f"SELECT payload_json FROM {table} ORDER BY ts_utc DESC LIMIT 1"
    ).fetchone()
    if not row or not row[0]:
        return []
    try:
        out = json.loads(row[0])
        return out if isinstance(out, list) else []
    except Exception:
        return []


def _pick_worst_scenario(scenarios: Dict[str, Dict[str, Any]]) -> Tuple[str, float, float]:
    """
    Returns (name, projected_dd, projected_equity).
    Worst = most negative DD (or, if DD missing, smallest equity).
    """
    worst_name = ""
    worst_dd = 0.0
    worst_eq = float("inf")

    for name, s in scenarios.items():
        dd = s.get("projected_dd_worst", None)
        eq = float(s.get("projected_equity_usd", 0.0))

        if dd is None:
            # fallback: use equity only
            if eq < worst_eq:
                worst_name, worst_eq = name, eq
            continue

        dd = float(dd)
        if worst_name == "" or dd < worst_dd:
            worst_name, worst_dd, worst_eq = name, dd, eq

    # if DD never existed, keep dd=0.0 and return smallest equity scenario
    if worst_name == "" and scenarios:
        worst_name = sorted(scenarios.keys())[0]
        worst_eq = float(scenarios[worst_name].get("projected_equity_usd", 0.0))

    return worst_name, float(worst_dd), float(worst_eq)


def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument("--db-path", required=True)
    p.add_argument("--fetch-live", action="store_true", help="Fetch & persist latest ticks from Deribit first")
    p.add_argument("--out-dir", default="logs")
    p.add_argument("--max-debug-rows", type=int, default=50, help="How many option/linear debug rows to keep per scenario")
    args = p.parse_args()

    os.makedirs(args.out_dir, exist_ok=True)

    logger = logging.getLogger("phase4_stress_deep")
    logger.setLevel(logging.INFO)

    # --- imports here to avoid import cost when showing help ---
    from hedge_engine.data.state_store import open_sqlite, load_hwm_usd
    from hedge_engine.data.deribit_client import DeribitClient
    from hedge_engine.core.snapshot_builder import (
        fetch_and_persist_ticks_from_deribit,
        build_engine_inputs_from_engine_db,
        T_POS,
    )
    from hedge_engine.risk.stress.stress_deep import deep_reprice, default_deep_cfg

    con = open_sqlite(args.db_path)

    if args.fetch_live:
        d = DeribitClient.from_env()
        fetch_and_persist_ticks_from_deribit(deribit=d, con=con)

    # Engine inputs (equity/spot etc) + persistent state already handled inside builder
    snap = build_engine_inputs_from_engine_db(con=con, logger=logger)
    inp = snap.inputs

    # HWM explicitly (for DD in deep stress)
    hwm = load_hwm_usd(con=con)

    # Latest positions list (engine-owned table)
    positions = _latest_tick_list(con, T_POS)
    if not positions:
        raise SystemExit(f"[PHASE4-DEEP] No positions found in {T_POS}. Run snapshot fetch first.")

    cfg = default_deep_cfg()

    res = deep_reprice(
        positions=positions,
        equity_usd=inp.total_equity_usd,
        hwm_usd=hwm,
        spot_index_usd=inp.spot_index_usd,
        cfg=cfg,
    )

    # Trim debug rows to keep JSON reasonable (optional)
    max_rows = int(args.max_debug_rows)
    for sname, s in (res.get("scenarios") or {}).items():
        dbg = s.get("debug") or {}
        if isinstance(dbg.get("options_rows"), list):
            dbg["options_rows"] = dbg["options_rows"][:max_rows]
        if isinstance(dbg.get("linear_rows"), list):
            dbg["linear_rows"] = dbg["linear_rows"][:max_rows]
        s["debug"] = dbg

    ts = snap.inputs.updated_at_utc.strftime("%Y-%m-%dT%H%M%SZ")
    out_path = os.path.join(args.out_dir, f"stress_deep_{ts}.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(res, f, indent=2, ensure_ascii=False, default=str)

    # Console summary (worst scenario)
    worst_name, worst_dd, worst_eq = _pick_worst_scenario(res.get("scenarios") or {})
    override = bool(res.get("stress_override"))

    # Build compact scenario summary: S1_dd=-2.5% S1_eq=...
    parts = []
    for name in sorted((res.get("scenarios") or {}).keys()):
        s = res["scenarios"][name]
        dd = s.get("projected_dd_worst", None)
        eq = float(s.get("projected_equity_usd", 0.0))
        if dd is None:
            parts.append(f"{name}_eq={eq:.0f}")
        else:
            parts.append(f"{name}_dd={float(dd):.2%} {name}_eq={eq:.0f}")
    scenario_line = " | ".join(parts)

    print(
        f"[PHASE4-DEEP] spot={inp.spot_index_usd:.2f} equity={inp.total_equity_usd:.2f} "
        f"hwm={0.0 if hwm is None else float(hwm):.2f} | "
        f"{scenario_line} | "
        f"WORST={worst_name} dd={worst_dd:.2%} eq={worst_eq:.0f} | "
        f"override={override} out={out_path}"
    )

    return 0


if __name__ == "__main__":
    raise SystemExit(main())


# python -m hedge_engine.cli.phase4_stress_deep_cli --db-path data/btc_trading.sqlite --fetch-live