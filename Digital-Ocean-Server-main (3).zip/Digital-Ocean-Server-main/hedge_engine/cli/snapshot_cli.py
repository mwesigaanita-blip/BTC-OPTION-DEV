# hedge_engine/cli/snapshot_cli.py
from __future__ import annotations

import argparse
import json
import logging

from hedge_engine.data.state_store import open_sqlite
from hedge_engine.core.snapshot_builder import build_engine_inputs_from_engine_db


def _logger() -> logging.Logger:
    logger = logging.getLogger("hedge_engine")
    if not logger.handlers:
        h = logging.StreamHandler()
        fmt = logging.Formatter("%(asctime)s | %(levelname)s | %(name)s | %(message)s")
        h.setFormatter(fmt)
        logger.addHandler(h)
    logger.setLevel(logging.INFO)
    return logger


def main() -> int:
    ap = argparse.ArgumentParser(description="Hedge Engine - Snapshot Builder CLI")
    ap.add_argument("--db", required=True, help="Path to btc_trading.sqlite")
    args = ap.parse_args()

    logger = _logger()
    con = open_sqlite(args.db)
    try:
        res = build_engine_inputs_from_engine_db(con=con, logger=logger)
        print(json.dumps({"inputs": res.inputs.__dict__, "debug": res.debug}, default=str, indent=2))
        return 0
    finally:
        con.close()


if __name__ == "__main__":
    raise SystemExit(main())