# hedge_engine/cli/live_monitor_cli.py
from __future__ import annotations

import argparse
import json
import logging
import os
import time
from typing import Any

from hedge_engine.data.state_store import (
    open_sqlite,
    ensure_state_tables,
    insert_hedge_tick,
    load_mode_state,
    save_mode_state,
    utc_now_iso,
)
from hedge_engine.data.deribit_client import DeribitClient
from hedge_engine.core.snapshot_builder import (
    fetch_and_persist_ticks_from_deribit,
    build_engine_inputs_from_engine_db,
)
from hedge_engine.risk.risk_checks import (
    compute_flags,
    decide_desired_mode_from_flags,
    apply_mode_hysteresis,
)
from hedge_engine.risk.stress import compute_stress_artifact
from hedge_engine.settings.config import EngineConfig
from dotenv import load_dotenv  # type: ignore

load_dotenv()


# ============================================================
# ANSI colors
# ============================================================

RESET = "\033[0m"
BOLD = "\033[1m"
DIM = "\033[2m"

RED = "\033[31m"
GREEN = "\033[32m"
YELLOW = "\033[33m"
BLUE = "\033[34m"
MAGENTA = "\033[35m"
CYAN = "\033[36m"
WHITE = "\033[37m"

BRIGHT_RED = "\033[91m"
BRIGHT_GREEN = "\033[92m"
BRIGHT_YELLOW = "\033[93m"
BRIGHT_BLUE = "\033[94m"
BRIGHT_MAGENTA = "\033[95m"
BRIGHT_CYAN = "\033[96m"


# ============================================================
# Logging
# ============================================================

def _logger() -> logging.Logger:
    logger = logging.getLogger("hedge_engine_live")
    if not logger.handlers:
        h = logging.StreamHandler()
        fmt = logging.Formatter("%(asctime)s | %(levelname)-7s | %(message)s")
        h.setFormatter(fmt)
        logger.addHandler(h)
    logger.setLevel(logging.INFO)
    return logger


def _safe_json(obj: Any) -> str:
    try:
        return json.dumps(obj, default=lambda o: o.__dict__, ensure_ascii=False)
    except Exception:
        return json.dumps({"_error": "json_serialize_failed"}, ensure_ascii=False)


# ============================================================
# Pretty terminal helpers
# ============================================================

def _fmt_pct(x: float, digits: int = 2) -> str:
    return f"{x:.{digits}%}"


def _fmt_num(x: float, digits: int = 2) -> str:
    return f"{x:,.{digits}f}"


def _fmt_int(x: float) -> str:
    return f"{x:,.0f}"


def _line(width: int = 92, char: str = "─") -> str:
    return DIM + (char * width) + RESET


def _kv(label: str, value: str, width: int = 24) -> str:
    return f"{DIM}{label:<{width}}{RESET} {value}"


def _section(title: str) -> str:
    return f"{BOLD}{BRIGHT_CYAN}{title}{RESET}"


def _color_bool(v: bool, yes: str = "YES", no: str = "NO") -> str:
    return f"{BRIGHT_GREEN}{yes}{RESET}" if v else f"{DIM}{no}{RESET}"


def _status_icon_bool(v: bool) -> str:
    return f"{BRIGHT_GREEN}✅{RESET}" if v else f"{DIM}❌{RESET}"


def _mode_color(mode: str) -> str:
    m = (mode or "").upper()
    if m == "NORMAL":
        return BRIGHT_GREEN
    if m == "DEFENSIVE":
        return BRIGHT_YELLOW
    if m == "DANGER":
        return YELLOW
    if m == "EMERGENCY":
        return BRIGHT_RED
    return WHITE


def _mode_badge(mode: str) -> str:
    m = (mode or "").upper()
    color = _mode_color(m)
    if m == "NORMAL":
        icon = "🟢"
    elif m == "DEFENSIVE":
        icon = "🟡"
    elif m == "DANGER":
        icon = "🟠"
    elif m == "EMERGENCY":
        icon = "🔴"
    else:
        icon = "⚪"
    return f"{BOLD}{color}{icon} {m}{RESET}"


def _color_mm(mm: float) -> str:
    if mm >= 95:
        return f"{BOLD}{BRIGHT_RED}{mm:.2f}%{RESET}"
    if mm >= 90:
        return f"{YELLOW}{mm:.2f}%{RESET}"
    if mm >= 85:
        return f"{BRIGHT_YELLOW}{mm:.2f}%{RESET}"
    return f"{BRIGHT_GREEN}{mm:.2f}%{RESET}"


def _color_dd(dd: float) -> str:
    pct = _fmt_pct(dd, 2)
    if dd <= -0.10:
        return f"{BOLD}{BRIGHT_RED}{pct}{RESET}"
    if dd <= -0.06:
        return f"{YELLOW}{pct}{RESET}"
    if dd <= -0.02:
        return f"{BRIGHT_YELLOW}{pct}{RESET}"
    return f"{BRIGHT_GREEN}{pct}{RESET}"


def _color_signed_value(x: float, digits: int = 0) -> str:
    txt = f"{x:,.{digits}f}"
    if x < 0:
        return f"{BRIGHT_RED}{txt}{RESET}"
    if x > 0:
        return f"{BRIGHT_GREEN}{txt}{RESET}"
    return txt


def _color_gamma(x: float) -> str:
    txt = f"{x:.6f}"
    if x < 0:
        return f"{BRIGHT_RED}{txt}{RESET}"
    if x > 0:
        return f"{BRIGHT_GREEN}{txt}{RESET}"
    return txt

# 1) add this helper near _color_gamma()

def _color_delta(x: float) -> str:
    txt = f"{x:+.4f} BTC"
    if x < 0:
        return f"{BRIGHT_RED}{txt}{RESET}"
    if x > 0:
        return f"{BRIGHT_GREEN}{txt}{RESET}"
    return txt

def _extract_last_deep_ts(con) -> str | None:
    try:
        row = con.execute(
            "SELECT stress_json FROM hedge_ticks ORDER BY ts_utc DESC LIMIT 1"
        ).fetchone()
        if row and row[0]:
            prev = json.loads(row[0])
            if prev.get("deep"):
                return prev.get("ts_utc")
    except Exception:
        logging.warning("Failed to load last_deep_run_ts_utc from DB, defaulting to None")
    return None

def _min_projected_dd(stress_block: dict | None) -> float | None:
    if not isinstance(stress_block, dict):
        return None

    scenarios = stress_block.get("scenarios")
    if not isinstance(scenarios, dict):
        return None

    vals: list[float] = []
    for row in scenarios.values():
        if not isinstance(row, dict):
            continue
        dd = row.get("projected_dd")
        if dd is None:
            dd = row.get("projected_dd_worst")
        try:
            if dd is not None:
                vals.append(float(dd))
        except Exception:
            pass

    if not vals:
        return None
    return min(vals)


def _worst_scenario_name(stress_block: dict | None) -> str | None:
    if not isinstance(stress_block, dict):
        return None

    scenarios = stress_block.get("scenarios")
    if not isinstance(scenarios, dict):
        return None

    best_name = None
    best_dd = None

    for name, row in scenarios.items():
        if not isinstance(row, dict):
            continue
        dd = row.get("projected_dd")
        if dd is None:
            dd = row.get("projected_dd_worst")
        try:
            if dd is None:
                continue
            dd_f = float(dd)
        except Exception:
            continue

        if best_dd is None or dd_f < best_dd:
            best_dd = dd_f
            best_name = str(name)

    return best_name


def _fmt_pct_or_dash(x: float | None, digits: int = 2) -> str:
    if x is None:
        return "-"
    return f"{x:.{digits}%}"


def _color_projected_dd(x: float | None) -> str:
    if x is None:
        return f"{DIM}-{RESET}"
    txt = f"{x:.2%}"
    if x <= -0.10:
        return f"{BOLD}{BRIGHT_RED}{txt}{RESET}"
    if x <= -0.08:
        return f"{YELLOW}{txt}{RESET}"
    if x <= -0.04:
        return f"{BRIGHT_YELLOW}{txt}{RESET}"
    return f"{BRIGHT_GREEN}{txt}{RESET}"

def _print_live_header(args) -> None:
    print(_line())
    print(f"{BOLD}{BRIGHT_BLUE}BTC OPTIONS HEDGE ENGINE - LIVE MONITOR{RESET}")
    print(_line())
    print(_kv("DB", f"{WHITE}{args.db}{RESET}"))
    print(_kv("Sleep Seconds", f"{WHITE}{args.sleep_s}{RESET}"))
    print(_kv("Fetch Live", _color_bool(bool(args.fetch_live), yes="TRUE", no="FALSE")))
    print(_kv("Currency", f"{WHITE}{args.currency}{RESET}"))
    print(_kv("Max Iterations", f"{WHITE}{args.max_iterations or '∞'}{RESET}"))
    print(_line())


# 2) update _print_tick_block() signature

def _print_tick_block(
    *,
    i: int,
    ts_utc: str,
    spot: float,
    eq: float,
    hwm_usd: float,   # <-- add this
    dd: float,
    mm: float,
    final_mode: str,
    final_reason: str,
    H: float,
    delta_btc: float,
    vega: float,
    gamma: float,
    deep_ran: bool,
    override: bool,
    override_reasons: list[str],
    fast_min_dd: float | None,
    deep_min_dd: float | None,
    fast_worst_scenario: str | None,
    deep_worst_scenario: str | None,
    elapsed: float,
    flags: dict[str, Any],
    regime: str,
    hv30: float,
    iv30: float,
) -> None:
    vega_breach = bool(flags.get("vega_breach", False))
    gamma_breach = bool(flags.get("gamma_budget_breach", False) or flags.get("gamma_breach", False))
    speed_trigger = bool(flags.get("speed_trigger", False))

    dd_bucket = str(flags.get("dd_bucket", "-"))
    mm_state = str(flags.get("mm_state", "-"))

    print()
    print(_line())
    print(f"{BOLD}{WHITE}Tick #{i}{RESET}  {DIM}|{RESET}  {CYAN}{ts_utc}{RESET}")
    print(_line())

    print(_section("MARKET / ACCOUNT"))
    print(_kv("Spot Index USD", f"{WHITE}{_fmt_num(spot, 2)}{RESET}"))
    print(_kv("Equity USD", f"{WHITE}{_fmt_int(eq)}{RESET}"))
    print(_kv("HWM USD", f"{WHITE}{_fmt_int(hwm_usd)}{RESET}"))   # <-- add this
    print(_kv("Drawdown", _color_dd(dd)))
    print(_kv("MM %", _color_mm(mm)))

    print()
    print(_section("RISK / MODE"))
    print(_kv("Mode", _mode_badge(final_mode)))
    print(_kv("Reason", f"{WHITE}{final_reason or '-'}{RESET}"))
    print(_kv("DD Bucket", f"{WHITE}{dd_bucket}{RESET}"))
    print(_kv("MM State", f"{WHITE}{mm_state}{RESET}"))
    print(_kv("Target Hedge Ratio H", f"{BRIGHT_MAGENTA}{H:.2f}{RESET}"))

    # 3) in the GREEKS block, print delta first

    print()
    print(_section("GREEKS"))
    print(_kv("Account Net Delta BTC", _color_delta(delta_btc)))
    print(_kv("Vega", _color_signed_value(vega, 0)))
    print(_kv("Gamma", _color_gamma(gamma)))
    
    print()
    print(_section("VOL REGIME"))
    print(_kv("Regime", f"{BOLD}{BRIGHT_CYAN}{regime}{RESET}"))
    print(_kv("HV30", f"{WHITE}{hv30:.1%}{RESET}"))
    print(_kv("IV30", f"{WHITE}{iv30:.1%}{RESET}"))
    print(_kv("IV-HV Spread", f"{WHITE}{(iv30 - hv30):+.1%}{RESET}"))
    
    print()
    print(_section("TRIGGERS / STRESS"))
    print(_kv("Vega Breach", _status_icon_bool(vega_breach)))
    print(_kv("Gamma Breach", _status_icon_bool(gamma_breach)))
    print(_kv("Speed Trigger", _status_icon_bool(speed_trigger)))
    print(_kv("Deep Stress Ran", _status_icon_bool(deep_ran)))

    print(_kv(
        "Stress Override",
        f"{BOLD}{BRIGHT_RED}🚨 YES{RESET}" if override else f"{BRIGHT_GREEN}NO{RESET}"
    ))

    print(_kv(
        "Fast Worst Projected DD",
        f"{_color_projected_dd(fast_min_dd)}"
        + (f"  {DIM}({fast_worst_scenario}){RESET}" if fast_worst_scenario else "")
    ))

    print(_kv(
        "Deep Worst Projected DD",
        f"{_color_projected_dd(deep_min_dd)}"
        + (f"  {DIM}({deep_worst_scenario}){RESET}" if deep_worst_scenario else "")
    ))

    reasons_txt = ", ".join(override_reasons) if override_reasons else "-"
    print(_kv("Override Reasons", f"{WHITE}{reasons_txt}{RESET}"))

    print()
    print(_section("PERFORMANCE"))
    print(_kv("Loop Time", f"{WHITE}{elapsed:.2f}s{RESET}"))
    print(_line())


def main() -> int:
    ap = argparse.ArgumentParser(description="Hedge Engine - Live Monitor (Phases 1–4.4)")
    ap.add_argument("--db", required=True, help="Path to btc_trading.sqlite")
    ap.add_argument("--sleep-s", type=float, default=10.0, help="Loop interval seconds (default 10)")
    ap.add_argument("--fetch-live", action="store_true", help="Fetch & persist Deribit ticks each loop")
    ap.add_argument("--currency", type=str, default="BTC")
    ap.add_argument("--max-iterations", type=int, default=0, help="0 = infinite")
    ap.add_argument("--json-dump", action="store_true", help="Also write a JSON file per loop to logs/")
    args = ap.parse_args()

    os.makedirs("logs", exist_ok=True)
    logger = _logger()

    con = open_sqlite(args.db)
    ensure_state_tables(con)

    cfg = EngineConfig()
    deribit = DeribitClient.from_env() if args.fetch_live else None

    _print_live_header(args)

    i = 0
    try:
        while True:
            i += 1
            t0 = time.time()

            if deribit is not None:
                info = fetch_and_persist_ticks_from_deribit(
                    deribit=deribit,
                    con=con,
                    currency=args.currency,
                )
                logger.info(json.dumps({"event": "LIVE_FETCH", **info}, ensure_ascii=False))

            res = build_engine_inputs_from_engine_db(con=con, logger=logger)
            snapshot = res.inputs
            state = res.inputs
            # Warn if vol regime inputs are missing from DB
            if not getattr(snapshot, "hv_30d_pct", None):
                logger.warning("snapshot.hv_30d_pct is 0/None - vol regime data missing, defaulting to LOW")
            if not getattr(snapshot, "iv_atm_30d_pct", None):
                logger.warning("snapshot.iv_atm_30d_pct is 0/None - IV data missing, spread adjustment disabled")
            

            flags = compute_flags(snapshot=snapshot, state=state, cfg=cfg, con=con)

            mode_state = load_mode_state(con=con)
            desired_mode, desired_reason = decide_desired_mode_from_flags(flags.to_dict())
            final_mode, final_reason, new_safe_streak, changed = apply_mode_hysteresis(
                desired_mode=desired_mode,
                desired_reason=desired_reason,
                prior_mode_state=mode_state,
                safe_required_ticks=10,
            )
            mode_state["mode"] = final_mode
            mode_state["safe_streak"] = new_safe_streak
            mode_state["last_reason"] = final_reason
            if changed:
                mode_state["last_change_ts_utc"] = utc_now_iso()
            save_mode_state(con=con, mode_state=mode_state)

            last_deep_run_ts_utc = _extract_last_deep_ts(con)

            stress = compute_stress_artifact(
                snapshot=snapshot,
                state=state,
                flags=flags.to_dict(),
                cfg=cfg,
                last_deep_run_ts_utc=last_deep_run_ts_utc,
            )
            display_mode = final_mode
            display_reason = final_reason
            regime = str(stress.get("regime", "UNKNOWN"))   # ← add this
            hv30 = float(getattr(snapshot, "hv_30d_pct",     None) or 0.0) / 100.0
            iv30 = float(getattr(snapshot, "iv_atm_30d_pct", None) or 0.0) / 100.0
            if bool(stress.get("stress_override")):
                display_mode = "EMERGENCY"
                display_reason = f"{final_reason}|stress_override"
            snapshot_json = _safe_json(snapshot)
            flags_json = json.dumps(flags.to_dict(), ensure_ascii=False)
            stress_json = json.dumps(stress, ensure_ascii=False)

            insert_hedge_tick(
                con=con,
                ts_utc=stress["ts_utc"],
                snapshot_json=snapshot_json,
                flags_json=flags_json,
                stress_json=stress_json,
            )

            f = flags.to_dict()
            dd = float(f.get("dd_worst", None) or f.get("dd", 0.0))
            mm = float(f.get("mm_pct", 0.0))
            eq = float(f.get("equity_usd", 0.0))
            spot = float(f.get("spot_index_usd", 0.0))

            hwm_usd = float(getattr(snapshot, "hwm_usd", 0.0) or 0.0)   # <-- add this

            delta_btc = float(getattr(snapshot, "portfolio_delta_btc", 0.0) or 0.0)
            vega = float(getattr(snapshot, "portfolio_vega", 0.0) or f.get("vega", 0.0))
            gamma = float(getattr(snapshot, "portfolio_gamma", 0.0) or f.get("gamma", 0.0))
            H = float(f.get("target_hedge_ratio_H", 0.0))

            deep_ran = bool(stress.get("deep") is not None)
            override = bool(stress.get("stress_override"))

            override_reasons = list(stress.get("stress_override_reasons", []) or [])

            fast_block = stress.get("fast")
            deep_block = stress.get("deep")

            fast_min_dd = _min_projected_dd(fast_block)
            deep_min_dd = _min_projected_dd(deep_block)

            fast_worst_scenario = _worst_scenario_name(fast_block)
            deep_worst_scenario = _worst_scenario_name(deep_block)

            elapsed = time.time() - t0

            # 5) pass it into _print_tick_block()

            _print_tick_block(
                i=i,
                ts_utc=stress["ts_utc"],
                spot=spot,
                eq=eq,
                hwm_usd=hwm_usd,   # <-- add this
                dd=dd,
                mm=mm,
                final_mode=display_mode,
                final_reason=display_reason,
                H=H,
                delta_btc=delta_btc,
                vega=vega,
                gamma=gamma,
                deep_ran=deep_ran,
                override=override,
                override_reasons=override_reasons,
                fast_min_dd=fast_min_dd,
                deep_min_dd=deep_min_dd,
                fast_worst_scenario=fast_worst_scenario,
                deep_worst_scenario=deep_worst_scenario,
                regime=regime,
                hv30=hv30,
                iv30=iv30,
                elapsed=elapsed,
                flags=f,
            )
            
            if args.json_dump:
                out_path = f"logs/live_tick_{i}_{int(time.time())}.json"
                with open(out_path, "w", encoding="utf-8") as fp:
                    json.dump(
                        {
                            "inputs": res.inputs.__dict__,
                            "debug": res.debug,
                            "flags": f,
                            "mode_state": mode_state,
                            "stress": stress,
                        },
                        fp,
                        indent=2,
                        ensure_ascii=False,
                        default=str,
                    )
                logger.info(f"{BRIGHT_GREEN}JSON dump written:{RESET} {out_path}")

            if args.max_iterations and i >= args.max_iterations:
                print()
                print(_line())
                print(f"{BOLD}{BRIGHT_GREEN}LIVE MONITOR DONE ✅{RESET}")
                print(_line())
                return 0

            time.sleep(max(0.0, float(args.sleep_s)))

    finally:
        con.close()


if __name__ == "__main__":
    raise SystemExit(main())


# Example:
# python -m hedge_engine.cli.live_monitor_cli --db data/btc_trading.sqlite --fetch-live --sleep-s 5 --max-iterations 1