# hedge_engine/cli/phase3_flags_cli.py
from __future__ import annotations

import argparse
import json
import logging

from hedge_engine.data.state_store import open_sqlite
from hedge_engine.core.snapshot_builder import build_engine_inputs_from_engine_db
from hedge_engine.risk.risk_checks import compute_flags
from hedge_engine.risk.stress import compute_stress_artifact
from hedge_engine.settings.config import EngineConfig

def _logger() -> logging.Logger:
    logger = logging.getLogger("hedge_engine")
    if not logger.handlers:
        h = logging.StreamHandler()
        fmt = logging.Formatter("%(asctime)s | %(levelname)s | %(name)s | %(message)s")
        h.setFormatter(fmt)
        logger.addHandler(h)
    logger.setLevel(logging.INFO)
    return logger


def main() -> int:
    ap = argparse.ArgumentParser(description="Hedge Engine - Phase 3 Flags (one tick)")
    ap.add_argument("--db", required=True, help="Path to btc_trading.sqlite")
    args = ap.parse_args()

    logger = _logger()
    con = open_sqlite(args.db)
    try:
        # build_engine_inputs_from_engine_db should already give you snapshot + state (as you built in Phase2.3)
        res = build_engine_inputs_from_engine_db(con=con, logger=logger)

        # We assume:
        #   res.inputs.snapshot  (or similar)
        #   res.inputs.state
        # If your names differ, change these 2 lines only.
        inputs = getattr(res, "inputs", None)
        if inputs is None:
            raise RuntimeError("build_engine_inputs_from_engine_db() returned no .inputs")

        # build_engine_inputs_from_engine_db returns SnapshotBuildResult(inputs=EngineInputs, debug=dict)
        snapshot = res.inputs       # EngineInputs (this is what risk_checks expects here)
        state = res.inputs          # for now, state fields live inside EngineInputs (hwm_usd, dd)
        cfg = EngineConfig()         

        if snapshot is None:
            raise RuntimeError("inputs.snapshot is missing")
        if state is None:
            raise RuntimeError("inputs.state is missing")
        if cfg is None:
            raise RuntimeError("inputs.cfg is missing")

        flags = compute_flags(snapshot=snapshot, state=state, cfg=cfg, con=con)
        # ---------------------------------------------------
        # PHASE 4.4 - Unified stress artifact (fast always, deep conditional)
        # ---------------------------------------------------

        # read last deep run ts from most recent tick (if any)
        last_deep_run_ts_utc = None
        try:
            row = con.execute(
                "SELECT stress_json FROM hedge_ticks ORDER BY ts DESC LIMIT 1"
            ).fetchone()
            if row and row[0]:
                prev = json.loads(row[0])
                if prev.get("deep"):
                    last_deep_run_ts_utc = prev.get("ts_utc")
        except Exception:
            last_deep_run_ts_utc = None

        stress = compute_stress_artifact(
            snapshot=snapshot,
            state=state,
            flags=flags.to_dict() if hasattr(flags, "to_dict") else flags,
            cfg=cfg,
            last_deep_run_ts_utc=last_deep_run_ts_utc,
        )

        print("[STRESS_TRIGGER]")
        print(json.dumps(stress["deep_trigger"], indent=2))

        if stress.get("stress_override"):
            print("⚠ STRESS OVERRIDE TRIGGERED")
            print(stress.get("stress_override_reasons", []))        
            
        from hedge_engine.data.state_store import load_mode_state, save_mode_state, utc_now_iso , insert_hedge_tick
        from hedge_engine.risk.risk_checks import decide_desired_mode_from_flags, apply_mode_hysteresis

        mode_state = load_mode_state(con=con)

        desired_mode, desired_reason = decide_desired_mode_from_flags(flags.to_dict())
        final_mode, final_reason, new_safe_streak, changed = apply_mode_hysteresis(
            desired_mode=desired_mode,
            desired_reason=desired_reason,
            prior_mode_state=mode_state,
            safe_required_ticks=10,
        )

        mode_state["mode"] = final_mode
        mode_state["safe_streak"] = new_safe_streak
        mode_state["last_reason"] = final_reason
        if changed:
            mode_state["last_change_ts_utc"] = utc_now_iso()

        save_mode_state(con=con, mode_state=mode_state)

        # print for debugging
        print(f"[MODE] desired={desired_mode} final={final_mode} reason={final_reason} safe_streak={new_safe_streak}")
        
        print(json.dumps(flags.to_dict(), indent=2))
        # Persist this tick (snapshot/flags/stress) into hedge_ticks
        # NOTE: requires hedge_ticks table to have stress_json column already.
        try:
            snapshot_json = json.dumps(snapshot, default=lambda o: o.__dict__, ensure_ascii=False)
        except Exception:
            snapshot_json = json.dumps({"_error": "snapshot_json_serialize_failed"})

        flags_json = json.dumps(flags.to_dict() if hasattr(flags, "to_dict") else flags, ensure_ascii=False)
        stress_json = json.dumps(stress, ensure_ascii=False)

        insert_hedge_tick(
            con=con,
            ts_utc=stress["ts_utc"],
            snapshot_json=snapshot_json,
            flags_json=flags_json,
            stress_json=stress_json,
        )
        return 0
    finally:
        con.close()


if __name__ == "__main__":
    raise SystemExit(main())


# python -m hedge_engine.cli.phase3_flags_cli --db data/btc_trading.sqlite