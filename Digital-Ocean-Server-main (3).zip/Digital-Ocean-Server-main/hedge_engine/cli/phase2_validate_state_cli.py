# hedge_engine/cli/phase2_validate_state_cli.py
from __future__ import annotations

import argparse
import json
import logging
import os
import sqlite3
import time
from dataclasses import asdict

from hedge_engine.core.snapshot_builder import (
    build_engine_inputs_from_engine_db,
    fetch_and_persist_ticks_from_deribit,
)
from hedge_engine.data.deribit_client import DeribitClient
from hedge_engine.data.state_store import open_sqlite, ensure_state_tables


def _ensure_logs() -> None:
    os.makedirs("logs", exist_ok=True)


def _dump_json(path: str, payload) -> None:
    with open(path, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2, ensure_ascii=False, default=str)


def cmd_phase2_validate_state(
    *,
    db_path: str,
    iterations: int,
    sleep_s: float,
    fetch_live: bool,
    currency: str,
) -> None:
    """
    Phase2 validation loop:
      - (optional) fetch live Deribit data and persist into hedge_engine_* tables
      - build EngineInputs from hedge_engine_* tables
      - invariants: HWM monotonic, DD <= 0, DD ~0 when equity>=HWM
      - JSON dump per iteration
    """
    _ensure_logs()

    logger = logging.getLogger("phase2_validate")
    logger.setLevel(logging.INFO)

    con = open_sqlite(db_path)
    ensure_state_tables(con)

    from hedge_engine.data.state_store import load_hwm_usd
    persisted_hwm = load_hwm_usd(con=con) or 0.0

    deribit = DeribitClient.from_env() if fetch_live else None

    print(
        f"[Phase2.3] db={db_path} iterations={iterations} sleep_s={sleep_s} fetch_live={fetch_live} currency={currency}"
    )
    print(f"[Phase2.3] START persisted_prev_hwm_usd={persisted_hwm:.2f}")

    prev_hwm = persisted_hwm

    for i in range(iterations):
        ts = int(time.time())

        if fetch_live:
            info = fetch_and_persist_ticks_from_deribit(deribit=deribit, con=con, currency=currency)
            logger.info(json.dumps({"event": "PHASE2_FETCH_LIVE", **info}, ensure_ascii=False))

        res = build_engine_inputs_from_engine_db(con=con, logger=logger)
        inputs = res.inputs

        equity = float(inputs.total_equity_usd)
        hwm = float(inputs.hwm_usd)
        dd = float(inputs.dd)

        # invariants
        inv_hwm_non_decreasing = True
        if prev_hwm is not None:
            inv_hwm_non_decreasing = (hwm + 1e-9) >= prev_hwm

        inv_dd_le_0 = dd <= 1e-12

        inv_dd_zero_if_new_high = True
        if equity >= hwm - 1e-9:
            inv_dd_zero_if_new_high = abs(dd) <= 1e-9

        if not inv_hwm_non_decreasing:
            raise AssertionError(f"HWM decreased: prev={prev_hwm:.6f} now={hwm:.6f}")
        if not inv_dd_le_0:
            raise AssertionError(f"DD must be <= 0; got dd={dd}")
        if not inv_dd_zero_if_new_high:
            raise AssertionError(f"DD should be ~0 when equity>=HWM; equity={equity} hwm={hwm} dd={dd}")

        out = {
            "ts_utc_epoch": ts,
            "iteration": i,
            "inputs": asdict(inputs),
            "debug": res.debug,
            "invariants": {
                "hwm_non_decreasing": inv_hwm_non_decreasing,
                "dd_le_0": inv_dd_le_0,
                "dd_zero_if_equity_at_or_above_hwm": inv_dd_zero_if_new_high,
            },
        }

        out_path = f"logs/phase2_validate_tick_{ts}_{i}.json"
        _dump_json(out_path, out)

        print(f"[Phase2.3] i={i} equity_usd={equity:.2f} hwm_usd={hwm:.2f} dd={dd:.4%} -> {out_path}")

        prev_hwm = hwm

        if i < iterations - 1:
            time.sleep(max(0.0, float(sleep_s)))

    print("[Phase2.3] DONE ✅")


def _parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser()
    p.add_argument("--db-path", dest="db_path", default=None)
    p.add_argument("--iterations", type=int, default=20)
    p.add_argument("--sleep-s", type=float, default=5.0)
    p.add_argument("--fetch-live", action="store_true")
    p.add_argument("--currency", type=str, default="BTC")
    return p.parse_args()


if __name__ == "__main__":
    from multi_agent_system.config import DB_PATH

    args = _parse_args()
    dbp = args.db_path or DB_PATH

    cmd_phase2_validate_state(
        db_path=dbp,
        iterations=args.iterations,
        sleep_s=args.sleep_s,
        fetch_live=bool(args.fetch_live),
        currency=args.currency,
    )
    
    
# python -m hedge_engine.cli.phase2_validate_state_cli --fetch-live

# python -m hedge_engine.cli.phase2_validate_state_cli --fetch-live --iterations 10 --sleep-s 1