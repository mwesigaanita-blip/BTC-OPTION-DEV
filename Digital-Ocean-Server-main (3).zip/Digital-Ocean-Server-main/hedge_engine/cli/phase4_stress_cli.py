# hedge_engine/cli/phase4_stress_cli.py
from __future__ import annotations

import argparse
import json
import logging
import os

from hedge_engine.data.state_store import open_sqlite, load_hwm_usd
from hedge_engine.data.deribit_client import DeribitClient
from hedge_engine.core.snapshot_builder import (
    fetch_and_persist_ticks_from_deribit,
    build_engine_inputs_from_engine_db,
)
from hedge_engine.risk.stress.stress_fast import run_stress_fast, to_json_dict
from dotenv import load_dotenv
load_dotenv()

def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument("--db-path", required=True)
    p.add_argument("--fetch-live", action="store_true", help="Fetch & persist latest ticks from Deribit first")
    p.add_argument("--out-dir", default="logs")
    args = p.parse_args()

    os.makedirs(args.out_dir, exist_ok=True)

    logger = logging.getLogger("phase4_stress")
    logger.setLevel(logging.INFO)

    con = open_sqlite(args.db_path)

    if args.fetch_live:
        d = DeribitClient.from_env()
        fetch_and_persist_ticks_from_deribit(deribit=d, con=con)

    snap = build_engine_inputs_from_engine_db(con=con, logger=logger)
    inp = snap.inputs

    # HWM from state store (Phase 2)
    hwm = load_hwm_usd(con=con)

    res = run_stress_fast(
        equity_usd=inp.total_equity_usd,
        hwm_usd=hwm,
        spot_index_usd=inp.spot_index_usd,
        delta_btc=inp.portfolio_delta_btc,
        gamma=inp.portfolio_gamma,
        vega_usd_per_vol=inp.portfolio_vega,
    )

    out_path = os.path.join(args.out_dir, f"stress_fast_{res.ts_utc.replace(':','').replace('-','')}.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(to_json_dict(res), f, indent=2, ensure_ascii=False, default=str)

    # short console line (dynamic for all scenarios)
    scenario_parts = []

    for name, s in res.scenarios.items():
        eq = s["projected_equity_usd"]
        dd = s["projected_dd_worst"]
        scenario_parts.append(
            f"{name}_eq={eq:.0f} {name}_dd={dd:.2%}"
        )

    scenario_summary = " | ".join(scenario_parts)

    print(
        f"[PHASE4] spot={inp.spot_index_usd:.2f} "
        f"equity={inp.total_equity_usd:.2f} | "
        f"{scenario_summary} | "
        f"override={res.stress_override} "
        f"out={out_path}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())


# python -m hedge_engine.cli.phase4_stress_cli --db-path data/btc_trading.sqlite --fetch-live