# hedge_engine/ml/regime_detector.py
"""
Phase 8: Market Regime Detector using a Hidden Markov Model (HMM).

States  : Bull | Bear | Sideways | Stress
Features: hv30, iv30, iv_minus_hv, spot_move_24h, funding_rate

Lifecycle
---------
1. Data collection starts from day 1 via log_regime_tick().
   The regime_label column is seeded with the deterministic classifier
   result (normal / high / panic) until the HMM model is trained.

2. After 30+ days (≥ min_rows ticks), call train(con) once to fit the HMM.
   The trained model + scaler + state-labels are saved to ml/models/regime_hmm.pkl.

3. predict(con) returns the HMM-inferred label for the latest tick.
   Returns None when the model file does not exist yet.
   runner.py falls back to the deterministic regime classifier in that case.
"""
from __future__ import annotations

import logging
import os
import sqlite3
from typing import Dict, Optional

import numpy as np

logger = logging.getLogger(__name__)

_MODELS_DIR = os.path.join(os.path.dirname(__file__), "models")
_MODEL_PATH = os.path.join(_MODELS_DIR, "regime_hmm.pkl")

# Feature column order - must match INSERT in log_regime_tick
FEATURE_COLS = ["hv30", "iv30", "iv_minus_hv", "spot_move_24h", "funding_rate"]


# ─── Data collection ──────────────────────────────────────────────────────────

def log_regime_tick(
    con: sqlite3.Connection,
    ts: str,
    hv30: float,
    iv30: float,
    iv_minus_hv: float,
    spot_move_24h: float,
    funding_rate: float,
    regime_label: str,
) -> None:
    """Persist one regime observation to ml_regime_ticks."""
    con.execute(
        """INSERT INTO ml_regime_ticks
           (ts_utc, hv30, iv30, iv_minus_hv, spot_move_24h, funding_rate, regime_label)
           VALUES (?, ?, ?, ?, ?, ?, ?)""",
        (ts, hv30, iv30, iv_minus_hv, spot_move_24h, funding_rate, regime_label),
    )
    con.commit()


# ─── Internal helpers ─────────────────────────────────────────────────────────

def _load_features(con: sqlite3.Connection) -> np.ndarray:
    """Return all regime tick rows ordered by time, shape (N, 5)."""
    rows = con.execute(
        "SELECT hv30, iv30, iv_minus_hv, spot_move_24h, funding_rate "
        "FROM ml_regime_ticks ORDER BY ts_utc ASC"
    ).fetchall()
    if not rows:
        return np.empty((0, 5))
    return np.array(rows, dtype=float)


def _assign_state_labels(means: np.ndarray) -> Dict[int, str]:
    """
    Assign human-readable labels to HMM states from their feature means.

    Feature index map:
      0 = hv30  |  1 = iv30  |  2 = iv_minus_hv  |  3 = spot_move_24h  |  4 = funding_rate

    Rules (deterministic after training):
      Stress   = state with highest IV30 mean
      Bull     = highest spot_move_24h mean (among non-Stress)
      Bear     = lowest  spot_move_24h mean (among non-Stress, non-Bull)
      Sideways = remainder
    """
    n = len(means)
    labels: Dict[int, str] = {}

    # Stress = highest IV
    stress = int(np.argmax(means[:, 1]))
    labels[stress] = "Stress"

    remaining = [i for i in range(n) if i != stress]

    if len(remaining) >= 2:
        bull = max(remaining, key=lambda i: means[i, 3])
        labels[bull] = "Bull"
        remaining.remove(bull)

        bear = min(remaining, key=lambda i: means[i, 3])
        labels[bear] = "Bear"
        remaining.remove(bear)

        for i in remaining:
            labels[i] = "Sideways"

    elif len(remaining) == 1:
        labels[remaining[0]] = "Sideways"

    return labels


# ─── Training ─────────────────────────────────────────────────────────────────

def train(con: sqlite3.Connection, min_rows: int = 500) -> bool:
    """
    Fit a GaussianHMM(n_components=4) on collected ml_regime_ticks data.

    Returns True  - training succeeded; model saved to ml/models/regime_hmm.pkl.
    Returns False - insufficient data (< min_rows rows).

    Typical call (run manually after 30+ days of live data):
        from hedge_engine.data.state_store import open_sqlite
        from hedge_engine.ml.regime_detector import train
        con = open_sqlite("/path/to/btc_trading.sqlite")
        ok = train(con, min_rows=500)
        print("Trained:", ok)
    """
    try:
        from hmmlearn import hmm
        from sklearn.preprocessing import StandardScaler
        import joblib
    except ImportError as exc:
        logger.error("Missing dependency for regime HMM training: %s", exc)
        return False

    X_raw = _load_features(con)
    if len(X_raw) < min_rows:
        logger.warning(
            "Regime HMM: insufficient data - %d rows collected, need ≥ %d. "
            "Keep the engine running and retry after 30+ days.",
            len(X_raw), min_rows,
        )
        return False

    # Standardise: zero-mean, unit-variance per feature
    scaler = StandardScaler()
    X = scaler.fit_transform(X_raw)

    model = hmm.GaussianHMM(
        n_components=4,
        covariance_type="full",
        n_iter=100,
        random_state=42,
        verbose=False,
    )
    model.fit(X)

    labels = _assign_state_labels(model.means_)

    os.makedirs(_MODELS_DIR, exist_ok=True)
    joblib.dump(
        {"model": model, "scaler": scaler, "labels": labels},
        _MODEL_PATH,
    )

    logger.info(
        "Regime HMM trained on %d ticks. State labels: %s. Saved → %s",
        len(X_raw), labels, _MODEL_PATH,
    )
    return True


# ─── Prediction ───────────────────────────────────────────────────────────────

def predict(con: sqlite3.Connection) -> Optional[str]:
    """
    Predict the market regime for the most recent tick using the trained HMM.

    Returns regime label string ("Bull" | "Bear" | "Sideways" | "Stress")
    or None if the model has not been trained yet.

    caller (runner.py) falls back to the deterministic regime_rules classifier
    when this returns None.
    """
    if not os.path.exists(_MODEL_PATH):
        return None

    try:
        import joblib
    except ImportError:
        return None

    row = con.execute(
        "SELECT hv30, iv30, iv_minus_hv, spot_move_24h, funding_rate "
        "FROM ml_regime_ticks ORDER BY ts_utc DESC LIMIT 1"
    ).fetchone()
    if not row:
        return None

    try:
        saved = joblib.load(_MODEL_PATH)
        model = saved["model"]
        scaler = saved["scaler"]
        labels = saved["labels"]

        X = np.array([[*row]], dtype=float)
        X_scaled = scaler.transform(X)
        state = int(model.predict(X_scaled)[0])
        return labels.get(state, f"State_{state}")

    except Exception as exc:
        logger.warning("Regime HMM prediction failed: %s", exc)
        return None
