# hedge_engine/ml/vol_forecast.py
from __future__ import annotations
import sqlite3
from typing import Optional


def log_vol_tick(
    con: sqlite3.Connection,
    ts: str,
    hv30: float,
    iv30: float,
    btc_price: float,
) -> None:
    con.execute(
        """INSERT INTO ml_vol_ticks (ts_utc, hv30, iv30, btc_price)
           VALUES (?, ?, ?, ?)""",
        (ts, hv30, iv30, btc_price),
    )
    con.commit()


def train_garch() -> None:
    pass  # Phase 9 - GARCH(1,1) after 60+ days of data


def predict_vol(horizon: int = 7) -> Optional[float]:
    return None  # Phase 9


def vol_signal(forecast: float, iv30: float) -> str:
    return "neutral"  # Phase 9
