# hedge_engine/tests/test_bundle_acceptance.py
"""Phase 2: Test hard bundle acceptance gates."""
from __future__ import annotations

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

from hedge_engine.risk.xpm.bundle_acceptance import evaluate_bundle_acceptance
from hedge_engine.tests.conftest import make_config, make_flags, make_before_dict, make_after_dict


def test_kill_switch_rejects_catastrophic_stress():
    """Stress DD after <= -10% must be rejected."""
    cfg = make_config()
    flags = make_flags()
    before = make_before_dict(stress_dd=-0.08)
    after = make_after_dict(stress_dd_after=-0.105)  # worse than -10%

    result = evaluate_bundle_acceptance(
        before=before, after=after, mode_reasons="dd>=6%",
        flags=flags, cfg=cfg,
    )
    assert not result.accepted
    assert any("killswitch" in r for r in result.rejection_reasons)


def test_kill_switch_passes_when_above_threshold():
    """Stress DD after = -9% should pass the kill-switch gate."""
    cfg = make_config()
    flags = make_flags()
    before = make_before_dict(stress_dd=-0.08)
    after = make_after_dict(stress_dd_after=-0.05)  # improved to -5%

    result = evaluate_bundle_acceptance(
        before=before, after=after, mode_reasons="dd>=4.8%",
        flags=flags, cfg=cfg,
    )
    assert result.accepted


def test_simulation_unavailable_rejects():
    """sim_ok=False must always reject."""
    cfg = make_config()
    flags = make_flags()
    before = make_before_dict()
    after = make_after_dict(sim_ok=False)

    result = evaluate_bundle_acceptance(
        before=before, after=after, mode_reasons="dd>=4.8%",
        flags=flags, cfg=cfg,
    )
    assert not result.accepted
    assert "simulation_unavailable" in result.rejection_reasons


def test_material_improvement_required():
    """Stress DD must improve by at least 0.5pp."""
    cfg = make_config()
    flags = make_flags()
    before = make_before_dict(stress_dd=-0.05)
    # Only 0.1pp improvement (need 0.5pp)
    after = make_after_dict(stress_dd_after=-0.049)

    result = evaluate_bundle_acceptance(
        before=before, after=after, mode_reasons="dd>=4.8%",
        flags=flags, cfg=cfg,
    )
    assert not result.accepted
    assert any("insufficient improvement" in r for r in result.rejection_reasons)


def test_mm_stressed_must_improve():
    """If MM >= warning (70%), MM must not stay the same or worsen."""
    cfg = make_config()
    flags = make_flags(mm_pct=75.0)
    before = make_before_dict(mm_pct=75.0, stress_dd=-0.06)
    after = make_after_dict(mm_pct_after=76.0, stress_dd_after=-0.04)

    result = evaluate_bundle_acceptance(
        before=before, after=after, mode_reasons="mm>=75",
        flags=flags, cfg=cfg,
    )
    assert not result.accepted
    assert any("mm_stressed_no_improve" in r for r in result.rejection_reasons)


def test_mm_dangerous_zone_rejects():
    """MM after > 90% must reject."""
    cfg = make_config()
    flags = make_flags()
    before = make_before_dict(stress_dd=-0.06)
    after = make_after_dict(mm_pct_after=92.0, stress_dd_after=-0.04)

    result = evaluate_bundle_acceptance(
        before=before, after=after, mode_reasons="dd>=4.8%",
        flags=flags, cfg=cfg,
    )
    assert not result.accepted
    assert any("dangerous" in r for r in result.rejection_reasons)


def test_mm_worsen_tolerance():
    """MM worsening by >5pp must reject."""
    cfg = make_config()
    flags = make_flags()
    before = make_before_dict(mm_pct=60.0, stress_dd=-0.06)
    after = make_after_dict(mm_pct_after=66.0, stress_dd_after=-0.04)

    result = evaluate_bundle_acceptance(
        before=before, after=after, mode_reasons="dd>=4.8%",
        flags=flags, cfg=cfg,
    )
    assert not result.accepted
    assert any("5pp" in r for r in result.rejection_reasons)


def test_full_acceptance_with_good_bundle():
    """A bundle that materially improves everything should pass."""
    cfg = make_config()
    flags = make_flags(vega_breach=False, gamma_budget_breach=False)
    before = make_before_dict(stress_dd=-0.06, mm_pct=72.0)
    after = make_after_dict(
        stress_dd_after=-0.03,  # 3pp improvement
        mm_pct_after=65.0,      # improved
        delta_after=1.0,         # reduced from 3.5
        vega_after=-2000.0,
    )

    result = evaluate_bundle_acceptance(
        before=before, after=after, mode_reasons="dd>=4.8%",
        flags=flags, cfg=cfg,
    )
    assert result.accepted
    assert len(result.rejection_reasons) == 0
    assert "stress_dd_before" in result.metrics


def test_metrics_populated():
    """AcceptanceResult must contain structured metrics."""
    cfg = make_config()
    flags = make_flags()
    before = make_before_dict()
    after = make_after_dict(stress_dd_after=-0.03)

    result = evaluate_bundle_acceptance(
        before=before, after=after, mode_reasons="dd>=4.8%",
        flags=flags, cfg=cfg,
    )
    assert "stress_dd_before" in result.metrics
    assert "stress_dd_after" in result.metrics
    assert "mm_before" in result.metrics
    assert "mm_after" in result.metrics


if __name__ == "__main__":
    for name, func in list(globals().items()):
        if name.startswith("test_") and callable(func):
            try:
                func()
                print(f"  PASS  {name}")
            except AssertionError as e:
                print(f"  FAIL  {name}: {e}")
            except Exception as e:
                print(f"  ERROR {name}: {e}")
