# hedge_engine/tests/conftest.py
"""Shared test fixtures for deterministic hedge engine tests."""
from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from hedge_engine.core.models import Position, PortfolioSnapshot
from hedge_engine.risk.risk_checks import RiskFlags
from hedge_engine.settings.config import EngineConfig


def make_config(**overrides: Any) -> EngineConfig:
    """Build EngineConfig with overrides. Frozen dataclass workaround."""
    defaults = {}
    defaults.update(overrides)
    return EngineConfig(**defaults)


def make_snapshot(**overrides: Any) -> PortfolioSnapshot:
    """Build a PortfolioSnapshot with sensible defaults."""
    defaults = dict(
        total_equity_usd=100_000.0,
        hwm_usd=105_000.0,
        dd=-0.0476,  # ~-4.76%
        mm_pct=72.0,
        spot_index_usd=85_000.0,
        portfolio_delta_btc=3.5,
        portfolio_gamma=-0.0003,
        portfolio_vega=-2500.0,
        hv_30d_pct=42.0,
        iv_atm_30d_pct=48.0,
        iv_minus_hv_30d_pp=6.0,
        updated_at_utc=datetime.now(timezone.utc),
        positions=[],
        stress_artifact=None,
        mode="DANGER",
        equity_usd=100_000.0,
    )
    defaults.update(overrides)
    return PortfolioSnapshot(**defaults)


def make_flags(**overrides: Any) -> RiskFlags:
    """Build RiskFlags with sensible defaults."""
    defaults = dict(
        ts_utc=datetime.now(timezone.utc),
        equity_usd=100_000.0,
        spot_index_usd=85_000.0,
        dd_worst=-0.0476,
        dd_bucket="4-6",
        dd_abs_pct=4.76,
        mm_pct=72.0,
        mm_state="warning",
        vega=-2500.0,
        vega_limit_usd=500.0,
        vega_breach=True,
        gamma=-0.0003,
        gamma_loss_est_usd=800.0,
        gamma_budget_usd=1000.0,
        gamma_budget_breach=False,
        ret_30m_pct=0.01,
        ret_24h_pct=0.02,
        speed_trigger=False,
        is_high_vol_regime=False,
        target_hedge_ratio_H=0.75,
        target_hedge_reason="dd_4_6",
    )
    defaults.update(overrides)
    return RiskFlags(**defaults)


def make_positions(specs: Optional[List[Dict[str, Any]]] = None) -> List[Position]:
    """Build Position list from compact spec dicts."""
    if specs is None:
        specs = [
            {"instrument_name": "BTC-27JUN25-90000-P", "kind": "option", "size": -10,
             "net_delta": -0.3, "gamma": -0.0002, "vega": -800, "theta": 50,
             "option_type": "P", "strike": 90000, "dte_days": 5, "mark_price_usd": 1200,
             "mark_price_btc": 0.014, "index_price": 85000, "delta": -0.30},
            {"instrument_name": "BTC-27JUN25-80000-P", "kind": "option", "size": -5,
             "net_delta": -0.15, "gamma": -0.0001, "vega": -500, "theta": 30,
             "option_type": "P", "strike": 80000, "dte_days": 20, "mark_price_usd": 800,
             "mark_price_btc": 0.0094, "index_price": 85000, "delta": -0.15},
        ]
    positions = []
    for s in specs:
        positions.append(Position(**s))
    return positions


def make_before_dict(**overrides: Any) -> Dict[str, Any]:
    """Build a before_dict for acceptance testing."""
    defaults = {
        "mm_pct": 72.0,
        "stress_dd": -0.06,
        "delta": 3.5,
        "gamma": -0.0003,
        "vega": -2500.0,
    }
    defaults.update(overrides)
    return defaults


def make_after_dict(**overrides: Any) -> Dict[str, Any]:
    """Build an after_sim dict for acceptance testing."""
    defaults = {
        "sim_ok": True,
        "mm_pct_after": 65.0,
        "stress_dd_after": -0.04,
        "delta_after": 1.0,
        "gamma_after": -0.0002,
        "vega_after": -2000.0,
    }
    defaults.update(overrides)
    return defaults
