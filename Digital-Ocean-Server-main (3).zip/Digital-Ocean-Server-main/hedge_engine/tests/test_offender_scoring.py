# hedge_engine/tests/test_offender_scoring.py
"""Phase 6: Test composite offender scoring."""
from __future__ import annotations

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

from hedge_engine.actions.position_management.risk_reduction import (
    rank_position_offenders,
    OffenderScore,
)
from hedge_engine.tests.conftest import make_config, make_flags, make_snapshot, make_positions


def test_short_dte_ranks_higher():
    """Position with lower DTE should score higher than one with higher DTE."""
    positions = make_positions([
        {"instrument_name": "SHORT_3DTE", "kind": "option", "size": -10,
         "net_delta": -0.3, "gamma": -0.0002, "vega": -800, "theta": 50,
         "option_type": "P", "strike": 90000, "dte_days": 3, "mark_price_usd": 1200,
         "mark_price_btc": 0.014, "index_price": 85000, "delta": -0.30},
        {"instrument_name": "SHORT_25DTE", "kind": "option", "size": -10,
         "net_delta": -0.3, "gamma": -0.0002, "vega": -800, "theta": 50,
         "option_type": "P", "strike": 80000, "dte_days": 25, "mark_price_usd": 1200,
         "mark_price_btc": 0.014, "index_price": 85000, "delta": -0.30},
    ])
    snapshot = make_snapshot(positions=positions)
    flags = make_flags()
    cfg = make_config()

    scores = rank_position_offenders(positions, snapshot, flags, cfg)
    assert len(scores) == 2
    assert scores[0].instrument_name == "SHORT_3DTE"
    assert scores[0].total_score > scores[1].total_score


def test_high_gamma_ranks_higher():
    """Position with higher abs(gamma) should score higher (same DTE)."""
    positions = make_positions([
        {"instrument_name": "HIGH_GAMMA", "kind": "option", "size": -10,
         "net_delta": -0.3, "gamma": -0.001, "vega": -800, "theta": 50,
         "option_type": "P", "strike": 90000, "dte_days": 15, "mark_price_usd": 1200,
         "mark_price_btc": 0.014, "index_price": 85000, "delta": -0.30},
        {"instrument_name": "LOW_GAMMA", "kind": "option", "size": -10,
         "net_delta": -0.3, "gamma": -0.00001, "vega": -800, "theta": 50,
         "option_type": "P", "strike": 80000, "dte_days": 15, "mark_price_usd": 1200,
         "mark_price_btc": 0.014, "index_price": 85000, "delta": -0.30},
    ])
    snapshot = make_snapshot(positions=positions)
    flags = make_flags()
    cfg = make_config()

    scores = rank_position_offenders(positions, snapshot, flags, cfg)
    assert scores[0].instrument_name == "HIGH_GAMMA"


def test_only_short_options_scored():
    """Long positions and non-options should be excluded."""
    positions = make_positions([
        {"instrument_name": "LONG_OPT", "kind": "option", "size": 5,
         "net_delta": 0.3, "gamma": 0.0002, "vega": 800, "theta": -50,
         "option_type": "C", "strike": 90000, "dte_days": 15, "mark_price_usd": 1200,
         "mark_price_btc": 0.014, "index_price": 85000, "delta": 0.30},
        {"instrument_name": "BTC-PERPETUAL", "kind": "perpetual", "size": -2.5,
         "net_delta": -2.5, "gamma": 0, "vega": 0, "theta": 0,
         "option_type": None, "strike": None, "dte_days": None, "mark_price_usd": 85000,
         "mark_price_btc": 1.0, "index_price": 85000, "delta": -1.0},
    ])
    snapshot = make_snapshot(positions=positions)
    flags = make_flags()
    cfg = make_config()

    scores = rank_position_offenders(positions, snapshot, flags, cfg)
    assert len(scores) == 0  # no short options


def test_components_populated():
    """Each OffenderScore should have all 5 component values."""
    positions = make_positions()
    snapshot = make_snapshot(positions=positions)
    flags = make_flags()
    cfg = make_config()

    scores = rank_position_offenders(positions, snapshot, flags, cfg)
    assert len(scores) > 0
    for s in scores:
        assert "dte" in s.components
        assert "gamma" in s.components
        assert "vega" in s.components
        assert "margin" in s.components
        assert "stress" in s.components


def test_weights_sum_to_one():
    """Config weights should sum to 1.0."""
    cfg = make_config()
    total = (
        cfg.OFFENDER_WEIGHT_DTE
        + cfg.OFFENDER_WEIGHT_GAMMA
        + cfg.OFFENDER_WEIGHT_VEGA
        + cfg.OFFENDER_WEIGHT_MARGIN
        + cfg.OFFENDER_WEIGHT_STRESS
    )
    assert abs(total - 1.0) < 1e-9


if __name__ == "__main__":
    for name, func in list(globals().items()):
        if name.startswith("test_") and callable(func):
            try:
                func()
                print(f"  PASS  {name}")
            except AssertionError as e:
                print(f"  FAIL  {name}: {e}")
            except Exception as e:
                print(f"  ERROR {name}: {e}")
