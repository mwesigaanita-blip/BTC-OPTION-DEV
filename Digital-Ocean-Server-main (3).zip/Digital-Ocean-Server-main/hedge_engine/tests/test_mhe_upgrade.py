# hedge_engine/tests/test_mhe_upgrade.py
"""Tests for MHE upgrade: mode classification, delta band-edge, vega effectiveness,
gamma forward-risk, instrument scorer threshold, combined post-state, and formatter."""
from __future__ import annotations

import pytest
from datetime import datetime, timezone

from hedge_engine.tests.conftest import make_config, make_flags, make_snapshot, make_positions
from hedge_engine.risk.risk_checks import (
    decide_desired_mode_from_flags,
    compute_target_hedge_ratio_H,
    vega_breach_check,
)
from hedge_engine.core.models import GreekProfile, GreekTargets, Suggestion, HedgeTick
from hedge_engine.core.enums import ActionClassification
from hedge_engine.actions.instrument_scorer import score_instrument
from hedge_engine.notifications.formatter import format_hedge_tick, _fmt_suggestion_block


# -----------------------------------------------------------------------
# Phase 2: Mode classification - MM primary, Greek breaches boost H only
# -----------------------------------------------------------------------

class TestModeClassification:
    def test_mm_warning_with_vega_breach_is_defensive(self):
        """MM 72% (warning) + vega_breach → DEFENSIVE, not DANGER."""
        flags = {
            "mm_state": "warning",
            "dd_abs_pct": 1.5,
            "vega_breach": True,
            "gamma_budget_breach": False,
            "speed_trigger": False,
            "is_high_vol_regime": False,
        }
        mode, reason = decide_desired_mode_from_flags(flags)
        assert mode == "DEFENSIVE"
        assert "vega_breach(H+1)" in reason

    def test_mm_normal_with_vega_breach_stays_normal(self):
        """MM < 70% (normal), DD < 2%, vega_breach → NORMAL."""
        flags = {
            "mm_state": "normal",
            "dd_abs_pct": 0.5,
            "vega_breach": True,
            "gamma_budget_breach": False,
            "speed_trigger": False,
            "is_high_vol_regime": False,
        }
        mode, reason = decide_desired_mode_from_flags(flags)
        assert mode == "NORMAL"
        assert "vega_breach(H+1)" in reason

    def test_mm_critical_is_danger(self):
        """MM >= 80% → DANGER regardless of Greek breaches."""
        flags = {
            "mm_state": "critical",
            "dd_abs_pct": 3.0,
            "vega_breach": False,
            "gamma_budget_breach": False,
            "speed_trigger": False,
            "is_high_vol_regime": False,
        }
        mode, reason = decide_desired_mode_from_flags(flags)
        assert mode == "DANGER"
        assert "mm>=80" in reason

    def test_mm_dangerous_is_emergency(self):
        """MM >= 90% → EMERGENCY."""
        flags = {
            "mm_state": "dangerous",
            "dd_abs_pct": 2.0,
            "vega_breach": True,
            "gamma_budget_breach": True,
            "speed_trigger": True,
            "is_high_vol_regime": True,
        }
        mode, reason = decide_desired_mode_from_flags(flags)
        assert mode == "EMERGENCY"

    def test_dd_8pct_is_emergency(self):
        """DD >= 8% → EMERGENCY."""
        flags = {
            "mm_state": "normal",
            "dd_abs_pct": 8.5,
            "vega_breach": False,
            "gamma_budget_breach": False,
            "speed_trigger": False,
            "is_high_vol_regime": False,
        }
        mode, _ = decide_desired_mode_from_flags(flags)
        assert mode == "EMERGENCY"

    def test_all_safe_is_normal(self):
        flags = {
            "mm_state": "normal",
            "dd_abs_pct": 0.5,
            "vega_breach": False,
            "gamma_budget_breach": False,
            "speed_trigger": False,
            "is_high_vol_regime": False,
        }
        mode, reason = decide_desired_mode_from_flags(flags)
        assert mode == "NORMAL"
        assert reason == "all_safe"


class TestHedgeRatioGreekBoost:
    def test_vega_breach_boosts_H(self):
        """vega_breach should boost H by 1 ladder step."""
        cfg = make_config()
        H_without = compute_target_hedge_ratio_H(
            dd_worst=-0.01, mm_state="normal", speed_trigger=False, cfg=cfg,
            vega_breach=False, gamma_breach=False,
        )
        H_with = compute_target_hedge_ratio_H(
            dd_worst=-0.01, mm_state="normal", speed_trigger=False, cfg=cfg,
            vega_breach=True, gamma_breach=False,
        )
        assert H_with > H_without

    def test_both_greek_breaches_boost_H_twice(self):
        """vega + gamma breach should boost H by 2 steps."""
        cfg = make_config()
        H_base = compute_target_hedge_ratio_H(
            dd_worst=-0.01, mm_state="normal", speed_trigger=False, cfg=cfg,
        )
        H_both = compute_target_hedge_ratio_H(
            dd_worst=-0.01, mm_state="normal", speed_trigger=False, cfg=cfg,
            vega_breach=True, gamma_breach=True,
        )
        assert H_both > H_base


# -----------------------------------------------------------------------
# Phase 3: Delta engine - band edge targeting
# -----------------------------------------------------------------------

class TestDeltaBandEdge:
    def test_targets_band_max_when_delta_positive(self):
        """When residual delta > band_max, target should be band_max (not center)."""
        # Simulate the sizing logic directly
        residual_delta = 1.5
        band_min, band_max = -0.30, 0.30

        if residual_delta > band_max:
            target = band_max
        elif residual_delta < band_min:
            target = band_min
        else:
            target = residual_delta

        raw_size = residual_delta - target
        assert target == 0.30
        assert abs(raw_size - 1.2) < 0.001

    def test_targets_band_min_when_delta_negative(self):
        """When residual delta < band_min, target should be band_min."""
        residual_delta = -2.0
        band_min, band_max = -0.30, 0.30

        target = band_min
        raw_size = residual_delta - target
        assert target == -0.30
        assert abs(raw_size - (-1.7)) < 0.001

    def test_clamping_does_not_set_fallback_used(self):
        """size_clamped should be True, but fallback_used should be False."""
        # The Suggestion model now has separate fields
        s = Suggestion(
            engine="delta", method="perp", instrument="BTC-PERPETUAL",
            size=5.0, direction="sell",
            delta_impact=-5.0, gamma_impact=0.0, vega_impact=0.0,
            post_mm_pct=70.0, post_dd_est=0.0,
            post_delta=3.0, post_gamma=0.0, post_vega=0.0,
            fallback_used=False, fallback_tier=0,
            rationale="test", risk_note="capped",
            simulation_ok=True,
            size_clamped=True,
            target_reached=False,
        )
        assert s.fallback_used is False
        assert s.size_clamped is True
        assert s.target_reached is False


# -----------------------------------------------------------------------
# Phase 4: Vega effectiveness filter
# -----------------------------------------------------------------------

class TestVegaEffectiveness:
    def test_classify_proper_hedge(self):
        """12% vega improvement → proper_hedge."""
        from hedge_engine.actions.vega_hedge import _classify_vega_action
        cfg = make_config()
        result = _classify_vega_action(
            adj_vega=-2500.0, post_vega=-2200.0,  # 300/2500 = 12%
            adj_mm=75.0, post_mm=72.0, cfg=cfg,
        )
        assert result == "proper_hedge"

    def test_classify_mm_relief(self):
        """2% vega improvement but MM improved by >1pp → mm_relief."""
        from hedge_engine.actions.vega_hedge import _classify_vega_action
        cfg = make_config()
        result = _classify_vega_action(
            adj_vega=-2500.0, post_vega=-2450.0,  # 50/2500 = 2% < 8%
            adj_mm=75.0, post_mm=72.0, cfg=cfg,
        )
        assert result == "mm_relief"

    def test_classify_fallback_last_resort(self):
        """1% vega improvement and no MM improvement → fallback_last_resort."""
        from hedge_engine.actions.vega_hedge import _classify_vega_action
        cfg = make_config()
        result = _classify_vega_action(
            adj_vega=-2500.0, post_vega=-2475.0,  # 25/2500 = 1% < 8%
            adj_mm=75.0, post_mm=75.5, cfg=cfg,
        )
        assert result == "fallback_last_resort"


# -----------------------------------------------------------------------
# Phase 5: Gamma forward-risk trigger
# -----------------------------------------------------------------------

class TestGammaForwardRisk:
    def test_forward_risk_detected(self):
        """Stress with projected_dd <= -4% → forward risk is bad."""
        from hedge_engine.actions.convexity.gamma_hedge import _check_forward_risk
        cfg = make_config()
        snapshot = make_snapshot(stress_artifact={
            "fast": {
                "scenarios": {
                    "S1_DOWN_5": {"projected_dd_worst": -0.06, "spot_shock_pct": -0.05},
                }
            }
        })
        assert _check_forward_risk(snapshot, cfg) is True

    def test_no_forward_risk_when_stress_safe(self):
        """Stress with projected_dd > -4% → no forward risk."""
        from hedge_engine.actions.convexity.gamma_hedge import _check_forward_risk
        cfg = make_config()
        snapshot = make_snapshot(stress_artifact={
            "fast": {
                "scenarios": {
                    "S1_DOWN_5": {"projected_dd_worst": -0.02, "spot_shock_pct": -0.05},
                }
            }
        })
        assert _check_forward_risk(snapshot, cfg) is False

    def test_no_forward_risk_when_no_stress(self):
        """No stress artifact → no forward risk."""
        from hedge_engine.actions.convexity.gamma_hedge import _check_forward_risk
        cfg = make_config()
        snapshot = make_snapshot(stress_artifact=None)
        assert _check_forward_risk(snapshot, cfg) is False


# -----------------------------------------------------------------------
# Phase 6: Instrument scorer - hard reject threshold
# -----------------------------------------------------------------------

class TestInstrumentScorerThreshold:
    def test_hard_reject_below_threshold(self):
        """primary_score < 8% → returns 0.0."""
        gp = GreekProfile(
            delta_btc=2.0, gamma=-0.001, vega=-3000.0,
            equity_usd=100_000.0, spot_usd=85_000.0, mm_pct=72.0,
        )
        tgt = GreekTargets(
            delta_band_min=-0.30, delta_band_max=0.30,
            gamma_target=-0.0005, vega_target=-500.0,
            mode="DEFENSIVE", iv_hv_multiplier=1.0, hedge_ratio_H=0.5,
        )
        cfg = make_config()
        # Instrument with near-zero greek impact
        score = score_instrument(
            engine="vega",
            greek_profile=gp,
            targets=tgt,
            instrument_greek=0.01,  # tiny vega
            instrument_delta=0.01,
            instrument_mark_usd=500.0,
            instrument_margin_usd=500.0,
            qty=1.0,
            direction="buy",
            cfg=cfg,
        )
        assert score == 0.0

    def test_above_threshold_gets_score(self):
        """primary_score >= 8% → returns positive score."""
        gp = GreekProfile(
            delta_btc=2.0, gamma=-0.001, vega=-3000.0,
            equity_usd=100_000.0, spot_usd=85_000.0, mm_pct=72.0,
        )
        tgt = GreekTargets(
            delta_band_min=-0.30, delta_band_max=0.30,
            gamma_target=-0.0005, vega_target=-500.0,
            mode="DEFENSIVE", iv_hv_multiplier=1.0, hedge_ratio_H=0.5,
        )
        cfg = make_config()
        score = score_instrument(
            engine="vega",
            greek_profile=gp,
            targets=tgt,
            instrument_greek=500.0,  # large vega impact
            instrument_delta=0.25,
            instrument_mark_usd=500.0,
            instrument_margin_usd=500.0,
            qty=1.0,
            direction="buy",
            cfg=cfg,
        )
        assert score > 0.0


# -----------------------------------------------------------------------
# Phase 7: Combined post-state aggregation
# -----------------------------------------------------------------------

class TestCombinedPostState:
    def test_aggregates_all_impacts(self):
        """Combined post-state should sum all suggestion impacts, not use just one."""
        gp = GreekProfile(
            delta_btc=2.0, gamma=-0.001, vega=-3000.0,
            equity_usd=100_000.0, spot_usd=85_000.0, mm_pct=72.0,
        )
        s_gamma = Suggestion(
            engine="gamma", method="buy_option", instrument="OPT1",
            size=1.0, direction="buy",
            delta_impact=-0.05, gamma_impact=0.0003, vega_impact=100.0,
            post_mm_pct=71.0, post_dd_est=0.0,
            post_delta=1.95, post_gamma=-0.0007, post_vega=-2900.0,
            fallback_used=False, fallback_tier=0,
            rationale="test", risk_note="", simulation_ok=True,
        )
        s_vega = Suggestion(
            engine="vega", method="buy_option", instrument="OPT2",
            size=2.0, direction="buy",
            delta_impact=-0.10, gamma_impact=0.0001, vega_impact=500.0,
            post_mm_pct=70.0, post_dd_est=0.0,
            post_delta=1.85, post_gamma=-0.0006, post_vega=-2400.0,
            fallback_used=False, fallback_tier=0,
            rationale="test", risk_note="", simulation_ok=True,
        )
        s_delta = Suggestion(
            engine="delta", method="perp", instrument="BTC-PERPETUAL",
            size=1.5, direction="sell",
            delta_impact=-1.5, gamma_impact=0.0, vega_impact=0.0,
            post_mm_pct=68.0, post_dd_est=0.0,
            post_delta=0.35, post_gamma=-0.0006, post_vega=-2400.0,
            fallback_used=False, fallback_tier=0,
            rationale="test", risk_note="", simulation_ok=True,
        )

        all_suggestions = [s_gamma, s_vega, s_delta]
        active = [s for s in all_suggestions if s and s.method != "no_action"]
        total_delta = sum(s.delta_impact for s in active)
        total_gamma = sum(s.gamma_impact for s in active)
        total_vega = sum(s.vega_impact for s in active)

        combined = {
            "delta": gp.delta_btc + total_delta,
            "gamma": gp.gamma + total_gamma,
            "vega": gp.vega + total_vega,
        }
        assert abs(combined["delta"] - (2.0 - 0.05 - 0.10 - 1.5)) < 0.001
        assert abs(combined["gamma"] - (-0.001 + 0.0003 + 0.0001)) < 1e-7
        assert abs(combined["vega"] - (-3000.0 + 100.0 + 500.0)) < 0.01


# -----------------------------------------------------------------------
# Phase 8: Formatter output truthfulness
# -----------------------------------------------------------------------

class TestFormatterOutput:
    def test_header_says_delta_and_dd(self):
        """format_hedge_tick header should show both 'Delta' value and 'DD' percentage."""
        gp = GreekProfile(
            delta_btc=2.0, gamma=-0.001, vega=-3000.0,
            equity_usd=100_000.0, spot_usd=85_000.0, mm_pct=72.0,
            dd=-0.05,
        )
        tgt = GreekTargets(
            delta_band_min=-0.30, delta_band_max=0.30,
            gamma_target=-0.0005, vega_target=-500.0,
            mode="DEFENSIVE", iv_hv_multiplier=1.0, hedge_ratio_H=0.5,
        )
        tick = HedgeTick(
            greek_profile=gp, targets=tgt,
            suggestion_gamma=None, suggestion_vega=None, suggestion_delta=None,
            combined_post_state={}, any_fallback_triggered=False,
            timestamp=datetime.now(timezone.utc),
        )
        output = format_hedge_tick(tick)
        header = output.split("\n")[0]
        assert "Delta" in header
        assert "DD" in header
        assert "MM" in header

    def test_classification_label_in_output(self):
        """Suggestion with classification should show label."""
        s = Suggestion(
            engine="vega", method="buy_option", instrument="OPT1",
            size=2.0, direction="buy",
            delta_impact=-0.1, gamma_impact=0.0001, vega_impact=400.0,
            post_mm_pct=70.0, post_dd_est=0.0,
            post_delta=1.9, post_gamma=-0.0009, post_vega=-2600.0,
            fallback_used=False, fallback_tier=0,
            rationale="test", risk_note="", simulation_ok=True,
            action_classification="mm_relief",
        )
        lines = _fmt_suggestion_block("VEGA HEDGE", s)
        joined = "\n".join(lines)
        assert "[MM-RELIEF]" in joined

    def test_delta_target_reached_in_output(self):
        """Delta suggestion with target_reached should show indicator."""
        s = Suggestion(
            engine="delta", method="perp", instrument="BTC-PERPETUAL",
            size=1.2, direction="sell",
            delta_impact=-1.2, gamma_impact=0.0, vega_impact=0.0,
            post_mm_pct=70.0, post_dd_est=0.0,
            post_delta=0.3, post_gamma=0.0, post_vega=0.0,
            fallback_used=False, fallback_tier=0,
            rationale="test", risk_note="", simulation_ok=True,
            action_classification="proper_hedge",
            target_reached=True,
        )
        lines = _fmt_suggestion_block("DELTA HEDGE", s)
        joined = "\n".join(lines)
        assert "Target reached" in joined

    def test_delta_partial_capped_in_output(self):
        """Clamped delta suggestion shows [PARTIAL HEDGE] label and partial indicator."""
        s = Suggestion(
            engine="delta", method="perp", instrument="BTC-PERPETUAL",
            size=5.0, direction="sell",
            delta_impact=-5.0, gamma_impact=0.0, vega_impact=0.0,
            post_mm_pct=70.0, post_dd_est=0.0,
            post_delta=3.0, post_gamma=0.0, post_vega=0.0,
            fallback_used=False, fallback_tier=0,
            rationale="test", risk_note="capped", simulation_ok=True,
            action_classification="partial_hedge",
            size_clamped=True,
            target_reached=False,
        )
        lines = _fmt_suggestion_block("DELTA HEDGE", s)
        joined = "\n".join(lines)
        assert "[PARTIAL HEDGE]" in joined
        assert "Partial" in joined
        assert "capped" in joined.lower()

    def test_formatter_shows_method_type(self):
        """Formatter should show method type (open new / close short) in action line."""
        s_open = Suggestion(
            engine="gamma", method="buy_option", instrument="BTC-29MAR26-80000-P",
            size=3.0, direction="buy",
            delta_impact=-0.05, gamma_impact=0.0002, vega_impact=200.0,
            post_mm_pct=49.0, post_dd_est=0.0,
            post_delta=2.28, post_gamma=-0.00010, post_vega=-2277.0,
            fallback_used=False, fallback_tier=0,
            rationale="test", risk_note="", simulation_ok=True,
            action_classification="proper_hedge",
        )
        s_close = Suggestion(
            engine="gamma", method="close_existing", instrument="BTC-26JUN26-80000-C",
            size=5.0, direction="buy",
            delta_impact=1.1, gamma_impact=0.0001, vega_impact=529.0,
            post_mm_pct=49.5, post_dd_est=0.0,
            post_delta=3.4, post_gamma=-0.000020, post_vega=-1948.0,
            fallback_used=True, fallback_tier=2,
            rationale="test", risk_note="", simulation_ok=True,
            action_classification="fallback_last_resort",
        )
        open_line = "\n".join(_fmt_suggestion_block("GAMMA HEDGE", s_open))
        close_line = "\n".join(_fmt_suggestion_block("GAMMA HEDGE", s_close))
        assert "(open new)" in open_line
        assert "(close short)" in close_line


# -----------------------------------------------------------------------
# ActionClassification enum
# -----------------------------------------------------------------------

class TestActionClassificationEnum:
    def test_enum_values(self):
        assert ActionClassification.PROPER_HEDGE.value == "proper_hedge"
        assert ActionClassification.PARTIAL_HEDGE.value == "partial_hedge"
        assert ActionClassification.MM_RELIEF.value == "mm_relief"
        assert ActionClassification.FALLBACK_LAST_RESORT.value == "fallback_last_resort"
        assert ActionClassification.NO_ACTION.value == "no_action"


# -----------------------------------------------------------------------
# DTE from expiration_timestamp fix
# -----------------------------------------------------------------------

class TestStrikeSelectorDTE:
    def test_dte_computed_from_expiration_timestamp(self):
        """get_candidates_from_chain should compute DTE from expiration_timestamp when dte_days absent."""
        from hedge_engine.actions.convexity.strike_selector import get_candidates_from_chain
        import sqlite3, json

        # Build a minimal in-memory DB with one book summary row
        # The item has no dte_days but has expiration_timestamp ~30 days from now
        now_ms = datetime.now(tz=timezone.utc).timestamp() * 1000
        exp_ms = now_ms + 30 * 24 * 3600 * 1000  # ~30 DTE

        item = {
            "instrument_name": "BTC-29APR26-80000-P",
            "mark_price": 0.002,  # BTC
            "expiration_timestamp": exp_ms,
            "greeks": {"delta": -0.25, "gamma": 0.0001, "vega": 50.0},
        }
        payload = {"options_summaries": [item]}

        con = sqlite3.connect(":memory:")
        con.execute(
            "CREATE TABLE hedge_engine_book_summaries_ticks (ts_utc TEXT PRIMARY KEY, payload_json TEXT)"
        )
        con.execute(
            "INSERT INTO hedge_engine_book_summaries_ticks VALUES (?, ?)",
            ("2026-03-29T00:00:00Z", json.dumps(payload)),
        )
        con.commit()

        results = get_candidates_from_chain(
            con=con, option_type="P", min_dte=25, max_dte=35,
            spot=85000.0, delta_target=0.25,
        )
        assert len(results) == 1, f"Expected 1 candidate, got {len(results)}"
        assert results[0]["instrument_name"] == "BTC-29APR26-80000-P"
        assert 25 <= results[0]["dte_days"] <= 35

    def test_item_without_expiration_skipped(self):
        """Items with neither dte_days nor expiration_timestamp are skipped."""
        from hedge_engine.actions.convexity.strike_selector import get_candidates_from_chain
        import sqlite3, json

        item = {
            "instrument_name": "BTC-29APR26-80000-P",
            "mark_price": 0.002,
            # No dte_days, no expiration_timestamp
            "greeks": {"delta": -0.25},
        }
        payload = {"options_summaries": [item]}

        con = sqlite3.connect(":memory:")
        con.execute(
            "CREATE TABLE hedge_engine_book_summaries_ticks (ts_utc TEXT PRIMARY KEY, payload_json TEXT)"
        )
        con.execute(
            "INSERT INTO hedge_engine_book_summaries_ticks VALUES (?, ?)",
            ("2026-03-29T00:00:00Z", json.dumps(payload)),
        )
        con.commit()

        results = get_candidates_from_chain(
            con=con, option_type="P", min_dte=25, max_dte=35,
            spot=85000.0, delta_target=0.25,
        )
        assert len(results) == 0


# -----------------------------------------------------------------------
# Tick quality label
# -----------------------------------------------------------------------

class TestTickQualityLabel:
    def _make_tick(self, suggestions, any_fallback):
        gp = GreekProfile(
            delta_btc=2.0, gamma=-0.001, vega=-3000.0,
            equity_usd=100_000.0, spot_usd=85_000.0, mm_pct=72.0,
        )
        tgt = GreekTargets(
            delta_band_min=-0.30, delta_band_max=0.30,
            gamma_target=-0.0005, vega_target=-500.0,
            mode="DEFENSIVE", iv_hv_multiplier=1.0, hedge_ratio_H=0.5,
        )
        sg, sv, sd = suggestions if len(suggestions) == 3 else (None, None, None)
        return HedgeTick(
            greek_profile=gp, targets=tgt,
            suggestion_gamma=sg, suggestion_vega=sv, suggestion_delta=sd,
            combined_post_state={}, any_fallback_triggered=any_fallback,
            timestamp=datetime.now(timezone.utc),
        )

    def test_no_active_suggestions_is_no_action_needed(self):
        tick = self._make_tick([None, None, None], False)
        output = format_hedge_tick(tick)
        assert "NO_ACTION_NEEDED" in output

    def test_fallback_with_breach_is_fallback_breach_remains(self):
        """Fallback active + delta and vega breach remaining → FALLBACK_BREACH_REMAINS."""
        # post_delta = 2.0 (outside band), post_vega = -3000 (< target -500)
        # combined_post_state not set → uses greek_profile defaults (delta=2.0, vega=-3000)
        sg = Suggestion(
            engine="gamma", method="close_existing", instrument="X",
            size=1.0, direction="buy",
            delta_impact=0.0, gamma_impact=0.001, vega_impact=100.0,
            post_mm_pct=71.0, post_dd_est=0.0,
            post_delta=2.0, post_gamma=-0.0004, post_vega=-2900.0,
            fallback_used=True, fallback_tier=2,
            rationale="t", risk_note="", simulation_ok=True,
            action_classification="fallback_last_resort",
        )
        tick = self._make_tick([sg, None, None], True)
        output = format_hedge_tick(tick)
        assert "FALLBACK_BREACH_REMAINS" in output


# -----------------------------------------------------------------------
# Over-hedging prevention: urgency gating + breach severity + delta cap
# -----------------------------------------------------------------------

class TestOverHedgingPrevention:
    """Tests for Fixes A/B/C/D/E in gamma_hedge and vega_hedge."""

    def test_gamma_classify_breach_severity_mild(self):
        """gap_pct < 25% → mild."""
        from hedge_engine.actions.convexity.gamma_hedge import _classify_breach_severity
        cfg = make_config()
        assert _classify_breach_severity(0.10, cfg) == "mild"

    def test_gamma_classify_breach_severity_moderate(self):
        """gap_pct in [25%, 75%) → moderate."""
        from hedge_engine.actions.convexity.gamma_hedge import _classify_breach_severity
        cfg = make_config()
        assert _classify_breach_severity(0.50, cfg) == "moderate"

    def test_gamma_classify_breach_severity_severe(self):
        """gap_pct >= 75% → severe."""
        from hedge_engine.actions.convexity.gamma_hedge import _classify_breach_severity
        cfg = make_config()
        assert _classify_breach_severity(0.90, cfg) == "severe"

    def test_gamma_classify_no_breach(self):
        """gap_pct <= 0 → none."""
        from hedge_engine.actions.convexity.gamma_hedge import _classify_breach_severity
        cfg = make_config()
        assert _classify_breach_severity(0.0, cfg) == "none"
        assert _classify_breach_severity(-0.1, cfg) == "none"

    def test_delta_side_effect_cap_per_mode(self):
        """Delta cap should vary by mode."""
        from hedge_engine.actions.convexity.gamma_hedge import _get_delta_side_effect_cap
        cfg = make_config()
        assert _get_delta_side_effect_cap("NORMAL", cfg)    == pytest.approx(0.30)
        assert _get_delta_side_effect_cap("DEFENSIVE", cfg) == pytest.approx(0.50)
        assert _get_delta_side_effect_cap("DANGER", cfg)    == pytest.approx(0.80)
        assert _get_delta_side_effect_cap("EMERGENCY", cfg) == pytest.approx(1.50)

    def test_vega_classify_breach_severity_mild(self):
        """Vega gap_pct < 25% → mild breach."""
        from hedge_engine.actions.vega_hedge import _classify_vega_breach_severity
        cfg = make_config()
        assert _classify_vega_breach_severity(0.10, cfg) == "mild"

    def test_vega_classify_breach_severity_severe(self):
        """Vega gap_pct >= 75% → severe breach."""
        from hedge_engine.actions.vega_hedge import _classify_vega_breach_severity
        cfg = make_config()
        assert _classify_vega_breach_severity(0.80, cfg) == "severe"

    def test_vega_delta_side_effect_cap(self):
        """Vega delta side-effect cap should match gamma cap for each mode."""
        from hedge_engine.actions.vega_hedge import _get_vega_delta_side_effect_cap
        cfg = make_config()
        assert _get_vega_delta_side_effect_cap("DEFENSIVE", cfg) == pytest.approx(0.50)
        assert _get_vega_delta_side_effect_cap("DANGER", cfg)    == pytest.approx(0.80)


# -----------------------------------------------------------------------
# Delta soft vs hard targeting: calm-state band widening
# -----------------------------------------------------------------------

class TestDeltaSoftTargeting:
    """Tests for Fix 2 (soft/hard delta band) in delta_hedge.run().

    The delta engine uses the base mode band (soft) when portfolio is calm:
        mm_pct < 65%, |dd| < 4%, mode in {NORMAL, DEFENSIVE}.
    In stressed states or DANGER/EMERGENCY it always uses the H-tightened hard band.
    """

    @staticmethod
    def _make_greek_profile(delta_btc=2.35, mm_pct=51.0, dd=-0.023):
        return GreekProfile(
            delta_btc=delta_btc, gamma=-0.0001, vega=-2466.0,
            equity_usd=100_000.0, spot_usd=85_000.0, mm_pct=mm_pct, dd=dd,
        )

    @staticmethod
    def _make_targets_defensive_tightened():
        """DEFENSIVE mode with H-tightened band ±0.075 (simulating vega_breach escalation)."""
        return GreekTargets(
            delta_band_min=-0.075, delta_band_max=0.075,
            gamma_target=-0.0005, vega_target=-500.0,
            mode="DEFENSIVE", iv_hv_multiplier=1.0, hedge_ratio_H=0.75,
        )

    @staticmethod
    def _make_targets_danger():
        """DANGER mode with tightened band ±0.10."""
        return GreekTargets(
            delta_band_min=-0.10, delta_band_max=0.10,
            gamma_target=-0.0005, vega_target=-500.0,
            mode="DANGER", iv_hv_multiplier=1.0, hedge_ratio_H=0.75,
        )

    @staticmethod
    def _make_no_action_suggestion():
        """A no_action suggestion that has fallback_used=True (mirrors previous gamma/vega engines)."""
        return Suggestion(
            engine="gamma", method="no_action", instrument="BTC-PERPETUAL",
            size=0.0, direction="none",
            delta_impact=0.0, gamma_impact=0.0, vega_impact=0.0,
            post_mm_pct=51.0, post_dd_est=0.0,
            post_delta=2.35, post_gamma=-0.0001, post_vega=-2466.0,
            fallback_used=True, fallback_tier=0,
            rationale="mild breach suppressed in calm state",
            risk_note="", simulation_ok=True,
        )

    def test_calm_defensive_uses_soft_band(self):
        """
        Calm state (MM 51%, DD -2.3%, DEFENSIVE) + hard band ±0.075 →
        engine should use soft band ±0.30, producing a smaller perp hedge.
        """
        from unittest.mock import patch
        from hedge_engine.actions.delta.delta_hedge import run

        gp  = self._make_greek_profile(delta_btc=2.35, mm_pct=51.0, dd=-0.023)
        tgt = self._make_targets_defensive_tightened()
        cfg = make_config()
        snap = make_snapshot(portfolio_delta_btc=2.35, mm_pct=51.0, dd=-0.023, mode="DEFENSIVE")

        with patch(
            "hedge_engine.risk.xpm.xpm_simulator.simulate_action_impact",
            return_value={"mm_pct_after": 50.0}
        ):
            sug = run(
                greek_profile=gp, targets=tgt,
                gamma_suggestion=None, vega_suggestion=None,
                snapshot=snap, cfg=cfg, deribit=None,
            )

        # With soft band ±0.30, target edge is +0.30; perp size ≈ 2.35 - 0.30 = 2.05 BTC
        # With hard band ±0.075, target edge is +0.075; perp size ≈ 2.275 BTC
        # Soft hedge must be noticeably smaller than hard hedge
        assert sug.method == "perp"
        assert sug.direction == "sell"
        # Size should reflect targeting ±0.30 soft band, not ±0.075 hard band
        assert sug.size == pytest.approx(2.35 - 0.30, abs=0.01), (
            f"Expected ~2.05 BTC (soft band ±0.30), got {sug.size:.4f}"
        )
        assert "soft" in sug.rationale
        assert "soft" in sug.risk_note

    def test_calm_defensive_no_action_when_in_soft_band(self):
        """
        Calm DEFENSIVE state, delta=0.25 BTC - inside soft band ±0.30.
        Engine should return no_action (delta is safe enough).
        Hard band ±0.075 would have triggered a hedge.
        """
        from unittest.mock import patch
        from hedge_engine.actions.delta.delta_hedge import run

        gp  = self._make_greek_profile(delta_btc=0.25, mm_pct=51.0, dd=-0.023)
        tgt = self._make_targets_defensive_tightened()  # hard band ±0.075
        cfg = make_config()
        snap = make_snapshot(portfolio_delta_btc=0.25, mm_pct=51.0, dd=-0.023, mode="DEFENSIVE")

        with patch(
            "hedge_engine.risk.xpm.xpm_simulator.simulate_action_impact",
            return_value={"mm_pct_after": 50.5}
        ):
            sug = run(
                greek_profile=gp, targets=tgt,
                gamma_suggestion=None, vega_suggestion=None,
                snapshot=snap, cfg=cfg, deribit=None,
            )

        # 0.25 BTC is inside soft band ±0.30 → no action
        assert sug.method == "no_action"
        assert "soft band" in sug.rationale

    def test_stressed_defensive_uses_hard_band(self):
        """
        Stressed DEFENSIVE state (MM 70%, DD -5%) → calm gate disabled → hard band ±0.075.
        Engine should produce a larger hedge targeting the tighter band edge.
        """
        from unittest.mock import patch
        from hedge_engine.actions.delta.delta_hedge import run

        gp  = self._make_greek_profile(delta_btc=2.35, mm_pct=70.0, dd=-0.05)
        tgt = self._make_targets_defensive_tightened()
        cfg = make_config()
        snap = make_snapshot(portfolio_delta_btc=2.35, mm_pct=70.0, dd=-0.05, mode="DEFENSIVE")

        with patch(
            "hedge_engine.risk.xpm.xpm_simulator.simulate_action_impact",
            return_value={"mm_pct_after": 68.0}
        ):
            sug = run(
                greek_profile=gp, targets=tgt,
                gamma_suggestion=None, vega_suggestion=None,
                snapshot=snap, cfg=cfg, deribit=None,
            )

        # Hard band ±0.075, target edge = 0.075; size ≈ 2.35 - 0.075 = 2.275 BTC
        assert sug.method == "perp"
        assert sug.size == pytest.approx(2.35 - 0.075, abs=0.01), (
            f"Expected ~2.275 BTC (hard band), got {sug.size:.4f}"
        )
        # Soft note should NOT appear
        assert "soft" not in sug.rationale

    def test_danger_mode_always_uses_hard_band(self):
        """
        DANGER mode is never calm → hard band ±0.10 always used,
        even if MM and DD would otherwise qualify as calm.
        """
        from unittest.mock import patch
        from hedge_engine.actions.delta.delta_hedge import run

        gp  = self._make_greek_profile(delta_btc=2.35, mm_pct=51.0, dd=-0.023)
        tgt = self._make_targets_danger()   # DANGER mode, hard band ±0.10
        cfg = make_config()
        snap = make_snapshot(portfolio_delta_btc=2.35, mm_pct=51.0, dd=-0.023, mode="DANGER")

        with patch(
            "hedge_engine.risk.xpm.xpm_simulator.simulate_action_impact",
            return_value={"mm_pct_after": 50.0}
        ):
            sug = run(
                greek_profile=gp, targets=tgt,
                gamma_suggestion=None, vega_suggestion=None,
                snapshot=snap, cfg=cfg, deribit=None,
            )

        # Hard band ±0.10, target edge = 0.10; size ≈ 2.35 - 0.10 = 2.25 BTC
        assert sug.method == "perp"
        assert sug.size == pytest.approx(2.35 - 0.10, abs=0.01)
        assert "soft" not in sug.rationale

    def test_soft_band_not_narrower_than_hard(self):
        """
        If soft band is already narrower than hard band (impossible by config but guard exists),
        engine should use hard band. Achieved by passing a very wide hard band.
        """
        from unittest.mock import patch
        from hedge_engine.actions.delta.delta_hedge import run

        gp  = self._make_greek_profile(delta_btc=1.5, mm_pct=51.0, dd=-0.023)
        # Hard band ±2.0 BTC (wider than soft ±0.30) → soft branch skipped
        tgt = GreekTargets(
            delta_band_min=-2.0, delta_band_max=2.0,
            gamma_target=-0.0005, vega_target=-500.0,
            mode="DEFENSIVE", iv_hv_multiplier=1.0, hedge_ratio_H=0.0,
        )
        cfg = make_config()
        snap = make_snapshot(portfolio_delta_btc=1.5, mm_pct=51.0, dd=-0.023, mode="DEFENSIVE")

        with patch(
            "hedge_engine.risk.xpm.xpm_simulator.simulate_action_impact",
            return_value={"mm_pct_after": 50.5}
        ):
            sug = run(
                greek_profile=gp, targets=tgt,
                gamma_suggestion=None, vega_suggestion=None,
                snapshot=snap, cfg=cfg, deribit=None,
            )

        # delta 1.5 is inside hard band ±2.0 → no action
        assert sug.method == "no_action"


# -----------------------------------------------------------------------
# Quality label fix: no_action suggestions with fallback_used must not
# trigger FALLBACK_BREACH_REMAINS when only a delta perp hedge ran.
# -----------------------------------------------------------------------

class TestQualityLabelFix:
    """Tests for runner.py any_fallback_triggered fix and formatter delta_ok fix."""

    @staticmethod
    def _make_targets():
        return GreekTargets(
            delta_band_min=-0.075, delta_band_max=0.075,
            gamma_target=-0.0005, vega_target=-500.0,
            mode="DEFENSIVE", iv_hv_multiplier=1.0, hedge_ratio_H=0.75,
        )

    @staticmethod
    def _make_gp(delta=2.35):
        return GreekProfile(
            delta_btc=delta, gamma=-0.0001, vega=-2466.0,
            equity_usd=100_000.0, spot_usd=85_000.0, mm_pct=51.0, dd=-0.023,
        )

    @staticmethod
    def _no_action_with_fallback(engine="gamma"):
        """Simulate a gamma/vega no_action that mistakenly has fallback_used=True."""
        return Suggestion(
            engine=engine, method="no_action", instrument="BTC-PERPETUAL",
            size=0.0, direction="none",
            delta_impact=0.0, gamma_impact=0.0, vega_impact=0.0,
            post_mm_pct=51.0, post_dd_est=0.0,
            post_delta=2.35, post_gamma=-0.0001, post_vega=-2466.0,
            fallback_used=True, fallback_tier=0,
            rationale="mild breach suppressed", risk_note="", simulation_ok=True,
        )

    @staticmethod
    def _delta_perp_suggestion(target_reached=True):
        return Suggestion(
            engine="delta", method="perp", instrument="BTC-PERPETUAL",
            size=2.05, direction="sell",
            delta_impact=-2.05, gamma_impact=0.0, vega_impact=0.0,
            post_mm_pct=50.5, post_dd_est=0.0,
            post_delta=0.30, post_gamma=-0.0001, post_vega=-2466.0,
            fallback_used=False, fallback_tier=0,
            rationale="SELL 2.0500 BTC-PERPETUAL toward soft band edge 0.300 [band ±0.300, type=soft]",
            risk_note="Calm state ...", simulation_ok=True,
            action_classification="proper_hedge",
            size_clamped=False, target_reached=target_reached,
        )

    def test_no_action_fallback_excluded_from_any_fallback(self):
        """
        HedgeTick with gamma/vega=no_action(fallback_used=True) + delta=perp(fallback_used=False)
        should have any_fallback_triggered=False (runner fix).
        """
        from hedge_engine.notifications.formatter import _compute_tick_quality

        sg = self._no_action_with_fallback("gamma")
        sv = self._no_action_with_fallback("vega")
        sd = self._delta_perp_suggestion(target_reached=True)
        gp = self._make_gp()
        tgt = self._make_targets()

        # Simulate corrected runner: any_fallback_triggered excludes no_action
        corrected_any_fallback = any(
            s.fallback_used for s in [sg, sv, sd]
            if s and s.method != "no_action"
        )
        assert corrected_any_fallback is False, (
            "any_fallback_triggered must be False when only no_action suggestions have fallback_used=True"
        )

    def test_quality_is_full_hedge_when_delta_ok(self):
        """
        Quality=FULL_HEDGE when delta target_reached=True, gamma/vega ok, no real fallback.
        """
        from hedge_engine.notifications.formatter import _compute_tick_quality

        sg = self._no_action_with_fallback("gamma")  # fallback_used=True but no_action
        sv = self._no_action_with_fallback("vega")
        sd = self._delta_perp_suggestion(target_reached=True)

        gp  = self._make_gp(delta=2.35)
        tgt = self._make_targets()

        tick = HedgeTick(
            greek_profile=gp, targets=tgt,
            suggestion_gamma=sg, suggestion_vega=sv, suggestion_delta=sd,
            combined_post_state={
                "mm_pct": 50.5, "delta": 0.30, "gamma": -0.0001, "vega": -400.0
            },
            any_fallback_triggered=False,   # corrected runner value
            timestamp=datetime.now(timezone.utc),
        )

        # post_gamma (-0.0001) >= gamma_target (-0.0005) → gamma_ok=True
        # post_vega (-400) >= vega_target (-500) → vega_ok=True
        # delta target_reached=True → delta_ok=True
        # any_fallback_triggered=False → FULL_HEDGE
        quality = _compute_tick_quality(tick, 0.30, -0.0001, -400.0)
        assert quality == "FULL_HEDGE", f"Expected FULL_HEDGE, got {quality}"

    def test_quality_is_partial_when_delta_not_reached(self):
        """
        delta target_reached=False (clamped), no real fallback → PARTIAL_HEDGE not FALLBACK_BREACH_REMAINS.
        """
        from hedge_engine.notifications.formatter import _compute_tick_quality

        sg = self._no_action_with_fallback("gamma")
        sv = self._no_action_with_fallback("vega")
        sd = self._delta_perp_suggestion(target_reached=False)

        gp  = self._make_gp(delta=2.35)
        tgt = self._make_targets()

        tick = HedgeTick(
            greek_profile=gp, targets=tgt,
            suggestion_gamma=sg, suggestion_vega=sv, suggestion_delta=sd,
            combined_post_state={
                "mm_pct": 50.5, "delta": 0.80, "gamma": -0.0001, "vega": -2466.0
            },
            any_fallback_triggered=False,  # corrected runner value
            timestamp=datetime.now(timezone.utc),
        )

        quality = _compute_tick_quality(tick, 0.80, -0.0001, -2466.0)
        assert quality == "PARTIAL_HEDGE", (
            f"Expected PARTIAL_HEDGE (no fallback, delta not reached), got {quality}"
        )

    def test_fallback_breach_remains_only_when_real_fallback(self):
        """
        True FALLBACK_BREACH_REMAINS requires a real fallback suggestion (method != no_action)
        with fallback_used=True AND delta+vega still in breach.
        """
        from hedge_engine.notifications.formatter import _compute_tick_quality

        sg_fallback = Suggestion(
            engine="gamma", method="close_existing", instrument="BTC-26JUN26-80000-C",
            size=5.0, direction="buy",
            delta_impact=1.1, gamma_impact=0.0002, vega_impact=200.0,
            post_mm_pct=49.5, post_dd_est=0.0,
            post_delta=3.45, post_gamma=-0.0003, post_vega=-2266.0,
            fallback_used=True, fallback_tier=2,
            rationale="Tier 2 close short", risk_note="", simulation_ok=True,
            action_classification="fallback_last_resort",
        )
        sd = self._delta_perp_suggestion(target_reached=False)

        gp  = self._make_gp(delta=2.35)
        tgt = self._make_targets()

        tick = HedgeTick(
            greek_profile=gp, targets=tgt,
            suggestion_gamma=sg_fallback, suggestion_vega=None, suggestion_delta=sd,
            combined_post_state={
                "mm_pct": 48.0, "delta": 2.5, "gamma": -0.0003, "vega": -2266.0
            },
            any_fallback_triggered=True,   # real fallback
            timestamp=datetime.now(timezone.utc),
        )

        quality = _compute_tick_quality(tick, 2.5, -0.0003, -2266.0)
        # any_fb=True, delta not reached, vega still below target → FALLBACK_BREACH_REMAINS
        assert quality == "FALLBACK_BREACH_REMAINS"


# -----------------------------------------------------------------------
# Phase 1: Option candidate Greek sourcing from chain and positions
# -----------------------------------------------------------------------

class TestPhase1GreekSourcing:
    """
    Tests for Phase 1 fix: strike_selector now propagates gamma_approx, vega_approx,
    and delta_signed from both chain (book summaries) and position-sourced candidates.
    gamma_hedge Tier 0 skips candidates with gamma_approx == 0 and tracks no_gamma_data.
    """

    # ------------------------------------------------------------------ #
    # Helpers                                                              #
    # ------------------------------------------------------------------ #

    @staticmethod
    def _make_sqlite_chain_db(items):
        """In-memory SQLite with hedge_engine_book_summaries_ticks populated."""
        import json
        import sqlite3
        con = sqlite3.connect(":memory:")
        con.execute(
            "CREATE TABLE hedge_engine_book_summaries_ticks "
            "(ts_utc TEXT, payload_json TEXT)"
        )
        con.execute(
            "INSERT INTO hedge_engine_book_summaries_ticks VALUES (?, ?)",
            ("2025-01-01T00:00:00Z", json.dumps(items)),
        )
        con.commit()
        return con

    # ------------------------------------------------------------------ #
    # strike_selector: chain candidates carry greek fields                #
    # ------------------------------------------------------------------ #

    def test_chain_candidates_include_gamma_vega_delta_signed(self):
        """
        get_candidates_from_chain() must return gamma_approx, vega_approx,
        and delta_signed populated from the 'greeks' dict in the payload.
        """
        from hedge_engine.actions.convexity.strike_selector import get_candidates_from_chain

        items = [
            {
                "instrument_name": "BTC-27JUN25-80000-P",
                "dte_days": 10.0,
                "mark_price": 0.012,   # BTC-denominated
                "greeks": {"delta": -0.25, "gamma": 0.000012, "vega": 45.0, "theta": -5.0},
            }
        ]
        con = self._make_sqlite_chain_db(items)
        results = get_candidates_from_chain(
            con=con, option_type="P", min_dte=5, max_dte=30,
            spot=85_000.0, delta_target=0.25,
        )

        assert len(results) == 1, "Expected one chain candidate"
        r = results[0]

        assert "gamma_approx" in r,  "gamma_approx missing from chain candidate"
        assert "vega_approx"  in r,  "vega_approx missing from chain candidate"
        assert "delta_signed" in r,  "delta_signed missing from chain candidate"

        assert r["gamma_approx"] == pytest.approx(0.000012), "gamma_approx must be abs(greeks.gamma)"
        assert r["vega_approx"]  == pytest.approx(45.0),     "vega_approx must be abs(greeks.vega)"
        assert r["delta_signed"] == pytest.approx(-0.25),    "delta_signed must preserve negative sign for put"
        assert r["delta_approx"] == pytest.approx(0.25),     "delta_approx must remain abs value"

    def test_chain_candidates_zero_greeks_produce_zero_approx(self):
        """
        When greeks dict contains zeros (or is absent), gamma_approx and vega_approx are 0.
        This represents the pre-fix scenario where Deribit data was missing greek fields.
        """
        from hedge_engine.actions.convexity.strike_selector import get_candidates_from_chain

        items = [
            {
                "instrument_name": "BTC-27JUN25-80000-P",
                "dte_days": 10.0,
                "mark_price": 0.012,
                "greeks": {},   # empty - typical for pre-populated chain cache
            }
        ]
        con = self._make_sqlite_chain_db(items)
        results = get_candidates_from_chain(
            con=con, option_type="P", min_dte=5, max_dte=30,
            spot=85_000.0, delta_target=0.25,
        )

        assert len(results) == 1
        r = results[0]
        assert r["gamma_approx"] == pytest.approx(0.0)
        assert r["vega_approx"]  == pytest.approx(0.0)
        assert r["delta_signed"] == pytest.approx(0.0)

    # ------------------------------------------------------------------ #
    # strike_selector: position-sourced candidates carry greek fields     #
    # ------------------------------------------------------------------ #

    def test_position_candidates_include_gamma_vega_delta_signed(self):
        """
        get_candidates() when using position-sourced candidates (>=2 matches) must
        include gamma_approx, vega_approx, and delta_signed from the Position object.
        """
        import sqlite3
        from hedge_engine.actions.convexity.strike_selector import get_candidates

        positions = make_positions([
            {
                "instrument_name": "BTC-27JUN25-80000-P",
                "kind": "option", "size": -10,
                "net_delta": -0.25, "gamma": -0.0002, "vega": -800.0, "theta": 50,
                "option_type": "P", "strike": 80000, "dte_days": 15,
                "mark_price_usd": 900.0, "mark_price_btc": 0.0106, "index_price": 85000,
                "delta": -0.25,
            },
            {
                "instrument_name": "BTC-27JUN25-70000-P",
                "kind": "option", "size": -5,
                "net_delta": -0.15, "gamma": -0.0001, "vega": -400.0, "theta": 30,
                "option_type": "P", "strike": 70000, "dte_days": 15,
                "mark_price_usd": 500.0, "mark_price_btc": 0.0059, "index_price": 85000,
                "delta": -0.15,
            },
        ])
        snap = make_snapshot(positions=positions)
        con  = sqlite3.connect(":memory:")   # empty - positions branch fires (>=2 matches)

        results = get_candidates(
            snapshot=snap, con=con,
            option_type="P", min_dte=5, max_dte=30,
            delta_target=0.25, max_results=5,
        )

        assert len(results) >= 1
        r = results[0]
        assert r["source"] == "positions"

        assert "gamma_approx" in r,  "gamma_approx missing from position candidate"
        assert "vega_approx"  in r,  "vega_approx missing from position candidate"
        assert "delta_signed" in r,  "delta_signed missing from position candidate"

        # Position gamma is -0.0002 (short); gamma_approx must be positive abs value
        assert r["gamma_approx"] > 0.0,        "gamma_approx must be > 0 for position with non-zero gamma"
        assert r["vega_approx"]  > 0.0,        "vega_approx must be > 0 for position with non-zero vega"
        assert r["delta_signed"] < 0.0,        "delta_signed must be negative for short put"
        assert r["delta_approx"] > 0.0,        "delta_approx (abs) must be positive"

    # ------------------------------------------------------------------ #
    # gamma Tier 0: no_gamma_data skip logic                              #
    # ------------------------------------------------------------------ #

    def test_gamma_tier0_skips_chain_candidate_with_zero_gamma(self):
        """
        gamma Tier 0: chain candidate with gamma_approx=0 (greeks missing in book data)
        is skipped early (no_gamma_data) rather than being passed to the scorer
        where it would get score=0.0 and become best_candidate anyway.
        When all candidates have zero gamma, tier0 has no valid candidate.
        """
        from unittest.mock import MagicMock, patch
        from hedge_engine.actions.convexity.gamma_hedge import run as gamma_run

        gp = GreekProfile(
            delta_btc=0.0, gamma=-0.0008, vega=-2000.0,
            equity_usd=100_000.0, spot_usd=85_000.0, mm_pct=51.0, dd=-0.023,
        )
        # Gamma target above current (less negative) → breach triggered
        tgt = GreekTargets(
            delta_band_min=-0.30, delta_band_max=0.30,
            gamma_target=-0.0003, vega_target=-500.0,
            mode="NORMAL", iv_hv_multiplier=1.0, hedge_ratio_H=0.25,
        )
        cfg  = make_config()
        snap = make_snapshot(positions=[], mm_pct=51.0, dd=-0.023, mode="NORMAL",
                             portfolio_delta_btc=0.0)

        # Chain candidate with gamma=0 in greeks (pre-fix scenario)
        items = [{
            "instrument_name": "BTC-27JUN25-80000-P",
            "dte_days": 10.0,
            "mark_price": 0.012,
            "greeks": {"delta": -0.20, "gamma": 0.0, "vega": 0.0},
        }]
        con          = self._make_sqlite_chain_db(items)
        mock_deribit = MagicMock()
        mock_deribit.get_last_trades_by_instrument.return_value = []

        with patch("hedge_engine.risk.xpm.xpm_simulator.simulate_action_impact",
                   return_value={"mm_pct_after": 50.0, "gamma_after": -0.0003,
                                 "delta_after": -0.20, "vega_after": -1950.0, "safe": True}):
            sug = gamma_run(
                greek_profile=gp, targets=tgt,
                positions=[], snapshot=snap,
                cfg=cfg, deribit=mock_deribit, con=con,
            )

        # With zero gamma_approx on the only candidate, Tier 0 has no valid candidate.
        # Tier 1 and Tier 2 also fail (no positions). Final result is no_action (sim_ok=False).
        assert sug.method == "no_action", (
            f"Expected no_action when all chain candidates have zero gamma, got {sug.method}"
        )

    def test_gamma_tier0_proceeds_when_chain_gamma_approx_positive(self):
        """
        gamma Tier 0: chain candidate with gamma_approx > 0 must NOT be rejected by
        the no_gamma_data gate - it should reach scoring and simulation.
        If simulation passes all other filters, method is 'buy_option'.
        """
        from unittest.mock import MagicMock, patch
        from hedge_engine.actions.convexity.gamma_hedge import run as gamma_run

        gp = GreekProfile(
            delta_btc=0.0, gamma=-0.0008, vega=-2000.0,
            equity_usd=100_000.0, spot_usd=85_000.0, mm_pct=51.0, dd=-0.023,
        )
        tgt = GreekTargets(
            delta_band_min=-0.30, delta_band_max=0.30,
            gamma_target=-0.0003, vega_target=-500.0,
            mode="NORMAL", iv_hv_multiplier=1.0, hedge_ratio_H=0.25,
        )
        cfg  = make_config()
        snap = make_snapshot(positions=[], mm_pct=51.0, dd=-0.023, mode="NORMAL",
                             portfolio_delta_btc=0.0)

        # Chain candidate with valid gamma data
        items = [{
            "instrument_name": "BTC-27JUN25-80000-P",
            "dte_days": 10.0,
            "mark_price": 0.012,   # → mark_usd = 0.012 * 85_000 = 1_020
            "greeks": {"delta": -0.20, "gamma": 0.000015, "vega": 50.0},
        }]
        con          = self._make_sqlite_chain_db(items)
        mock_deribit = MagicMock()
        mock_deribit.get_last_trades_by_instrument.return_value = []

        # Simulation: action brings gamma from -0.0008 toward -0.0003, safe MM
        with patch("hedge_engine.risk.xpm.xpm_simulator.simulate_action_impact",
                   return_value={
                       "mm_pct_after": 50.0, "gamma_after": -0.00035,
                       "delta_after": -0.20,  "vega_after": -1950.0,
                       "safe": True,
                   }):
            sug = gamma_run(
                greek_profile=gp, targets=tgt,
                positions=[], snapshot=snap,
                cfg=cfg, deribit=mock_deribit, con=con,
            )

        # With valid gamma_approx > 0, the candidate passes no_gamma_data gate.
        # Scoring and simulation run. If all other filters pass: buy_option.
        # If net_benefit/delta_cap filters reject: no_action - but NOT because of missing gamma.
        assert sug.method in {"buy_option", "no_action"}, (
            f"Unexpected method {sug.method!r} - should be buy_option (or no_action from other filter)"
        )
        # The key invariant: simulation must have been called (not short-circuited by no_gamma_data)
        # Verified indirectly: if method is no_action, rationale must NOT mention gamma data
        if sug.method == "no_action":
            assert "gamma data" not in sug.rationale.lower(), (
                f"no_action due to missing gamma data - Phase 1 fix did not take effect: {sug.rationale}"
            )


# -----------------------------------------------------------------------
# Phase 3: Vega breach flag aligned with engine target threshold
# (Option B - both use tightened formula: 0.005 * (1 - effective * 0.5) * equity)
# -----------------------------------------------------------------------

class TestPhase3VegaBreachAlignment:
    """
    Tests for Phase 3 fix: vega_breach_check() now accepts an 'effective' parameter
    that tightens the limit using the same formula as compute_greek_targets().

    At effective=0.0  → un-tightened limit = 0.005 * equity   (bootstrap / no stress)
    At effective=0.75 → tightened  limit = 0.005 * 0.625 * equity
    At effective=1.0  → half the un-tightened limit (maximum tightening, 50%)
    """

    # ------------------------------------------------------------------ #
    # vega_breach_check: effective parameter behaves correctly            #
    # ------------------------------------------------------------------ #

    def test_untightened_breach_at_effective_zero(self):
        """effective=0.0 → limit = 0.005 * equity (un-tightened, same as old behavior)."""
        cfg = make_config()
        breach, limit = vega_breach_check(
            equity_usd=100_000.0, portfolio_vega=-600.0, cfg=cfg, effective=0.0
        )
        assert limit == pytest.approx(500.0), f"Expected 0.005*100k=500, got {limit}"
        assert breach is True, "vega=-600 < -500 must be a breach"

    def test_no_breach_at_effective_zero_when_within_limit(self):
        """vega=-400, limit=500, effective=0.0 → no breach."""
        cfg = make_config()
        breach, limit = vega_breach_check(
            equity_usd=100_000.0, portfolio_vega=-400.0, cfg=cfg, effective=0.0
        )
        assert limit == pytest.approx(500.0)
        assert breach is False

    def test_tightened_limit_at_effective_075(self):
        """
        effective=0.75 → limit = 0.005 * (1 - 0.75*0.5) * 100k
                                = 0.005 * 0.625 * 100k = 312.5
        """
        cfg = make_config()
        _, limit = vega_breach_check(
            equity_usd=100_000.0, portfolio_vega=-200.0, cfg=cfg, effective=0.75
        )
        assert limit == pytest.approx(0.005 * 0.625 * 100_000.0, rel=1e-6), (
            f"Expected 312.5, got {limit}"
        )

    def test_tightened_breach_fires_before_untightened(self):
        """
        With effective=0.75 the tightened limit is 312.5.
        vega=-400 is between -312.5 and -500:
          - tightened (effective=0.75): breach=True  (−400 < −312.5)
          - un-tightened (effective=0):  breach=False (−400 > −500)
        This is the key property of Option B.
        """
        cfg = make_config()
        breach_tight, _  = vega_breach_check(
            equity_usd=100_000.0, portfolio_vega=-400.0, cfg=cfg, effective=0.75
        )
        breach_loose, _  = vega_breach_check(
            equity_usd=100_000.0, portfolio_vega=-400.0, cfg=cfg, effective=0.0
        )
        assert breach_tight is True,  "Tightened flag must fire at -400 (< -312.5)"
        assert breach_loose is False, "Un-tightened flag must NOT fire at -400 (> -500)"

    def test_maximum_tightening_at_effective_one(self):
        """effective=1.0 → limit = 0.005 * 0.5 * equity = 250 (50% tighter)."""
        cfg = make_config()
        _, limit = vega_breach_check(
            equity_usd=100_000.0, portfolio_vega=-200.0, cfg=cfg, effective=1.0
        )
        assert limit == pytest.approx(250.0, rel=1e-6), (
            f"Expected 0.005 * 0.5 * 100k = 250, got {limit}"
        )

    def test_effective_clamped_to_one(self):
        """effective > 1.0 is clamped to 1.0 - limit floor at 50% of un-tightened."""
        cfg = make_config()
        _, limit_at_1   = vega_breach_check(
            equity_usd=100_000.0, portfolio_vega=-200.0, cfg=cfg, effective=1.0
        )
        _, limit_over_1 = vega_breach_check(
            equity_usd=100_000.0, portfolio_vega=-200.0, cfg=cfg, effective=2.0
        )
        assert limit_at_1 == pytest.approx(limit_over_1, rel=1e-6), (
            "effective > 1.0 should be clamped to 1.0"
        )

    def test_breach_flag_matches_engine_target_formula(self):
        """
        After Phase 3 fix, flags.vega_limit_usd must equal the engine's vega_target (abs).
        This verifies the two formulas are identical at the same effective.
        """
        from hedge_engine.risk.risk_checks import compute_greek_targets
        from unittest.mock import MagicMock

        equity   = 100_000.0
        cfg      = make_config()
        effective = 0.75

        # What the engine target computes (from compute_greek_targets formula)
        vega_pct        = float(getattr(cfg, "VEGA_LIMIT_EQUITY_PCT_PER_VOL", 0.005))
        engine_limit    = vega_pct * (1.0 - effective * 0.5) * equity  # = 312.5

        # What the updated breach check computes at same effective
        _, breach_limit = vega_breach_check(
            equity_usd=equity, portfolio_vega=-200.0, cfg=cfg, effective=effective
        )

        assert breach_limit == pytest.approx(engine_limit, rel=1e-9), (
            f"Breach flag limit ({breach_limit}) must equal engine target limit ({engine_limit})"
        )

    # ------------------------------------------------------------------ #
    # Two-pass bootstrap: vb_bootstrap=False, vb_final=True edge case    #
    # ------------------------------------------------------------------ #

    def test_two_pass_edge_case_breach_fires_at_tighter_threshold(self):
        """
        Edge case: vega in the window (tightened_limit, un-tightened_limit).
        Bootstrap (effective=0) should NOT fire; tightened pass SHOULD fire.
        This confirms the two-pass design is correct for Option B.
        """
        cfg      = make_config()
        equity   = 100_000.0
        effective = 0.75
        # tightened limit = 312.5; un-tightened = 500
        # vega = -380: between limits - tightened fires, un-tightened does not
        vega = -380.0

        vb_bootstrap, _  = vega_breach_check(equity_usd=equity, portfolio_vega=vega,
                                              cfg=cfg, effective=0.0)
        vb_final, limit  = vega_breach_check(equity_usd=equity, portfolio_vega=vega,
                                              cfg=cfg, effective=effective)

        assert vb_bootstrap is False, (
            f"Un-tightened breach should NOT fire at vega={vega} (limit=500)"
        )
        assert vb_final is True, (
            f"Tightened breach SHOULD fire at vega={vega} (limit={limit:.1f})"
        )
        assert limit == pytest.approx(312.5, rel=1e-6)


# -----------------------------------------------------------------------
# Phase 5: Delta soft-band vega severity interaction
# -----------------------------------------------------------------------

class TestPhase5DeltaVegaSeverityInteraction:
    """
    Tests for Phase 5: The soft band now emits vega severity context in risk_note,
    and honours the opt-in DELTA_SOFT_BAND_VEGA_SEVERE_BYPASS config flag.

    Default behavior (bypass=False): soft band applies even when vega is severely
    below target - preserves the Request-5 over-hedging prevention intent.

    Opt-in behavior (bypass=True): when vega is severely below target, the soft band
    is skipped and the H-tightened hard band is used instead.
    """

    @staticmethod
    def _run_delta(delta_btc, vega, vega_target, hard_half, mm_pct=51.0, dd=-0.023,
                   mode="DEFENSIVE", bypass=False):
        from unittest.mock import patch
        from hedge_engine.actions.delta.delta_hedge import run

        gp = GreekProfile(
            delta_btc=delta_btc, gamma=-0.0001, vega=vega,
            equity_usd=100_000.0, spot_usd=85_000.0, mm_pct=mm_pct, dd=dd,
        )
        tgt = GreekTargets(
            delta_band_min=-hard_half, delta_band_max=hard_half,
            gamma_target=-0.0005, vega_target=vega_target,
            mode=mode, iv_hv_multiplier=1.0, hedge_ratio_H=0.75,
        )
        cfg = make_config(DELTA_SOFT_BAND_VEGA_SEVERE_BYPASS=bypass)
        snap = make_snapshot(portfolio_delta_btc=delta_btc, mm_pct=mm_pct, dd=dd, mode=mode)

        with patch(
            "hedge_engine.risk.xpm.xpm_simulator.simulate_action_impact",
            return_value={"mm_pct_after": mm_pct - 1.0}
        ):
            return run(
                greek_profile=gp, targets=tgt,
                gamma_suggestion=None, vega_suggestion=None,
                snapshot=snap, cfg=cfg, deribit=None,
            )

    # ------------------------------------------------------------------ #
    # Soft band applies when vega severe + bypass disabled (default)      #
    # ------------------------------------------------------------------ #

    def test_soft_band_applies_when_vega_severe_and_bypass_disabled(self):
        """
        Calm state (MM 51%, DD 2.3%, DEFENSIVE), vega=-2466 severely below
        target=-500.  With bypass=False (default), soft band ±0.30 still applies.
        This preserves the Request-5 behaviour: don't over-hedge at low MM/DD.
        """
        sug = self._run_delta(
            delta_btc=2.35, vega=-2466.0, vega_target=-500.0,
            hard_half=0.075, bypass=False,
        )
        # Soft band ±0.30 applies → hedge to soft edge 0.30 BTC
        assert sug.method == "perp"
        assert sug.size == pytest.approx(2.35 - 0.30, abs=0.01), (
            f"Expected soft band hedge ≈2.05 BTC, got {sug.size:.4f}"
        )
        assert "soft" in sug.rationale,  "rationale must say 'soft'"
        # risk_note should expose vega severity even though bypass is off
        assert "vega" in sug.risk_note.lower()
        assert "SEVERE" in sug.risk_note

    def test_soft_band_risk_note_includes_gap_pct(self):
        """
        When soft band fires, risk_note must include the vega gap percentage
        so operators can see how far vega is from its target.
        """
        sug = self._run_delta(
            delta_btc=2.35, vega=-2466.0, vega_target=-500.0,
            hard_half=0.075, bypass=False,
        )
        assert "%" in sug.risk_note, "risk_note must include vega gap percentage"
        # gap = max(0, -500 - (-2466)) / 500 = 1966/500 ≈ 393%
        assert "393" in sug.risk_note or "39" in sug.risk_note, (
            f"Expected ~393% gap in risk_note, got: {sug.risk_note}"
        )

    def test_soft_band_applies_when_vega_ok(self):
        """
        Calm DEFENSIVE state, vega=-200 (above target=-500, no breach).
        Soft band ±0.30 still applies - non-severe vega never blocks soft band.
        """
        sug = self._run_delta(
            delta_btc=2.35, vega=-200.0, vega_target=-500.0,
            hard_half=0.075, bypass=False,
        )
        assert sug.method == "perp"
        assert "soft" in sug.rationale
        # risk_note: gap = 0 (vega is ABOVE target, no gap), not severe
        assert "SEVERE" not in sug.risk_note

    # ------------------------------------------------------------------ #
    # Bypass enabled: hard band used when vega severe                     #
    # ------------------------------------------------------------------ #

    def test_hard_band_used_when_vega_severe_and_bypass_enabled(self):
        """
        Calm DEFENSIVE state, vega=-2466 severely below target=-500.
        With bypass=True the soft band is skipped → hard band ±0.075 applies.
        Hedge size reflects the tighter hard band edge 0.075, not soft 0.30.
        """
        sug = self._run_delta(
            delta_btc=2.35, vega=-2466.0, vega_target=-500.0,
            hard_half=0.075, bypass=True,
        )
        assert sug.method == "perp"
        # Hard band ±0.075 → hedge to 0.075 BTC edge; size ≈ 2.35 - 0.075 = 2.275
        assert sug.size == pytest.approx(2.35 - 0.075, abs=0.01), (
            f"Expected hard band hedge ≈2.275 BTC, got {sug.size:.4f}"
        )
        assert "soft" not in sug.rationale, "bypass active → rationale must NOT say 'soft'"

    def test_bypass_enabled_but_vega_ok_still_uses_soft_band(self):
        """
        bypass=True but vega is NOT severe (gap < 75% of target).
        Soft band should still apply - bypass only fires when vega IS severe.
        """
        # vega=-200, target=-500: gap = max(0, -500-(-200)) / 500 = 300/500 = 60% < 75%
        sug = self._run_delta(
            delta_btc=2.35, vega=-200.0, vega_target=-500.0,
            hard_half=0.075, bypass=True,
        )
        assert sug.method == "perp"
        assert "soft" in sug.rationale, (
            "bypass=True but vega not severe → soft band must still apply"
        )

    def test_bypass_risk_note_when_active(self):
        """
        When bypass fires, risk_note must describe the bypass reason clearly.
        """
        sug = self._run_delta(
            delta_btc=2.35, vega=-2466.0, vega_target=-500.0,
            hard_half=0.075, bypass=True,
        )
        assert "bypass" in sug.risk_note.lower() or "severe" in sug.risk_note.lower(), (
            f"Expected bypass/severe in risk_note, got: {sug.risk_note}"
        )
