# hedge_engine/tests/test_bundle_scoring.py
"""Phase 4: Test survival-first bundle scoring."""
from __future__ import annotations

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

from hedge_engine.risk.xpm.bundle_acceptance import score_bundle_survival
from hedge_engine.tests.conftest import make_config, make_flags, make_before_dict, make_after_dict


def test_stress_improvement_dominates():
    """Bundle with better stress improvement should score higher than one with better MM."""
    cfg = make_config()
    flags = make_flags()
    before = make_before_dict(stress_dd=-0.06, mm_pct=75.0)

    # Bundle A: great stress improvement, slight MM worsening
    after_a = make_after_dict(stress_dd_after=-0.02, mm_pct_after=76.0, delta_after=1.0, vega_after=-2000.0)
    score_a = score_bundle_survival(before=before, after=after_a, flags=flags, cfg=cfg, n_actions=2)

    # Bundle B: moderate stress improvement, great MM improvement
    after_b = make_after_dict(stress_dd_after=-0.05, mm_pct_after=60.0, delta_after=1.0, vega_after=-2000.0)
    score_b = score_bundle_survival(before=before, after=after_b, flags=flags, cfg=cfg, n_actions=2)

    assert score_a.total > score_b.total, f"Stress-focused bundle should win: {score_a.total} vs {score_b.total}"


def test_simpler_bundle_preferred():
    """With equal improvements, fewer actions should score slightly higher."""
    cfg = make_config()
    flags = make_flags()
    before = make_before_dict(stress_dd=-0.06)
    after = make_after_dict(stress_dd_after=-0.03)

    score_1 = score_bundle_survival(before=before, after=after, flags=flags, cfg=cfg, n_actions=1)
    score_3 = score_bundle_survival(before=before, after=after, flags=flags, cfg=cfg, n_actions=3)

    assert score_1.total > score_3.total


def test_score_components_populated():
    """Score should have all 6 component values."""
    cfg = make_config()
    flags = make_flags()
    before = make_before_dict()
    after = make_after_dict()

    score = score_bundle_survival(before=before, after=after, flags=flags, cfg=cfg, n_actions=2)
    assert "stress_improve" in score.components
    assert "ks_headroom" in score.components
    assert "mm_improve" in score.components
    assert "delta_reduce" in score.components
    assert "vega_reduce" in score.components
    assert "simplicity" in score.components


def test_score_total_in_range():
    """Total score should be between 0 and 1."""
    cfg = make_config()
    flags = make_flags()
    before = make_before_dict()
    after = make_after_dict()

    score = score_bundle_survival(before=before, after=after, flags=flags, cfg=cfg, n_actions=2)
    assert 0.0 <= score.total <= 1.0


def test_no_improvement_low_score():
    """A bundle that doesn't improve anything should score low."""
    cfg = make_config()
    flags = make_flags()
    before = make_before_dict(stress_dd=-0.06, mm_pct=72.0, delta=3.5, vega=-2500.0)
    after = make_after_dict(
        stress_dd_after=-0.06,  # no improvement
        mm_pct_after=72.0,       # no improvement
        delta_after=3.5,         # no improvement
        vega_after=-2500.0,      # no improvement
    )

    score = score_bundle_survival(before=before, after=after, flags=flags, cfg=cfg, n_actions=3)
    assert score.total < 0.3, f"No-improvement bundle scored too high: {score.total}"


if __name__ == "__main__":
    for name, func in list(globals().items()):
        if name.startswith("test_") and callable(func):
            try:
                func()
                print(f"  PASS  {name}")
            except AssertionError as e:
                print(f"  FAIL  {name}: {e}")
            except Exception as e:
                print(f"  ERROR {name}: {e}")
