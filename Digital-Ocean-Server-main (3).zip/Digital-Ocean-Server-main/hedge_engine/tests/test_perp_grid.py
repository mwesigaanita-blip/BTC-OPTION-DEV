# hedge_engine/tests/test_perp_grid.py
"""Phase 7: Test perp hedge grid search."""
from __future__ import annotations

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

from hedge_engine.actions.delta.delta_hedge import propose_perp_hedge_grid, _get_delta_band
from hedge_engine.tests.conftest import make_config, make_flags, make_snapshot


def test_grid_finds_entry_into_band():
    """Grid search should find smallest SELL entering DANGER band (-0.2, +0.2)."""
    snapshot = make_snapshot(portfolio_delta_btc=3.0, mode="DANGER", equity_usd=100000, spot_index_usd=85000)
    flags = make_flags()
    cfg = make_config()

    result = propose_perp_hedge_grid(snapshot=snapshot, flags=flags, cfg=cfg)
    assert result is not None
    assert result.side.value == "SELL"
    assert result.qty_btc > 0
    # Projected delta should be in band
    projected = 3.0 - result.qty_btc
    assert -0.2 <= projected <= 0.2 or result.qty_btc >= 3.0  # might need full neutralize


def test_no_action_when_in_band():
    """If delta is already in band, no action needed."""
    snapshot = make_snapshot(portfolio_delta_btc=0.1, mode="DANGER", equity_usd=100000, spot_index_usd=85000)
    flags = make_flags()
    cfg = make_config()

    result = propose_perp_hedge_grid(snapshot=snapshot, flags=flags, cfg=cfg)
    assert result is None


def test_normal_mode_no_band():
    """NORMAL mode should not have a delta band."""
    cfg = make_config()
    band = _get_delta_band("NORMAL", cfg)
    assert band is None


def test_emergency_tight_band():
    """EMERGENCY mode should have tight band (-0.05, +0.05)."""
    cfg = make_config()
    band = _get_delta_band("EMERGENCY", cfg)
    assert band == (-0.05, 0.05)


def test_grid_meta_populated():
    """Grid result should contain debug metadata."""
    snapshot = make_snapshot(portfolio_delta_btc=2.0, mode="DANGER", equity_usd=100000, spot_index_usd=85000)
    flags = make_flags()
    cfg = make_config()

    result = propose_perp_hedge_grid(snapshot=snapshot, flags=flags, cfg=cfg)
    if result:
        assert "method" in result.meta
        assert result.meta["method"] == "grid_search"
        assert "grid_tested" in result.meta
        assert "band" in result.meta


def test_max_btc_clamp():
    """Grid should respect MAX_SINGLE_DELTA_HEDGE_BTC."""
    snapshot = make_snapshot(portfolio_delta_btc=10.0, mode="EMERGENCY", equity_usd=100000, spot_index_usd=85000)
    flags = make_flags()
    cfg = make_config()

    result = propose_perp_hedge_grid(snapshot=snapshot, flags=flags, cfg=cfg)
    if result:
        assert result.qty_btc <= cfg.MAX_SINGLE_DELTA_HEDGE_BTC


if __name__ == "__main__":
    for name, func in list(globals().items()):
        if name.startswith("test_") and callable(func):
            try:
                func()
                print(f"  PASS  {name}")
            except AssertionError as e:
                print(f"  FAIL  {name}: {e}")
            except Exception as e:
                print(f"  ERROR {name}: {e}")
