# hedge_engine/tests/test_reason_coverage.py
"""Phase 3: Test reason-to-action linkage."""
from __future__ import annotations

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

from hedge_engine.risk.xpm.bundle_acceptance import evaluate_reason_coverage
from hedge_engine.tests.conftest import make_config, make_flags, make_before_dict, make_after_dict


def test_vega_breach_covered():
    """Vega improves by >5% → covered."""
    cfg = make_config()
    flags = make_flags(vega_breach=True)
    before = make_before_dict(vega=-2500.0)
    after = make_after_dict(vega_after=-2200.0)  # 12% reduction in abs(vega)

    coverages, uncovered = evaluate_reason_coverage(
        mode_reasons="vega_breach",
        before=before, after=after, flags=flags, cfg=cfg,
    )
    assert len(coverages) == 1
    assert coverages[0].covered
    assert len(uncovered) == 0


def test_vega_breach_not_covered():
    """Vega improves by <5% → uncovered."""
    cfg = make_config()
    flags = make_flags(vega_breach=True)
    before = make_before_dict(vega=-2500.0)
    after = make_after_dict(vega_after=-2450.0)  # only 2% improvement

    coverages, uncovered = evaluate_reason_coverage(
        mode_reasons="vega_breach",
        before=before, after=after, flags=flags, cfg=cfg,
    )
    assert len(coverages) == 1
    assert not coverages[0].covered
    assert "vega_breach" in uncovered


def test_compound_reasons_all_covered():
    """Multiple reasons, all covered."""
    cfg = make_config()
    flags = make_flags(vega_breach=True)
    before = make_before_dict(stress_dd=-0.06, vega=-2500.0)
    after = make_after_dict(stress_dd_after=-0.04, vega_after=-2000.0)

    coverages, uncovered = evaluate_reason_coverage(
        mode_reasons="dd>=6% | vega_breach",
        before=before, after=after, flags=flags, cfg=cfg,
    )
    assert len(coverages) == 2
    assert all(c.covered for c in coverages)
    assert len(uncovered) == 0


def test_compound_reasons_partial_coverage():
    """DD covered but vega not covered."""
    cfg = make_config()
    flags = make_flags(vega_breach=True)
    before = make_before_dict(stress_dd=-0.06, vega=-2500.0)
    after = make_after_dict(stress_dd_after=-0.04, vega_after=-2480.0)  # vega barely improved

    coverages, uncovered = evaluate_reason_coverage(
        mode_reasons="dd>=6% | vega_breach",
        before=before, after=after, flags=flags, cfg=cfg,
    )
    assert len(coverages) == 2
    dd_cov = [c for c in coverages if c.reason.startswith("dd")]
    vega_cov = [c for c in coverages if "vega" in c.reason]
    assert dd_cov[0].covered
    assert not vega_cov[0].covered
    assert len(uncovered) == 1


def test_gamma_breach_coverage():
    """Gamma improves by >5% → covered."""
    cfg = make_config()
    flags = make_flags(gamma_budget_breach=True)
    before = make_before_dict(gamma=-0.0003)
    after = make_after_dict(gamma_after=-0.00025)  # ~17% improvement

    coverages, uncovered = evaluate_reason_coverage(
        mode_reasons="gamma_breach",
        before=before, after=after, flags=flags, cfg=cfg,
    )
    assert len(coverages) == 1
    assert coverages[0].covered


def test_mm_reason_coverage():
    """MM must decrease when it's a reason."""
    cfg = make_config()
    flags = make_flags()
    before = make_before_dict(mm_pct=80.0)
    after = make_after_dict(mm_pct_after=82.0)  # worsened

    coverages, uncovered = evaluate_reason_coverage(
        mode_reasons="mm>=80",
        before=before, after=after, flags=flags, cfg=cfg,
    )
    assert len(coverages) == 1
    assert not coverages[0].covered
    assert "mm>=80" in uncovered


def test_speed_trigger_coverage():
    """Speed trigger → delta must decrease by 10%."""
    cfg = make_config()
    flags = make_flags(speed_trigger=True)
    before = make_before_dict(delta=3.5)
    after = make_after_dict(delta_after=2.0)  # ~43% reduction

    coverages, uncovered = evaluate_reason_coverage(
        mode_reasons="speed_trigger",
        before=before, after=after, flags=flags, cfg=cfg,
    )
    assert len(coverages) == 1
    assert coverages[0].covered


def test_empty_reasons():
    """No reasons → empty coverage, no failures."""
    cfg = make_config()
    flags = make_flags()
    before = make_before_dict()
    after = make_after_dict()

    coverages, uncovered = evaluate_reason_coverage(
        mode_reasons="",
        before=before, after=after, flags=flags, cfg=cfg,
    )
    assert len(coverages) == 0
    assert len(uncovered) == 0


if __name__ == "__main__":
    for name, func in list(globals().items()):
        if name.startswith("test_") and callable(func):
            try:
                func()
                print(f"  PASS  {name}")
            except AssertionError as e:
                print(f"  FAIL  {name}: {e}")
            except Exception as e:
                print(f"  ERROR {name}: {e}")
