# hedge_engine/notifications/notifier.py
from __future__ import annotations

import json
import os
import time
from typing import Any, Dict, List, Optional

import requests

from hedge_engine.core.models import ActionBundle, HedgeTick
from hedge_engine.notifications.formatter import (
    format_bundle, format_no_valid_bundle, format_hedge_tick,
)
from hedge_engine.settings.config import EngineConfig


# Urgency → cooldown seconds (mirrors AlertPolicy)
_COOLDOWNS = {
    "INFO":      24 * 3600,
    "WARNING":   10 * 60,
    "URGENT":    3 * 60,
    "EMERGENCY": 60,
}

_MODE_TO_URGENCY = {
    "NORMAL":    "INFO",
    "DEFENSIVE": "WARNING",
    "DANGER":    "URGENT",
    "EMERGENCY": "EMERGENCY",
}


class TelegramNotifier:
    def __init__(self, bot_token: str, chat_ids: List[str]):
        self.bot_token = bot_token
        self.chat_ids = [c for c in chat_ids if c]   # filter empty
        self._last_sent: Dict[str, float] = {}        # urgency -> unix ts

    @classmethod
    def from_env(cls) -> "TelegramNotifier":
        token = os.getenv("TELEGRAM_HEDGE_BOT_TOKEN", "").strip()
        if not token:
            token = os.getenv("TELEGRAM_BOT_TOKEN", "").strip()
        chat_ids = [
            os.getenv("REMO_CHAT_ID", "").strip(),
            os.getenv("ANDRES_CHAT_ID", "").strip(),
            os.getenv("AHMED_CHAT_ID", "").strip(),
        ]
        return cls(bot_token=token, chat_ids=chat_ids)

    def _is_on_cooldown(self, urgency: str) -> bool:
        cooldown = _COOLDOWNS.get(urgency, 600)
        last = self._last_sent.get(urgency, 0.0)
        return (time.time() - last) < cooldown

    def send(
        self,
        text: str,
        urgency: str = "INFO",
        *,
        bypass_cooldown: bool = False,
        parse_mode: Optional[str] = None,
    ) -> bool:
        """
        Send text to all chat_ids if not on cooldown.
        EMERGENCY bypasses cooldown and repeats every 60s.

        ``bypass_cooldown=True`` disables the per-urgency cooldown entirely
        and does NOT update the cooldown clock - used by portfolio_analysis
        which already de-duplicates at the rule layer.
        ``parse_mode`` is forwarded to Telegram (e.g. "HTML", "MarkdownV2").

        Returns True if at least one message was sent.
        """
        if not self.bot_token or not self.chat_ids:
            return False

        if not bypass_cooldown and self._is_on_cooldown(urgency):
            return False

        sent = False
        url = f"https://api.telegram.org/bot{self.bot_token}/sendMessage"
        for chat_id in self.chat_ids:
            payload: Dict[str, Any] = {"chat_id": chat_id, "text": text}
            if parse_mode:
                payload["parse_mode"] = parse_mode
            try:
                r = requests.post(url, json=payload, timeout=10)
                r.raise_for_status()
                sent = True
            except Exception:
                pass   # Telegram failure never blocks the engine

        if sent and not bypass_cooldown:
            self._last_sent[urgency] = time.time()

        return sent

    def notify_bundle(self, bundle: ActionBundle) -> bool:
        if getattr(bundle, "no_valid_bundle", False):
            text = format_no_valid_bundle(bundle)
            return self.send(text, urgency="EMERGENCY")
        urgency = _MODE_TO_URGENCY.get((bundle.mode or "NORMAL").upper(), "INFO")
        text = format_bundle(bundle)
        return self.send(text, urgency=urgency)

    def notify_hedge_tick(self, tick: HedgeTick) -> bool:
        """
        Send Telegram notification for a HedgeTick (sub-engine pipeline output).

        Urgency is derived from the mode in tick.targets.mode.
        Only sends if at least one sub-engine has a non-no_action suggestion,
        OR if any simulation failed (potential manual intervention needed).
        """
        mode = (tick.targets.mode or "NORMAL").upper()

        # Check if any suggestion has actual actions
        suggestions = [tick.suggestion_gamma, tick.suggestion_vega, tick.suggestion_delta]
        has_action     = any(s and s.method != "no_action" for s in suggestions)
        has_sim_fail   = any(s and not s.simulation_ok for s in suggestions)

        if not has_action and not has_sim_fail:
            return False  # nothing to report

        # Escalate urgency to EMERGENCY if simulation failed
        urgency = _MODE_TO_URGENCY.get(mode, "INFO")
        if has_sim_fail:
            urgency = "EMERGENCY"

        text = format_hedge_tick(tick)
        return self.send(text, urgency=urgency)