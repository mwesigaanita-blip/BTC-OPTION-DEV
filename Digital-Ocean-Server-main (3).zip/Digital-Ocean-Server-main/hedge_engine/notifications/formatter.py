# hedge_engine/notifications/formatter.py
from __future__ import annotations

from hedge_engine.core.models import ActionBundle, PortfolioSnapshot, HedgeTick, Suggestion
from hedge_engine.risk.risk_checks import RiskFlags

MODE_ICON = {
    "NORMAL": "🟢",
    "DEFENSIVE": "🟠",
    "DANGER": "🔴",
    "EMERGENCY": "🚨",
}


def format_bundle(bundle: ActionBundle) -> str:
    """
    Plain-text Telegram message for a bundle.

    Example:
      🔴 DANGER | Reasons: mm>=83 | vega_breach

      ACTIONS:
      1. SELL 4.0000 BTC BTC-PERPETUAL [HEDGE_DELTA]
      2. BUY 1 contracts BTC-27JUN25-70000-P [HEDGE_TAIL]

      BEFORE -> AFTER
      Net Delta:  +6.20 -> +2.10 BTC
      Vega:   -18,400 -> -14,200
      MM%:    83.0% -> 76.0%
    """
    mode = (bundle.mode or "NORMAL").upper()
    icon = MODE_ICON.get(mode, "🛡️")

    before = bundle.before
    after = bundle.after_est

    lines = [
        f"{icon} {mode} | Reasons: {bundle.reason}",
        "",
        "ACTIONS:",
    ]
    for i, action in enumerate(bundle.actions, 1):
        lines.append(f"{i}. {action.cmd}")

    lines.append("")

    after_sim = bundle.debug.get("after_sim", {}) or {}
    sim_ok = bool(after_sim.get("sim_ok", True))
    sim_error = after_sim.get("sim_error")

    if not sim_ok:
        lines += [
            "BEFORE -> AFTER",
            f"Net Delta:  {before.delta_btc:+.2f} -> n/a",
            f"Vega:   {before.vega:,.0f} -> n/a",
            f"MM%:    {before.mm_pct:.1f}% -> n/a",
        ]
        if sim_error:
            lines.append(f"Simulation error: {sim_error}")
        lines.append("Note: Simulation unavailable; AFTER metrics not computed.")
    else:
        lines += [
            "BEFORE -> AFTER",
            f"Net Delta:  {before.delta_btc:+.2f} -> {after.delta_btc:+.2f} BTC",
            f"Vega:   {before.vega:,.0f} -> {after.vega:,.0f}",
            f"MM%:    {before.mm_pct:.1f}% -> {after.mm_pct:.1f}%",
        ]

        stress_after = after_sim.get("stress_dd_after")
        if stress_after is not None:
            lines.append(f"Stress: -> {stress_after*100:.1f}% DD (projected worst)")

    return "\n".join(lines)


def format_no_valid_bundle(bundle: ActionBundle) -> str:
    """
    Format a NO_VALID_BUNDLE alert for Telegram.
    Shown when all escalation tiers fail to produce an acceptable hedge bundle.
    """
    debug = bundle.debug or {}
    tiers_tested = debug.get("escalation_tiers_tested", [])
    tier_names = [t.get("tier", "?") for t in tiers_tested]
    top_rejections = debug.get("rejection_reasons", [])

    lines = [
        f"{MODE_ICON.get('EMERGENCY', '🚨')} NO VALID HEDGE FOUND",
        f"Reasons: {bundle.reason}",
        "",
        f"Tiers tested: {', '.join(tier_names) or 'none'}",
    ]

    if top_rejections:
        lines.append("Top rejections:")
        for r in top_rejections[:5]:
            lines.append(f"  - {r}")

    lines += [
        "",
        "Manual intervention required.",
        f"DD: {bundle.before.mm_pct:.1f}% MM | Delta: {bundle.before.delta_btc:+.2f} BTC",
    ]

    return "\n".join(lines)


def format_alert(flags: RiskFlags, mode: str) -> str:
    """Short status message for INFO/WARNING urgency levels."""
    icon = MODE_ICON.get((mode or "NORMAL").upper(), "🛡️")
    return (
        f"{icon} MHE | {mode} | "
        f"DD {flags.dd_worst*100:.1f}% | "
        f"MM {flags.mm_pct:.0f}%"
    )



_METHOD_DISPLAY = {
    "buy_option":     "open new",
    "sell_option":    "sell offset",
    "perp":           "perp",
    "close_existing": "close short",
    "no_action":      "no action",
}


def _fmt_suggestion_block(label: str, s: Optional[Suggestion]) -> list:
    """Format one sub-engine suggestion block for Telegram."""
    if s is None:
        return [f"── {label}: no suggestion ──"]

    lines = [f"── {label} ──"]
    if s.method == "no_action":
        lines.append(f"  No action: {s.rationale}")
        return lines

    dir_icon = "▲" if s.direction == "buy" else "▼"
    fb_tag = f" [fallback-tier{s.fallback_tier}]" if s.fallback_used else ""

    # Action classification label
    classification = getattr(s, "action_classification", "no_action")
    _cls_labels = {
        "proper_hedge": "[PROPER HEDGE]",
        "partial_hedge": "[PARTIAL HEDGE]",
        "mm_relief": "[MM-RELIEF]",
        "fallback_last_resort": "[FALLBACK]",
    }
    cls_tag = f" {_cls_labels[classification]}" if classification in _cls_labels else ""

    method_display = _METHOD_DISPLAY.get(s.method, s.method)
    lines.append(f"  {dir_icon} {s.direction.upper()} ({method_display}) {s.size:.4g}x {s.instrument}{fb_tag}{cls_tag}")
    lines.append(f"  ΔΔ={s.delta_impact:+.4f}  Δγ={s.gamma_impact:+.6f}  Δν={s.vega_impact:+.2f}")
    lines.append(f"  post-MM: {s.post_mm_pct:.1f}%")

    # Delta target-reached indicator
    if s.engine == "delta":
        size_clamped = getattr(s, "size_clamped", False)
        target_reached = getattr(s, "target_reached", True)
        if target_reached:
            lines.append("  Target reached")
        elif size_clamped:
            lines.append(f"  Partial (capped at {s.size:.4g} BTC)")

    if not s.simulation_ok:
        lines.append("  ⚠️ simulation failed")
    if s.risk_note:
        lines.append(f"  note: {s.risk_note}")
    return lines


def _compute_tick_quality(tick: HedgeTick, post_delta: float, post_gamma: float, post_vega: float) -> str:
    """Compute a top-level outcome quality label for the combined hedge tick.

    delta_ok uses suggestion.target_reached when available so that calm-state soft
    targeting (wider band) is reflected correctly - not the hard H-tightened band.
    """
    tgt = tick.targets
    active = [
        s for s in [tick.suggestion_gamma, tick.suggestion_vega, tick.suggestion_delta]
        if s and s.method != "no_action"
    ]
    if not active:
        return "NO_ACTION_NEEDED"

    # Use delta suggestion's own target_reached flag (honours soft vs hard band).
    # Fall back to hard-band comparison when delta took no action or suggestion unavailable.
    d_sug = tick.suggestion_delta
    if d_sug and d_sug.method != "no_action":
        delta_ok = bool(getattr(d_sug, "target_reached", False))
    else:
        delta_ok = tgt.delta_band_min <= post_delta <= tgt.delta_band_max

    gamma_ok = post_gamma >= tgt.gamma_target
    vega_ok  = post_vega  >= tgt.vega_target
    any_fb   = tick.any_fallback_triggered
    if not any_fb and delta_ok and gamma_ok and vega_ok:
        return "FULL_HEDGE"
    if any_fb and not delta_ok and not vega_ok:
        return "FALLBACK_BREACH_REMAINS"
    if any_fb:
        return "FALLBACK_PARTIAL"
    return "PARTIAL_HEDGE"


def format_hedge_tick(tick: HedgeTick) -> str:
    """
    Telegram message for one HedgeTick (three sub-engine suggestions).

    Structure:
      Header:  mode icon + DD + MM%
      Block 1: GAMMA HEDGE
      Block 2: VEGA HEDGE
      Block 3: DELTA HEDGE
      Footer:  COMBINED state before→after
    """
    from typing import Optional as _Opt

    mode = (tick.targets.mode or "NORMAL").upper()
    icon = MODE_ICON.get(mode, "🛡️")
    gp   = tick.greek_profile
    cps  = tick.combined_post_state or {}

    dd_pct = getattr(gp, "dd", 0.0) * 100  # fraction → percent; negative when in drawdown
    lines = [
        f"{icon} {mode} | Delta {gp.delta_btc:+.2f} BTC | MM {gp.mm_pct:.1f}% | DD {dd_pct:.1f}%",
        "",
    ]
    lines += _fmt_suggestion_block("GAMMA HEDGE", tick.suggestion_gamma)
    lines.append("")
    lines += _fmt_suggestion_block("VEGA HEDGE",  tick.suggestion_vega)
    lines.append("")
    lines += _fmt_suggestion_block("DELTA HEDGE", tick.suggestion_delta)
    lines.append("")

    # Combined footer
    post_mm    = cps.get("mm_pct",   gp.mm_pct)
    post_delta = cps.get("delta",    gp.delta_btc)
    post_gamma = cps.get("gamma",    gp.gamma)
    post_vega  = cps.get("vega",     gp.vega)

    quality = _compute_tick_quality(tick, post_delta, post_gamma, post_vega)
    lines += [
        "── COMBINED ──",
        f"  Quality: {quality}",
        f"  Delta: {gp.delta_btc:+.4f} → {post_delta:+.4f} BTC",
        f"  Gamma: {gp.gamma:+.6f} → {post_gamma:+.6f}",
        f"  Vega:  {gp.vega:+.2f} → {post_vega:+.2f}",
        f"  MM:    {gp.mm_pct:.1f}% → {post_mm:.1f}%",
    ]
    if tick.any_fallback_triggered:
        lines.append("  ⚠️ fallback triggered on ≥1 engine")

    # Remaining breach summary
    # For delta: use suggestion.target_reached to honour soft vs hard band.
    breaches_remaining = []
    tgt = tick.targets
    _d_sug = tick.suggestion_delta
    if _d_sug and _d_sug.method != "no_action":
        _delta_breach = not bool(getattr(_d_sug, "target_reached", False))
        _delta_breach_label = (
            f"delta {post_delta:+.4f} outside effective band "
            f"(target_reached=False, hard band [{tgt.delta_band_min:.3f}, {tgt.delta_band_max:.3f}])"
        )
    else:
        _delta_breach = not (tgt.delta_band_min <= post_delta <= tgt.delta_band_max)
        _delta_breach_label = f"delta {post_delta:+.4f} outside [{tgt.delta_band_min:.3f}, {tgt.delta_band_max:.3f}]"
    if _delta_breach:
        breaches_remaining.append(_delta_breach_label)
    if post_gamma < tgt.gamma_target:
        breaches_remaining.append(f"gamma {post_gamma:.6f} < target {tgt.gamma_target:.6f}")
    if post_vega < tgt.vega_target:
        breaches_remaining.append(f"vega {post_vega:.2f} < target {tgt.vega_target:.2f}")
    if breaches_remaining:
        lines.append("  ⚠️ remaining breaches:")
        for b in breaches_remaining:
            lines.append(f"    - {b}")

    return "\n".join(lines)


def format_heartbeat(snapshot: PortfolioSnapshot) -> str:
    """Daily INFO heartbeat: equity, DD, mode, tail hedge status."""
    from hedge_engine.actions.convexity.tail_hedge import check_tail_hedge_status

    tail = check_tail_hedge_status(snapshot.positions)
    tail_str = (
        f"✅ {tail['instrument_name']} ({tail['dte_days']:.0f}d)"
        if tail["has_tail_hedge"]
        else "❌ none"
    )
    dd_pct = snapshot.dd * 100
    return (
        f"💓 MHE Heartbeat\n"
        f"Equity: ${snapshot.total_equity_usd:,.0f}\n"
        f"DD: {dd_pct:.2f}%\n"
        f"MM%: {snapshot.mm_pct:.1f}%\n"
        f"Mode: {snapshot.mode}\n"
        f"Tail hedge: {tail_str}"
    )
