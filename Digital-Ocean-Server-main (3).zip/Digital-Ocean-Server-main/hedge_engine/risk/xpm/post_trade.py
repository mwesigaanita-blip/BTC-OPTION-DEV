# hedge_engine/risk/xpm/post_trade.py
"""
Phase 6: Reconciliation layer.

Ensures the local stress engine runs on the Deribit-based post-trade state,
not on the stale pre-trade state.

Flow per candidate:
  1. Build candidate actions
  2. Call Deribit simulate_portfolio → PostTradeState
  3. Feed PostTradeState into local fast stress
  4. Compute stressed PnL / projected equity / projected DD
  5. Return unified result with full provenance
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

from hedge_engine.core.models import CandidateAction, PortfolioSnapshot
from hedge_engine.core.portfolio_state import (
    CurrentPortfolioState,
    PostTradeState,
    StressedState,
    build_post_trade_state,
    _sf,
)
from hedge_engine.data.deribit_client import DeribitClient
from hedge_engine.settings.config import EngineConfig

logger = logging.getLogger("hedge_engine.post_trade")


def simulate_and_stress_candidate(
    *,
    deribit: DeribitClient,
    snapshot: PortfolioSnapshot,
    actions: List[CandidateAction],
    cfg: EngineConfig,
    currency: str = "BTC",
) -> Dict[str, Any]:
    """
    Full reconciled simulation path for one candidate bundle.

    1. Build simulated_positions from actions
    2. Call Deribit simulate_portfolio (current-market post-trade)
    3. Extract PostTradeState
    4. Run local fast stress with PostTradeState as base
    5. Return unified result with provenance

    This replaces the direct simulate_bundle_impact → stress path
    with a properly reconciled flow.
    """
    from hedge_engine.core.enums import Side
    from hedge_engine.risk.xpm.xpm_simulator import (
        _amount_for_simulation,
        _normalize_instrument_name,
        _is_option_instrument,
        _safe_float,
        _mm_pct,
        _extract_greeks,
        _extract_post_trade_equity,
    )
    from hedge_engine.risk.stress.stress_fast import run_stress_fast

    # ── Step 1: Build simulated_positions dict ──
    sim_positions: Dict[str, float] = {}
    for action in actions:
        if action.qty_contracts is not None:
            amount = float(action.qty_contracts)
        elif action.qty_btc is not None:
            amount = _amount_for_simulation(
                instrument_name=action.instrument_name,
                qty_btc=float(action.qty_btc),
                spot_index_usd=float(snapshot.spot_index_usd),
            )
        else:
            continue
        signed = amount if action.side == Side.BUY else -amount
        inst = _normalize_instrument_name(action.instrument_name, currency)
        sim_positions[inst] = sim_positions.get(inst, 0.0) + signed

    # ── Step 2: Call Deribit simulate_portfolio ──
    sim_ok = True
    sim_error: Optional[str] = None
    raw: Dict[str, Any] = {}

    try:
        raw = deribit.simulate_portfolio(
            currency=currency,
            simulated_positions=sim_positions if sim_positions else None,
        )
    except Exception as e:
        sim_ok = False
        sim_error = f"{e} | instruments={list(sim_positions.keys())}"

    if sim_ok and sim_positions and not raw:
        sim_ok = False
        sim_error = "simulate_portfolio returned empty response"

    # ── Step 3: Extract post-trade metrics ──
    mm = _safe_float(raw.get("projected_maintenance_margin") or raw.get("maintenance_margin"))
    mb = _safe_float(raw.get("margin_balance"))
    im = _safe_float(raw.get("projected_initial_margin") or raw.get("initial_margin"))
    mm_pct_after = _mm_pct(mm, mb) if mb > 0 else snapshot.mm_pct

    greeks = _extract_greeks(raw)
    delta_after = greeks["delta"] if sim_ok and greeks["delta"] is not None else snapshot.portfolio_delta_btc
    gamma_after = greeks["gamma"] if sim_ok and greeks["gamma"] is not None else snapshot.portfolio_gamma
    vega_after = greeks["vega"] if sim_ok and greeks["vega"] is not None else snapshot.portfolio_vega

    equity_after = _extract_post_trade_equity(raw, snapshot.total_equity_usd, snapshot.spot_index_usd)

    # ── Step 4: Run local fast stress with POST-TRADE state ──
    stress_after = run_stress_fast(
        equity_usd=equity_after,         # POST-TRADE equity from Deribit
        hwm_usd=snapshot.hwm_usd,
        spot_index_usd=snapshot.spot_index_usd,
        delta_btc=delta_after,           # POST-TRADE delta from Deribit
        gamma=gamma_after,               # POST-TRADE gamma from Deribit
        vega_usd_per_vol=vega_after,     # POST-TRADE vega from Deribit
        scenarios=list(cfg.stress_scenarios),
        dd_override_threshold=cfg.FAST_STRESS_OVERRIDE_DD,
        regime="NORMAL",
    )

    stress_dd_after = min(
        (_safe_float(s.get("projected_dd_worst") if isinstance(s, dict) else s.projected_dd_worst)
         for s in (stress_after.scenarios or {}).values()),
        default=0.0,
    )

    # ── Step 5: Build unified result ──
    mm_safe = mm_pct_after < cfg.mm_critical_pct
    stress_improves = stress_dd_after >= snapshot.dd

    # Per-scenario detail for debugging
    scenario_details = {}
    for sname, sresult in (stress_after.scenarios or {}).items():
        if isinstance(sresult, dict):
            scenario_details[sname] = {
                "projected_dd_worst": sresult.get("projected_dd_worst"),
                "projected_equity_usd": sresult.get("projected_equity_usd"),
                "pnl_total_usd": sresult.get("pnl_total_usd"),
            }

    return {
        # Core metrics
        "mm_pct_after": mm_pct_after,
        "im_pct_after": _mm_pct(im, mb) if mb > 0 else 0.0,
        "delta_after": delta_after,
        "gamma_after": gamma_after,
        "vega_after": vega_after,
        "equity_after": equity_after,
        "stress_dd_after": stress_dd_after,
        "mm_safe": mm_safe,
        "stress_improves": stress_improves,
        "approved": mm_safe,

        # Simulation status
        "sim_ok": sim_ok,
        "sim_error": sim_error,
        "sim_raw": raw,
        "simulated_positions": sim_positions,

        # Source provenance
        "after_est_source": "simulate" if sim_ok else "fallback",
        "delta_after_source": "simulate" if sim_ok and greeks["delta"] is not None else "fallback",
        "gamma_after_source": "simulate" if sim_ok and greeks["gamma"] is not None else "fallback",
        "vega_after_source": "simulate" if sim_ok and greeks["vega"] is not None else "fallback",
        "equity_after_source": "simulate" if sim_ok and equity_after != snapshot.total_equity_usd else "fallback",

        # Stress detail
        "stress_scenario_details": scenario_details,
        "stress_base_equity_usd": equity_after,
        "stress_base_source": "post_trade_deribit" if sim_ok else "fallback_pre_trade",
    }
