# hedge_engine/risk/xpm/xpm_simulator.py
#
# Uses private/simulate_portfolio (same endpoint as MM_test.py) which returns
# full projected margin + Greeks in one call - far richer than get_margins.
from __future__ import annotations

from typing import Any, Dict, List, Optional

from hedge_engine.core.enums import Side
from hedge_engine.core.models import CandidateAction, PortfolioSnapshot
from hedge_engine.data.deribit_client import DeribitClient
from hedge_engine.settings.config import EngineConfig


def _safe_float(v: Any, default: float = 0.0) -> float:
    try:
        if v is None:
            return default
        return float(v)
    except Exception:
        return default


def _extract_scalar_or_map_value(obj: Dict[str, Any], key: str) -> Optional[float]:
    value = obj.get(key)
    if value is None:
        return None
    if isinstance(value, dict):
        for nested_value in value.values():
            try:
                return float(nested_value)
            except Exception:
                continue
        return None
    try:
        return float(value)
    except Exception:
        return None


def _extract_greeks(sim: Dict[str, Any]) -> Dict[str, Optional[float]]:
    """
    Extract delta/gamma/vega from simulate_portfolio response.
    Tries multiple key variants (Deribit response varies by account type).
    """
    def pick(keys: List[str]) -> Optional[float]:
        for k in keys:
            value = _extract_scalar_or_map_value(sim, k)
            if value is not None:
                return value
        for container in ("result", "portfolio", "risk", "greeks"):
            obj = sim.get(container)
            if isinstance(obj, dict):
                for k in keys:
                    value = _extract_scalar_or_map_value(obj, k)
                    if value is not None:
                        return value
        return None

    return {
        "delta": pick([
            "delta",
            "portfolio_delta",
            "total_delta",
            "delta_total",
            "projected_delta_total",
            "delta_total_map",
        ]),
        "gamma": pick([
            "gamma",
            "portfolio_gamma",
            "total_gamma",
            "gamma_total",
            "net_gamma",
            "options_gamma",
            "options_gamma_map",
        ]),
        "vega": pick([
            "vega",
            "portfolio_vega",
            "total_vega",
            "vega_total",
            "net_vega",
            "options_vega",
            "options_vega_map",
        ]),
    }


def _mm_pct(mm: float, mb: float) -> float:
    if mb <= 0:
        return 0.0
    return (mm / mb) * 100.0


def _normalize_instrument_name(name: str, currency: str) -> str:
    n = (name or "").strip().upper()
    if not n:
        return n
    # Normalize common perp shorthand
    if n.endswith("-PERP"):
        n = n[:-5] + "-PERPETUAL"
    elif n == f"{currency.upper()}-PERP":
        n = f"{currency.upper()}-PERPETUAL"
    return n


def _is_option_instrument(name: str) -> bool:
    n = (name or "").strip().upper()
    return n.endswith("-C") or n.endswith("-P")




def _amount_for_simulation(
    *,
    instrument_name: str,
    qty_btc: float,
    spot_index_usd: float,
) -> float:
    """
    Deribit simulate_portfolio expects:
    - options: amount in contracts (qty_btc should not be used)
    - futures/perpetual: amount in USD notional
    When qty_btc is provided for perps/futures, convert to USD notional.
    """
    if _is_option_instrument(instrument_name):
        return float(qty_btc)
    if spot_index_usd > 0:
        return float(qty_btc) * float(spot_index_usd)
    return float(qty_btc)


def _extract_post_trade_equity(
    sim_raw: Dict[str, Any],
    pre_trade_equity_usd: float,
    spot_index_usd: float,
) -> float:
    """
    Phase 3: Extract post-trade equity from Deribit simulate_portfolio response.

    Priority:
      1. margin_balance (BTC) * spot → USD equity proxy
      2. equity field if present
      3. Fallback to pre-trade equity

    Deribit PM simulate_portfolio returns margin_balance in BTC for BTC-denominated accounts.
    This is the closest proxy to post-trade equity.
    """
    if not sim_raw:
        return pre_trade_equity_usd

    # Try margin_balance (most commonly returned by simulate_portfolio)
    mb = _safe_float(sim_raw.get("margin_balance"))
    if mb > 0 and spot_index_usd > 0:
        # margin_balance from simulate_portfolio is in BTC for BTC accounts
        # Heuristic: if mb is small (< 100), it's BTC; if large, it's USD
        if mb < 100:
            return mb * spot_index_usd
        return mb

    # Try explicit equity field
    eq = _safe_float(sim_raw.get("equity"))
    if eq > 0:
        if eq < 100 and spot_index_usd > 0:
            return eq * spot_index_usd
        return eq

    return pre_trade_equity_usd


def simulate_action_impact(
    deribit: DeribitClient,
    snapshot: PortfolioSnapshot,
    action: CandidateAction,
    currency: str = "BTC",
) -> Dict[str, Any]:
    """
    Simulate a single action via private/simulate_portfolio.
    Returns {mm_pct_after, im_pct_after, delta_after, gamma_after, vega_after, safe, raw}.
    On failure returns safe pass-through (never blocks the pipeline).
    """
    if action.qty_contracts is not None:
        amount = float(action.qty_contracts)
    elif action.qty_btc is not None:
        amount = _amount_for_simulation(
            instrument_name=action.instrument_name,
            qty_btc=float(action.qty_btc),
            spot_index_usd=float(snapshot.spot_index_usd),
        )
    else:
        return _passthrough(snapshot)

    instrument_name = _normalize_instrument_name(action.instrument_name, currency)
    signed_amount = amount if action.side == Side.BUY else -amount

    try:
        raw = deribit.simulate_portfolio(
            currency=currency,
            simulated_positions={instrument_name: signed_amount},
        )
    except Exception as e:
        return {**_passthrough(snapshot), "error": str(e)}

    mm = _safe_float(raw.get("projected_maintenance_margin") or raw.get("maintenance_margin"))
    mb = _safe_float(raw.get("margin_balance"))
    im = _safe_float(raw.get("projected_initial_margin") or raw.get("initial_margin"))

    mm_pct_after = _mm_pct(mm, mb)
    im_pct_after = _mm_pct(im, mb)
    greeks = _extract_greeks(raw)

    return {
        "mm_pct_after": mm_pct_after,
        "im_pct_after": im_pct_after,
        "delta_after": greeks["delta"] if greeks["delta"] is not None else snapshot.portfolio_delta_btc,
        "gamma_after": greeks["gamma"] if greeks["gamma"] is not None else snapshot.portfolio_gamma,
        "vega_after": greeks["vega"] if greeks["vega"] is not None else snapshot.portfolio_vega,
        "safe": mm_pct_after < 95.0,
        "raw": raw,
    }


def _passthrough(snapshot: PortfolioSnapshot) -> Dict[str, Any]:
    return {
        "mm_pct_after": snapshot.mm_pct,
        "im_pct_after": 0.0,
        "delta_after": snapshot.portfolio_delta_btc,
        "gamma_after": snapshot.portfolio_gamma,
        "vega_after": snapshot.portfolio_vega,
        "safe": True,
        "raw": {},
    }


def simulate_bundle_impact(
    deribit: DeribitClient,
    snapshot: PortfolioSnapshot,
    actions: List[CandidateAction],
    cfg: EngineConfig,
    currency: str = "BTC",
) -> Dict[str, Any]:
    """
    Simulate all actions at once via simulate_portfolio (single API call).
    Aggregates position deltas into one simulated_positions dict, then re-runs
    fast stress with projected greeks.
    """
    # Merge all actions into one simulated_positions dict
    sim_positions: Dict[str, float] = {}
    for action in actions:
        if action.qty_contracts is not None:
            amount = float(action.qty_contracts)
        elif action.qty_btc is not None:
            amount = _amount_for_simulation(
                instrument_name=action.instrument_name,
                qty_btc=float(action.qty_btc),
                spot_index_usd=float(snapshot.spot_index_usd),
            )
        else:
            continue
        signed = amount if action.side == Side.BUY else -amount
        instrument_name = _normalize_instrument_name(action.instrument_name, currency)
        sim_positions[instrument_name] = (
            sim_positions.get(instrument_name, 0.0) + signed
        )

    sim_ok = True
    sim_error: Optional[str] = None
    after_est_source = "simulate"
    delta_after_source = "simulate"

    try:
        raw = deribit.simulate_portfolio(
            currency=currency,
            simulated_positions=sim_positions if sim_positions else None,
        )
    except Exception as e:
        # Fallback: use current snapshot values
        raw = {}
        sim_ok = False
        sim_error = f"{e} | instruments={list(sim_positions.keys())}"
        after_est_source = "fallback"
        delta_after_source = "fallback"

    # If we got an empty response while we expected a simulation, mark as failed.
    if sim_ok and sim_positions and not raw:
        sim_ok = False
        sim_error = "simulate_portfolio returned empty response"
        after_est_source = "fallback"
        delta_after_source = "fallback"

    mm = _safe_float(raw.get("projected_maintenance_margin") or raw.get("maintenance_margin"))
    mb = _safe_float(raw.get("margin_balance"))
    im = _safe_float(raw.get("projected_initial_margin") or raw.get("initial_margin"))

    mm_pct_after = _mm_pct(mm, mb) if mb > 0 else snapshot.mm_pct
    greeks = _extract_greeks(raw)

    # Use projected greeks when simulation succeeded; otherwise fall back to snapshot.
    delta_after_sim = greeks["delta"] if sim_ok else None
    delta_after = delta_after_sim if delta_after_sim is not None else snapshot.portfolio_delta_btc
    delta_source = "simulate" if delta_after_sim is not None else "fallback"

    gamma_after_sim = greeks["gamma"] if sim_ok else None
    vega_after_sim = greeks["vega"] if sim_ok else None
    gamma_after = gamma_after_sim if gamma_after_sim is not None else snapshot.portfolio_gamma
    vega_after = vega_after_sim if vega_after_sim is not None else snapshot.portfolio_vega
    delta_after_source = delta_source if sim_ok else "fallback"
    gamma_after_source = "simulate" if gamma_after_sim is not None else "fallback"
    vega_after_source = "simulate" if vega_after_sim is not None else "fallback"

    # ── Phase 3 FIX: Extract post-trade equity from Deribit simulation ──
    # Deribit simulate_portfolio returns margin_balance (BTC) and/or equity.
    # We use this as the TRUE post-trade equity base for stress testing,
    # instead of the stale pre-trade snapshot equity.
    equity_after_sim = _extract_post_trade_equity(
        raw, snapshot.total_equity_usd, snapshot.spot_index_usd,
    )
    equity_source = "simulate" if sim_ok and equity_after_sim != snapshot.total_equity_usd else "fallback"

    # Re-run fast stress with after-state greeks AND after-state equity
    # Apply calibration caps to prevent Taylor-expansion from diverging
    from hedge_engine.risk.stress.stress_fast import run_stress_fast
    stress_after = run_stress_fast(
        equity_usd=equity_after_sim,  # CRITICAL: use post-trade equity
        hwm_usd=snapshot.hwm_usd,
        spot_index_usd=snapshot.spot_index_usd,
        delta_btc=delta_after,
        gamma=gamma_after,
        vega_usd_per_vol=vega_after,
        scenarios=list(cfg.stress_scenarios),
        dd_override_threshold=cfg.FAST_STRESS_OVERRIDE_DD,
        regime="NORMAL",
        gamma_pnl_cap_equity_pct=_safe_float(
            getattr(cfg, "FAST_STRESS_GAMMA_PNL_CAP_EQUITY_PCT", 0.0), 0.0,
        ),
        vega_pnl_cap_equity_pct=_safe_float(
            getattr(cfg, "FAST_STRESS_VEGA_PNL_CAP_EQUITY_PCT", 0.0), 0.0,
        ),
        total_loss_floor_equity_pct=_safe_float(
            getattr(cfg, "FAST_STRESS_TOTAL_LOSS_FLOOR_EQUITY_PCT", 0.0), 0.0,
        ),
    )
    stress_dd_after = min(
        (_safe_float(s.get("projected_dd_worst") if isinstance(s, dict) else s.projected_dd_worst)
         for s in (stress_after.scenarios or {}).values()),
        default=0.0,
    )

    mm_safe = mm_pct_after < cfg.mm_critical_pct
    stress_improves = stress_dd_after >= snapshot.dd

    return {
        "mm_pct_after": mm_pct_after,
        "im_pct_after": _mm_pct(im, mb) if mb > 0 else 0.0,
        "delta_after": delta_after,
        "delta_after_sim": delta_after_sim,
        "delta_after_source": delta_after_source,
        "gamma_after_source": gamma_after_source,
        "vega_after_source": vega_after_source,
        "gamma_after": gamma_after,
        "vega_after": vega_after,
        "equity_after": equity_after_sim,
        "equity_after_source": equity_source,
        "stress_dd_after": stress_dd_after,
        "stress_dd_after_source": "fast_calibrated",
        "mm_safe": mm_safe,
        "stress_improves": stress_improves,
        "approved": mm_safe,
        "sim_ok": sim_ok,
        "sim_error": sim_error,
        "after_est_source": after_est_source,
        "sim_raw": raw,
    }
