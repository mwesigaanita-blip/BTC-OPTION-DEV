# hedge_engine/risk/xpm/bundle_acceptance.py
# DEPRECATED: Per-bundle acceptance gates replaced by per-suggestion simulation gates
# inside gamma_hedge.run(), vega_hedge.run(), delta_hedge.run().
# Kept for rollback only (used by bundle_builder.py when SUB_ENGINE_ENABLED=False).
"""
Phase 2-4: Deterministic bundle acceptance gates, reason coverage, and scoring.

Survival-first design:
  - No bundle passes unless it materially improves portfolio survival.
  - Kill-switch: projected stress DD <= -10% => unconditional reject.
  - Reason-linked coverage: if a risk reason triggered the mode, the bundle
    must demonstrably improve that metric.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Tuple

from hedge_engine.risk.risk_checks import RiskFlags
from hedge_engine.settings.config import EngineConfig


# ─────────────────────────────────────────────
# Phase 2: Hard acceptance gates
# ─────────────────────────────────────────────

@dataclass(frozen=True)
class AcceptanceResult:
    accepted: bool
    rejection_reasons: List[str]
    metrics: Dict[str, Any]


def _safe_float(v: Any, default: float = 0.0) -> float:
    try:
        if v is None:
            return default
        return float(v)
    except Exception:
        return default


def evaluate_bundle_acceptance(
    *,
    before: Dict[str, Any],
    after: Dict[str, Any],
    mode_reasons: str,
    flags: RiskFlags,
    cfg: EngineConfig,
) -> AcceptanceResult:
    """
    Deterministic acceptance evaluation for a candidate bundle.

    Gates (ordered by survival priority):
      1. Simulation must be real (not fallback)
      2. Kill-switch: stress_dd_after <= BUNDLE_STRESS_DD_KILLSWITCH => reject
      3. MM must not enter dangerous zone
      4. MM must not worsen by > BUNDLE_MM_WORSEN_TOLERANCE_PP
      5. Stress DD must materially improve by >= BUNDLE_STRESS_IMPROVEMENT_MIN
      6. If MM already stressed (>= warning), MM must improve
      7. Reason coverage (Phase 3): each risk reason must be addressed

    Returns AcceptanceResult with structured metrics for telemetry.
    """
    reasons: List[str] = []

    sim_ok = bool(after.get("sim_ok", True))
    mm_after = _safe_float(after.get("mm_pct_after"), 0.0)
    mm_before = _safe_float(before.get("mm_pct"), 0.0)
    stress_dd_after = _safe_float(after.get("stress_dd_after"), 0.0)
    stress_dd_before = _safe_float(before.get("stress_dd"), 0.0)
    delta_before = _safe_float(before.get("delta"), 0.0)
    delta_after = _safe_float(after.get("delta_after"), delta_before)
    gamma_before = _safe_float(before.get("gamma"), 0.0)
    gamma_after = _safe_float(after.get("gamma_after"), gamma_before)
    vega_before = _safe_float(before.get("vega"), 0.0)
    vega_after = _safe_float(after.get("vega_after"), vega_before)

    stress_dd_before_source = str(before.get("stress_dd_source", "unknown"))
    stress_dd_after_source = str(after.get("stress_dd_after_source", "fast"))

    metrics: Dict[str, Any] = {
        "stress_dd_before": stress_dd_before,
        "stress_dd_before_source": stress_dd_before_source,
        "stress_dd_after": stress_dd_after,
        "stress_dd_after_source": stress_dd_after_source,
        "mm_before": mm_before,
        "mm_after": mm_after,
        "delta_before": delta_before,
        "delta_after": delta_after,
        "gamma_before": gamma_before,
        "gamma_after": gamma_after,
        "vega_before": vega_before,
        "vega_after": vega_after,
    }

    # Gate 1: Simulation must be real
    if not sim_ok:
        reasons.append("simulation_unavailable")
        return AcceptanceResult(accepted=False, rejection_reasons=reasons, metrics=metrics)

    # Gate 2: Kill-switch - absolute stress DD floor
    killswitch = _safe_float(
        getattr(cfg, "BUNDLE_STRESS_DD_KILLSWITCH", -0.10), -0.10
    )
    if stress_dd_after <= killswitch:
        reasons.append(
            f"stress_dd_killswitch: after={stress_dd_after:.4f} <= {killswitch:.4f}"
        )

    # Gate 3: MM must not enter dangerous zone
    mm_dangerous = _safe_float(cfg.mm_dangerous_pct, 90.0)
    if mm_after > mm_dangerous:
        reasons.append(
            f"mm_after={mm_after:.1f}% exceeds dangerous threshold {mm_dangerous:.0f}%"
        )

    # Gate 4: MM must not worsen by > tolerance
    mm_worsen_tol = _safe_float(
        getattr(cfg, "BUNDLE_MM_WORSEN_TOLERANCE_PP", 5.0), 5.0
    )
    if mm_after > mm_before + mm_worsen_tol:
        reasons.append(
            f"mm worsens by >{mm_worsen_tol:.0f}pp: {mm_before:.1f}% → {mm_after:.1f}%"
        )

    # Gate 5: Stress DD must materially improve
    improvement_min = _safe_float(
        getattr(cfg, "BUNDLE_STRESS_IMPROVEMENT_MIN", 0.005), 0.005
    )
    stress_improvement = stress_dd_after - stress_dd_before
    if stress_improvement < improvement_min:
        reasons.append(
            f"stress_dd insufficient improvement: "
            f"{stress_dd_before:.4f} → {stress_dd_after:.4f} "
            f"(improvement={stress_improvement:.4f}, need>={improvement_min:.4f})"
        )

    # Gate 6: If MM already stressed, must improve
    require_mm_improve = bool(
        getattr(cfg, "BUNDLE_REQUIRE_MM_IMPROVE_WHEN_STRESSED", True)
    )
    if require_mm_improve and mm_before >= cfg.mm_warning_pct and mm_after >= mm_before:
        reasons.append(
            f"mm_stressed_no_improve: mm_before={mm_before:.1f}% (>= warning {cfg.mm_warning_pct:.0f}%), "
            f"mm_after={mm_after:.1f}% did not improve"
        )

    # Gate 7: Reason coverage (Phase 3)
    reason_coverage_required = bool(
        getattr(cfg, "REASON_COVERAGE_REQUIRED", True)
    )
    if reason_coverage_required and not reasons:
        coverages, uncovered = evaluate_reason_coverage(
            mode_reasons=mode_reasons,
            before=before,
            after=after,
            flags=flags,
            cfg=cfg,
        )
        metrics["reason_coverage"] = [
            {
                "reason": c.reason,
                "metric": c.metric_name,
                "before": c.before_value,
                "after": c.after_value,
                "threshold": c.threshold,
                "covered": c.covered,
            }
            for c in coverages
        ]
        for name in uncovered:
            reasons.append(f"uncovered_reason:{name}")

    accepted = len(reasons) == 0
    return AcceptanceResult(accepted=accepted, rejection_reasons=reasons, metrics=metrics)


# ─────────────────────────────────────────────
# Phase 3: Reason-to-action linkage
# ─────────────────────────────────────────────

@dataclass(frozen=True)
class ReasonCoverage:
    reason: str
    metric_name: str
    before_value: float
    after_value: float
    threshold: float
    covered: bool


def _parse_mode_reasons(mode_reasons: str) -> List[str]:
    """Parse pipe-separated reason string into individual reason tokens."""
    if not mode_reasons:
        return []
    return [r.strip() for r in mode_reasons.split("|") if r.strip()]


def evaluate_reason_coverage(
    *,
    mode_reasons: str,
    before: Dict[str, Any],
    after: Dict[str, Any],
    flags: RiskFlags,
    cfg: EngineConfig,
) -> Tuple[List[ReasonCoverage], List[str]]:
    """
    Check if the bundle addresses each risk reason that triggered the mode.

    For each reason, a specific metric must improve by a minimum threshold.
    Returns (all_coverages, uncovered_reason_names).
    """
    tokens = _parse_mode_reasons(mode_reasons)
    if not tokens:
        return [], []

    mm_before = _safe_float(before.get("mm_pct"), 0.0)
    mm_after = _safe_float(after.get("mm_pct_after"), 0.0)
    delta_before = _safe_float(before.get("delta"), 0.0)
    delta_after = _safe_float(after.get("delta_after"), delta_before)
    vega_before = _safe_float(before.get("vega"), 0.0)
    vega_after = _safe_float(after.get("vega_after"), vega_before)
    gamma_before = _safe_float(before.get("gamma"), 0.0)
    gamma_after = _safe_float(after.get("gamma_after"), gamma_before)
    stress_dd_before = _safe_float(before.get("stress_dd"), 0.0)
    stress_dd_after = _safe_float(after.get("stress_dd_after"), 0.0)

    vega_improve_min = _safe_float(
        getattr(cfg, "REASON_VEGA_IMPROVE_MIN_PCT", 0.05), 0.05
    )
    gamma_improve_min = _safe_float(
        getattr(cfg, "REASON_GAMMA_IMPROVE_MIN_PCT", 0.05), 0.05
    )
    delta_improve_min = _safe_float(
        getattr(cfg, "REASON_DELTA_IMPROVE_MIN_PCT", 0.10), 0.10
    )
    stress_improve_min = _safe_float(
        getattr(cfg, "BUNDLE_STRESS_IMPROVEMENT_MIN", 0.005), 0.005
    )

    coverages: List[ReasonCoverage] = []
    uncovered: List[str] = []

    for token in tokens:
        t = token.lower()

        if t.startswith("dd>=") or t.startswith("dd>"):
            # Drawdown reason → stress DD must improve
            improvement = stress_dd_after - stress_dd_before
            covered = improvement >= stress_improve_min
            coverages.append(ReasonCoverage(
                reason=token,
                metric_name="stress_dd",
                before_value=stress_dd_before,
                after_value=stress_dd_after,
                threshold=stress_improve_min,
                covered=covered,
            ))
            if not covered:
                uncovered.append(token)

        elif "vega_breach" in t:
            # Vega reason → abs(vega) must decrease by threshold %
            abs_before = abs(vega_before)
            abs_after = abs(vega_after)
            if abs_before > 1e-9:
                pct_improve = (abs_before - abs_after) / abs_before
            else:
                pct_improve = 0.0 if abs_after <= abs_before else -1.0
            covered = pct_improve >= vega_improve_min
            coverages.append(ReasonCoverage(
                reason=token,
                metric_name="abs_vega",
                before_value=abs_before,
                after_value=abs_after,
                threshold=vega_improve_min,
                covered=covered,
            ))
            if not covered:
                uncovered.append(token)

        elif "gamma_breach" in t:
            # Gamma reason → abs(gamma) must decrease by threshold %
            abs_before = abs(gamma_before)
            abs_after = abs(gamma_after)
            if abs_before > 1e-9:
                pct_improve = (abs_before - abs_after) / abs_before
            else:
                pct_improve = 0.0 if abs_after <= abs_before else -1.0
            covered = pct_improve >= gamma_improve_min
            coverages.append(ReasonCoverage(
                reason=token,
                metric_name="abs_gamma",
                before_value=abs_before,
                after_value=abs_after,
                threshold=gamma_improve_min,
                covered=covered,
            ))
            if not covered:
                uncovered.append(token)

        elif t.startswith("mm>=") or t.startswith("mm>"):
            # Margin reason → MM must decrease
            covered = mm_after < mm_before
            coverages.append(ReasonCoverage(
                reason=token,
                metric_name="mm_pct",
                before_value=mm_before,
                after_value=mm_after,
                threshold=0.0,
                covered=covered,
            ))
            if not covered:
                uncovered.append(token)

        elif "speed" in t:
            # Speed trigger → delta must decrease by threshold %
            abs_delta_before = abs(delta_before)
            abs_delta_after = abs(delta_after)
            if abs_delta_before > 1e-9:
                pct_improve = (abs_delta_before - abs_delta_after) / abs_delta_before
            else:
                pct_improve = 0.0 if abs_delta_after <= abs_delta_before else -1.0
            covered = pct_improve >= delta_improve_min
            coverages.append(ReasonCoverage(
                reason=token,
                metric_name="abs_delta",
                before_value=abs_delta_before,
                after_value=abs_delta_after,
                threshold=delta_improve_min,
                covered=covered,
            ))
            if not covered:
                uncovered.append(token)

        elif "high_vol" in t:
            # High vol regime - informational, no strict coverage required
            pass

        # else: unknown reason token - skip silently

    return coverages, uncovered


# ─────────────────────────────────────────────
# Phase 4: Survival-first bundle scoring
# ─────────────────────────────────────────────

@dataclass(frozen=True)
class BundleScore:
    total: float
    components: Dict[str, float]
    debug: Dict[str, Any] = field(default_factory=dict)


def _clamp01(x: float) -> float:
    return max(0.0, min(1.0, x))


def score_bundle_survival(
    *,
    before: Dict[str, Any],
    after: Dict[str, Any],
    flags: RiskFlags,
    cfg: EngineConfig,
    n_actions: int,
) -> BundleScore:
    """
    Score a bundle using survival-first weighted priority.

    Weights:
      - Stress DD improvement: 0.35
      - Kill-switch headroom:  0.20
      - MM improvement:        0.20
      - Delta reduction:       0.10
      - Vega/convexity:        0.10
      - Simplicity:            0.05

    Returns BundleScore with component breakdown for debugging.
    """
    stress_dd_before = _safe_float(before.get("stress_dd"), 0.0)
    stress_dd_after = _safe_float(after.get("stress_dd_after"), 0.0)
    mm_before = _safe_float(before.get("mm_pct"), 0.0)
    mm_after = _safe_float(after.get("mm_pct_after"), 0.0)
    delta_before = _safe_float(before.get("delta"), 0.0)
    delta_after = _safe_float(after.get("delta_after"), delta_before)
    vega_before = _safe_float(before.get("vega"), 0.0)
    vega_after = _safe_float(after.get("vega_after"), vega_before)

    killswitch = _safe_float(
        getattr(cfg, "BUNDLE_STRESS_DD_KILLSWITCH", -0.10), -0.10
    )

    # Component 1: Stress DD improvement (higher = better)
    if abs(stress_dd_before) > 1e-9:
        stress_improve = _clamp01(
            (stress_dd_after - stress_dd_before) / abs(stress_dd_before)
        )
    else:
        stress_improve = _clamp01(stress_dd_after - stress_dd_before)

    # Component 2: Kill-switch headroom (distance from killswitch)
    if abs(killswitch) > 1e-9:
        ks_headroom = _clamp01(
            (stress_dd_after - killswitch) / abs(killswitch)
        )
    else:
        ks_headroom = 1.0

    # Component 3: MM improvement
    if mm_before > 1e-9:
        mm_improve = _clamp01((mm_before - mm_after) / mm_before)
    else:
        mm_improve = 1.0 if mm_after <= 0 else 0.0

    # Component 4: Delta reduction
    abs_delta_before = abs(delta_before)
    abs_delta_after = abs(delta_after)
    if abs_delta_before > 1e-9:
        delta_reduce = _clamp01(
            (abs_delta_before - abs_delta_after) / abs_delta_before
        )
    else:
        delta_reduce = 1.0 if abs_delta_after <= 1e-9 else 0.0

    # Component 5: Vega/convexity improvement
    abs_vega_before = abs(vega_before)
    abs_vega_after = abs(vega_after)
    if abs_vega_before > 1e-9:
        vega_reduce = _clamp01(
            (abs_vega_before - abs_vega_after) / abs_vega_before
        )
    else:
        vega_reduce = 1.0 if abs_vega_after <= 1e-9 else 0.0

    # Component 6: Simplicity (fewer actions preferred)
    simplicity = _clamp01(1.0 - (max(n_actions, 1) - 1) / 3.0)

    # Weighted total
    W_STRESS = 0.35
    W_KS = 0.20
    W_MM = 0.20
    W_DELTA = 0.10
    W_VEGA = 0.10
    W_SIMPLE = 0.05

    total = (
        W_STRESS * stress_improve
        + W_KS * ks_headroom
        + W_MM * mm_improve
        + W_DELTA * delta_reduce
        + W_VEGA * vega_reduce
        + W_SIMPLE * simplicity
    )

    components = {
        "stress_improve": round(stress_improve, 4),
        "ks_headroom": round(ks_headroom, 4),
        "mm_improve": round(mm_improve, 4),
        "delta_reduce": round(delta_reduce, 4),
        "vega_reduce": round(vega_reduce, 4),
        "simplicity": round(simplicity, 4),
    }

    debug = {
        "weights": {
            "stress": W_STRESS, "ks": W_KS, "mm": W_MM,
            "delta": W_DELTA, "vega": W_VEGA, "simple": W_SIMPLE,
        },
        "raw_inputs": {
            "stress_dd_before": stress_dd_before,
            "stress_dd_after": stress_dd_after,
            "mm_before": mm_before,
            "mm_after": mm_after,
            "delta_before": delta_before,
            "delta_after": delta_after,
            "vega_before": vega_before,
            "vega_after": vega_after,
            "n_actions": n_actions,
        },
    }

    return BundleScore(total=round(total, 6), components=components, debug=debug)
