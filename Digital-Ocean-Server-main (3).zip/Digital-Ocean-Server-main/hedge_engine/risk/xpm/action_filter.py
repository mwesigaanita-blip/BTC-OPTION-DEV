# hedge_engine/risk/xpm/action_filter.py
#
# DEPRECATED: Replaced by bundle_acceptance.py (Phase 2).
# evaluate_bundle_acceptance() provides hard gates, reason coverage, and scoring.
# This file is kept for backward compatibility.
from __future__ import annotations

from typing import Any, Dict, List, Tuple

from hedge_engine.settings.config import EngineConfig


def validate_bundle(
    before: Dict[str, Any],
    after: Dict[str, Any],
    cfg: EngineConfig,
    *,
    sim_ok: bool = True,
) -> Tuple[bool, List[str]]:
    """
    Reject a bundle if it worsens margin or stress drawdown.

    Rejection conditions:
      1. mm_pct_after > mm_dangerous_pct  (worsens MM into danger zone)
      2. stress_dd_after < stress_dd_before  (worsens projected stress DD)
      3. mm_pct_after > mm_pct_before + 5pp  (MM worsens by more than 5pp)

    Returns (approved: bool, rejection_reasons: List[str])
    """
    reasons: List[str] = []

    if not sim_ok:
        reasons.append("simulation_unavailable")
        return False, reasons

    mm_after = float(after.get("mm_pct_after", 0))
    mm_before = float(before.get("mm_pct", 0))
    stress_after = float(after.get("stress_dd_after", 0))
    stress_before = float(before.get("stress_dd", 0))

    if mm_after > cfg.mm_dangerous_pct:
        reasons.append(
            f"mm_after={mm_after:.1f}% exceeds dangerous threshold {cfg.mm_dangerous_pct}%"
        )

    if stress_after < stress_before:
        reasons.append(
            f"stress_dd worsens: {stress_before:.3f} → {stress_after:.3f}"
        )

    if mm_after > mm_before + 5.0:
        reasons.append(
            f"mm worsens by >5pp: {mm_before:.1f}% → {mm_after:.1f}%"
        )

    return len(reasons) == 0, reasons
