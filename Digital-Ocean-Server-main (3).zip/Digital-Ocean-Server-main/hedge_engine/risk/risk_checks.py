# hedge_engine/risk/risk_checks.py
from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Any, Dict, Optional, Tuple
import time
import sqlite3

from hedge_engine.core.models import GreekTargets

# add near the top of hedge_engine/risk/risk_checks.py

def _get(obj: Any, *path: str, default: Any = None) -> Any:
    """
    Safe getter that supports:
    - dict nesting: obj["greeks"]["gamma"]
    - attribute nesting: obj.greeks.gamma
    - mixed dict/attr
    """
    cur = obj
    for key in path:
        if cur is None:
            return default
        # dict-like
        if isinstance(cur, dict):
            cur = cur.get(key, None)
            continue
        # attr-like
        if hasattr(cur, key):
            cur = getattr(cur, key)
            continue
        return default
    return default if cur is None else cur

def _pick(obj: Any, candidates: list[tuple[str, ...]], default: Any = None) -> Any:
    """
    Try multiple _get() paths, return first non-None/non-empty value.
    Example:
      _pick(snapshot, [("equity_usd",), ("total_equity_usd",)], default=0.0)
    """
    for path in candidates:
        v = _get(obj, *path, default=None)
        if v is None:
            continue
        # treat empty dict/list as missing
        if isinstance(v, (dict, list)) and len(v) == 0:
            continue
        return v
    return default

def compute_target_hedge_ratio_H(
    *,
    dd_worst: float,
    mm_state: str,
    speed_trigger: bool,
    cfg: Any,
    vega_breach: bool = False,
    gamma_breach: bool = False,
) -> float:
    """
    Base ladder (by |DD|):
      0–2%: 0.25
      2–4%: 0.50
      4–6%: 0.75
      6–8%: 0.95
      >=8%: 1.00

    Escalators (each bumps index +1):
      speed_trigger  -> +1 bucket
      vega_breach    -> +1 bucket
      gamma_breach   -> +1 bucket

    MM ladder:
      warning   (70-80) -> + extra reduction
      critical  (80-90) -> force strong hedge
      dangerous (90+)   -> full hedge
    """
    abs_pct = abs(min(float(dd_worst), 0.0)) * 100.0

    ladder = [0.25, 0.50, 0.75, 0.95, 1.00]

    if abs_pct < 2.0:
        idx = 0
    elif abs_pct < 4.0:
        idx = 1
    elif abs_pct < 6.0:
        idx = 2
    elif abs_pct < 8.0:
        idx = 3
    else:
        idx = 4

    if speed_trigger and idx < len(ladder) - 1:
        idx += 1
    if vega_breach and idx < len(ladder) - 1:
        idx += 1
    if gamma_breach and idx < len(ladder) - 1:
        idx += 1

    H = float(ladder[idx])

    mm = (mm_state or "").lower().strip()
    if mm == "warning":
        H = min(1.0, H + float(getattr(cfg, "mm_extra_delta_reduction_pct", 0.10)))
    elif mm == "critical":
        H = max(H, float(getattr(cfg, "force_min_hedge_ratio_on_mm_danger", 0.95)))
    elif mm == "dangerous":
        H = 1.0

    return max(0.0, min(1.0, float(H)))

# -----------------------------
# Output model
# -----------------------------
@dataclass(frozen=True)
class RiskFlags:
    ts_utc: int

    # core
    equity_usd: float
    spot_index_usd: float
    dd_worst: float  # negative or 0

    # ladder
    dd_bucket: str   # "0-2", "2-4", "4-6", "6-8", ">=8"
    dd_abs_pct: float

    # margin state
    mm_pct: float
    mm_state: str  # "normal"|"warning"|"danger"|"emergency"

    # greek breaches
    vega: float
    vega_limit_usd: float
    vega_breach: bool

    gamma: float
    gamma_loss_est_usd: float
    gamma_budget_usd: float
    gamma_budget_breach: bool

    # speed triggers
    ret_30m_pct: float
    ret_24h_pct: float
    speed_trigger: bool

    # regime
    is_high_vol_regime: bool
    target_hedge_ratio_H: float
    target_hedge_reason: str
    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


# -----------------------------
# Spot history (SQLite)
# -----------------------------
SPOT_TICKS_TABLE = "hedge_engine_spot_ticks"


def ensure_spot_ticks_table(con: sqlite3.Connection) -> None:
    con.execute(
        f"""
        CREATE TABLE IF NOT EXISTS {SPOT_TICKS_TABLE} (
            ts_utc INTEGER PRIMARY KEY,
            spot_index_usd REAL NOT NULL
        )
        """
    )
    # helpful index for time queries (primary key already indexed, but explicit is ok)
    con.execute(f"CREATE INDEX IF NOT EXISTS idx_{SPOT_TICKS_TABLE}_ts ON {SPOT_TICKS_TABLE}(ts_utc)")
    con.commit()


def upsert_spot_tick(con: sqlite3.Connection, *, ts_utc: int, spot_index_usd: float) -> None:
    con.execute(
        f"""
        INSERT INTO {SPOT_TICKS_TABLE}(ts_utc, spot_index_usd)
        VALUES(?, ?)
        ON CONFLICT(ts_utc) DO UPDATE SET spot_index_usd=excluded.spot_index_usd
        """,
        (int(ts_utc), float(spot_index_usd)),
    )
    con.commit()


def _spot_at_or_before(con: sqlite3.Connection, *, ts_utc: int) -> Optional[float]:
    row = con.execute(
        f"""
        SELECT spot_index_usd
        FROM {SPOT_TICKS_TABLE}
        WHERE ts_utc <= ?
        ORDER BY ts_utc DESC
        LIMIT 1
        """,
        (int(ts_utc),),
    ).fetchone()
    return float(row[0]) if row else None


def compute_returns_from_db(
    con: sqlite3.Connection,
    *,
    now_ts_utc: int,
    spot_now: float,
    lookback_30m_s: int = 30 * 60,
    lookback_24h_s: int = 24 * 60 * 60,
) -> Tuple[Optional[float], Optional[float]]:
    s30 = _spot_at_or_before(con, ts_utc=now_ts_utc - lookback_30m_s)
    s24 = _spot_at_or_before(con, ts_utc=now_ts_utc - lookback_24h_s)

    ret30 = ((spot_now / s30) - 1.0) if (s30 and s30 > 0) else None
    ret24 = ((spot_now / s24) - 1.0) if (s24 and s24 > 0) else None
    return ret30, ret24


# -----------------------------
# Small helpers (unit-testable)
# -----------------------------
def classify_mm_state(mm_pct: float, cfg: Any) -> str:
    if mm_pct >= float(getattr(cfg, "mm_dangerous_pct", 90.0)):
        return "dangerous"
    if mm_pct >= float(getattr(cfg, "mm_critical_pct", 80.0)):
        return "critical"
    if mm_pct >= float(getattr(cfg, "mm_warning_pct", 70.0)):
        return "warning"
    return "normal"


def dd_bucket_from_dd(dd_worst: float) -> Tuple[str, float]:
    """
    dd_worst is negative or 0.
    returns (bucket, abs_pct)
    """
    dd = float(dd_worst)
    abs_pct = abs(min(dd, 0.0)) * 100.0
    if abs_pct < 2.0:
        return "0-2", abs_pct
    if abs_pct < 4.0:
        return "2-4", abs_pct
    if abs_pct < 6.0:
        return "4-6", abs_pct
    if abs_pct < 8.0:
        return "6-8", abs_pct
    return ">=8", abs_pct


def vega_breach_check(
    *, equity_usd: float, portfolio_vega: float, cfg: Any,
    effective: float = 0.0,
) -> Tuple[bool, float]:
    """
    Compute the vega breach flag and its corresponding USD limit.

    When effective == 0.0 (default / bootstrap pass):
        limit = VEGA_LIMIT_EQUITY_PCT_PER_VOL * equity_usd   (un-tightened)

    When effective > 0 (Phase 3 Option B - tightened pass):
        limit = VEGA_LIMIT_EQUITY_PCT_PER_VOL * (1 - effective * 0.5) * equity_usd

    The tightened formula matches compute_greek_targets() exactly, so that
    flags.vega_breach fires at the same threshold as the vega engine action trigger.
    At effective=1.0 the limit halves; at effective=0.0 it equals the un-tightened value.
    """
    vega_pct = float(getattr(cfg, "VEGA_LIMIT_EQUITY_PCT_PER_VOL", 0.005))
    if effective > 0.0:
        vega_pct = vega_pct * (1.0 - max(0.0, min(1.0, float(effective))) * 0.5)
    limit = vega_pct * float(equity_usd)
    breach = float(portfolio_vega) < -limit
    return breach, float(limit)


def gamma_budget_check(*, equity_usd: float, spot: float, gamma: float, cfg: Any) -> Tuple[bool, float, float]:
    """
    Use a practical estimate for your stored aggregate gamma:

    - Treat gamma as "BTC delta change per 1% spot move" (a common aggregated scaling).
    - For a 5% move => steps = 5 (each step = 1%).
    - 2nd-order BTC impact estimate: 0.5 * gamma * steps^2
    - Convert BTC -> USD by * spot.
    """
    spot = float(spot)
    steps = float(getattr(cfg, "GAMMA_STRESS_MOVE_PCT", 5.0)) # 5% / 1% steps
    gamma_btc_impact = 0.5 * float(gamma) * (steps * steps)
    gamma_usd_loss = abs(gamma_btc_impact) * spot

    budget = float(getattr(cfg, "GAMMA_BUDGET_EQUITY_PCT_UNDER_5PCT_MOVE", 0.01)) * float(equity_usd)
    breach = gamma_usd_loss > budget
    return breach, float(gamma_usd_loss), float(budget)


def high_vol_regime_placeholder(snapshot: Any) -> bool:
    """
    Placeholder until you fully wire in regime_rules.
    Uses common thresholds from your plan as a simple OR rule.
    """
    hv = float(_get(snapshot, "vol", "hv_30d_pct", default=0.0) or 0.0)
    iv = float(_get(snapshot, "vol", "iv_atm_30d_pct", default=0.0) or 0.0)
    iv_minus_hv = float(_get(snapshot, "vol", "iv_minus_hv_30d_pp", default=0.0) or 0.0)

    return (hv >= 55.0) or (iv >= 70.0) or (iv_minus_hv >= 12.0)


import datetime as dt

def _parse_ts_utc(value: Any) -> int:
    """
    Accepts:
      - int/float epoch seconds
      - ISO8601 string like '2026-03-01T12:01:42.459317+00:00'
      - '...Z'
    Returns epoch seconds (int).
    """
    if value is None:
        return int(time.time())

    if isinstance(value, (int, float)):
        return int(value)

    if isinstance(value, str):
        s = value.strip()
        # handle Z suffix
        if s.endswith("Z"):
            s = s[:-1] + "+00:00"
        try:
            d = dt.datetime.fromisoformat(s)
            if d.tzinfo is None:
                d = d.replace(tzinfo=dt.timezone.utc)
            return int(d.timestamp())
        except Exception:
            return int(time.time())

    return int(time.time())



# -----------------------------
# Main API
# -----------------------------
def compute_flags(*, snapshot: Any, state: Any, cfg: Any, con: Optional[sqlite3.Connection] = None) -> RiskFlags:
    """
    Snapshot: should expose:
      - spot_index_usd
      - equity_usd
      - mm_pct
      - portfolio_gamma
      - portfolio_vega (USD per 1.0 vol)
    State: should expose:
      - dd_worst  (preferred)
      OR hwm_usd (fallback for dd calculation)

    cfg: currently not used heavily; kept for future wiring.
    con: if provided, enables DB-backed speed triggers.
    """
    ts = _parse_ts_utc(_get(snapshot, "ts_utc", default=None))

    spot = float(_pick(snapshot, [("spot_index_usd",)], default=0.0) or 0.0)

    # equity can be "equity_usd" (PortfolioSnapshot) or "total_equity_usd" (EngineInputs)
    equity_usd = float(_pick(snapshot, [("equity_usd",), ("total_equity_usd",)], default=0.0) or 0.0)

    mm_pct = float(_pick(snapshot, [("mm_pct",)], default=0.0) or 0.0)

    # greeks can be nested (snapshot.greeks.gamma/vega) OR top-level (portfolio_gamma/portfolio_vega)
    gamma = float(_pick(snapshot, [("greeks", "gamma"), ("portfolio_gamma",), ("gamma",)], default=0.0) or 0.0)
    vega  = float(_pick(snapshot, [("greeks", "vega"), ("portfolio_vega",), ("vega",)], default=0.0) or 0.0)

    # dd_worst: prefer state.dd_worst
    dd_worst = _pick(state, [("dd_worst",), ("dd",)], default=None)
    if dd_worst is None:
        dd_worst = _pick(snapshot, [("dd_worst",), ("dd",)], default=None)

    if dd_worst is None:
        hwm = float(getattr(state, "hwm_usd", equity_usd) or equity_usd)
        dd_worst = 0.0 if hwm <= 0 else min((equity_usd / hwm) - 1.0, 0.0)

    dd_worst = float(dd_worst)
    
        
    bucket, dd_abs_pct = dd_bucket_from_dd(dd_worst)
    mm_state = classify_mm_state(mm_pct, cfg)

    gb, gamma_loss_usd, gamma_budget_usd = gamma_budget_check(equity_usd=equity_usd, spot=spot, gamma=gamma, cfg=cfg)

    # speed trigger (DB-backed if con provided)
    ret30 = 0.0
    ret24 = 0.0
    if con is not None and spot > 0:
        ensure_spot_ticks_table(con)
        upsert_spot_tick(con, ts_utc=ts, spot_index_usd=spot)
        ret30, ret24 = compute_returns_from_db(con, now_ts_utc=ts, spot_now=spot)

    thr30 = float(getattr(cfg, "SPEED_TRIGGER_30M_RETURN", 0.03))
    thr24 = float(getattr(cfg, "SPEED_TRIGGER_DAY_RETURN", 0.06))
    speed_trigger = ((ret30 is not None and abs(ret30) >= thr30) or
                    (ret24 is not None and abs(ret24) >= thr24))

    # -----------------------------------------------------------------------
    # Phase 3 (Option B): vega breach flag uses the same tightened threshold
    # as the engine action target in compute_greek_targets() / vega_hedge.run().
    # Both use: limit = VEGA_LIMIT_EQUITY_PCT_PER_VOL * (1 - effective * 0.5) * equity
    #
    # Two-pass approach breaks the circular dependency
    # (breach threshold → tighter limit → needs effective → needs H → needs breach):
    #
    #   Pass 1  Bootstrap vb with effective=0 (un-tightened) → compute H_bootstrap.
    #   Pass 2  Derive effective_base from H_bootstrap and iv_hv_mult → compute
    #           tightened vb and vlimit → compute H_final using tightened vb.
    #
    # In the common case (vega clearly over/under limit) both passes agree.
    # Edge case: vega in (tightened_limit, un-tightened_limit) → passes differ by
    # at most one H ladder step, which is the bounded acceptable inconsistency.
    # -----------------------------------------------------------------------

    # Pass 1 - bootstrap
    vb_bootstrap, _ = vega_breach_check(
        equity_usd=equity_usd, portfolio_vega=vega, cfg=cfg, effective=0.0
    )
    H_bootstrap = compute_target_hedge_ratio_H(
        dd_worst=dd_worst, mm_state=mm_state, speed_trigger=speed_trigger, cfg=cfg,
        vega_breach=vb_bootstrap, gamma_breach=gb,
    )

    # Replicate iv_hv_mult from compute_greek_targets() for consistent effective_base
    _iv_hv_pp   = float(_pick(snapshot, [("iv_minus_hv_30d_pp",)], default=0.0) or 0.0)
    _iv_hv_mult = (1.30 if _iv_hv_pp >= float(getattr(cfg, "IV_HV_MULTIPLIER_HIGH_PP", 20.0))
                   else 1.15 if _iv_hv_pp >= float(getattr(cfg, "IV_HV_MULTIPLIER_MED_PP",  15.0))
                   else 1.00)
    effective_base = max(0.0, min(1.0, H_bootstrap * _iv_hv_mult))

    # Pass 2 - tightened breach flag, consistent with engine target threshold
    vb, vlimit = vega_breach_check(
        equity_usd=equity_usd, portfolio_vega=vega, cfg=cfg, effective=effective_base
    )

    # Final H using tightened vb (may differ from H_bootstrap by ≤1 ladder step)
    H = compute_target_hedge_ratio_H(
        dd_worst=dd_worst, mm_state=mm_state, speed_trigger=speed_trigger, cfg=cfg,
        vega_breach=vb, gamma_breach=gb,
    )

    reason = f"ladder(dd_abs={dd_abs_pct:.2f}%, bucket={bucket})"
    if speed_trigger:
        reason += " + speed_escalation"
    if vb:
        reason += " + vega_breach(+1)"
    if gb:
        reason += " + gamma_breach(+1)"

    if mm_state == "warning":
        reason += " + mm_warning(+0.10)"
    elif mm_state == "critical":
        reason += " + mm_critical(force>=0.95)"
    elif mm_state == "dangerous":
        reason += " + mm_dangerous(=1.0)"
    # regime placeholder
    is_high_vol = high_vol_regime_placeholder(snapshot)

    return RiskFlags(
        ts_utc=ts,
        equity_usd=equity_usd,
        spot_index_usd=spot,
        dd_worst=dd_worst,
        dd_bucket=bucket,
        dd_abs_pct=dd_abs_pct,
        mm_pct=mm_pct,
        mm_state=mm_state,
        vega=vega,
        vega_limit_usd=vlimit,
        vega_breach=vb,
        gamma=gamma,
        gamma_loss_est_usd=gamma_loss_usd,
        gamma_budget_usd=gamma_budget_usd,
        gamma_budget_breach=gb,
        ret_30m_pct=ret30,
        ret_24h_pct=ret24,
        speed_trigger=speed_trigger,
        is_high_vol_regime=is_high_vol,
        target_hedge_ratio_H=H,
        target_hedge_reason=reason,
    )
    
    
def compute_greek_targets(
    *, flags: "RiskFlags", snapshot: Any, cfg: Any,
) -> GreekTargets:
    """
    Compute safe-zone greek boundaries for the current tick.

    Drivers (in order of priority):
      1. DD ladder → base hedge ratio H (already in flags.target_hedge_ratio_H)
      2. IV-HV spread → tightening multiplier (1.00 / 1.15 / 1.30)
      3. Mode → base delta band width
      4. effective = clamp(H × iv_hv_mult, 0, 1) → tighten bands/targets

    Stress scenarios are NOT a driver here. They are background monitoring only.
    """
    equity_usd = float(flags.equity_usd or 0.0)
    spot = float(flags.spot_index_usd or 1.0)
    mode = str(getattr(snapshot, "mode", "NORMAL") or "NORMAL").upper()

    # 1. IV-HV multiplier
    iv_hv_pp = float(_pick(snapshot, [("iv_minus_hv_30d_pp",)], default=0.0) or 0.0)
    high_pp = float(getattr(cfg, "IV_HV_MULTIPLIER_HIGH_PP", 20.0))
    med_pp  = float(getattr(cfg, "IV_HV_MULTIPLIER_MED_PP",  15.0))
    if iv_hv_pp >= high_pp:
        iv_hv_mult = 1.30
    elif iv_hv_pp >= med_pp:
        iv_hv_mult = 1.15
    else:
        iv_hv_mult = 1.00

    # 2. Effective aggressiveness
    base_H = float(flags.target_hedge_ratio_H)
    effective = max(0.0, min(1.0, base_H * iv_hv_mult))

    # 3. Mode-based delta band
    mode_bands = {
        "NORMAL":    (-0.50, +0.50),
        "DEFENSIVE": (-0.30, +0.30),
        "DANGER":    (-0.15, +0.15),
        "EMERGENCY": (-0.05, +0.05),
    }
    band_lo, band_hi = mode_bands.get(mode, (-0.50, +0.50))
    # Tighten: reduce half-width by effective (effective=1 → band collapses to 0)
    half_width = band_hi * (1.0 - effective)
    delta_band_min = -abs(half_width)
    delta_band_max = +abs(half_width)
    # Floor: never collapse below ±0.01 BTC
    delta_band_min = min(delta_band_min, -0.01)
    delta_band_max = max(delta_band_max, +0.01)

    # 4. Gamma target: reuse breach formula, tighten by effective
    # gamma_loss > budget means breach; target is the gamma where loss == budget
    # gamma_loss = 0.5 * |gamma| * steps² * spot, budget = pct * equity
    steps = float(getattr(cfg, "GAMMA_STRESS_MOVE_PCT", 5.0))
    budget_pct = float(getattr(cfg, "GAMMA_BUDGET_EQUITY_PCT_UNDER_5PCT_MOVE", 0.01))
    # Tighten budget by effective (higher effective → smaller budget → tighter limit)
    tightened_budget_pct = budget_pct * (1.0 - effective * 0.5)  # max 50% tighter at effective=1
    gamma_budget = tightened_budget_pct * equity_usd
    # Solve: 0.5 * |gamma_target| * steps² * spot = gamma_budget
    gamma_target = -(gamma_budget / (0.5 * (steps ** 2) * spot + 1e-9))  # negative = short book

    # 5. Vega target: reuse breach formula, tighten by effective
    vega_pct = float(getattr(cfg, "VEGA_LIMIT_EQUITY_PCT_PER_VOL", 0.005))
    tightened_vega_pct = vega_pct * (1.0 - effective * 0.5)
    vega_limit = tightened_vega_pct * equity_usd
    vega_target = -vega_limit  # negative = short vega book; breach when vega < vega_target

    return GreekTargets(
        delta_band_min=delta_band_min,
        delta_band_max=delta_band_max,
        gamma_target=gamma_target,
        vega_target=vega_target,
        mode=mode,
        iv_hv_multiplier=iv_hv_mult,
        hedge_ratio_H=base_H,
    )


def _mode_rank(mode: str) -> int:
    m = (mode or "").upper()
    return {"NORMAL": 0, "DEFENSIVE": 1, "DANGER": 2, "EMERGENCY": 3}.get(m, 0)


def decide_desired_mode_from_flags(flags_dict: dict) -> tuple[str, str]:
    """
    Mode is driven by MM state + DD + speed + high_vol ONLY.
    Greek breaches (vega/gamma) do NOT escalate mode - they boost H instead.
    This ensures MM is the primary driver of urgency.
    """
    dd_abs = float(flags_dict.get("dd_abs_pct", 0.0) or 0.0)
    mm_state = str(flags_dict.get("mm_state", "normal") or "normal").lower()
    speed = bool(flags_dict.get("speed_trigger", False))
    high_vol = bool(flags_dict.get("is_high_vol_regime", False))

    # Greek breach info: included in reason string for transparency, but does NOT change mode
    vega_breach = bool(flags_dict.get("vega_breach", False))
    gamma_breach = bool(
        flags_dict.get("gamma_budget_breach", False) or flags_dict.get("gamma_breach", False)
    )

    reasons: list[str] = []

    # EMERGENCY - MM dangerous or extreme DD
    if mm_state == "dangerous" or dd_abs >= 8.0:
        if mm_state == "dangerous":
            reasons.append("mm>=90")
        if dd_abs >= 8.0:
            reasons.append("dd>=8%")
        if vega_breach:
            reasons.append("vega_breach(H+1)")
        if gamma_breach:
            reasons.append("gamma_breach(H+1)")
        return "EMERGENCY", "|".join(reasons)

    # DANGER - MM critical or severe DD
    if mm_state == "critical" or dd_abs >= 6.0:
        if mm_state == "critical":
            reasons.append("mm>=80")
        if dd_abs >= 6.0:
            reasons.append("dd>=6%")
        if vega_breach:
            reasons.append("vega_breach(H+1)")
        if gamma_breach:
            reasons.append("gamma_breach(H+1)")
        return "DANGER", "|".join(reasons)

    # DEFENSIVE - MM warning or moderate DD or market stress
    if mm_state == "warning" or dd_abs >= 2.0 or speed or high_vol:
        if mm_state == "warning":
            reasons.append("mm>=70")
        if dd_abs >= 2.0:
            reasons.append("dd>=2%")
        if speed:
            reasons.append("speed")
        if high_vol:
            reasons.append("high_vol")
        if vega_breach:
            reasons.append("vega_breach(H+1)")
        if gamma_breach:
            reasons.append("gamma_breach(H+1)")
        return "DEFENSIVE", "|".join(reasons)

    # NORMAL - annotate Greek breaches in reason but mode stays NORMAL
    if vega_breach or gamma_breach:
        if vega_breach:
            reasons.append("vega_breach(H+1)")
        if gamma_breach:
            reasons.append("gamma_breach(H+1)")
        return "NORMAL", "|".join(reasons)

    return "NORMAL", "all_safe"


def apply_mode_hysteresis(
    *,
    desired_mode: str,
    desired_reason: str,
    prior_mode_state: dict,
    safe_required_ticks: int = 10,
) -> tuple[str, str, int, bool]:
    """
    Returns: (final_mode, final_reason, new_safe_streak, changed)

    Rules:
    - escalate immediately
    - downgrade only after N consecutive safer ticks
    - downgrade one step at a time
    """
    prior_mode = str(prior_mode_state.get("mode", "NORMAL") or "NORMAL").upper()
    safe_streak = int(prior_mode_state.get("safe_streak", 0) or 0)
    desired_mode = str(desired_mode or "NORMAL").upper()

    prior_rank = _mode_rank(prior_mode)
    desired_rank = _mode_rank(desired_mode)

    # escalate immediately
    if desired_rank > prior_rank:
        return desired_mode, desired_reason, 0, True

    # same mode
    if desired_rank == prior_rank:
        if prior_mode == "NORMAL":
            safe_streak += 1
        else:
            safe_streak = 0
        return prior_mode, desired_reason, safe_streak, False

    # desired safer than prior -> count safe ticks
    safe_streak += 1
    if safe_streak >= safe_required_ticks:
        next_mode = {
            "EMERGENCY": "DANGER",
            "DANGER": "DEFENSIVE",
            "DEFENSIVE": "NORMAL",
            "NORMAL": "NORMAL",
        }[prior_mode]
        changed = next_mode != prior_mode
        return next_mode, f"downgrade_after_safe({safe_streak})", 0, changed

    return prior_mode, f"hold_until_safe({safe_streak}/{safe_required_ticks})", safe_streak, False