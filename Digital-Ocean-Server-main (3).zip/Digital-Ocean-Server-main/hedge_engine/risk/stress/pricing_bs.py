# hedge_engine/risk/stress/pricing_bs.py
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Optional, Literal, Dict

OptionType = Literal["call", "put"]


# ----------------------------
# Math helpers (pure)
# ----------------------------
def _norm_cdf(x: float) -> float:
    # Standard normal CDF using erf (deterministic, no scipy needed)
    return 0.5 * (1.0 + math.erf(x / math.sqrt(2.0)))


def _clamp(x: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, x))


# ----------------------------
# Black–Scholes pricing (pure)
# ----------------------------
def black_scholes_price(
    *,
    spot: float,
    strike: float,
    t_years: float,
    iv: float,
    r: float = 0.0,
    option_type: OptionType,
) -> float:
    """
    Deterministic Black–Scholes (no dividends).
    - spot/strike in USD
    - t_years in years (e.g., days/365)
    - iv in decimal (e.g., 0.65 for 65%)
    - r in decimal
    Returns option price in USD.
    """
    s = float(spot)
    k = float(strike)
    t = float(t_years)
    sigma = float(iv)
    rr = float(r)

    if s <= 0 or k <= 0:
        return 0.0

    # Expired or near-expiry -> intrinsic
    if t <= 0 or sigma <= 0:
        intrinsic = max(0.0, s - k) if option_type == "call" else max(0.0, k - s)
        return float(intrinsic)

    sqrt_t = math.sqrt(t)
    d1 = (math.log(s / k) + (rr + 0.5 * sigma * sigma) * t) / (sigma * sqrt_t)
    d2 = d1 - sigma * sqrt_t

    df = math.exp(-rr * t)

    if option_type == "call":
        price = s * _norm_cdf(d1) - k * df * _norm_cdf(d2)
    else:
        price = k * df * _norm_cdf(-d2) - s * _norm_cdf(-d1)

    # numerical safety
    return float(max(0.0, price))


# ----------------------------
# IV shock helper (pure)
# ----------------------------
@dataclass(frozen=True)
class IvShockConfig:
    """
    - scenario_iv_bump_pp: bump in *vol points* (e.g., +10 means +10pp => +0.10 in decimal)
    - skew_bump_by_bucket_pp: extra bump (vol points) by bucket
    - iv_floor: minimum IV (decimal, e.g., 0.05)
    - iv_cap: optional cap (decimal). If None, no cap.
    """
    scenario_iv_bump_pp: float
    skew_bump_by_bucket_pp: Dict[str, float]
    iv_floor: float = 0.05
    iv_cap: Optional[float] = None


def iv_after_shock(
    *,
    base_iv: float,
    cfg: IvShockConfig,
    skew_delta_bucket: str,
) -> float:
    """
    Convert vol-points bumps to decimal and apply floor/cap.
    Example:
      base_iv=0.60 (60%)
      scenario bump=+10pp => +0.10
      skew bump=+5pp => +0.05
      -> 0.75 (75%)

    skew_delta_bucket: deterministic bucket name (you choose the taxonomy in stress_deep)
      e.g.: "PUT_10D", "PUT_25D", "ATM", "CALL_25D", "CALL_10D"
    """
    base = float(base_iv)

    scenario_bump = float(cfg.scenario_iv_bump_pp) / 100.0
    skew_bump_pp = float(cfg.skew_bump_by_bucket_pp.get(skew_delta_bucket, 0.0))
    skew_bump = skew_bump_pp / 100.0

    shocked = base + scenario_bump + skew_bump

    shocked = max(float(cfg.iv_floor), shocked)
    if cfg.iv_cap is not None:
        shocked = min(float(cfg.iv_cap), shocked)

    return float(shocked)


# ----------------------------
# Default skew bumps (deterministic)
# ----------------------------
def default_skew_bumps_pp() -> Dict[str, float]:
    return {
        "PUT_10D":  9.0,   # <10 delta puts:   +9 vol  (per spec)
        "PUT_25D":  6.0,   # 10–20 delta puts: +6 vol  (per spec)
        "ATM":      4.0,   # 20–30 delta puts: +4 vol  (per spec)
        "CALL_25D": 0.0,   # upside: no skew per spec
        "CALL_10D": 0.0,   # upside: no skew per spec
    }