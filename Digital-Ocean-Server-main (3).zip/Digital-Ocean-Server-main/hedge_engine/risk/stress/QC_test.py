# =============================================================
# FILE: stress_backtest_qc.py
# -------------------------------------------------------------
# NOTE: This file is a rewrite of stress_engine.py (local version)
#       adapted specifically to run and backtest on QuantConnect.
#
# Changes made from the original:
#   1. Removed scipy dependency - replaced norm.cdf with
#      pure Python _norm_cdf() using math.erf (QC has no scipy)
#   2. Removed the local test block (if __name__ == "__main__")
#   3. Added QC entry point class StressBacktest(QCAlgorithm)
#   4. HV30 is computed from rolling BTC daily returns inside QC
#   5. IV30 is estimated synthetically as HV30 * 1.15
#      (no Deribit options data - to be replaced with real data
#       once client confirms the data approach)
# =============================================================

from AlgorithmImports import * # type: ignore
import math
from dataclasses import dataclass, field
from typing import List, Tuple, Optional


# ─────────────────────────────────────────────
# CONSTANTS
# ─────────────────────────────────────────────

# Regime thresholds (as decimals, e.g. 0.35 = 35%)
HV_LOW_THRESHOLD    = 0.35
HV_HIGH_THRESHOLD   = 0.55

# Spread adjustment thresholds
IV_HV_UPGRADE_LOW    = 0.15    # spread >= 15%  => upgrade LOW    -> NORMAL
IV_HV_UPGRADE_NORMAL = 0.20    # spread >= 20%  => upgrade NORMAL -> HIGH
IV_HV_DOWNGRADE_HIGH = -0.15   # spread <= -15% => downgrade HIGH -> NORMAL

# Stress override drawdown trigger
OVERRIDE_DRAWDOWN_THRESHOLD = -0.08   # -8%

# Black-Scholes constants (per spec)
BS_RATE     = 0.0    # r = 0
BS_IV_FLOOR = 0.05   # 5% IV floor

# Skew adjustments for downside scenarios (delta-based, as decimals)
SKEW_TABLE = [
    (0.20, 0.30, 0.04),   # 20–30 delta puts: +4 vol
    (0.10, 0.20, 0.06),   # 10–20 delta puts: +6 vol
    (0.00, 0.10, 0.09),   # <10 delta puts:   +9 vol
]

# All 10 scenarios: (id, spot_shock, iv_shock, is_downside)
ALL_SCENARIOS = [
    ("S1",  -0.05,  0.03, True),
    ("S2",  -0.05,  0.05, True),
    ("S3",  -0.05,  0.10, True),
    ("S4",  -0.10,  0.10, True),
    ("S5",  -0.10,  0.20, True),
    ("S6",  +0.05,  0.03, False),
    ("S7",  +0.05,  0.05, False),
    ("S8",  +0.05,  0.10, False),
    ("S9",  +0.10,  0.10, False),
    ("S10", +0.10,  0.20, False),
]

# Which scenarios are active per regime
REGIME_SCENARIOS = {
    "LOW":    ["S1", "S2", "S6", "S7"],
    "NORMAL": ["S1", "S2", "S3", "S4", "S6", "S7", "S8", "S9"],
    "HIGH":   ["S1", "S2", "S3", "S4", "S5", "S6", "S7", "S8", "S9", "S10"],
}


# ─────────────────────────────────────────────
# DATA STRUCTURES
# ─────────────────────────────────────────────

@dataclass
class OptionPosition:
    position_id: str
    option_type: str      # "call" or "put"
    strike: float         # K in USD
    expiry_years: float   # T in years (e.g. 30/365)
    iv: float             # current IV as decimal (e.g. 0.80 = 80%)
    delta: float          # current delta
    gamma: float          # current gamma
    vega: float           # vega per 1 vol point move (as decimal)
    quantity: float       # contracts (negative = short)
    notional: float       # USD notional per contract


@dataclass
class PerpPosition:
    position_id: str
    quantity: float       # BTC (positive = long, negative = short)
    entry_price: float    # USD


@dataclass
class Portfolio:
    options: List[OptionPosition] = field(default_factory=list)
    perps:   List[PerpPosition]   = field(default_factory=list)
    total_value_usd: float = 1.0


@dataclass
class ScenarioResult:
    scenario_id: str
    spot_shock: float
    iv_shock: float
    is_downside: bool
    pnl_usd: float
    drawdown_pct: float
    override_triggered: bool


@dataclass
class StressResult:
    regime: str
    hv30: float
    iv30: float
    iv_hv_spread: float
    scenario_results: List[ScenarioResult]
    worst_scenario: ScenarioResult
    override_triggered: bool


# ─────────────────────────────────────────────
# BLACK-SCHOLES PRICER
# (pure Python - no scipy)
# ─────────────────────────────────────────────

def _norm_cdf(x: float) -> float:
    """Standard normal CDF using math.erf - no scipy needed."""
    return 0.5 * (1.0 + math.erf(x / math.sqrt(2.0)))


def bs_price(S: float, K: float, T: float, sigma: float, option_type: str) -> float:
    """
    Black-Scholes price. r=0, IV floor=5% per spec.
    S: spot, K: strike, T: years to expiry
    sigma: IV as decimal, option_type: 'call' or 'put'
    """
    sigma = max(sigma, BS_IV_FLOOR)

    if T <= 0:
        if option_type == "call":
            return max(S - K, 0.0)
        else:
            return max(K - S, 0.0)

    d1 = (math.log(S / K) + 0.5 * sigma ** 2 * T) / (sigma * math.sqrt(T))
    d2 = d1 - sigma * math.sqrt(T)

    if option_type == "call":
        return S * _norm_cdf(d1) - K * _norm_cdf(d2)
    else:
        return K * _norm_cdf(-d2) - S * _norm_cdf(-d1)


# ─────────────────────────────────────────────
# REGIME DETECTION
# ─────────────────────────────────────────────

def detect_regime(hv30: float, iv30: float) -> str:
    """
    Step 1: base regime from HV30 (realized vol - backward looking)
    Step 2: adjust using IV-HV spread (forward looking market signal)
    hv30, iv30: decimals (e.g. 0.58 = 58%)
    """
    spread = iv30 - hv30

    # Step 1: base from HV30
    if hv30 < HV_LOW_THRESHOLD:
        regime = "LOW"
    elif hv30 < HV_HIGH_THRESHOLD:
        regime = "NORMAL"
    else:
        regime = "HIGH"

    # Step 2: spread adjustment
    if spread >= IV_HV_UPGRADE_LOW and regime == "LOW":
        regime = "NORMAL"
    elif spread >= IV_HV_UPGRADE_NORMAL and regime == "NORMAL":
        regime = "HIGH"

    if spread <= IV_HV_DOWNGRADE_HIGH and regime == "HIGH":
        regime = "NORMAL"

    return regime


# ─────────────────────────────────────────────
# SKEW ADJUSTMENT
# ─────────────────────────────────────────────

def apply_skew(option: OptionPosition, base_iv_shock: float, is_downside: bool) -> float:
    """
    Downside scenarios only: steepen IV shock based on delta bucket.
    Upside scenarios: parallel shift, no skew applied.
    """
    if not is_downside or option.option_type == "call":
        return base_iv_shock

    abs_delta = abs(option.delta)
    for (low, high, extra) in SKEW_TABLE:
        if low <= abs_delta < high:
            return base_iv_shock + extra

    # delta >= 0.30 (near ATM puts): no extra skew
    return base_iv_shock


# ─────────────────────────────────────────────
# FAST STRESS  (Greeks approximation)
# ─────────────────────────────────────────────

def fast_stress_option(option: OptionPosition,
                       spot: float,
                       dS: float,
                       dIV: float) -> float:
    """PnL ≈ Δ*dS + 0.5*Γ*dS² + Vega*dIV"""
    pnl_per_contract = (
        option.delta * dS
        + 0.5 * option.gamma * dS ** 2
        + option.vega * dIV
    )
    return pnl_per_contract * option.quantity * option.notional


def fast_stress_perp(perp: PerpPosition, dS: float) -> float:
    """Linear PnL for perpetuals/futures."""
    return perp.quantity * dS


# ─────────────────────────────────────────────
# DEEP STRESS  (Full BS repricing)
# ─────────────────────────────────────────────

def deep_stress_option(option: OptionPosition,
                       spot: float,
                       dS_pct: float,
                       dIV: float,
                       is_downside: bool) -> float:
    """Full Black-Scholes reprice under stressed spot and IV."""
    stressed_spot = spot * (1 + dS_pct)
    adjusted_dIV  = apply_skew(option, dIV, is_downside)
    stressed_iv   = max(option.iv + adjusted_dIV, BS_IV_FLOOR)

    price_now      = bs_price(spot,          option.strike, option.expiry_years,
                               option.iv,     option.option_type)
    price_stressed = bs_price(stressed_spot, option.strike, option.expiry_years,
                               stressed_iv,   option.option_type)

    pnl_per_contract = price_stressed - price_now
    return pnl_per_contract * option.quantity * option.notional


def deep_stress_perp(perp: PerpPosition, spot: float, dS_pct: float) -> float:
    """Linear PnL for perps under deep stress."""
    return fast_stress_perp(perp, spot * dS_pct)


# ─────────────────────────────────────────────
# CORE STRESS ENGINE
# ─────────────────────────────────────────────

class StressEngine:

    def __init__(self, portfolio: Portfolio):
        self.portfolio = portfolio

    def get_active_scenarios(self, regime: str) -> List[Tuple]:
        active_ids = REGIME_SCENARIOS[regime]
        return [s for s in ALL_SCENARIOS if s[0] in active_ids]

    def run_scenario(self, scenario: Tuple, spot: float, use_deep: bool = True) -> float:
        sid, dS_pct, dIV, is_downside = scenario
        dS_abs    = spot * dS_pct
        total_pnl = 0.0

        for opt in self.portfolio.options:
            if use_deep:
                total_pnl += deep_stress_option(opt, spot, dS_pct, dIV, is_downside)
            else:
                adj_dIV    = apply_skew(opt, dIV, is_downside)
                total_pnl += fast_stress_option(opt, spot, dS_abs, adj_dIV)

        for perp in self.portfolio.perps:
            if use_deep:
                total_pnl += deep_stress_perp(perp, spot, dS_pct)
            else:
                total_pnl += fast_stress_perp(perp, dS_abs)

        return total_pnl

    def check_override(self, pnl_usd: float) -> bool:
        drawdown  = pnl_usd / self.portfolio.total_value_usd
        return drawdown <= OVERRIDE_DRAWDOWN_THRESHOLD

    def run_fast_stress(self, spot: float, hv30: float, iv30: float) -> StressResult:
        return self._run(spot, hv30, iv30, use_deep=False)

    def run_deep_stress(self, spot: float, hv30: float, iv30: float) -> StressResult:
        return self._run(spot, hv30, iv30, use_deep=True)

    def _run(self, spot: float, hv30: float, iv30: float, use_deep: bool) -> StressResult:
        regime           = detect_regime(hv30, iv30)
        iv_hv_spread     = iv30 - hv30
        active_scenarios = self.get_active_scenarios(regime)
        results: List[ScenarioResult] = []

        for scenario in active_scenarios:
            sid, dS_pct, dIV, is_downside = scenario
            pnl          = self.run_scenario(scenario, spot, use_deep=use_deep)
            drawdown_pct = pnl / self.portfolio.total_value_usd
            override     = self.check_override(pnl)

            results.append(ScenarioResult(
                scenario_id=sid,
                spot_shock=dS_pct,
                iv_shock=dIV,
                is_downside=is_downside,
                pnl_usd=pnl,
                drawdown_pct=drawdown_pct,
                override_triggered=override,
            ))

        worst        = min(results, key=lambda r: r.pnl_usd)
        any_override = any(r.override_triggered for r in results)

        return StressResult(
            regime=regime,
            hv30=hv30,
            iv30=iv30,
            iv_hv_spread=iv_hv_spread,
            scenario_results=results,
            worst_scenario=worst,
            override_triggered=any_override,
        )


# ─────────────────────────────────────────────
# QUANTCONNECT ENTRY POINT
# ─────────────────────────────────────────────

class StressBacktest(QCAlgorithm):
    """
    QC backtest entry point.
    - Feeds daily BTC price into the stress engine
    - Computes HV30 from rolling 30-day log returns
    - Estimates IV30 synthetically as HV30 * 1.15
      (replace with real Deribit IV data once available)
    - Runs deep stress every bar
    - Logs regime, worst scenario, drawdown, override flag
    - Plots worst projected drawdown and override signal
    """

    def Initialize(self):
        self.SetStartDate(2022, 1, 1)
        self.SetEndDate(2024, 1, 1)
        self.SetCash(100_000)

        # BTC daily data
        self.btc = self.AddCrypto("BTCUSD", Resolution.Daily).Symbol

        # Rolling window: 31 prices => 30 log returns => HV30
        self.price_window = RollingWindow[float](31)

        # Backtest portfolio - replace with real positions when available
        self.portfolio_state = Portfolio(
            total_value_usd=100_000,
            options=[
                OptionPosition(
                    position_id="OPT-001",
                    option_type="call",
                    strike=70_000,
                    expiry_years=30 / 365,
                    iv=0.80,
                    delta=0.45,
                    gamma=0.000012,
                    vega=18.5,
                    quantity=-5,
                    notional=1.0,
                ),
                OptionPosition(
                    position_id="OPT-002",
                    option_type="put",
                    strike=60_000,
                    expiry_years=30 / 365,
                    iv=0.90,
                    delta=-0.25,
                    gamma=0.000009,
                    vega=14.2,
                    quantity=10,
                    notional=1.0,
                ),
            ],
            perps=[
                PerpPosition(
                    position_id="PERP-001",
                    quantity=-2.0,
                    entry_price=65_000,
                ),
            ]
        )

        self.engine = StressEngine(self.portfolio_state)

        # Track override events for summary
        self.override_count = 0
        self.total_bars     = 0

    def OnData(self, data: Slice):
        if not data.ContainsKey(self.btc):
            return

        price = float(data[self.btc].Close)
        self.price_window.Add(price)

        # Wait until we have 31 prices (30 returns) for HV30
        if not self.price_window.IsReady:
            return

        self.total_bars += 1

        # ── Compute HV30 from rolling log returns ──
        prices      = [self.price_window[i] for i in range(self.price_window.Count)]
        log_returns = [
            math.log(prices[i] / prices[i + 1])
            for i in range(len(prices) - 1)
        ]
        mean_sq  = sum(r ** 2 for r in log_returns) / len(log_returns)
        hv30_ann = math.sqrt(mean_sq) * math.sqrt(252)   # annualized

        # ── Synthetic IV30 estimate ──
        # IV tends to run ~15% above realized vol on average.
        # Replace with real Deribit ATM IV once data is available.
        iv30_ann = hv30_ann * 1.15

        # ── Update portfolio value to current equity ──
        self.portfolio_state.total_value_usd = float(
            self.Portfolio.TotalPortfolioValue
        )

        # ── Run deep stress ──
        result = self.engine.run_deep_stress(
            spot=price,
            hv30=hv30_ann,
            iv30=iv30_ann,
        )

        # ── Track overrides ──
        if result.override_triggered:
            self.override_count += 1

        # ── Log every bar ──
        w = result.worst_scenario
        self.Log(
            f"Regime={result.regime} | "
            f"HV30={result.hv30:.1%} | "
            f"IV30={result.iv30:.1%} | "
            f"Spread={result.iv_hv_spread:+.1%} | "
            f"ActiveScenarios={len(result.scenario_results)} | "
            f"Worst={w.scenario_id} | "
            f"WorstDD={w.drawdown_pct:.2%} | "
            f"Override={'YES' if result.override_triggered else 'NO'}"
        )

        # ── Plot for backtest charts ──
        self.Plot("Stress DD",   "WorstProjectedDD",  w.drawdown_pct * 100)
        self.Plot("Stress",      "Override",          1.0 if result.override_triggered else 0.0)
        self.Plot("Vol Regime",  "HV30_pct",          hv30_ann * 100)
        self.Plot("Vol Regime",  "IV30_pct",          iv30_ann * 100)

    def OnEndOfAlgorithm(self):
        """Print summary stats at end of backtest."""
        override_rate = (
            self.override_count / self.total_bars
            if self.total_bars > 0 else 0.0
        )
        self.Log("=" * 60)
        self.Log("STRESS BACKTEST SUMMARY")
        self.Log(f"  Total bars       : {self.total_bars}")
        self.Log(f"  Override triggers: {self.override_count}")
        self.Log(f"  Override rate    : {override_rate:.1%}")
        self.Log("=" * 60)