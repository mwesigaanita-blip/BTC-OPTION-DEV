# hedge_engine/risk/stress/calibration.py
"""
Phase 4: Scenario calibration layer.

Uses Deribit PME data (when available) to:
  1. Compare our custom scenario severity against Deribit PM shock ranges
  2. Log calibration diagnostics
  3. Suggest whether extreme scenarios should be activated

Design principle:
  - NEVER replace our custom scenarios with Deribit PM parameters
  - Use Deribit PM only as calibration / sanity-check input
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional

from hedge_engine.settings.config import StressScenario

logger = logging.getLogger("hedge_engine.calibration")


def _sf(v: Any, default: float = 0.0) -> float:
    try:
        if v is None:
            return default
        return float(v)
    except Exception:
        return default


@dataclass
class CalibrationResult:
    """Output of comparing our scenarios against Deribit PM ranges."""
    # Deribit PM ranges (if available)
    deribit_price_shock_down_pct: Optional[float] = None
    deribit_price_shock_up_pct: Optional[float] = None
    deribit_vol_range_up: Optional[float] = None
    deribit_vol_range_down: Optional[float] = None

    # Our scenario ranges
    our_worst_down_pct: float = 0.0
    our_worst_up_pct: float = 0.0
    our_max_iv_bump: float = 0.0

    # Calibration flags
    our_downside_weaker_than_deribit: bool = False
    our_upside_weaker_than_deribit: bool = False
    extreme_scenario_recommended: bool = False
    extreme_scenario_reason: str = ""

    # Historical vol context
    hv_30d_pct: Optional[float] = None

    # Debug
    pme_available: bool = False
    notes: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


def extract_pme_ranges(pme_raw: Dict[str, Any]) -> Dict[str, Optional[float]]:
    """
    Extract calibration-relevant ranges from Deribit pme/simulate response.

    The PME response structure varies by account type. We try multiple known paths.
    """
    if not pme_raw:
        return {}

    result: Dict[str, Optional[float]] = {}

    # Try common PME response fields
    for key_down in ("price_shock_down", "spot_shock_down_pct", "min_price_shock"):
        v = pme_raw.get(key_down)
        if v is not None:
            result["price_shock_down_pct"] = _sf(v)
            break

    for key_up in ("price_shock_up", "spot_shock_up_pct", "max_price_shock"):
        v = pme_raw.get(key_up)
        if v is not None:
            result["price_shock_up_pct"] = _sf(v)
            break

    for key_vol_up in ("volatility_range_up", "vol_shock_up", "max_vol_shock"):
        v = pme_raw.get(key_vol_up)
        if v is not None:
            result["vol_range_up"] = _sf(v)
            break

    for key_vol_down in ("volatility_range_down", "vol_shock_down", "min_vol_shock"):
        v = pme_raw.get(key_vol_down)
        if v is not None:
            result["vol_range_down"] = _sf(v)
            break

    # Try nested structure: pme_raw["scenarios"] or pme_raw["risk_matrix"]
    for container_key in ("scenarios", "risk_matrix", "erm"):
        container = pme_raw.get(container_key)
        if isinstance(container, dict):
            # Extract min/max spot shocks from scenario grid
            spot_shocks = []
            vol_shocks = []
            for scenario_data in container.values():
                if isinstance(scenario_data, dict):
                    ss = scenario_data.get("spot_shock_pct") or scenario_data.get("price_shock")
                    if ss is not None:
                        spot_shocks.append(_sf(ss))
                    vs = scenario_data.get("vol_shock") or scenario_data.get("iv_shock")
                    if vs is not None:
                        vol_shocks.append(_sf(vs))
            if spot_shocks:
                result.setdefault("price_shock_down_pct", min(spot_shocks))
                result.setdefault("price_shock_up_pct", max(spot_shocks))
            if vol_shocks:
                result.setdefault("vol_range_up", max(vol_shocks))
                result.setdefault("vol_range_down", min(vol_shocks))

    return result


def calibrate_scenarios(
    *,
    our_scenarios: tuple[StressScenario, ...],
    pme_raw: Optional[Dict[str, Any]] = None,
    hv_30d_pct: Optional[float] = None,
) -> CalibrationResult:
    """
    Compare our custom scenario set against Deribit PM ranges.

    Returns CalibrationResult with flags indicating whether our scenarios
    are weaker than Deribit's PM requirements.
    """
    result = CalibrationResult()
    result.hv_30d_pct = hv_30d_pct

    # Compute our scenario ranges
    if our_scenarios:
        down_shocks = [s.spot_shock_pct for s in our_scenarios if s.spot_shock_pct < 0]
        up_shocks = [s.spot_shock_pct for s in our_scenarios if s.spot_shock_pct > 0]
        iv_bumps = [s.iv_bump_vol for s in our_scenarios]

        result.our_worst_down_pct = min(down_shocks) if down_shocks else 0.0
        result.our_worst_up_pct = max(up_shocks) if up_shocks else 0.0
        result.our_max_iv_bump = max(iv_bumps) if iv_bumps else 0.0

    # Extract Deribit PM ranges
    if pme_raw:
        pme_ranges = extract_pme_ranges(pme_raw)
        if pme_ranges:
            result.pme_available = True
            result.deribit_price_shock_down_pct = pme_ranges.get("price_shock_down_pct")
            result.deribit_price_shock_up_pct = pme_ranges.get("price_shock_up_pct")
            result.deribit_vol_range_up = pme_ranges.get("vol_range_up")
            result.deribit_vol_range_down = pme_ranges.get("vol_range_down")

            # Compare downside
            if result.deribit_price_shock_down_pct is not None:
                if result.our_worst_down_pct > result.deribit_price_shock_down_pct:
                    result.our_downside_weaker_than_deribit = True
                    result.notes.append(
                        f"Our worst downside ({result.our_worst_down_pct:.1%}) is weaker than "
                        f"Deribit PM ({result.deribit_price_shock_down_pct:.1%})"
                    )

            # Compare upside
            if result.deribit_price_shock_up_pct is not None:
                if result.our_worst_up_pct < result.deribit_price_shock_up_pct:
                    result.our_upside_weaker_than_deribit = True
                    result.notes.append(
                        f"Our worst upside ({result.our_worst_up_pct:.1%}) is weaker than "
                        f"Deribit PM ({result.deribit_price_shock_up_pct:.1%})"
                    )
    else:
        result.notes.append("PME data not available - calibration skipped")

    # Recommend extreme scenario if HV is elevated
    if hv_30d_pct is not None and hv_30d_pct > 55.0:
        result.extreme_scenario_recommended = True
        result.extreme_scenario_reason = f"HV30={hv_30d_pct:.1f}% > 55% threshold"
        result.notes.append(result.extreme_scenario_reason)

    if result.our_downside_weaker_than_deribit:
        result.extreme_scenario_recommended = True
        result.extreme_scenario_reason += " + our_downside_weaker_than_deribit"

    return result


# ─────────────────────────────────────────────
# Extreme scenario definitions
# ─────────────────────────────────────────────

# These are activated ONLY when calibration recommends them
EXTREME_SCENARIOS = (
    StressScenario("S11_DOWN_15", spot_shock_pct=-0.15, iv_bump_vol=25.0, apply_skew_bump=True),
    StressScenario("S12_DOWN_20", spot_shock_pct=-0.20, iv_bump_vol=30.0, apply_skew_bump=True),
    StressScenario("S13_UP_15",   spot_shock_pct=+0.15, iv_bump_vol=15.0, apply_skew_bump=False),
)


def get_active_scenarios_with_calibration(
    *,
    base_scenarios: tuple[StressScenario, ...],
    calibration: CalibrationResult,
) -> tuple[StressScenario, ...]:
    """
    Return the active scenario set, adding extreme scenarios if recommended.
    """
    if not calibration.extreme_scenario_recommended:
        return base_scenarios

    # Add extreme scenarios that are more severe than our current worst
    added: List[StressScenario] = []
    for extreme in EXTREME_SCENARIOS:
        # Only add if strictly more severe than what we have
        already_covered = any(
            s.spot_shock_pct <= extreme.spot_shock_pct and s.iv_bump_vol >= extreme.iv_bump_vol
            for s in base_scenarios
        )
        if not already_covered:
            added.append(extreme)

    if added:
        logger.info(
            "Calibration added %d extreme scenarios: %s",
            len(added),
            [s.name for s in added],
        )

    return base_scenarios + tuple(added)
