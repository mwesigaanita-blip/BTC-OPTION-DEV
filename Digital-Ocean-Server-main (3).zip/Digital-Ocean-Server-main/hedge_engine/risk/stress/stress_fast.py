# hedge_engine/risk/stress/stress_fast.py
from __future__ import annotations

import json
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from typing import Any, Dict, Optional
from hedge_engine.settings.config import StressScenario

def _utc_now_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _safe_float(x: Any, default: float = 0.0) -> float:
    try:
        if x is None:
            return default
        return float(x)
    except Exception:
        return default





@dataclass(frozen=True)
class StressScenarioResult:
    spot_shock_pct: float
    iv_shock_abs: float
    dS_usd: float
    pnl_delta_usd: float
    pnl_gamma_usd: float
    pnl_vega_usd: float
    pnl_total_usd: float
    projected_equity_usd: float
    projected_dd_worst: Optional[float]  # None if hwm missing


@dataclass(frozen=True)
class StressFastResult:
    ts_utc: str
    method: str
    regime: str          # ← add this
    inputs: Dict[str, Any]
    scenarios: Dict[str, Dict[str, Any]]
    stress_override: bool
    override_reasons: list[str]


def fast_stress_pnl_usd(
    *,
    equity_usd: float,
    hwm_usd: Optional[float],
    spot_index_usd: float,
    delta_btc: float,
    gamma: float,
    vega_usd_per_vol: float,
    spot_shock_pct: float,
    iv_shock_abs: float,
    gamma_pnl_cap_equity_pct: float = 0.0,
    vega_pnl_cap_equity_pct: float = 0.0,
    total_loss_floor_equity_pct: float = 0.0,
) -> StressScenarioResult:
    """
    Fast (Taylor-expansion) stress PnL per scenario.

    Calibration caps (set > 0 to activate):
      gamma_pnl_cap_equity_pct:  max |gamma PnL| as fraction of equity (e.g. 0.40 = 40%)
      vega_pnl_cap_equity_pct:   max |vega PnL| as fraction of equity (e.g. 0.50 = 50%)
      total_loss_floor_equity_pct: total PnL cannot exceed -X * equity (e.g. 0.80 = max 80% loss)

    These keep the Taylor approximation from producing impossible results
    (like -112% DD) for large shocks where the approximation breaks down.
    Deep stress (B-S repricing) remains the accurate layer.
    """
    eq = float(equity_usd)
    dS = float(spot_index_usd) * float(spot_shock_pct)

    pnl_delta = float(delta_btc) * dS

    pnl_gamma_raw = 0.5 * float(gamma) * (dS ** 2)
    pnl_gamma = pnl_gamma_raw
    if gamma_pnl_cap_equity_pct > 0 and eq > 0:
        cap = gamma_pnl_cap_equity_pct * eq
        pnl_gamma = max(-cap, min(cap, pnl_gamma_raw))

    pnl_vega_raw = float(vega_usd_per_vol) * float(iv_shock_abs)
    pnl_vega = pnl_vega_raw
    if vega_pnl_cap_equity_pct > 0 and eq > 0:
        cap = vega_pnl_cap_equity_pct * eq
        pnl_vega = max(-cap, min(cap, pnl_vega_raw))

    pnl_total = pnl_delta + pnl_gamma + pnl_vega

    # Floor: total loss cannot exceed X% of equity
    if total_loss_floor_equity_pct > 0 and eq > 0 and pnl_total < 0:
        floor = -total_loss_floor_equity_pct * eq
        pnl_total = max(floor, pnl_total)

    projected_equity = eq + pnl_total

    projected_dd = None
    if hwm_usd is not None and float(hwm_usd) > 0:
        projected_dd = (projected_equity / float(hwm_usd)) - 1.0
        projected_dd = min(0.0, projected_dd)

    return StressScenarioResult(
        spot_shock_pct=float(spot_shock_pct),
        iv_shock_abs=float(iv_shock_abs),
        dS_usd=float(dS),
        pnl_delta_usd=float(pnl_delta),
        pnl_gamma_usd=float(pnl_gamma),
        pnl_vega_usd=float(pnl_vega),
        pnl_total_usd=float(pnl_total),
        projected_equity_usd=float(projected_equity),
        projected_dd_worst=projected_dd,
    )


def stress_override_policy(
    *,
    scenario_results: Dict[str, StressScenarioResult],
    dd_override_threshold: float = -0.08,
    min_equity_usd: float = 0.0,
) -> tuple[bool, list[str]]:
    """
    Deterministic override:
    - if ANY scenario projected_dd <= threshold => override
    - if ANY scenario projected_equity <= min_equity_usd => override
    """
    reasons: list[str] = []
    override = False

    for name, r in scenario_results.items():
        if r.projected_dd_worst is not None and r.projected_dd_worst <= float(dd_override_threshold):
            override = True
            reasons.append(f"{name}:PROJECTED_DD<={dd_override_threshold}")

        if r.projected_equity_usd <= float(min_equity_usd):
            override = True
            reasons.append(f"{name}:PROJECTED_EQUITY<={min_equity_usd}")

    return override, reasons


def run_stress_fast(
    *,
    equity_usd: float,
    hwm_usd: Optional[float],
    spot_index_usd: float,
    delta_btc: float,
    gamma: float,
    vega_usd_per_vol: float,
    scenarios: list[StressScenario],
    dd_override_threshold: float = -0.08,
    regime: str = "UNKNOWN",
    gamma_pnl_cap_equity_pct: float = 0.0,
    vega_pnl_cap_equity_pct: float = 0.0,
    total_loss_floor_equity_pct: float = 0.0,
) -> StressFastResult:

    ts = _utc_now_iso()

    # compute results
    out: Dict[str, StressScenarioResult] = {}
    for s in scenarios:
        result = fast_stress_pnl_usd(
            equity_usd=equity_usd,
            hwm_usd=hwm_usd,
            spot_index_usd=spot_index_usd,
            delta_btc=delta_btc,
            gamma=gamma,
            vega_usd_per_vol=vega_usd_per_vol,
            spot_shock_pct=s.spot_shock_pct,
            iv_shock_abs=s.iv_bump_vol,
            gamma_pnl_cap_equity_pct=gamma_pnl_cap_equity_pct,
            vega_pnl_cap_equity_pct=vega_pnl_cap_equity_pct,
            total_loss_floor_equity_pct=total_loss_floor_equity_pct,
        )
        out[s.name] = result
    override, reasons = stress_override_policy(
        scenario_results=out,
        dd_override_threshold=dd_override_threshold,
    )

    # pack JSON-friendly payload
    scenarios_json = {k: asdict(v) for k, v in out.items()}
    inputs = {
        "equity_usd": float(equity_usd),
        "hwm_usd": (None if hwm_usd is None else float(hwm_usd)),
        "spot_index_usd": float(spot_index_usd),
        "delta_btc": float(delta_btc),
        "gamma": float(gamma),
        "vega_usd_per_vol": float(vega_usd_per_vol),
    }

    return StressFastResult(
        ts_utc=ts,
        method="fast_greeks",
        regime=regime,          # ← add this
        inputs=inputs,
        scenarios=scenarios_json,
        stress_override=bool(override),
        override_reasons=reasons,
    )


def to_json_dict(res: StressFastResult) -> Dict[str, Any]:
    return asdict(res)


def to_json_str(res: StressFastResult) -> str:
    return json.dumps(to_json_dict(res), indent=2, ensure_ascii=False, default=str)