# hedge_engine/risk/stress/stress_deep.py
from __future__ import annotations

import math
from dataclasses import dataclass, asdict
from typing import Any, Dict, List, Optional, Tuple

from hedge_engine.risk.stress.pricing_bs import (
    black_scholes_price,
    IvShockConfig,
    iv_after_shock,
    default_skew_bumps_pp,
)


# ----------------------------
# Config (pure / deterministic)
# ----------------------------
@dataclass(frozen=True)
class DeepStressConfig:
    # stress scenarios: name -> (spot_shock_pct, iv_bump_pp) or (spot_shock_pct, iv_bump_pp, apply_skew)
    # 2-tuple: skew is applied by default on downside (legacy behavior)
    # 3-tuple: third element controls skew application explicitly
    scenarios: Dict[str, Tuple[float, ...]]  # name -> (spot_shock_pct, iv_bump_pp[, apply_skew_bump])

    # IV constraints for implied vol solve & shocked IV clamp
    iv_floor: float = 0.05     # 5%
    iv_cap: float = 3.00       # 300% (safe upper bound for solve)
    r: float = 0.0

    # skew bumps in vol points by bucket name
    skew_bumps_pp: Optional[Dict[str, float]] = None




def default_deep_cfg() -> "DeepStressConfig":
    from hedge_engine.settings.config import EngineConfig
    cfg = EngineConfig()
    return DeepStressConfig(
        scenarios={s.name: (s.spot_shock_pct, s.iv_bump_vol, s.apply_skew_bump)
                   for s in cfg.stress_scenarios},
        iv_floor=cfg.iv_floor,
        iv_cap=3.0,
        r=cfg.r_rate,
        skew_bumps_pp={
            "PUT_10D": 9.0, "PUT_25D": 6.0, "ATM": 4.0,
            "CALL_25D": 0.0, "CALL_10D": 0.0,
        },
    )


# ----------------------------
# Helpers
# ----------------------------
def _safe_float(x: Any, default: float = 0.0) -> float:
    try:
        if x is None:
            return default
        if isinstance(x, str) and x.strip().lower() == "nan":
            return default
        v = float(x)
        if math.isnan(v) or math.isinf(v):
            return default
        return v
    except Exception:
        return default


def _position_as_dict(position: Any) -> Dict[str, Any]:
    """
    Accept either the legacy dict rows or runner-built Position objects.
    Adds a few aliases so the deep stress logic can use one stable shape.
    """
    if isinstance(position, dict):
        row = dict(position)
    elif hasattr(position, "__dataclass_fields__"):
        row = asdict(position)
    elif hasattr(position, "__dict__"):
        row = dict(vars(position))
    else:
        return {}

    option_type = str(row.get("option_type") or row.get("right") or "").strip().upper()
    if not row.get("right"):
        if option_type in ("C", "CALL"):
            row["right"] = "C"
        elif option_type in ("P", "PUT"):
            row["right"] = "P"

    dte_days = row.get("dte_days")
    if dte_days is not None:
        row.setdefault("DTE", dte_days)
        row.setdefault("dte", dte_days)
        row.setdefault("days_to_expiry", dte_days)
        row.setdefault("days_to_expiration", dte_days)

    if row.get("mark_price_usd") is not None:
        row.setdefault("mark_usd", row.get("mark_price_usd"))
    if row.get("mark_price_btc") is not None:
        row.setdefault("mark_price", row.get("mark_price_btc"))

    return row


def _contract_multiplier_btc(p: Dict[str, Any]) -> float:
    # Try common keys
    for k in ("contract_size", "contract_multiplier", "multiplier"):
        v = _safe_float(p.get(k), 0.0)
        if v > 0:
            return v
    # Fallback: Deribit BTC options are typically 1 BTC per contract.
    # If your account uses 0.1 BTC contracts, set this to 0.1 globally or detect from instrument/settlement.
    return 1.0


def _option_type_from_right(right: Any) -> Optional[str]:
    r = (right or "").strip().upper()
    if r == "C":
        return "call"
    if r == "P":
        return "put"
    return None

def _position_btc_for_option(p: Dict[str, Any]) -> float:
    # 1) explicit btc size
    for k in ("size_btc", "position_btc"):
        v = _safe_float(p.get(k), 0.0)
        if v != 0:
            return v

    # 2) contracts * contract_size
    contracts = _safe_float(p.get("contracts"), 0.0)
    cs = _safe_float(p.get("contract_size"), 0.0)
    if contracts != 0 and cs > 0:
        return contracts * cs

    # 3) if mark_price exists (BTC premium), Deribit options are typically 1 BTC per contract
    size = _safe_float(p.get("size"), 0.0)
    if size != 0 and _safe_float(p.get("mark_price"), 0.0) > 0:
        return size * 1.0

    # 4) last resort: assume size is BTC
    return size

def _skew_bucket_from_position(pos: Dict[str, Any], spot: float) -> str:
    """
    Deterministic bucket mapping.
    We only need *some* stable buckets to apply skew bumps.
    We use moneyness vs spot:
      - For puts: deeper OTM => PUT_10D else PUT_25D else ATM
      - For calls: similar buckets
    """
    right = (pos.get("right") or "").strip().upper()
    k = _safe_float(pos.get("strike"), 0.0)
    if k <= 0 or spot <= 0:
        return "ATM"

    m = k / spot  # strike/spot

    # crude deterministic mapping (tune later)
    if right == "P":
        if m <= 0.80:
            return "PUT_10D"    # deep OTM - <10 delta
        if m <= 0.92:
            return "PUT_25D"    # mid OTM - 10–20 delta
        return "ATM"            # near money - 20–30 delta
    if right == "C":
        if m >= 1.25:
            return "CALL_10D"
        if m >= 1.05:
            return "CALL_25D"
        return "ATM"
    return "ATM"


# ----------------------------
# Implied Vol solver (pure)
# ----------------------------
def implied_vol_bisect(
    *,
    target_price_usd: float,
    spot: float,
    strike: float,
    t_years: float,
    r: float,
    option_type: str,
    iv_floor: float,
    iv_cap: float,
    max_iter: int = 60,
    tol: float = 1e-6,
) -> Optional[float]:
    """
    Deterministic implied vol via bisection.
    Returns IV (decimal), or None if cannot solve.
    """
    target = _safe_float(target_price_usd, 0.0)
    if target <= 0:
        # could be near-zero option; return floor as conservative
        return float(iv_floor)

    s = float(spot)
    k = float(strike)
    t = float(t_years)
    if s <= 0 or k <= 0 or t <= 0:
        return None

    lo = float(iv_floor)
    hi = float(iv_cap)

    # Ensure monotonic bracket: price(lo) <= target <= price(hi)
    plo = black_scholes_price(spot=s, strike=k, t_years=t, iv=lo, r=r, option_type=option_type)
    phi = black_scholes_price(spot=s, strike=k, t_years=t, iv=hi, r=r, option_type=option_type)

    # If even at cap it is below target => cap is too low or data inconsistent
    if phi < target:
        return None

    # If at floor already above target, return floor
    if plo > target:
        return None

    for _ in range(max_iter):
        mid = 0.5 * (lo + hi)
        pmid = black_scholes_price(spot=s, strike=k, t_years=t, iv=mid, r=r, option_type=option_type)

        if abs(pmid - target) <= tol:
            return mid

        if pmid < target:
            lo = mid
        else:
            hi = mid

    return 0.5 * (lo + hi)


# ----------------------------
# Core deep repricing
# ----------------------------
def deep_reprice(
    *,
    positions: List[Any],
    equity_usd: float,
    hwm_usd: Optional[float],
    spot_index_usd: float,
    cfg: Optional[DeepStressConfig] = None,
) -> Dict[str, Any]:
    """
    Deep stress:
      - Options: derive base option price (USD), infer base IV via bisection, apply IV shock + skew bump,
                reprice with Black–Scholes, compute PnL.
      - Perps/Futures: linear PnL using estimated BTC position size * ΔS.
    Returns StressResult dict compatible with your Phase4 output style.
    """
    import datetime as _dt

    if cfg is None:
        raise RuntimeError("Deep stress requires DeepStressConfig from EngineConfig")

    skew_bumps = cfg.skew_bumps_pp or default_skew_bumps_pp()

    base_spot = float(spot_index_usd)
    base_equity = float(equity_usd)

    def _is_option_row(p: Dict[str, Any]) -> bool:
        right = (p.get("right") or "").strip().upper()
        if right in ("C", "P"):
            return True
        name = (p.get("instrument_name") or "").strip().upper()
        return name.endswith("-C") or name.endswith("-P")

    def _option_type(p: Dict[str, Any]) -> Optional[str]:
        right = (p.get("right") or "").strip().upper()
        if right == "C":
            return "call"
        if right == "P":
            return "put"
        name = (p.get("instrument_name") or "").strip().upper()
        if name.endswith("-C"):
            return "call"
        if name.endswith("-P"):
            return "put"
        return None

    def _get_dte_days(p: Dict[str, Any]) -> Optional[float]:
        import datetime as _dt

        # 1) explicit DTE fields
        for k in ("DTE", "dte", "days_to_expiry", "days_to_expiration"):
            if k in p and p.get(k) is not None:
                d = _safe_float(p.get(k), None)
                if d is not None:
                    return max(0.0, float(d))

        # 2) ISO expiry fields
        exp = p.get("expiry") or p.get("expiration")
        if exp:
            try:
                s = str(exp).replace("Z", "+00:00")
                dt = _dt.datetime.fromisoformat(s)
                if dt.tzinfo is None:
                    dt = dt.replace(tzinfo=_dt.timezone.utc)
                now = _dt.datetime.now(_dt.timezone.utc)
                return max(0.0, (dt - now).total_seconds() / 86400.0)
            except Exception:
                pass

        # 3) fallback: parse expiry from instrument_name: BTC-24APR26-50000-P
        name = (p.get("instrument_name") or "").strip().upper()
        try:
            parts = name.split("-")
            if len(parts) >= 4:
                exp_token = parts[1]  # "24APR26"
                # Deribit expiry ~08:00 UTC
                dt = _dt.datetime.strptime(exp_token, "%d%b%y").replace(
                    hour=8, minute=0, second=0, microsecond=0, tzinfo=_dt.timezone.utc
                )
                now = _dt.datetime.now(_dt.timezone.utc)
                return max(0.0, (dt - now).total_seconds() / 86400.0)
        except Exception:
            return None

        return None


    def _finite(x: Any) -> bool:
        try:
            v = float(x)
            return math.isfinite(v)
        except Exception:
            return False


    def _get_base_option_price_usd(p: Dict[str, Any], base_spot: float) -> float:
        """
        Deep stress must use CURRENT market mark, not entry average.
        Priority:
        1) mark_usd
        2) mark_price_usd
        3) mark_price (BTC premium) * index_price (or base_spot)
        Never use avg/average price here.
        """
        v = p.get("mark_usd")
        if _finite(v) and float(v) > 0:
            return float(v)

        v = p.get("mark_price_usd")
        if _finite(v) and float(v) > 0:
            return float(v)

        mp_btc = p.get("mark_price") or p.get("mark_price_btc")
        if _finite(mp_btc) and float(mp_btc) > 0:
            idx = p.get("index_price")
            if not (_finite(idx) and float(idx) > 0):
                idx = base_spot
            return float(mp_btc) * float(idx)

        return 0.0

    def _get_signed_size(p: Dict[str, Any]) -> float:
        # In your snapshots, "size" is signed (short negative).
        # Sometimes there is "qty" or "amount".
        for k in ("size", "qty", "amount", "position"):
            if k in p and p.get(k) is not None:
                s = _safe_float(p.get(k), 0.0)
                if s != 0:
                    return s
        return 0.0

    scenarios_out: Dict[str, Any] = {}

    for scen_name, scen_tuple in cfg.scenarios.items():
        # Support 2-tuple (legacy) or 3-tuple (with explicit skew flag)
        spot_shock_pct = float(scen_tuple[0])
        iv_bump_pp = float(scen_tuple[1])
        # Third element: apply_skew_bump (default: True for downside, False for upside)
        if len(scen_tuple) >= 3:
            scenario_apply_skew = bool(scen_tuple[2])
        else:
            scenario_apply_skew = True  # legacy: skew applied on downside by default
        shocked_spot = base_spot * (1.0 + float(spot_shock_pct))
        dS = shocked_spot - base_spot

        pnl_options = 0.0
        pnl_linear = 0.0

        option_rows: List[Dict[str, Any]] = []
        linear_rows: List[Dict[str, Any]] = []

        # counters to stop “silent skips”
        counts = {
            "total_rows": 0,
            "opt_detected": 0,
            "opt_skipped_no_type": 0,
            "opt_skipped_no_strike": 0,
            "opt_skipped_no_dte": 0,
            "opt_skipped_no_price": 0,
            "opt_skipped_size0": 0,
            "opt_skipped_iv_fail": 0,
            "opt_priced": 0,
            "lin_detected": 0,
            "lin_priced": 0,
        }

        for raw_position in positions:
            p = _position_as_dict(raw_position)
            counts["total_rows"] += 1

            # -----------------
            # Options repricing
            # -----------------
            if _is_option_row(p):
                counts["opt_detected"] += 1

                opt_type = _option_type(p)
                if opt_type is None:
                    counts["opt_skipped_no_type"] += 1
                    continue

                # --- strike (robust) ---
                strike = 0.0

                # try common keys first
                for k in ("strike", "strike_price", "strike_usd"):
                    v = _safe_float(p.get(k), 0.0)
                    if v > 0:
                        strike = v
                        break

                # fallback: parse from instrument_name: BTC-24APR26-50000-P
                if strike <= 0:
                    name = (p.get("instrument_name") or "")
                    try:
                        parts = name.split("-")
                        if len(parts) >= 4:
                            strike = float(parts[2])  # the "50000" part
                    except Exception:
                        strike = 0.0

                if strike <= 0:
                    counts["opt_skipped_no_strike"] += 1
                    continue

                dte_days = _get_dte_days(p)
                if dte_days is None or dte_days <= 0:
                    counts["opt_skipped_no_dte"] += 1
                    continue
                t_years = max(0.0, float(dte_days) / 365.0)

                base_price = _get_base_option_price_usd(p, base_spot=base_spot)
                if base_price <= 0:
                    counts["opt_skipped_no_price"] += 1
                    continue

                size_signed = _get_signed_size(p)
                if size_signed == 0:
                    counts["opt_skipped_size0"] += 1
                    continue

                base_iv = implied_vol_bisect(
                    target_price_usd=base_price,
                    spot=base_spot,
                    strike=strike,
                    t_years=t_years,
                    r=cfg.r,
                    option_type=opt_type,
                    iv_floor=cfg.iv_floor,
                    iv_cap=cfg.iv_cap,
                )
                if base_iv is None:
                    counts["opt_skipped_iv_fail"] += 1
                    option_rows.append({
                        "instrument_name": p.get("instrument_name"),
                        "reason": "iv_solve_failed_floor_price_above_market",
                        "base_price_usd": base_price,
                        "strike": strike,
                        "dte_days": dte_days,
                    })
                    continue

                bucket = _skew_bucket_from_position(p, base_spot)

                # Skew steepening: only on downside scenarios AND only when
                # the scenario config flag apply_skew_bump is True.
                # Fixed: previously ignored apply_skew_bump flag from scenario config.
                is_downside = float(spot_shock_pct) < 0
                apply_skew = is_downside and scenario_apply_skew
                active_skew = skew_bumps if apply_skew else {k: 0.0 for k in skew_bumps}

                shock_cfg = IvShockConfig(
                    scenario_iv_bump_pp=float(iv_bump_pp),
                    skew_bump_by_bucket_pp=active_skew,
                    iv_floor=cfg.iv_floor,
                    iv_cap=cfg.iv_cap,
                )
                shocked_iv = iv_after_shock(base_iv=base_iv, cfg=shock_cfg, skew_delta_bucket=bucket)

                shocked_price = black_scholes_price(
                    spot=shocked_spot,
                    strike=strike,
                    t_years=t_years,
                    iv=shocked_iv,
                    r=cfg.r,
                    option_type=opt_type,
                )

                # Position sizing:
                # _position_btc_for_option returns the signed BTC notional of the position.
                # For Deribit BTC options: size = signed contract count, 1 contract = 1 BTC,
                #   so pos_btc = size = signed BTC notional already.
                # BS prices (base_price, shocked_price) are USD per 1 BTC of underlying.
                # PnL = (shocked_price - base_price) * pos_btc
                #   → positive when long and price goes up, or short and price goes down.
                # NOTE: Do NOT multiply by _contract_multiplier_btc() - that would double-count
                #   since pos_btc already includes the BTC scaling via size.
                pos_btc = _position_btc_for_option(p)
                if pos_btc == 0:
                    counts["opt_skipped_size0"] += 1
                    continue
                pnl_i = (shocked_price - base_price) * pos_btc
                pnl_options += pnl_i

                counts["opt_priced"] += 1
                option_rows.append(
                    {
                        "instrument_name": p.get("instrument_name"),
                        "bucket": bucket,
                        "size": size_signed,
                        "strike": strike,
                        "dte_days": dte_days,
                        "base_price_usd": base_price,
                        "base_iv": base_iv,
                        "shocked_iv": shocked_iv,
                        "shocked_price_usd": shocked_price,
                        "pnl_usd": pnl_i,
                    }
                )
                continue

            # -----------------
            # Linear instruments
            # -----------------
            kind = (p.get("kind") or "").strip().lower()
            if kind in ("perpetual", "future", "futures") or (p.get("instrument_name") == "BTC-PERPETUAL"):
                counts["lin_detected"] += 1

                size_raw = _safe_float(p.get("size"), 0.0)
                idx_px = _safe_float(p.get("index_price"), base_spot)
                if idx_px <= 0:
                    idx_px = base_spot

                # Approx BTC exposure from USD notional / index
                btc_pos = size_raw / idx_px if idx_px > 0 else 0.0
                pnl_i = btc_pos * dS
                pnl_linear += pnl_i

                counts["lin_priced"] += 1
                linear_rows.append(
                    {
                        "instrument_name": p.get("instrument_name"),
                        "kind": kind or "future",
                        "size_raw": size_raw,
                        "btc_pos_est": btc_pos,
                        "pnl_usd": pnl_i,
                    }
                )
                continue

        pnl_total = pnl_options + pnl_linear
        projected_equity = base_equity + pnl_total

        projected_dd = None
        if hwm_usd is not None and float(hwm_usd) > 0:
            projected_dd = (projected_equity / float(hwm_usd)) - 1.0
            projected_dd = min(0.0, projected_dd)

        scenarios_out[scen_name] = {
            "spot_shock_pct": float(spot_shock_pct),
            "iv_shock_abs": float(iv_bump_pp),  # vol points
            "base_spot_usd": base_spot,
            "shocked_spot_usd": shocked_spot,
            "dS_usd": dS,
            "pnl_options_usd": pnl_options,
            "pnl_linear_usd": pnl_linear,
            "pnl_total_usd": pnl_total,
            "projected_equity_usd": projected_equity,
            "projected_dd_worst": projected_dd,
            "debug": {
                "counts": counts,
                "options_rows": option_rows[:50],
                "linear_rows": linear_rows[:50],
                "skew_bumps_pp": skew_bumps,
            },
        }

    return {
        "method": "deep_reprice",
        "inputs": {
            "equity_usd": base_equity,
            "hwm_usd": None if hwm_usd is None else float(hwm_usd),
            "spot_index_usd": base_spot,
        },
        "scenarios": scenarios_out,
    }
