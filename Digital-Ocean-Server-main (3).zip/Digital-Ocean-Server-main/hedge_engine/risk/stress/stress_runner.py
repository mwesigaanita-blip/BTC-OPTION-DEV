# FILE: hedge_engine/risk/stress/stress_runner.py
"""
PHASE 4.4 - Deep stress trigger wiring + unified stress artifact.

Produces ONE dict per tick:
- always includes FAST stress
- optionally includes DEEP stress if triggered (or forced)

Designed to be:
- deterministic
- unit-testable
- runner/CLI friendly
"""

from __future__ import annotations

from datetime import datetime, timezone
import logging
from typing import Any, Dict, Optional, Tuple, List


# -----------------------------
# Small utils
# -----------------------------

def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def safe_float(x: Any, default: float = 0.0) -> float:
    try:
        return float(x)
    except Exception:
        return default


def _get(obj: Any, key: str, default: Any = None) -> Any:
    """Support both dataclasses/objects and dicts."""
    if obj is None:
        return default
    if isinstance(obj, dict):
        return obj.get(key, default)
    return getattr(obj, key, default)


def _scenario_name(scenario: Any) -> str:
    return str(_get(scenario, "name", "") or "").strip()


def _scenario_spot_shock_pct(scenario: Any) -> float:
    return safe_float(_get(scenario, "spot_shock_pct", 0.0), 0.0)


def _scenario_iv_bump_vol(scenario: Any) -> float:
    return safe_float(_get(scenario, "iv_bump_vol", 0.0), 0.0)


def select_active_scenarios(*, cfg: Any, regime: str) -> Tuple[List[Any], Dict[str, Any]]:
    """
    Select active stress scenarios from the real configured scenario objects.

    Rules mirror the intended severity ladder without relying on fragile
    short IDs:
      - LOW: mild moves only (<= 5% spot shock and <= 5 vol bump)
      - NORMAL: all non-extreme scenarios (<= 10 vol bump)
      - HIGH: all configured scenarios

    If a custom config would otherwise produce an empty set, fall back to all
    configured scenarios so the pipeline never fails silently.
    """
    all_scenarios = [
        scenario
        for scenario in list(_get(cfg, "stress_scenarios", []) or [])
        if _scenario_name(scenario)
    ]

    if regime == "LOW":
        active_scenarios = [
            scenario
            for scenario in all_scenarios
            if abs(_scenario_spot_shock_pct(scenario)) <= 0.05 + 1e-12
            and _scenario_iv_bump_vol(scenario) <= 5.0 + 1e-12
        ]
        selection_mode = "severity_rules_low"
    elif regime == "NORMAL":
        active_scenarios = [
            scenario
            for scenario in all_scenarios
            if _scenario_iv_bump_vol(scenario) <= 10.0 + 1e-12
        ]
        selection_mode = "severity_rules_normal"
    else:
        active_scenarios = list(all_scenarios)
        selection_mode = "all_configured_high"

    fallback_used = False
    if all_scenarios and not active_scenarios:
        active_scenarios = list(all_scenarios)
        fallback_used = True
        selection_mode = "fallback_all_configured"

    debug = {
        "selection_mode": selection_mode,
        "selection_fallback_used": fallback_used,
        "configured_scenarios_count": len(all_scenarios),
        "active_scenarios_count": len(active_scenarios),
        "active_scenario_names": [_scenario_name(scenario) for scenario in active_scenarios],
    }
    return active_scenarios, debug


def min_projected_dd_from_scenarios(stress_result: Dict[str, Any]) -> float:
    """
    Returns the most negative projected drawdown found in scenarios.
    Supports both:
      - projected_dd
      - projected_dd_worst
    """
    scenarios = stress_result.get("scenarios") or stress_result.get("by_scenario") or None
    dds: List[float] = []

    def _row_dd(d: Dict[str, Any]) -> float:
        return safe_float(
            d.get("projected_dd", None)
            if d.get("projected_dd", None) is not None
            else d.get("projected_dd_worst", 0.0),
            0.0,
        )

    if isinstance(scenarios, dict):
        for v in scenarios.values():
            if isinstance(v, dict):
                dds.append(_row_dd(v))

    elif isinstance(scenarios, list):
        for row in scenarios:
            if isinstance(row, dict):
                dds.append(_row_dd(row))

    return min(dds) if dds else 0.0


def normalize_scenario_block(block: Optional[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    """
    Add a few stable aliases so downstream consumers can treat fast/deep
    scenario rows consistently without losing the raw block structure.
    """
    if not isinstance(block, dict):
        return block

    scenarios = block.get("scenarios") or block.get("by_scenario")
    if not isinstance(scenarios, dict):
        return block

    for scenario_name, row in scenarios.items():
        if not isinstance(row, dict):
            continue
        row.setdefault("scenario_name", scenario_name)
        if row.get("iv_bump_vol") is None and row.get("iv_shock_abs") is not None:
            row["iv_bump_vol"] = row.get("iv_shock_abs")
        if row.get("pnl_usd") is None and row.get("pnl_total_usd") is not None:
            row["pnl_usd"] = row.get("pnl_total_usd")
        if row.get("projected_dd") is None and row.get("projected_dd_worst") is not None:
            row["projected_dd"] = row.get("projected_dd_worst")
        if row.get("projected_equity_usd") is None and row.get("projected_equity") is not None:
            row["projected_equity_usd"] = row.get("projected_equity")

    return block


def build_display_rows(
    *,
    fast: Optional[Dict[str, Any]],
    deep: Optional[Dict[str, Any]],
    regime: str,
    ts_utc: str,
) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []

    def _append_rows(block: Optional[Dict[str, Any]], source: str) -> None:
        if not isinstance(block, dict):
            return

        scenarios = block.get("scenarios") or block.get("by_scenario") or {}
        if not isinstance(scenarios, dict):
            return

        block_ts_utc = str(block.get("ts_utc") or ts_utc)
        for scenario_name, result in scenarios.items():
            if not isinstance(result, dict):
                continue
            rows.append(
                {
                    "scenario_name": str(result.get("scenario_name") or scenario_name),
                    "source": source,
                    "spot_shock_pct": result.get("spot_shock_pct", result.get("spot_shock", None)),
                    "iv_bump_vol": result.get(
                        "iv_bump_vol",
                        result.get("iv_shock_abs", result.get("iv_bump", None)),
                    ),
                    "pnl_usd": result.get("pnl_usd", result.get("pnl_total_usd", None)),
                    "projected_equity_usd": result.get("projected_equity_usd", result.get("projected_equity", None)),
                    "projected_dd": result.get("projected_dd", result.get("projected_dd_worst", None)),
                    "regime": regime,
                    "ts_utc": block_ts_utc,
                }
            )

    _append_rows(fast, "fast")
    _append_rows(deep, "deep")
    return rows


# -----------------------------
# Trigger policy
# -----------------------------

def should_run_deep_stress(
    *,
    dd_worst: float,
    mm_pct: float,
    speed_trigger: bool,
    vega_breach: bool,
    gamma_breach: bool,
    fast_min_projected_dd: float,
    cfg: Any,
    last_deep_run_ts_utc: Optional[str] = None,
    now_ts_utc: Optional[str] = None,
) -> Tuple[bool, Dict[str, Any]]:
    """
    Deep stress runs when ANY condition is true:
      - dd_worst <= -2%
      - mm_pct >= 85
      - speed_trigger
      - vega_breach or gamma_breach
      - fast_min_projected_dd <= -8%
      - interval elapsed (default 10 minutes)
    """
    now_ts_utc = now_ts_utc or utc_now_iso()

    # Defaults align with the plan
    dd_trigger = safe_float(_get(cfg, "DEEP_STRESS_DD_TRIGGER", -0.02), -0.02)
    mm_trigger = safe_float(_get(cfg, "MM_WARN_PCT", 85.0), 85.0)
    fast_trigger = safe_float(_get(cfg, "FAST_STRESS_OVERRIDE_DD", -0.08), -0.08)
    interval_sec = int(_get(cfg, "DEEP_STRESS_INTERVAL_SEC", 600))

    reasons: List[str] = []

    if dd_worst <= dd_trigger:
        reasons.append(f"dd_worst<= {dd_trigger:.2%}")
    if mm_pct >= mm_trigger:
        reasons.append(f"mm_pct>= {mm_trigger:.2f}")
    if speed_trigger:
        reasons.append("speed_trigger")
    if vega_breach:
        reasons.append("vega_breach")
    if gamma_breach:
        reasons.append("gamma_breach")
    if fast_min_projected_dd <= fast_trigger:
        reasons.append(f"fast_min_projected_dd<= {fast_trigger:.2%}")

    # interval gating (deterministic)
    if interval_sec > 0 and last_deep_run_ts_utc:
        try:
            last_dt = datetime.fromisoformat(last_deep_run_ts_utc.replace("Z", "+00:00"))
            now_dt = datetime.fromisoformat(now_ts_utc.replace("Z", "+00:00"))
            delta_s = (now_dt - last_dt).total_seconds()
            if delta_s >= interval_sec:
                reasons.append(f"interval_elapsed({int(delta_s)}s>={interval_sec}s)")
        except Exception:
            # If parsing fails, do NOT force deep by interval alone
            pass

    run_deep = bool(reasons)

    debug = {
        "now_ts_utc": now_ts_utc,
        "last_deep_run_ts_utc": last_deep_run_ts_utc,
        "thresholds": {
            "dd_trigger": dd_trigger,
            "mm_trigger": mm_trigger,
            "fast_trigger": fast_trigger,
            "interval_sec": interval_sec,
        },
        "inputs": {
            "dd_worst": dd_worst,
            "mm_pct": mm_pct,
            "speed_trigger": bool(speed_trigger),
            "vega_breach": bool(vega_breach),
            "gamma_breach": bool(gamma_breach),
            "fast_min_projected_dd": fast_min_projected_dd,
        },
        "reasons": reasons,
        "run_deep": run_deep,
    }
    return run_deep, debug


# -----------------------------
# Unified stress artifact
# -----------------------------
def normalize_deep_to_unified(deep: Dict[str, Any]) -> Dict[str, Any]:
    """
    Normalize deep_reprice output to a consistent schema:
      deep["scenarios"][Si]["projected_dd"] always exists
      deep["min_projected_dd"] always exists
    Keeps original deep fields untouched where possible.
    """
    if not isinstance(deep, dict):
        return deep

    scenarios = deep.get("scenarios")
    if isinstance(scenarios, dict):
        for _, row in scenarios.items():
            if not isinstance(row, dict):
                continue
            if "projected_dd" not in row and "projected_dd_worst" in row:
                row["projected_dd"] = row["projected_dd_worst"]
            if "projected_equity_usd" not in row and "projected_equity" in row:
                row["projected_equity_usd"] = row["projected_equity"]

    # ensure deep-level min_projected_dd exists
    if "min_projected_dd" not in deep or deep.get("min_projected_dd") is None:
        deep["min_projected_dd"] = min_projected_dd_from_scenarios(deep)

    return normalize_scenario_block(deep)


def compute_stress_artifact(
    *,
    snapshot: Any,
    state: Any,
    flags: Any,
    cfg: Any,
    last_deep_run_ts_utc: Optional[str] = None,
    force_deep: bool = False,
    now_ts_utc: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Main entrypoint for engine runner / CLI.

    Returns:
      stress_artifact dict containing:
        - fast (always)
        - deep (optional)
        - trigger debug
        - stress_override + reasons
    """
    now_ts_utc = now_ts_utc or utc_now_iso()

    # import lazily to avoid circular imports
    from hedge_engine.risk.stress.stress_fast import run_stress_fast, to_json_dict
    from hedge_engine.risk.stress.stress_deep import deep_reprice

    # core fields
    spot = safe_float(_get(snapshot, "spot_index_usd", 0.0), 0.0)
    equity_usd = safe_float(_get(snapshot, "equity_usd", 0.0), 0.0)
    hwm_usd = safe_float(_get(state, "hwm_usd", 0.0), 0.0)

    dd_worst = safe_float(
        _get(state, "dd_worst", None) if _get(state, "dd_worst", None) is not None else _get(state, "dd", 0.0),
        0.0
    )
    mm_pct = safe_float(_get(snapshot, "mm_pct", 0.0), 0.0)

    speed_trigger = bool(_get(flags, "speed_trigger", False))
    vega_breach = bool(_get(flags, "vega_breach", False))
    gamma_breach = bool(_get(flags, "gamma_budget_breach", False))

    # 1) FAST always (your implementation uses run_stress_fast)
    # Fixed: chained _get for nested greeks access (flat _get does not support nested keys)
    delta_btc = safe_float(
        _get(snapshot, "portfolio_delta_btc", None)
        or _get(_get(snapshot, "greeks", {}), "delta_btc", None)
        or _get(snapshot, "delta_btc", 0.0),
        0.0,
    )
    gamma = safe_float(
        _get(snapshot, "portfolio_gamma", None)
        or _get(_get(snapshot, "greeks", {}), "gamma", None)
        or _get(snapshot, "gamma", 0.0),
        0.0,
    )
    vega = safe_float(
        _get(snapshot, "portfolio_vega_usd_per_vol", None)
        or _get(snapshot, "portfolio_vega", None)
        or _get(_get(snapshot, "greeks", {}), "vega", None)
        or _get(snapshot, "vega", 0.0),
        0.0,
    )
    if not getattr(cfg, "stress_scenarios", None):
        raise RuntimeError("No stress_scenarios defined in EngineConfig")
    
    # ── Regime detection ──────────────────────────────
    hv30   = safe_float(_get(snapshot, "hv_30d_pct",     0.0), 0.0) / 100.0
    iv30   = safe_float(_get(snapshot, "iv_atm_30d_pct", 0.0), 0.0) / 100.0

    # iv_minus_hv_30d_pp is already in vol points (e.g. -4.77pp)
    # so divide by 100 to get decimal spread
    spread_raw = _get(snapshot, "iv_minus_hv_30d_pp", None)
    if spread_raw is not None:
        spread = safe_float(spread_raw, 0.0) / 100.0
    else:
        spread = iv30 - hv30

    # Step 1: base regime from HV30 (realized vol)
    if hv30 < 0.35:
        regime = "LOW"
    elif hv30 < 0.55:
        regime = "NORMAL"
    else:
        regime = "HIGH"

    # Step 2: adjust using IV-HV spread (forward-looking market signal)
    # Upgrade: market is pricing in significantly more risk than realized vol shows
    if spread >= 0.15 and regime == "LOW":
        logging.warning(f"Regime upgrade LOW->NORMAL due to high IV-HV spread ({spread*100:.2f}pp)")
        regime = "NORMAL"
    elif spread >= 0.20 and regime == "NORMAL":
        logging.warning(f"Regime upgrade NORMAL->HIGH due to very high IV-HV spread ({spread*100:.2f}pp)")
        regime = "HIGH"

    # Downgrade: realized vol spike has passed and market has settled
    if spread <= -0.15 and regime == "HIGH":
        logging.warning(f"Regime downgrade HIGH->NORMAL due to low IV-HV spread ({spread*100:.2f}pp)")
        regime = "NORMAL"

    active_scenarios, scenario_debug = select_active_scenarios(cfg=cfg, regime=regime)

    fast_res = run_stress_fast(
        equity_usd=equity_usd,
        hwm_usd=(hwm_usd if hwm_usd > 0 else None),
        spot_index_usd=spot,
        delta_btc=delta_btc,
        gamma=gamma,
        vega_usd_per_vol=vega,
        regime=regime,
        scenarios=active_scenarios,
        dd_override_threshold=safe_float(_get(cfg, "FAST_STRESS_OVERRIDE_DD", -0.08), -0.08),
        gamma_pnl_cap_equity_pct=safe_float(
            _get(cfg, "FAST_STRESS_GAMMA_PNL_CAP_EQUITY_PCT", 0.0), 0.0,
        ),
        vega_pnl_cap_equity_pct=safe_float(
            _get(cfg, "FAST_STRESS_VEGA_PNL_CAP_EQUITY_PCT", 0.0), 0.0,
        ),
        total_loss_floor_equity_pct=safe_float(
            _get(cfg, "FAST_STRESS_TOTAL_LOSS_FLOOR_EQUITY_PCT", 0.0), 0.0,
        ),
    )
    fast = normalize_scenario_block(to_json_dict(fast_res))
    fast_min_dd = min_projected_dd_from_scenarios(fast)

    # 2) decide deep trigger
    if force_deep:
        run_deep = True
        deep_trigger_debug = {"run_deep": True, "reasons": ["force_deep"], "now_ts_utc": now_ts_utc}
    else:
        run_deep, deep_trigger_debug = should_run_deep_stress(
            dd_worst=dd_worst,
            mm_pct=mm_pct,
            speed_trigger=speed_trigger,
            vega_breach=vega_breach,
            gamma_breach=gamma_breach,
            fast_min_projected_dd=fast_min_dd,
            cfg=cfg,
            last_deep_run_ts_utc=last_deep_run_ts_utc,
            now_ts_utc=now_ts_utc,
        )

    # 3) DEEP conditional
    deep = None
    if run_deep:
        from hedge_engine.risk.stress.stress_deep import DeepStressConfig

        # Build DeepStressConfig from EngineConfig (bidirectional scenarios)
        stress_scenarios = getattr(cfg, "stress_scenarios", None)
        if not stress_scenarios:
            raise RuntimeError("EngineConfig.stress_scenarios is missing")

        skew = getattr(cfg, "skew_bump", None)

        # convert to dict if needed
        if hasattr(skew, "__dict__"):
            skew = dict(skew.__dict__)
        elif not isinstance(skew, dict):
            logging.warning("No skew bump config found in EngineConfig, using defaults")
            skew = None

        deep_cfg = DeepStressConfig(
            scenarios={
                s.name: (s.spot_shock_pct, s.iv_bump_vol, s.apply_skew_bump)
                for s in active_scenarios          # ← use active_scenarios, not all
            },
            iv_floor=cfg.iv_floor,
            iv_cap=3.0,
            r=cfg.r_rate,
            skew_bumps_pp=skew,
        )

        deep = deep_reprice(
            positions=_get(snapshot, "positions", []),
            equity_usd=equity_usd,
            hwm_usd=hwm_usd,
            spot_index_usd=spot,
            cfg=deep_cfg,
        )

        deep = normalize_deep_to_unified(deep)
    display_rows = build_display_rows(
        fast=fast,
        deep=deep,
        regime=regime,
        ts_utc=now_ts_utc,
    )
    debug = {
        **scenario_debug,
        "fast_scenario_rows_count": len([row for row in display_rows if row.get("source") == "fast"]),
        "deep_scenario_rows_count": len([row for row in display_rows if row.get("source") == "deep"]),
    }

    # 4) Unified override logic
    override_dd = safe_float(_get(cfg, "FAST_STRESS_OVERRIDE_DD", -0.08), -0.08)
    override_reasons: List[str] = []

    if fast_min_dd <= override_dd:
        override_reasons.append(f"fast_min_projected_dd<= {override_dd:.2%}")

    if deep:
        deep_min_dd = safe_float(deep.get("min_projected_dd", None), None)
        if deep_min_dd is None:
            deep_min_dd = min_projected_dd_from_scenarios(deep)

        if deep_min_dd <= override_dd:
            override_reasons.append(f"deep_min_projected_dd<= {override_dd:.2%}")

    stress_override = bool(override_reasons)

    return {
        "version": "phase4.5",
        "ts_utc": now_ts_utc,
        "spot_index_usd": spot,
        "equity_usd": equity_usd,
        "hwm_usd": hwm_usd,
        "dd_worst": dd_worst,
        "mm_pct": mm_pct,
        "regime": regime,
        "debug": debug,
        "fast": fast,
        "deep": deep,
        "display_rows": display_rows,
        "deep_trigger": deep_trigger_debug,
        "stress_override": stress_override,
        "stress_override_reasons": override_reasons,
    }


def run_stress_pipeline_sanity_check(cfg: Optional[Any] = None) -> Dict[str, Any]:
    """
    Lightweight self-check for local debugging and unit tests.
    Verifies:
      - configured scenarios exist
      - each regime selects at least one active scenario
      - display_rows is populated on valid mock inputs
    """
    if cfg is None:
        from hedge_engine.settings.config import EngineConfig

        cfg = EngineConfig()

    configured = list(_get(cfg, "stress_scenarios", []) or [])
    assert configured, "Expected EngineConfig.stress_scenarios to be non-empty"

    regime_inputs = {
        "LOW": {"hv_30d_pct": 28.0, "iv_atm_30d_pct": 35.0, "iv_minus_hv_30d_pp": 7.0},
        "NORMAL": {"hv_30d_pct": 45.0, "iv_atm_30d_pct": 55.0, "iv_minus_hv_30d_pp": 10.0},
        "HIGH": {"hv_30d_pct": 65.0, "iv_atm_30d_pct": 80.0, "iv_minus_hv_30d_pp": 15.0},
    }

    summary: Dict[str, Any] = {
        "configured_scenarios_count": len(configured),
        "regimes": {},
    }

    for regime_name, regime_snapshot in regime_inputs.items():
        active_scenarios, scenario_debug = select_active_scenarios(cfg=cfg, regime=regime_name)
        assert scenario_debug["configured_scenarios_count"] > 0
        assert scenario_debug["active_scenarios_count"] > 0

        artifact = compute_stress_artifact(
            snapshot={
                "spot_index_usd": 70_000.0,
                "equity_usd": 100_000.0,
                "portfolio_delta_btc": 1.25,
                "portfolio_gamma": -0.0004,
                "portfolio_vega": -2_000.0,
                "positions": [],
                **regime_snapshot,
            },
            state={
                "hwm_usd": 105_000.0,
                "dd": -0.01,
            },
            flags={
                "speed_trigger": False,
                "vega_breach": False,
                "gamma_budget_breach": False,
            },
            cfg=cfg,
            force_deep=True,
            now_ts_utc="2026-01-01T00:00:00+00:00",
        )

        display_rows = artifact.get("display_rows") or []
        assert artifact.get("regime") == regime_name
        assert active_scenarios
        assert display_rows, f"Expected display_rows for regime {regime_name}"

        summary["regimes"][regime_name] = {
            "active_scenarios_count": scenario_debug["active_scenarios_count"],
            "active_scenario_names": scenario_debug["active_scenario_names"],
            "display_rows_count": len(display_rows),
        }

    return summary


if __name__ == "__main__":
    import json

    print(json.dumps(run_stress_pipeline_sanity_check(), indent=2))
