# hedge_engine/risk/stress/stress_truth.py
"""
Stress truth selection and fast-vs-deep reconciliation.

Design:
  - Deep stress = primary decision truth when available and valid
  - Fast stress = screening / trigger / fallback only
  - Every consumer sees an explicit `stress_truth_source` tag

This module provides:
  1. select_stress_truth()      - pick the authoritative worst DD
  2. reconcile_fast_deep()      - per-scenario side-by-side comparison
  3. extract_worst_dd()         - unified worst-DD extractor with source tag
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional, Tuple

from hedge_engine.risk.stress.stress_runner import (
    min_projected_dd_from_scenarios,
    safe_float,
)


# ─────────────────────────────────────────────
# 1.  Worst-DD extractor with source tag
# ─────────────────────────────────────────────

def extract_worst_dd(
    stress_artifact: Optional[Dict[str, Any]],
    *,
    fallback_dd: float = 0.0,
) -> Tuple[float, str]:
    """
    Return (worst_projected_dd, source) from a stress artifact.

    Priority:
      1. deep block → "deep"
      2. fast block → "fast"
      3. fallback   → "fallback"

    This is the SINGLE function every downstream consumer should call
    instead of manually reading artifact["fast"].
    """
    if not stress_artifact or not isinstance(stress_artifact, dict):
        return fallback_dd, "fallback"

    # ── Try deep first ──
    deep = stress_artifact.get("deep")
    if _block_is_valid(deep):
        deep_dd = min_projected_dd_from_scenarios(deep)
        if deep_dd != 0.0 or fallback_dd >= 0:
            return deep_dd, "deep"

    # ── Fall back to fast ──
    fast = stress_artifact.get("fast")
    if _block_is_valid(fast):
        fast_dd = min_projected_dd_from_scenarios(fast)
        if fast_dd != 0.0 or fallback_dd >= 0:
            return fast_dd, "fast"

    return fallback_dd, "fallback"


def _block_is_valid(block: Any) -> bool:
    """A stress block is valid if it is a dict with at least one scenario row."""
    if not isinstance(block, dict):
        return False
    scenarios = block.get("scenarios") or block.get("by_scenario")
    if not scenarios:
        return False
    if isinstance(scenarios, dict) and len(scenarios) > 0:
        return True
    if isinstance(scenarios, list) and len(scenarios) > 0:
        return True
    return False


# ─────────────────────────────────────────────
# 2.  Fast-vs-deep reconciliation
# ─────────────────────────────────────────────

def reconcile_fast_deep(
    stress_artifact: Optional[Dict[str, Any]],
) -> Dict[str, Any]:
    """
    Build a per-scenario side-by-side comparison of fast vs deep results.

    Returns dict with:
      - scenarios: list of per-scenario comparison rows
      - fast_worst_dd, deep_worst_dd
      - truth_source
      - summary stats (max_abs_diff, etc.)
    """
    if not stress_artifact or not isinstance(stress_artifact, dict):
        return {"scenarios": [], "truth_source": "unavailable"}

    fast = stress_artifact.get("fast") or {}
    deep = stress_artifact.get("deep")

    fast_scenarios = _extract_scenario_map(fast)
    deep_scenarios = _extract_scenario_map(deep) if deep else {}

    # Union of all scenario names
    all_names = sorted(set(list(fast_scenarios.keys()) + list(deep_scenarios.keys())))

    rows: List[Dict[str, Any]] = []
    for name in all_names:
        fr = fast_scenarios.get(name, {})
        dr = deep_scenarios.get(name, {})

        fast_pnl = safe_float(fr.get("pnl_usd") or fr.get("pnl_total_usd"), None)
        deep_pnl = safe_float(dr.get("pnl_usd") or dr.get("pnl_total_usd"), None)
        fast_dd = safe_float(fr.get("projected_dd") or fr.get("projected_dd_worst"), None)
        deep_dd = safe_float(dr.get("projected_dd") or dr.get("projected_dd_worst"), None)

        abs_pnl_diff = None
        pct_pnl_diff = None
        if fast_pnl is not None and deep_pnl is not None:
            abs_pnl_diff = round(fast_pnl - deep_pnl, 2)
            if abs(deep_pnl) > 1.0:
                pct_pnl_diff = round((fast_pnl - deep_pnl) / abs(deep_pnl) * 100, 1)

        # Which source is being used for this scenario
        truth_used = "deep" if deep_dd is not None else ("fast" if fast_dd is not None else "none")

        rows.append({
            "scenario": name,
            "fast_pnl": fast_pnl,
            "deep_pnl": deep_pnl,
            "fast_dd": fast_dd,
            "deep_dd": deep_dd,
            "pnl_diff": abs_pnl_diff,
            "pnl_diff_pct": pct_pnl_diff,
            "truth_used": truth_used,
        })

    # Summaries
    fast_worst_dd = min((r["fast_dd"] for r in rows if r["fast_dd"] is not None), default=None)
    deep_worst_dd = min((r["deep_dd"] for r in rows if r["deep_dd"] is not None), default=None)
    worst_dd, truth_source = extract_worst_dd(stress_artifact)

    pnl_diffs = [abs(r["pnl_diff"]) for r in rows if r["pnl_diff"] is not None]
    max_abs_pnl_diff = max(pnl_diffs) if pnl_diffs else None

    return {
        "scenarios": rows,
        "fast_worst_dd": fast_worst_dd,
        "deep_worst_dd": deep_worst_dd,
        "worst_dd_used": worst_dd,
        "truth_source": truth_source,
        "deep_available": deep is not None and _block_is_valid(deep),
        "max_abs_pnl_diff": max_abs_pnl_diff,
        "n_scenarios_compared": sum(1 for r in rows if r["fast_pnl"] is not None and r["deep_pnl"] is not None),
    }


def _extract_scenario_map(block: Optional[Dict[str, Any]]) -> Dict[str, Dict[str, Any]]:
    """Pull the scenario dict out of a fast or deep block."""
    if not isinstance(block, dict):
        return {}
    scenarios = block.get("scenarios") or block.get("by_scenario") or {}
    if isinstance(scenarios, dict):
        return {k: v for k, v in scenarios.items() if isinstance(v, dict)}
    return {}
