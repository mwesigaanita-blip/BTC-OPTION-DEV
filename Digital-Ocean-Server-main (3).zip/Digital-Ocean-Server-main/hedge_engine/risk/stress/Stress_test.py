"""
stress_engine.py
----------------
BTC Options Portfolio Stress Test Framework
Based on the Stress Test Framework specification.

Runnable locally for testing and debugging.
When ready for QuantConnect, the StressEngine class drops in directly.
"""

import math
import logging
from dataclasses import dataclass, field
from typing import List, Tuple, Optional
from scipy.stats import norm # type: ignore

# ─────────────────────────────────────────────
# LOGGING
# ─────────────────────────────────────────────
logging.basicConfig(
    level=logging.DEBUG,
    format="%(asctime)s | %(levelname)-8s | %(message)s",
    datefmt="%H:%M:%S"
)
log = logging.getLogger("StressEngine")


# ─────────────────────────────────────────────
# CONSTANTS
# ─────────────────────────────────────────────

# Regime thresholds (HV30 as decimal, e.g. 0.35 = 35%)
HV_LOW_THRESHOLD    = 0.35
HV_HIGH_THRESHOLD   = 0.55

# Stress override drawdown trigger
OVERRIDE_DRAWDOWN_THRESHOLD = -0.08  # -8%

# Black-Scholes constants (per spec)
BS_RATE   = 0.0    # r = 0
BS_IV_FLOOR = 0.05  # 5% floor

# Skew adjustments for downside scenarios (delta-based, as decimals)
SKEW_TABLE = [
    (0.20, 0.30, 0.04),   # 20–30 delta puts: +4 vol
    (0.10, 0.20, 0.06),   # 10–20 delta puts: +6 vol
    (0.00, 0.10, 0.09),   # <10 delta puts:   +9 vol
]

# All 10 scenarios: (id, spot_shock, iv_shock, is_downside)
ALL_SCENARIOS = [
    ("S1",  -0.05,  0.03, True),
    ("S2",  -0.05,  0.05, True),
    ("S3",  -0.05,  0.10, True),
    ("S4",  -0.10,  0.10, True),
    ("S5",  -0.10,  0.20, True),
    ("S6",  +0.05,  0.03, False),
    ("S7",  +0.05,  0.05, False),
    ("S8",  +0.05,  0.10, False),
    ("S9",  +0.10,  0.10, False),
    ("S10", +0.10,  0.20, False),
]

# Which scenarios are active per regime
REGIME_SCENARIOS = {
    "LOW":    ["S1", "S2", "S6", "S7"],
    "NORMAL": ["S1", "S2", "S3", "S4", "S6", "S7", "S8", "S9"],
    "HIGH":   ["S1", "S2", "S3", "S4", "S5", "S6", "S7", "S8", "S9", "S10"],
}


# ─────────────────────────────────────────────
# DATA STRUCTURES
# ─────────────────────────────────────────────

@dataclass
class OptionPosition:
    """
    Represents one option leg in the portfolio.
    All Greeks are per-contract (not notional-adjusted).
    """
    position_id: str
    option_type: str        # "call" or "put"
    strike: float           # K
    expiry_years: float     # T in years (e.g. 30 days = 30/365)
    iv: float               # current implied volatility as decimal (e.g. 0.80 = 80%)
    delta: float            # current delta (positive for calls, negative for puts)
    gamma: float            # current gamma
    vega: float             # current vega (per 1 point move in IV as decimal)
    quantity: float         # number of contracts (negative = short)
    notional: float         # USD notional per contract


@dataclass
class PerpPosition:
    """
    Represents a perpetual or futures position.
    PnL is purely linear: quantity * spot_change
    """
    position_id: str
    quantity: float         # positive = long, negative = short (in BTC)
    entry_price: float      # USD


@dataclass
class Portfolio:
    options: List[OptionPosition] = field(default_factory=list)
    perps:   List[PerpPosition]   = field(default_factory=list)
    total_value_usd: float = 1.0  # used to compute drawdown %


@dataclass
class ScenarioResult:
    scenario_id: str
    spot_shock: float
    iv_shock: float
    is_downside: bool
    pnl_usd: float
    drawdown_pct: float
    override_triggered: bool


@dataclass
class StressResult:
    regime: str
    hv30: float
    iv30: float
    iv_hv_spread: float
    scenario_results: List[ScenarioResult]
    worst_scenario: ScenarioResult
    override_triggered: bool


# ─────────────────────────────────────────────
# BLACK-SCHOLES PRICER
# ─────────────────────────────────────────────

def bs_price(S: float, K: float, T: float, sigma: float, option_type: str) -> float:
    """
    Black-Scholes price. r=0, IV floor = 5% per spec.
    S: spot price
    K: strike
    T: time to expiry in years
    sigma: implied volatility as decimal
    option_type: 'call' or 'put'
    """
    sigma = max(sigma, BS_IV_FLOOR)

    if T <= 0:
        # Intrinsic value only at expiry
        if option_type == "call":
            return max(S - K, 0.0)
        else:
            return max(K - S, 0.0)

    d1 = (math.log(S / K) + 0.5 * sigma ** 2 * T) / (sigma * math.sqrt(T))
    d2 = d1 - sigma * math.sqrt(T)

    if option_type == "call":
        return S * norm.cdf(d1) - K * norm.cdf(d2)
    else:
        return K * norm.cdf(-d2) - S * norm.cdf(-d1)


# ─────────────────────────────────────────────
# REGIME DETECTION
# ─────────────────────────────────────────────

# Spread thresholds
IV_HV_UPGRADE_LOW    = 0.15   # spread >= 15%  => upgrade LOW    -> NORMAL
IV_HV_UPGRADE_NORMAL = 0.20   # spread >= 20%  => upgrade NORMAL -> HIGH
IV_HV_DOWNGRADE_HIGH = -0.15  # spread <= -15% => downgrade HIGH -> NORMAL


def detect_regime(hv30: float, iv30: float) -> str:
    """
    Classify market volatility regime using both HV30 and IV30.
    Step 1: base regime from HV30 (realized vol - backward looking)
    Step 2: adjust using IV-HV spread (forward looking market signal)
    """
    spread = iv30 - hv30

    # Step 1: base regime
    if hv30 < HV_LOW_THRESHOLD:
        regime = "LOW"
    elif hv30 < HV_HIGH_THRESHOLD:
        regime = "NORMAL"
    else:
        regime = "HIGH"

    # Step 2: spread adjustment
    if spread >= IV_HV_UPGRADE_LOW and regime == "LOW":
        regime = "NORMAL"
    elif spread >= IV_HV_UPGRADE_NORMAL and regime == "NORMAL":
        regime = "HIGH"

    if spread <= IV_HV_DOWNGRADE_HIGH and regime == "HIGH":
        regime = "NORMAL"

    log.debug(f"Regime detection | HV30={hv30:.1%} IV30={iv30:.1%} "
              f"Spread={spread:.1%} => {regime}")
    return regime


# ─────────────────────────────────────────────
# SKEW ADJUSTMENT
# ─────────────────────────────────────────────

def apply_skew(option: OptionPosition, base_iv_shock: float, is_downside: bool) -> float:
    """
    For downside scenarios only: steepen the IV shock based on option delta.
    For upside scenarios: parallel shift, no skew.
    Returns adjusted IV shock as decimal.
    """
    if not is_downside or option.option_type == "call":
        return base_iv_shock

    abs_delta = abs(option.delta)
    for (low, high, extra) in SKEW_TABLE:
        if low <= abs_delta < high:
            adjusted = base_iv_shock + extra
            log.debug(f"  Skew applied to {option.position_id} | "
                      f"delta={abs_delta:.2f} | +{extra:.0%} => IV shock={adjusted:.0%}")
            return adjusted

    # delta >= 0.30 (ATM-ish puts): no extra skew beyond base
    return base_iv_shock


# ─────────────────────────────────────────────
# FAST STRESS  (Greeks approximation)
# ─────────────────────────────────────────────

def fast_stress_option(option: OptionPosition,
                       spot: float,
                       dS: float,
                       dIV: float) -> float:
    """
    Greeks-based PnL approximation per option position.
    PnL ≈ Δ*dS + 0.5*Γ*dS² + Vega*dIV
    dS : absolute spot move in USD
    dIV: absolute IV move as decimal (e.g. 0.03 = +3 vol points)
    Returns PnL in USD for this position.
    """
    pnl_per_contract = (
        option.delta * dS
        + 0.5 * option.gamma * dS ** 2
        + option.vega * dIV
    )
    total_pnl = pnl_per_contract * option.quantity * option.notional
    log.debug(f"  FastStress {option.position_id} | dS={dS:+.1f} dIV={dIV:+.1%} "
              f"| pnl/contract={pnl_per_contract:.4f} | total={total_pnl:.2f} USD")
    return total_pnl


def fast_stress_perp(perp: PerpPosition, dS: float) -> float:
    """
    Linear PnL for perpetuals/futures.
    dS: absolute spot move in USD
    """
    pnl = perp.quantity * dS
    log.debug(f"  FastStress perp {perp.position_id} | dS={dS:+.1f} "
              f"qty={perp.quantity} | pnl={pnl:.2f} USD")
    return pnl


# ─────────────────────────────────────────────
# DEEP STRESS  (Full BS repricing)
# ─────────────────────────────────────────────

def deep_stress_option(option: OptionPosition,
                       spot: float,
                       dS_pct: float,
                       dIV: float,
                       is_downside: bool) -> float:
    """
    Full Black-Scholes reprice under stressed spot and IV.
    dS_pct: spot shock as decimal (e.g. -0.05)
    dIV   : base IV shock as decimal (skew applied internally)
    Returns PnL in USD for this position.
    """
    stressed_spot = spot * (1 + dS_pct)
    adjusted_dIV  = apply_skew(option, dIV, is_downside)
    stressed_iv   = max(option.iv + adjusted_dIV, BS_IV_FLOOR)

    price_now      = bs_price(spot,         option.strike, option.expiry_years,
                              option.iv,     option.option_type)
    price_stressed = bs_price(stressed_spot, option.strike, option.expiry_years,
                              stressed_iv,   option.option_type)

    pnl_per_contract = price_stressed - price_now
    total_pnl = pnl_per_contract * option.quantity * option.notional

    log.debug(f"  DeepStress {option.position_id} | "
              f"spot {spot:.0f}->{stressed_spot:.0f} | "
              f"IV {option.iv:.1%}->{stressed_iv:.1%} | "
              f"price {price_now:.4f}->{price_stressed:.4f} | "
              f"pnl={total_pnl:.2f} USD")
    return total_pnl


def deep_stress_perp(perp: PerpPosition, spot: float, dS_pct: float) -> float:
    """
    Linear PnL for perps under deep stress.
    """
    dS = spot * dS_pct
    return fast_stress_perp(perp, dS)


# ─────────────────────────────────────────────
# CORE STRESS ENGINE
# ─────────────────────────────────────────────

class StressEngine:
    """
    Main engine. Holds portfolio state and runs stress evaluation.
    """

    def __init__(self, portfolio: Portfolio):
        self.portfolio = portfolio

    # ── Regime-filtered scenario list ──────────
    def get_active_scenarios(self, regime: str) -> List[Tuple]:
        active_ids = REGIME_SCENARIOS[regime]
        return [s for s in ALL_SCENARIOS if s[0] in active_ids]

    # ── Single scenario PnL ────────────────────
    def run_scenario(self,
                     scenario: Tuple,
                     spot: float,
                     use_deep: bool = True) -> float:
        sid, dS_pct, dIV, is_downside = scenario
        dS_abs = spot * dS_pct
        total_pnl = 0.0

        for opt in self.portfolio.options:
            if use_deep:
                total_pnl += deep_stress_option(opt, spot, dS_pct, dIV, is_downside)
            else:
                adj_dIV = apply_skew(opt, dIV, is_downside)
                total_pnl += fast_stress_option(opt, spot, dS_abs, adj_dIV)

        for perp in self.portfolio.perps:
            if use_deep:
                total_pnl += deep_stress_perp(perp, spot, dS_pct)
            else:
                total_pnl += fast_stress_perp(perp, dS_abs)

        return total_pnl

    # ── Override check ─────────────────────────
    def check_override(self, pnl_usd: float) -> bool:
        drawdown = pnl_usd / self.portfolio.total_value_usd
        triggered = drawdown <= OVERRIDE_DRAWDOWN_THRESHOLD
        if triggered:
            log.warning(f"  OVERRIDE TRIGGERED | drawdown={drawdown:.2%} "
                        f"<= threshold={OVERRIDE_DRAWDOWN_THRESHOLD:.0%}")
        return triggered

    # ── Fast stress (every tick) ───────────────
    def run_fast_stress(self, spot: float, hv30: float, iv30: float) -> StressResult:
        log.info("=== FAST STRESS RUN ===")
        return self._run(spot, hv30, iv30, use_deep=False)

    # ── Deep stress (triggered) ────────────────
    def run_deep_stress(self, spot: float, hv30: float, iv30: float) -> StressResult:
        log.info("=== DEEP STRESS RUN ===")
        return self._run(spot, hv30, iv30, use_deep=True)

    # ── Shared runner ──────────────────────────
    def _run(self, spot: float, hv30: float, iv30: float,
             use_deep: bool) -> StressResult:

        regime          = detect_regime(hv30, iv30)
        iv_hv_spread    = iv30 - hv30
        active_scenarios = self.get_active_scenarios(regime)
        results: List[ScenarioResult] = []

        log.info(f"Spot={spot:.0f} | HV30={hv30:.1%} | IV30={iv30:.1%} | "
                 f"Regime={regime} | Active scenarios: "
                 f"{[s[0] for s in active_scenarios]}")

        for scenario in active_scenarios:
            sid, dS_pct, dIV, is_downside = scenario
            log.debug(f"Running {sid} | spot {dS_pct:+.0%} | IV {dIV:+.0%} | "
                      f"downside={is_downside}")

            pnl = self.run_scenario(scenario, spot, use_deep=use_deep)
            drawdown_pct = pnl / self.portfolio.total_value_usd
            override = self.check_override(pnl)

            result = ScenarioResult(
                scenario_id=sid,
                spot_shock=dS_pct,
                iv_shock=dIV,
                is_downside=is_downside,
                pnl_usd=pnl,
                drawdown_pct=drawdown_pct,
                override_triggered=override,
            )
            results.append(result)
            log.info(f"  {sid} => PnL={pnl:+.2f} USD | "
                     f"Drawdown={drawdown_pct:.2%} | Override={override}")

        worst = min(results, key=lambda r: r.pnl_usd)
        any_override = any(r.override_triggered for r in results)

        log.info(f"Worst scenario: {worst.scenario_id} | "
                 f"PnL={worst.pnl_usd:+.2f} | Override={any_override}")

        return StressResult(
            regime=regime,
            hv30=hv30,
            iv30=iv30,
            iv_hv_spread=iv_hv_spread,
            scenario_results=results,
            worst_scenario=worst,
            override_triggered=any_override,
        )


# ─────────────────────────────────────────────
# RESULT PRINTER
# ─────────────────────────────────────────────

def print_result(result: StressResult):
    print("\n" + "=" * 60)
    print(f"STRESS TEST RESULT")
    print(f"  Regime     : {result.regime}")
    print(f"  HV30       : {result.hv30:.1%}")
    print(f"  IV30       : {result.iv30:.1%}")
    print(f"  IV-HV Spread: {result.iv_hv_spread:.1%}")
    print(f"  Override   : {'YES *** RISK ESCALATION ***' if result.override_triggered else 'No'}")
    print("-" * 60)
    print(f"{'Scenario':<10} {'Spot Shock':>12} {'IV Shock':>10} "
          f"{'PnL (USD)':>14} {'Drawdown':>10} {'Override':>10}")
    print("-" * 60)
    for r in result.scenario_results:
        print(f"{r.scenario_id:<10} {r.spot_shock:>+11.0%} {r.iv_shock:>+9.0%} "
              f"{r.pnl_usd:>+14.2f} {r.drawdown_pct:>+9.2%} "
              f"{'YES' if r.override_triggered else 'No':>10}")
    print("-" * 60)
    w = result.worst_scenario
    print(f"WORST: {w.scenario_id} | PnL={w.pnl_usd:+.2f} USD | "
          f"Drawdown={w.drawdown_pct:.2%}")
    print("=" * 60 + "\n")


# ─────────────────────────────────────────────
# TESTS
# ─────────────────────────────────────────────

if __name__ == "__main__":

    print("\n" + "#" * 60)
    print("# STRESS ENGINE - LOCAL TEST SUITE")
    print("#" * 60)

    # ── Sample portfolio ───────────────────────
    # One short call, one long put, one short perp
    portfolio = Portfolio(
        total_value_usd=100_000,   # $100k portfolio for drawdown %
        options=[
            OptionPosition(
                position_id="OPT-001",
                option_type="call",
                strike=70_000,
                expiry_years=30 / 365,
                iv=0.80,            # 80% IV
                delta=0.45,
                gamma=0.000012,
                vega=18.5,          # per 1 vol point move (as decimal)
                quantity=-5,        # short 5 contracts
                notional=1.0,       # 1 BTC per contract
            ),
            OptionPosition(
                position_id="OPT-002",
                option_type="put",
                strike=60_000,
                expiry_years=30 / 365,
                iv=0.90,            # 90% IV (skew)
                delta=-0.25,        # 25-delta put
                gamma=0.000009,
                vega=14.2,
                quantity=10,        # long 10 contracts
                notional=1.0,
            ),
        ],
        perps=[
            PerpPosition(
                position_id="PERP-001",
                quantity=-2.0,      # short 2 BTC
                entry_price=65_000,
            ),
        ]
    )

    engine = StressEngine(portfolio)
    spot   = 65_000  # current BTC price

    # ── TEST 1: LOW volatility regime ──────────
    print("\n>>> TEST 1: LOW Volatility Regime (HV30=28%, IV30=35%)")
    result = engine.run_deep_stress(spot=spot, hv30=0.28, iv30=0.35)
    print_result(result)
    assert result.regime == "LOW", "Expected LOW regime"
    assert len(result.scenario_results) == 4, "LOW regime should run 4 scenarios"
    print("TEST 1 PASSED\n")

    # ── TEST 2: NORMAL volatility regime ───────
    print(">>> TEST 2: NORMAL Volatility Regime (HV30=45%, IV30=55%)")
    result = engine.run_deep_stress(spot=spot, hv30=0.45, iv30=0.55)
    print_result(result)
    assert result.regime == "NORMAL", "Expected NORMAL regime"
    assert len(result.scenario_results) == 8, "NORMAL regime should run 8 scenarios"
    print("TEST 2 PASSED\n")

    # ── TEST 3: HIGH volatility regime ─────────
    print(">>> TEST 3: HIGH Volatility Regime (HV30=65%, IV30=80%)")
    result = engine.run_deep_stress(spot=spot, hv30=0.65, iv30=0.80)
    print_result(result)
    assert result.regime == "HIGH", "Expected HIGH regime"
    assert len(result.scenario_results) == 10, "HIGH regime should run all 10 scenarios"
    print("TEST 3 PASSED\n")

    # ── TEST 4: Fast stress vs Deep stress ─────
    print(">>> TEST 4: Fast Stress vs Deep Stress (NORMAL regime)")
    fast   = engine.run_fast_stress(spot=spot, hv30=0.45, iv30=0.55)
    deep   = engine.run_deep_stress(spot=spot, hv30=0.45, iv30=0.55)
    print(f"  Fast worst PnL : {fast.worst_scenario.pnl_usd:+.2f} USD")
    print(f"  Deep worst PnL : {deep.worst_scenario.pnl_usd:+.2f} USD")
    print("  (Values will differ - fast uses Greeks approx, deep uses full BS reprice)")
    print("TEST 4 PASSED\n")

    # ── TEST 5: Override trigger ────────────────
    # Force a large short position to blow past -8% drawdown
    print(">>> TEST 5: Override Trigger Test")
    big_portfolio = Portfolio(
        total_value_usd=100_000,
        options=[],
        perps=[
            PerpPosition(
                position_id="PERP-BIG",
                quantity=-20.0,     # large short: will lose big on upside
                entry_price=65_000,
            )
        ]
    )
    big_engine = StressEngine(big_portfolio)
    result = big_engine.run_deep_stress(spot=spot, hv30=0.65, iv30=0.80)
    print_result(result)
    assert result.override_triggered, "Override should be triggered with large short in HIGH regime"
    print("TEST 5 PASSED\n")

    # ── TEST 6: Skew application ────────────────
    print(">>> TEST 6: Skew Adjustment on Deep OTM Put (delta=0.08)")
    otm_put = OptionPosition(
        position_id="OTM-PUT",
        option_type="put",
        strike=50_000,
        expiry_years=30 / 365,
        iv=1.20,
        delta=-0.08,        # deep OTM - should get +9 vol skew
        gamma=0.000003,
        vega=8.0,
        quantity=5,
        notional=1.0,
    )
    adjusted = apply_skew(otm_put, base_iv_shock=0.10, is_downside=True)
    print(f"  Base IV shock: 10% | After skew: {adjusted:.0%}")
    assert adjusted == 0.19, f"Expected 19% (10+9), got {adjusted:.0%}"
    print("TEST 6 PASSED\n")

    # ── TEST 7: Spread upgrades LOW -> NORMAL ──
    print(">>> TEST 7: Spread upgrade LOW -> NORMAL (HV30=28%, IV30=48%)")
    result = engine.run_deep_stress(spot=spot, hv30=0.28, iv30=0.48)
    print_result(result)
    assert result.regime == "NORMAL", "Spread >= 15% should upgrade LOW to NORMAL"
    assert len(result.scenario_results) == 8, "NORMAL regime should run 8 scenarios"
    print("TEST 7 PASSED\n")

    # ── TEST 8: Spread downgrades HIGH -> NORMAL ──
    print(">>> TEST 8: Spread downgrade HIGH -> NORMAL (HV30=60%, IV30=40%)")
    result = engine.run_deep_stress(spot=spot, hv30=0.60, iv30=0.40)
    print_result(result)
    assert result.regime == "NORMAL", "Spread <= -15% should downgrade HIGH to NORMAL"
    assert len(result.scenario_results) == 8, "NORMAL regime should run 8 scenarios"
    print("TEST 8 PASSED\n")

    print("#" * 60)
    print("# ALL TESTS PASSED")
    print("#" * 60 + "\n")