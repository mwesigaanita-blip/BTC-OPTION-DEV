# hedge_engine/core/snapshot_builder.py
from __future__ import annotations

import json
import logging
import os
import sqlite3
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple

from hedge_engine.data.deribit_client import DeribitClient, _classify_instrument_kind
from hedge_engine.data.state_store import ensure_state_tables, load_hwm_usd, update_hwm_usd


# ----------------------------
# Engine-owned table names (NEW)
# ----------------------------
T_ACCT = "hedge_engine_account_ticks"
T_POS  = "hedge_engine_positions_ticks"
T_VOL  = "hedge_engine_vol_ticks"  
T_MARKETS = "hedge_engine_markets_ticks"      # futures/perps + option chain meta
T_INSTR   = "hedge_engine_instruments_ticks"  # raw instruments lists
T_BOOKSUM = "hedge_engine_book_summaries_ticks"

from datetime import timedelta

def _pick_hv_value_at_or_before(hv_series: list[list[float]], target_ts_ms: int) -> float:
    """
    hv_series: [[ts_ms, hv], ...] sorted ascending.
    returns hv at/before target_ts_ms (closest).
    """
    if not hv_series:
        return 0.0
    best = None
    for ts_ms, hv in hv_series:
        if int(ts_ms) <= int(target_ts_ms):
            best = float(hv)
        else:
            break
    return float(best) if best is not None else float(hv_series[0][1])


def _compute_hv_change_7d_pp(hv_series: list[list[float]], hv_now: float) -> float:
    if not hv_series:
        return 0.0
    now_ms = int(_now_utc().timestamp() * 1000)
    ts_7d = now_ms - int(7 * 24 * 3600 * 1000)
    hv_7d = _pick_hv_value_at_or_before(hv_series, ts_7d)
    return float(hv_now - hv_7d)
# ----------------------------
# Data models
# ----------------------------
@dataclass(frozen=True)
class EngineInputs:
    # Single USD equity base (cross portfolio)
    total_equity_usd: float

    # Persistent risk state
    hwm_usd: float
    dd: float  # <= 0

    # Margin (cross portfolio)
    mm_pct: float

    # Market
    spot_index_usd: float

    # Speed metrics (Phase 1 placeholder)
    spot_move_24h_pct: float
    spot_move_30m_pct: float
    spot_move_intraday_pct: float

    # Vol (optional if available)
    hv_30d_pct: float
    hv_30d_change_7d_pct: float
    iv_atm_30d_pct: float
    iv_minus_hv_30d_pp: float

    # Portfolio greeks
    portfolio_delta_btc: float
    portfolio_gamma: float
    portfolio_vega: float

    updated_at_utc: datetime


@dataclass(frozen=True)
class SnapshotBuildResult:
    inputs: EngineInputs
    debug: Dict[str, Any]


# ----------------------------
# Helpers
# ----------------------------
def _now_utc() -> datetime:
    return datetime.now(timezone.utc)


def _safe_float(x: Any, default: float = 0.0) -> float:
    try:
        if x is None:
            return default
        return float(x)
    except Exception:
        return default


def compute_drawdown(*, equity_usd: float, hwm_usd: float) -> float:
    if hwm_usd <= 0:
        return 0.0
    dd = (equity_usd / hwm_usd) - 1.0
    return min(0.0, dd)


def _sum_greeks_from_positions(positions: List[Dict[str, Any]]) -> Tuple[float, float, float]:
    d = 0.0
    g = 0.0
    v = 0.0
    for p in positions or []:
        # net_delta is now always present after enrichment
        # fall back to delta only for legacy rows without enrichment
        delta_val = p.get("net_delta")
        if delta_val is None:
            delta_val = p.get("delta")
        d += _safe_float(delta_val)
        g += _safe_float(p.get("gamma"))
        v += _safe_float(p.get("vega"))
    return d, g, v


def _derive_mm_pct_from_account(acct: Dict[str, Any]) -> float:
    mb_usd = _safe_float(acct.get("total_margin_balance_usd"))
    mm_usd = _safe_float(acct.get("total_maintenance_margin_usd"))
    if mb_usd > 0:
        return (mm_usd / mb_usd) * 100.0

    mm_pct_of_mb = acct.get("mm_pct_of_mb")
    if mm_pct_of_mb is not None:
        return _safe_float(mm_pct_of_mb)

    return 0.0


def _derive_total_equity_usd_cross(acct: Dict[str, Any]) -> float:
    """
    Cross-portfolio requirement:
    total_equity_usd should include BTC + USDT + USDC (whole account).
    We REQUIRE it (clear & deterministic).
    """
    v = _safe_float(acct.get("total_equity_usd"))
    if v > 0:
        return v
    raise RuntimeError(
        f"Deribit account summary missing total_equity_usd (cross-portfolio). "
        f"keys={sorted(list(acct.keys()))}"
    )


# ----------------------------
# NEW: engine-owned tables
# ----------------------------
def ensure_engine_tables(con: sqlite3.Connection) -> None:
    con.execute(
        f"""
        CREATE TABLE IF NOT EXISTS {T_ACCT} (
            ts_utc TEXT PRIMARY KEY,
            payload_json TEXT NOT NULL
        )
        """
    )
    con.execute(
        f"""
        CREATE TABLE IF NOT EXISTS {T_POS} (
            ts_utc TEXT PRIMARY KEY,
            payload_json TEXT NOT NULL
        )
        """
    )
    con.execute(
        f"""
        CREATE TABLE IF NOT EXISTS {T_VOL} (
            ts_utc TEXT PRIMARY KEY,
            payload_json TEXT NOT NULL
        )
        """
    )
    con.execute(f"CREATE INDEX IF NOT EXISTS idx_{T_ACCT}_ts ON {T_ACCT}(ts_utc)")
    con.execute(f"CREATE INDEX IF NOT EXISTS idx_{T_POS}_ts ON {T_POS}(ts_utc)")
    con.execute(f"CREATE INDEX IF NOT EXISTS idx_{T_VOL}_ts ON {T_VOL}(ts_utc)")
    con.execute(
        f"""
        CREATE TABLE IF NOT EXISTS {T_MARKETS} (
            ts_utc TEXT PRIMARY KEY,
            payload_json TEXT NOT NULL
        )
        """
    )
    con.execute(
        f"""
        CREATE TABLE IF NOT EXISTS {T_INSTR} (
            ts_utc TEXT PRIMARY KEY,
            payload_json TEXT NOT NULL
        )
        """
    )
    con.execute(
        f"""
        CREATE TABLE IF NOT EXISTS {T_BOOKSUM} (
            ts_utc TEXT PRIMARY KEY,
            payload_json TEXT NOT NULL
        )
        """
    )
    con.execute(f"CREATE INDEX IF NOT EXISTS idx_{T_MARKETS}_ts ON {T_MARKETS}(ts_utc)")
    con.execute(f"CREATE INDEX IF NOT EXISTS idx_{T_INSTR}_ts ON {T_INSTR}(ts_utc)")
    con.execute(f"CREATE INDEX IF NOT EXISTS idx_{T_BOOKSUM}_ts ON {T_BOOKSUM}(ts_utc)")
    con.commit()


def _insert_tick(con: sqlite3.Connection, table: str, *, ts_utc: str, payload: Any) -> None:
    con.execute(
        f"INSERT OR REPLACE INTO {table}(ts_utc, payload_json) VALUES (?, ?)",
        (ts_utc, json.dumps(payload, ensure_ascii=False)),
    )
    con.commit()


def _latest_tick(con: sqlite3.Connection, table: str) -> Optional[dict]:
    row = con.execute(
        f"SELECT ts_utc, payload_json FROM {table} ORDER BY ts_utc DESC LIMIT 1"
    ).fetchone()
    if not row:
        return None
    ts_utc, payload_s = row
    payload = json.loads(payload_s)
    if isinstance(payload, dict):
        payload["_tick_ts_utc"] = ts_utc
    return payload


def _latest_tick_list(con: sqlite3.Connection, table: str) -> Optional[list]:
    row = con.execute(
        f"SELECT ts_utc, payload_json FROM {table} ORDER BY ts_utc DESC LIMIT 1"
    ).fetchone()
    if not row:
        return None
    _, payload_s = row
    payload = json.loads(payload_s)
    if isinstance(payload, list):
        return payload
    return None

def _enrich_positions_with_net_delta(
    positions: List[Dict[str, Any]],
    spot: float,
) -> List[Dict[str, Any]]:
    """
    Normalize positions so every row has:
      - kind
      - net_delta

    Rules:
      1) If Deribit already returned net_delta, trust it.
      2) Else if delta exists:
         - options: use delta directly if it already looks size-adjusted,
                    otherwise fallback to delta * size
         - futures/perps: prefer delta directly, else fallback to size / spot
      3) Else fallback to 0.0
    """
    enriched: List[Dict[str, Any]] = []

    for p in positions or []:
        row = dict(p)

        name = str(row.get("instrument_name", "") or "")
        kind = _classify_instrument_kind(name)

        size = _safe_float(row.get("size", 0.0))
        delta = _safe_float(row.get("delta", 0.0))

        net_delta_raw = row.get("net_delta")

        if net_delta_raw is not None:
            net_delta = _safe_float(net_delta_raw)

        elif kind == "option":
            # If Deribit delta already looks size-adjusted, keep it.
            # Otherwise derive from signed size.
            if abs(size) > 0 and abs(delta) > 1.0:
                net_delta = delta
            else:
                net_delta = delta * size

        elif kind in ("future", "perpetual"):
            # Prefer returned delta when available; otherwise derive BTC exposure.
            if row.get("delta") is not None:
                net_delta = delta
            else:
                net_delta = (size / spot) if spot > 0 else 0.0

        else:
            net_delta = delta if row.get("delta") is not None else 0.0

        row["net_delta"] = net_delta
        row["kind"] = kind
        enriched.append(row)

    return enriched
# ----------------------------
# Fetch + persist ticks (Deribit) - NEW PATH
# ----------------------------
def fetch_and_persist_ticks_from_deribit(
    *,
    deribit: DeribitClient,
    con: sqlite3.Connection,
    currency: str = "BTC",
) -> Dict[str, Any]:
    ensure_engine_tables(con)

    now = _now_utc()
    ts_utc = now.strftime("%Y-%m-%dT%H:%M:%SZ")

    # -------------------------
    # ACCOUNT (cross-portfolio)
    # -------------------------
    acct = dict(deribit.get_account_summary(currency=currency, extended=True) or {})
    for k in ("total_equity_usd", "total_margin_balance_usd", "total_maintenance_margin_usd"):
        if k in acct:
            acct[k] = _safe_float(acct.get(k))

    spot = deribit.get_index_price("btc_usd")
    acct["spot_index_usd"] = _safe_float(spot)

    # -------------------------
    # POSITIONS (all: options + futures/perps)
    # -------------------------
    positions_raw = deribit.get_positions(currency=currency) or []
    positions = _enrich_positions_with_net_delta(positions_raw, spot=_safe_float(spot))

    # -------------------------
    # VOL (HV + IV)
    # -------------------------
    hv_series = deribit.get_historical_volatility(currency=currency) or []
    hv_now = float(hv_series[-1][1]) if hv_series else 0.0
    hv_change_7d_pp = _compute_hv_change_7d_pp(hv_series, hv_now)

    iv_30 = float(deribit.get_latest_iv_30d_pct(currency=currency) or 0.0)
    iv_minus_hv_pp = float(iv_30 - hv_now)

    vol_payload = {
        "spot_index_usd": _safe_float(spot),
        "hv_30d_pct": float(hv_now),
        "hv_30d_change_7d_pct": float(hv_change_7d_pp),
        "iv_atm_30d_pct": float(iv_30),
        "iv_minus_hv_30d_pp": float(iv_minus_hv_pp),
        "source": {"hv": "public/get_historical_volatility", "iv": "public/get_volatility_index_data"},
    }

    # -------------------------
    # MARKETS: instruments + chain + summaries
    # -------------------------
    # NOTE: these require DeribitClient to already have these public calls:
    # - get_instruments(currency, kind="option"/"future", expired=False)
    # - get_book_summary_by_currency(currency, kind="option"/"future")
    # If your DeribitClient uses other names, we’ll map them.

    opt_instr = deribit.get_instruments(currency=currency, kind="option", expired=False) or []
    fut_instr = deribit.get_instruments(currency=currency, kind="future", expired=False) or []

    # book summaries give mark/index/volume/open_interest etc per instrument
    opt_summ = deribit.get_book_summary_by_currency(currency=currency, kind="option") or []
    fut_summ = deribit.get_book_summary_by_currency(currency=currency, kind="future") or []

    # quick chain meta (expiries, strikes)
    expiries = sorted({i.get("expiration_timestamp") for i in opt_instr if i.get("expiration_timestamp") is not None})
    strikes = sorted({i.get("strike") for i in opt_instr if i.get("strike") is not None})

    markets_payload = {
        "spot_index_usd": _safe_float(spot),
        "currency": currency,
        "options": {
            "count": len(opt_instr),
            "expiries_count": len(expiries),
            "strikes_count": len(strikes),
            "expiries": expiries[:60],  # cap for JSON size
            "strikes": strikes[:200],
        },
        "futures": {"count": len(fut_instr)},
        "ts_utc": ts_utc,
    }

    instruments_payload = {
        "currency": currency,
        "options_instruments": opt_instr,
        "futures_instruments": fut_instr,
        "ts_utc": ts_utc,
    }

    book_summaries_payload = {
        "currency": currency,
        "options_summaries": opt_summ,
        "futures_summaries": fut_summ,
        "ts_utc": ts_utc,
    }

    # -------------------------
    # Persist DB ticks (engine-owned)
    # -------------------------
    _insert_tick(con, T_ACCT, ts_utc=ts_utc, payload=acct)
    _insert_tick(con, T_POS, ts_utc=ts_utc, payload=positions)
    _insert_tick(con, T_VOL, ts_utc=ts_utc, payload=vol_payload)
    _insert_tick(con, T_MARKETS, ts_utc=ts_utc, payload=markets_payload)
    _insert_tick(con, T_INSTR, ts_utc=ts_utc, payload=instruments_payload)
    _insert_tick(con, T_BOOKSUM, ts_utc=ts_utc, payload=book_summaries_payload)

    # -------------------------
    # One JSON debug snapshot (everything)
    # -------------------------
    try:
        os.makedirs("logs", exist_ok=True)
        debug_path = f"logs/engine_full_snapshot_{ts_utc.replace(':','').replace('-','')}.json"
        full = {
            "ts_utc": ts_utc,
            "account": acct,
            "positions": positions,
            "vol": vol_payload,
            "markets": markets_payload,
            "instruments": instruments_payload,
            "book_summaries": book_summaries_payload,
        }
        with open(debug_path, "w", encoding="utf-8") as f:
            json.dump(full, f, indent=2, ensure_ascii=False, default=str)
    except Exception:
        debug_path = None

    return {
        "ts_utc": ts_utc,
        "positions_len": len(positions),
        "hv_30d_pct": hv_now,
        "iv_30d_pct": iv_30,
        "options_instr": len(opt_instr),
        "futures_instr": len(fut_instr),
        "debug_json": debug_path,
    }
# ----------------------------
# Build EngineInputs (from engine tables + persistent state)
# ----------------------------


def build_engine_inputs_from_engine_db(*, con: sqlite3.Connection, logger: logging.Logger) -> SnapshotBuildResult:
    ensure_state_tables(con)
    ensure_engine_tables(con)

    account = _latest_tick(con, T_ACCT) or {}
    positions = _latest_tick_list(con, T_POS) or []
    vol = _latest_tick(con, T_VOL) or {}

    spot_index_usd = _safe_float(account.get("spot_index_usd")) or _safe_float(vol.get("spot_index_usd"))
    equity_usd = _derive_total_equity_usd_cross(account)

    hwm_before = load_hwm_usd(con=con) or 0.0
    hwm_update = update_hwm_usd(con=con, total_equity_usd=equity_usd, logger=logger)
    hwm_after = float(hwm_update.hwm_after)

    dd = compute_drawdown(equity_usd=equity_usd, hwm_usd=hwm_after)

    mm_pct = _derive_mm_pct_from_account(account)
    positions_delta_btc, gamma, vega = _sum_greeks_from_positions(positions)

    # Main hedge delta: prefer account net delta (explicitly requested)
    if account.get("net_delta_btc") is not None:
        delta_btc = _safe_float(account.get("net_delta_btc"))
        delta_source = "account_net_delta_btc"
    elif account.get("net_delta") is not None:
        delta_btc = _safe_float(account.get("net_delta"))
        delta_source = "account_net_delta"
    elif account.get("delta_total") is not None:
        delta_btc = _safe_float(account.get("delta_total"))
        delta_source = "account_delta_total"
    elif positions:
        delta_btc = positions_delta_btc
        delta_source = "positions_net_delta"
    else:
        opt_d = _safe_float(account.get("options_delta"))
        fut_d = _safe_float(account.get("futures_delta"))
        delta_btc = opt_d + fut_d
        delta_source = "account_options_plus_futures"

    # vol fields (optional)
    hv_30d_pct = _safe_float(vol.get("hv_30d_pct"))
    hv_30d_change_7d_pct = _safe_float(vol.get("hv_30d_change_7d_pct"))
    iv_atm_30d_pct = _safe_float(vol.get("iv_atm_30d_pct"))
    iv_minus_hv_30d_pp = _safe_float(vol.get("iv_minus_hv_30d_pp"))

    ts = _now_utc()

    inputs = EngineInputs(
        total_equity_usd=equity_usd,
        hwm_usd=hwm_after,
        dd=dd,
        mm_pct=mm_pct,
        spot_index_usd=spot_index_usd,

        spot_move_24h_pct=0.0,
        spot_move_30m_pct=0.0,
        spot_move_intraday_pct=0.0,

        hv_30d_pct=hv_30d_pct,
        hv_30d_change_7d_pct=hv_30d_change_7d_pct,
        iv_atm_30d_pct=iv_atm_30d_pct,
        iv_minus_hv_30d_pp=iv_minus_hv_30d_pp,

        portfolio_delta_btc=delta_btc,
        portfolio_gamma=gamma,
        portfolio_vega=vega,
        updated_at_utc=ts,
    )

    debug = {
        "event": "ENGINE_SNAPSHOT_BUILD",
        "ticks": {
            "acct_ts_utc": account.get("_tick_ts_utc"),
        },
        "equity_usd": equity_usd,
        "hwm_before": hwm_before,
        "hwm_after": hwm_after,
        "dd": dd,
        "mm_pct": mm_pct,
        "spot_index_usd": spot_index_usd,
        "greeks": {
            "account_delta_btc": delta_btc,
            "positions_delta_btc": positions_delta_btc,
            "delta_source": delta_source,
            "gamma": gamma,
            "vega": vega,
        },
        "vol": {
            "hv_30d_pct": hv_30d_pct,
            "hv_30d_change_7d_pct": hv_30d_change_7d_pct,
            "iv_atm_30d_pct": iv_atm_30d_pct,
            "iv_minus_hv_30d_pp": iv_minus_hv_30d_pp,
        },
        "ts_utc": ts.isoformat(),
    }

    try:
        os.makedirs("logs", exist_ok=True)
        with open(f"logs/engine_snapshot_build_{int(ts.timestamp())}.json", "w", encoding="utf-8") as f:
            json.dump({"inputs": asdict(inputs), "debug": debug}, f, indent=2, ensure_ascii=False, default=str)
    except Exception:
        pass

    logger.info(json.dumps(debug, ensure_ascii=False, default=str))
    return SnapshotBuildResult(inputs=inputs, debug=debug)


if __name__ == "__main__":
    from shared.db_paths import HEDGE_ENGINE_DB
    print(f"[DB] Using {HEDGE_ENGINE_DB} in {__file__}", flush=True)
    # quick test
    con = sqlite3.connect(str(HEDGE_ENGINE_DB))
    ensure_engine_tables(con)

    c = DeribitClient.from_env()
    fetch_and_persist_ticks_from_deribit(deribit=c, con=con)

    logger = logging.getLogger("test_snapshot_build")
    logger.setLevel(logging.INFO)
    build_engine_inputs_from_engine_db(con=con, logger=logger)


# python -m hedge_engine.cli.snapshot_cli --db data/hedge_engine.sqlite
