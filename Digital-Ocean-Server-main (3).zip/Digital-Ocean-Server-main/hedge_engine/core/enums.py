# hedge_engine/core/enums.py

from enum import Enum


class ActionType(str, Enum):
    HEDGE_DELTA = "HEDGE_DELTA"
    HEDGE_GAMMA = "HEDGE_GAMMA"
    HEDGE_VEGA  = "HEDGE_VEGA"
    HEDGE_TAIL  = "HEDGE_TAIL"
    REDUCE_POS  = "REDUCE_POS"
    ROLL_SHORT  = "ROLL_SHORT"


class Side(str, Enum):
    BUY  = "BUY"
    SELL = "SELL"


class RiskMode(str, Enum):
    NORMAL    = "NORMAL"
    DEFENSIVE = "DEFENSIVE"
    DANGER    = "DANGER"
    EMERGENCY = "EMERGENCY"


class ActionClassification(str, Enum):
    PROPER_HEDGE = "proper_hedge"
    PARTIAL_HEDGE = "partial_hedge"
    MM_RELIEF = "mm_relief"
    FALLBACK_LAST_RESORT = "fallback_last_resort"
    NO_ACTION = "no_action"
