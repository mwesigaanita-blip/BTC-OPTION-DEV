# hedge_engine/core/portfolio_state.py
"""
Phase 2-3: Normalized portfolio state models.

CurrentPortfolioState  - Deribit-sourced present truth
PostTradeState         - Deribit-simulated post-hedge state
StressedState          - Local stress engine output per scenario

Design principle:
  Deribit = present-state truth
  Local engine = future stressed-state truth
"""
from __future__ import annotations

from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


def _sf(v: Any, default: float = 0.0) -> float:
    """Safe float conversion."""
    try:
        if v is None:
            return default
        return float(v)
    except Exception:
        return default


# ─────────────────────────────────────────────
# Current state (from Deribit)
# ─────────────────────────────────────────────

@dataclass
class CurrentPortfolioState:
    """
    Normalized current-state snapshot sourced entirely from Deribit endpoints.
    Fields are tagged with their Deribit source for auditability.
    """
    # Account-level (from get_account_summary)
    equity_usd: float = 0.0
    margin_balance_usd: float = 0.0
    maintenance_margin_usd: float = 0.0
    initial_margin_usd: float = 0.0
    available_funds_usd: float = 0.0
    mm_pct: float = 0.0  # (maintenance_margin / margin_balance) * 100

    # Greeks - account-level aggregates (from get_account_summary or simulate_portfolio)
    delta_btc: float = 0.0
    gamma: float = 0.0
    vega: float = 0.0

    # Spot reference (from get_index_price)
    spot_index_usd: float = 0.0

    # HWM / DD (from local state DB, not Deribit)
    hwm_usd: float = 0.0
    dd: float = 0.0  # <= 0

    # Source provenance
    source: Dict[str, str] = field(default_factory=dict)
    ts_utc: datetime = field(default_factory=_utc_now)

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        d["ts_utc"] = self.ts_utc.isoformat() if self.ts_utc else None
        return d


def build_current_state_from_deribit(
    *,
    account_summary: Dict[str, Any],
    positions: List[Dict[str, Any]],
    spot_index_usd: float,
    hwm_usd: float,
) -> CurrentPortfolioState:
    """
    Build CurrentPortfolioState from raw Deribit API responses.

    Priority for equity:
      1. total_equity_usd (cross-portfolio, from extended account summary)
      2. equity field * spot (BTC-denominated accounts)

    Priority for greeks:
      1. Account-level delta_total / options_gamma / options_vega (from summary)
      2. Fallback: sum from positions
    """
    acct = account_summary or {}

    # ── Equity ──
    equity_usd = _sf(acct.get("total_equity_usd"))
    if equity_usd <= 0:
        # Fallback: BTC equity * spot
        equity_btc = _sf(acct.get("equity"))
        if equity_btc > 0 and spot_index_usd > 0:
            equity_usd = equity_btc * spot_index_usd

    # ── Margin ──
    mb_usd = _sf(acct.get("total_margin_balance_usd"))
    mm_usd = _sf(acct.get("total_maintenance_margin_usd"))
    im_usd = _sf(acct.get("total_initial_margin_usd"))
    avail_usd = _sf(acct.get("available_funds"))

    if mb_usd <= 0:
        # BTC-denominated fallback
        mb_btc = _sf(acct.get("margin_balance"))
        mm_btc = _sf(acct.get("maintenance_margin"))
        im_btc = _sf(acct.get("initial_margin"))
        if mb_btc > 0 and spot_index_usd > 0:
            mb_usd = mb_btc * spot_index_usd
            mm_usd = mm_btc * spot_index_usd
            im_usd = im_btc * spot_index_usd

    mm_pct = (mm_usd / mb_usd * 100.0) if mb_usd > 0 else 0.0

    # ── Greeks ──
    # Account-level: try delta_total first
    delta_btc = _sf(acct.get("delta_total"))
    delta_src = "account_delta_total"
    if delta_btc == 0.0:
        # Try options_delta + futures_delta
        od = _sf(acct.get("options_delta"))
        fd = _sf(acct.get("futures_delta"))
        if od != 0.0 or fd != 0.0:
            delta_btc = od + fd
            delta_src = "account_options_plus_futures"
        else:
            # Fallback: sum from positions
            delta_btc = sum(_sf(p.get("net_delta", p.get("delta"))) for p in (positions or []))
            delta_src = "positions_sum"

    gamma = _sf(acct.get("options_gamma"))
    gamma_src = "account_options_gamma"
    if gamma == 0.0:
        gamma = sum(_sf(p.get("gamma")) for p in (positions or []))
        gamma_src = "positions_sum"

    vega = _sf(acct.get("options_vega"))
    vega_src = "account_options_vega"
    if vega == 0.0:
        vega = sum(_sf(p.get("vega")) for p in (positions or []))
        vega_src = "positions_sum"

    # ── DD ──
    dd = 0.0
    if hwm_usd > 0 and equity_usd > 0:
        dd = min(0.0, (equity_usd / hwm_usd) - 1.0)

    source = {
        "equity": "deribit_account_summary",
        "margin": "deribit_account_summary",
        "delta": delta_src,
        "gamma": gamma_src,
        "vega": vega_src,
        "spot": "deribit_get_index_price",
        "hwm": "local_db",
    }

    return CurrentPortfolioState(
        equity_usd=equity_usd,
        margin_balance_usd=mb_usd,
        maintenance_margin_usd=mm_usd,
        initial_margin_usd=im_usd,
        available_funds_usd=avail_usd,
        mm_pct=mm_pct,
        delta_btc=delta_btc,
        gamma=gamma,
        vega=vega,
        spot_index_usd=spot_index_usd,
        hwm_usd=hwm_usd,
        dd=dd,
        source=source,
    )


# ─────────────────────────────────────────────
# Post-trade state (from Deribit simulate_portfolio)
# ─────────────────────────────────────────────

@dataclass
class PostTradeState:
    """
    Normalized post-trade state after applying a candidate hedge bundle.
    Sourced from Deribit private/simulate_portfolio.
    """
    equity_usd: float = 0.0      # projected equity after trade (current market)
    margin_balance_usd: float = 0.0
    maintenance_margin_usd: float = 0.0
    initial_margin_usd: float = 0.0
    mm_pct: float = 0.0

    delta_btc: float = 0.0
    gamma: float = 0.0
    vega: float = 0.0

    spot_index_usd: float = 0.0
    hwm_usd: float = 0.0

    # Simulation status
    sim_ok: bool = True
    sim_error: Optional[str] = None
    source: str = "deribit_simulate_portfolio"

    # The actions that were simulated
    simulated_positions: Dict[str, float] = field(default_factory=dict)

    ts_utc: datetime = field(default_factory=_utc_now)

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        d["ts_utc"] = self.ts_utc.isoformat() if self.ts_utc else None
        return d


def build_post_trade_state(
    *,
    sim_raw: Dict[str, Any],
    current_state: CurrentPortfolioState,
    simulated_positions: Dict[str, float],
    sim_ok: bool = True,
    sim_error: Optional[str] = None,
) -> PostTradeState:
    """
    Build PostTradeState from Deribit simulate_portfolio response.

    Extracts projected margin + greeks. Falls back to current state on failure.
    """
    if not sim_ok or not sim_raw:
        # Failure: return current state with failure markers
        return PostTradeState(
            equity_usd=current_state.equity_usd,
            margin_balance_usd=current_state.margin_balance_usd,
            maintenance_margin_usd=current_state.maintenance_margin_usd,
            initial_margin_usd=current_state.initial_margin_usd,
            mm_pct=current_state.mm_pct,
            delta_btc=current_state.delta_btc,
            gamma=current_state.gamma,
            vega=current_state.vega,
            spot_index_usd=current_state.spot_index_usd,
            hwm_usd=current_state.hwm_usd,
            sim_ok=False,
            sim_error=sim_error or "simulation_failed",
            source="fallback_from_current",
            simulated_positions=simulated_positions,
        )

    # ── Extract margin fields ──
    mm = _sf(sim_raw.get("projected_maintenance_margin") or sim_raw.get("maintenance_margin"))
    mb = _sf(sim_raw.get("margin_balance"))
    im = _sf(sim_raw.get("projected_initial_margin") or sim_raw.get("initial_margin"))
    mm_pct = (mm / mb * 100.0) if mb > 0 else current_state.mm_pct

    # ── Extract equity ──
    # simulate_portfolio may return equity or margin_balance as post-trade equity proxy
    equity_after = _sf(sim_raw.get("equity"))
    if equity_after <= 0:
        equity_after = _sf(sim_raw.get("margin_balance"))
    if equity_after <= 0:
        equity_after = current_state.equity_usd

    # Convert BTC equity to USD if needed
    spot = current_state.spot_index_usd
    if equity_after > 0 and equity_after < 100 and spot > 1000:
        # Heuristic: if equity looks like BTC value (small number), convert to USD
        equity_after = equity_after * spot

    # ── Extract greeks ──
    def _pick_greek(keys: List[str]) -> Optional[float]:
        for k in keys:
            v = sim_raw.get(k)
            if v is not None:
                if isinstance(v, dict):
                    for nested_v in v.values():
                        try:
                            return float(nested_v)
                        except Exception:
                            continue
                try:
                    return float(v)
                except Exception:
                    continue
            # Check nested containers
            for container in ("result", "portfolio", "risk", "greeks"):
                obj = sim_raw.get(container)
                if isinstance(obj, dict):
                    cv = obj.get(k)
                    if cv is not None:
                        try:
                            return float(cv) if not isinstance(cv, dict) else None
                        except Exception:
                            pass
        return None

    delta = _pick_greek([
        "delta", "portfolio_delta", "total_delta", "delta_total",
        "projected_delta_total", "delta_total_map",
    ])
    gamma = _pick_greek([
        "gamma", "portfolio_gamma", "total_gamma", "options_gamma", "options_gamma_map",
    ])
    vega = _pick_greek([
        "vega", "portfolio_vega", "total_vega", "options_vega", "options_vega_map",
    ])

    return PostTradeState(
        equity_usd=equity_after,
        margin_balance_usd=mb,
        maintenance_margin_usd=mm,
        initial_margin_usd=im,
        mm_pct=mm_pct,
        delta_btc=delta if delta is not None else current_state.delta_btc,
        gamma=gamma if gamma is not None else current_state.gamma,
        vega=vega if vega is not None else current_state.vega,
        spot_index_usd=spot,
        hwm_usd=current_state.hwm_usd,
        sim_ok=True,
        sim_error=None,
        source="deribit_simulate_portfolio",
        simulated_positions=simulated_positions,
    )


# ─────────────────────────────────────────────
# Stressed state (from local stress engine)
# ─────────────────────────────────────────────

@dataclass
class StressedState:
    """
    Result of running one scenario through the local stress engine.
    This is computed locally, NOT from Deribit.
    """
    scenario_name: str = ""
    spot_shock_pct: float = 0.0
    iv_shock_vol: float = 0.0

    pnl_total_usd: float = 0.0
    pnl_delta_usd: float = 0.0
    pnl_gamma_usd: float = 0.0
    pnl_vega_usd: float = 0.0

    projected_equity_usd: float = 0.0
    projected_dd: float = 0.0  # <= 0

    # Which base was used for stress
    base_equity_usd: float = 0.0
    base_source: str = ""  # "current" or "post_trade"

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)
