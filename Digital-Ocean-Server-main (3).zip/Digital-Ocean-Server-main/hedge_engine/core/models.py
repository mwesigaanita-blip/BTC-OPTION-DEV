# hedge_engine/core/models.py
from __future__ import annotations

from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


def to_jsonable_dict(obj: Any) -> Dict[str, Any]:
    if hasattr(obj, "__dataclass_fields__"):
        return asdict(obj)
    if isinstance(obj, dict):
        return obj
    raise TypeError(f"Unsupported type for to_jsonable_dict: {type(obj)}")


@dataclass(frozen=True)
class EngineInputs:
    total_equity_usd: float
    hwm_usd: float
    dd: float  # negative in drawdown

    mm_pct: float

    spot_index_usd: float
    spot_move_24h_pct: float
    spot_move_30m_pct: float
    spot_move_intraday_pct: float

    hv_30d_pct: float
    hv_30d_change_7d_pct: float
    iv_atm_30d_pct: float
    iv_minus_hv_30d_pp: float

    portfolio_delta_btc: float  # MUST match Deribit "Delta" column (BTC)
    portfolio_gamma: float
    portfolio_vega: float  # signed; negative means short vega exposure

    updated_at_utc: datetime = field(default_factory=utc_now)


@dataclass(frozen=True)
class StressScenario:
    name: str
    spot_shock_pct: float  # e.g. -0.05
    iv_shock_vol: float    # e.g. +10 vol points
    skew_bump: Optional[Dict[str, float]] = None  # optional by delta bucket


@dataclass(frozen=True)
class StressResult:
    scenario: str
    pnl_usd: float
    dd_after: float
    notes: List[str] = field(default_factory=list)


@dataclass(frozen=True)
class HedgeMetrics:
    delta_btc: float
    gamma: float
    vega: float
    mm_pct: float
    stress_a: Optional[StressResult] = None
    stress_b: Optional[StressResult] = None


@dataclass(frozen=True)
class Action:
    # executable string like:
    # "SELL 14 BTC-PERP"
    # "CLOSE 12 BTC-29MAR24-80000-C"
    # "BUY 6 BTC-28JUN24-60000-P"
    cmd: str
    meta: Dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class ActionBundle:
    mode: str  # "SUGGEST" | "NO_VALID_BUNDLE"
    reason: str
    actions: List[Action]

    before: HedgeMetrics
    after_est: HedgeMetrics

    debug: Dict[str, Any] = field(default_factory=dict)
    created_at_utc: datetime = field(default_factory=utc_now)
    no_valid_bundle: bool = False  # Phase 8: True when all escalation tiers exhausted


def compute_drawdown(*, total_equity_usd: float, hwm_usd: float) -> float:
    """
    dd = (equity - hwm) / hwm
    returns <= 0 when below HWM
    """
    if hwm_usd <= 0:
        raise ValueError("hwm_usd must be > 0")
    return (float(total_equity_usd) - float(hwm_usd)) / float(hwm_usd)


from hedge_engine.core.enums import ActionType, Side


@dataclass
class Position:
    instrument_name: str
    kind: str                      # "option" | "perpetual" | "future"
    size: float                    # signed
    net_delta: float
    gamma: float
    vega: float
    theta: float
    option_type: Optional[str]     # "C" | "P" | None
    strike: Optional[float]
    dte_days: Optional[float]
    mark_price_usd: Optional[float]
    mark_price_btc: Optional[float]
    index_price: Optional[float]
    delta: Optional[float]
    meta: Dict[str, Any] = field(default_factory=dict)


@dataclass
class PortfolioSnapshot:
    total_equity_usd: float
    hwm_usd: float
    dd: float
    mm_pct: float
    spot_index_usd: float
    portfolio_delta_btc: float
    portfolio_gamma: float
    portfolio_vega: float
    hv_30d_pct: float
    iv_atm_30d_pct: float
    iv_minus_hv_30d_pp: float
    updated_at_utc: datetime
    positions: List[Position] = field(default_factory=list)
    stress_artifact: Optional[Dict[str, Any]] = None
    mode: str = "NORMAL"
    equity_usd: float = 0.0        # alias for total_equity_usd


@dataclass
class CandidateAction:
    action_type: ActionType
    instrument_name: str
    side: Side
    qty_btc: Optional[float] = None
    qty_contracts: Optional[int] = None
    meta: Dict[str, Any] = field(default_factory=dict)


# ---------------------------------------------------------------------------
# Sub-engine models (Greek-per-engine pipeline)
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class GreekProfile:
    """Snapshot of portfolio greeks at a point in time (possibly adjusted by prior suggestions)."""
    delta_btc: float
    gamma: float
    vega: float
    equity_usd: float
    spot_usd: float
    mm_pct: float
    dd: float = 0.0  # drawdown fraction (negative when below HWM); 0.0 if unknown


@dataclass(frozen=True)
class GreekTargets:
    """Safe-zone boundaries computed from DD ladder + IV-HV spread + mode."""
    delta_band_min: float      # BTC lower bound (negative = short delta ok)
    delta_band_max: float      # BTC upper bound
    gamma_target: float        # min safe gamma (negative book: target is closer to 0)
    vega_target: float         # min safe vega (negative book: target is closer to 0)
    mode: str                  # "NORMAL" | "DEFENSIVE" | "DANGER" | "EMERGENCY"
    iv_hv_multiplier: float    # 1.00 | 1.15 | 1.30 based on IV-HV spread
    hedge_ratio_H: float       # 0.0–1.0 from DD ladder


@dataclass(frozen=True)
class Suggestion:
    """Output of one Greek sub-engine (gamma, vega, or delta)."""
    engine: str                # "gamma" | "vega" | "delta"
    method: str                # "buy_option" | "sell_option" | "perp" | "close_existing" | "no_action"
    instrument: str            # e.g. "BTC-27JUN25-70000-P" or "BTC-PERPETUAL"
    size: float                # contracts or BTC
    direction: str             # "buy" | "sell" | "none"
    delta_impact: float        # signed BTC delta change from this suggestion
    gamma_impact: float        # signed gamma change
    vega_impact: float         # signed vega change (USD/vol)
    post_mm_pct: float         # projected MM% after this trade
    post_dd_est: float         # estimated DD after (from simulation)
    post_delta: float          # portfolio delta after
    post_gamma: float          # portfolio gamma after
    post_vega: float           # portfolio vega after
    fallback_used: bool        # True if tier > 0 was used
    fallback_tier: int         # 0=primary, 1=sell_other_side, 2=close_existing
    rationale: str             # plain English - why this action was chosen
    risk_note: str             # plain English - residual risk or caveats
    simulation_ok: bool        # False if Deribit simulation failed for all tiers
    action_classification: str = "no_action"  # proper_hedge | mm_relief | fallback_last_resort | no_action
    size_clamped: bool = False               # True when size was limited by hard cap
    target_reached: bool = True              # False when clamping prevented reaching target


@dataclass(frozen=True)
class HedgeTick:
    """Complete output of one hedge engine tick (all three sub-engine suggestions)."""
    greek_profile: GreekProfile        # portfolio state at start of tick
    targets: GreekTargets              # computed safe-zone boundaries
    suggestion_gamma: Optional[Suggestion]
    suggestion_vega: Optional[Suggestion]
    suggestion_delta: Optional[Suggestion]
    combined_post_state: Dict[str, Any]  # {mm_pct, delta, gamma, vega} after all suggestions
    any_fallback_triggered: bool
    timestamp: datetime


if __name__ == "__main__":
    # Example usage
    inputs = EngineInputs(
        total_equity_usd=95000,
        hwm_usd=100000,
        dd=compute_drawdown(total_equity_usd=95000, hwm_usd=100000),
        mm_pct=0.05,
        spot_index_usd=30000,
        spot_move_24h_pct=-0.02,
        spot_move_30m_pct=-0.01,
        spot_move_intraday_pct=-0.015,
        hv_30d_pct=0.6,
        hv_30d_change_7d_pct=-0.1,
        iv_atm_30d_pct=0.65,
        iv_minus_hv_30d_pp=0.05,
        portfolio_delta_btc=-2.5,
        portfolio_gamma=150,
        portfolio_vega=-500
    )
    print(inputs)