# test remo branch


# hedge_engine/settings/regime_rules.py
#
# Deterministic regime classification (unit-test friendly).
# Used to decide whether we are in HIGH-VOL regime (tail hedge budget 0.55%/month)
# or NORMAL regime (tail hedge budget 0.35%/month).
#
# This file MUST stay purely deterministic (no LLM, no external calls).

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Optional


@dataclass(frozen=True)
class RegimeInputs:
    """
    All fields are optional so the engine can run even if some signals are missing.
    Values are expected in percentage points (e.g., 52.3 for 52.3%).
    """
    hv_30d_pct: Optional[float] = None          # realized vol 30D (annualized %)
    hv_30d_change_7d_pct: Optional[float] = None  # hv_30d now - hv_30d 7d ago (pp)
    iv_atm_30d_pct: Optional[float] = None      # ATM IV ~30D (annualized %)
    iv_minus_hv_30d_pp: Optional[float] = None  # (IV - HV) in percentage points
    spot_move_24h_pct: Optional[float] = None   # absolute move in last 24h (%, abs)
    funding_annualized_pct: Optional[float] = None  # optional signal


@dataclass(frozen=True)
class RegimeResult:
    regime: str  # "normal" | "high" | "panic"
    is_high_vol: bool
    is_panic: bool
    reasons: tuple[str, ...]
    debug: Dict[str, Any]


def classify_regime(inp: RegimeInputs) -> RegimeResult:
    """
    Deterministic rules.

    Philosophy:
    - HIGH regime should be triggered when realized vol is high OR rising fast OR IV >> HV.
    - PANIC is a stronger state (extreme IV or extreme IV-HV dislocation),
      useful for being more defensive and allowing higher tail budget.

    Thresholds are chosen to be reasonable for BTC and can be tuned later in config,
    but the logic stays the same.
    """
    reasons = []
    debug: Dict[str, Any] = {
        "hv_30d_pct": inp.hv_30d_pct,
        "hv_30d_change_7d_pct": inp.hv_30d_change_7d_pct,
        "iv_atm_30d_pct": inp.iv_atm_30d_pct,
        "iv_minus_hv_30d_pp": inp.iv_minus_hv_30d_pp,
        "spot_move_24h_pct": inp.spot_move_24h_pct,
        "funding_annualized_pct": inp.funding_annualized_pct,
    }

    # --- base thresholds (tunable later) ---
    HV_HIGH = 55.0                # HV >= 55% => high vol
    HV_RISING_FAST_7D = 7.0       # HV +7pp in 7d => high vol
    IV_HIGH = 70.0                # IV >= 70% => high vol
    IVHV_DISLOC_HIGH = 12.0       # IV - HV >= 12pp => high vol

    # panic thresholds
    IV_PANIC = 85.0               # IV >= 85% => panic
    IVHV_DISLOC_PANIC = 20.0      # IV - HV >= 20pp => panic
    MOVE_24H_PANIC = 10.0         # abs move >= 10% in 24h => panic (optional)

    # --- compute flags safely ---
    hv_high = (inp.hv_30d_pct is not None) and (inp.hv_30d_pct >= HV_HIGH)
    hv_rising_fast = (inp.hv_30d_change_7d_pct is not None) and (inp.hv_30d_change_7d_pct >= HV_RISING_FAST_7D)
    iv_high = (inp.iv_atm_30d_pct is not None) and (inp.iv_atm_30d_pct >= IV_HIGH)
    ivhv_disloc_high = (inp.iv_minus_hv_30d_pp is not None) and (inp.iv_minus_hv_30d_pp >= IVHV_DISLOC_HIGH)

    iv_panic = (inp.iv_atm_30d_pct is not None) and (inp.iv_atm_30d_pct >= IV_PANIC)
    ivhv_disloc_panic = (inp.iv_minus_hv_30d_pp is not None) and (inp.iv_minus_hv_30d_pp >= IVHV_DISLOC_PANIC)
    move_24h_panic = (inp.spot_move_24h_pct is not None) and (abs(inp.spot_move_24h_pct) >= MOVE_24H_PANIC)

    # --- PANIC first ---
    is_panic = False
    if iv_panic:
        is_panic = True
        reasons.append(f"IV_ATM_30D>= {IV_PANIC:.0f}%")
    if ivhv_disloc_panic:
        is_panic = True
        reasons.append(f"IV-HV>= {IVHV_DISLOC_PANIC:.0f}pp")
    if move_24h_panic:
        is_panic = True
        reasons.append(f"|MOVE_24H|>= {MOVE_24H_PANIC:.0f}%")

    # --- HIGH regime ---
    is_high_vol = False
    if hv_high:
        is_high_vol = True
        reasons.append(f"HV_30D>= {HV_HIGH:.0f}%")
    if hv_rising_fast:
        is_high_vol = True
        reasons.append(f"HV_30D_7D_RISE>= {HV_RISING_FAST_7D:.0f}pp")
    if iv_high:
        is_high_vol = True
        reasons.append(f"IV_ATM_30D>= {IV_HIGH:.0f}%")
    if ivhv_disloc_high:
        is_high_vol = True
        reasons.append(f"IV-HV>= {IVHV_DISLOC_HIGH:.0f}pp")

    # panic implies high vol
    if is_panic:
        is_high_vol = True

    # --- final regime label ---
    if is_panic:
        regime = "panic"
    elif is_high_vol:
        regime = "high"
    else:
        regime = "normal"

    debug.update(
        {
            "hv_high": hv_high,
            "hv_rising_fast": hv_rising_fast,
            "iv_high": iv_high,
            "ivhv_disloc_high": ivhv_disloc_high,
            "iv_panic": iv_panic,
            "ivhv_disloc_panic": ivhv_disloc_panic,
            "move_24h_panic": move_24h_panic,
            "regime": regime,
        }
    )

    return RegimeResult(
        regime=regime,
        is_high_vol=is_high_vol,
        is_panic=is_panic,
        reasons=tuple(reasons) if reasons else ("no_high_vol_signals",),
        debug=debug,
    )


def decide_tail_budget_monthly_equity_pct(
    *,
    normal_budget_pct: float,
    highvol_budget_pct: float,
    regime: RegimeResult,
) -> float:
    """
    Returns which monthly tail budget to use (unit-testable).
    """
    return highvol_budget_pct if regime.is_high_vol else normal_budget_pct


def regime_debug_dict(inp: RegimeInputs, res: RegimeResult) -> Dict[str, Any]:
    """
    Standard JSON-friendly payload for logging/debug dumps.
    """
    return {
        "inputs": {
            "hv_30d_pct": inp.hv_30d_pct,
            "hv_30d_change_7d_pct": inp.hv_30d_change_7d_pct,
            "iv_atm_30d_pct": inp.iv_atm_30d_pct,
            "iv_minus_hv_30d_pp": inp.iv_minus_hv_30d_pp,
            "spot_move_24h_pct": inp.spot_move_24h_pct,
            "funding_annualized_pct": inp.funding_annualized_pct,
        },
        "result": {
            "regime": res.regime,
            "is_high_vol": res.is_high_vol,
            "is_panic": res.is_panic,
            "reasons": list(res.reasons),
            "debug": res.debug,
        },
    }
    
    
if __name__ == "__main__":
    # Quick test
    test_input = RegimeInputs(
        hv_30d_pct=60.0,
        hv_30d_change_7d_pct=8.0,
        iv_atm_30d_pct=75.0,
        iv_minus_hv_30d_pp=15.0,
        spot_move_24h_pct=2.0,
        funding_annualized_pct=5.0,
    )
    result = classify_regime(test_input)
    print(regime_debug_dict(test_input, result))