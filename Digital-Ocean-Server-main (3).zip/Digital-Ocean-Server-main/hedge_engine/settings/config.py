# Live test
# test again 


# hedge_engine/settings/config.py
#
# Deterministic BTC Options Hedge Engine (Suggest-only, Deribit X:PM)
# All constants and configuration live here.

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Optional

REPO_ROOT = Path(__file__).resolve().parents[2]
DB_PATH = REPO_ROOT / "data" / "btc_trading.sqlite"

# =========================
# Paths / Environment
# =========================

def _find_repo_root(start: Optional[Path] = None) -> Path:
    """
    Find project root by walking up until we find a known anchor folder.
    Works whether you deploy on DigitalOcean or move the project elsewhere.
    """
    # Last resort: assume 3 levels up from this file (hedge_engine/settings/config.py)
    return Path(__file__).resolve().parents[2]


def get_db_path() -> Path:
    """
    Dynamic DB path:
    - If you keep the same relative structure:
        <repo>/Digital-Ocean-Server/data/btc_trading.sqlite
      it will resolve correctly.
    - If you move the whole folder, it still works as long as "data/btc_trading.sqlite"
      exists under the repo root.
    """
    root = _find_repo_root()
    return (root / "data" / "btc_trading.sqlite").resolve()


# =========================
# Stress scenario config
# =========================

@dataclass(frozen=True)
class StressScenario:
    name: str
    spot_shock_pct: float     # e.g. -0.05
    iv_bump_vol: float        # absolute vol points (e.g. +10)
    apply_skew_bump: bool = False


@dataclass(frozen=True)
class SkewBumpRule:
    """
    Extra IV bump (vol points) applied to puts in Scenario B by delta buckets.
    Delta here refers to absolute put delta in (0..1), e.g. 0.15 for 15-delta put.
    """
    # bucket bounds are inclusive of lower, exclusive of upper
    # Example: 20–30Δ => [0.20, 0.30)
    put_delta_20_30_extra_vol: float = 4.0
    put_delta_10_20_extra_vol: float = 6.0
    put_delta_lt_10_extra_vol: float = 9.0


# =========================
# Alert config
# =========================

@dataclass(frozen=True)
class AlertPolicy:
    """
    Non-spam policy:
    - Severity thresholds are based on DD/MM/stress.
    - Cooldowns prevent repeating the same alert too often.
    """
    # Thresholds
    warn_mm_pct: float = 80.0
    urgent_mm_pct: float = 90.0
    emergency_mm_pct: float = 95.0

    warn_dd_pct: float = -2.0     # dd <= -2% -> WARNING
    urgent_dd_pct: float = -6.0   # dd <= -6% -> URGENT

    # "near breach" stress threshold (start alerting before -10%)
    stress_near_breach_dd_pct: float = -8.0

    # Cooldowns (seconds)
    cooldown_info_s: int = 24 * 3600      # daily heartbeat (optional)
    cooldown_warning_s: int = 10 * 60     # 10 minutes
    cooldown_urgent_s: int = 3 * 60       # 3 minutes
    cooldown_emergency_s: int = 60        # 1 minute (can repeat until ack)


# =========================
# Main engine config
# =========================

@dataclass(frozen=True)
class EngineConfig:
    # ---- runtime ----
    tick_seconds: int = 30

    # ---- drawdown ----
    max_dd: float = 0.10  # 10% hard cap (DD is negative in calculations)
    # Convex ladder (neutralization ratios)
    dd_ladder: Dict[str, float] = None  # set in __post_init__ via defaults below

    # ---- modifiers ----
    mm_extra_delta_reduction_pct: float = 0.10  # +10% hedge ratio when MM in warning zone
    force_min_hedge_ratio_on_mm_danger: float = 0.95  # MM>=90% => at least 95% neutral

    # ---- vega / gamma limits ----
    vega_limit_equity_pct_per_vol: float = 0.005  # 0.5% equity per +1 vol
    gamma_budget_equity_pct_under_5pct_move: float = 0.01  # 1% equity budget under -5% move

    # ---- tail hedge (budget model) ----
    tail_budget_monthly_normal_equity_pct: float = 0.0035  # 0.35% equity per month
    tail_budget_monthly_highvol_equity_pct: float = 0.0055 # 0.55% equity per month
    tail_dte_min: int = 30
    tail_dte_max: int = 60

    # ---- stress scenarios (bidirectional) ----
    # Design principles:
    #   Downside: IV typically spikes on crashes → iv_bump is always positive
    #   Upside:   IV behavior depends on move type:
    #     - Calm rally:    IV drops (most common)    → iv_bump negative
    #     - Flat IV rally: IV unchanged              → iv_bump zero
    #     - Squeeze/mania: IV spikes (rare stress)   → iv_bump positive
    #   We model all three upside regimes for correct risk assessment.
    stress_scenarios: tuple[StressScenario, ...] = (
        # ── Downside: spot drops, IV spikes ──
        StressScenario("S1_DOWN_5",  spot_shock_pct=-0.05, iv_bump_vol=3.0,  apply_skew_bump=False),
        StressScenario("S2_DOWN_5",  spot_shock_pct=-0.05, iv_bump_vol=5.0,  apply_skew_bump=False),
        StressScenario("S3_DOWN_5",  spot_shock_pct=-0.05, iv_bump_vol=10.0, apply_skew_bump=False),
        StressScenario("S4_DOWN_10", spot_shock_pct=-0.10, iv_bump_vol=10.0, apply_skew_bump=False),
        StressScenario("S5_DOWN_10", spot_shock_pct=-0.10, iv_bump_vol=20.0, apply_skew_bump=True),

        # ── Upside: calm rally, IV drops (most likely) ──
        StressScenario("S6_UP_5",    spot_shock_pct=+0.05, iv_bump_vol=-2.0, apply_skew_bump=False),
        StressScenario("S7_UP_10",   spot_shock_pct=+0.10, iv_bump_vol=-3.0, apply_skew_bump=False),

        # ── Upside: flat IV rally ──
        StressScenario("S8_UP_5",    spot_shock_pct=+0.05, iv_bump_vol=0.0,  apply_skew_bump=False),
        StressScenario("S9_UP_10",   spot_shock_pct=+0.10, iv_bump_vol=0.0,  apply_skew_bump=False),

        # ── Upside: squeeze / mania, IV spikes (rare but dangerous) ──
        StressScenario("S10_UP_5",   spot_shock_pct=+0.05, iv_bump_vol=3.0,  apply_skew_bump=False),
        StressScenario("S11_UP_10",  spot_shock_pct=+0.10, iv_bump_vol=5.0,  apply_skew_bump=False),
        StressScenario("S12_UP_10",  spot_shock_pct=+0.10, iv_bump_vol=10.0, apply_skew_bump=False),
    )
    skew_bump: SkewBumpRule = SkewBumpRule()

    # ---- pricing ----
    r_rate: float = 0.0
    iv_floor: float = 0.05  # 5%
    use_index_price_as_spot: bool = True
    perps_linear_pnl: bool = True

    # ---- margin guardrails ----
    mm_warning_pct = 70.0
    mm_critical_pct = 80.0
    mm_dangerous_pct = 90.0

    # ---- speed triggers ----
    speed_trigger_30m_return: float = 0.03  # 3%
    speed_trigger_day_return: float = 0.06  # 6%
    # how much history to keep for speed calculations
    speed_window_minutes: int = 30

    # ---- deep stress trigger policy ----
    deep_stress_trigger_dd_pct: float = -2.0
    deep_stress_trigger_mm_pct: float = 80.0
    deep_stress_trigger_stress_near_breach_dd_pct: float = -8.0
    deep_stress_min_interval_s: int = 10 * 60  # run deep stress at most once per 10 min unless emergency

    # ---- alerts ----
    alerts: AlertPolicy = AlertPolicy()

    # ---- sqlite path ----
    db_path: Path = DB_PATH  # filled in __post_init__

    def __post_init__(self):
        # dataclasses with frozen=True: use object.__setattr__
        if self.ESCALATION_MAX_REDUCTIONS is None:
            object.__setattr__(
                self,
                "ESCALATION_MAX_REDUCTIONS",
                {"A_LIGHT": 2, "B_MEDIUM": 3, "C_STRONG": 4, "D_SURVIVAL": 5},
            )
        if self.dd_ladder is None:
            object.__setattr__(
                self,
                "dd_ladder",
                {
                    "dd_0_2": 0.25,
                    "dd_2_4": 0.50,
                    "dd_4_6": 0.75,
                    "dd_6_8": 0.95,
                    "dd_ge_8": 1.00,
                },
            )
        if self.db_path is None:
            object.__setattr__(self, "db_path", get_db_path())
        # ---- keep aliases synced with your "pct" fields ----
        object.__setattr__(self, "DEEP_STRESS_DD_TRIGGER", float(self.deep_stress_trigger_dd_pct) / 100.0)
        object.__setattr__(self, "MM_WARN_PCT", float(self.deep_stress_trigger_mm_pct))
        object.__setattr__(self, "FAST_STRESS_OVERRIDE_DD", float(self.deep_stress_trigger_stress_near_breach_dd_pct) / 100.0)
        object.__setattr__(self, "DEEP_STRESS_INTERVAL_SEC", int(self.deep_stress_min_interval_s))

        object.__setattr__(self, "VEGA_LIMIT_EQUITY_PCT_PER_VOL", float(self.vega_limit_equity_pct_per_vol))
        object.__setattr__(self, "GAMMA_BUDGET_EQUITY_PCT_UNDER_5PCT_MOVE", float(self.gamma_budget_equity_pct_under_5pct_move))
        object.__setattr__(self, "SPEED_TRIGGER_30M_RETURN", float(self.speed_trigger_30m_return))
        object.__setattr__(self, "SPEED_TRIGGER_DAY_RETURN", float(self.speed_trigger_day_return))

    # ---- unified aliases used by stress_runner / risk_checks ----
    # (keep these even if you already have similar fields; this avoids fragile getattr names)

    # deep stress trigger (runner expects decimals, not percents)
    DEEP_STRESS_DD_TRIGGER: float = -0.02           # dd_worst <= -0.02 triggers deep
    DEEP_STRESS_INTERVAL_SEC: int = 10 * 60         # deep stress periodic gate
    MM_WARN_PCT: float = 85.0                       # runner uses this for deep trigger
    FAST_STRESS_OVERRIDE_DD: float = -0.08          # projected_dd <= -0.08 triggers override

    # thresholds for risk_checks (keep in sync with existing fields)
    VEGA_LIMIT_EQUITY_PCT_PER_VOL: float = 0.005
    GAMMA_BUDGET_EQUITY_PCT_UNDER_5PCT_MOVE: float = 0.01
    SPEED_TRIGGER_30M_RETURN: float = 0.03
    SPEED_TRIGGER_DAY_RETURN: float = 0.06

    # Delta hedge ignore threshold: skip tiny hedges unless impact >= X% of equity
    MIN_DELTA_HEDGE_USD_PCT_EQUITY: float = 0.002  # 0.20% of equity

    # Gamma hedge candidate generation (Phase 5)
    GAMMA_HEDGE_MIN_DTE_DAYS: int = 7
    GAMMA_HEDGE_MAX_DTE_DAYS: int = 14
    GAMMA_HEDGE_MAX_CANDIDATES: int = 3

    # Event sizing caps (deterministic, conservative; Phase 6 will validate)
    GAMMA_HEDGE_EVENT_BUDGET_USD: float = 500.0
    GAMMA_HEDGE_MIN_CONTRACTS: int = 1
    GAMMA_HEDGE_MAX_CONTRACTS: int = 10

    GAMMA_STRESS_MOVE_PCT: float = 5.0
    
    MIN_DELTA_HEDGE_BTC: float = 0.001
    MAX_SINGLE_DELTA_HEDGE_BTC: float = 5.0
    PERP_CHUNK_BTC: float = 2.0
    PERP_MIN_CHUNK_BTC: float = 0.5
    PERP_MAX_CHUNKS: int = 5

    # ---- Phase 2: Bundle acceptance gates ----
    BUNDLE_STRESS_DD_KILLSWITCH: float = -0.10       # reject if stress DD after <= this
    BUNDLE_STRESS_IMPROVEMENT_MIN: float = 0.005      # minimum stress DD improvement (0.5pp)
    BUNDLE_MM_WORSEN_TOLERANCE_PP: float = 5.0        # max MM% worsening allowed
    BUNDLE_REQUIRE_MM_IMPROVE_WHEN_STRESSED: bool = True  # require MM improvement when >= warning

    # ---- Phase 3: Reason coverage thresholds ----
    REASON_VEGA_IMPROVE_MIN_PCT: float = 0.05         # 5% reduction in abs(vega)
    REASON_GAMMA_IMPROVE_MIN_PCT: float = 0.05        # 5% reduction in abs(gamma)
    REASON_DELTA_IMPROVE_MIN_PCT: float = 0.10        # 10% reduction in abs(delta)
    REASON_COVERAGE_REQUIRED: bool = True              # enforce reason-linked improvement

    # ---- Phase 5: Escalation tiers ----
    ESCALATION_ENABLED: bool = True
    ESCALATION_TIER_B_H_BOOST: float = 0.20           # hedge ratio boost for tier B
    ESCALATION_TIER_C_H: float = 0.95                 # forced hedge ratio for tier C
    ESCALATION_MAX_REDUCTIONS: Dict[str, int] = None   # per-tier max risk reductions

    # ---- Phase 6: Offender scoring weights ----
    OFFENDER_WEIGHT_DTE: float = 0.25
    OFFENDER_WEIGHT_GAMMA: float = 0.25
    OFFENDER_WEIGHT_VEGA: float = 0.20
    OFFENDER_WEIGHT_MARGIN: float = 0.15
    OFFENDER_WEIGHT_STRESS: float = 0.15

    # ---- Phase 7: Perp grid search ----
    PERP_GRID_SEARCH_ENABLED: bool = True
    PERP_GRID_STEPS: int = 10
    PERP_DELTA_BAND_DEFENSIVE: tuple = (-0.5, 0.5)
    PERP_DELTA_BAND_DANGER: tuple = (-0.2, 0.2)
    PERP_DELTA_BAND_EMERGENCY: tuple = (-0.05, 0.05)

    # ---- Fast stress calibration caps ----
    # These prevent the Taylor-expansion fast stress from producing impossible results.
    # Deep stress (B-S repricing) is the accurate layer; fast stress is screening only.
    # Set > 0 to activate. 0.0 = uncapped (original behavior).
    #
    # Calibration rationale (2026-03-25):
    #   Live portfolio: vega = -4981 USD/vol, equity = $111k
    #   S4_DOWN_10 (+10 vol): raw vega PnL = $49,814 = 44.7% of equity
    #   Deep stress shows actual S4 loss is only $47,656 = 42.8% of equity (total)
    #   So vega alone in fast stress is already LARGER than the total deep loss.
    #   Caps must be tighter than the old 40/50/80 to be effective on NORMAL-regime.
    FAST_STRESS_GAMMA_PNL_CAP_EQUITY_PCT: float = 0.25   # max |gamma PnL| = 25% of equity
    FAST_STRESS_VEGA_PNL_CAP_EQUITY_PCT: float = 0.35    # max |vega PnL| = 35% of equity
    FAST_STRESS_TOTAL_LOSS_FLOOR_EQUITY_PCT: float = 0.65 # total loss cannot exceed 65% of equity

    # ---- Stress truth source preference ----
    # When True, deep stress is preferred over fast for acceptance/ranking decisions.
    # When False, fast stress is always used (legacy behavior).
    STRESS_PREFER_DEEP: bool = True

    # ---- Phase 9: Decision telemetry ----
    TELEMETRY_ENABLED: bool = True

    # ---- Sub-engine pipeline (Steps 4–7 migration) ----
    # Feature flag: True = new sequential sub-engine pipeline; False = legacy build_bundle()
    SUB_ENGINE_ENABLED: bool = True

    # Expanded DTE window for gamma hedge (was 14, now 21)
    GAMMA_HEDGE_DTE_MAX_EXPANDED: int = 21

    # Tier 1 fallback: max fraction of current book greek exposure to sell on other side
    TIER1_SELL_CAP_PCT: float = 0.30   # 30%

    # Tier 2 fallback: max number of existing positions to close
    TIER2_MAX_CLOSES: int = 2

    # IV-HV spread thresholds (percentage points) for multiplier steps
    IV_HV_MULTIPLIER_HIGH_PP: float = 20.0   # >= 20pp -> multiplier 1.30
    IV_HV_MULTIPLIER_MED_PP: float = 15.0    # >= 15pp -> multiplier 1.15

    # Recent trades count to fetch per instrument for liquidity scoring
    INSTRUMENT_SCORER_TRADE_COUNT: int = 20

    # Recency window for trade liquidity scoring (seconds)
    INSTRUMENT_SCORER_RECENCY_WINDOW_S: int = 300   # 5 minutes

    # ---- MHE upgrade: effectiveness & quality filters ----
    VEGA_EFFECTIVENESS_MIN_PCT: float = 0.08         # 8% min vega improvement ratio
    IMPACT_QUALITY_MIN_PCT: float = 0.08             # 8% min primary_score for scorer
    GAMMA_FORWARD_RISK_DD_THRESHOLD: float = -0.04   # projected DD that triggers proactive gamma

    # ---- MHE over-hedging prevention ----
    # Calm-state suppression: below both thresholds + NORMAL/DEFENSIVE → mild breaches are skipped
    CALM_MM_THRESHOLD: float = 65.0              # MM% below this = calm (0-65% = clearly safe)
    CALM_DD_ABS_PCT: float = 0.04                # |DD fraction| below this = calm (e.g. 0.04 = 4%)
    # Breach severity classification
    MILD_BREACH_MAX_PCT: float = 0.25            # breach < 25% of target gap = mild
    SEVERE_BREACH_MIN_PCT: float = 0.75          # breach >= 75% of target gap = severe
    # Delta side-effect caps per mode: max BTC abs delta impact allowed from a gamma/vega hedge
    DELTA_SIDE_EFFECT_CAP_NORMAL_BTC: float = 0.30
    DELTA_SIDE_EFFECT_CAP_DEFENSIVE_BTC: float = 0.50
    DELTA_SIDE_EFFECT_CAP_DANGER_BTC: float = 0.80
    DELTA_SIDE_EFFECT_CAP_EMERGENCY_BTC: float = 1.50
    # Net-benefit filter: (greek_improvement_ratio / delta_penalty_ratio) must exceed this
    NET_BENEFIT_MIN_RATIO: float = 0.5           # e.g. 0.5 means Greek improvement >= 50% of delta cost

    # ---- MHE delta soft-targeting: calm states use wider base-mode band ----
    # In calm states (MM < CALM_MM_THRESHOLD, |DD| < CALM_DD_ABS_PCT, NORMAL/DEFENSIVE)
    # the delta engine uses the soft band instead of the H-tightened hard band.
    # This prevents vega_breach escalators from forcing aggressive perp sells at low risk.
    DELTA_SOFT_BAND_NORMAL_BTC: float = 0.50      # base NORMAL band half-width (no H tightening)
    DELTA_SOFT_BAND_DEFENSIVE_BTC: float = 0.30   # base DEFENSIVE band half-width (no H tightening)

    # Phase 5: Opt-in bypass - when True, the soft band does NOT apply if vega is
    # severely below targets.vega_target (gap >= SEVERE_BREACH_MIN_PCT of target).
    # Disabled by default to preserve the Request-5 behaviour (avoid over-hedging at
    # low MM/DD even when vega is very short).  Set True if you want the H-escalation
    # from a severe vega breach to be honoured even in calm MM/DD states.
    DELTA_SOFT_BAND_VEGA_SEVERE_BYPASS: bool = False


def load_config() -> EngineConfig:
    """
    Single entry point used by the rest of the engine.
    """
    return EngineConfig()


# Test All
if __name__ == "__main__":
    config = load_config()
    print(config)