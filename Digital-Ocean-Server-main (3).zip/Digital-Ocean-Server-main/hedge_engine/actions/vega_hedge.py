# hedge_engine/actions/vega_hedge.py
from __future__ import annotations

import logging
import math
import sqlite3
from typing import Any, Dict, List, Optional

from hedge_engine.core.enums import ActionType, Side
from hedge_engine.core.models import (
    CandidateAction, PortfolioSnapshot, Position,
    GreekProfile, GreekTargets, Suggestion,
)
from hedge_engine.risk.risk_checks import RiskFlags
from hedge_engine.settings.config import EngineConfig
from hedge_engine.actions.convexity.strike_selector import get_candidates

logger = logging.getLogger(__name__)


def propose_vega_hedge(
    snapshot: PortfolioSnapshot,
    flags: RiskFlags,
    cfg: EngineConfig,
    con: sqlite3.Connection,
) -> Optional[CandidateAction]:
    """
    Propose a HEDGE_VEGA action when portfolio vega breaches the limit.

    Logic:
      - Trigger: flags.vega_breach == True
      - Target: long 30-60 DTE ~25-delta puts (downside protection preferred)
      - Sizing: ceil(vega_to_recover / est_vega_per_contract), clamped 1-10
      - Returns action with top-3 candidates in meta for operator selection
    """
    if not flags.vega_breach:
        return None

    vega_limit_usd = flags.vega_limit_usd
    vega_to_recover = abs(snapshot.portfolio_vega) - vega_limit_usd
    if vega_to_recover <= 0:
        return None

    candidates = get_candidates(
        snapshot, con, "P",
        min_dte=30, max_dte=60,
        delta_target=0.25,
        max_results=5,
    )
    if not candidates:
        return None

    top3 = candidates[:3]
    top_candidate = top3[0]

    mark_usd = float(top_candidate.get("mark_usd") or 1)
    est_vega_per_contract = mark_usd * 0.01   # approximation: ~1% of USD premium
    if est_vega_per_contract <= 0:
        est_vega_per_contract = 1.0

    qty = math.ceil(vega_to_recover / est_vega_per_contract)
    qty = max(1, min(10, qty))

    # Build top-3 candidate details for operator review
    top_candidates_meta = []
    for c in top3:
        c_mark = float(c.get("mark_usd") or 1)
        c_vega = max(c_mark * 0.01, 1e-9)
        c_qty = max(1, min(10, math.ceil(vega_to_recover / c_vega)))
        top_candidates_meta.append({
            "instrument_name": c["instrument_name"],
            "dte_days": c.get("dte_days"),
            "strike": c.get("strike"),
            "mark_usd": c_mark,
            "qty_suggested": c_qty,
            "est_vega_recovery": c_vega * c_qty,
        })

    return CandidateAction(
        action_type=ActionType.HEDGE_VEGA,
        instrument_name=top_candidate["instrument_name"],
        side=Side.BUY,
        qty_contracts=qty,
        meta={
            "generic_instruction": (
                f"BUY ~{qty} contracts, 30-60 DTE, ~25-delta put"
            ),
            "top_candidates": top_candidates_meta,
            "vega_breach_usd": abs(snapshot.portfolio_vega),
            "vega_limit_usd": vega_limit_usd,
            "vega_to_recover": vega_to_recover,
        },
    )


# ---------------------------------------------------------------------------
# DEPRECATED: propose_vega_hedge() above - use run() for new pipeline
# ---------------------------------------------------------------------------

def _no_action_suggestion_vega(rationale: str, risk_note: str = "") -> Suggestion:
    return Suggestion(
        engine="vega", method="no_action", instrument="", size=0.0, direction="none",
        delta_impact=0.0, gamma_impact=0.0, vega_impact=0.0,
        post_mm_pct=0.0, post_dd_est=0.0, post_delta=0.0, post_gamma=0.0, post_vega=0.0,
        fallback_used=False, fallback_tier=0,
        rationale=rationale, risk_note=risk_note, simulation_ok=True,
        action_classification="no_action",
    )


def _classify_vega_breach_severity(gap_pct: float, cfg: Any) -> str:
    """
    Classify vega breach severity from gap_pct = vega_gap / abs(targets.vega_target).
    Returns: 'none', 'mild', 'moderate', or 'severe'.
    """
    if gap_pct <= 0.0:
        return "none"
    mild_max   = float(getattr(cfg, "MILD_BREACH_MAX_PCT",  0.25))
    severe_min = float(getattr(cfg, "SEVERE_BREACH_MIN_PCT", 0.75))
    if gap_pct < mild_max:
        return "mild"
    if gap_pct < severe_min:
        return "moderate"
    return "severe"


def _get_vega_delta_side_effect_cap(mode: str, cfg: Any) -> float:
    """Per-mode BTC cap on the absolute delta side-effect from a vega hedge candidate."""
    m = (mode or "NORMAL").upper()
    if m == "NORMAL":
        return float(getattr(cfg, "DELTA_SIDE_EFFECT_CAP_NORMAL_BTC",    0.30))
    elif m == "DEFENSIVE":
        return float(getattr(cfg, "DELTA_SIDE_EFFECT_CAP_DEFENSIVE_BTC", 0.50))
    elif m == "DANGER":
        return float(getattr(cfg, "DELTA_SIDE_EFFECT_CAP_DANGER_BTC",    0.80))
    else:  # EMERGENCY
        return float(getattr(cfg, "DELTA_SIDE_EFFECT_CAP_EMERGENCY_BTC", 1.50))


def _classify_vega_action(
    adj_vega: float, post_vega: float, adj_mm: float, post_mm: float, cfg: Any,
) -> str:
    """Classify a vega action: proper_hedge, mm_relief, or fallback_last_resort."""
    eff_min = float(getattr(cfg, "VEGA_EFFECTIVENESS_MIN_PCT", 0.08))
    vega_ratio = abs(post_vega - adj_vega) / max(abs(adj_vega), 1e-9)
    mm_improved = post_mm < adj_mm - 1.0  # at least 1pp MM improvement
    if vega_ratio >= eff_min:
        return "proper_hedge"
    elif mm_improved:
        return "mm_relief"
    else:
        return "fallback_last_resort"


def _build_vega_suggestion(
    *,
    method: str,
    instrument: str,
    size: float,
    direction: str,
    sim: Dict[str, Any],
    greek_profile: GreekProfile,
    fallback_tier: int,
    rationale: str,
    risk_note: str,
    action_classification: str = "proper_hedge",
    target_reached: bool = True,
) -> Suggestion:
    post_delta = float(sim.get("delta_after") or greek_profile.delta_btc)
    post_gamma = float(sim.get("gamma_after") or greek_profile.gamma)
    post_vega  = float(sim.get("vega_after")  or greek_profile.vega)
    post_mm    = float(sim.get("mm_pct_after") or greek_profile.mm_pct)
    sim_ok     = bool(sim.get("safe", False)) and sim.get("error") is None

    return Suggestion(
        engine="vega",
        method=method,
        instrument=instrument,
        size=size,
        direction=direction,
        delta_impact=post_delta - greek_profile.delta_btc,
        gamma_impact=post_gamma - greek_profile.gamma,
        vega_impact=post_vega - greek_profile.vega,
        post_mm_pct=post_mm,
        post_dd_est=0.0,
        post_delta=post_delta,
        post_gamma=post_gamma,
        post_vega=post_vega,
        fallback_used=fallback_tier > 0,
        fallback_tier=fallback_tier,
        rationale=rationale,
        risk_note=risk_note,
        simulation_ok=sim_ok,
        action_classification=action_classification,
        target_reached=target_reached,
    )


def run(
    *,
    greek_profile: GreekProfile,
    targets: GreekTargets,
    positions: List[Position],
    snapshot: PortfolioSnapshot,
    cfg: EngineConfig,
    deribit: Any,
    con: sqlite3.Connection,
    gamma_suggestion: Optional[Suggestion] = None,
) -> Suggestion:
    """
    Vega sub-engine: suggests one action to bring net_vega above targets.vega_target.

    Receives the gamma_suggestion and applies its greek impacts first, so this engine
    sees the portfolio state AFTER the gamma hedge has been applied.

    Fallback chain:
      Tier 0 - buy 30–60 DTE ~25-delta put (preferred for downside vega exposure)
      Tier 1 - sell OTM call to free MM capacity
      Tier 2 - close existing short put (smallest close that achieves target)
      All fail - return Suggestion(simulation_ok=False)
    """
    from hedge_engine.actions.instrument_scorer import score_for_vega
    from hedge_engine.actions.position_management.risk_reduction import rank_position_offenders
    from hedge_engine.risk.xpm.xpm_simulator import simulate_action_impact

    # --- Apply gamma_suggestion impacts to get adjusted profile ---
    g_delta = float(gamma_suggestion.delta_impact if gamma_suggestion else 0.0)
    g_gamma = float(gamma_suggestion.gamma_impact if gamma_suggestion else 0.0)
    g_vega  = float(gamma_suggestion.vega_impact  if gamma_suggestion else 0.0)

    adj_delta = greek_profile.delta_btc + g_delta
    adj_gamma = greek_profile.gamma + g_gamma
    adj_vega  = greek_profile.vega  + g_vega

    # Build adjusted profile for scoring (equity/spot/mm unchanged)
    from dataclasses import replace as dc_replace
    try:
        adj_profile = dc_replace(
            greek_profile,
            delta_btc=adj_delta,
            gamma=adj_gamma,
            vega=adj_vega,
        )
    except Exception:
        # Fallback if frozen dataclass replace doesn't work: use original
        adj_profile = greek_profile

    # --- Trigger check ---
    if adj_vega >= targets.vega_target:
        return _no_action_suggestion_vega(
            rationale=f"adjusted vega {adj_vega:.2f} >= target {targets.vega_target:.2f}, no action needed",
        )

    vega_gap = targets.vega_target - adj_vega  # positive = how much vega we need to gain

    # --- Urgency gating (over-hedging prevention) ---
    mm_pct   = greek_profile.mm_pct
    dd_abs   = abs(float(getattr(greek_profile, "dd", 0.0)))
    mode_str = (targets.mode or "NORMAL").upper()
    is_calm  = (
        mm_pct < float(getattr(cfg, "CALM_MM_THRESHOLD", 65.0))
        and dd_abs < float(getattr(cfg, "CALM_DD_ABS_PCT", 0.04))
        and mode_str in {"NORMAL", "DEFENSIVE"}
    )
    # Vega breach severity: vega_gap / abs(target) - how large gap is relative to target size
    v_breach_pct      = vega_gap / max(abs(targets.vega_target), 1e-9)
    v_breach_severity = _classify_vega_breach_severity(v_breach_pct, cfg)

    # Fix B: Suppress mild vega breach in calm state
    if is_calm and v_breach_severity == "mild":
        logger.info(
            "vega: mild breach suppressed in calm state "
            "(MM=%.1f%%, DD=%.1f%%, breach=%.0f%%)",
            mm_pct, dd_abs * 100, v_breach_pct * 100,
        )
        return _no_action_suggestion_vega(
            rationale=(
                f"mild breach suppressed in calm state "
                f"(breach={v_breach_pct:.0%}, MM={mm_pct:.1f}%, DD={dd_abs*100:.1f}%)"
            ),
        )

    mm_critical  = float(getattr(cfg, "mm_critical_pct", 80.0))
    sell_cap_pct = float(getattr(cfg, "TIER1_SELL_CAP_PCT", 0.30))
    max_closes   = int(getattr(cfg, "TIER2_MAX_CLOSES", 2))
    trade_count  = int(getattr(cfg, "INSTRUMENT_SCORER_TRADE_COUNT", 20))
    recency_s    = int(getattr(cfg, "INSTRUMENT_SCORER_RECENCY_WINDOW_S", 300))
    budget_usd   = float(getattr(cfg, "GAMMA_HEDGE_EVENT_BUDGET_USD", 500.0))  # reuse budget

    # -----------------------------------------------------------------------
    # TIER 0: Buy put - regime-aware DTE/delta selection
    # -----------------------------------------------------------------------
    from hedge_engine.settings.regime_rules import classify_regime, RegimeInputs
    try:
        regime = classify_regime(RegimeInputs(
            hv_30d_pct=getattr(snapshot, "hv_30d_pct", None),
            iv_atm_30d_pct=getattr(snapshot, "iv_atm_30d_pct", None),
            iv_minus_hv_30d_pp=getattr(snapshot, "iv_minus_hv_30d_pp", None),
            spot_move_24h_pct=getattr(snapshot, "spot_move_24h_pct", None),
        ))
    except Exception:
        from hedge_engine.settings.regime_rules import RegimeResult
        regime = RegimeResult(regime="normal", is_high_vol=False, is_panic=False, reasons=(), debug={})

    if regime.is_panic:
        v_min_dte, v_max_dte, v_delta_target = 14, 90, 0.30
    elif regime.is_high_vol:
        v_min_dte, v_max_dte, v_delta_target = 21, 75, 0.25
    else:
        v_min_dte, v_max_dte, v_delta_target = 30, 60, 0.25

    candidates = get_candidates(
        snapshot=snapshot,
        con=con,
        option_type="P",
        min_dte=v_min_dte,
        max_dte=v_max_dte,
        delta_target=v_delta_target,
        max_results=5,
    )

    logger.info(
        "vega Tier0: %d candidates (DTE %d-%d, regime=%s, source=%s)",
        len(candidates), v_min_dte, v_max_dte, regime.regime,
        ",".join({c.get("source", "?") for c in candidates}) if candidates else "none",
    )
    if candidates:
        for _c in candidates[:3]:
            logger.info(
                "  candidate: %s  DTE=%.1f  mark_usd=%.2f  vega_approx=%s  source=%s",
                _c.get("instrument_name"), _c.get("dte_days", float("nan")), _c.get("mark_usd", 0),
                _c.get("vega_approx", "n/a"), _c.get("source", "?"),
            )

    best_score = -1.0
    best_candidate = None
    best_qty = 1
    _t0_rejections = {
        "no_mark_usd": 0, "sim_error": 0, "mm_breach": 0, "vega_below_threshold": 0,
        "no_vega_data": 0, "delta_side_effect_too_large": 0, "net_benefit_too_low": 0,
    }

    for cand in candidates:
        mark_usd = float(cand.get("mark_usd") or 0.0)
        if mark_usd <= 0:
            _t0_rejections["no_mark_usd"] += 1
            continue

        try:
            recent_trades = deribit.get_last_trades_by_instrument(
                instrument_name=cand["instrument_name"], count=trade_count
            )
        except Exception:
            recent_trades = []

        matched_pos = next(
            (p for p in positions if p.instrument_name == cand["instrument_name"]), None
        )
        # Estimate vega/delta per contract:
        #   Phase 1 fix - use chain greeks (vega_approx, delta_signed) for non-position candidates.
        if matched_pos is not None:
            inst_vega  = abs(float(getattr(matched_pos, "vega",  0.0) or 0.0)) or (mark_usd * 0.01)
            inst_delta = float(getattr(matched_pos, "delta", 0.0) or 0.0)
        else:
            # Prefer chain-sourced vega; fall back to ~1% of USD premium as approximation
            inst_vega  = float(cand.get("vega_approx") or 0.0) or (mark_usd * 0.01)
            # Use signed delta from chain data; fall back to negating abs for puts
            _ds = cand.get("delta_signed")
            inst_delta = float(_ds) if _ds is not None else -abs(cand.get("delta_approx", 0.25))

        # Sizing: enough contracts to close vega gap, capped by budget
        if inst_vega > 0:
            qty_needed = max(1, int(vega_gap / inst_vega + 0.5))
        else:
            qty_needed = 1
        qty = max(1, min(10, qty_needed, int(budget_usd / mark_usd) if mark_usd > 0 else 1))

        score = score_for_vega(
            greek_profile=adj_profile,
            targets=targets,
            instrument_vega=inst_vega,
            instrument_delta=inst_delta,
            instrument_mark_usd=mark_usd,
            instrument_margin_usd=mark_usd,
            qty=float(qty),
            direction="buy",
            recent_trades=recent_trades,
            recency_window_s=recency_s,
        )
        if score > best_score:
            best_score = score
            best_candidate = cand
            best_qty = qty

    if best_candidate:
        action = CandidateAction(
            action_type=ActionType.HEDGE_VEGA,
            instrument_name=best_candidate["instrument_name"],
            side=Side.BUY,
            qty_contracts=best_qty,
        )
        try:
            sim = simulate_action_impact(deribit, snapshot, action, "BTC")
        except Exception as exc:
            logger.warning("vega Tier 0 simulation error: %s", exc)
            _t0_rejections["sim_error"] += 1
            sim = {}

        post_mm = float(sim.get("mm_pct_after") or adj_profile.mm_pct)
        post_vega_sim = float(sim.get("vega_after") or adj_vega)
        if post_mm < mm_critical and sim.get("vega_after") is not None:
            classification = _classify_vega_action(adj_vega, post_vega_sim, adj_profile.mm_pct, post_mm, cfg)
            if classification == "fallback_last_resort":
                _t0_rejections["vega_below_threshold"] += 1
                tier0_rejection = (
                    f"Tier 0 rejected: vega improvement too weak "
                    f"({abs(post_vega_sim - adj_vega):.2f} / {abs(adj_vega):.2f})"
                )
                logger.info("vega %s | loop rejections: %s", tier0_rejection, _t0_rejections)
            else:
                # Fix C: Delta side-effect cap
                delta_after      = float(sim.get("delta_after") or adj_profile.delta_btc)
                delta_impact_abs = abs(delta_after - adj_profile.delta_btc)
                max_delta_side   = _get_vega_delta_side_effect_cap(mode_str, cfg)
                if delta_impact_abs > max_delta_side:
                    _t0_rejections["delta_side_effect_too_large"] += 1
                    logger.info(
                        "vega Tier0: delta side-effect %.4f > cap %.4f (%s), rejecting %s",
                        delta_impact_abs, max_delta_side, mode_str,
                        best_candidate["instrument_name"],
                    )
                    tier0_rejection = (
                        f"Tier 0 rejected: delta side-effect {delta_impact_abs:.4f} > "
                        f"cap {max_delta_side:.2f} ({mode_str})"
                    )
                    logger.info("vega %s | loop rejections: %s", tier0_rejection, _t0_rejections)
                else:
                    # Fix E: Net-benefit filter
                    delta_band_half = (targets.delta_band_max - targets.delta_band_min) / 2.0
                    delta_penalty   = delta_impact_abs / max(delta_band_half, 1e-9)
                    pre_dist        = abs(targets.vega_target - adj_vega)
                    post_dist       = abs(targets.vega_target - post_vega_sim)
                    greek_impr      = max(0.0, (pre_dist - post_dist) / max(pre_dist, 1e-9))
                    net_ben         = greek_impr / max(delta_penalty, 1e-9)
                    net_ben_min     = float(getattr(cfg, "NET_BENEFIT_MIN_RATIO", 0.5))
                    if net_ben < net_ben_min:
                        _t0_rejections["net_benefit_too_low"] += 1
                        logger.info(
                            "vega Tier0: net_benefit %.2f < %.2f, rejecting %s",
                            net_ben, net_ben_min, best_candidate["instrument_name"],
                        )
                        tier0_rejection = (
                            f"Tier 0 rejected: net_benefit {net_ben:.2f} < {net_ben_min:.2f}"
                        )
                        logger.info("vega %s | loop rejections: %s", tier0_rejection, _t0_rejections)
                    else:
                        classification_note = f" [{classification.upper()}]" if classification == "mm_relief" else ""
                        return _build_vega_suggestion(
                            method="buy_option",
                            instrument=best_candidate["instrument_name"],
                            size=float(best_qty),
                            direction="buy",
                            sim=sim,
                            greek_profile=adj_profile,
                            fallback_tier=0,
                            rationale=(
                                f"Tier 0: buy {best_qty}x {best_candidate['instrument_name']} "
                                f"(score={best_score:.2f}, DTE={best_candidate.get('dte_days', '?')}){classification_note}"
                            ),
                            risk_note=f"post_MM={post_mm:.1f}%, vega_gap_closed={abs(vega_gap):.2f}",
                            action_classification=classification,
                            target_reached=post_vega_sim >= targets.vega_target,
                        )
        else:
            _t0_rejections["mm_breach"] += 1
            tier0_rejection = f"Tier 0 rejected: post_MM={post_mm:.1f}% >= {mm_critical}%"
            logger.info("vega %s | loop rejections: %s", tier0_rejection, _t0_rejections)
    else:
        tier0_rejection = "Tier 0: no valid candidates found"
        logger.info("vega %s | loop rejections: %s", tier0_rejection, _t0_rejections)

    # -----------------------------------------------------------------------
    # TIER 1: Sell OTM call (30-60 DTE) to free MM capacity
    # -----------------------------------------------------------------------
    sell_candidates = get_candidates(
        snapshot=snapshot,
        con=con,
        option_type="C",
        min_dte=30,
        max_dte=60,
        delta_target=0.10,
        max_results=5,
    )

    logger.info(
        "vega Tier1: %d sell candidates (DTE 30-60, C)",
        len(sell_candidates),
    )
    _t1_rejections = {
        "no_mark_usd": 0, "sim_error": 0, "mm_breach": 0, "vega_no_improve": 0,
        "delta_side_effect_too_large": 0, "net_benefit_too_low": 0,
    }

    for cand in sell_candidates:
        mark_usd = float(cand.get("mark_usd") or 0.0)
        if mark_usd <= 0:
            _t1_rejections["no_mark_usd"] += 1
            continue

        book_exposure = sum(
            abs(float(p.vega or 0.0))
            for p in positions
            if p.kind == "option" and p.option_type == "C" and float(p.size or 0) < 0
        )
        max_qty = max(1, int(book_exposure * sell_cap_pct / (abs(mark_usd * 0.01) + 1e-9)))
        max_qty = min(max_qty, 10)

        action = CandidateAction(
            action_type=ActionType.HEDGE_VEGA,
            instrument_name=cand["instrument_name"],
            side=Side.SELL,
            qty_contracts=max_qty,
        )
        try:
            sim = simulate_action_impact(deribit, snapshot, action, "BTC")
        except Exception as exc:
            logger.warning("vega Tier 1 simulation error: %s", exc)
            _t1_rejections["sim_error"] += 1
            continue

        post_mm   = float(sim.get("mm_pct_after") or adj_profile.mm_pct)
        post_vega = float(sim.get("vega_after")   or adj_profile.vega)
        vega_improves = abs(post_vega - targets.vega_target) < abs(adj_vega - targets.vega_target)

        if post_mm >= mm_critical:
            _t1_rejections["mm_breach"] += 1
        elif not vega_improves:
            _t1_rejections["vega_no_improve"] += 1
        if post_mm < mm_critical and vega_improves:
            # Fix C: Delta side-effect cap
            delta_after      = float(sim.get("delta_after") or adj_profile.delta_btc)
            delta_impact_abs = abs(delta_after - adj_profile.delta_btc)
            max_delta_side   = _get_vega_delta_side_effect_cap(mode_str, cfg)
            if delta_impact_abs > max_delta_side:
                _t1_rejections["delta_side_effect_too_large"] += 1
                logger.info(
                    "vega Tier1: delta side-effect %.4f > cap %.4f (%s), skipping %s",
                    delta_impact_abs, max_delta_side, mode_str, cand["instrument_name"],
                )
                continue
            # Fix E: Net-benefit filter
            delta_band_half = (targets.delta_band_max - targets.delta_band_min) / 2.0
            delta_penalty   = delta_impact_abs / max(delta_band_half, 1e-9)
            pre_dist        = abs(targets.vega_target - adj_vega)
            post_dist       = abs(targets.vega_target - post_vega)
            greek_impr      = max(0.0, (pre_dist - post_dist) / max(pre_dist, 1e-9))
            net_ben         = greek_impr / max(delta_penalty, 1e-9)
            net_ben_min     = float(getattr(cfg, "NET_BENEFIT_MIN_RATIO", 0.5))
            if net_ben < net_ben_min:
                _t1_rejections["net_benefit_too_low"] += 1
                logger.info(
                    "vega Tier1: net_benefit %.2f < %.2f, skipping %s",
                    net_ben, net_ben_min, cand["instrument_name"],
                )
                continue
            classification = _classify_vega_action(adj_vega, post_vega, adj_profile.mm_pct, post_mm, cfg)
            return _build_vega_suggestion(
                method="sell_option",
                instrument=cand["instrument_name"],
                size=float(max_qty),
                direction="sell",
                sim=sim,
                greek_profile=adj_profile,
                fallback_tier=1,
                rationale=(
                    f"Tier 1 (sell call): sell {max_qty}x {cand['instrument_name']} "
                    f"to free MM capacity. Prior: {tier0_rejection}"
                ),
                risk_note="New short call exposure added. Monitor gamma balance.",
                target_reached=post_vega >= targets.vega_target,
                action_classification=classification,
            )

    tier1_rejection = "Tier 1: no valid sell-call candidate"
    logger.info("vega %s | loop rejections: %s", tier1_rejection, _t1_rejections)

    # -----------------------------------------------------------------------
    # TIER 2: Close existing short put
    # -----------------------------------------------------------------------
    # Fix D: Suppress Tier 2 in calm state unless breach is severe.
    if is_calm and v_breach_severity != "severe":
        logger.info(
            "vega Tier2: suppressed in calm state "
            "(MM=%.1f%%, DD=%.1f%%, severity=%s). Falling through to no-action.",
            mm_pct, dd_abs * 100, v_breach_severity,
        )
        offenders = []
    else:
        try:
            offenders = rank_position_offenders(positions, snapshot, None, cfg)
        except Exception:
            offenders = []

    # Exclude instrument already proposed by gamma engine (avoid duplicate closes)
    gamma_instrument = (
        gamma_suggestion.instrument
        if gamma_suggestion and gamma_suggestion.method != "no_action"
        else None
    )
    vega_offenders = [
        o for o in offenders
        if o.components.get("vega", 0.0) > 0.0
        and o.instrument_name != gamma_instrument
    ][:max_closes]

    for offender in vega_offenders:
        matched_pos = next(
            (p for p in positions if p.instrument_name == offender.instrument_name), None
        )
        if matched_pos is None or float(matched_pos.size or 0) >= 0:
            continue

        close_qty = max(1, abs(int(matched_pos.size or 0)))
        action = CandidateAction(
            action_type=ActionType.REDUCE_POS,
            instrument_name=offender.instrument_name,
            side=Side.BUY,
            qty_contracts=close_qty,
        )
        try:
            sim = simulate_action_impact(deribit, snapshot, action, "BTC")
        except Exception as exc:
            logger.warning("vega Tier 2 simulation error: %s", exc)
            continue

        post_mm   = float(sim.get("mm_pct_after") or adj_profile.mm_pct)
        post_vega = float(sim.get("vega_after")   or adj_profile.vega)

        if post_vega >= targets.vega_target or post_mm < mm_critical:
            mm_improvement = adj_profile.mm_pct - post_mm
            vega_ratio = abs(post_vega - adj_vega) / max(abs(adj_vega), 1e-9)
            # Tier 2 minimum quality floor: reject if near-zero vega AND tiny MM improvement
            if vega_ratio < 0.01 and mm_improvement < 2.0:
                logger.info(
                    "vega Tier 2 skipped: near-zero vega improvement %.4f%% and MM improvement %.2fpp < 2pp",
                    vega_ratio * 100, mm_improvement,
                )
                continue
            # Fix C: Delta side-effect cap - close-shorts can create large positive delta
            delta_after      = float(sim.get("delta_after") or adj_profile.delta_btc)
            delta_impact_abs = abs(delta_after - adj_profile.delta_btc)
            max_delta_side   = _get_vega_delta_side_effect_cap(mode_str, cfg)
            if delta_impact_abs > max_delta_side:
                logger.info(
                    "vega Tier2: delta side-effect %.4f > cap %.4f (%s), skipping %s",
                    delta_impact_abs, max_delta_side, mode_str, offender.instrument_name,
                )
                continue
            return _build_vega_suggestion(
                method="close_existing",
                instrument=offender.instrument_name,
                size=float(close_qty),
                direction="buy",
                sim=sim,
                greek_profile=adj_profile,
                fallback_tier=2,
                rationale=(
                    f"Tier 2 (close existing): bought back {close_qty}x {offender.instrument_name} "
                    f"(score={offender.total_score:.2f}). Prior: {tier0_rejection}; {tier1_rejection}"
                ),
                risk_note="Bought back short position to relieve vega pressure. Reconsider re-opening at safer DTE/strike.",
                action_classification="fallback_last_resort",
                target_reached=post_vega >= targets.vega_target,
            )

    # -----------------------------------------------------------------------
    # ALL TIERS FAILED
    # -----------------------------------------------------------------------
    logger.warning(
        "vega all tiers failed: %s; %s; tier2 also exhausted",
        tier0_rejection, tier1_rejection,
    )
    return Suggestion(
        engine="vega", method="no_action", instrument="", size=0.0, direction="none",
        delta_impact=0.0, gamma_impact=0.0, vega_impact=0.0,
        post_mm_pct=adj_profile.mm_pct, post_dd_est=0.0,
        post_delta=adj_profile.delta_btc, post_gamma=adj_profile.gamma,
        post_vega=adj_profile.vega,
        fallback_used=True, fallback_tier=2,
        rationale=f"All tiers failed: {tier0_rejection}; {tier1_rejection}; Tier 2 exhausted",
        risk_note="Manual intervention required. Vega exposure unhedged.",
        simulation_ok=False,
        target_reached=False,
        action_classification="fallback_last_resort",
    )
