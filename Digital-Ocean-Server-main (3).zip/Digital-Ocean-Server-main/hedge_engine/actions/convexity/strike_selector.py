# hedge_engine/actions/convexity/strike_selector.py
from __future__ import annotations

import json
import sqlite3
from datetime import datetime, timezone
from typing import Any, Dict, List

from hedge_engine.core.models import Position, PortfolioSnapshot


def get_candidates_from_positions(
    positions: List[Position],
    option_type: str,       # "C" or "P"
    min_dte: int,
    max_dte: int,
    delta_target: float,
) -> List[Position]:
    """
    Filter existing positions by option_type, DTE range.
    Sort by proximity to delta_target (closest first).
    """
    filtered = [
        p for p in positions
        if p.kind == "option"
        and p.option_type == option_type
        and p.dte_days is not None
        and min_dte <= p.dte_days <= max_dte
    ]
    return sorted(filtered, key=lambda p: abs((p.delta or 0.0) - delta_target))


def _parse_instrument(name: str):
    """
    Parse Deribit instrument name BTC-DDMMMYY-STRIKE-C/P.
    Returns (strike, option_type, None) or (None, None, None) on failure.
    """
    try:
        parts = name.split("-")
        if len(parts) == 4:
            strike = float(parts[2])
            opt_type = parts[3].upper()
            return strike, opt_type, None
    except Exception:
        pass
    return None, None, None


def get_candidates_from_chain(
    con: sqlite3.Connection,
    option_type: str,
    min_dte: int,
    max_dte: int,
    spot: float,
    delta_target: float,
) -> List[Dict[str, Any]]:
    """
    Read the latest hedge_engine_book_summaries_ticks row and return
    matching option candidates sorted by proximity to delta_target.
    """
    try:
        info = con.execute(
            "PRAGMA table_info(hedge_engine_book_summaries_ticks)"
        ).fetchall()
        cols = {row[1] for row in info} if info else set()
        payload_col = (
            "COALESCE(payload_json, tick_json)"
            if "tick_json" in cols
            else "payload_json"
        )
        row = con.execute(
            f"SELECT {payload_col} AS payload_json "
            "FROM hedge_engine_book_summaries_ticks "
            "ORDER BY ts_utc DESC LIMIT 1"
        ).fetchone()
        if not row:
            return []
        data = json.loads(row[0])
        if isinstance(data, list):
            items = data
        elif isinstance(data, dict):
            if "options_summaries" in data:
                items = data.get("options_summaries", [])
            else:
                items = data.get("result", [])
        else:
            items = []
    except Exception:
        return []

    results = []
    for item in items:
        name = item.get("instrument_name", "")
        strike, opt_t, _ = _parse_instrument(name)
        if strike is None or opt_t != option_type:
            continue

        dte = item.get("dte_days") or item.get("days_to_expiry")
        if dte is None:
            # Deribit book summary provides expiration_timestamp (ms epoch) but not dte_days
            exp_ms = item.get("expiration_timestamp")
            if exp_ms:
                try:
                    exp_dt = datetime.fromtimestamp(float(exp_ms) / 1000.0, tz=timezone.utc)
                    now_utc = datetime.now(tz=timezone.utc)
                    dte = (exp_dt - now_utc).total_seconds() / 86400.0
                except Exception:
                    pass
        if dte is None:
            continue
        dte = float(dte)
        if not (min_dte <= dte <= max_dte):
            continue

        mark_price_raw = float(item.get("mark_price", 0) or 0)
        mark_usd = mark_price_raw * spot   # Deribit mark_price is in BTC for BTC options

        greeks = item.get("greeks") or {}
        delta_approx = abs(float(greeks.get("delta", 0) or 0))
        delta_signed = float(greeks.get("delta", 0) or 0)          # signed delta (negative for puts)
        gamma_approx = abs(float(greeks.get("gamma", 0) or 0))     # per-contract gamma, positive
        vega_approx  = abs(float(greeks.get("vega",  0) or 0))     # per-contract vega, positive

        results.append({
            "instrument_name": name,
            "strike": strike,
            "option_type": opt_t,
            "dte_days": dte,
            "mark_usd": mark_usd,
            "delta_approx": delta_approx,
            "delta_signed":  delta_signed,
            "gamma_approx":  gamma_approx,
            "vega_approx":   vega_approx,
            "delta_distance": abs(delta_approx - abs(delta_target)),
        })

    return sorted(results, key=lambda x: x["delta_distance"])


def get_candidates(
    snapshot: PortfolioSnapshot,
    con: sqlite3.Connection,
    option_type: str,
    min_dte: int,
    max_dte: int,
    delta_target: float,
    max_results: int = 5,
) -> List[Dict[str, Any]]:
    """
    Try existing positions first. If fewer than 2 match, fallback to chain.
    Returns up to max_results candidates as dicts with a "source" key.
    """
    from_pos = get_candidates_from_positions(
        snapshot.positions, option_type, min_dte, max_dte, delta_target
    )
    if len(from_pos) >= 2:
        return [
            {
                "instrument_name": p.instrument_name,
                "strike": p.strike,
                "option_type": p.option_type,
                "dte_days": p.dte_days,
                "mark_usd": p.mark_price_usd or 0.0,
                "delta_approx": abs(float(p.delta or 0.0)),
                "delta_signed":  float(p.delta or 0.0),
                "gamma_approx":  abs(float(p.gamma or 0.0)),
                "vega_approx":   abs(float(p.vega  or 0.0)),
                "source": "positions",
            }
            for p in from_pos[:max_results]
        ]

    from_chain = get_candidates_from_chain(
        con, option_type, min_dte, max_dte, snapshot.spot_index_usd, delta_target
    )
    return [{**c, "source": "chain"} for c in from_chain[:max_results]]
