from __future__ import annotations

import logging
import sqlite3
from dataclasses import asdict
from typing import Any, Dict, List, Optional, Tuple

from hedge_engine.settings.config import EngineConfig
from hedge_engine.core.models import (
    PortfolioSnapshot, CandidateAction, Position,
    GreekProfile, GreekTargets, Suggestion,
)
from hedge_engine.risk.risk_checks import RiskFlags
from hedge_engine.core.enums import ActionType, Side

logger = logging.getLogger(__name__)

def _detect_worst_stress_direction(snapshot: PortfolioSnapshot) -> str:
    """
    Reads snapshot.stress (from stress_runner output).
    Returns: "down" | "up" | "unknown"
    """
    stress = getattr(snapshot, "stress_artifact", None) or getattr(snapshot, "stress", None)
    if not stress:
        return "unknown"

    scenarios = stress.get("scenarios") or {}
    worst_dd = 0.0
    worst_dir = "unknown"

    for name, s in scenarios.items():
        dd = s.get("projected_dd_worst")
        shock = float(s.get("spot_shock_pct", 0.0))

        if dd is None:
            continue

        if dd < worst_dd:
            worst_dd = dd
            worst_dir = "down" if shock < 0 else "up"

    return worst_dir


def _check_forward_risk(snapshot: PortfolioSnapshot, cfg: EngineConfig) -> bool:
    """
    Returns True if stress scenarios show dangerous forward convexity risk,
    even when static gamma is above the gamma target.
    Reads projected_dd_worst from stress artifact scenarios.
    """
    stress = getattr(snapshot, "stress_artifact", None) or getattr(snapshot, "stress", None)
    if not stress:
        return False

    threshold = float(getattr(cfg, "GAMMA_FORWARD_RISK_DD_THRESHOLD", -0.04))

    # Check fast stress scenarios first (always available)
    fast = stress.get("fast") or {}
    fast_scenarios = fast.get("scenarios") or {}
    for name, s in fast_scenarios.items():
        projected_dd = s.get("projected_dd_worst")
        if projected_dd is not None and float(projected_dd) <= threshold:
            return True

    # Also check top-level scenarios (deep stress if available)
    scenarios = stress.get("scenarios") or {}
    for name, s in scenarios.items():
        projected_dd = s.get("projected_dd_worst") or s.get("projected_dd")
        if projected_dd is not None and float(projected_dd) <= threshold:
            return True

    return False

def _is_triggered_for_gamma_hedge(*, flags: RiskFlags, snapshot: PortfolioSnapshot) -> bool:
    if bool(flags.gamma_budget_breach):
        return True
    if bool(flags.speed_trigger):
        return True
    if float(flags.dd_worst) <= -0.04 and float(snapshot.portfolio_gamma) < 0.0:
        return True
    return False


def _score_gamma_candidate(*, dte_days: float, approx_delta_abs: float) -> float:
    """
    Deterministic ranking score (higher is better).
    We prefer:
      - shorter DTE (more gamma impact)
      - ~10–20 delta puts (convex protection, not too expensive)
    """
    # DTE: 7 best, 14 worst in our allowed window
    dte_score = max(0.0, 1.0 - (dte_days - 7.0) / 7.0)

    # delta: target ~0.15 abs
    delta_target = 0.15
    delta_score = max(0.0, 1.0 - abs(approx_delta_abs - delta_target) / 0.10)

    return 0.6 * dte_score + 0.4 * delta_score


def propose_gamma_hedge(
    *,
    snapshot: PortfolioSnapshot,
    flags: RiskFlags,
    cfg: EngineConfig,
) -> List[CandidateAction]:
    """
    Deterministically propose 7–14 DTE PUT(s) as a gamma hedge.

    Notes:
    - This phase is candidate generation only (no X:PM sim, no final bundle).
    - Instrument selection uses what we already hold/see in snapshot positions.
      (We pick from existing PUT instruments in the positions list as an MVP.)
    - In Phase 6/7 we will replace/extend with instrument discovery + strike selection.
    """
    if not _is_triggered_for_gamma_hedge(flags=flags, snapshot=snapshot):
        return []

    direction = _detect_worst_stress_direction(snapshot)
    
    # Filter eligible PUT options in the snapshot universe
    eligible: List[Tuple[float, float, Position]] = []
    for p in snapshot.positions:
        if getattr(p, "kind", "") != "option":
            continue
        opt_type = getattr(p, "option_type", "").upper()

        if direction == "down" and opt_type != "P":
            continue
        if direction == "up" and opt_type != "C":
            continue
        if direction == "unknown":
            continue

        dte_days = float(getattr(p, "dte_days", 0.0))
        if dte_days <= 0:
            continue
        if dte_days < float(cfg.GAMMA_HEDGE_MIN_DTE_DAYS) or dte_days > float(cfg.GAMMA_HEDGE_MAX_DTE_DAYS):
            continue

        # Use per-position delta as a proxy (abs delta in BTC terms)
        pos_delta = float(getattr(p, "delta", 0.0))
        approx_delta_abs = abs(pos_delta)

        score = _score_gamma_candidate(dte_days=dte_days, approx_delta_abs=approx_delta_abs)
        eligible.append((score, dte_days, p))

    if not eligible:
        return []

    # Sort by score desc, then shorter DTE, then lower strike (more OTM) deterministically
    eligible.sort(
        key=lambda t: (
            -t[0],
            t[1],
            float(getattr(t[2], "strike", 0.0)),
            str(getattr(t[2], "instrument_name", "")),
        )
    )

    top_n = int(cfg.GAMMA_HEDGE_MAX_CANDIDATES)
    picks = eligible[: max(1, top_n)]

    # Deterministic small sizing cap (event budget)
    # We keep sizing conservative; Phase 6 sim will validate impact.
    notional_cap_usd = float(cfg.GAMMA_HEDGE_EVENT_BUDGET_USD)
    spot_usd = float(snapshot.spot_index_usd)

    actions: List[CandidateAction] = []
    remaining = notional_cap_usd

    for score, dte_days, p in picks:
        if remaining <= 0:
            break

        # Price proxy: use mark_price_usd if present else mark_price_btc * spot
        mark_usd = float(getattr(p, "mark_price_usd", 0.0))
        if mark_usd <= 0.0:
            mark_btc = float(getattr(p, "mark_price_btc", 0.0))
            if mark_btc > 0.0:
                mark_usd = mark_btc * spot_usd

        if mark_usd <= 0.0:
            continue

        # Contracts sizing: spend up to remaining; clamp by min/max contracts
        # If your Position uses "contract_size" / "multiplier", adapt here later.
        # For now assume 1 contract ~ 1 option with price mark_usd.
        max_contracts_by_budget = int(remaining // mark_usd)
        qty = max(int(cfg.GAMMA_HEDGE_MIN_CONTRACTS), min(int(cfg.GAMMA_HEDGE_MAX_CONTRACTS), max_contracts_by_budget))

        if qty <= 0:
            continue

        est_cost = qty * mark_usd
        remaining -= est_cost

        actions.append(
            CandidateAction(
                action_type=ActionType.HEDGE_GAMMA,
                instrument_name=str(getattr(p, "instrument_name", "")),
                side=Side.BUY,
                qty_contracts=qty,
                meta={
                    "reason": f"gamma_hedge_{direction}",
                    "trigger_flags": {
                        "gamma_budget_breach": bool(flags.gamma_budget_breach),
                        "speed_trigger": bool(flags.speed_trigger),
                        "dd_worst": float(flags.dd_worst),
                        "portfolio_gamma": float(snapshot.portfolio_gamma),
                    },
                    "selection": {
                        "score": float(score),
                        "dte_days": float(dte_days),
                        "strike": float(getattr(p, "strike", 0.0)),
                        "mark_usd": float(mark_usd),
                        "est_cost_usd": float(est_cost),
                    },
                    "budget": {
                        "event_budget_usd": float(notional_cap_usd),
                        "remaining_budget_usd": float(max(0.0, remaining)),
                    },
                },
            )
        )

    return actions


# ---------------------------------------------------------------------------
# DEPRECATED: propose_gamma_hedge() above - use run() for new pipeline
# ---------------------------------------------------------------------------

def _no_action_suggestion(rationale: str, risk_note: str = "") -> Suggestion:
    return Suggestion(
        engine="gamma", method="no_action", instrument="", size=0.0, direction="none",
        delta_impact=0.0, gamma_impact=0.0, vega_impact=0.0,
        post_mm_pct=0.0, post_dd_est=0.0, post_delta=0.0, post_gamma=0.0, post_vega=0.0,
        fallback_used=False, fallback_tier=0,
        rationale=rationale, risk_note=risk_note, simulation_ok=True,
    )


def _build_suggestion_from_sim(
    *,
    method: str,
    instrument: str,
    size: float,
    direction: str,
    sim: Dict[str, Any],
    greek_profile: GreekProfile,
    fallback_tier: int,
    rationale: str,
    risk_note: str,
    action_classification: str = "proper_hedge",
    target_reached: bool = True,
) -> Suggestion:
    """Build a Suggestion from a simulate_action_impact() result dict."""
    post_delta = float(sim.get("delta_after") or greek_profile.delta_btc)
    post_gamma = float(sim.get("gamma_after") or greek_profile.gamma)
    post_vega  = float(sim.get("vega_after")  or greek_profile.vega)
    post_mm    = float(sim.get("mm_pct_after") or greek_profile.mm_pct)
    sim_ok     = bool(sim.get("safe", False)) and sim.get("error") is None

    return Suggestion(
        engine="gamma",
        method=method,
        instrument=instrument,
        size=size,
        direction=direction,
        delta_impact=post_delta - greek_profile.delta_btc,
        gamma_impact=post_gamma - greek_profile.gamma,
        vega_impact=post_vega - greek_profile.vega,
        post_mm_pct=post_mm,
        post_dd_est=0.0,
        post_delta=post_delta,
        post_gamma=post_gamma,
        post_vega=post_vega,
        fallback_used=fallback_tier > 0,
        fallback_tier=fallback_tier,
        rationale=rationale,
        risk_note=risk_note,
        simulation_ok=sim_ok,
        action_classification=action_classification,
        target_reached=target_reached,
    )


def _classify_breach_severity(gap_pct: float, cfg: EngineConfig) -> str:
    """
    Classify breach severity from gap_pct = (target - current) / abs(target).
    Returns: 'none', 'mild', 'moderate', or 'severe'.
    gap_pct > 0 means we are below target.
    """
    if gap_pct <= 0.0:
        return "none"
    mild_max   = float(getattr(cfg, "MILD_BREACH_MAX_PCT",  0.25))
    severe_min = float(getattr(cfg, "SEVERE_BREACH_MIN_PCT", 0.75))
    if gap_pct < mild_max:
        return "mild"
    if gap_pct < severe_min:
        return "moderate"
    return "severe"


def _get_delta_side_effect_cap(mode: str, cfg: EngineConfig) -> float:
    """Per-mode BTC cap on the absolute delta side-effect from a gamma/vega hedge candidate."""
    m = (mode or "NORMAL").upper()
    if m == "NORMAL":
        return float(getattr(cfg, "DELTA_SIDE_EFFECT_CAP_NORMAL_BTC",    0.30))
    elif m == "DEFENSIVE":
        return float(getattr(cfg, "DELTA_SIDE_EFFECT_CAP_DEFENSIVE_BTC", 0.50))
    elif m == "DANGER":
        return float(getattr(cfg, "DELTA_SIDE_EFFECT_CAP_DANGER_BTC",    0.80))
    else:  # EMERGENCY
        return float(getattr(cfg, "DELTA_SIDE_EFFECT_CAP_EMERGENCY_BTC", 1.50))


def run(
    *,
    greek_profile: GreekProfile,
    targets: GreekTargets,
    positions: List[Position],
    snapshot: PortfolioSnapshot,
    cfg: EngineConfig,
    deribit: Any,
    con: sqlite3.Connection,
) -> Suggestion:
    """
    Gamma sub-engine: suggests one action to bring net_gamma above targets.gamma_target.

    Fallback chain:
      Tier 0 - buy 7–21 DTE option (highest gamma density)
      Tier 1 - sell OTM option on other side (if Tier 0 rejected due to MM%)
      Tier 2 - close existing short position (smallest close that achieves target)
      All fail - return Suggestion(simulation_ok=False)

    Each suggestion is simulated via Deribit /private/simulate_portfolio.
    """
    from hedge_engine.actions.convexity.strike_selector import get_candidates
    from hedge_engine.actions.instrument_scorer import score_for_gamma
    from hedge_engine.actions.position_management.risk_reduction import rank_position_offenders
    from hedge_engine.risk.xpm.xpm_simulator import simulate_action_impact

    # --- Trigger check with forward-risk awareness ---
    forward_risk_bad = _check_forward_risk(snapshot, cfg)

    if greek_profile.gamma >= targets.gamma_target and not forward_risk_bad:
        return _no_action_suggestion(
            rationale=f"gamma {greek_profile.gamma:.4f} >= target {targets.gamma_target:.4f}, no action needed",
        )

    if greek_profile.gamma >= targets.gamma_target and forward_risk_bad:
        # Gamma above static target but forward risk is dangerous - act proactively
        # Conservative sizing: 25% of target as buffer
        gamma_gap = abs(targets.gamma_target) * 0.25
        logger.info(
            "gamma forward-risk override: gamma %.4f >= target %.4f but stress is bad, "
            "proactive gap=%.4f",
            greek_profile.gamma, targets.gamma_target, gamma_gap,
        )
    else:
        gamma_gap = targets.gamma_target - greek_profile.gamma  # positive = how much we need to gain

    # --- Urgency gating (over-hedging prevention) ---
    mm_pct   = greek_profile.mm_pct
    dd_abs   = abs(float(getattr(greek_profile, "dd", 0.0)))
    mode_str = (targets.mode or "NORMAL").upper()
    is_calm  = (
        mm_pct < float(getattr(cfg, "CALM_MM_THRESHOLD", 65.0))
        and dd_abs < float(getattr(cfg, "CALM_DD_ABS_PCT", 0.04))
        and mode_str in {"NORMAL", "DEFENSIVE"}
    )
    # forward_risk override → always treat as severe (don't suppress proactive hedges)
    if forward_risk_bad:
        breach_pct      = 1.0
        breach_severity = "severe"
    else:
        breach_pct      = gamma_gap / max(abs(targets.gamma_target), 1e-9)
        breach_severity = _classify_breach_severity(breach_pct, cfg)

    # Fix B: Suppress mild breach in calm state
    if is_calm and breach_severity == "mild":
        logger.info(
            "gamma: mild breach suppressed in calm state "
            "(MM=%.1f%%, DD=%.1f%%, breach=%.0f%%)",
            mm_pct, dd_abs * 100, breach_pct * 100,
        )
        return _no_action_suggestion(
            rationale=(
                f"mild breach suppressed in calm state "
                f"(breach={breach_pct:.0%}, MM={mm_pct:.1f}%, DD={dd_abs*100:.1f}%)"
            ),
        )

    mm_critical = float(getattr(cfg, "mm_critical_pct", 80.0))
    sell_cap_pct = float(getattr(cfg, "TIER1_SELL_CAP_PCT", 0.30))
    max_closes   = int(getattr(cfg, "TIER2_MAX_CLOSES", 2))
    dte_max      = int(getattr(cfg, "GAMMA_HEDGE_DTE_MAX_EXPANDED", 21))
    dte_min      = int(getattr(cfg, "GAMMA_HEDGE_MIN_DTE_DAYS", 7))
    budget_usd   = float(getattr(cfg, "GAMMA_HEDGE_EVENT_BUDGET_USD", 500.0))
    trade_count  = int(getattr(cfg, "INSTRUMENT_SCORER_TRADE_COUNT", 20))
    recency_s    = int(getattr(cfg, "INSTRUMENT_SCORER_RECENCY_WINDOW_S", 300))
    spot         = float(snapshot.spot_index_usd or 1.0)

    # Determine preferred option type (puts for downside, calls for upside)
    direction = _detect_worst_stress_direction(snapshot)
    opt_type = "P" if direction != "up" else "C"

    # -----------------------------------------------------------------------
    # TIER 0: Buy gamma-dense option (7–21 DTE)
    # -----------------------------------------------------------------------
    candidates = get_candidates(
        snapshot=snapshot,
        con=con,
        option_type=opt_type,
        min_dte=dte_min,
        max_dte=dte_max,
        delta_target=0.15,
        max_results=5,
    )

    logger.info(
        "gamma Tier0: %d candidates (DTE %d-%d, type=%s, source=%s)",
        len(candidates), dte_min, dte_max, opt_type,
        ",".join({c.get("source", "?") for c in candidates}) if candidates else "none",
    )
    if candidates:
        for _c in candidates[:3]:
            logger.info(
                "  candidate: %s  DTE=%.1f  mark_usd=%.2f  gamma_approx=%s  source=%s",
                _c.get("instrument_name"), _c.get("dte_days", float("nan")), _c.get("mark_usd", 0),
                _c.get("gamma_approx", "n/a"), _c.get("source", "?"),
            )

    best_score = -1.0
    best_candidate = None
    best_qty = 1
    _t0_rejections = {
        "no_mark_usd": 0, "sim_error": 0, "mm_breach": 0, "no_gamma_data": 0,
        "delta_side_effect_too_large": 0, "net_benefit_too_low": 0,
    }

    for cand in candidates:
        mark_usd = float(cand.get("mark_usd") or 0.0)
        if mark_usd <= 0:
            _t0_rejections["no_mark_usd"] += 1
            continue

        # Fetch recent trades for liquidity scoring
        try:
            recent_trades = deribit.get_last_trades_by_instrument(
                instrument_name=cand["instrument_name"], count=trade_count
            )
        except Exception:
            recent_trades = []

        # Estimate gamma/delta per contract:
        #   Phase 1 fix - use chain greeks (gamma_approx, delta_signed) for non-position candidates
        #   so that Tier 0 is not always hard-rejected when matched_pos is None.
        matched_pos = next(
            (p for p in positions if p.instrument_name == cand["instrument_name"]), None
        )
        if matched_pos is not None:
            inst_gamma = abs(float(getattr(matched_pos, "gamma", 0.0) or 0.0))
            inst_delta = float(getattr(matched_pos, "delta", 0.0) or 0.0)
        else:
            inst_gamma = float(cand.get("gamma_approx") or 0.0)
            # Use signed delta from chain data; fall back to negating abs for puts
            _ds = cand.get("delta_signed")
            inst_delta = float(_ds) if _ds is not None else -abs(cand.get("delta_approx", 0.15))

        # Skip candidates with no usable gamma data - scorer would hard-reject anyway
        if inst_gamma <= 0:
            _t0_rejections["no_gamma_data"] += 1
            logger.debug(
                "gamma Tier0: skipping %s - no gamma data (source=%s, gamma_approx=%s)",
                cand.get("instrument_name"), cand.get("source", "?"),
                cand.get("gamma_approx"),
            )
            continue

        inst_margin = mark_usd  # conservative: 1x mark price as margin proxy

        # Size: enough to close gamma gap, capped by budget
        if inst_gamma > 0:
            qty_needed = max(1, int(gamma_gap / inst_gamma + 0.5))
        else:
            qty_needed = 1
        qty = max(1, min(int(cfg.GAMMA_HEDGE_MAX_CONTRACTS), qty_needed,
                         int(budget_usd / mark_usd) if mark_usd > 0 else 1))

        score = score_for_gamma(
            greek_profile=greek_profile,
            targets=targets,
            instrument_gamma=inst_gamma,
            instrument_delta=inst_delta,
            instrument_mark_usd=mark_usd,
            instrument_margin_usd=inst_margin,
            qty=float(qty),
            direction="buy",
            recent_trades=recent_trades,
            recency_window_s=recency_s,
        )
        if score > best_score:
            best_score = score
            best_candidate = cand
            best_qty = qty

    if best_candidate:
        action = CandidateAction(
            action_type=ActionType.HEDGE_GAMMA,
            instrument_name=best_candidate["instrument_name"],
            side=Side.BUY,
            qty_contracts=best_qty,
        )
        try:
            sim = simulate_action_impact(deribit, snapshot, action, "BTC")
        except Exception as exc:
            logger.warning("gamma Tier 0 simulation error: %s", exc)
            _t0_rejections["sim_error"] += 1
            sim = {}

        post_mm = float(sim.get("mm_pct_after") or greek_profile.mm_pct)
        if post_mm < mm_critical and sim.get("gamma_after") is not None:
            # Fix C: Delta side-effect cap
            delta_after      = float(sim.get("delta_after") or greek_profile.delta_btc)
            delta_impact_abs = abs(delta_after - greek_profile.delta_btc)
            max_delta_side   = _get_delta_side_effect_cap(mode_str, cfg)
            if delta_impact_abs > max_delta_side:
                _t0_rejections["delta_side_effect_too_large"] += 1
                logger.info(
                    "gamma Tier0: delta side-effect %.4f > cap %.4f (%s), rejecting %s",
                    delta_impact_abs, max_delta_side, mode_str,
                    best_candidate["instrument_name"],
                )
            else:
                # Fix E: Net-benefit filter
                delta_band_half = (targets.delta_band_max - targets.delta_band_min) / 2.0
                delta_penalty   = delta_impact_abs / max(delta_band_half, 1e-9)
                pre_dist        = abs(targets.gamma_target - greek_profile.gamma)
                post_gamma_val  = float(sim.get("gamma_after") or greek_profile.gamma)
                post_dist       = abs(targets.gamma_target - post_gamma_val)
                greek_impr      = max(0.0, (pre_dist - post_dist) / max(pre_dist, 1e-9))
                net_ben         = greek_impr / max(delta_penalty, 1e-9)
                net_ben_min     = float(getattr(cfg, "NET_BENEFIT_MIN_RATIO", 0.5))
                if net_ben < net_ben_min:
                    _t0_rejections["net_benefit_too_low"] += 1
                    logger.info(
                        "gamma Tier0: net_benefit %.2f < %.2f, rejecting %s",
                        net_ben, net_ben_min, best_candidate["instrument_name"],
                    )
                else:
                    return _build_suggestion_from_sim(
                        method="buy_option",
                        instrument=best_candidate["instrument_name"],
                        size=float(best_qty),
                        direction="buy",
                        sim=sim,
                        greek_profile=greek_profile,
                        fallback_tier=0,
                        rationale=(
                            f"Tier 0: buy {best_qty}x {best_candidate['instrument_name']} "
                            f"(score={best_score:.2f}, DTE={best_candidate.get('dte_days', '?')})"
                        ),
                        risk_note=f"post_MM={post_mm:.1f}%, gamma_gap_closed={abs(gamma_gap):.4f}",
                        target_reached=post_gamma_val >= targets.gamma_target,
                    )
            tier0_rejection = (
                f"Tier 0 rejected: delta/net-benefit filter "
                f"(delta_impact={delta_impact_abs:.4f})"
            )
        else:
            _t0_rejections["mm_breach"] += 1
            tier0_rejection = f"Tier 0 rejected: post_MM={post_mm:.1f}% >= {mm_critical}%"
        logger.info("gamma %s | loop rejections: %s", tier0_rejection, _t0_rejections)
    else:
        tier0_rejection = "Tier 0: no valid candidates found"
        logger.info("gamma %s | loop rejections: %s", tier0_rejection, _t0_rejections)

    # -----------------------------------------------------------------------
    # TIER 1: Sell OTM option on other side (to reduce MM usage)
    # -----------------------------------------------------------------------
    other_type = "C" if opt_type == "P" else "P"
    sell_candidates = get_candidates(
        snapshot=snapshot,
        con=con,
        option_type=other_type,
        min_dte=dte_min,
        max_dte=dte_max,
        delta_target=0.10,  # OTM
        max_results=5,
    )

    logger.info(
        "gamma Tier1: %d sell candidates (DTE %d-%d, type=%s)",
        len(sell_candidates), dte_min, dte_max, other_type,
    )
    _t1_rejections = {
        "no_mark_usd": 0, "sim_error": 0, "mm_breach": 0, "gamma_no_improve": 0,
        "delta_side_effect_too_large": 0, "net_benefit_too_low": 0,
    }

    for cand in sell_candidates:
        mark_usd = float(cand.get("mark_usd") or 0.0)
        if mark_usd <= 0:
            _t1_rejections["no_mark_usd"] += 1
            continue

        # Hard cap: size <= 30% of current book greek exposure from other_type options
        book_exposure = sum(
            abs(float(p.gamma or 0.0))
            for p in positions
            if p.kind == "option" and p.option_type == other_type and float(p.size or 0) < 0
        )
        max_qty = max(1, int(book_exposure * sell_cap_pct))

        action = CandidateAction(
            action_type=ActionType.HEDGE_GAMMA,
            instrument_name=cand["instrument_name"],
            side=Side.SELL,
            qty_contracts=max_qty,
        )
        try:
            sim = simulate_action_impact(deribit, snapshot, action, "BTC")
        except Exception as exc:
            logger.warning("gamma Tier 1 simulation error: %s", exc)
            _t1_rejections["sim_error"] += 1
            continue

        post_mm = float(sim.get("mm_pct_after") or greek_profile.mm_pct)
        post_gamma = float(sim.get("gamma_after") or greek_profile.gamma)
        # Must: (1) pass MM check, (2) gamma is MORE balanced (closer to target) than pre-trade
        gamma_improves = abs(post_gamma - targets.gamma_target) < abs(greek_profile.gamma - targets.gamma_target)
        if post_mm >= mm_critical:
            _t1_rejections["mm_breach"] += 1
        elif not gamma_improves:
            _t1_rejections["gamma_no_improve"] += 1
        if post_mm < mm_critical and gamma_improves:
            # Fix C: Delta side-effect cap
            delta_after      = float(sim.get("delta_after") or greek_profile.delta_btc)
            delta_impact_abs = abs(delta_after - greek_profile.delta_btc)
            max_delta_side   = _get_delta_side_effect_cap(mode_str, cfg)
            if delta_impact_abs > max_delta_side:
                _t1_rejections["delta_side_effect_too_large"] += 1
                logger.info(
                    "gamma Tier1: delta side-effect %.4f > cap %.4f (%s), skipping %s",
                    delta_impact_abs, max_delta_side, mode_str, cand["instrument_name"],
                )
                continue
            # Fix E: Net-benefit filter
            delta_band_half = (targets.delta_band_max - targets.delta_band_min) / 2.0
            delta_penalty   = delta_impact_abs / max(delta_band_half, 1e-9)
            pre_dist        = abs(targets.gamma_target - greek_profile.gamma)
            post_gamma_val  = float(sim.get("gamma_after") or greek_profile.gamma)
            post_dist       = abs(targets.gamma_target - post_gamma_val)
            greek_impr      = max(0.0, (pre_dist - post_dist) / max(pre_dist, 1e-9))
            net_ben         = greek_impr / max(delta_penalty, 1e-9)
            net_ben_min     = float(getattr(cfg, "NET_BENEFIT_MIN_RATIO", 0.5))
            if net_ben < net_ben_min:
                _t1_rejections["net_benefit_too_low"] += 1
                logger.info(
                    "gamma Tier1: net_benefit %.2f < %.2f, skipping %s",
                    net_ben, net_ben_min, cand["instrument_name"],
                )
                continue
            mm_improved = post_mm < greek_profile.mm_pct - 1.0  # lower is better; ≥1pp improvement
            t1_classification = "mm_relief" if mm_improved else "partial_hedge"
            return _build_suggestion_from_sim(
                method="sell_option",
                instrument=cand["instrument_name"],
                size=float(max_qty),
                direction="sell",
                sim=sim,
                greek_profile=greek_profile,
                fallback_tier=1,
                rationale=(
                    f"Tier 1 (sell other side): sell {max_qty}x {cand['instrument_name']} "
                    f"to free MM capacity. Prior: {tier0_rejection}"
                ),
                risk_note=(
                    f"post_MM={post_mm:.1f}%, new short {other_type} exposure added. "
                    f"Monitor carefully."
                ),
                action_classification=t1_classification,
                target_reached=post_gamma_val >= targets.gamma_target,
            )

    tier1_rejection = "Tier 1: no valid sell-other-side candidate"
    logger.info("gamma %s | loop rejections: %s", tier1_rejection, _t1_rejections)

    # -----------------------------------------------------------------------
    # TIER 2: Close existing short position (smallest close to achieve target)
    # -----------------------------------------------------------------------
    # Fix D: Suppress Tier 2 in calm state unless breach is severe.
    # Close-short actions have the highest delta side-effects and must be restricted
    # to states where the breach justifies the disruption.
    if is_calm and breach_severity != "severe":
        logger.info(
            "gamma Tier2: suppressed in calm state "
            "(MM=%.1f%%, DD=%.1f%%, severity=%s). Falling through to no-action.",
            mm_pct, dd_abs * 100, breach_severity,
        )
        offenders = []
    else:
        try:
            offenders = rank_position_offenders(positions, snapshot, None, cfg)
        except Exception:
            offenders = []

    # Filter to options with meaningful gamma contribution
    gamma_offenders = [
        o for o in offenders
        if o.components.get("gamma", 0.0) > 0.0
    ][:max_closes]

    for offender in gamma_offenders:
        matched_pos = next(
            (p for p in positions if p.instrument_name == offender.instrument_name), None
        )
        if matched_pos is None or float(matched_pos.size or 0) >= 0:
            continue  # only short positions

        close_qty = max(1, abs(int(matched_pos.size or 0)))
        action = CandidateAction(
            action_type=ActionType.REDUCE_POS,
            instrument_name=offender.instrument_name,
            side=Side.BUY,  # buy back to close short
            qty_contracts=close_qty,
        )
        try:
            sim = simulate_action_impact(deribit, snapshot, action, "BTC")
        except Exception as exc:
            logger.warning("gamma Tier 2 simulation error: %s", exc)
            continue

        post_mm = float(sim.get("mm_pct_after") or greek_profile.mm_pct)
        post_gamma = float(sim.get("gamma_after") or greek_profile.gamma)
        if post_gamma >= targets.gamma_target or post_mm < mm_critical:
            # Fix C: Delta side-effect cap - close-shorts can create large positive delta
            delta_after      = float(sim.get("delta_after") or greek_profile.delta_btc)
            delta_impact_abs = abs(delta_after - greek_profile.delta_btc)
            max_delta_side   = _get_delta_side_effect_cap(mode_str, cfg)
            if delta_impact_abs > max_delta_side:
                logger.info(
                    "gamma Tier2: delta side-effect %.4f > cap %.4f (%s), skipping %s",
                    delta_impact_abs, max_delta_side, mode_str, offender.instrument_name,
                )
                continue
            return _build_suggestion_from_sim(
                method="close_existing",
                instrument=offender.instrument_name,
                size=float(close_qty),
                direction="buy",
                sim=sim,
                greek_profile=greek_profile,
                fallback_tier=2,
                rationale=(
                    f"Tier 2 (close existing): bought back {close_qty}x {offender.instrument_name} "
                    f"(offender_score={offender.total_score:.2f}). "
                    f"Prior: {tier0_rejection}; {tier1_rejection}"
                ),
                risk_note=(
                    f"Bought back short position to relieve gamma pressure. "
                    f"Reconsider re-opening at safer DTE/strike."
                ),
                action_classification="fallback_last_resort",
                target_reached=post_gamma >= targets.gamma_target,
            )

    # -----------------------------------------------------------------------
    # ALL TIERS FAILED
    # -----------------------------------------------------------------------
    logger.warning(
        "gamma all tiers failed: %s; %s; tier2 also exhausted",
        tier0_rejection, tier1_rejection,
    )
    return Suggestion(
        engine="gamma", method="no_action", instrument="", size=0.0, direction="none",
        delta_impact=0.0, gamma_impact=0.0, vega_impact=0.0,
        post_mm_pct=greek_profile.mm_pct, post_dd_est=0.0,
        post_delta=greek_profile.delta_btc, post_gamma=greek_profile.gamma,
        post_vega=greek_profile.vega,
        fallback_used=True, fallback_tier=2,
        rationale=f"All tiers failed: {tier0_rejection}; {tier1_rejection}; Tier 2 exhausted",
        risk_note="Manual intervention required. Gamma exposure unhedged.",
        simulation_ok=False,
        target_reached=False,
        action_classification="fallback_last_resort",
    )