# hedge_engine/actions/convexity/tail_hedge.py
from __future__ import annotations

import json
import math
import sqlite3
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from hedge_engine.core.enums import ActionType, Side
from hedge_engine.core.models import CandidateAction, Position, PortfolioSnapshot
from hedge_engine.settings.config import EngineConfig
from hedge_engine.actions.convexity.strike_selector import get_candidates


def get_tail_budget_usd(equity_usd: float, regime: str) -> float:
    """
    Monthly tail hedge budget as a % of equity.
      normal regime  → 0.35% of equity
      high/panic     → 0.55% of equity
    """
    regime_l = (regime or "").lower()
    pct = 0.0055 if regime_l in ("high", "panic") else 0.0035
    return float(equity_usd) * pct


def check_tail_hedge_status(positions: List[Position]) -> Dict[str, Any]:
    """
    Detect existing long tail hedge positions:
      - kind == "option", size > 0
      - 30-60 DTE
      - deep OTM: abs(delta) <= 0.15
    Returns dict with has_tail_hedge and details of the nearest-expiry match.
    """
    candidates = [
        p for p in positions
        if p.kind == "option"
        and p.size > 0
        and p.dte_days is not None
        and 30 <= p.dte_days <= 60
        and p.option_type in ("C", "P")
        and abs(p.delta or 0.5) <= 0.15
    ]
    if not candidates:
        return {
            "has_tail_hedge": False,
            "dte_days": None,
            "instrument_name": None,
            "cost_usd": None,
        }
    best = min(candidates, key=lambda p: p.dte_days)
    return {
        "has_tail_hedge": True,
        "dte_days": best.dte_days,
        "instrument_name": best.instrument_name,
        "cost_usd": best.mark_price_usd,
    }


def suggest_tail_hedge(
    snapshot: PortfolioSnapshot,
    cfg: EngineConfig,
    regime: str,
    con: sqlite3.Connection,
) -> Optional[CandidateAction]:
    """
    Propose a HEDGE_TAIL buy if no tail hedge already exists within budget.
    Target: 30-60 DTE deep OTM put (~8-delta), cheapest candidate within budget.
    """
    status = check_tail_hedge_status(snapshot.positions)
    if status["has_tail_hedge"]:
        return None   # already covered

    equity = snapshot.equity_usd or snapshot.total_equity_usd
    budget_usd = get_tail_budget_usd(equity, regime)

    candidates = get_candidates(
        snapshot, con, "P",
        min_dte=cfg.tail_dte_min,
        max_dte=cfg.tail_dte_max,
        delta_target=0.08,   # ~8-delta deep OTM
        max_results=5,
    )
    if not candidates:
        return None

    # Prefer cheapest within budget; fall back to cheapest overall
    affordable = [c for c in candidates if c.get("mark_usd", 0) <= budget_usd]
    target = affordable[0] if affordable else candidates[0]

    mark = max(float(target.get("mark_usd") or 1), 1.0)
    qty = max(1, min(5, int(math.floor(budget_usd / mark))))

    return CandidateAction(
        action_type=ActionType.HEDGE_TAIL,
        instrument_name=target["instrument_name"],
        side=Side.BUY,
        qty_contracts=qty,
        meta={
            "reason": "tail_hedge_top_up",
            "regime": regime,
            "budget_usd": budget_usd,
            "mark_usd": target.get("mark_usd"),
            "dte_days": target.get("dte_days"),
            "delta_approx": target.get("delta_approx"),
            "strike": target.get("strike"),
            "source": target.get("source"),
        },
    )


def track_monthly_spend(con: sqlite3.Connection) -> Dict[str, float]:
    """
    Sum the actual cost of HEDGE_TAIL actions executed in the current calendar month
    from hedge_decisions_log. Returns {spent_usd, budget_usd, remaining_usd}.
    budget_usd and remaining_usd are left as 0.0 (caller can fill with equity context).
    """
    now = datetime.now(timezone.utc)
    month_prefix = now.strftime("%Y-%m")
    rows = []
    try:
        rows = con.execute(
            "SELECT actions_json FROM hedge_decisions_log "
            "WHERE ts_utc LIKE ? AND actions_json LIKE '%HEDGE_TAIL%'",
            (f"{month_prefix}%",),
        ).fetchall()
    except Exception:
        pass   # table may not exist yet (Phase 7 creates it)

    spent = 0.0
    for (actions_json,) in rows:
        try:
            for action in json.loads(actions_json):
                if action.get("action_type") == "HEDGE_TAIL":
                    spent += float((action.get("meta") or {}).get("mark_usd", 0) or 0)
        except Exception:
            pass

    return {"spent_usd": spent, "budget_usd": 0.0, "remaining_usd": 0.0}
