# hedge_engine/actions/position_management/risk_reduction.py
"""
Risk reduction: rank and trim short options.

Phase 6: Composite offender scoring replaces simple tuple sort.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List

from hedge_engine.core.enums import ActionType, Side
from hedge_engine.core.models import CandidateAction, Position, PortfolioSnapshot
from hedge_engine.risk.risk_checks import RiskFlags
from hedge_engine.settings.config import EngineConfig


# ─────────────────────────────────────────────
# Phase 6: Composite offender scoring
# ─────────────────────────────────────────────

@dataclass(frozen=True)
class OffenderScore:
    instrument_name: str
    total_score: float
    components: Dict[str, float]


def rank_position_offenders(
    positions: List[Position],
    snapshot: PortfolioSnapshot,
    flags: RiskFlags,
    cfg: EngineConfig,
) -> List[OffenderScore]:
    """
    Rank short options by composite offender score (higher = trim first).

    Factors:
      - DTE urgency: shorter DTE = higher score
      - Gamma contribution: higher abs(gamma) relative to portfolio
      - Vega contribution: higher abs(vega) relative to portfolio
      - Margin impact estimate: mark_price * abs(size) relative to equity
      - Stress proxy: abs(net_delta) * spot * 5% move relative to equity

    Returns sorted list (highest score first).
    """
    short_opts = [p for p in positions if p.size < 0 and p.kind == "option"]
    if not short_opts:
        return []

    w_dte = getattr(cfg, "OFFENDER_WEIGHT_DTE", 0.25)
    w_gamma = getattr(cfg, "OFFENDER_WEIGHT_GAMMA", 0.25)
    w_vega = getattr(cfg, "OFFENDER_WEIGHT_VEGA", 0.20)
    w_margin = getattr(cfg, "OFFENDER_WEIGHT_MARGIN", 0.15)
    w_stress = getattr(cfg, "OFFENDER_WEIGHT_STRESS", 0.15)

    equity = max(snapshot.total_equity_usd, 1.0)
    spot = max(snapshot.spot_index_usd, 1.0)
    port_gamma = max(abs(snapshot.portfolio_gamma), 1e-9)
    port_vega = max(abs(snapshot.portfolio_vega), 1e-9)

    scores: List[OffenderScore] = []
    for p in short_opts:
        dte = p.dte_days if p.dte_days is not None else 9999.0

        # DTE urgency: 0 DTE = 1.0, 30+ DTE = 0.0
        dte_score = max(0.0, min(1.0, 1.0 - dte / 30.0))

        # Gamma contribution
        gamma_score = min(1.0, abs(p.gamma) / port_gamma)

        # Vega contribution
        vega_score = min(1.0, abs(p.vega) / port_vega)

        # Margin impact estimate
        mark = p.mark_price_usd or 0.0
        margin_score = min(1.0, (mark * abs(p.size)) / equity)

        # Stress proxy: 5% spot move PnL from this position's delta
        stress_pnl = abs(p.net_delta * spot * 0.05)
        stress_score = min(1.0, stress_pnl / equity)

        total = (
            w_dte * dte_score
            + w_gamma * gamma_score
            + w_vega * vega_score
            + w_margin * margin_score
            + w_stress * stress_score
        )

        scores.append(OffenderScore(
            instrument_name=p.instrument_name,
            total_score=round(total, 6),
            components={
                "dte": round(dte_score, 4),
                "gamma": round(gamma_score, 4),
                "vega": round(vega_score, 4),
                "margin": round(margin_score, 4),
                "stress": round(stress_score, 4),
            },
        ))

    return sorted(scores, key=lambda s: s.total_score, reverse=True)


# ─────────────────────────────────────────────
# Legacy ranking (kept for reference)
# ─────────────────────────────────────────────

def rank_for_reduction(positions: List[Position]) -> List[Position]:
    """
    DEPRECATED: Use rank_position_offenders instead.

    Sort short options for partial trim priority:
      1. DTE ascending (nearest expiry first)
      2. abs(gamma) descending (most gamma risk first)
      3. vega ascending (most negative vega first)
      4. mark_price_usd descending (biggest margin relief first)
    """
    short_opts = [p for p in positions if p.size < 0 and p.kind == "option"]
    return sorted(
        short_opts,
        key=lambda p: (
            p.dte_days if p.dte_days is not None else 9999,
            -abs(p.gamma),
            p.vega,
            -(p.mark_price_usd or 0.0),
        ),
    )


def propose_risk_reduction(
    snapshot: PortfolioSnapshot,
    flags: RiskFlags,
    cfg: EngineConfig,
    max_actions: int = 2,
) -> List[CandidateAction]:
    """
    Rank short options by composite offender score and propose 50% partial trims.
    Only short options qualify (size < 0, kind == "option").
    """
    offenders = rank_position_offenders(snapshot.positions, snapshot, flags, cfg)
    top_names = [o.instrument_name for o in offenders[:max_actions]]

    # Map back to Position objects in order
    pos_by_name = {p.instrument_name: p for p in snapshot.positions}
    ranked = [pos_by_name[name] for name in top_names if name in pos_by_name]

    # Build offender lookup for meta
    offender_lookup = {o.instrument_name: o for o in offenders}

    actions = []
    for pos in ranked:
        trim_size = abs(int(pos.size * 0.5)) or 1
        offender = offender_lookup.get(pos.instrument_name)
        actions.append(CandidateAction(
            action_type=ActionType.REDUCE_POS,
            instrument_name=pos.instrument_name,
            side=Side.BUY,
            qty_contracts=trim_size,
            meta={
                "reason": "risk_reduction",
                "dte_days": pos.dte_days,
                "gamma": pos.gamma,
                "vega": pos.vega,
                "full_size": pos.size,
                "trim_size": trim_size,
                "mark_price_usd": pos.mark_price_usd,
                "strike": pos.strike,
                "option_type": pos.option_type,
                "offender_score": offender.total_score if offender else None,
                "offender_components": offender.components if offender else None,
            },
        ))
    return actions
