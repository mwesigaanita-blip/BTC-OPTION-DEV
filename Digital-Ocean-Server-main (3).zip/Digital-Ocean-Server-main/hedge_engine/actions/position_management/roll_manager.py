# hedge_engine/actions/position_management/roll_manager.py
from __future__ import annotations

from typing import Any, Dict, List, Optional

from hedge_engine.core.enums import ActionType, Side
from hedge_engine.core.models import CandidateAction, Position, PortfolioSnapshot
from hedge_engine.settings.config import EngineConfig


def check_roll_candidates(
    positions: List[Position],
    roll_dte_threshold: int = 7,
) -> List[Dict[str, Any]]:
    """
    Scan all short options and return those with DTE <= threshold.
    Results are sorted by DTE ascending (most urgent first).
    """
    results = []
    for p in positions:
        if p.size >= 0 or p.kind != "option":
            continue
        dte = p.dte_days if p.dte_days is not None else 9999
        if dte <= roll_dte_threshold:
            results.append({
                "instrument_name": p.instrument_name,
                "dte_days": dte,
                "size": p.size,
                "strike": p.strike,
                "option_type": p.option_type,
                "kind": p.kind,
            })
    return sorted(results, key=lambda x: x["dte_days"])


def propose_roll(
    position: Position,
    snapshot: PortfolioSnapshot,
    cfg: EngineConfig,
) -> Optional[CandidateAction]:
    """
    Propose closing the near-expiry short and re-opening at ~30 DTE.
    Instrument discovery is advisory - no chain lookup here.
    Returns None if position is not a short option.
    """
    if position.size >= 0 or position.kind != "option":
        return None

    qty = abs(int(position.size)) or 1

    return CandidateAction(
        action_type=ActionType.ROLL_SHORT,
        instrument_name=position.instrument_name,
        side=Side.BUY,   # close leg: buy back the short
        qty_contracts=qty,
        meta={
            "reason": "roll_near_expiry",
            "dte_days": position.dte_days,
            "strike": position.strike,
            "option_type": position.option_type,
            "target_dte_days": 30,
            "action_note": "Close this leg and re-open at ~30 DTE same strike",
        },
    )
