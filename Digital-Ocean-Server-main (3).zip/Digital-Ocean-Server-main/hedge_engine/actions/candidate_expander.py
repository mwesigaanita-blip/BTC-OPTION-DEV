# hedge_engine/actions/candidate_expander.py
"""
Phase 8: Expanded candidate search space.

Before changing final acceptance wording, we ensure the engine tests
strong enough hedge candidates. This module provides:

1. Deterministic perp size grid (account-size aware)
2. Wider option candidate search (for tail hedges and gamma hedges)
3. Candidate ranking by stress improvement, cost, and suitability

Design principle:
  - Deterministic (no LLM / AI)
  - Broader search → let acceptance gates filter
  - Ranked by survival priority
"""
from __future__ import annotations

import logging
import math
from typing import Any, Dict, List, Optional, Tuple

from hedge_engine.core.enums import ActionType, Side
from hedge_engine.core.models import CandidateAction, PortfolioSnapshot
from hedge_engine.risk.risk_checks import RiskFlags
from hedge_engine.settings.config import EngineConfig

logger = logging.getLogger("hedge_engine.candidate_expander")


def _sf(v: Any, default: float = 0.0) -> float:
    try:
        return float(v) if v is not None else default
    except Exception:
        return default


# ─────────────────────────────────────────────
# 1. Expanded perp size grid
# ─────────────────────────────────────────────

def build_perp_size_grid(
    *,
    delta_btc: float,
    equity_usd: float,
    spot_usd: float,
    mode: str,
    cfg: EngineConfig,
) -> List[float]:
    """
    Build a deterministic grid of perp hedge sizes (in BTC) to test.

    Grid is based on:
      - Account equity / spot → max sensible BTC size
      - Current delta → full neutralization size
      - Mode → how aggressive the grid should be

    Returns list of positive BTC amounts (the caller decides direction).
    """
    if spot_usd <= 0 or equity_usd <= 0:
        return []

    max_btc = min(
        abs(delta_btc) * 1.2,  # up to 120% of current delta
        float(cfg.MAX_SINGLE_DELTA_HEDGE_BTC),
        equity_usd / spot_usd,  # never more than account size in BTC terms
    )

    if max_btc < float(cfg.MIN_DELTA_HEDGE_BTC):
        return []

    # Determine grid density based on mode
    mode_u = (mode or "NORMAL").upper()
    if mode_u == "EMERGENCY":
        # Dense grid: 8 steps
        n_steps = 8
    elif mode_u == "DANGER":
        n_steps = 6
    elif mode_u == "DEFENSIVE":
        n_steps = 5
    else:
        n_steps = 4

    # Build grid: evenly spaced from min to max
    min_btc = max(float(cfg.MIN_DELTA_HEDGE_BTC), 0.1)
    step = (max_btc - min_btc) / max(n_steps - 1, 1)

    grid = []
    for i in range(n_steps):
        size = min_btc + step * i
        size = round(size, 4)
        if size > 0:
            grid.append(size)

    # Always include full neutralization size
    full_neutral = round(abs(delta_btc), 4)
    if full_neutral > 0 and full_neutral not in grid:
        grid.append(full_neutral)

    # Always include max size
    max_rounded = round(max_btc, 4)
    if max_rounded > 0 and max_rounded not in grid:
        grid.append(max_rounded)

    # Sort and deduplicate
    grid = sorted(set(g for g in grid if g > 0))
    return grid


def generate_perp_candidates(
    *,
    snapshot: PortfolioSnapshot,
    flags: RiskFlags,
    cfg: EngineConfig,
) -> List[CandidateAction]:
    """
    Generate multiple perp hedge candidates at different sizes.

    Each candidate is a separate CandidateAction that can be independently
    simulated and scored. The bundle builder picks the best one.
    """
    delta = snapshot.portfolio_delta_btc
    equity = snapshot.equity_usd or snapshot.total_equity_usd
    spot = snapshot.spot_index_usd
    mode = (snapshot.mode or "NORMAL").upper()

    grid = build_perp_size_grid(
        delta_btc=delta,
        equity_usd=equity,
        spot_usd=spot,
        mode=mode,
        cfg=cfg,
    )

    if not grid:
        return []

    # Direction: sell to reduce positive delta, buy to reduce negative delta
    if abs(delta) < float(cfg.MIN_DELTA_HEDGE_BTC):
        return []  # already near neutral

    side = Side.SELL if delta > 0 else Side.BUY

    candidates = []
    for size_btc in grid:
        ca = CandidateAction(
            action_type=ActionType.HEDGE_DELTA,
            instrument_name="BTC-PERPETUAL",
            side=side,
            qty_btc=size_btc,
            meta={
                "method": "expanded_grid",
                "grid_size": size_btc,
                "delta_before": delta,
                "projected_delta_after": delta + (size_btc if side == Side.BUY else -size_btc),
                "mode": mode,
            },
        )
        candidates.append(ca)

    return candidates


# ─────────────────────────────────────────────
# 2. Option chain candidate search
# ─────────────────────────────────────────────

def rank_option_instruments(
    instruments: List[Dict[str, Any]],
    *,
    spot_usd: float,
    option_type: str = "P",   # "P" for protective puts, "C" for upside calls
    min_dte_days: int = 7,
    max_dte_days: int = 60,
    target_moneyness: float = 0.90,  # strike/spot ratio target
    max_results: int = 10,
) -> List[Dict[str, Any]]:
    """
    Rank option instruments for hedge candidate selection.

    Scoring factors:
      - DTE suitability (prefer 14-30 DTE sweet spot)
      - Moneyness proximity to target
      - Liquidity (open interest / volume if available)
      - Cost efficiency (mark price relative to theoretical value)

    Returns ranked list of instrument dicts with added 'hedge_score' field.
    """
    if not instruments or spot_usd <= 0:
        return []

    scored: List[Tuple[float, Dict[str, Any]]] = []

    for inst in instruments:
        # Parse instrument fields
        name = str(inst.get("instrument_name", ""))
        kind = str(inst.get("kind", "")).lower()

        if kind != "option":
            continue

        # Option type filter
        opt_type = str(inst.get("option_type", "")).upper()
        if not opt_type:
            if name.endswith("-C"):
                opt_type = "C"
            elif name.endswith("-P"):
                opt_type = "P"
        if opt_type != option_type.upper():
            continue

        # Strike
        strike = _sf(inst.get("strike"))
        if strike <= 0:
            continue

        # DTE
        dte = _sf(inst.get("dte_days"))
        if dte < min_dte_days or dte > max_dte_days:
            continue

        # Moneyness
        moneyness = strike / spot_usd

        # Mark price
        mark = _sf(inst.get("mark_price_usd") or inst.get("mark_price"))
        if mark <= 0:
            continue

        # ── Scoring ──
        # DTE score: prefer 14-30 DTE range
        dte_center = 21.0
        dte_score = max(0.0, 1.0 - abs(dte - dte_center) / 30.0)

        # Moneyness score: closer to target = better
        moneyness_score = max(0.0, 1.0 - abs(moneyness - target_moneyness) / 0.15)

        # Liquidity score (if available)
        oi = _sf(inst.get("open_interest"))
        vol = _sf(inst.get("volume"))
        liq_score = min(1.0, (oi + vol) / 100.0) if (oi + vol) > 0 else 0.5

        # Cost score: cheaper relative to spot = better for protection
        cost_ratio = mark / spot_usd
        cost_score = max(0.0, 1.0 - cost_ratio * 100)  # penalize expensive options

        # Composite score
        total = (
            0.30 * dte_score
            + 0.30 * moneyness_score
            + 0.20 * liq_score
            + 0.20 * cost_score
        )

        inst_copy = dict(inst)
        inst_copy["hedge_score"] = round(total, 4)
        inst_copy["dte_days"] = dte
        inst_copy["moneyness"] = round(moneyness, 4)
        inst_copy["mark_price_usd"] = mark

        scored.append((total, inst_copy))

    # Sort by score descending
    scored.sort(key=lambda x: -x[0])

    return [inst for _, inst in scored[:max_results]]


# ─────────────────────────────────────────────
# 3. Bundle expansion: generate multiple candidate bundles
# ─────────────────────────────────────────────

def expand_candidates_for_tier(
    *,
    base_candidates: List[CandidateAction],
    snapshot: PortfolioSnapshot,
    flags: RiskFlags,
    cfg: EngineConfig,
) -> List[List[CandidateAction]]:
    """
    Generate expanded candidate bundles from a base candidate list.

    Strategy:
      - Replace the perp action with each size from the expanded grid
      - Keep non-perp actions constant (reductions, vega, gamma hedges)
      - This produces multiple bundles that differ only in perp size

    Returns list of candidate bundles to test.
    """
    # Separate perp actions from non-perp actions
    perp_actions = [a for a in base_candidates if a.instrument_name == "BTC-PERPETUAL"]
    non_perp_actions = [a for a in base_candidates if a.instrument_name != "BTC-PERPETUAL"]

    if not perp_actions:
        # No perp in base → just return the original bundle
        return [base_candidates] if base_candidates else []

    # Generate expanded perp sizes
    expanded_perps = generate_perp_candidates(
        snapshot=snapshot,
        flags=flags,
        cfg=cfg,
    )

    if not expanded_perps:
        return [base_candidates]

    # Create bundles: each expanded perp + non-perp actions
    bundles: List[List[CandidateAction]] = []

    # Always include the original bundle first
    bundles.append(base_candidates)

    for perp_candidate in expanded_perps:
        bundle = [perp_candidate] + non_perp_actions
        # Avoid duplicating the original
        original_qty = perp_actions[0].qty_btc if perp_actions else None
        if perp_candidate.qty_btc != original_qty:
            bundles.append(bundle)

    return bundles
