# hedge_engine/actions/instrument_scorer.py
#
# Scores hedge candidate instruments for the Greek sub-engine pipeline.
# Used by gamma_hedge.py and vega_hedge.py to rank candidates before simulation.
#
# Score = weighted sum of 5 dimensions (total = 1.0):
#   0.35  primary_greek_relief  - how much this trade closes the greek gap
#   0.25  delta_help            - how much it moves net_delta toward zero
#   0.20  greek_efficiency      - greek relief per dollar of premium
#   0.10  margin_cost           - lower margin usage = better
#   0.10  trade_liquidity       - recent market activity (from get_last_trades_by_instrument)

from __future__ import annotations

import time
from typing import Any, Dict, List, Optional

from hedge_engine.core.models import GreekProfile, GreekTargets

# Default scorer weights (must sum to 1.0)
DEFAULT_WEIGHTS: Dict[str, float] = {
    "primary_greek": 0.35,
    "delta_help":    0.25,
    "efficiency":    0.20,
    "margin_cost":   0.10,
    "liquidity":     0.10,
}

# Regime-aware weight presets: stress regimes prioritize greek relief and margin safety
REGIME_WEIGHTS: Dict[str, Dict[str, float]] = {
    "normal": DEFAULT_WEIGHTS,
    "high": {
        "primary_greek": 0.40,
        "delta_help":    0.20,
        "efficiency":    0.15,
        "margin_cost":   0.15,
        "liquidity":     0.10,
    },
    "panic": {
        "primary_greek": 0.50,
        "delta_help":    0.15,
        "efficiency":    0.10,
        "margin_cost":   0.15,
        "liquidity":     0.10,
    },
}

# Max trade count for normalizing trade_count_score (10+ trades = full score)
_TRADE_COUNT_SATURATION = 10
# Recency window in seconds (default 5 minutes; overridable via cfg)
_DEFAULT_RECENCY_WINDOW_S = 300
# Max acceptable price deviation vs mark before penalizing liquidity score
_PRICE_SANITY_MAX_PCT = 0.05  # 5%


def _clamp01(x: float) -> float:
    return max(0.0, min(1.0, x))


# ---------------------------------------------------------------------------
# Trade liquidity scoring (dimension 5)
# ---------------------------------------------------------------------------

def _score_trade_liquidity(
    recent_trades: List[Dict[str, Any]],
    mark_price: Optional[float],
    recency_window_s: int = _DEFAULT_RECENCY_WINDOW_S,
) -> float:
    """
    Score 0–1 based on recent trade data for one instrument.
    Falls back to 0.5 (neutral) if trades is empty or None.

    Sub-components:
      0.40  trade_count_score  - 0 trades=0, >=10 trades=1.0
      0.30  volume_score       - normalized total amount (capped vs max known)
      0.20  recency_score      - fraction of trades within recency_window_s
      0.10  price_sanity       - 1 - penalty if last trade is far from mark
    """
    if not recent_trades:
        return 0.5  # neutral fallback

    count = len(recent_trades)
    trade_count_score = _clamp01(count / _TRADE_COUNT_SATURATION)

    # Total volume (sum of amounts)
    total_volume = sum(float(t.get("amount", 0) or 0) for t in recent_trades)
    # Normalise against a reasonable "active" threshold; 10 contracts = full score
    volume_score = _clamp01(total_volume / 10.0)

    # Recency: fraction of trades that occurred within the recency window
    now_ms = int(time.time() * 1000)
    cutoff_ms = now_ms - recency_window_s * 1000
    recent_count = sum(
        1 for t in recent_trades
        if int(t.get("timestamp", 0) or 0) >= cutoff_ms
    )
    recency_score = _clamp01(recent_count / max(count, 1))

    # Price sanity: if last trade price is far from mark, penalise
    price_sanity_score = 1.0
    if mark_price and mark_price > 0:
        last_price = float(recent_trades[0].get("price", mark_price) or mark_price)
        deviation = abs(last_price - mark_price) / mark_price
        penalty = _clamp01(deviation / _PRICE_SANITY_MAX_PCT)
        price_sanity_score = 1.0 - penalty

    return (
        0.40 * trade_count_score
        + 0.30 * volume_score
        + 0.20 * recency_score
        + 0.10 * price_sanity_score
    )


# ---------------------------------------------------------------------------
# Core scorer
# ---------------------------------------------------------------------------

def score_instrument(
    *,
    engine: str,                          # "gamma" | "vega"
    greek_profile: GreekProfile,          # current portfolio state
    targets: GreekTargets,                # safe-zone boundaries
    instrument_greek: float,              # gamma or vega of the instrument (per contract)
    instrument_delta: float,              # net delta of the instrument (per contract)
    instrument_mark_usd: float,           # current mark price in USD
    instrument_margin_usd: float,         # estimated margin impact in USD
    qty: float = 1.0,                     # number of contracts / BTC to trade
    direction: str = "buy",               # "buy" | "sell"
    recent_trades: Optional[List[Dict[str, Any]]] = None,
    recency_window_s: int = _DEFAULT_RECENCY_WINDOW_S,
    weights: Optional[Dict[str, float]] = None,
    regime: str = "normal",               # "normal" | "high" | "panic"
    cfg: Any = None,                      # EngineConfig for IMPACT_QUALITY_MIN_PCT
) -> float:
    """
    Score a candidate instrument for hedging (higher = better).
    Returns a float in [0, 1].

    Works for both buy and sell candidates:
      - buy: positive greek relief, delta help is movement toward 0
      - sell: also valid - selling the other side can improve greek balance
    """
    w = weights or REGIME_WEIGHTS.get(regime, DEFAULT_WEIGHTS)

    sign = 1.0 if direction == "buy" else -1.0

    # --- Primary greek relief (how much this closes the gap to target) ---
    if engine == "gamma":
        current_greek = greek_profile.gamma
        target_greek = targets.gamma_target
        greek_impact = sign * instrument_greek * qty
    elif engine == "vega":
        current_greek = greek_profile.vega
        target_greek = targets.vega_target
        greek_impact = sign * instrument_greek * qty
    else:
        current_greek = 0.0
        target_greek = 0.0
        greek_impact = 0.0

    gap = target_greek - current_greek  # how far we need to move the greek
    if abs(gap) < 1e-9:
        primary_score = 1.0  # already at target - no action needed, max score
    else:
        # How much of the gap does this trade close?
        relief_fraction = _clamp01(greek_impact / gap)
        primary_score = relief_fraction

    # --- Delta help (moves net_delta toward zero) ---
    current_delta = greek_profile.delta_btc
    delta_impact = sign * instrument_delta * qty
    new_delta = current_delta + delta_impact
    # Score = improvement in |delta| (positive = closer to zero)
    if abs(current_delta) < 1e-6:
        delta_score = 1.0  # already at zero - no harm
    else:
        delta_improvement = abs(current_delta) - abs(new_delta)
        delta_score = _clamp01(delta_improvement / abs(current_delta))

    # --- Greek efficiency (relief per dollar of premium) ---
    cost_usd = abs(instrument_mark_usd * qty) + 1e-9
    raw_relief = abs(greek_impact)
    # Normalise: assume 1 unit of greek per $1 premium is "baseline efficient"
    # Scale to [0,1] - cap at 10x baseline
    efficiency_raw = raw_relief / cost_usd
    efficiency_score = _clamp01(efficiency_raw / 10.0)

    # --- Margin cost (lower is better) ---
    equity = greek_profile.equity_usd or 1.0
    margin_fraction = abs(instrument_margin_usd * qty) / equity
    # Full score = 0 margin, zero score = >=5% of equity
    margin_score = _clamp01(1.0 - margin_fraction / 0.05)

    # --- Trade liquidity ---
    mark_for_sanity = instrument_mark_usd if instrument_mark_usd > 0 else None
    liquidity_score = _score_trade_liquidity(
        recent_trades or [],
        mark_price=mark_for_sanity,
        recency_window_s=recency_window_s,
    )

    # Hard reject: instrument does not move the needle enough
    impact_quality_min = float(getattr(cfg, "IMPACT_QUALITY_MIN_PCT", 0.08)) if cfg else 0.08
    if primary_score < impact_quality_min:
        return 0.0

    total = (
        w.get("primary_greek", 0.35) * primary_score
        + w.get("delta_help",    0.25) * delta_score
        + w.get("efficiency",    0.20) * efficiency_score
        + w.get("margin_cost",   0.10) * margin_score
        + w.get("liquidity",     0.10) * liquidity_score
    )
    return _clamp01(total)


# ---------------------------------------------------------------------------
# Convenience wrappers for gamma and vega engines
# ---------------------------------------------------------------------------

def score_for_gamma(
    *,
    greek_profile: GreekProfile,
    targets: GreekTargets,
    instrument_gamma: float,
    instrument_delta: float,
    instrument_mark_usd: float,
    instrument_margin_usd: float,
    qty: float = 1.0,
    direction: str = "buy",
    recent_trades: Optional[List[Dict[str, Any]]] = None,
    recency_window_s: int = _DEFAULT_RECENCY_WINDOW_S,
    regime: str = "normal",
    cfg: Any = None,
) -> float:
    return score_instrument(
        engine="gamma",
        greek_profile=greek_profile,
        targets=targets,
        instrument_greek=instrument_gamma,
        instrument_delta=instrument_delta,
        instrument_mark_usd=instrument_mark_usd,
        instrument_margin_usd=instrument_margin_usd,
        qty=qty,
        direction=direction,
        recent_trades=recent_trades,
        recency_window_s=recency_window_s,
        regime=regime,
        cfg=cfg,
    )


def score_for_vega(
    *,
    greek_profile: GreekProfile,
    targets: GreekTargets,
    instrument_vega: float,
    instrument_delta: float,
    instrument_mark_usd: float,
    instrument_margin_usd: float,
    qty: float = 1.0,
    direction: str = "buy",
    recent_trades: Optional[List[Dict[str, Any]]] = None,
    recency_window_s: int = _DEFAULT_RECENCY_WINDOW_S,
    regime: str = "normal",
    cfg: Any = None,
) -> float:
    return score_instrument(
        engine="vega",
        greek_profile=greek_profile,
        targets=targets,
        instrument_greek=instrument_vega,
        instrument_delta=instrument_delta,
        instrument_mark_usd=instrument_mark_usd,
        instrument_margin_usd=instrument_margin_usd,
        qty=qty,
        direction=direction,
        recent_trades=recent_trades,
        recency_window_s=recency_window_s,
        regime=regime,
        cfg=cfg,
    )
