# hedge_engine/actions/delta/perp_sizing.py
from __future__ import annotations

import json
import math
from dataclasses import asdict
from datetime import datetime, timezone
from typing import Dict, List, Tuple

from hedge_engine.settings.config import EngineConfig


def compute_perp_chunks(
    *,
    qty_btc: float,
    cfg: EngineConfig,
) -> List[float]:
    """
    Deterministically split a PERP order into chunks.

    Rules (all config-driven):
    - Use abs(qty_btc)
    - Target chunk size cfg.PERP_CHUNK_BTC (soft)
    - Clamp chunks count to [1, cfg.PERP_MAX_CHUNKS]
    - Enforce minimum chunk size cfg.PERP_MIN_CHUNK_BTC (except possibly last remainder)
    - Preserve sign of qty_btc across all chunks
    """
    if qty_btc == 0.0:
        return []

    # Single chunk if total is below minimum floor (execute as-is, never skip)
    if abs(qty_btc) < float(cfg.PERP_MIN_CHUNK_BTC):
        return [float(qty_btc)]

    sign = 1.0 if qty_btc > 0 else -1.0
    total = abs(float(qty_btc))

    chunk_target = float(cfg.PERP_CHUNK_BTC)
    min_chunk = float(cfg.PERP_MIN_CHUNK_BTC)
    max_chunks = int(cfg.PERP_MAX_CHUNKS)

    # Defensive guards
    if chunk_target <= 0:
        chunk_target = total
    if min_chunk <= 0:
        min_chunk = 0.0
    if max_chunks <= 0:
        max_chunks = 1

    # initial estimate for chunk count
    n = int(math.ceil(total / chunk_target))
    n = max(1, min(max_chunks, n))

    # recompute uniform chunk size
    base = total / n

    # if base below min_chunk, reduce number of chunks
    if base < min_chunk and min_chunk > 0:
        n = int(max(1, min(max_chunks, math.floor(total / min_chunk))))
        if n == 0:
            n = 1
        base = total / n

    chunks_abs: List[float] = []
    remaining = total

    for i in range(n):
        if i == n - 1:
            c = remaining
        else:
            c = base

        # enforce min chunk where possible
        if min_chunk > 0 and c < min_chunk and remaining >= min_chunk:
            c = min_chunk

        # ensure we don't overshoot remaining
        c = min(c, remaining)
        remaining -= c
        chunks_abs.append(c)

        if remaining <= 1e-12:
            remaining = 0.0
            break

    # If any remainder due to min-chunk enforcement, add to last chunk
    if remaining > 0 and chunks_abs:
        chunks_abs[-1] += remaining
        remaining = 0.0

    return [sign * c for c in chunks_abs if abs(c) > 0.0]


def perp_chunk_debug_dump(
    *,
    qty_btc: float,
    cfg: EngineConfig,
) -> Dict:
    chunks = compute_perp_chunks(qty_btc=qty_btc, cfg=cfg)
    return {
        "ts_utc": datetime.now(timezone.utc).isoformat(),
        "input": {"qty_btc": qty_btc},
        "cfg": {
            "PERP_CHUNK_BTC": float(cfg.PERP_CHUNK_BTC),
            "PERP_MIN_CHUNK_BTC": float(cfg.PERP_MIN_CHUNK_BTC),
            "PERP_MAX_CHUNKS": int(cfg.PERP_MAX_CHUNKS),
        },
        "result": {
            "chunks": chunks,
            "sum_qty_btc": float(sum(chunks)),
            "n_chunks": len(chunks),
        },
    }


def cmd_debug_perp_sizing(*, qty_btc: float, cfg: EngineConfig) -> None:
    """
    Single-step CLI helper: print JSON debug dump.
    """
    payload = perp_chunk_debug_dump(qty_btc=qty_btc, cfg=cfg)
    print(json.dumps(payload, indent=2, sort_keys=True))