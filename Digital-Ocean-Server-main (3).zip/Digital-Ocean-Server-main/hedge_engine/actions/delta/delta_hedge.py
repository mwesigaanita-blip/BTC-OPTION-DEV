from __future__ import annotations

import logging
from dataclasses import asdict, dataclass, field
from typing import Any, Dict, List, Optional, Tuple

from hedge_engine.settings.config import EngineConfig
from hedge_engine.core.models import (
    PortfolioSnapshot, CandidateAction,
    GreekProfile, GreekTargets, Suggestion,
)
from hedge_engine.core.enums import ActionType, Side
from hedge_engine.risk.risk_checks import RiskFlags

logger = logging.getLogger(__name__)


def propose_perp_hedge(
    *,
    snapshot: PortfolioSnapshot,
    H: float,
    cfg: EngineConfig,
) -> Optional[CandidateAction]:
    """
    Deterministically propose a BTC-PERPETUAL hedge to reduce portfolio delta by hedge ratio H.

    Target:
        target_delta_after = delta_before * (1 - H)

    PERP sizing assumption:
        1 BTC-PERP ~= 1 BTC delta exposure
        => trade_qty_btc = - (target_delta_after - delta_before)

    Skip if proposed hedge has too-small USD impact vs equity:
        abs(trade_qty_btc) * spot_usd < equity_usd * cfg.MIN_DELTA_HEDGE_USD_PCT_EQUITY
    """
    # --- defensive clamps ---
    if H < 0.0:
        H = 0.0
    if H > 1.0:
        H = 1.0

    delta_before_btc = float(snapshot.portfolio_delta_btc)
    equity_usd = float(snapshot.equity_usd)
    spot_usd = float(snapshot.spot_index_usd)
    if spot_usd <= 0:
        return None
    
    target_delta_after_btc = delta_before_btc * (1.0 - H)
    delta_change_needed_btc = target_delta_after_btc - delta_before_btc  # negative means we need to sell to reduce delta
    trade_qty_btc = delta_change_needed_btc
    if abs(trade_qty_btc) > cfg.MAX_SINGLE_DELTA_HEDGE_BTC:
        trade_qty_btc = (
            cfg.MAX_SINGLE_DELTA_HEDGE_BTC
            if trade_qty_btc > 0
            else -cfg.MAX_SINGLE_DELTA_HEDGE_BTC
        )
    # --- % equity threshold (USD impact) ---
    min_usd_impact = equity_usd * float(cfg.MIN_DELTA_HEDGE_USD_PCT_EQUITY)
    usd_impact = abs(trade_qty_btc) * spot_usd

    if usd_impact < min_usd_impact:
        return None

    side = Side.BUY if trade_qty_btc > 0 else Side.SELL

    return CandidateAction(
        action_type=ActionType.HEDGE_DELTA,
        instrument_name="BTC-PERPETUAL",
        side=side,
        qty_btc=abs(trade_qty_btc),
        meta={
            "H": H,
            "delta_before_btc": delta_before_btc,
            "target_delta_after_btc": target_delta_after_btc,
            "delta_change_needed_btc": delta_change_needed_btc,
            "trade_qty_btc": trade_qty_btc,
            "spot_usd": spot_usd,
            "equity_usd": equity_usd,
            "usd_impact": usd_impact,
            "min_usd_impact": min_usd_impact,
            "threshold_pct_equity": float(cfg.MIN_DELTA_HEDGE_USD_PCT_EQUITY),
        },
    )


# ─────────────────────────────────────────────
# Phase 7: Target-band grid search
# ─────────────────────────────────────────────

@dataclass(frozen=True)
class PerpGridResult:
    optimal_qty_btc: float
    target_delta_after: float
    band: Tuple[float, float]
    grid_tested: int
    debug: Dict[str, Any]


def _get_delta_band(mode: str, cfg: EngineConfig) -> Optional[Tuple[float, float]]:
    """Get target delta band for the current mode."""
    mode = (mode or "NORMAL").upper()
    if mode == "EMERGENCY":
        return tuple(getattr(cfg, "PERP_DELTA_BAND_EMERGENCY", (-0.05, 0.05)))
    elif mode == "DANGER":
        return tuple(getattr(cfg, "PERP_DELTA_BAND_DANGER", (-0.2, 0.2)))
    elif mode == "DEFENSIVE":
        return tuple(getattr(cfg, "PERP_DELTA_BAND_DEFENSIVE", (-0.5, 0.5)))
    return None  # NORMAL: no forced delta band


def propose_perp_hedge_grid(
    *,
    snapshot: PortfolioSnapshot,
    flags: RiskFlags,
    cfg: EngineConfig,
) -> Optional[CandidateAction]:
    """
    Phase 7: Outcome-driven perp hedge sizing via grid search.

    1. Determine target delta band based on mode
    2. If already in band → no action
    3. Test grid of sizes from minimum to full neutralization
    4. Choose smallest size that puts projected delta within band
    5. Respect MAX_SINGLE_DELTA_HEDGE_BTC clamp

    Falls back to propose_perp_hedge if grid search is disabled.
    """
    delta_before = float(snapshot.portfolio_delta_btc)
    equity_usd = float(snapshot.equity_usd)
    spot_usd = float(snapshot.spot_index_usd)
    mode = (snapshot.mode or "NORMAL").upper()

    if spot_usd <= 0:
        return None

    band = _get_delta_band(mode, cfg)
    if band is None:
        return None

    band_low, band_high = band

    # Already in band?
    if band_low <= delta_before <= band_high:
        return None

    # Grid search: test evenly spaced sizes
    grid_steps = int(getattr(cfg, "PERP_GRID_STEPS", 10))
    max_btc = float(cfg.MAX_SINGLE_DELTA_HEDGE_BTC)
    min_usd_impact = equity_usd * float(cfg.MIN_DELTA_HEDGE_USD_PCT_EQUITY)

    # Full neutralize size (clamped)
    full_neutralize = min(abs(delta_before), max_btc)
    if full_neutralize <= 0:
        return None

    # Generate grid: from small to full
    step = full_neutralize / max(grid_steps, 1)
    grid_sizes = [step * (i + 1) for i in range(grid_steps)]
    # Ensure full neutralize is always tested
    if grid_sizes and abs(grid_sizes[-1] - full_neutralize) > 1e-6:
        grid_sizes.append(full_neutralize)

    # Direction: sell if delta > band_high, buy if delta < band_low
    if delta_before > band_high:
        direction = -1.0  # sell to reduce
    else:
        direction = 1.0   # buy to increase

    tested: List[Dict[str, Any]] = []
    best_qty: Optional[float] = None
    best_delta_after: Optional[float] = None

    for qty in grid_sizes:
        projected_delta = delta_before + direction * qty
        in_band = band_low <= projected_delta <= band_high
        usd_impact = qty * spot_usd

        entry = {
            "qty_btc": round(qty, 6),
            "projected_delta": round(projected_delta, 6),
            "in_band": in_band,
            "usd_impact": round(usd_impact, 2),
        }
        tested.append(entry)

        if in_band and usd_impact >= min_usd_impact:
            if best_qty is None:  # smallest first
                best_qty = qty
                best_delta_after = projected_delta

    # If no grid step lands in band, use the one closest to band center
    if best_qty is None:
        band_center = (band_low + band_high) / 2.0
        best_dist = float("inf")
        for entry in tested:
            dist = abs(entry["projected_delta"] - band_center)
            if dist < best_dist and entry["usd_impact"] >= min_usd_impact:
                best_dist = dist
                best_qty = entry["qty_btc"]
                best_delta_after = entry["projected_delta"]

    if best_qty is None or best_qty <= 0:
        return None

    side = Side.SELL if direction < 0 else Side.BUY

    grid_result = PerpGridResult(
        optimal_qty_btc=best_qty,
        target_delta_after=best_delta_after or 0.0,
        band=band,
        grid_tested=len(tested),
        debug={"grid_entries": tested},
    )

    return CandidateAction(
        action_type=ActionType.HEDGE_DELTA,
        instrument_name="BTC-PERPETUAL",
        side=side,
        qty_btc=abs(best_qty),
        meta={
            "method": "grid_search",
            "delta_before_btc": delta_before,
            "target_delta_after_btc": best_delta_after,
            "band": band,
            "grid_tested": len(tested),
            "optimal_qty_btc": best_qty,
            "spot_usd": spot_usd,
            "equity_usd": equity_usd,
            "grid_entries": tested,
        },
    )


# ---------------------------------------------------------------------------
# DEPRECATED: propose_perp_hedge / propose_perp_hedge_grid above
# Use run() for new sequential sub-engine pipeline
# ---------------------------------------------------------------------------

def run(
    *,
    greek_profile: GreekProfile,
    targets: GreekTargets,
    gamma_suggestion: Optional[Suggestion] = None,
    vega_suggestion: Optional[Suggestion] = None,
    snapshot: PortfolioSnapshot,
    cfg: EngineConfig,
    deribit: Any,
) -> Suggestion:
    """
    Delta sub-engine: mops up residual delta after gamma and vega hedges.

    Computes:
      residual_delta = greek_profile.delta_btc
                     + gamma_suggestion.delta_impact
                     + vega_suggestion.delta_impact

    If residual delta is within targets.delta_band, returns no-action.
    Otherwise sizes a BTC-PERPETUAL trade to bring delta to the band center.
    Capped at cfg.MAX_SINGLE_DELTA_HEDGE_BTC (5 BTC) per tick.
    """
    from hedge_engine.risk.xpm.xpm_simulator import simulate_action_impact

    # --- Compute residual delta after upstream suggestions ---
    g_delta = float(gamma_suggestion.delta_impact if gamma_suggestion else 0.0)
    v_delta = float(vega_suggestion.delta_impact  if vega_suggestion  else 0.0)
    residual_delta = greek_profile.delta_btc + g_delta + v_delta

    hard_band_min = float(targets.delta_band_min)
    hard_band_max = float(targets.delta_band_max)

    # --- Soft vs hard targeting ---
    # In calm states (MM safe, DD small, NORMAL/DEFENSIVE) vega_breach escalators can
    # tighten the H-derived band to ±0.075 even at MM 51%.  Using the base mode band
    # instead prevents the engine from forcing an aggressive perp sell that is not
    # warranted by actual portfolio stress.
    mm_pct    = float(greek_profile.mm_pct)
    dd_abs    = abs(float(getattr(greek_profile, "dd", 0.0)))
    mode_str  = (targets.mode or "NORMAL").upper()
    calm_mm   = float(getattr(cfg, "CALM_MM_THRESHOLD",  65.0))
    calm_dd   = float(getattr(cfg, "CALM_DD_ABS_PCT",    0.04))
    _soft_bands = {
        "NORMAL":    float(getattr(cfg, "DELTA_SOFT_BAND_NORMAL_BTC",    0.50)),
        "DEFENSIVE": float(getattr(cfg, "DELTA_SOFT_BAND_DEFENSIVE_BTC", 0.30)),
    }

    # --- Phase 5: Vega severity check ---
    # Compute how far current vega is from targets.vega_target (same formula as vega_hedge).
    # Used for diagnostic logging and the opt-in severe-vega bypass below.
    _vega_target  = float(targets.vega_target)
    _vega_curr    = float(greek_profile.vega)
    _vega_gap     = max(0.0, _vega_target - _vega_curr)      # positive = vega too short
    _vega_gap_pct = _vega_gap / max(abs(_vega_target), 1e-9) # fraction relative to target size
    _severe_min   = float(getattr(cfg, "SEVERE_BREACH_MIN_PCT", 0.75))
    _is_vega_severe = _vega_gap_pct >= _severe_min

    # Opt-in: when DELTA_SOFT_BAND_VEGA_SEVERE_BYPASS=True, a severe vega breach
    # causes the soft band to be skipped so the H-escalated hard band is honoured.
    # Default=False preserves the Request-5 behaviour (no over-hedging at low MM/DD).
    _vega_severe_bypass_enabled = bool(
        getattr(cfg, "DELTA_SOFT_BAND_VEGA_SEVERE_BYPASS", False)
    )
    _vega_severe_bypass_active = _is_vega_severe and _vega_severe_bypass_enabled

    _is_calm_delta = (
        mm_pct < calm_mm
        and dd_abs < calm_dd
        and mode_str in {"NORMAL", "DEFENSIVE"}
        and not _vega_severe_bypass_active   # honour H-escalation when bypass enabled + severe
    )

    band_min = hard_band_min
    band_max = hard_band_max
    _delta_target_type = "hard"

    if _is_calm_delta and mode_str in _soft_bands:
        soft_half = _soft_bands[mode_str]
        if soft_half > hard_band_max:  # only widen - never narrow further
            band_min = -soft_half
            band_max = +soft_half
            _delta_target_type = "soft"
            logger.info(
                "delta: soft band applied "
                "(MM=%.1f%%, DD=%.1f%%, mode=%s, H=%.2f) "
                "→ soft ±%.3f overrides H-tightened hard ±%.3f "
                "[vega_gap=%.0f%% of target, severe=%s, bypass=%s]",
                mm_pct, dd_abs * 100, mode_str,
                float(getattr(targets, "hedge_ratio_H", float("nan"))),
                soft_half, hard_band_max,
                _vega_gap_pct * 100, _is_vega_severe, _vega_severe_bypass_enabled,
            )
    elif _vega_severe_bypass_active:
        logger.info(
            "delta: soft band bypassed - severe vega breach "
            "(gap=%.0f%% of target) with DELTA_SOFT_BAND_VEGA_SEVERE_BYPASS=True; "
            "using H-tightened hard band ±%.3f (H=%.2f)",
            _vega_gap_pct * 100, hard_band_max,
            float(getattr(targets, "hedge_ratio_H", float("nan"))),
        )

    # --- Trigger check ---
    if band_min <= residual_delta <= band_max:
        return Suggestion(
            engine="delta", method="no_action", instrument="BTC-PERPETUAL",
            size=0.0, direction="none",
            delta_impact=0.0, gamma_impact=0.0, vega_impact=0.0,
            post_mm_pct=greek_profile.mm_pct, post_dd_est=0.0,
            post_delta=residual_delta, post_gamma=greek_profile.gamma,
            post_vega=greek_profile.vega,
            fallback_used=False, fallback_tier=0,
            rationale=(
                f"residual delta {residual_delta:.4f} BTC within "
                f"{_delta_target_type} band [{band_min:.3f}, {band_max:.3f}], "
                f"no perp action needed"
            ),
            risk_note="",
            simulation_ok=True,
        )

    # --- Compute perp size to bring delta to band EDGE (not center) ---
    if residual_delta > band_max:
        target = band_max
    elif residual_delta < band_min:
        target = band_min
    else:
        target = residual_delta  # should not reach here due to trigger check above

    raw_size = residual_delta - target  # positive = need to sell, negative = need to buy
    max_btc = float(getattr(cfg, "MAX_SINGLE_DELTA_HEDGE_BTC", 5.0))
    clamped_size = max(-max_btc, min(max_btc, raw_size))

    if clamped_size > 0:
        direction = "sell"
        side = Side.SELL
    else:
        direction = "buy"
        side = Side.BUY

    qty_btc = abs(clamped_size)
    if qty_btc < 1e-6:
        return Suggestion(
            engine="delta", method="no_action", instrument="BTC-PERPETUAL",
            size=0.0, direction="none",
            delta_impact=0.0, gamma_impact=0.0, vega_impact=0.0,
            post_mm_pct=greek_profile.mm_pct, post_dd_est=0.0,
            post_delta=residual_delta, post_gamma=greek_profile.gamma,
            post_vega=greek_profile.vega,
            fallback_used=False, fallback_tier=0,
            rationale="delta trade size negligible after clamping",
            risk_note="",
            simulation_ok=True,
        )

    action = CandidateAction(
        action_type=ActionType.HEDGE_DELTA,
        instrument_name="BTC-PERPETUAL",
        side=side,
        qty_btc=qty_btc,
    )

    try:
        sim = simulate_action_impact(deribit, snapshot, action, "BTC")
    except Exception as exc:
        logger.warning("delta simulation error: %s", exc)
        sim = {}

    # post-delta: analytical, consistent with sizing basis (residual_delta)
    # simulate_action_impact runs against the original snapshot delta which diverges
    # from residual_delta when upstream gamma/vega suggestions exist.
    post_delta = residual_delta - clamped_size

    # post-MM: simulation is correct for margin (full portfolio margin calc)
    post_mm = float(sim.get("mm_pct_after") or greek_profile.mm_pct)
    sim_ok  = sim.get("error") is None

    # post-gamma/vega: BTC-PERPETUAL has 0 gamma and 0 vega; use residual upstream values
    g_gamma = float(gamma_suggestion.gamma_impact if gamma_suggestion else 0.0)
    g_vega  = float(gamma_suggestion.vega_impact  if gamma_suggestion else 0.0)
    v_gamma = float(vega_suggestion.gamma_impact  if vega_suggestion  else 0.0)
    v_vega  = float(vega_suggestion.vega_impact   if vega_suggestion  else 0.0)
    post_gamma = greek_profile.gamma + g_gamma + v_gamma
    post_vega  = greek_profile.vega  + g_vega  + v_vega

    was_clamped = abs(raw_size) > max_btc + 1e-9
    in_band_after = band_min <= post_delta <= band_max

    risk_note = ""
    if _delta_target_type == "soft":
        _vega_note = (
            f"  Vega {'SEVERE' if _is_vega_severe else 'OK'}: "
            f"gap={_vega_gap_pct:.0%} of target "
            f"(bypass {'ENABLED' if _vega_severe_bypass_enabled else 'off'})."
        )
        risk_note = (
            f"Calm state ({mode_str}, MM={mm_pct:.1f}%, DD={dd_abs*100:.1f}%): "
            f"using soft band ±{band_max:.3f} BTC instead of tightened hard band "
            f"±{hard_band_max:.3f} BTC.{_vega_note}"
        )
    elif _vega_severe_bypass_active:
        risk_note = (
            f"Severe vega breach (gap {_vega_gap_pct:.0%} of target): "
            f"soft-band bypass active - using H-tightened hard band ±{hard_band_max:.3f} BTC."
        )
    if was_clamped:
        clamp_note = (
            f"Partial hedge: capped at {max_btc} BTC (raw={raw_size:.4f} BTC). "
            f"Target band edge {target:.4f} not reached. "
            f"Post-hedge delta {post_delta:.4f} BTC."
        )
        risk_note = (risk_note + "  " + clamp_note) if risk_note else clamp_note

    target_reached = in_band_after

    # Classification: proper if delta reached the effective (soft or hard) band;
    # partial if capped; mm_relief only if perp trade improved MM without reaching band
    if in_band_after:
        action_classification = "proper_hedge"
    elif was_clamped:
        action_classification = "partial_hedge"
    else:
        action_classification = "mm_relief"

    target_label = f"{_delta_target_type} band edge"
    return Suggestion(
        engine="delta",
        method="perp",
        instrument="BTC-PERPETUAL",
        size=qty_btc,
        direction=direction,
        delta_impact=post_delta - residual_delta,
        gamma_impact=0.0,
        vega_impact=0.0,
        post_mm_pct=post_mm,
        post_dd_est=0.0,
        post_delta=post_delta,
        post_gamma=post_gamma,
        post_vega=post_vega,
        fallback_used=False,
        fallback_tier=0,
        rationale=(
            f"{direction.upper()} {qty_btc:.4f} BTC-PERPETUAL to bring residual delta "
            f"{residual_delta:.4f} BTC toward {target_label} {target:.4f} "
            f"[band ±{band_max:.3f}, type={_delta_target_type}]"
        ),
        risk_note=risk_note,
        simulation_ok=sim_ok,
        action_classification=action_classification,
        size_clamped=was_clamped,
        target_reached=target_reached,
    )
