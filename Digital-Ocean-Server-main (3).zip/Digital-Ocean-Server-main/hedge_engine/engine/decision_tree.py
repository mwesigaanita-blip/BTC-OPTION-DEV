# hedge_engine/engine/decision_tree.py
# DEPRECATED: Mode-based candidate routing replaced by per-engine trigger logic
# in gamma_hedge.run(), vega_hedge.run(), delta_hedge.run().
# Kept for rollback only (used by bundle_builder.py when SUB_ENGINE_ENABLED=False).
from __future__ import annotations

import sqlite3
from typing import List

from hedge_engine.core.models import CandidateAction, PortfolioSnapshot
from hedge_engine.data.deribit_client import DeribitClient
from hedge_engine.risk.risk_checks import RiskFlags
from hedge_engine.settings.config import EngineConfig

from hedge_engine.actions.delta.delta_hedge import propose_perp_hedge, propose_perp_hedge_grid
from hedge_engine.actions.convexity.gamma_hedge import propose_gamma_hedge
from hedge_engine.actions.convexity.tail_hedge import suggest_tail_hedge
from hedge_engine.actions.position_management.risk_reduction import propose_risk_reduction
from hedge_engine.actions.position_management.roll_manager import check_roll_candidates, propose_roll
from hedge_engine.actions.vega_hedge import propose_vega_hedge


def _get_regime(snapshot: PortfolioSnapshot) -> str:
    artifact = snapshot.stress_artifact or {}
    return str(artifact.get("regime", "NORMAL")).upper()


def _propose_perp(snapshot: PortfolioSnapshot, H: float, flags: RiskFlags, cfg: EngineConfig):
    """Phase 7: Use grid search if enabled, else formula-based."""
    if getattr(cfg, "PERP_GRID_SEARCH_ENABLED", False):
        result = propose_perp_hedge_grid(snapshot=snapshot, flags=flags, cfg=cfg)
        if result is not None:
            return result
    return propose_perp_hedge(snapshot=snapshot, H=H, cfg=cfg)


def get_candidate_actions(
    snapshot: PortfolioSnapshot,
    flags: RiskFlags,
    cfg: EngineConfig,
    con: sqlite3.Connection,
    deribit: DeribitClient,
) -> List[CandidateAction]:
    """
    Route to the correct action builders based on current risk mode.

    NORMAL    → tail hedge check only
    DEFENSIVE → delta hedge + tail hedge + roll flag (advisory)
    DANGER    → delta hedge + risk reduction + vega hedge + gamma hedge + tail hedge
    EMERGENCY → full delta neutralize (H=1.0) + close worst positions + vega hedge
    """
    mode = (snapshot.mode or "NORMAL").upper()
    actions: List[CandidateAction] = []
    regime = _get_regime(snapshot)

    if mode == "NORMAL":
        tail = suggest_tail_hedge(snapshot, cfg, regime, con)
        if tail:
            actions.append(tail)

    elif mode == "DEFENSIVE":
        perp = _propose_perp(snapshot, flags.target_hedge_ratio_H, flags, cfg)
        if perp:
            actions.append(perp)
        tail = suggest_tail_hedge(snapshot, cfg, regime, con)
        if tail:
            actions.append(tail)
        # Roll: flag the single most urgent near-expiry short (advisory)
        roll_candidates = check_roll_candidates(snapshot.positions)
        for rc in roll_candidates[:1]:
            pos = next(
                (p for p in snapshot.positions if p.instrument_name == rc["instrument_name"]),
                None,
            )
            if pos:
                roll = propose_roll(pos, snapshot, cfg)
                if roll:
                    actions.append(roll)

    elif mode == "DANGER":
        perp = _propose_perp(snapshot, flags.target_hedge_ratio_H, flags, cfg)
        if perp:
            actions.append(perp)
        reductions = propose_risk_reduction(snapshot, flags, cfg, max_actions=2)
        actions.extend(reductions)
        if flags.vega_breach:
            vega = propose_vega_hedge(snapshot, flags, cfg, con)
            if vega:
                actions.append(vega)
        if flags.gamma_budget_breach or flags.speed_trigger:
            gamma_list = propose_gamma_hedge(snapshot, flags, cfg)
            actions.extend(gamma_list)
        tail = suggest_tail_hedge(snapshot, cfg, regime, con)
        if tail:
            actions.append(tail)

    elif mode == "EMERGENCY":
        # Full delta neutralize
        perp = _propose_perp(snapshot, 1.0, flags, cfg)
        if perp:
            actions.append(perp)
        reductions = propose_risk_reduction(snapshot, flags, cfg, max_actions=3)
        actions.extend(reductions)
        # Vega hedge forced (even without explicit breach flag)
        vega = propose_vega_hedge(snapshot, flags, cfg, con)
        if vega:
            actions.append(vega)
        # No new tail hedge in EMERGENCY: preserve margin

    return actions
