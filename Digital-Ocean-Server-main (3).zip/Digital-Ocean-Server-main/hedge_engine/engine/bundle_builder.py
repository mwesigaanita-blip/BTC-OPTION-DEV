# hedge_engine/engine/bundle_builder.py
# DEPRECATED: This file is superseded by the sequential Greek sub-engine pipeline.
# The new pipeline runs in runner.py when cfg.SUB_ENGINE_ENABLED=True (default).
# This file is kept for rollback only. Do NOT delete until sub-engine pipeline is stable.
"""
Full decision pipeline: candidate generation → simulation → acceptance → ranking → escalation.

Phases 2-5, 8-9 integrated:
  - Phase 2: Hard acceptance gates (kill-switch, material improvement, MM)
  - Phase 3: Reason-linked coverage validation
  - Phase 4: Survival-first bundle scoring & variant generation
  - Phase 5: Escalation tiers (A_LIGHT → B_MEDIUM → C_STRONG → D_SURVIVAL)
  - Phase 8: Explicit "no valid bundle" outcome
  - Phase 9: Decision telemetry
"""
from __future__ import annotations

import json
import logging
import sqlite3
import time
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple

from hedge_engine.core.models import (
    Action, ActionBundle, CandidateAction, HedgeMetrics, PortfolioSnapshot,
)
from hedge_engine.data.deribit_client import DeribitClient
from hedge_engine.engine.decision_tree import get_candidate_actions
from hedge_engine.risk.risk_checks import RiskFlags
from hedge_engine.risk.stress.stress_runner import min_projected_dd_from_scenarios
from hedge_engine.risk.stress.stress_truth import extract_worst_dd, reconcile_fast_deep
from hedge_engine.risk.xpm.bundle_acceptance import (
    AcceptanceResult,
    evaluate_bundle_acceptance,
    score_bundle_survival,
)
from hedge_engine.risk.xpm.xpm_simulator import simulate_bundle_impact
from hedge_engine.settings.config import EngineConfig

logger = logging.getLogger("hedge_engine.bundle_builder")

# Escalation tier ordering (Phase 5)
TIER_ORDER = ["A_LIGHT", "B_MEDIUM", "C_STRONG", "D_SURVIVAL"]


# ─────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────

def _candidate_to_action(ca: CandidateAction) -> Action:
    """Convert CandidateAction to an Action with a human-readable cmd string."""
    if ca.qty_contracts is not None:
        qty_str = f"{ca.qty_contracts} contracts"
    elif ca.qty_btc is not None:
        qty_str = f"{ca.qty_btc:.4f} BTC"
    else:
        qty_str = "?"
    cmd = f"{ca.side.value} {qty_str} {ca.instrument_name} [{ca.action_type.value}]"
    return Action(cmd=cmd, meta=ca.meta or {})


def _build_before_metrics(snapshot: PortfolioSnapshot) -> HedgeMetrics:
    return HedgeMetrics(
        delta_btc=snapshot.portfolio_delta_btc,
        gamma=snapshot.portfolio_gamma,
        vega=snapshot.portfolio_vega,
        mm_pct=snapshot.mm_pct,
    )


def _build_after_metrics(after_sim: Dict[str, Any], snapshot: PortfolioSnapshot) -> HedgeMetrics:
    sim_ok = bool(after_sim.get("sim_ok", True))
    if sim_ok:
        return HedgeMetrics(
            delta_btc=after_sim.get("delta_after", snapshot.portfolio_delta_btc),
            gamma=after_sim.get("gamma_after", snapshot.portfolio_gamma),
            vega=after_sim.get("vega_after", snapshot.portfolio_vega),
            mm_pct=after_sim.get("mm_pct_after", snapshot.mm_pct),
        )
    unknown = float("nan")
    return HedgeMetrics(
        delta_btc=snapshot.portfolio_delta_btc,
        gamma=unknown,
        vega=unknown,
        mm_pct=unknown,
    )


def _mode_to_urgency(mode: str) -> str:
    return {
        "NORMAL": "INFO",
        "DEFENSIVE": "WARNING",
        "DANGER": "URGENT",
        "EMERGENCY": "EMERGENCY",
        "NO_VALID_BUNDLE": "EMERGENCY",
    }.get((mode or "NORMAL").upper(), "INFO")


def _build_reason_str(flags: RiskFlags, cfg: EngineConfig) -> str:
    """Build human-readable reason string from active flags."""
    reason_parts: List[str] = []
    if flags.dd_abs_pct >= 2.0:
        reason_parts.append(f"dd>={flags.dd_abs_pct:.1f}%")
    if flags.mm_pct >= cfg.mm_warning_pct:
        reason_parts.append(f"mm>={flags.mm_pct:.0f}")
    if flags.speed_trigger:
        reason_parts.append("speed_trigger")
    if flags.vega_breach:
        reason_parts.append("vega_breach")
    if flags.gamma_budget_breach:
        reason_parts.append("gamma_breach")
    return " | ".join(reason_parts) or "NORMAL"


def _extract_stress_dd_before(snapshot: PortfolioSnapshot) -> Tuple[float, str]:
    """
    Extract the authoritative worst-case projected stress DD from the stress artifact.

    Priority:
      1. Deep stress (position-level B-S repricing) - most accurate
      2. Fast stress (Taylor-expansion Greeks approximation) - fallback
      3. snapshot.dd - last resort

    Returns (worst_dd, source) where source is "deep" | "fast" | "fallback".
    """
    artifact = snapshot.stress_artifact
    worst_dd, source = extract_worst_dd(artifact, fallback_dd=snapshot.dd)
    # If extraction failed (returned 0.0 but we have a real DD), fall back
    if worst_dd == 0.0 and snapshot.dd < 0:
        return snapshot.dd, "fallback"
    return worst_dd, source


# ─────────────────────────────────────────────
# Phase 4: Bundle variant generation
# ─────────────────────────────────────────────

def _generate_bundle_variants(candidates: List[CandidateAction]) -> List[List[CandidateAction]]:
    """
    Generate candidate subsets for ranking.

    Produces unique subsets ordered by preference:
      - Full set
      - Drop last action
      - Drop first action (keep rest)
      - First two only
    """
    if not candidates:
        return []

    variants: List[List[CandidateAction]] = [candidates]
    seen = {tuple(c.instrument_name for c in candidates)}

    if len(candidates) > 1:
        # Drop last
        v = candidates[:-1]
        key = tuple(c.instrument_name for c in v)
        if key not in seen:
            variants.append(v)
            seen.add(key)

        # Drop first
        v = candidates[1:]
        key = tuple(c.instrument_name for c in v)
        if key not in seen:
            variants.append(v)
            seen.add(key)

    if len(candidates) > 2:
        # First two only
        v = candidates[:2]
        key = tuple(c.instrument_name for c in v)
        if key not in seen:
            variants.append(v)
            seen.add(key)

    return variants


def _evaluate_variant(
    variant: List[CandidateAction],
    deribit: DeribitClient,
    snapshot: PortfolioSnapshot,
    before_dict: Dict[str, Any],
    reason_str: str,
    flags: RiskFlags,
    cfg: EngineConfig,
) -> Tuple[Optional[AcceptanceResult], Optional[Dict[str, Any]], float]:
    """
    Simulate + acceptance-test + score a single variant.
    Returns (acceptance_result, after_sim, score).
    """
    after_sim = simulate_bundle_impact(deribit, snapshot, variant, cfg)
    acceptance = evaluate_bundle_acceptance(
        before=before_dict,
        after=after_sim,
        mode_reasons=reason_str,
        flags=flags,
        cfg=cfg,
    )

    if acceptance.accepted:
        score_result = score_bundle_survival(
            before=before_dict,
            after=after_sim,
            flags=flags,
            cfg=cfg,
            n_actions=len(variant),
        )
        return acceptance, after_sim, score_result.total
    else:
        return acceptance, after_sim, -1.0


# ─────────────────────────────────────────────
# Phase 5: Escalation-aware candidate generation
# ─────────────────────────────────────────────

def _get_candidates_for_tier(
    tier: str,
    snapshot: PortfolioSnapshot,
    flags: RiskFlags,
    cfg: EngineConfig,
    con: sqlite3.Connection,
    deribit: DeribitClient,
) -> List[CandidateAction]:
    """
    Generate candidate actions for a specific escalation tier.

    Tier A_LIGHT: default mode-routed candidates (existing logic)
    Tier B_MEDIUM: boosted hedge ratio, more reductions, forced vega
    Tier C_STRONG: H=0.95, max reductions, forced vega+gamma
    Tier D_SURVIVAL: H=1.0, aggressive reductions, forced vega
    """
    from hedge_engine.actions.delta.delta_hedge import propose_perp_hedge
    from hedge_engine.actions.convexity.gamma_hedge import propose_gamma_hedge
    from hedge_engine.actions.convexity.tail_hedge import suggest_tail_hedge
    from hedge_engine.actions.position_management.risk_reduction import propose_risk_reduction
    from hedge_engine.actions.vega_hedge import propose_vega_hedge

    if tier == "A_LIGHT":
        return get_candidate_actions(snapshot, flags, cfg, con, deribit)

    mode = (snapshot.mode or "NORMAL").upper()
    regime = "NORMAL"
    artifact = snapshot.stress_artifact or {}
    if isinstance(artifact, dict):
        regime = str(artifact.get("regime", "NORMAL")).upper()

    max_reductions = cfg.ESCALATION_MAX_REDUCTIONS.get(tier, 3)
    actions: List[CandidateAction] = []

    if tier == "B_MEDIUM":
        h = min(flags.target_hedge_ratio_H + cfg.ESCALATION_TIER_B_H_BOOST, 1.0)
        perp = propose_perp_hedge(snapshot=snapshot, H=h, cfg=cfg)
        if perp:
            actions.append(perp)
        reductions = propose_risk_reduction(snapshot, flags, cfg, max_actions=max_reductions)
        actions.extend(reductions)
        # Forced vega hedge
        vega = propose_vega_hedge(snapshot, flags, cfg, con)
        if vega:
            actions.append(vega)
        if flags.gamma_budget_breach or flags.speed_trigger:
            gamma_list = propose_gamma_hedge(snapshot=snapshot, flags=flags, cfg=cfg)
            actions.extend(gamma_list)

    elif tier == "C_STRONG":
        h = cfg.ESCALATION_TIER_C_H
        perp = propose_perp_hedge(snapshot=snapshot, H=h, cfg=cfg)
        if perp:
            actions.append(perp)
        reductions = propose_risk_reduction(snapshot, flags, cfg, max_actions=max_reductions)
        actions.extend(reductions)
        # Forced vega + gamma
        vega = propose_vega_hedge(snapshot, flags, cfg, con)
        if vega:
            actions.append(vega)
        gamma_list = propose_gamma_hedge(snapshot=snapshot, flags=flags, cfg=cfg)
        actions.extend(gamma_list)

    elif tier == "D_SURVIVAL":
        perp = propose_perp_hedge(snapshot=snapshot, H=1.0, cfg=cfg)
        if perp:
            actions.append(perp)
        reductions = propose_risk_reduction(snapshot, flags, cfg, max_actions=max_reductions)
        actions.extend(reductions)
        # Forced vega (no gamma - preserve margin)
        vega = propose_vega_hedge(snapshot, flags, cfg, con)
        if vega:
            actions.append(vega)

    return actions


# ─────────────────────────────────────────────
# Phase 8: No valid bundle outcome
# ─────────────────────────────────────────────

def _aggregate_top_rejections(tier_results: List[Dict[str, Any]], top_n: int = 5) -> List[str]:
    """Collect the most common rejection reasons across all tiers."""
    from collections import Counter
    counts: Counter = Counter()
    for tr in tier_results:
        for r in tr.get("rejection_reasons", []):
            counts[r] += 1
    return [reason for reason, _ in counts.most_common(top_n)]


def _build_no_valid_bundle(
    snapshot: PortfolioSnapshot,
    flags: RiskFlags,
    reason_str: str,
    tier_results: List[Dict[str, Any]],
) -> ActionBundle:
    """Build an informational ActionBundle documenting that all tiers failed."""
    return ActionBundle(
        mode="NO_VALID_BUNDLE",
        reason=reason_str,
        actions=[],
        before=_build_before_metrics(snapshot),
        after_est=_build_before_metrics(snapshot),
        debug={
            "urgency": "EMERGENCY",
            "approved": False,
            "rejection_reasons": _aggregate_top_rejections(tier_results),
            "simulation_unavailable": False,
            "validation_status": "all_tiers_exhausted",
            "escalation_tiers_tested": tier_results,
            "no_valid_bundle": True,
            "n_actions": 0,
            "after_sim": {},
        },
        no_valid_bundle=True,
    )


# ─────────────────────────────────────────────
# Main entry point
# ─────────────────────────────────────────────

def build_bundle(
    snapshot: PortfolioSnapshot,
    flags: RiskFlags,
    stress: Dict[str, Any],
    cfg: EngineConfig,
    con: sqlite3.Connection,
    deribit: DeribitClient,
) -> Optional[ActionBundle]:
    """
    Full decision pipeline with escalation:
      1. Build reason string from active flags
      2. Extract correct stress_dd_before from stress artifact
      3. For each escalation tier (A → B → C → D):
         a. Generate candidate actions
         b. Generate bundle variants (subsets)
         c. Simulate each variant
         d. Acceptance-test each variant (hard gates + reason coverage)
         e. Score accepted variants (survival-first)
         f. If best accepted variant found → return bundle
      4. If all tiers fail → return NO_VALID_BUNDLE
    """
    t0 = time.monotonic()
    mode = (snapshot.mode or "NORMAL").upper()
    urgency = _mode_to_urgency(mode)
    reason_str = _build_reason_str(flags, cfg)

    # Use the authoritative stress truth (deep > fast > fallback)
    stress_dd_before, stress_dd_source = _extract_stress_dd_before(snapshot)

    # Build reconciliation for debug (Phase 3)
    reconciliation = reconcile_fast_deep(snapshot.stress_artifact)

    before_dict = {
        "mm_pct": snapshot.mm_pct,
        "stress_dd": stress_dd_before,
        "stress_dd_source": stress_dd_source,
        "delta": snapshot.portfolio_delta_btc,
        "gamma": snapshot.portfolio_gamma,
        "vega": snapshot.portfolio_vega,
    }

    # Determine which tiers to try
    escalation_enabled = bool(getattr(cfg, "ESCALATION_ENABLED", True))
    tiers_to_try = TIER_ORDER if escalation_enabled else ["A_LIGHT"]

    # For NORMAL mode, only try tier A (no escalation needed)
    if mode == "NORMAL":
        tiers_to_try = ["A_LIGHT"]

    tier_results: List[Dict[str, Any]] = []
    best_bundle: Optional[ActionBundle] = None
    best_candidates: Optional[List[CandidateAction]] = None
    best_after_sim: Optional[Dict[str, Any]] = None
    best_acceptance: Optional[AcceptanceResult] = None
    best_score: float = -1.0
    winning_tier: Optional[str] = None

    for tier in tiers_to_try:
        candidates = _get_candidates_for_tier(
            tier, snapshot, flags, cfg, con, deribit,
        )
        if not candidates:
            tier_results.append({
                "tier": tier,
                "n_candidates": 0,
                "accepted": False,
                "rejection_reasons": ["no_candidates_generated"],
                "score": -1.0,
            })
            continue

        # Cap at 5 actions per tier (higher tiers can have more)
        max_actions = cfg.ESCALATION_MAX_REDUCTIONS.get(tier, 3) + 2  # reductions + perp + hedge
        candidates = candidates[:max_actions]

        # Phase 8: Generate expanded variants (different perp sizes + subsets)
        from hedge_engine.actions.candidate_expander import expand_candidates_for_tier
        expanded_bundles = expand_candidates_for_tier(
            base_candidates=candidates,
            snapshot=snapshot,
            flags=flags,
            cfg=cfg,
        )
        # Also add subset variants for each expanded bundle
        variants = []
        for bundle in expanded_bundles:
            variants.extend(_generate_bundle_variants(bundle))
        # Deduplicate by instrument set + qty
        seen_keys = set()
        unique_variants = []
        for v in variants:
            key = tuple(
                (c.instrument_name, c.side.value, c.qty_btc, c.qty_contracts)
                for c in v
            )
            if key not in seen_keys:
                seen_keys.add(key)
                unique_variants.append(v)
        variants = unique_variants

        tier_best_acceptance = None
        tier_best_after_sim = None
        tier_best_score = -1.0
        tier_best_candidates = None
        tier_rejection_reasons: List[str] = []

        for variant in variants:
            acceptance, after_sim, score = _evaluate_variant(
                variant, deribit, snapshot, before_dict, reason_str, flags, cfg,
            )
            if acceptance and not acceptance.accepted:
                tier_rejection_reasons.extend(acceptance.rejection_reasons)
            if acceptance and acceptance.accepted and score > tier_best_score:
                tier_best_score = score
                tier_best_acceptance = acceptance
                tier_best_after_sim = after_sim
                tier_best_candidates = variant

        tier_accepted = tier_best_acceptance is not None and tier_best_acceptance.accepted
        tier_results.append({
            "tier": tier,
            "n_candidates": len(candidates),
            "n_variants": len(variants),
            "n_expanded_bundles": len(expanded_bundles) if expanded_bundles else 0,
            "accepted": tier_accepted,
            "rejection_reasons": list(set(tier_rejection_reasons)) if not tier_accepted else [],
            "score": round(tier_best_score, 6) if tier_accepted else -1.0,
        })

        if tier_accepted and tier_best_score > best_score:
            best_score = tier_best_score
            best_candidates = tier_best_candidates
            best_after_sim = tier_best_after_sim
            best_acceptance = tier_best_acceptance
            winning_tier = tier
            break  # Stop at first tier that produces an accepted bundle

    elapsed_ms = (time.monotonic() - t0) * 1000.0

    # Build the final bundle
    if best_candidates and best_after_sim and best_acceptance:
        actions = [_candidate_to_action(c) for c in best_candidates]
        before_metrics = _build_before_metrics(snapshot)
        after_metrics = _build_after_metrics(best_after_sim, snapshot)

        bundle = ActionBundle(
            mode=mode,
            reason=reason_str,
            actions=actions,
            before=before_metrics,
            after_est=after_metrics,
            debug={
                "urgency": urgency,
                "approved": True,
                "rejection_reasons": [],
                "simulation_unavailable": not bool(best_after_sim.get("sim_ok", True)),
                "validation_status": "accepted",
                "after_est_source": best_after_sim.get("after_est_source", "simulate"),
                "delta_after_source": best_after_sim.get("delta_after_source"),
                "sim_error": best_after_sim.get("sim_error"),
                "n_actions": len(actions),
                "after_sim": best_after_sim,
                "escalation_tier": winning_tier,
                "escalation_tiers_tested": tier_results,
                "acceptance_metrics": best_acceptance.metrics,
                "bundle_score": best_score,
                "stress_dd_before": stress_dd_before,
                "stress_dd_before_source": stress_dd_source,
                "stress_dd_after": best_after_sim.get("stress_dd_after"),
                "stress_dd_after_source": best_after_sim.get("stress_dd_after_source", "fast"),
                "equity_after": best_after_sim.get("equity_after"),
                "equity_after_source": best_after_sim.get("equity_after_source"),
                "stress_scenario_details": best_after_sim.get("stress_scenario_details"),
                "reconciliation": {
                    "truth_source": reconciliation.get("truth_source"),
                    "fast_worst_dd": reconciliation.get("fast_worst_dd"),
                    "deep_worst_dd": reconciliation.get("deep_worst_dd"),
                    "deep_available": reconciliation.get("deep_available"),
                    "max_abs_pnl_diff": reconciliation.get("max_abs_pnl_diff"),
                },
                "elapsed_ms": round(elapsed_ms, 1),
            },
        )
        _log_bundle(con, snapshot, bundle, before_dict, best_after_sim)
        _log_telemetry(con, mode, reason_str, flags, tier_results, bundle, elapsed_ms, cfg)
        return bundle

    # No accepted bundle from any tier
    if mode == "NORMAL":
        # NORMAL mode with no valid bundle is fine - just return None
        return None

    no_valid = _build_no_valid_bundle(snapshot, flags, reason_str, tier_results)
    _log_bundle(con, snapshot, no_valid, before_dict, {})
    _log_telemetry(con, mode, reason_str, flags, tier_results, no_valid, elapsed_ms, cfg)
    return no_valid


# ─────────────────────────────────────────────
# Logging
# ─────────────────────────────────────────────

def _log_bundle(
    con: sqlite3.Connection,
    snapshot: PortfolioSnapshot,
    bundle: ActionBundle,
    before: Dict[str, Any],
    after_sim: Dict[str, Any],
) -> None:
    """Log bundle to hedge_decisions_log for ML data collection."""
    ts = datetime.now(timezone.utc).isoformat()
    try:
        actions_list = [{"cmd": a.cmd, "meta": a.meta} for a in bundle.actions]
        con.execute(
            """
            INSERT OR REPLACE INTO hedge_decisions_log
              (ts_utc, mode, actions_json, before_json, after_json,
               stress_dd_before, stress_dd_after, mm_before, mm_after, outcome)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                ts,
                bundle.mode,
                json.dumps(actions_list, default=str),
                json.dumps(before, default=str),
                json.dumps(after_sim, default=str),
                float(before.get("stress_dd", 0)),
                float(after_sim.get("stress_dd_after", 0)),
                float(before.get("mm_pct", 0)),
                float(after_sim.get("mm_pct_after", 0)),
                "",
            ),
        )
        con.commit()
    except Exception:
        pass  # table may not exist yet


# ─────────────────────────────────────────────
# Phase 9: Decision telemetry
# ─────────────────────────────────────────────

def _log_telemetry(
    con: sqlite3.Connection,
    mode: str,
    reason_str: str,
    flags: RiskFlags,
    tier_results: List[Dict[str, Any]],
    bundle: ActionBundle,
    elapsed_ms: float,
    cfg: EngineConfig,
) -> None:
    """Persist structured decision telemetry to DB and log."""
    if not getattr(cfg, "TELEMETRY_ENABLED", True):
        return

    ts = datetime.now(timezone.utc).isoformat()
    cycle = {
        "ts_utc": ts,
        "mode": mode,
        "mode_reasons": reason_str,
        "flags_summary": {
            "dd_abs_pct": flags.dd_abs_pct,
            "mm_pct": flags.mm_pct,
            "mm_state": flags.mm_state,
            "vega_breach": flags.vega_breach,
            "gamma_budget_breach": flags.gamma_budget_breach,
            "speed_trigger": flags.speed_trigger,
            "target_hedge_ratio_H": flags.target_hedge_ratio_H,
        },
        "escalation_tiers": tier_results,
        "final_bundle_mode": bundle.mode,
        "final_n_actions": len(bundle.actions),
        "no_valid_bundle": getattr(bundle, "no_valid_bundle", False),
        "bundle_score": bundle.debug.get("bundle_score"),
        "winning_tier": bundle.debug.get("escalation_tier"),
        "acceptance_metrics": bundle.debug.get("acceptance_metrics"),
        "elapsed_ms": round(elapsed_ms, 1),
    }

    logger.info("decision_telemetry: %s", json.dumps(cycle, default=str))

    try:
        con.execute(
            """
            CREATE TABLE IF NOT EXISTS hedge_decisions_telemetry (
                ts_utc TEXT PRIMARY KEY,
                mode TEXT,
                cycle_json TEXT,
                elapsed_ms REAL
            )
            """,
        )
        con.execute(
            "INSERT OR REPLACE INTO hedge_decisions_telemetry (ts_utc, mode, cycle_json, elapsed_ms) VALUES (?, ?, ?, ?)",
            (ts, mode, json.dumps(cycle, default=str), round(elapsed_ms, 1)),
        )
        con.commit()
    except Exception:
        pass
