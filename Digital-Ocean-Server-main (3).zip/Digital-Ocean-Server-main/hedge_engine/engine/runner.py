# hedge_engine/engine/runner.py
from __future__ import annotations

import json
import logging
import time
import traceback
from dataclasses import asdict
from datetime import datetime, timezone
from typing import Any, Dict, Optional

from hedge_engine.core.models import PortfolioSnapshot, Position, GreekProfile, HedgeTick
from hedge_engine.core.snapshot_builder import (
    fetch_and_persist_ticks_from_deribit,
    build_engine_inputs_from_engine_db,
)
from hedge_engine.data.deribit_client import DeribitClient
from hedge_engine.data.state_store import (
    open_sqlite, insert_hedge_tick,
    load_hwm_usd,
    load_mode_state, save_mode_state,
)
from hedge_engine.engine.bundle_builder import build_bundle
from hedge_engine.notifications.notifier import TelegramNotifier
from hedge_engine.risk.risk_checks import (
    compute_flags, compute_greek_targets,
    decide_desired_mode_from_flags, apply_mode_hysteresis,
)
from hedge_engine.risk.stress import compute_stress_artifact
from hedge_engine.settings.config import EngineConfig, load_config
from hedge_engine.settings.regime_rules import classify_regime, RegimeInputs
from hedge_engine.ml.regime_detector import log_regime_tick, predict as predict_regime
from hedge_engine.ml.vol_forecast import log_vol_tick
from hedge_engine.ml.hedge_optimizer import log_hedge_decision
from hedge_engine.actions.convexity.gamma_hedge import run as run_gamma
from hedge_engine.actions.vega_hedge import run as run_vega
from hedge_engine.actions.delta.delta_hedge import run as run_delta

logger = logging.getLogger(__name__)


def _utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _load_positions_from_db(con) -> list:
    """Read latest positions tick and convert to Position objects."""
    try:
        row = con.execute(
            "SELECT payload_json FROM hedge_engine_positions_ticks "
            "ORDER BY ts_utc DESC LIMIT 1"
        ).fetchone()
        if not row:
            return []
        items = json.loads(row[0])
        positions = []
        for p in (items if isinstance(items, list) else []):
            instrument_name = p.get("instrument_name", "")
            instrument_parts = instrument_name.split("-")
            parsed_option_type = instrument_parts[-1].upper() if len(instrument_parts) >= 4 else None
            if parsed_option_type not in ("C", "P"):
                parsed_option_type = None

            mark_price_btc = p.get("mark_price_btc", p.get("mark_price"))
            index_price = p.get("index_price")
            mark_price_usd = p.get("mark_price_usd")
            if mark_price_usd is None and mark_price_btc is not None and index_price:
                try:
                    mark_price_usd = float(mark_price_btc) * float(index_price)
                except Exception:
                    mark_price_usd = None

            positions.append(Position(
                instrument_name=instrument_name,
                kind=p.get("kind", "unknown"),
                size=float(p.get("size", 0)),
                net_delta=float(p.get("net_delta", p.get("delta", 0))),
                gamma=float(p.get("gamma", 0)),
                vega=float(p.get("vega", 0)),
                theta=float(p.get("theta", 0)),
                option_type=p.get("option_type") or parsed_option_type,
                strike=p.get("strike"),
                dte_days=p.get("dte_days"),
                mark_price_usd=mark_price_usd,
                mark_price_btc=mark_price_btc,
                index_price=index_price,
                delta=p.get("delta"),
                meta=p.get("meta", {}),
            ))
        return positions
    except Exception:
        return []


def _build_snapshot(inputs, positions, mode_state, stress_artifact=None) -> PortfolioSnapshot:
    """Construct PortfolioSnapshot from EngineInputs + positions + mode."""
    mode = (mode_state or {}).get("mode", "NORMAL")
    snap = PortfolioSnapshot(
        total_equity_usd=inputs.total_equity_usd,
        hwm_usd=inputs.hwm_usd,
        dd=inputs.dd,
        mm_pct=inputs.mm_pct,
        spot_index_usd=inputs.spot_index_usd,
        portfolio_delta_btc=inputs.portfolio_delta_btc,
        portfolio_gamma=inputs.portfolio_gamma,
        portfolio_vega=inputs.portfolio_vega,
        hv_30d_pct=inputs.hv_30d_pct,
        iv_atm_30d_pct=inputs.iv_atm_30d_pct,
        iv_minus_hv_30d_pp=inputs.iv_minus_hv_30d_pp,
        updated_at_utc=inputs.updated_at_utc,
        positions=positions,
        stress_artifact=stress_artifact,
        mode=mode,
        equity_usd=inputs.total_equity_usd,
    )
    return snap


def run(cfg: EngineConfig, db_path: str) -> None:
    """
    Production 30s tick loop. Runs indefinitely.

    Pipeline per tick:
      1. fetch_and_persist_ticks_from_deribit()
      2. build_engine_inputs_from_engine_db()
      3. Build PortfolioSnapshot (enrich with positions)
      4. compute_flags()
      5. mode hysteresis → save mode state
      6. compute_stress_artifact()
      7. build_bundle() (decision tree + X:PM sim + validation)
      8. if bundle: notifier.notify_bundle(bundle)
      9. insert_hedge_tick()
      10. sleep(cfg.tick_seconds)
    """
    deribit = DeribitClient.from_env()
    notifier = TelegramNotifier.from_env()

    logging.basicConfig(level=logging.INFO,
                        format="%(asctime)s %(levelname)s %(name)s %(message)s")
    logger.info("MHE runner starting. db=%s tick=%ds", db_path, cfg.tick_seconds)

    while True:
        tick_start = time.time()
        ts = _utc_now_iso()

        try:
            con = open_sqlite(db_path)

            # 1. Fetch live data from Deribit
            fetch_and_persist_ticks_from_deribit(deribit=deribit, con=con)

            # 2. Build engine inputs from DB (also updates HWM internally)
            inputs = build_engine_inputs_from_engine_db(con=con, logger=logger).inputs

            # 3. Load positions + build snapshot
            positions = _load_positions_from_db(con)
            mode_state = load_mode_state(con=con)
            snapshot = _build_snapshot(inputs, positions, mode_state)

            # 4. Compute risk flags
            flags = compute_flags(snapshot=snapshot, state=inputs, cfg=cfg, con=con)

            # 5. Mode hysteresis
            desired_mode, desired_reason = decide_desired_mode_from_flags(asdict(flags))
            final_mode, final_reason, safe_streak, _ = apply_mode_hysteresis(
                desired_mode=desired_mode,
                desired_reason=desired_reason,
                prior_mode_state=mode_state,
            )
            new_mode_state = {
                "mode": final_mode,
                "last_reason": final_reason,
                "safe_streak": safe_streak,
                "last_change_ts_utc": ts,
            }
            save_mode_state(con=con, mode_state=new_mode_state)
            snapshot = _build_snapshot(inputs, positions, new_mode_state)

            # 6. Stress artifact
            stress = compute_stress_artifact(
                snapshot=snapshot, state=inputs, flags=flags, cfg=cfg,
            )
            snapshot = _build_snapshot(inputs, positions, new_mode_state, stress)

            # 7. Hedge pipeline (sub-engine or legacy bundle builder)
            if getattr(cfg, "SUB_ENGINE_ENABLED", True):
                # ── NEW: Sequential Greek Sub-Engine Pipeline ──────────────
                greek_profile = GreekProfile(
                    delta_btc=snapshot.portfolio_delta_btc,
                    gamma=snapshot.portfolio_gamma,
                    vega=snapshot.portfolio_vega,
                    equity_usd=snapshot.total_equity_usd,
                    spot_usd=snapshot.spot_index_usd,
                    mm_pct=snapshot.mm_pct,
                    dd=snapshot.dd,
                )
                targets = compute_greek_targets(
                    flags=flags, snapshot=snapshot, cfg=cfg,
                )
                suggestion_gamma = run_gamma(
                    greek_profile=greek_profile, targets=targets,
                    positions=positions, snapshot=snapshot,
                    cfg=cfg, deribit=deribit, con=con,
                )
                suggestion_vega = run_vega(
                    greek_profile=greek_profile, targets=targets,
                    positions=positions, snapshot=snapshot,
                    cfg=cfg, deribit=deribit, con=con,
                    gamma_suggestion=suggestion_gamma,
                )
                suggestion_delta = run_delta(
                    greek_profile=greek_profile, targets=targets,
                    gamma_suggestion=suggestion_gamma,
                    vega_suggestion=suggestion_vega,
                    snapshot=snapshot, cfg=cfg, deribit=deribit,
                )
                # Combined post-state: aggregate all suggestion impacts additively
                all_suggestions = [suggestion_gamma, suggestion_vega, suggestion_delta]
                active_suggestions = [s for s in all_suggestions if s and s.method != "no_action"]

                total_delta_impact = sum(s.delta_impact for s in active_suggestions)
                total_gamma_impact = sum(s.gamma_impact for s in active_suggestions)
                total_vega_impact  = sum(s.vega_impact  for s in active_suggestions)

                # MM%: use the last engine's post_mm (delta runs last, most complete sim view)
                last_active = next(
                    (s for s in [suggestion_delta, suggestion_vega, suggestion_gamma]
                     if s and s.method != "no_action"),
                    None,
                )
                combined_post = {
                    "mm_pct": last_active.post_mm_pct if last_active else greek_profile.mm_pct,
                    "delta":  greek_profile.delta_btc + total_delta_impact,
                    "gamma":  greek_profile.gamma     + total_gamma_impact,
                    "vega":   greek_profile.vega      + total_vega_impact,
                }
                hedge_tick = HedgeTick(
                    greek_profile=greek_profile,
                    targets=targets,
                    suggestion_gamma=suggestion_gamma,
                    suggestion_vega=suggestion_vega,
                    suggestion_delta=suggestion_delta,
                    combined_post_state=combined_post,
                    any_fallback_triggered=any(
                        s.fallback_used for s in
                        [suggestion_gamma, suggestion_vega, suggestion_delta]
                        if s and s.method != "no_action"
                    ),
                    timestamp=datetime.now(timezone.utc),
                )

                # 8. Notify
                notifier.notify_hedge_tick(hedge_tick)
                logger.info(
                    "HedgeTick: gamma=%s vega=%s delta=%s fallback=%s",
                    suggestion_gamma.method, suggestion_vega.method,
                    suggestion_delta.method, hedge_tick.any_fallback_triggered,
                )

                # 9. Persist tick
                insert_hedge_tick(
                    con=con,
                    ts_utc=ts,
                    snapshot_json=json.dumps({
                        "equity": inputs.total_equity_usd,
                        "dd": inputs.dd,
                        "mm_pct": inputs.mm_pct,
                        "delta": inputs.portfolio_delta_btc,
                    }),
                    flags_json=json.dumps({
                        "mode": final_mode,
                        "vega_breach": flags.vega_breach,
                        "gamma_breach": flags.gamma_budget_breach,
                        "speed_trigger": flags.speed_trigger,
                        "H": flags.target_hedge_ratio_H,
                        "sub_engine": True,
                    }),
                    stress_json=json.dumps(stress, default=str) if stress else None,
                )

                # 10. ML data collection (never blocks engine)
                try:
                    _ml_label = predict_regime(con)
                    if _ml_label is None:
                        _det = classify_regime(RegimeInputs(
                            hv_30d_pct=inputs.hv_30d_pct,
                            iv_atm_30d_pct=inputs.iv_atm_30d_pct,
                            iv_minus_hv_30d_pp=inputs.iv_minus_hv_30d_pp,
                            spot_move_24h_pct=inputs.spot_move_24h_pct,
                            hv_30d_change_7d_pct=inputs.hv_30d_change_7d_pct,
                        ))
                        _ml_label = _det.regime
                    log_regime_tick(
                        con=con, ts=ts,
                        hv30=inputs.hv_30d_pct, iv30=inputs.iv_atm_30d_pct,
                        iv_minus_hv=inputs.iv_minus_hv_30d_pp,
                        spot_move_24h=inputs.spot_move_24h_pct,
                        funding_rate=0.0, regime_label=_ml_label,
                    )
                    log_vol_tick(
                        con=con, ts=ts,
                        hv30=inputs.hv_30d_pct, iv30=inputs.iv_atm_30d_pct,
                        btc_price=inputs.spot_index_usd,
                    )
                except Exception:
                    pass

                if last_active:
                    try:
                        log_hedge_decision(
                            con=con, ts=ts,
                            mode=final_mode,
                            actions_json=json.dumps([
                                {"engine": s.engine, "instrument": s.instrument,
                                 "direction": s.direction, "size": s.size}
                                for s in [suggestion_gamma, suggestion_vega, suggestion_delta]
                                if s and s.method != "no_action"
                            ]),
                            before_json=json.dumps({
                                "delta": greek_profile.delta_btc,
                                "vega": greek_profile.vega,
                                "mm_pct": greek_profile.mm_pct,
                            }),
                            after_json=json.dumps(combined_post),
                            stress_dd_before=float(stress.get("dd_30pct", 0.0)) if stress else 0.0,
                            stress_dd_after=0.0,
                            mm_before=greek_profile.mm_pct,
                            mm_after=combined_post.get("mm_pct", greek_profile.mm_pct),
                        )
                    except Exception:
                        pass

            else:
                # ── LEGACY: Bundle builder (fallback when SUB_ENGINE_ENABLED=False) ──
                bundle = build_bundle(
                    snapshot=snapshot, flags=flags, stress=stress,
                    cfg=cfg, con=con, deribit=deribit,
                )

                # 8. Notify
                if bundle:
                    notifier.notify_bundle(bundle)
                    logger.info("Bundle sent: mode=%s actions=%d", bundle.mode, len(bundle.actions))

                # 9. Persist tick
                insert_hedge_tick(
                    con=con,
                    ts_utc=ts,
                    snapshot_json=json.dumps({
                        "equity": inputs.total_equity_usd,
                        "dd": inputs.dd,
                        "mm_pct": inputs.mm_pct,
                        "delta": inputs.portfolio_delta_btc,
                    }),
                    flags_json=json.dumps({
                        "mode": new_mode_state.get("mode"),
                        "vega_breach": flags.vega_breach,
                        "gamma_breach": flags.gamma_budget_breach,
                        "speed_trigger": flags.speed_trigger,
                        "H": flags.target_hedge_ratio_H,
                    }),
                    stress_json=json.dumps(stress, default=str) if stress else None,
                )

                # 10. ML data collection (never blocks engine)
                try:
                    _ml_label = predict_regime(con)
                    if _ml_label is None:
                        _det = classify_regime(RegimeInputs(
                            hv_30d_pct=inputs.hv_30d_pct,
                            iv_atm_30d_pct=inputs.iv_atm_30d_pct,
                            iv_minus_hv_30d_pp=inputs.iv_minus_hv_30d_pp,
                            spot_move_24h_pct=inputs.spot_move_24h_pct,
                            hv_30d_change_7d_pct=inputs.hv_30d_change_7d_pct,
                        ))
                        _ml_label = _det.regime
                    log_regime_tick(
                        con=con, ts=ts,
                        hv30=inputs.hv_30d_pct, iv30=inputs.iv_atm_30d_pct,
                        iv_minus_hv=inputs.iv_minus_hv_30d_pp,
                        spot_move_24h=inputs.spot_move_24h_pct,
                        funding_rate=0.0, regime_label=_ml_label,
                    )
                    log_vol_tick(
                        con=con, ts=ts,
                        hv30=inputs.hv_30d_pct, iv30=inputs.iv_atm_30d_pct,
                        btc_price=inputs.spot_index_usd,
                    )
                except Exception:
                    pass

                if bundle:
                    try:
                        log_hedge_decision(
                            con=con, ts=ts,
                            mode=bundle.mode or "NORMAL",
                            actions_json=json.dumps([str(a) for a in bundle.actions]),
                            before_json=json.dumps({
                                "delta": snapshot.portfolio_delta_btc,
                                "vega": snapshot.portfolio_vega,
                                "mm_pct": snapshot.mm_pct,
                            }),
                            after_json="{}",
                            stress_dd_before=float(stress.get("dd_30pct", 0.0)) if stress else 0.0,
                            stress_dd_after=0.0,
                            mm_before=snapshot.mm_pct,
                            mm_after=snapshot.mm_pct,
                        )
                    except Exception:
                        pass

            con.close()

        except Exception:
            logger.error("Tick error:\n%s", traceback.format_exc())
            # Never break the loop on any error

        elapsed = time.time() - tick_start
        sleep_s = max(0, cfg.tick_seconds - elapsed)
        logger.info("Tick done in %.1fs, sleeping %.1fs", elapsed, sleep_s)
        time.sleep(sleep_s)


if __name__ == "__main__":
    cfg = load_config()
    run(cfg, str(cfg.db_path))
