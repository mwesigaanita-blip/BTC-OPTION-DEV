"""Phase 5 smoke client - connects to backend_ws and prints incoming frames.

Reads INTERNAL_API_KEY (or BACKEND_WS_INTERNAL_API_KEY) from env. Designed to
run from the same docker network as backend_ws so it can use the service name.

Usage (inside docker network):
  python -m backend_ws.tools.ws_smoke account
  python -m backend_ws.tools.ws_smoke market
  python -m backend_ws.tools.ws_smoke positions
  python -m backend_ws.tools.ws_smoke alerts

Defaults: ws://backend_ws:8100, key from $BACKEND_WS_INTERNAL_API_KEY or
$INTERNAL_API_KEY. Override with WS_SMOKE_URL / WS_SMOKE_KEY.
"""
from __future__ import annotations

import argparse
import asyncio
import os
import sys

import websockets

try:
    from dotenv import load_dotenv

    load_dotenv()
except Exception:
    pass

ROUTES = ("account", "positions", "market", "alerts")


def _resolve_key() -> str:
    return (
        os.getenv("WS_SMOKE_KEY")
        or os.getenv("BACKEND_WS_INTERNAL_API_KEY")
        or os.getenv("INTERNAL_API_KEY")
        or ""
    )


async def _amain(route: str, max_messages: int) -> int:
    base = os.getenv("WS_SMOKE_URL", "ws://backend_ws:8100")
    url = f"{base}/ws/{route}"
    key = _resolve_key()
    if not key:
        print(
            "ERROR: no INTERNAL_API_KEY in env. Set WS_SMOKE_KEY or "
            "INTERNAL_API_KEY before running.",
            file=sys.stderr,
        )
        return 2
    print(f"connecting: {url}  (key set: yes)")
    headers = {"X-Internal-API-Key": key}
    async with websockets.connect(url, extra_headers=headers) as ws:
        print("connected - waiting for messages...")
        n = 0
        async for raw in ws:
            n += 1
            print(f"--- msg {n} ({len(raw)} bytes) ---")
            print(raw)
            if max_messages and n >= max_messages:
                print(f"reached --max-messages={max_messages}, exiting.")
                return 0
    return 0


def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument("route", choices=ROUTES)
    p.add_argument("--max-messages", type=int, default=3)
    args = p.parse_args()
    try:
        return asyncio.run(_amain(args.route, args.max_messages))
    except KeyboardInterrupt:
        return 0


if __name__ == "__main__":
    sys.exit(main())
