"""Track open WebSocket clients across all routes.

Useful for:
  - reporting active client count on /healthz / /metrics
  - graceful shutdown (close all sockets cleanly on SIGTERM)
"""
from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass, field

from fastapi import WebSocket

log = logging.getLogger("backend_ws.connection_mgr")


@dataclass
class ConnectionManager:
    _connections: set[WebSocket] = field(default_factory=set, repr=False)
    _lock: asyncio.Lock = field(default_factory=asyncio.Lock, repr=False)

    async def add(self, ws: WebSocket) -> None:
        async with self._lock:
            self._connections.add(ws)
        log.info("ws client connected (total=%d)", len(self._connections))

    async def remove(self, ws: WebSocket) -> None:
        async with self._lock:
            self._connections.discard(ws)
        log.info("ws client disconnected (total=%d)", len(self._connections))

    @property
    def count(self) -> int:
        return len(self._connections)

    async def close_all(self, *, code: int = 1001, reason: str = "server shutdown") -> None:
        async with self._lock:
            victims = list(self._connections)
            self._connections.clear()
        for ws in victims:
            try:
                await ws.close(code=code, reason=reason)
            except Exception:
                pass
        log.info("closed %d ws connection(s) on shutdown", len(victims))
