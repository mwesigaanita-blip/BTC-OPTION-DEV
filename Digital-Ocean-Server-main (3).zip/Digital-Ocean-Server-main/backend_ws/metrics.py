"""Prometheus counters/gauges for the WS fanout server (plan §7 Phase 8).

Exposed via GET /metrics on the existing FastAPI app.
"""
from __future__ import annotations

from prometheus_client import Counter, Gauge

ws_clients_active = Gauge(
    "backend_ws_clients_active",
    "Number of currently connected WebSocket clients, by route.",
    ["route"],
)

ws_clients_total = Counter(
    "backend_ws_clients_total",
    "Total WebSocket client connections accepted, by route.",
    ["route"],
)

fanout_messages_total = Counter(
    "backend_ws_fanout_messages_total",
    "Number of pub/sub messages forwarded to ws clients, by topic.",
    ["topic"],
)

fanout_drops_total = Counter(
    "backend_ws_fanout_drops_total",
    "Number of pub/sub messages dropped because a client queue was full.",
    ["topic"],
)

redis_ping_failures_total = Counter(
    "backend_ws_redis_ping_failures_total",
    "Number of failed Redis PINGs reported by /healthz.",
)

# Redis pubsub subscription downtime - per-topic gap between losing the
# subscription (exception in pubsub.listen) and resubscribing successfully.
redis_sub_reconnects_total = Counter(
    "backend_ws_redis_sub_reconnects_total",
    "Number of times the per-topic Redis pubsub subscription was re-established.",
    ["topic"],
)

redis_sub_last_downtime_seconds = Gauge(
    "backend_ws_redis_sub_last_downtime_seconds",
    "Duration of the most recent Redis pubsub disconnect→resubscribe gap.",
    ["topic"],
)

redis_sub_longest_downtime_seconds = Gauge(
    "backend_ws_redis_sub_longest_downtime_seconds",
    "Longest Redis pubsub disconnect→resubscribe gap observed since start.",
    ["topic"],
)

redis_sub_downtime_seconds_total = Counter(
    "backend_ws_redis_sub_downtime_seconds_total",
    "Cumulative seconds the per-topic Redis pubsub subscription was down.",
    ["topic"],
)

redis_sub_current_downtime_seconds = Gauge(
    "backend_ws_redis_sub_current_downtime_seconds",
    "Seconds since the current per-topic outage began, or 0 if subscribed.",
    ["topic"],
)
