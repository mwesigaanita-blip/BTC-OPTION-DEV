"""Uvicorn entrypoint for backend_ws."""
from __future__ import annotations

import sys

import uvicorn

from .config import load_config


def main() -> int:
    cfg = load_config()
    uvicorn.run(
        "backend_ws.main:app",
        host="0.0.0.0",
        port=cfg.port,
        log_level="info",
        access_log=False,
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
