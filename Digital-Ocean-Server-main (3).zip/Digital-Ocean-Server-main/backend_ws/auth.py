"""WS auth: shared-secret header check OR browser JWT.

Two accepted credentials on every ws route:
  * `X-Internal-API-Key: <INTERNAL_API_KEY>` header - service-to-service.
  * `?token=<jwt>` query-param - browser clients (React). Browsers cannot set
    custom headers on a `WebSocket`, so the JWT issued by `backend_api`
    (`/api/auth/login`) is passed as a query-param instead. Validated with the
    shared `JWT_SECRET`.
"""
from __future__ import annotations

import logging
import os
from typing import Mapping

import jwt

log = logging.getLogger("backend_ws.auth")

HEADER_NAME = "x-internal-api-key"
JWT_ALGORITHM = "HS256"


def check_api_key(headers: Mapping[str, str], expected: str) -> bool:
    """Return True iff `headers[HEADER_NAME]` matches `expected`.

    `expected` empty string → reject everything (no auth-bypass on
    misconfiguration). `headers` is case-insensitive on FastAPI/Starlette.
    """
    if not expected:
        log.warning("INTERNAL_API_KEY not configured - rejecting ws connect")
        return False
    provided = headers.get(HEADER_NAME) or headers.get(HEADER_NAME.upper()) or ""
    return provided == expected


def check_jwt(token: str) -> bool:
    """Return True iff `token` is a valid, unexpired JWT signed with JWT_SECRET.

    Missing `JWT_SECRET` → reject (no auth-bypass on misconfiguration).
    """
    secret = os.getenv("JWT_SECRET", "").strip()
    if not secret or not token:
        return False
    try:
        jwt.decode(token, secret, algorithms=[JWT_ALGORITHM])
        return True
    except jwt.PyJWTError:
        return False
