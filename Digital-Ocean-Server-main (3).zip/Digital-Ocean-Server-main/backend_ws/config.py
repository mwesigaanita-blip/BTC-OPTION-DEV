"""Env-driven config for backend_ws."""
from __future__ import annotations

import os
from dataclasses import dataclass

try:
    from dotenv import load_dotenv

    load_dotenv()
except Exception:
    pass


@dataclass(frozen=True)
class Config:
    port: int
    redis_url: str
    redis_pubsub_prefix: str
    internal_api_key: str


def load_config() -> Config:
    port_raw = os.getenv("BACKEND_WS_PORT", "8100").strip() or "8100"
    # Prefer BACKEND_WS_INTERNAL_API_KEY, but treat empty-string as unset so
    # the .env template line `BACKEND_WS_INTERNAL_API_KEY=` falls back to
    # the existing INTERNAL_API_KEY (per plan §1).
    api_key = os.getenv("BACKEND_WS_INTERNAL_API_KEY", "").strip()
    if not api_key:
        api_key = os.getenv("INTERNAL_API_KEY", "").strip()
    return Config(
        port=int(port_raw),
        redis_url=os.getenv("REDIS_URL", "redis://redis:6379/0"),
        redis_pubsub_prefix=os.getenv("REDIS_PUBSUB_PREFIX", ""),
        internal_api_key=api_key,
    )
