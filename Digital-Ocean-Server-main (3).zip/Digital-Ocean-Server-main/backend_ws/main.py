"""FastAPI app - pattern reproduced from backend_api/main.py (NOT imported).

Phase 1: /healthz only.
Phase 5 (added): /ws/account, /ws/positions, /ws/market, /ws/alerts -
each forwards a Redis pub/sub topic to authenticated WebSocket clients.
"""
from __future__ import annotations

import logging
from typing import Optional

import redis.asyncio as aioredis
from fastapi import FastAPI

from .config import load_config
from .connection_mgr import ConnectionManager
from .redis_bridge import RedisFanout
from .routes.http_health import router as health_router
from .routes.ws_account import router as ws_account_router
from .routes.ws_alerts import router as ws_alerts_router
from .routes.ws_market import router as ws_market_router
from .routes.ws_positions import router as ws_positions_router

logging.basicConfig(level=logging.INFO, force=True)
log = logging.getLogger("backend_ws")

app = FastAPI(title="BTC Backend WS", version="0.5.0")
app.include_router(health_router)
app.include_router(ws_account_router)
app.include_router(ws_positions_router)
app.include_router(ws_market_router)
app.include_router(ws_alerts_router)


@app.on_event("startup")
async def on_startup() -> None:
    cfg = load_config()
    app.state.config = cfg
    app.state.redis = aioredis.from_url(cfg.redis_url, decode_responses=True)
    app.state.fanout = RedisFanout(redis=app.state.redis, pubsub_prefix=cfg.redis_pubsub_prefix)
    app.state.connections = ConnectionManager()
    log.info(
        "backend_ws started: redis=%s port=%s api_key_set=%s",
        cfg.redis_url,
        cfg.port,
        bool(cfg.internal_api_key),
    )


@app.on_event("shutdown")
async def on_shutdown() -> None:
    conn_mgr: Optional[ConnectionManager] = getattr(app.state, "connections", None)
    if conn_mgr is not None:
        await conn_mgr.close_all()
    fanout: Optional[RedisFanout] = getattr(app.state, "fanout", None)
    if fanout is not None:
        await fanout.close()
    client: Optional[aioredis.Redis] = getattr(app.state, "redis", None)
    if client is not None:
        try:
            await client.aclose()
        except Exception:
            pass
    log.info("backend_ws stopped")
