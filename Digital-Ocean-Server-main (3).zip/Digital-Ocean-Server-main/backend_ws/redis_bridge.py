"""Redis pub/sub → in-process fanout to many WS clients.

One pubsub task per topic, regardless of how many ws clients are connected.
Each ws client gets its own bounded asyncio.Queue; the topic task pushes the
incoming Redis message to every queue and drops on slow consumers
(`asyncio.QueueFull`) so one stuck client can't block the rest.

Why a single shared task per topic instead of one Redis subscription per ws
client: Phase 5 exit criterion is 100 concurrent ws clients all receiving
identical messages within 50 ms. With per-client subscriptions that's 100
TCP connections to Redis per topic; with shared fanout it's exactly 1.
"""
from __future__ import annotations

import asyncio
import logging
import random
import time
from dataclasses import dataclass, field
from typing import Optional

import redis.asyncio as aioredis

from .metrics import (
    fanout_drops_total,
    fanout_messages_total,
    redis_sub_current_downtime_seconds,
    redis_sub_downtime_seconds_total,
    redis_sub_last_downtime_seconds,
    redis_sub_longest_downtime_seconds,
    redis_sub_reconnects_total,
)

# Backoff bounds for the per-topic resubscribe loop.
_RESUB_BASE_S = 1.0
_RESUB_CAP_S = 30.0

log = logging.getLogger("backend_ws.redis_bridge")

QUEUE_MAXSIZE = 256
"""Per-client buffer. If a ws client falls behind, we drop messages rather
than block the fanout. 256 messages on app.market at 1 msg/s = ~4 min of
slack before drops start."""


@dataclass
class RedisFanout:
    redis: aioredis.Redis
    pubsub_prefix: str = ""

    _subscribers: dict[str, list[asyncio.Queue]] = field(default_factory=dict, repr=False)
    _tasks: dict[str, asyncio.Task] = field(default_factory=dict, repr=False)
    _lock: asyncio.Lock = field(default_factory=asyncio.Lock, repr=False)
    _closed: bool = field(default=False, repr=False)

    # Per-topic downtime tracking. `_disconnected_at` holds the timestamp of
    # the last subscription drop (0 == currently subscribed). The longest
    # gap observed is mirrored in memory so /healthz can read it without
    # parsing Prometheus.
    _disconnected_at: dict[str, float] = field(default_factory=dict, repr=False)
    _last_downtime_s: dict[str, float] = field(default_factory=dict, repr=False)
    _longest_downtime_s: dict[str, float] = field(default_factory=dict, repr=False)
    _total_downtime_s: dict[str, float] = field(default_factory=dict, repr=False)

    def _topic_with_prefix(self, topic: str) -> str:
        return f"{self.pubsub_prefix}{topic}" if self.pubsub_prefix else topic

    async def subscribe(self, topic: str) -> asyncio.Queue:
        """Register interest in `topic`. Returns a queue that will receive
        every JSON-string payload published to it. Caller must `unsubscribe`
        when done."""
        if self._closed:
            raise RuntimeError("RedisFanout is closed")
        q: asyncio.Queue = asyncio.Queue(maxsize=QUEUE_MAXSIZE)
        async with self._lock:
            if topic not in self._subscribers:
                self._subscribers[topic] = []
                self._tasks[topic] = asyncio.create_task(
                    self._pubsub_loop(topic), name=f"fanout:{topic}"
                )
            self._subscribers[topic].append(q)
            log.info("subscribed: topic=%s clients=%d", topic, len(self._subscribers[topic]))
        return q

    async def unsubscribe(self, topic: str, q: asyncio.Queue) -> None:
        async with self._lock:
            subs = self._subscribers.get(topic)
            if subs and q in subs:
                subs.remove(q)
                log.info("unsubscribed: topic=%s clients=%d", topic, len(subs))
            # Keep the pubsub task running even if subs is empty - it will
            # be torn down on close(). Cheaper than restarting on next client.

    async def _pubsub_loop(self, topic: str) -> None:
        """Subscribe to `topic` and forward messages to all subscriber queues.

        Wraps the subscribe + listen cycle in a retry loop so a Redis hiccup
        no longer kills the topic permanently. Per-topic downtime (gap
        between an exception in `listen()` and a successful resubscribe) is
        recorded in both the Prometheus metrics and the in-memory dicts that
        /healthz exposes.
        """
        full = self._topic_with_prefix(topic)
        attempt = 0
        while not self._closed:
            pubsub = None
            try:
                pubsub = self.redis.pubsub()
                await pubsub.subscribe(full)
                if self._disconnected_at.get(topic, 0.0) > 0.0:
                    delta = time.time() - self._disconnected_at[topic]
                    if delta < 0.0:
                        delta = 0.0
                    self._last_downtime_s[topic] = delta
                    self._total_downtime_s[topic] = (
                        self._total_downtime_s.get(topic, 0.0) + delta
                    )
                    if delta > self._longest_downtime_s.get(topic, 0.0):
                        self._longest_downtime_s[topic] = delta
                    self._disconnected_at[topic] = 0.0
                    redis_sub_last_downtime_seconds.labels(topic=topic).set(delta)
                    redis_sub_longest_downtime_seconds.labels(topic=topic).set(
                        self._longest_downtime_s[topic]
                    )
                    redis_sub_downtime_seconds_total.labels(topic=topic).inc(delta)
                    redis_sub_current_downtime_seconds.labels(topic=topic).set(0.0)
                    redis_sub_reconnects_total.labels(topic=topic).inc()
                    log.info(
                        "fanout resubscribed: topic=%s downtime=%.2fs", topic, delta
                    )
                else:
                    redis_sub_current_downtime_seconds.labels(topic=topic).set(0.0)
                    log.info("fanout listening: topic=%s (redis=%s)", topic, full)
                attempt = 0

                async for msg in pubsub.listen():
                    if msg.get("type") != "message":
                        continue
                    data = msg.get("data")
                    if isinstance(data, (bytes, bytearray)):
                        try:
                            data = data.decode("utf-8")
                        except Exception:
                            continue
                    fanout_messages_total.labels(topic=topic).inc()
                    for q in list(self._subscribers.get(topic, [])):
                        try:
                            q.put_nowait(data)
                        except asyncio.QueueFull:
                            fanout_drops_total.labels(topic=topic).inc()
                            log.warning(
                                "queue full on topic=%s - dropping message for slow client",
                                topic,
                            )
                # listen() returned without exception → treat as a drop and
                # reconnect rather than leaving the topic silent.
                raise RuntimeError("pubsub.listen() returned unexpectedly")
            except asyncio.CancelledError:
                return
            except Exception as e:
                if self._disconnected_at.get(topic, 0.0) == 0.0:
                    self._disconnected_at[topic] = time.time()
                log.warning(
                    "fanout subscription dropped topic=%s: %s (attempt=%d)",
                    topic,
                    e,
                    attempt,
                )
            finally:
                if pubsub is not None:
                    try:
                        await pubsub.unsubscribe(full)
                    except Exception:
                        pass
                    try:
                        await pubsub.aclose()
                    except Exception:
                        pass

            if self._closed:
                break
            # Reflect ongoing outage on the gauge so a scrape during backoff
            # still shows non-zero current downtime.
            if self._disconnected_at.get(topic, 0.0) > 0.0:
                redis_sub_current_downtime_seconds.labels(topic=topic).set(
                    time.time() - self._disconnected_at[topic]
                )
            delay = min(_RESUB_CAP_S, _RESUB_BASE_S * (2 ** attempt))
            delay += random.uniform(0.0, min(1.0, delay * 0.25))
            attempt += 1
            try:
                await asyncio.sleep(delay)
            except asyncio.CancelledError:
                return

    async def close(self) -> None:
        self._closed = True
        for t in list(self._tasks.values()):
            t.cancel()
        for t in list(self._tasks.values()):
            try:
                await t
            except (asyncio.CancelledError, Exception):
                pass
        self._tasks.clear()
        self._subscribers.clear()

    def stats(self) -> dict:
        return {
            topic: len(subs) for topic, subs in self._subscribers.items()
        }

    def downtime_stats(self) -> dict:
        """Per-topic Redis pubsub downtime snapshot for /healthz."""
        now = time.time()
        out: dict[str, dict] = {}
        for topic in self._tasks.keys():
            disc_at = self._disconnected_at.get(topic, 0.0)
            current = round(now - disc_at, 1) if disc_at > 0.0 else 0.0
            out[topic] = {
                "current_downtime_s": current,
                "last_downtime_s": round(self._last_downtime_s.get(topic, 0.0), 1),
                "longest_downtime_s": round(self._longest_downtime_s.get(topic, 0.0), 1),
                "total_downtime_s": round(self._total_downtime_s.get(topic, 0.0), 1),
            }
        return out
