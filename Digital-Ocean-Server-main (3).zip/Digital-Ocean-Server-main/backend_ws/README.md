# backend_ws

FastAPI WebSocket fanout server. Self-contained - **must not import from `realtime/`, `mm_alert_bot/`, `backend_api/`, `hedge_engine/`, or `shared/`**. See plan: [02_priority1_backend_ws_implementation_plan.md](../new_dashboard_plan_doc/02_priority1_backend_ws_implementation_plan.md).

## Phase 1 status
Skeleton only. `/healthz` pings Redis. No WS routes wired yet.

## Run locally
```
python -m backend_ws.run
curl http://127.0.0.1:8100/healthz
```

## Isolation guard
See `scripts/check_ws_isolation.{sh,ps1}`. Must return zero matches before commit.
