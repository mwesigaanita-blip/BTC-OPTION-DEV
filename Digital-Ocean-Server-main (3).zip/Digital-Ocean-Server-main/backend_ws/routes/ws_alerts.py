"""/ws/alerts - forwards `app.alerts.mmp` AND `app.alerts.lock` (plan §3.2).

Two Redis topics, one ws stream. We subscribe to both and merge.
"""
from __future__ import annotations

import asyncio
import logging

from fastapi import APIRouter, WebSocket, WebSocketDisconnect, status

from ..auth import check_api_key

log = logging.getLogger("backend_ws.ws_alerts")
router = APIRouter()

ALERT_TOPICS = ("app.alerts.mmp", "app.alerts.lock")


@router.websocket("/ws/alerts")
async def ws_alerts(websocket: WebSocket) -> None:
    cfg = websocket.app.state.config
    fanout = websocket.app.state.fanout
    conn_mgr = websocket.app.state.connections

    if not check_api_key(websocket.headers, cfg.internal_api_key):
        await websocket.close(
            code=status.WS_1008_POLICY_VIOLATION, reason="auth_required"
        )
        return

    await websocket.accept()
    await conn_mgr.add(websocket)
    queues = [await fanout.subscribe(t) for t in ALERT_TOPICS]
    log.info("ws connected: alerts (mmp+lock) remote=%s", websocket.client)

    async def _multi_send():
        # Wait on any of the queues - whichever has a message goes out next.
        pending = {asyncio.create_task(q.get()): q for q in queues}
        try:
            while True:
                done, _ = await asyncio.wait(
                    pending, return_when=asyncio.FIRST_COMPLETED
                )
                for task in done:
                    q = pending.pop(task)
                    msg = task.result()
                    await websocket.send_text(msg)
                    pending[asyncio.create_task(q.get())] = q
        finally:
            for task in pending:
                task.cancel()

    async def _recv():
        while True:
            try:
                await websocket.receive_text()
            except WebSocketDisconnect:
                return

    try:
        producer = asyncio.create_task(_multi_send(), name="ws-alerts-send")
        reader = asyncio.create_task(_recv(), name="ws-alerts-recv")
        done, pending = await asyncio.wait(
            {producer, reader}, return_when=asyncio.FIRST_COMPLETED
        )
        for t in pending:
            t.cancel()
            try:
                await t
            except (asyncio.CancelledError, Exception):
                pass
    except WebSocketDisconnect:
        pass
    except Exception as e:
        log.warning("ws alerts loop error: %s", e)
    finally:
        for topic, q in zip(ALERT_TOPICS, queues):
            await fanout.unsubscribe(topic, q)
        await conn_mgr.remove(websocket)
        try:
            await websocket.close()
        except Exception:
            pass
