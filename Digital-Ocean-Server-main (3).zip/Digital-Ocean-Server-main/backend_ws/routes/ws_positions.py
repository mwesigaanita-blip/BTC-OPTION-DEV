"""/ws/positions - forwards Redis topic `app.positions` to authenticated clients."""
from __future__ import annotations

from fastapi import APIRouter, WebSocket

from ._ws_helper import serve_ws

router = APIRouter()


@router.websocket("/ws/positions")
async def ws_positions(websocket: WebSocket) -> None:
    await serve_ws(websocket, topic="app.positions")
