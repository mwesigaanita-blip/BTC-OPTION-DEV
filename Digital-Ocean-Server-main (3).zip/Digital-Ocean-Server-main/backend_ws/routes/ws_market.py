"""/ws/market - forwards Redis topic `app.market` to authenticated clients."""
from __future__ import annotations

from fastapi import APIRouter, WebSocket

from ._ws_helper import serve_ws

router = APIRouter()


@router.websocket("/ws/market")
async def ws_market(websocket: WebSocket) -> None:
    await serve_ws(websocket, topic="app.market")
