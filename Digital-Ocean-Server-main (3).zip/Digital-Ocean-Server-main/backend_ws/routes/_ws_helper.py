"""Shared loop body for ws_account / ws_positions / ws_market / ws_alerts.

Each route is a thin wrapper that calls `serve_ws(websocket, topic)` with the
right Redis topic name. Auth check + accept + queue subscribe + send loop +
cleanup all live here.
"""
from __future__ import annotations

import asyncio
import logging

from fastapi import WebSocket, WebSocketDisconnect, status

from ..auth import check_api_key, check_jwt
from ..metrics import ws_clients_active, ws_clients_total

log = logging.getLogger("backend_ws.ws")


async def serve_ws(websocket: WebSocket, topic: str) -> None:
    cfg = websocket.app.state.config
    fanout = websocket.app.state.fanout
    conn_mgr = websocket.app.state.connections

    # 1. Auth gate - reject before accept() so the client gets the close cleanly.
    #    Accept either the service header or a browser JWT query-param.
    authorized = check_api_key(websocket.headers, cfg.internal_api_key) or check_jwt(
        websocket.query_params.get("token", "")
    )
    if not authorized:
        # Starlette requires accept() before close() carries a code; deny via
        # close() alone results in 403. Use ws-protocol close instead.
        await websocket.close(code=status.WS_1008_POLICY_VIOLATION, reason="auth_required")
        return

    await websocket.accept()
    await conn_mgr.add(websocket)
    ws_clients_total.labels(route=topic).inc()
    ws_clients_active.labels(route=topic).inc()
    queue = await fanout.subscribe(topic)
    log.info("ws connected: topic=%s remote=%s", topic, websocket.client)

    try:
        # Two coroutines:
        #   - producer: drain queue → send_text
        #   - reader:   read incoming frames so we notice disconnects (and
        #               can support optional ping/pong from clients later)
        producer = asyncio.create_task(_send_loop(websocket, queue), name=f"ws-send:{topic}")
        reader = asyncio.create_task(_recv_loop(websocket), name=f"ws-recv:{topic}")
        done, pending = await asyncio.wait(
            {producer, reader}, return_when=asyncio.FIRST_COMPLETED
        )
        for t in pending:
            t.cancel()
            try:
                await t
            except (asyncio.CancelledError, Exception):
                pass
    except WebSocketDisconnect:
        pass
    except Exception as e:
        log.warning("ws loop error topic=%s: %s", topic, e)
    finally:
        await fanout.unsubscribe(topic, queue)
        await conn_mgr.remove(websocket)
        ws_clients_active.labels(route=topic).dec()
        try:
            await websocket.close()
        except Exception:
            pass


async def _send_loop(ws: WebSocket, queue: asyncio.Queue) -> None:
    while True:
        msg = await queue.get()
        await ws.send_text(msg)


async def _recv_loop(ws: WebSocket) -> None:
    """Drain inbound frames so the connection notices client-side close.

    Phase 5 doesn't expect clients to send anything, but Starlette won't
    raise WebSocketDisconnect on TCP close until something tries to read.
    """
    while True:
        try:
            await ws.receive_text()
        except WebSocketDisconnect:
            return
