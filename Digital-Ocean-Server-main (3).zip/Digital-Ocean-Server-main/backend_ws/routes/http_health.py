"""/healthz - pings Redis and reports liveness.

Phase 5: also surfaces fanout subscriber counts and total ws clients.
"""
from __future__ import annotations

import logging

import redis.asyncio as aioredis
from fastapi import APIRouter, Request, Response
from prometheus_client import CONTENT_TYPE_LATEST, generate_latest

from ..metrics import redis_ping_failures_total

log = logging.getLogger("backend_ws.health")
router = APIRouter()


@router.get("/healthz")
async def healthz(request: Request) -> dict:
    client: aioredis.Redis = request.app.state.redis
    redis_status = "ok"
    ok = True
    try:
        pong = await client.ping()
        if not pong:
            redis_status, ok = "no-pong", False
    except Exception as e:
        redis_status, ok = f"error: {type(e).__name__}", False
        redis_ping_failures_total.inc()
        log.warning("redis ping failed: %s", e)

    fanout = getattr(request.app.state, "fanout", None)
    conn_mgr = getattr(request.app.state, "connections", None)
    return {
        "ok": ok,
        "redis": redis_status,
        "ws_clients": conn_mgr.count if conn_mgr is not None else 0,
        "fanout_subs": fanout.stats() if fanout is not None else {},
        "redis_sub": fanout.downtime_stats() if fanout is not None else {},
    }


@router.get("/metrics")
async def metrics() -> Response:
    return Response(content=generate_latest(), media_type=CONTENT_TYPE_LATEST)
