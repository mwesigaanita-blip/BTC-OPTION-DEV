"""/ws/account - forwards Redis topic `app.account` to authenticated clients."""
from __future__ import annotations

from fastapi import APIRouter, WebSocket

from ._ws_helper import serve_ws

router = APIRouter()


@router.websocket("/ws/account")
async def ws_account(websocket: WebSocket) -> None:
    await serve_ws(websocket, topic="app.account")
