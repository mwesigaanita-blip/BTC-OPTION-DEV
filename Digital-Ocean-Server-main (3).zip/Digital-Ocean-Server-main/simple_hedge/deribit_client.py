"""
simple_hedge/deribit_client.py

Deribit REST client for the hedge engine.

Responsibilities:
  - Auth token cache + auto refresh
  - get_account_summary()  → MM%, net delta, equity
  - get_index_price()      → current BTC/USD spot
  - place_market_order()   → BTC-PERPETUAL buy/sell
  - SpotPriceHistory       → maintains 60s rolling window for speed calculation
"""

from __future__ import annotations

import logging
import os
import time
from collections import deque
from typing import Any, Dict, Optional, Tuple

import requests

log = logging.getLogger(__name__)

# ── Constants ─────────────────────────────────────────────────────────────────

BASE_URL      = os.getenv("DERIBIT_BASE_URL", "https://www.deribit.com").rstrip("/") + "/api/v2"
CLIENT_ID     = os.getenv("DERIBIT_CLIENT_ID_EXECUTION", "")
CLIENT_SECRET = os.getenv("DERIBIT_CLIENT_SECRET_EXECUTION", "")
CURRENCY      = "BTC"
PERP_SYMBOL   = "BTC-PERPETUAL"


# ── Spot price history ────────────────────────────────────────────────────────

class SpotPriceHistory:
    """
    Rolling window of (timestamp, price) pairs.
    Used to compute 30s and 60s spot speed.

    Automatically prunes entries older than 65s.
    """

    def __init__(self) -> None:
        self._history: deque[Tuple[float, float]] = deque()

    def record(self, price: float) -> None:
        """Add current price with current epoch timestamp."""
        now = time.time()
        self._history.append((now, price))
        self._prune(now)

    def _prune(self, now: float) -> None:
        """Remove entries older than 65 seconds."""
        while self._history and now - self._history[0][0] > 65:
            self._history.popleft()

    def _price_n_seconds_ago(self, seconds: int) -> Optional[float]:
        """
        Find the closest price recorded ~N seconds ago.
        Returns None if not enough history yet.
        """
        now = time.time()
        target_ts = now - seconds

        best: Optional[Tuple[float, float]] = None
        best_diff = float("inf")

        for ts, price in self._history:
            diff = abs(ts - target_ts)
            if diff < best_diff:
                best_diff = diff
                best = (ts, price)

        # Only use if within 10s of the target window
        if best and best_diff <= 10:
            return best[1]
        return None

    def get_speeds(self, current_price: float) -> Dict[str, float]:
        """
        Compute 30s and 60s spot speed as absolute price move %.

        Returns:
            {
                "speed_30s": 0.008,   # 0.8% move in 30s
                "speed_60s": 0.012,   # 1.2% move in 60s
            }
        Returns 0.0 for a window if not enough history yet.
        """
        px_30s = self._price_n_seconds_ago(30)
        px_60s = self._price_n_seconds_ago(60)

        speed_30s = abs((current_price - px_30s) / px_30s) if px_30s and px_30s > 0 else 0.0
        speed_60s = abs((current_price - px_60s) / px_60s) if px_60s and px_60s > 0 else 0.0

        return {"speed_30s": speed_30s, "speed_60s": speed_60s}


# ── Deribit REST client ───────────────────────────────────────────────────────

class DeribitClient:
    """
    Stateful REST client.
    One instance lives for the full lifetime of the hedge loop.
    Maintains spot price history internally for speed calculations.
    """

    def __init__(self) -> None:
        self.session       = requests.Session()
        self.access_token  : Optional[str] = None
        self.token_expiry  : float = 0.0
        self.spot_history  = SpotPriceHistory()

    # ── Auth ──────────────────────────────────────────────────────────────────

    def _ensure_auth(self) -> None:
        """Fetch or refresh token if expired (30s buffer)."""
        if self.access_token and time.time() < self.token_expiry - 30:
            return

        resp = self.session.get(
            f"{BASE_URL}/public/auth",
            params={
                "grant_type"    : "client_credentials",
                "client_id"     : CLIENT_ID,
                "client_secret" : CLIENT_SECRET,
            },
            timeout=10,
        )
        resp.raise_for_status()

        raw = resp.text
        if not raw or not raw.strip():
            raise RuntimeError(
                f"Deribit auth returned empty response (HTTP {resp.status_code})"
            )
        try:
            body = resp.json()
        except Exception:
            raise RuntimeError(
                f"Deribit auth returned non-JSON (HTTP {resp.status_code}): "
                f"{raw[:200]}"
            )

        if "error" in body:
            raise RuntimeError(f"Deribit auth error: {body['error']}")

        result = body["result"]
        self.access_token = result["access_token"]
        self.token_expiry = time.time() + result.get("expires_in", 900)
        log.debug("Deribit token refreshed. expires_in=%s", result.get("expires_in"))

    def _get(self, endpoint: str, params: Optional[Dict[str, Any]] = None) -> Any:
        """Authenticated GET. Returns result field or raises."""
        self._ensure_auth()
        resp = self.session.get(
            f"{BASE_URL}/{endpoint}",
            params=params or {},
            headers={"Authorization": f"Bearer {self.access_token}"},
            timeout=30,
        )
        resp.raise_for_status()

        raw = resp.text
        if not raw or not raw.strip():
            raise RuntimeError(
                f"Deribit [{endpoint}] returned empty response (HTTP {resp.status_code})"
            )
        try:
            body = resp.json()
        except Exception:
            raise RuntimeError(
                f"Deribit [{endpoint}] returned non-JSON (HTTP {resp.status_code}): "
                f"{raw[:200]}"
            )

        if "error" in body:
            raise RuntimeError(f"Deribit API error [{endpoint}]: {body['error']}")

        return body["result"]

    # ── Account summary ───────────────────────────────────────────────────────

    def get_account_summary(self) -> Dict[str, Any]:
        """
        Fetch BTC account summary.

        Key fields:
          margin_balance      (float) BTC
          maintenance_margin  (float) BTC
          delta_total         (float) net delta BTC
          equity              (float) BTC total equity
        """
        result = self._get(
            "private/get_account_summary",
            {"currency": CURRENCY, "extended": "true"},
        )
        log.debug(
            "Account → margin_balance=%.4f  maintenance_margin=%.4f  "
            "delta_total=%.4f  equity=%.4f  total_equity_usd=%.2f",
            result.get("margin_balance", 0),
            result.get("maintenance_margin", 0),
            result.get("delta_total", 0),
            result.get("equity", 0),
            result.get("total_equity_usd", 0),
        )
        return result

    # ── Index price + speed ───────────────────────────────────────────────────

    def get_index_price(self) -> float:
        """
        Fetch current BTC/USD index price.
        Also records into spot history for speed calculation.
        """
        result = self._get("public/get_index_price", {"index_name": "btc_usd"})
        price  = float(result["index_price"])
        self.spot_history.record(price)
        log.debug("BTC index price: %.2f", price)
        return price

    def get_speed_metrics(self, current_price: float) -> Dict[str, float]:
        """
        Get 30s and 60s spot speed from rolling history.

        Args:
            current_price: latest BTC price (already fetched)

        Returns:
            {"speed_30s": float, "speed_60s": float}
        """
        return self.spot_history.get_speeds(current_price)

    # ── Orders ────────────────────────────────────────────────────────────────

    def place_market_order(self, direction: str, size_btc: float) -> Dict[str, Any]:
        """
        Place a market order on BTC-PERPETUAL.

        Args:
            direction : "buy" or "sell"
            size_btc  : amount in BTC (e.g. 0.05)

        Returns:
            order dict with keys: order_id, average_price, filled_amount

        Notes:
            Deribit BTC-PERPETUAL amounts are in USD.
            Converts: amount_usd = size_btc * index_price, rounded to nearest $10.
        """
        if direction not in ("buy", "sell"):
            raise ValueError(f"Invalid direction: '{direction}'. Must be 'buy' or 'sell'.")
        if size_btc <= 0:
            raise ValueError(f"size_btc must be positive, got {size_btc}")

        # Use last known price from history if available, else fetch fresh
        index_price = self.get_index_price()
        amount_usd  = round((size_btc * index_price) / 10) * 10  # nearest $10 contract

        if amount_usd < 10:
            raise ValueError(
                f"Order too small: {size_btc} BTC = ~${amount_usd:.0f} "
                f"(minimum is $10 / 1 contract)"
            )

        log.info(
            "Placing %s market order: %.4f BTC → $%d on %s",
            direction.upper(), size_btc, amount_usd, PERP_SYMBOL,
        )

        result = self._get(f"private/{direction}", {
            "instrument_name" : PERP_SYMBOL,
            "amount"          : amount_usd,
            "type"            : "market",
        })

        order = result.get("order", {})
        log.info(
            "Order filled → id=%s  avg_price=%.2f  filled=$%.0f",
            order.get("order_id"),
            order.get("average_price", 0),
            order.get("filled_amount", 0),
        )
        return order