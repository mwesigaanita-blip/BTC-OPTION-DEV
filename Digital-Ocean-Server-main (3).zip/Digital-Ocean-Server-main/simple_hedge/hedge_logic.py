"""
simple_hedge/hedge_logic.py

Pure stateless decision logic.
No API calls, no DB, no side effects - fully unit testable.

Decision flow:
  1. Compute MM bucket
  2. Check delta deadband
  3. Check cooldown
  4. Check 5min cap
  5. Compute dynamic hedge size
  6. Determine direction from net delta
  7. Return HedgeDecision
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

log = logging.getLogger(__name__)


# ── Data structures ───────────────────────────────────────────────────────────

@dataclass
class AccountState:
    margin_balance     : float   # BTC
    maintenance_margin : float   # BTC
    net_delta          : float   # BTC  (+) = net long  (-) = net short
    equity_usd         : float   # USD total equity (from total_equity_usd)

    @property
    def mm_percent(self) -> float:
        """MM% = (maintenance_margin / margin_balance) * 100"""
        if self.margin_balance <= 0:
            return 100.0
        return (self.maintenance_margin / self.margin_balance) * 100.0


@dataclass
class HedgeConfig:
    """All parameters read from DB config each cycle."""
    # MM buckets
    mm_safe_below       : float = 90.0
    mm_light_below      : float = 94.0
    mm_medium_below     : float = 97.0
    mm_aggressive_below : float = 98.5
    mm_bypass_cooldown  : float = 99.2

    # Dynamic sizing
    hedge_pct_of_equity  : float = 0.02
    delta_hedge_ratio    : float = 0.35
    min_trade_btc        : float = 0.01
    max_single_trade_btc : float = 0.25

    # Safety controls
    delta_deadband_btc : float = 0.03
    cooldown_secs      : int   = 45
    cooldown_fast_secs : int   = 20
    max_btc_per_5min   : float = 0.50

    # Speed thresholds
    speed_warn_30s   : float = 0.008
    speed_danger_30s : float = 0.015
    speed_warn_60s   : float = 0.012
    speed_danger_60s : float = 0.025


@dataclass
class TradeRecord:
    """One entry in the 5min rolling trade window."""
    ts_epoch : float
    size_btc : float


@dataclass
class HedgeDecision:
    should_hedge : bool
    direction    : Optional[str]   # "buy" | "sell" | None
    size_btc     : float
    mm_pct       : float
    mm_bucket    : str
    net_delta    : float
    speed_30s    : float
    speed_60s    : float
    reason       : str
    multipliers  : Dict[str, float] = field(default_factory=dict)


# ── MM bucket logic ───────────────────────────────────────────────────────────

def get_mm_bucket(mm_pct: float, cfg: HedgeConfig) -> str:
    """
    Classify MM% into a named bucket.

    safe       < mm_safe_below      → no hedge
    light      < mm_light_below     → small hedge
    medium     < mm_medium_below    → medium hedge
    aggressive < mm_aggressive_below→ larger hedge
    emergency  >= mm_aggressive_below → maximum hedge
    """
    if mm_pct < cfg.mm_safe_below:
        return "safe"
    if mm_pct < cfg.mm_light_below:
        return "light"
    if mm_pct < cfg.mm_medium_below:
        return "medium"
    if mm_pct < cfg.mm_aggressive_below:
        return "aggressive"
    return "emergency"


def get_mm_multiplier(bucket: str) -> float:
    """Size multiplier per MM bucket."""
    return {
        "safe"       : 0.0,
        "light"      : 1.0,
        "medium"     : 1.5,
        "aggressive" : 2.0,
        "emergency"  : 3.0,
    }.get(bucket, 0.0)


# ── Speed multiplier ──────────────────────────────────────────────────────────

def get_speed_multiplier(speed_30s: float, speed_60s: float, cfg: HedgeConfig) -> float:
    """
    Increase hedge size in fast-moving markets.
    1.0 = normal, 1.5 = warn, 2.0 = danger
    """
    if (speed_30s >= cfg.speed_danger_30s or speed_60s >= cfg.speed_danger_60s):
        return 2.0
    if (speed_30s >= cfg.speed_warn_30s or speed_60s >= cfg.speed_warn_60s):
        return 1.5
    return 1.0


# ── Dynamic sizing ────────────────────────────────────────────────────────────

def compute_hedge_size(
    state      : AccountState,
    cfg        : HedgeConfig,
    btc_price  : float,
    bucket     : str,
    speed_30s  : float,
    speed_60s  : float,
) -> tuple[float, Dict[str, float]]:
    """
    Compute hedge size in BTC.

    Formula:
      base_btc   = (equity_usd * hedge_pct_of_equity) / btc_price
      delta_btc  = abs(net_delta) * delta_hedge_ratio
      raw_btc    = max(base_btc, delta_btc)
      sized_btc  = raw_btc * mm_mult * speed_mult
      clamped    = clamp(sized_btc, min_trade_btc, max_single_trade_btc)

    Returns:
        (final_size_btc, multipliers_dict)
    """
    mm_mult    = get_mm_multiplier(bucket)
    speed_mult = get_speed_multiplier(speed_30s, speed_60s, cfg)

    base_btc  = (state.equity_usd * cfg.hedge_pct_of_equity) / btc_price if btc_price > 0 else 0.0
    delta_btc = abs(state.net_delta) * cfg.delta_hedge_ratio
    raw_btc   = max(base_btc, delta_btc)

    sized_btc = raw_btc * mm_mult * speed_mult

    # Cap at effective delta - no point hedging more than the exposure
    sized_btc = min(sized_btc, abs(state.net_delta), cfg.max_single_trade_btc)

    # Round to 3 decimal places (Deribit minimum step)
    sized_btc = round(sized_btc, 3)

    multipliers = {
        "mm_multiplier"    : mm_mult,
        "speed_multiplier" : speed_mult,
        "base_btc"         : round(base_btc, 4),
        "delta_btc"        : round(delta_btc, 4),
        "raw_btc"          : round(raw_btc, 4),
    }

    return sized_btc, multipliers


# ── 5 min trade window ────────────────────────────────────────────────────────

def prune_trade_window(trades: List[TradeRecord], now: float) -> List[TradeRecord]:
    """Remove trades older than 5 minutes."""
    return [t for t in trades if now - t.ts_epoch <= 300]


def btc_used_last_5min(trades: List[TradeRecord]) -> float:
    """Sum of absolute BTC traded in last 5 minutes."""
    return sum(t.size_btc for t in trades)


# ── Core decision function ────────────────────────────────────────────────────

def evaluate_hedge(
    state      : AccountState,
    cfg        : HedgeConfig,
    btc_price  : float,
    speed_30s  : float,
    speed_60s  : float,
    last_hedge_ts : float,         # epoch of last hedge execution
    trade_window  : List[TradeRecord],  # rolling 5min window
) -> HedgeDecision:
    """
    Full hedge decision with all safety controls.

    Args:
        state         : current account snapshot
        cfg           : engine config from DB
        btc_price     : current BTC/USD index price
        speed_30s     : 30s spot price speed (abs %)
        speed_60s     : 60s spot price speed (abs %)
        last_hedge_ts : epoch timestamp of last hedge (0 if never)
        trade_window  : list of TradeRecord in last 5min

    Returns:
        HedgeDecision
    """
    mm_pct  = state.mm_percent
    bucket  = get_mm_bucket(mm_pct, cfg)
    now     = time.time()

    log.debug(
        "Evaluating → MM%%=%.2f%% bucket=%s delta=%+.4f "
        "speed_30s=%.4f speed_60s=%.4f",
        mm_pct, bucket, state.net_delta, speed_30s, speed_60s,
    )

    def _no_hedge(reason: str) -> HedgeDecision:
        return HedgeDecision(
            should_hedge = False,
            direction    = None,
            size_btc     = 0.0,
            mm_pct       = mm_pct,
            mm_bucket    = bucket,
            net_delta    = state.net_delta,
            speed_30s    = speed_30s,
            speed_60s    = speed_60s,
            reason       = reason,
        )

    # ── 1. Safe bucket → no hedge ─────────────────────────────────────────────
    if bucket == "safe":
        return _no_hedge(f"MM%={mm_pct:.2f}% is in safe zone (< {cfg.mm_safe_below}%)")

    # ── 2. Delta deadband ─────────────────────────────────────────────────────
    if abs(state.net_delta) < cfg.delta_deadband_btc:
        return _no_hedge(
            f"net_delta={state.net_delta:+.4f} BTC inside deadband "
            f"(< {cfg.delta_deadband_btc} BTC)"
        )

    # ── 3. Cooldown check ─────────────────────────────────────────────────────
    bypass_cooldown = mm_pct >= cfg.mm_bypass_cooldown
    if not bypass_cooldown:
        is_fast_market = (
            speed_30s >= cfg.speed_warn_30s or
            speed_60s >= cfg.speed_warn_60s
        )
        cooldown = cfg.cooldown_fast_secs if is_fast_market else cfg.cooldown_secs
        elapsed  = now - last_hedge_ts

        if elapsed < cooldown:
            return _no_hedge(
                f"Cooldown active: {elapsed:.0f}s elapsed of {cooldown}s required"
            )

    # ── 4. 5min cap check ─────────────────────────────────────────────────────
    pruned   = prune_trade_window(trade_window, now)
    used_5m  = btc_used_last_5min(pruned)

    if used_5m >= cfg.max_btc_per_5min:
        return _no_hedge(
            f"5min cap reached: {used_5m:.4f} BTC used "
            f"of {cfg.max_btc_per_5min} BTC max"
        )

    # ── 5. Compute hedge size ─────────────────────────────────────────────────
    size_btc, multipliers = compute_hedge_size(
        state     = state,
        cfg       = cfg,
        btc_price = btc_price,
        bucket    = bucket,
        speed_30s = speed_30s,
        speed_60s = speed_60s,
    )

    if size_btc < cfg.min_trade_btc:
        return _no_hedge(
            f"Computed size {size_btc:.4f} BTC is below "
            f"minimum {cfg.min_trade_btc} BTC"
        )

    # Cap remaining 5min budget
    remaining_5m = cfg.max_btc_per_5min - used_5m
    size_btc     = round(min(size_btc, remaining_5m), 3)

    if size_btc < cfg.min_trade_btc:
        return _no_hedge(
            f"Size after 5min budget cap {size_btc:.4f} BTC "
            f"is below minimum {cfg.min_trade_btc} BTC"
        )

    # ── 6. Direction ──────────────────────────────────────────────────────────
    if state.net_delta > 0:
        direction = "sell"
        reason = (
            f"MM%={mm_pct:.2f}% [{bucket}] | "
            f"net_delta=+{state.net_delta:.4f} BTC (long) → SELL {size_btc} BTC perp"
        )
    elif state.net_delta < 0:
        direction = "buy"
        reason = (
            f"MM%={mm_pct:.2f}% [{bucket}] | "
            f"net_delta={state.net_delta:.4f} BTC (short) → BUY {size_btc} BTC perp"
        )
    else:
        return _no_hedge("net_delta=0 - direction ambiguous")

    return HedgeDecision(
        should_hedge = True,
        direction    = direction,
        size_btc     = size_btc,
        mm_pct       = mm_pct,
        mm_bucket    = bucket,
        net_delta    = state.net_delta,
        speed_30s    = speed_30s,
        speed_60s    = speed_60s,
        reason       = reason,
        multipliers  = multipliers,
    )


# ── Parser ────────────────────────────────────────────────────────────────────

def parse_account_state(summary: dict) -> AccountState:
    """
    Extract AccountState from raw Deribit account summary.

    Args:
        summary: dict from DeribitClient.get_account_summary()
    """
    return AccountState(
        margin_balance     = float(summary.get("margin_balance", 0)),
        maintenance_margin = float(summary.get("maintenance_margin", 0)),
        net_delta          = float(summary.get("delta_total", 0)),
        equity_usd         = float(summary.get("total_equity_usd", 0)),
    )


def make_config_from_dict(cfg: dict) -> HedgeConfig:
    """
    Build HedgeConfig from DB config dict (from read_config()).
    """
    return HedgeConfig(
        mm_safe_below        = float(cfg["mm_safe_below"]),
        mm_light_below       = float(cfg["mm_light_below"]),
        mm_medium_below      = float(cfg["mm_medium_below"]),
        mm_aggressive_below  = float(cfg["mm_aggressive_below"]),
        mm_bypass_cooldown   = float(cfg["mm_bypass_cooldown"]),
        hedge_pct_of_equity  = float(cfg["hedge_pct_of_equity"]),
        delta_hedge_ratio    = float(cfg["delta_hedge_ratio"]),
        min_trade_btc        = float(cfg["min_trade_btc"]),
        max_single_trade_btc = float(cfg["max_single_trade_btc"]),
        delta_deadband_btc   = float(cfg["delta_deadband_btc"]),
        cooldown_secs        = int(cfg["cooldown_secs"]),
        cooldown_fast_secs   = int(cfg["cooldown_fast_secs"]),
        max_btc_per_5min     = float(cfg["max_btc_per_5min"]),
        speed_warn_30s       = float(cfg["speed_warn_30s"]),
        speed_danger_30s     = float(cfg["speed_danger_30s"]),
        speed_warn_60s       = float(cfg["speed_warn_60s"]),
        speed_danger_60s     = float(cfg["speed_danger_60s"]),
    )


# ── Self test ─────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import sys

    PASS = "✅ PASS"
    FAIL = "❌ FAIL"
    results = []

    def test(name, condition):
        tag = PASS if condition else FAIL
        print(f"  {tag}  {name}")
        results.append(condition)

    cfg = HedgeConfig()

    def state(mb, mm, delta, equity_usd=10.0):
        return AccountState(mb, mm, delta, equity_usd)

    def decide(s, speed_30s=0.0, speed_60s=0.0, last_ts=0.0, trades=None):
        return evaluate_hedge(
            state=s, cfg=cfg, btc_price=80000.0,
            speed_30s=speed_30s, speed_60s=speed_60s,
            last_hedge_ts=last_ts, trade_window=trades or [],
        )

    print("\n── MM buckets ──────────────────────────────────────────────────")
    test("safe < 90%",         get_mm_bucket(85.0, cfg) == "safe")
    test("light 90-94%",       get_mm_bucket(92.0, cfg) == "light")
    test("medium 94-97%",      get_mm_bucket(95.0, cfg) == "medium")
    test("aggressive 97-98.5%",get_mm_bucket(98.0, cfg) == "aggressive")
    test("emergency >= 98.5%", get_mm_bucket(99.0, cfg) == "emergency")

    print("\n── Safe zone → no hedge ────────────────────────────────────────")
    d = decide(state(1.0, 0.85, 0.5))
    test("MM%=85% → no hedge", not d.should_hedge)
    test("bucket=safe", d.mm_bucket == "safe")

    print("\n── Delta deadband ──────────────────────────────────────────────")
    d = decide(state(1.0, 0.95, 0.01))  # delta 0.01 < 0.03 deadband
    test("tiny delta → no hedge", not d.should_hedge)

    print("\n── Cooldown ────────────────────────────────────────────────────")
    recent_ts = time.time() - 10  # 10s ago, cooldown=45s
    d = decide(state(1.0, 0.95, 0.5), last_ts=recent_ts)
    test("cooldown active → no hedge", not d.should_hedge)

    old_ts = time.time() - 60    # 60s ago, cooldown=45s
    d = decide(state(1.0, 0.95, 0.5), last_ts=old_ts)
    test("cooldown expired → hedge", d.should_hedge)

    print("\n── Bypass cooldown at 99.2% ────────────────────────────────────")
    recent_ts = time.time() - 5
    d = decide(state(1.0, 0.993, 0.5), last_ts=recent_ts)
    test("MM%=99.3% bypasses cooldown", d.should_hedge)

    print("\n── Fast market cooldown (20s) ──────────────────────────────────")
    ts_25s_ago = time.time() - 25  # 25s ago
    d = decide(state(1.0, 0.95, 0.5), speed_30s=0.01, last_ts=ts_25s_ago)
    test("fast market 25s elapsed → hedge (cooldown=20s)", d.should_hedge)

    print("\n── 5min cap ────────────────────────────────────────────────────")
    big_trades = [TradeRecord(ts_epoch=time.time()-10, size_btc=0.50)]
    d = decide(state(1.0, 0.95, 0.5), trades=big_trades)
    test("5min cap reached → no hedge", not d.should_hedge)

    print("\n── Direction ───────────────────────────────────────────────────")
    d = decide(state(1.0, 0.95, +0.5))
    test("long delta → sell", d.direction == "sell")

    d = decide(state(1.0, 0.95, -0.5))
    test("short delta → buy", d.direction == "buy")

    d = decide(state(1.0, 0.95, 0.0))
    test("zero delta → no hedge", not d.should_hedge)

    print("\n── Dynamic sizing increases with bucket ────────────────────────")
    d_light = decide(state(1.0, 0.92, 0.5, equity_usd=10.0))
    d_emerg = decide(state(1.0, 0.99, 0.5, equity_usd=10.0))
    test("emergency size > light size",
         d_emerg.should_hedge and d_light.should_hedge and
         d_emerg.size_btc >= d_light.size_btc)

    print("\n── Speed multiplier increases size ─────────────────────────────")
    d_slow = decide(state(1.0, 0.95, 0.5))
    d_fast = decide(state(1.0, 0.95, 0.5), speed_30s=0.02)
    test("fast market size >= slow market size",
         d_fast.size_btc >= d_slow.size_btc)

    passed = sum(results)
    total  = len(results)
    print(f"\n{'─'*55}")
    print(f"  Results: {passed}/{total} passed", "✅" if passed == total else "❌")
    print(f"{'─'*55}\n")
    sys.exit(0 if passed == total else 1)