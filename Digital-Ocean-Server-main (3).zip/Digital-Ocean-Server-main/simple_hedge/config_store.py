"""
simple_hedge/config_store.py

Two tables:
  - simple_hedge_config  → engine settings (1 row)
  - simple_hedge_log     → one row per hedge execution

Config fields cover:
  - engine on/off
  - MM bucket thresholds
  - dynamic sizing params
  - safety controls (deadband, cooldown, 5min cap)
  - speed thresholds
"""

from __future__ import annotations

import logging
import sqlite3
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from shared.db_paths import INFRA_DB as DB_PATH

log = logging.getLogger("simple_hedge.config_store")
print(f"[DB] Using {DB_PATH} in {__file__}", flush=True)


# ── Helpers ───────────────────────────────────────────────────────────────────

def _utc_now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

def _connect() -> sqlite3.Connection:
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    return conn


# ── Schema ────────────────────────────────────────────────────────────────────

def ensure_tables() -> None:
    """Create tables if they don't exist. Safe to call on every startup."""
    conn = _connect()
    try:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS simple_hedge_config (
                id INTEGER PRIMARY KEY CHECK (id = 1),

                -- Engine
                is_enabled              INTEGER NOT NULL DEFAULT 0,
                poll_interval_secs      INTEGER NOT NULL DEFAULT 15,

                -- MM bucket thresholds
                mm_safe_below           REAL NOT NULL DEFAULT 90.0,
                mm_light_below          REAL NOT NULL DEFAULT 94.0,
                mm_medium_below         REAL NOT NULL DEFAULT 97.0,
                mm_aggressive_below     REAL NOT NULL DEFAULT 98.5,
                mm_bypass_cooldown      REAL NOT NULL DEFAULT 99.2,

                -- Dynamic sizing
                hedge_pct_of_equity     REAL NOT NULL DEFAULT 0.02,
                delta_hedge_ratio       REAL NOT NULL DEFAULT 0.35,
                min_trade_btc           REAL NOT NULL DEFAULT 0.01,
                max_single_trade_btc    REAL NOT NULL DEFAULT 0.25,

                -- Safety controls
                delta_deadband_btc      REAL NOT NULL DEFAULT 0.03,
                cooldown_secs           INTEGER NOT NULL DEFAULT 45,
                cooldown_fast_secs      INTEGER NOT NULL DEFAULT 20,
                max_btc_per_5min        REAL NOT NULL DEFAULT 0.50,

                -- Speed thresholds
                speed_warn_30s          REAL NOT NULL DEFAULT 0.008,
                speed_danger_30s        REAL NOT NULL DEFAULT 0.015,
                speed_warn_60s          REAL NOT NULL DEFAULT 0.012,
                speed_danger_60s        REAL NOT NULL DEFAULT 0.025,

                updated_at              TEXT NOT NULL
            )
        """)

        conn.execute("""
            CREATE TABLE IF NOT EXISTS simple_hedge_log (
                id              INTEGER PRIMARY KEY AUTOINCREMENT,
                executed_at     TEXT    NOT NULL,
                direction       TEXT    NOT NULL,
                size_btc        REAL    NOT NULL,
                mm_before       REAL    NOT NULL,
                mm_after        REAL,
                mm_bucket       TEXT,
                net_delta       REAL    NOT NULL,
                speed_30s       REAL,
                speed_60s       REAL,
                order_id        TEXT,
                avg_price       REAL,
                error           TEXT
            )
        """)

        # Insert default config row if not exists
        cur = conn.execute("SELECT 1 FROM simple_hedge_config WHERE id = 1")
        if cur.fetchone() is None:
            conn.execute("""
                INSERT INTO simple_hedge_config (
                    id, is_enabled, poll_interval_secs,
                    mm_safe_below, mm_light_below, mm_medium_below,
                    mm_aggressive_below, mm_bypass_cooldown,
                    hedge_pct_of_equity, delta_hedge_ratio,
                    min_trade_btc, max_single_trade_btc,
                    delta_deadband_btc, cooldown_secs, cooldown_fast_secs,
                    max_btc_per_5min,
                    speed_warn_30s, speed_danger_30s,
                    speed_warn_60s, speed_danger_60s,
                    updated_at
                ) VALUES (
                    1, 0, 15,
                    90.0, 94.0, 97.0,
                    98.5, 99.2,
                    0.02, 0.35,
                    0.01, 0.25,
                    0.03, 45, 20,
                    0.50,
                    0.008, 0.015,
                    0.012, 0.025,
                    ?
                )
            """, (_utc_now(),))

        conn.commit()
        log.debug("simple_hedge tables ensured.")
    finally:
        conn.close()


# ── Config read/write ─────────────────────────────────────────────────────────

def read_config() -> Dict[str, Any]:
    """Read current engine config. Returns full dict."""
    conn = _connect()
    try:
        ensure_tables()
        row = conn.execute(
            "SELECT * FROM simple_hedge_config WHERE id = 1"
        ).fetchone()
        out = dict(row)
        out["is_enabled"] = bool(out["is_enabled"])
        return out
    finally:
        conn.close()


def upsert_config(payload: Dict[str, Any]) -> Dict[str, Any]:
    """
    Merge payload into existing config and save.
    Only keys present in payload are updated.
    """
    conn = _connect()
    try:
        ensure_tables()
        current = read_config()
        merged  = {**current, **payload}

        conn.execute("""
            UPDATE simple_hedge_config SET
                is_enabled              = ?,
                poll_interval_secs      = ?,
                mm_safe_below           = ?,
                mm_light_below          = ?,
                mm_medium_below         = ?,
                mm_aggressive_below     = ?,
                mm_bypass_cooldown      = ?,
                hedge_pct_of_equity     = ?,
                delta_hedge_ratio       = ?,
                min_trade_btc           = ?,
                max_single_trade_btc    = ?,
                delta_deadband_btc      = ?,
                cooldown_secs           = ?,
                cooldown_fast_secs      = ?,
                max_btc_per_5min        = ?,
                speed_warn_30s          = ?,
                speed_danger_30s        = ?,
                speed_warn_60s          = ?,
                speed_danger_60s        = ?,
                updated_at              = ?
            WHERE id = 1
        """, (
            1 if merged.get("is_enabled") else 0,
            int(merged["poll_interval_secs"]),
            float(merged["mm_safe_below"]),
            float(merged["mm_light_below"]),
            float(merged["mm_medium_below"]),
            float(merged["mm_aggressive_below"]),
            float(merged["mm_bypass_cooldown"]),
            float(merged["hedge_pct_of_equity"]),
            float(merged["delta_hedge_ratio"]),
            float(merged["min_trade_btc"]),
            float(merged["max_single_trade_btc"]),
            float(merged["delta_deadband_btc"]),
            int(merged["cooldown_secs"]),
            int(merged["cooldown_fast_secs"]),
            float(merged["max_btc_per_5min"]),
            float(merged["speed_warn_30s"]),
            float(merged["speed_danger_30s"]),
            float(merged["speed_warn_60s"]),
            float(merged["speed_danger_60s"]),
            _utc_now(),
        ))
        conn.commit()
        log.info("simple_hedge_config updated.")
        return read_config()
    finally:
        conn.close()


# ── Hedge log ─────────────────────────────────────────────────────────────────

def insert_hedge_log(
    *,
    direction  : str,
    size_btc   : float,
    mm_before  : float,
    mm_after   : Optional[float],
    mm_bucket  : Optional[str],
    net_delta  : float,
    speed_30s  : Optional[float] = None,
    speed_60s  : Optional[float] = None,
    order_id   : Optional[str]   = None,
    avg_price  : Optional[float] = None,
    error      : Optional[str]   = None,
) -> int:
    """Insert one hedge execution record. Returns new row id."""
    conn = _connect()
    try:
        cur = conn.execute("""
            INSERT INTO simple_hedge_log (
                executed_at, direction, size_btc,
                mm_before, mm_after, mm_bucket,
                net_delta, speed_30s, speed_60s,
                order_id, avg_price, error
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            _utc_now(),
            direction,
            float(size_btc),
            float(mm_before),
            float(mm_after)  if mm_after  is not None else None,
            mm_bucket,
            float(net_delta),
            float(speed_30s) if speed_30s is not None else None,
            float(speed_60s) if speed_60s is not None else None,
            order_id,
            float(avg_price) if avg_price is not None else None,
            error,
        ))
        conn.commit()
        log.debug("Hedge log inserted id=%s", cur.lastrowid)
        return cur.lastrowid
    finally:
        conn.close()


def get_hedge_logs(limit: int = 50) -> List[Dict[str, Any]]:
    """Fetch last N hedge executions, newest first."""
    conn = _connect()
    try:
        rows = conn.execute("""
            SELECT * FROM simple_hedge_log
            ORDER BY id DESC
            LIMIT ?
        """, (limit,)).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()