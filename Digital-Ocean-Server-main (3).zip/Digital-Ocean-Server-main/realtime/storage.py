"""Storage layer for the realtime tick DB.

Schema (``data/realtime.sqlite``):

    account_ticks(   ts_utc TEXT PRIMARY KEY, payload_json TEXT NOT NULL )
    positions_ticks( ts_utc TEXT PRIMARY KEY, payload_json TEXT NOT NULL )
    market_ticks(    ts_utc TEXT PRIMARY KEY, btc_price REAL NOT NULL    )

All three carry an explicit btree index on ``ts_utc`` (in addition to the
implicit primary-key index) so that range scans for the aggregator and
cleanup paths stay cheap as the table grows.

Concurrency model:

* WAL mode + ``synchronous=NORMAL`` so writers and readers don't block.
* One ``sqlite3.Connection`` per OS thread, cached in a ``threading.local``
  - sqlite3 connections are not safe to share across threads, but the WAL
  journal makes concurrent connections to the same file fine.
* Writes go through ``INSERT OR REPLACE`` keyed on ``ts_utc`` so a retry
  inside the poller is idempotent.

Public API:

    init_realtime_db()                  - create file + tables (idempotent)
    save_account_tick(ts, payload)
    save_positions_tick(ts, payload)
    save_market_tick(ts, price)
    get_realtime_conn()                 - thread-local connection
"""
from __future__ import annotations

import json
import sqlite3
import threading
from datetime import datetime, timezone
from typing import Any, Mapping, Sequence, Union

from shared.db_paths import REALTIME_DB

__all__ = [
    "REALTIME_DB",
    "init_realtime_db",
    "get_realtime_conn",
    "save_account_tick",
    "save_positions_tick",
    "save_market_tick",
    "utc_now_iso",
]

# ---------------------------------------------------------------------------
# Schema
# ---------------------------------------------------------------------------

_SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS account_ticks (
    ts_utc       TEXT PRIMARY KEY,
    payload_json TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS positions_ticks (
    ts_utc       TEXT PRIMARY KEY,
    payload_json TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS market_ticks (
    ts_utc    TEXT PRIMARY KEY,
    btc_price REAL NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_account_ticks_ts   ON account_ticks(ts_utc);
CREATE INDEX IF NOT EXISTS idx_positions_ticks_ts ON positions_ticks(ts_utc);
CREATE INDEX IF NOT EXISTS idx_market_ticks_ts    ON market_ticks(ts_utc);
"""

_PRAGMAS = (
    "PRAGMA journal_mode = WAL;",
    "PRAGMA synchronous  = NORMAL;",
    "PRAGMA temp_store   = MEMORY;",
    "PRAGMA busy_timeout = 5000;",
)


# ---------------------------------------------------------------------------
# Time helpers
# ---------------------------------------------------------------------------

def utc_now_iso() -> str:
    """Microsecond-precision UTC ISO-8601 (e.g. ``2026-04-25T12:34:56.789012Z``)."""
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f") + "Z"


# ---------------------------------------------------------------------------
# Connection management
# ---------------------------------------------------------------------------

_tls = threading.local()
_init_lock = threading.Lock()
_initialized = False


def _new_conn() -> sqlite3.Connection:
    REALTIME_DB.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(
        str(REALTIME_DB),
        timeout=5.0,
        isolation_level=None,  # autocommit; we manage txns explicitly when needed
        check_same_thread=True,
    )
    conn.row_factory = sqlite3.Row
    for pragma in _PRAGMAS:
        conn.execute(pragma)
    return conn


def init_realtime_db() -> None:
    """Create the DB file, apply pragmas, and create tables.

    Safe to call repeatedly; only the first call does real work.
    """
    global _initialized
    with _init_lock:
        if _initialized:
            return
        conn = _new_conn()
        try:
            conn.executescript(_SCHEMA_SQL)
        finally:
            conn.close()
        _initialized = True


def get_realtime_conn() -> sqlite3.Connection:
    """Return a thread-local sqlite3 connection to ``realtime.sqlite``."""
    if not _initialized:
        init_realtime_db()
    conn = getattr(_tls, "conn", None)
    if conn is None:
        conn = _new_conn()
        _tls.conn = conn
    return conn


# ---------------------------------------------------------------------------
# Writers
# ---------------------------------------------------------------------------

JsonLike = Union[Mapping[str, Any], Sequence[Any], None]


def _dumps(payload: JsonLike) -> str:
    # ``default=str`` keeps datetimes / Decimals / unknown types from blowing
    # up the writer - raw fidelity is enforced upstream by the poller.
    return json.dumps(payload if payload is not None else {}, default=str, separators=(",", ":"))


def save_account_tick(ts: str, payload: JsonLike) -> None:
    """Persist one account-summary tick. INSERT OR REPLACE on ``ts_utc``."""
    conn = get_realtime_conn()
    conn.execute(
        "INSERT OR REPLACE INTO account_ticks (ts_utc, payload_json) VALUES (?, ?);",
        (ts, _dumps(payload)),
    )


def save_positions_tick(ts: str, payload: JsonLike) -> None:
    """Persist one positions tick (raw list/dict)."""
    conn = get_realtime_conn()
    conn.execute(
        "INSERT OR REPLACE INTO positions_ticks (ts_utc, payload_json) VALUES (?, ?);",
        (ts, _dumps(payload)),
    )


def save_market_tick(ts: str, price: float) -> None:
    """Persist one BTC index-price tick."""
    conn = get_realtime_conn()
    conn.execute(
        "INSERT OR REPLACE INTO market_ticks (ts_utc, btc_price) VALUES (?, ?);",
        (ts, float(price)),
    )
