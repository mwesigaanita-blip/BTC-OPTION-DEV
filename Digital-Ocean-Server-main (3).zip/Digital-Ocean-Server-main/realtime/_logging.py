"""Shared logger for the realtime package.

A single rotating-file handler is shared across poller / aggregator /
cleanup / scheduler so every component appends to ``logs/realtime.log``
with the same format. The handler is attached at most once even if the
helper is imported from multiple threads.
"""
from __future__ import annotations

import logging
import threading
from logging.handlers import RotatingFileHandler
from pathlib import Path

from shared.db_paths import PROJECT_ROOT

_LOG_DIR: Path = PROJECT_ROOT / "logs"
_LOG_FILE: Path = _LOG_DIR / "realtime.log"
_DEBUG_DUMP_DIR: Path = _LOG_DIR / "debug_ticks"

_LOG_DIR.mkdir(parents=True, exist_ok=True)
_DEBUG_DUMP_DIR.mkdir(parents=True, exist_ok=True)

_lock = threading.Lock()
_configured = False


def get_logger(name: str = "realtime") -> logging.Logger:
    """Return the package logger, attaching the rotating handler once."""
    global _configured
    logger = logging.getLogger(name)

    with _lock:
        if not _configured:
            logger.setLevel(logging.INFO)
            fmt = logging.Formatter(
                "%(asctime)sZ [%(levelname)s] %(name)s: %(message)s",
                datefmt="%Y-%m-%dT%H:%M:%S",
            )
            fmt.converter = __import__("time").gmtime  # UTC timestamps

            fh = RotatingFileHandler(
                _LOG_FILE, maxBytes=5_000_000, backupCount=3, encoding="utf-8"
            )
            fh.setFormatter(fmt)
            logger.addHandler(fh)

            sh = logging.StreamHandler()
            sh.setFormatter(fmt)
            logger.addHandler(sh)

            logger.propagate = False
            _configured = True

    return logger


def debug_dump_dir() -> Path:
    return _DEBUG_DUMP_DIR
