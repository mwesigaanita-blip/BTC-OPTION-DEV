"""Real-time ingestion pipeline (Phase 2).

A self-contained polling + aggregation system that writes high-frequency
ticks to ``data/realtime.sqlite`` and rolls them up into
``hedge_engine.sqlite.hedge_engine_aggregated_metrics`` every 60 s.

The package is deliberately decoupled from the hedge engine's transactional
DB so that a flaky API call or a slow write never blocks risk logic.
"""

from .storage import (
    REALTIME_DB,
    get_realtime_conn,
    init_realtime_db,
    save_account_tick,
    save_market_tick,
    save_positions_tick,
)
from .live_view import read_latest_live_state

__all__ = [
    "REALTIME_DB",
    "get_realtime_conn",
    "init_realtime_db",
    "save_account_tick",
    "save_market_tick",
    "save_positions_tick",
    "read_latest_live_state",
]
