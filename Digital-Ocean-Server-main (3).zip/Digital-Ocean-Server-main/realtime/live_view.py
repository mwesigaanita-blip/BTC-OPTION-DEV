"""Read-side helpers for dashboards (Live Mode).

The dashboard's "Live Mode" toggle should call ``read_latest_live_state``;
when off, callers fall back to whatever they used before (e.g.
``snapshots.sqlite``). All queries here are bounded with ``LIMIT`` and
hit the indexed ``ts_utc`` column - no full scans.

Read-only: this module never writes.
"""
from __future__ import annotations

import json
import sqlite3
from typing import Any, Optional

from shared.db_paths import HEDGE_ENGINE_DB

from .aggregator import TABLE_NAME as AGG_TABLE
from .storage import REALTIME_DB

__all__ = [
    "read_latest_account_tick",
    "read_latest_positions_tick",
    "read_latest_market_tick",
    "read_recent_market_ticks",
    "read_latest_aggregated",
    "read_latest_live_state",
]


def _ro_realtime() -> sqlite3.Connection:
    conn = sqlite3.connect(str(REALTIME_DB), timeout=2.0)
    conn.row_factory = sqlite3.Row
    return conn


def _ro_hedge_engine() -> sqlite3.Connection:
    conn = sqlite3.connect(str(HEDGE_ENGINE_DB), timeout=2.0)
    conn.row_factory = sqlite3.Row
    return conn


def read_latest_account_tick() -> Optional[dict]:
    conn = _ro_realtime()
    try:
        row = conn.execute(
            "SELECT ts_utc, payload_json FROM account_ticks ORDER BY ts_utc DESC LIMIT 1;"
        ).fetchone()
    finally:
        conn.close()
    if not row:
        return None
    try:
        return {"ts_utc": row["ts_utc"], "payload": json.loads(row["payload_json"])}
    except json.JSONDecodeError:
        return {"ts_utc": row["ts_utc"], "payload": None}


def read_latest_positions_tick() -> Optional[dict]:
    conn = _ro_realtime()
    try:
        row = conn.execute(
            "SELECT ts_utc, payload_json FROM positions_ticks ORDER BY ts_utc DESC LIMIT 1;"
        ).fetchone()
    finally:
        conn.close()
    if not row:
        return None
    try:
        return {"ts_utc": row["ts_utc"], "payload": json.loads(row["payload_json"])}
    except json.JSONDecodeError:
        return {"ts_utc": row["ts_utc"], "payload": None}


def read_latest_market_tick() -> Optional[dict]:
    conn = _ro_realtime()
    try:
        row = conn.execute(
            "SELECT ts_utc, btc_price FROM market_ticks ORDER BY ts_utc DESC LIMIT 1;"
        ).fetchone()
    finally:
        conn.close()
    return dict(row) if row else None


def read_recent_market_ticks(limit: int = 720) -> list[dict]:
    """Last ``limit`` market ticks, oldest-first. Default 720 ≈ 1 h at 5 s."""
    limit = max(1, min(int(limit), 51_840))  # cap at 72 h @ 5 s
    conn = _ro_realtime()
    try:
        rows = conn.execute(
            "SELECT ts_utc, btc_price FROM market_ticks "
            "ORDER BY ts_utc DESC LIMIT ?;",
            (limit,),
        ).fetchall()
    finally:
        conn.close()
    return [dict(r) for r in reversed(rows)]


def read_latest_aggregated() -> Optional[dict]:
    """Latest row from ``hedge_engine_aggregated_metrics``."""
    conn = _ro_hedge_engine()
    try:
        row = conn.execute(
            f"SELECT * FROM {AGG_TABLE} ORDER BY ts_utc DESC LIMIT 1;"
        ).fetchone()
    except sqlite3.OperationalError:
        # table may not exist yet on a brand-new install
        conn.close()
        return None
    finally:
        try:
            conn.close()
        except Exception:
            pass
    return dict(row) if row else None


def read_latest_live_state() -> dict:
    """One-stop snapshot for the dashboard's Live Mode tile.

    Combines the freshest tick from each source plus the latest aggregated
    metrics row. All four lookups are independent - a missing table or an
    empty stream leaves that field as ``None`` rather than failing the call.
    """
    return {
        "account_tick":   read_latest_account_tick(),
        "positions_tick": read_latest_positions_tick(),
        "market_tick":    read_latest_market_tick(),
        "aggregated":     read_latest_aggregated(),
    }
