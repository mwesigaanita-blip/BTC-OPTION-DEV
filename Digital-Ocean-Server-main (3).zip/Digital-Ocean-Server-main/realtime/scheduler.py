"""Threaded scheduler - runs poller (5 s), aggregator (60 s), cleanup (5 m).

Three daemon worker threads, one per cadence. The scheduler itself never
blocks the caller's main thread; ``start()`` returns immediately and
``stop()`` signals all workers to exit then joins with a small grace
period.

Why threads instead of async
----------------------------
The poller is HTTP-bound and the aggregator does sqlite IO; both of those
release the GIL on syscalls, so threading is the simplest correct
primitive here. Going async would bring no throughput win and would
force a rewrite of the existing ``DeribitClient`` (which is sync
``requests``).

Crash safety
------------
Each worker wraps the blocking call in a top-level try/except. Even if
``run_once`` somehow leaks an exception (it shouldn't - both paths
already swallow), the worker logs it and keeps going. The ONLY way out
is ``stop_event.set()`` via ``stop()`` or ``KeyboardInterrupt`` in
``run_blocking``.

Rate limiting
-------------
Each loop computes ``elapsed`` for its own iteration and sleeps the
remainder of its interval. So a slow tick never causes back-to-back
fires (which would amount to a self-induced API hammer).
"""
from __future__ import annotations

import argparse
import json
import signal
import threading
import time
from typing import Optional

from . import aggregator as _aggregator
from . import cleanup as _cleanup
from ._logging import get_logger
from .poller import POLL_INTERVAL_S, Poller

log = get_logger("realtime.scheduler")


class RealtimeScheduler:
    """Holds three worker threads + a single shared stop signal."""

    def __init__(
        self,
        *,
        poll_interval_s: float = POLL_INTERVAL_S,
        agg_interval_s: float = _aggregator.AGG_INTERVAL_S,
        cleanup_interval_s: float = _cleanup.CLEANUP_INTERVAL_S,
    ) -> None:
        self.poll_interval_s = float(poll_interval_s)
        self.agg_interval_s = float(agg_interval_s)
        self.cleanup_interval_s = float(cleanup_interval_s)

        self._stop = threading.Event()
        self._threads: list[threading.Thread] = []

        # Poller has stateful health info; instantiate once and let the worker drive it.
        self.poller = Poller(interval_s=self.poll_interval_s)
        self._started_at: Optional[float] = None

    # ------------------------------------------------------------------
    # Workers
    # ------------------------------------------------------------------

    def _poll_worker(self) -> None:
        log.info("poll worker started (every %.1fs)", self.poll_interval_s)
        while not self._stop.is_set():
            t0 = time.perf_counter()
            try:
                self.poller.run_once()
            except Exception as e:
                log.exception("poll worker error: %s", e)
            elapsed = time.perf_counter() - t0
            sleep_for = max(0.0, self.poll_interval_s - elapsed)
            if self._stop.wait(timeout=sleep_for):
                break
        log.info("poll worker exited")

    def _agg_worker(self) -> None:
        log.info("agg worker started (every %.1fs)", self.agg_interval_s)
        # Initial 5s grace so the poller has at least one tick to roll up.
        if self._stop.wait(timeout=min(5.0, self.agg_interval_s)):
            return
        while not self._stop.is_set():
            t0 = time.perf_counter()
            try:
                _aggregator.run_once()
            except Exception as e:
                log.exception("agg worker error: %s", e)
            elapsed = time.perf_counter() - t0
            sleep_for = max(0.0, self.agg_interval_s - elapsed)
            if self._stop.wait(timeout=sleep_for):
                break
        log.info("agg worker exited")

    def _cleanup_worker(self) -> None:
        log.info("cleanup worker started (every %.0fs)", self.cleanup_interval_s)
        while not self._stop.is_set():
            try:
                _cleanup.run_cleanup()
            except Exception as e:
                log.exception("cleanup worker error: %s", e)
            if self._stop.wait(timeout=self.cleanup_interval_s):
                break
        log.info("cleanup worker exited")

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def start(self) -> None:
        if self._threads:
            raise RuntimeError("scheduler already started")
        self._started_at = time.time()
        self._stop.clear()

        self._threads = [
            threading.Thread(target=self._poll_worker, name="rt-poller", daemon=True),
            threading.Thread(target=self._agg_worker, name="rt-aggregator", daemon=True),
            threading.Thread(target=self._cleanup_worker, name="rt-cleanup", daemon=True),
        ]
        for t in self._threads:
            t.start()
        log.info(
            "scheduler started: poll=%.1fs agg=%.1fs cleanup=%.0fs",
            self.poll_interval_s, self.agg_interval_s, self.cleanup_interval_s,
        )

    def stop(self, timeout_s: float = 10.0) -> None:
        if not self._threads:
            return
        log.info("scheduler stopping...")
        self._stop.set()
        self.poller.stop()
        deadline = time.time() + float(timeout_s)
        for t in self._threads:
            remaining = max(0.0, deadline - time.time())
            t.join(timeout=remaining)
        still_alive = [t.name for t in self._threads if t.is_alive()]
        if still_alive:
            log.warning("threads did not stop cleanly: %s", still_alive)
        self._threads = []
        log.info("scheduler stopped")

    def health_check(self) -> dict:
        uptime = time.time() - self._started_at if self._started_at else 0.0
        return {
            "uptime_s": round(uptime, 1),
            "alive": [t.name for t in self._threads if t.is_alive()],
            "stopped": self._stop.is_set(),
            "poller": self.poller.health_check(),
        }

    # Convenience: block the calling thread until SIGINT/SIGTERM.
    def run_blocking(self) -> None:
        self.start()
        try:
            # In Windows, signal.SIGTERM is not delivered the same way; the
            # KeyboardInterrupt fallback covers Ctrl-C universally.
            signal.signal(signal.SIGINT, lambda *_: self._stop.set())
            try:
                signal.signal(signal.SIGTERM, lambda *_: self._stop.set())
            except (AttributeError, ValueError):
                # SIGTERM not available on this platform / not main thread
                pass
            while not self._stop.is_set():
                if self._stop.wait(timeout=1.0):
                    break
        except KeyboardInterrupt:
            pass
        finally:
            self.stop()


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main(argv: Optional[list[str]] = None) -> int:
    p = argparse.ArgumentParser(prog="realtime.scheduler")
    p.add_argument("--poll", type=float, default=POLL_INTERVAL_S)
    p.add_argument("--agg", type=float, default=_aggregator.AGG_INTERVAL_S)
    p.add_argument("--cleanup", type=float, default=_cleanup.CLEANUP_INTERVAL_S)
    p.add_argument("--health", action="store_true", help="Print health snapshot after 12s and exit")
    args = p.parse_args(argv)

    sched = RealtimeScheduler(
        poll_interval_s=args.poll,
        agg_interval_s=args.agg,
        cleanup_interval_s=args.cleanup,
    )
    if args.health:
        sched.start()
        time.sleep(12)
        print(json.dumps(sched.health_check(), indent=2))
        sched.stop()
        return 0

    sched.run_blocking()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
