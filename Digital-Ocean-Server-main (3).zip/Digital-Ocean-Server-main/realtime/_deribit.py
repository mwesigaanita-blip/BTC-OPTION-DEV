"""Minimal, self-contained Deribit client for the realtime poller.

Why this lives here instead of importing ``hedge_engine.data.deribit_client``:

* The realtime container must keep working even if the larger
  ``hedge_engine`` package isn't fully present in a deployment (e.g. the
  ``hedge_engine/data/`` subtree isn't always shipped).
* The poller only needs three endpoints - account summary, positions,
  index price. Inlining a ~80 line client here avoids a fragile
  cross-package dependency on the hot path.

Environment:

* ``DERIBIT_CLIENT_ID``      (required)
* ``DERIBIT_CLIENT_SECRET``  (required)
* ``DERIBIT_BASE_URL``       (optional, default ``https://www.deribit.com``)
* ``DERIBIT_TIMEOUT_S``      (optional, default 10)

Auth + retries follow the same shape as the larger client so behaviour is
identical from the poller's perspective.
"""
from __future__ import annotations

import json
import os
import random
import time
from typing import Any, Dict, Optional

import requests

try:
    from dotenv import load_dotenv
    load_dotenv()
except Exception:
    pass


class DeribitError(RuntimeError):
    pass


def _backoff(attempt: int, base: float = 0.35, cap: float = 6.0, jitter: float = 0.15) -> float:
    raw = min(cap, base * (2 ** attempt))
    return max(0.0, raw + random.uniform(-jitter, jitter))


class DeribitClient:
    """Bare-bones Deribit JSON-RPC client (HTTPS, sync, retrying)."""

    def __init__(
        self,
        *,
        base_url: str,
        client_id: str,
        client_secret: str,
        timeout_s: float = 10.0,
        max_retries: int = 5,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.client_id = client_id
        self.client_secret = client_secret
        self.timeout_s = float(timeout_s)
        self.max_retries = int(max_retries)

        self._session = requests.Session()
        self._rpc_id = 0
        self._token: Optional[str] = None
        self._token_expires_at: float = 0.0

    # ------------------------------------------------------------------
    @staticmethod
    def from_env() -> "DeribitClient":
        cid = os.getenv("DERIBIT_CLIENT_ID", "").strip()
        sec = os.getenv("DERIBIT_CLIENT_SECRET", "").strip()
        if not cid or not sec:
            raise ValueError("Missing DERIBIT_CLIENT_ID / DERIBIT_CLIENT_SECRET in env")
        return DeribitClient(
            base_url=os.getenv("DERIBIT_BASE_URL", "https://www.deribit.com"),
            client_id=cid,
            client_secret=sec,
            timeout_s=float(os.getenv("DERIBIT_TIMEOUT_S", "10")),
        )

    # ------------------------------------------------------------------
    def _next_id(self) -> int:
        self._rpc_id += 1
        return self._rpc_id

    def _rpc(self, method: str, params: Optional[Dict[str, Any]] = None, *, auth: bool) -> Dict[str, Any]:
        url = f"{self.base_url}/api/v2"
        payload = {"jsonrpc": "2.0", "id": self._next_id(), "method": method, "params": params or {}}
        headers = {"Content-Type": "application/json"}
        if auth:
            headers["Authorization"] = f"Bearer {self._access_token()}"

        last_err: Optional[Exception] = None
        for attempt in range(self.max_retries + 1):
            try:
                r = self._session.post(url, data=json.dumps(payload), headers=headers, timeout=self.timeout_s)

                if r.status_code in (408, 429, 500, 502, 503, 504):
                    raise DeribitError(f"HTTP {r.status_code}: transient")
                if r.status_code >= 400:
                    raise DeribitError(f"HTTP {r.status_code}: {r.text[:500]}")

                out = r.json()
                if "error" in out and out["error"] is not None:
                    code = int((out["error"] or {}).get("code", 0) or 0)
                    msg = str((out["error"] or {}).get("message", "") or "")
                    if code in (13009, 13004) or "invalid_token" in msg.lower():
                        self._token = None
                        self._token_expires_at = 0.0
                        if attempt < self.max_retries:
                            continue
                    raise DeribitError(f"RPC error code={code} msg={msg}")
                return out["result"]

            except (requests.Timeout, requests.ConnectionError, DeribitError) as e:
                last_err = e
                if attempt >= self.max_retries:
                    break
                time.sleep(_backoff(attempt))

        raise DeribitError(f"Deribit RPC failed method={method}: {last_err}")

    # ------------------------------------------------------------------
    def _access_token(self) -> str:
        if self._token and time.time() < (self._token_expires_at - 15.0):
            return self._token
        result = self._rpc(
            "public/auth",
            params={
                "grant_type": "client_credentials",
                "client_id": self.client_id,
                "client_secret": self.client_secret,
            },
            auth=False,
        )
        token = str(result.get("access_token", "") or "")
        ttl = float(result.get("expires_in", 0) or 0)
        if not token or ttl <= 0:
            raise DeribitError("Auth failed: missing access_token / expires_in")
        self._token = token
        self._token_expires_at = time.time() + ttl
        return token

    # ------------------------------------------------------------------
    # Three endpoints used by the poller
    # ------------------------------------------------------------------
    def get_account_summary(self, *, currency: str = "BTC", extended: bool = True) -> dict:
        return self._rpc(
            "private/get_account_summary",
            params={"currency": currency.upper(), "extended": bool(extended)},
            auth=True,
        ) or {}

    def get_positions(self, currency: str = "BTC") -> list[dict]:
        res = self._rpc("private/get_positions", params={"currency": currency.upper()}, auth=True) or []
        # Normalize ``delta`` → ``net_delta`` so downstream code mirrors the
        # bigger hedge_engine client's contract.
        out = []
        for p in res:
            row = dict(p)
            try:
                row["net_delta"] = float(row.get("delta", 0.0) or 0.0)
            except Exception:
                row["net_delta"] = 0.0
            out.append(row)
        return out

    def get_index_price(self, *, index_name: str = "btc_usd") -> float:
        res = self._rpc("public/get_index_price", params={"index_name": index_name}, auth=False) or {}
        return float(res.get("index_price", 0.0) or 0.0)
