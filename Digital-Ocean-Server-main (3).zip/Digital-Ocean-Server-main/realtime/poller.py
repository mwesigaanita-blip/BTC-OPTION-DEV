"""Fast poller - fetch Deribit account/positions/spot every 5 seconds.

The poller is intentionally dumb: it pulls raw payloads from Deribit and
dumps them straight into ``realtime.sqlite``. No greeks, no margin %, no
joins - those happen in the aggregator. Keeping this hot loop simple is
what lets it finish well under 1 s per tick.

Failure policy
--------------

* Every API call is wrapped in try/except; an error never escapes ``run_once``.
* A single tick failure is logged and accounted for - the loop keeps ticking.
* The Deribit client itself already retries with exponential backoff on
  transient HTTP/RPC errors, so we don't double-retry here.

Run it stand-alone:

    python -m realtime.poller            # foreground loop until Ctrl-C
    python -m realtime.poller --once     # single tick, useful for cron / smoke
"""
from __future__ import annotations

import argparse
import json
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

from ._deribit import DeribitClient
from ._logging import debug_dump_dir, get_logger
from .storage import (
    init_realtime_db,
    save_account_tick,
    save_market_tick,
    save_positions_tick,
    utc_now_iso,
)

log = get_logger("realtime.poller")

POLL_INTERVAL_S = 5.0
DEFAULT_CURRENCY = "BTC"
DEFAULT_INDEX = "btc_usd"

# How often (in ticks) to write a raw debug dump to disk. 1 / 60 = once a minute
# at 5-second cadence - enough for forensics, light enough not to drown /logs.
DEBUG_DUMP_EVERY = 12


@dataclass
class PollerStats:
    """In-memory health snapshot for the health_check() endpoint."""
    started_at_utc: Optional[str] = None
    last_tick_utc: Optional[str] = None
    last_tick_ms: float = 0.0
    last_error: Optional[str] = None
    ok_ticks: int = 0
    failed_ticks: int = 0
    failed_subcalls: dict = field(default_factory=lambda: {"account": 0, "positions": 0, "price": 0})


class Poller:
    """Owns the 5-second loop and a single ``DeribitClient``."""

    def __init__(
        self,
        client: Optional[DeribitClient] = None,
        *,
        currency: str = DEFAULT_CURRENCY,
        index_name: str = DEFAULT_INDEX,
        interval_s: float = POLL_INTERVAL_S,
    ) -> None:
        self.currency = currency
        self.index_name = index_name
        self.interval_s = float(interval_s)
        self.stats = PollerStats()
        self._stop = threading.Event()
        self._tick_count = 0
        self._client = client  # lazy init in _client_or_init for safer test-time usage

        init_realtime_db()

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def stop(self) -> None:
        self._stop.set()

    def health_check(self) -> dict:
        return {
            "started_at_utc": self.stats.started_at_utc,
            "last_tick_utc": self.stats.last_tick_utc,
            "last_tick_ms": round(self.stats.last_tick_ms, 2),
            "ok_ticks": self.stats.ok_ticks,
            "failed_ticks": self.stats.failed_ticks,
            "failed_subcalls": dict(self.stats.failed_subcalls),
            "last_error": self.stats.last_error,
            "alive": (not self._stop.is_set()),
        }

    # ------------------------------------------------------------------
    # Hot path
    # ------------------------------------------------------------------

    def _client_or_init(self) -> Optional[DeribitClient]:
        if self._client is None:
            try:
                self._client = DeribitClient.from_env()
            except Exception as e:
                log.error("Deribit client init failed: %s", e)
                return None
        return self._client

    def run_once(self) -> bool:
        """One full poll iteration. Returns True if at least one sub-call succeeded.

        Each sub-call (account / positions / price) is independent: a failure
        in one does not skip the others. This is deliberate so a transient
        spike on /private/get_account_summary does not blank our market_ticks.
        """
        t0 = time.perf_counter()
        client = self._client_or_init()
        if client is None:
            self.stats.failed_ticks += 1
            self.stats.last_error = "deribit_client_unavailable"
            return False

        ts = utc_now_iso()
        any_ok = False

        account_payload: Optional[dict] = None
        positions_payload: Optional[list] = None
        price: Optional[float] = None

        # account summary
        try:
            account_payload = client.get_account_summary(currency=self.currency, extended=True)
            save_account_tick(ts, account_payload)
            any_ok = True
        except Exception as e:
            self.stats.failed_subcalls["account"] += 1
            self.stats.last_error = f"account: {e!r}"
            log.warning("account_summary failed: %s", e)

        # positions
        try:
            positions_payload = client.get_positions(currency=self.currency)
            save_positions_tick(ts, positions_payload)
            any_ok = True
        except Exception as e:
            self.stats.failed_subcalls["positions"] += 1
            self.stats.last_error = f"positions: {e!r}"
            log.warning("get_positions failed: %s", e)

        # spot index
        try:
            price = client.get_index_price(index_name=self.index_name)
            if price and price > 0:
                save_market_tick(ts, price)
                any_ok = True
        except Exception as e:
            self.stats.failed_subcalls["price"] += 1
            self.stats.last_error = f"price: {e!r}"
            log.warning("get_index_price failed: %s", e)

        elapsed_ms = (time.perf_counter() - t0) * 1000.0
        self.stats.last_tick_utc = ts
        self.stats.last_tick_ms = elapsed_ms
        self._tick_count += 1

        if any_ok:
            self.stats.ok_ticks += 1
        else:
            self.stats.failed_ticks += 1

        log.info(
            "tick ts=%s ms=%.1f acct=%s pos=%s price=%s",
            ts,
            elapsed_ms,
            "ok" if account_payload is not None else "ERR",
            ("ok(%d)" % len(positions_payload)) if positions_payload is not None else "ERR",
            ("%.2f" % price) if price else "ERR",
        )

        # periodic debug dump (raw JSON for forensics)
        if any_ok and self._tick_count % DEBUG_DUMP_EVERY == 0:
            self._dump_debug(ts, account_payload, positions_payload, price)

        # >1 s warning helps catch creeping latency early
        if elapsed_ms > 1000.0:
            log.warning("tick exceeded 1s budget (%.1f ms)", elapsed_ms)

        return any_ok

    # ------------------------------------------------------------------
    # Loop driver
    # ------------------------------------------------------------------

    def run_forever(self) -> None:
        self.stats.started_at_utc = utc_now_iso()
        log.info(
            "poller starting interval=%.1fs currency=%s index=%s",
            self.interval_s, self.currency, self.index_name,
        )
        while not self._stop.is_set():
            cycle_start = time.perf_counter()
            try:
                self.run_once()
            except Exception as e:
                # belt + suspenders: run_once already swallows exceptions, but
                # the loop must NEVER die.
                self.stats.failed_ticks += 1
                self.stats.last_error = f"unexpected: {e!r}"
                log.exception("unexpected poller error: %s", e)

            elapsed = time.perf_counter() - cycle_start
            sleep_for = max(0.0, self.interval_s - elapsed)
            if self._stop.wait(timeout=sleep_for):
                break

        log.info("poller stopped (ok=%d failed=%d)", self.stats.ok_ticks, self.stats.failed_ticks)

    # ------------------------------------------------------------------
    # Debug dumps
    # ------------------------------------------------------------------

    def _dump_debug(
        self,
        ts: str,
        account: Any,
        positions: Any,
        price: Optional[float],
    ) -> None:
        try:
            safe_ts = ts.replace(":", "").replace(".", "_")
            dest: Path = debug_dump_dir() / f"tick_{safe_ts}.json"
            dest.write_text(
                json.dumps(
                    {
                        "ts_utc": ts,
                        "btc_price": price,
                        "account_summary": account,
                        "positions": positions,
                    },
                    default=str,
                    indent=2,
                ),
                encoding="utf-8",
            )
        except Exception as e:
            log.warning("debug dump failed: %s", e)


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def _build_argparser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="realtime.poller", description="Realtime Deribit tick poller")
    p.add_argument("--once", action="store_true", help="Run a single tick and exit")
    p.add_argument("--interval", type=float, default=POLL_INTERVAL_S, help="Polling interval in seconds")
    p.add_argument("--currency", default=DEFAULT_CURRENCY)
    p.add_argument("--index", default=DEFAULT_INDEX)
    return p


def main(argv: Optional[list[str]] = None) -> int:
    args = _build_argparser().parse_args(argv)
    poller = Poller(currency=args.currency, index_name=args.index, interval_s=args.interval)
    if args.once:
        ok = poller.run_once()
        print(json.dumps(poller.health_check(), indent=2))
        return 0 if ok else 1
    try:
        poller.run_forever()
    except KeyboardInterrupt:
        poller.stop()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
