"""Retention sweeper - keep only the last 72 hours of ticks.

Why a separate process from the poller:

* Cleanup must NEVER stall a write. Running it on a different cadence
  (5 min) and a separate connection means a slow DELETE never widens the
  poller's tick latency.
* WAL allows concurrent reads/writes; the DELETE only briefly contends
  with the active page being written.

We run a periodic ``PRAGMA wal_checkpoint(TRUNCATE)`` so the WAL file
doesn't grow unbounded after a long burst of activity.
"""
from __future__ import annotations

import argparse
import sqlite3
import time
from datetime import datetime, timedelta, timezone
from typing import Optional

from ._logging import get_logger
from .storage import REALTIME_DB, init_realtime_db

log = get_logger("realtime.cleanup")

CLEANUP_INTERVAL_S = 5 * 60  # 5 minutes
RETENTION_HOURS = 72  # 3 days of 5s ticks; longer history lives in hedge_engine_aggregated_metrics
TABLES = ("account_ticks", "positions_ticks", "market_ticks")


def _cutoff_iso(hours: int = RETENTION_HOURS) -> str:
    cutoff = datetime.now(timezone.utc) - timedelta(hours=hours)
    return cutoff.strftime("%Y-%m-%dT%H:%M:%S.%f") + "Z"


def run_cleanup(retention_hours: int = RETENTION_HOURS) -> dict:
    """Delete rows older than ``retention_hours`` from each tick table.

    Returns a per-table count of deleted rows for logging / health.
    """
    init_realtime_db()
    cutoff = _cutoff_iso(retention_hours)
    deleted: dict[str, int] = {}

    # Cleanup uses its own short-lived connection - we don't want to share a
    # connection with the poller's thread-local cache.
    conn = sqlite3.connect(str(REALTIME_DB), timeout=10.0, isolation_level=None)
    try:
        conn.execute("PRAGMA busy_timeout = 10000;")
        t0 = time.perf_counter()
        for tbl in TABLES:
            cur = conn.execute(f"DELETE FROM {tbl} WHERE ts_utc < ?;", (cutoff,))
            deleted[tbl] = cur.rowcount or 0

        # keep WAL bounded
        try:
            conn.execute("PRAGMA wal_checkpoint(TRUNCATE);")
        except sqlite3.OperationalError as e:
            log.warning("wal_checkpoint failed: %s", e)

        elapsed_ms = (time.perf_counter() - t0) * 1000.0
        total = sum(deleted.values())
        log.info(
            "cleanup cutoff=%s deleted=%d (%s) ms=%.1f",
            cutoff,
            total,
            ",".join(f"{k}={v}" for k, v in deleted.items()),
            elapsed_ms,
        )
    finally:
        conn.close()
    return deleted


def run_forever(
    interval_s: float = CLEANUP_INTERVAL_S,
    *,
    stop_event=None,
) -> None:
    log.info("cleanup loop starting interval=%.0fs retention=%dh", interval_s, RETENTION_HOURS)
    while True:
        try:
            run_cleanup()
        except Exception as e:
            log.exception("cleanup failed: %s", e)
        if stop_event is not None:
            if stop_event.wait(timeout=interval_s):
                break
        else:
            time.sleep(interval_s)
    log.info("cleanup loop stopped")


def main(argv: Optional[list[str]] = None) -> int:
    p = argparse.ArgumentParser(prog="realtime.cleanup")
    p.add_argument("--once", action="store_true", help="Run cleanup once and exit")
    p.add_argument("--hours", type=int, default=RETENTION_HOURS)
    p.add_argument("--interval", type=float, default=CLEANUP_INTERVAL_S)
    args = p.parse_args(argv)

    if args.once:
        run_cleanup(retention_hours=args.hours)
        return 0
    try:
        run_forever(interval_s=args.interval)
    except KeyboardInterrupt:
        pass
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
