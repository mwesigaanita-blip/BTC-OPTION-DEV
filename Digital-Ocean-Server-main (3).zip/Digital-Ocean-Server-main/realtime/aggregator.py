"""60-second aggregator - roll raw ticks into hedge-engine metrics.

Pulls the last ``LOOKBACK_S`` seconds of ticks from ``realtime.sqlite``,
extracts a single representative point (the most-recent tick in the
window), and writes one row to
``hedge_engine.sqlite.hedge_engine_aggregated_metrics``.

Why this is in its own module / process boundary
------------------------------------------------

* The poller MUST stay <1 s; greek/margin maths happen here.
* This is the only writer that touches ``hedge_engine.sqlite`` from the
  realtime pipeline. Everything else stays inside ``realtime.sqlite``.
* Read from realtime DB, write to hedge_engine DB - two separate
  connections, no cross-DB transactions, no shared locks.

Output schema (``hedge_engine_aggregated_metrics``):

    ts_utc      TEXT PRIMARY KEY  -- end of the 60s window, ISO UTC
    delta       REAL              -- portfolio delta (BTC)
    gamma       REAL
    vega        REAL
    mm_pct      REAL              -- maintenance_margin / margin_balance * 100
    btc_price   REAL              -- last index price in window
    btc_roc     REAL              -- (last - first) / first  (decimal, e.g. 0.0023 = +0.23%)
    sample_n    INTEGER           -- number of ticks observed in the window (audit)
    created_at  TEXT              -- write time (UTC)
"""
from __future__ import annotations

import argparse
import json
import sqlite3
import time
from datetime import datetime, timedelta, timezone
from typing import Any, Optional

from shared.db_paths import HEDGE_ENGINE_DB

from ._logging import get_logger
from .storage import REALTIME_DB, init_realtime_db, utc_now_iso

log = get_logger("realtime.aggregator")

LOOKBACK_S = 60
AGG_INTERVAL_S = 60.0
TABLE_NAME = "hedge_engine_aggregated_metrics"

_SCHEMA_SQL = f"""
CREATE TABLE IF NOT EXISTS {TABLE_NAME} (
    ts_utc     TEXT PRIMARY KEY,
    delta      REAL,
    gamma      REAL,
    vega       REAL,
    mm_pct     REAL,
    btc_price  REAL,
    btc_roc    REAL,
    sample_n   INTEGER,
    created_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_{TABLE_NAME}_ts ON {TABLE_NAME}(ts_utc);
"""


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _sf(v: Any, default: float = 0.0) -> float:
    try:
        if v is None:
            return default
        return float(v)
    except Exception:
        return default


def _window_start_iso(seconds: int = LOOKBACK_S) -> str:
    start = datetime.now(timezone.utc) - timedelta(seconds=seconds)
    return start.strftime("%Y-%m-%dT%H:%M:%S.%f") + "Z"


def _ensure_hedge_engine_table() -> None:
    conn = sqlite3.connect(str(HEDGE_ENGINE_DB), timeout=10.0)
    try:
        conn.executescript(_SCHEMA_SQL)
        conn.commit()
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Greek / margin extraction
# ---------------------------------------------------------------------------

def _extract_greeks_and_margin(account_payload: dict, positions_payload: list) -> dict:
    """Reproduce the hedge engine's account-first / positions-fallback logic.

    Mirrors ``hedge_engine.core.portfolio_state.build_current_state_from_deribit``
    but kept inline here so the realtime pipeline does not import the heavier
    engine module on the hot path.
    """
    acct = account_payload or {}
    positions = positions_payload or []

    # delta: account-level → positions sum fallback
    delta = _sf(acct.get("delta_total"))
    if delta == 0.0:
        od = _sf(acct.get("options_delta"))
        fd = _sf(acct.get("futures_delta"))
        if od or fd:
            delta = od + fd
        else:
            delta = sum(_sf(p.get("net_delta", p.get("delta"))) for p in positions)

    gamma = _sf(acct.get("options_gamma")) or sum(_sf(p.get("gamma")) for p in positions)
    vega = _sf(acct.get("options_vega")) or sum(_sf(p.get("vega")) for p in positions)

    # margin %: USD-aggregate first, BTC-denominated fallback
    mb = _sf(acct.get("total_margin_balance_usd")) or _sf(acct.get("margin_balance"))
    mm = _sf(acct.get("total_maintenance_margin_usd")) or _sf(acct.get("maintenance_margin"))
    mm_pct = (mm / mb * 100.0) if mb > 0 else 0.0

    return {"delta": delta, "gamma": gamma, "vega": vega, "mm_pct": mm_pct}


# ---------------------------------------------------------------------------
# Window readers
# ---------------------------------------------------------------------------

def _fetch_window(conn: sqlite3.Connection, since_iso: str) -> dict:
    """Return latest account + positions tick + first/last price in the window."""
    out: dict[str, Any] = {
        "account": None,
        "positions": None,
        "ts_account": None,
        "ts_positions": None,
        "ts_market_last": None,
        "btc_first": None,
        "btc_last": None,
        "sample_n": 0,
    }

    row = conn.execute(
        "SELECT ts_utc, payload_json FROM account_ticks "
        "WHERE ts_utc >= ? ORDER BY ts_utc DESC LIMIT 1;",
        (since_iso,),
    ).fetchone()
    if row:
        try:
            out["account"] = json.loads(row["payload_json"])
            out["ts_account"] = row["ts_utc"]
        except Exception as e:
            log.warning("bad account_ticks payload: %s", e)

    row = conn.execute(
        "SELECT ts_utc, payload_json FROM positions_ticks "
        "WHERE ts_utc >= ? ORDER BY ts_utc DESC LIMIT 1;",
        (since_iso,),
    ).fetchone()
    if row:
        try:
            out["positions"] = json.loads(row["payload_json"])
            out["ts_positions"] = row["ts_utc"]
        except Exception as e:
            log.warning("bad positions_ticks payload: %s", e)

    # market: take first + last for ROC, count for sample_n
    rows = conn.execute(
        "SELECT ts_utc, btc_price FROM market_ticks "
        "WHERE ts_utc >= ? ORDER BY ts_utc ASC;",
        (since_iso,),
    ).fetchall()
    if rows:
        out["btc_first"] = float(rows[0]["btc_price"])
        out["btc_last"] = float(rows[-1]["btc_price"])
        out["ts_market_last"] = rows[-1]["ts_utc"]
        out["sample_n"] = len(rows)

    return out


# ---------------------------------------------------------------------------
# Main aggregation step
# ---------------------------------------------------------------------------

def run_once() -> Optional[dict]:
    """Compute one aggregated metrics row. Returns the row dict or ``None`` on no data."""
    init_realtime_db()
    _ensure_hedge_engine_table()

    t0 = time.perf_counter()
    since = _window_start_iso(LOOKBACK_S)
    rt_conn = sqlite3.connect(str(REALTIME_DB), timeout=5.0)
    rt_conn.row_factory = sqlite3.Row
    try:
        win = _fetch_window(rt_conn, since)
    finally:
        rt_conn.close()

    if not any([win["account"], win["positions"], win["btc_last"]]):
        log.warning("no ticks in window since=%s - skipping aggregation", since)
        return None

    metrics = _extract_greeks_and_margin(win["account"] or {}, win["positions"] or [])

    btc_price = _sf(win["btc_last"])
    btc_first = _sf(win["btc_first"])
    btc_roc = ((btc_price - btc_first) / btc_first) if btc_first > 0 else 0.0

    # Use the most recent observation's timestamp as the row's ts_utc so the
    # series is monotonic with the underlying truth, falling back to "now".
    ts_utc = win["ts_market_last"] or win["ts_account"] or win["ts_positions"] or utc_now_iso()
    created_at = utc_now_iso()

    row = {
        "ts_utc": ts_utc,
        "delta": metrics["delta"],
        "gamma": metrics["gamma"],
        "vega": metrics["vega"],
        "mm_pct": metrics["mm_pct"],
        "btc_price": btc_price,
        "btc_roc": btc_roc,
        "sample_n": int(win["sample_n"]),
        "created_at": created_at,
    }

    he_conn = sqlite3.connect(str(HEDGE_ENGINE_DB), timeout=10.0)
    try:
        he_conn.execute(
            f"INSERT OR REPLACE INTO {TABLE_NAME} "
            "(ts_utc, delta, gamma, vega, mm_pct, btc_price, btc_roc, sample_n, created_at) "
            "VALUES (:ts_utc, :delta, :gamma, :vega, :mm_pct, :btc_price, :btc_roc, :sample_n, :created_at);",
            row,
        )
        he_conn.commit()
    finally:
        he_conn.close()

    elapsed_ms = (time.perf_counter() - t0) * 1000.0
    log.info(
        "aggregated ts=%s delta=%.4f gamma=%.6f vega=%.4f mm%%=%.2f btc=%.2f roc=%+.4f%% n=%d ms=%.1f",
        ts_utc, row["delta"], row["gamma"], row["vega"], row["mm_pct"],
        row["btc_price"], row["btc_roc"] * 100, row["sample_n"], elapsed_ms,
    )
    return row


def run_forever(interval_s: float = AGG_INTERVAL_S, *, stop_event=None) -> None:
    log.info("aggregator loop starting interval=%.1fs lookback=%ds", interval_s, LOOKBACK_S)
    while True:
        cycle_start = time.perf_counter()
        try:
            run_once()
        except Exception as e:
            log.exception("aggregator failed: %s", e)
        elapsed = time.perf_counter() - cycle_start
        sleep_for = max(0.0, interval_s - elapsed)
        if stop_event is not None:
            if stop_event.wait(timeout=sleep_for):
                break
        else:
            time.sleep(sleep_for)
    log.info("aggregator loop stopped")


def main(argv: Optional[list[str]] = None) -> int:
    p = argparse.ArgumentParser(prog="realtime.aggregator")
    p.add_argument("--once", action="store_true")
    p.add_argument("--interval", type=float, default=AGG_INTERVAL_S)
    args = p.parse_args(argv)

    if args.once:
        row = run_once()
        print(json.dumps(row, indent=2, default=str))
        return 0 if row else 1
    try:
        run_forever(interval_s=args.interval)
    except KeyboardInterrupt:
        pass
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
