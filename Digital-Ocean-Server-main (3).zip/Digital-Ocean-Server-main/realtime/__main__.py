"""``python -m realtime`` → starts the full scheduler.

Equivalent to ``python -m realtime.scheduler``. Sub-modules can still
be invoked individually (``python -m realtime.poller`` etc.).
"""
from realtime.scheduler import main

if __name__ == "__main__":
    raise SystemExit(main())
