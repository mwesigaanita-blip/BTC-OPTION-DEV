-- realtime.sqlite - high-frequency tick store (Phase 2)
--
-- This file is the canonical source of truth for the realtime pipeline's
-- schema. ``realtime.storage.init_realtime_db()`` applies the same DDL
-- programmatically on first use - keep both in sync if you change one.

PRAGMA journal_mode = WAL;
PRAGMA synchronous  = NORMAL;
PRAGMA temp_store   = MEMORY;
PRAGMA busy_timeout = 5000;

CREATE TABLE IF NOT EXISTS account_ticks (
    ts_utc       TEXT PRIMARY KEY,    -- ISO-8601 UTC, microsecond precision, 'Z' suffix
    payload_json TEXT NOT NULL        -- raw Deribit private/get_account_summary response
);

CREATE TABLE IF NOT EXISTS positions_ticks (
    ts_utc       TEXT PRIMARY KEY,
    payload_json TEXT NOT NULL        -- raw Deribit private/get_positions response (list)
);

CREATE TABLE IF NOT EXISTS market_ticks (
    ts_utc    TEXT PRIMARY KEY,
    btc_price REAL NOT NULL           -- public/get_index_price (btc_usd)
);

CREATE INDEX IF NOT EXISTS idx_account_ticks_ts   ON account_ticks(ts_utc);
CREATE INDEX IF NOT EXISTS idx_positions_ticks_ts ON positions_ticks(ts_utc);
CREATE INDEX IF NOT EXISTS idx_market_ticks_ts    ON market_ticks(ts_utc);


-- Aggregated metrics live in hedge_engine.sqlite (separate DB!).
-- Schema reproduced here for reference - created by realtime.aggregator.
--
-- CREATE TABLE IF NOT EXISTS hedge_engine_aggregated_metrics (
--     ts_utc     TEXT PRIMARY KEY,
--     delta      REAL,
--     gamma      REAL,
--     vega       REAL,
--     mm_pct     REAL,
--     btc_price  REAL,
--     btc_roc    REAL,
--     sample_n   INTEGER,
--     created_at TEXT
-- );
-- CREATE INDEX IF NOT EXISTS idx_hedge_engine_aggregated_metrics_ts
--     ON hedge_engine_aggregated_metrics(ts_utc);
