# Realtime ingestion pipeline (Phase 2)

Fast Deribit poller → `data/realtime.sqlite` → 60 s aggregator → `data/hedge_engine.sqlite::hedge_engine_aggregated_metrics` → dashboard.

```
   Deribit API
       │  every 5 s
       ▼
   poller.py ──▶ storage.py ──▶ realtime.sqlite
                                     │  every 60 s
                                     ▼
                                aggregator.py
                                     │
                                     ▼
                          hedge_engine.sqlite
                            (aggregated metrics)
                                     │
                                     ▼
                               Dashboard (Live)
```

Cleanup runs every 5 minutes and trims rows older than **72 h**. Longer
history (week / month / year) is served from `hedge_engine_aggregated_metrics`
which keeps 60 s rollups indefinitely.

## Modules

| File | Purpose |
|------|---------|
| `storage.py` | WAL-mode sqlite + `INSERT OR REPLACE` writers |
| `poller.py` | 5 s loop, calls Deribit, writes 3 tables |
| `aggregator.py` | 60 s loop, computes delta/gamma/vega/mm%/btc_roc |
| `cleanup.py` | 24 h retention sweeper, runs every 5 min |
| `scheduler.py` | Threaded supervisor: `start()` / `stop()` |
| `live_view.py` | Read-only helpers for dashboard "Live Mode" |
| `schema.sql` | Canonical DDL for `realtime.sqlite` |

## Run it

```bash
# full pipeline (recommended)
python -m realtime                       # alias for realtime.scheduler
python -m realtime.scheduler             # SIGINT to stop

# components in isolation
python -m realtime.poller                # foreground 5 s loop
python -m realtime.poller --once         # one tick + health JSON
python -m realtime.aggregator --once
python -m realtime.cleanup --once
```

## Embed it in another process

```python
from realtime.scheduler import RealtimeScheduler

sched = RealtimeScheduler()
sched.start()                     # non-blocking, daemon threads
...                               # do other work
print(sched.health_check())
sched.stop(timeout_s=10)
```

## Dashboard ("Live Mode")

```python
from realtime.live_view import read_latest_live_state, read_recent_market_ticks

state = read_latest_live_state()
# { "account_tick": {...}, "positions_tick": {...},
#   "market_tick": {...},  "aggregated": {...} }

prices = read_recent_market_ticks(limit=720)   # last hour @ 5 s
```

When the toggle is OFF, fall back to whatever the page used before
(e.g. `snapshots.sqlite`).

## Output schema (`hedge_engine_aggregated_metrics`)

| Column | Type | Notes |
|--------|------|-------|
| `ts_utc` | TEXT PK | end of 60 s window |
| `delta` | REAL | portfolio delta (BTC) |
| `gamma` | REAL | |
| `vega` | REAL | |
| `mm_pct` | REAL | maintenance / margin balance × 100 |
| `btc_price` | REAL | last index price in window |
| `btc_roc` | REAL | rate of change, decimal (0.002 = +0.2 %) |
| `sample_n` | INTEGER | tick count in window (audit) |
| `created_at` | TEXT | row write time, UTC |

## Operational guarantees

- **Non-blocking** - the scheduler runs three daemon threads; `start()` returns immediately.
- **Loops never crash** - every iteration is wrapped; failures are logged and the loop continues.
- **Hedge engine isolation** - only the aggregator writes to `hedge_engine.sqlite`, and only to the new `hedge_engine_aggregated_metrics` table. Nothing else in the realtime pipeline touches it.
- **Tick budget** - poller logs a warning if a tick exceeds 1 s.
- **WAL mode** - concurrent readers (dashboard) and writer (poller) do not block each other.
- **Idempotent writes** - `INSERT OR REPLACE` keyed on `ts_utc`.
- **UTC only** - every timestamp is microsecond-precision ISO-8601 with `Z`.

## Logging

All four components share `logs/realtime.log` (rotating, 5 MB × 3).
Periodic raw-payload dumps land in `logs/debug_ticks/` (one every ≈ 60 s).
