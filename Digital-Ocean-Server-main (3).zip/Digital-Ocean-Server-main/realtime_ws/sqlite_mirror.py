"""Mirror live WS data into the legacy realtime.sqlite tables.

# Schema + writers + pragmas copied from realtime/storage.py on 2026-05-10.
# Per plan §5: must not import from realtime/. Modify here only.

Why this exists (plan §6):
  The old REST poller (`realtime/poller.py`) writes a snapshot every 5 s into
  three tables (account_ticks, positions_ticks, market_ticks). Old services
  (aggregator, simple_hedge, MM bot) read from those tables. During the
  parallel-run period we need the new WS pipeline to produce **byte-compatible
  rows** so the existing services keep working unchanged.

Design - state cache + 5 s flush:
  WS messages are event-driven and high-frequency (perp ticker fires every
  100 ms). Mirroring every event would flood the table. Instead we maintain
  an in-process state cache:
    - latest user.portfolio.btc payload          → account_ticks
    - latest deribit_price_index.btc_usd price   → market_ticks
    - dict of latest position-by-instrument      → positions_ticks (full snapshot)
  A timer task drains the cache every 5 s with a single shared `ts_utc`,
  matching the legacy poller's cadence and write contract.

`INSERT OR REPLACE` keeps the writes idempotent - if the new and old
pipelines happen to produce the same `ts_utc` the second writer overwrites
without error. The parity check in Phase 7 tolerates this.
"""
from __future__ import annotations

import asyncio
import json
import logging
import sqlite3
import threading
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Mapping, Optional, Sequence, Union

from .db_paths import REALTIME_DB
from .metrics import sqlite_writes_failed_total, sqlite_writes_total

log = logging.getLogger("realtime_ws.sqlite_mirror")

DEFAULT_FLUSH_INTERVAL_S = 5.0
"""Match the legacy poller cadence (`realtime/poller.py:POLL_INTERVAL_S`)."""

# ---------------------------------------------------------------------------
# Schema (verbatim from realtime/storage.py)
# ---------------------------------------------------------------------------

_SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS account_ticks (
    ts_utc       TEXT PRIMARY KEY,
    payload_json TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS positions_ticks (
    ts_utc       TEXT PRIMARY KEY,
    payload_json TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS market_ticks (
    ts_utc    TEXT PRIMARY KEY,
    btc_price REAL NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_account_ticks_ts   ON account_ticks(ts_utc);
CREATE INDEX IF NOT EXISTS idx_positions_ticks_ts ON positions_ticks(ts_utc);
CREATE INDEX IF NOT EXISTS idx_market_ticks_ts    ON market_ticks(ts_utc);
"""

_PRAGMAS = (
    "PRAGMA journal_mode = WAL;",
    "PRAGMA synchronous  = NORMAL;",
    "PRAGMA temp_store   = MEMORY;",
    "PRAGMA busy_timeout = 5000;",
)


def utc_now_iso() -> str:
    """Microsecond-precision UTC ISO-8601 (e.g. ``2026-04-25T12:34:56.789012Z``)."""
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f") + "Z"


# ---------------------------------------------------------------------------
# Connection management (thread-local; same pattern as origin)
# ---------------------------------------------------------------------------

_tls = threading.local()
_init_lock = threading.Lock()
_initialized = False


def _new_conn() -> sqlite3.Connection:
    REALTIME_DB.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(
        str(REALTIME_DB),
        timeout=5.0,
        isolation_level=None,
        check_same_thread=True,
    )
    conn.row_factory = sqlite3.Row
    for pragma in _PRAGMAS:
        conn.execute(pragma)
    return conn


def init_realtime_db() -> None:
    """Idempotent: create file + tables on first call."""
    global _initialized
    with _init_lock:
        if _initialized:
            return
        conn = _new_conn()
        try:
            conn.executescript(_SCHEMA_SQL)
        finally:
            conn.close()
        _initialized = True


def get_realtime_conn() -> sqlite3.Connection:
    if not _initialized:
        init_realtime_db()
    conn = getattr(_tls, "conn", None)
    if conn is None:
        conn = _new_conn()
        _tls.conn = conn
    return conn


JsonLike = Union[Mapping[str, Any], Sequence[Any], None]


def _dumps(payload: JsonLike) -> str:
    return json.dumps(
        payload if payload is not None else {}, default=str, separators=(",", ":")
    )


def save_account_tick(ts: str, payload: JsonLike) -> None:
    get_realtime_conn().execute(
        "INSERT OR REPLACE INTO account_ticks (ts_utc, payload_json) VALUES (?, ?);",
        (ts, _dumps(payload)),
    )


def save_positions_tick(ts: str, payload: JsonLike) -> None:
    get_realtime_conn().execute(
        "INSERT OR REPLACE INTO positions_ticks (ts_utc, payload_json) VALUES (?, ?);",
        (ts, _dumps(payload)),
    )


def save_market_tick(ts: str, price: float) -> None:
    get_realtime_conn().execute(
        "INSERT OR REPLACE INTO market_ticks (ts_utc, btc_price) VALUES (?, ?);",
        (ts, float(price)),
    )


# ---------------------------------------------------------------------------
# Mirror state cache + flush task
# ---------------------------------------------------------------------------


@dataclass
class MirrorState:
    """Latest values from each WS channel that the legacy schema cares about."""

    account_payload: Optional[dict] = None
    btc_index_price: Optional[float] = None
    positions: dict[str, dict] = field(default_factory=dict)
    """Positions keyed by `instrument_name`. Updated from `user.changes.*`
    payloads' `positions` list. A position with size==0 stays in the cache
    as a flat row to match the legacy poller's behaviour."""

    _lock: threading.Lock = field(default_factory=threading.Lock, repr=False)

    def update_account(self, payload: dict) -> None:
        with self._lock:
            self.account_payload = payload

    def update_btc_index(self, price: float) -> None:
        with self._lock:
            self.btc_index_price = float(price)

    def update_positions(self, positions: list[dict]) -> None:
        if not positions:
            return
        with self._lock:
            for p in positions:
                inst = p.get("instrument_name")
                if not inst:
                    continue
                self.positions[inst] = p

    def snapshot(self) -> tuple[Optional[dict], Optional[float], list[dict]]:
        """Returns a snapshot tuple of (account_payload, btc_index, positions_list)."""
        with self._lock:
            return (
                self.account_payload,
                self.btc_index_price,
                list(self.positions.values()),
            )


class SqliteMirror:
    """Holds the cache + a periodic flush task. Lifecycle managed by run.py."""

    def __init__(self, *, flush_interval_s: float = DEFAULT_FLUSH_INTERVAL_S) -> None:
        self.flush_interval_s = float(flush_interval_s)
        self.state = MirrorState()
        self._task: Optional[asyncio.Task] = None
        self._stop = asyncio.Event()
        self._writes_total = 0
        self._writes_failed = 0

    # ---- handler hooks ---------------------------------------------------

    def on_message(self, channel: str, msg: dict) -> None:
        """Called for every WS message after the publisher has run.

        We update the in-memory cache from the **raw** Deribit payload
        (`msg.params.data`) so the SQLite mirror is byte-compatible with the
        legacy poller's schema (the aggregator reads `delta_total`,
        `options_gamma`, etc. from the raw shape - see plan §6 / §5).

        The flush task does the actual SQLite writes on a fixed cadence so we
        don't write per-event (would flood the table).
        """
        params = msg.get("params") or {}
        data = params.get("data")
        if data is None:
            return

        if channel == "user.portfolio.btc" and isinstance(data, dict):
            self.state.update_account(data)
        elif channel == "deribit_price_index.btc_usd" and isinstance(data, dict):
            price = data.get("price")
            if price is not None:
                try:
                    self.state.update_btc_index(float(price))
                except (TypeError, ValueError):
                    pass
        elif channel.startswith("user.changes.") and isinstance(data, dict):
            positions = data.get("positions") or []
            if positions:
                self.state.update_positions(positions)

    # ---- task lifecycle --------------------------------------------------

    def start(self) -> asyncio.Task:
        if self._task is not None:
            return self._task
        init_realtime_db()
        log.info(
            "sqlite mirror starting: db=%s flush=%.1fs",
            REALTIME_DB,
            self.flush_interval_s,
        )
        self._task = asyncio.create_task(self._flush_loop(), name="sqlite-mirror")
        return self._task

    def stop(self) -> None:
        self._stop.set()

    async def aclose(self) -> None:
        self.stop()
        if self._task is not None:
            try:
                await self._task
            except (asyncio.CancelledError, Exception):
                pass

    async def _flush_loop(self) -> None:
        try:
            while not self._stop.is_set():
                try:
                    await asyncio.wait_for(
                        self._stop.wait(), timeout=self.flush_interval_s
                    )
                    return  # stop requested
                except asyncio.TimeoutError:
                    pass
                await self._flush_once()
        except asyncio.CancelledError:
            return
        except Exception as e:
            log.exception("flush loop crashed: %s", e)

    async def _flush_once(self) -> None:
        # Run the sqlite writes off the event loop so a slow disk doesn't
        # block the WS read path.
        await asyncio.get_running_loop().run_in_executor(None, self._flush_sync)

    def _flush_sync(self) -> None:
        ts = utc_now_iso()
        account, btc_index, positions_list = self.state.snapshot()
        wrote = False
        try:
            if account is not None:
                save_account_tick(ts, account)
                wrote = True
            # Only emit positions when we actually have any cached. Avoids
            # writing empty `[]` rows before the user has any positions.
            if positions_list:
                save_positions_tick(ts, positions_list)
                wrote = True
            if btc_index is not None:
                save_market_tick(ts, btc_index)
                wrote = True
            if wrote:
                self._writes_total += 1
                sqlite_writes_total.inc()
        except Exception as e:
            self._writes_failed += 1
            sqlite_writes_failed_total.inc()
            log.warning("sqlite mirror write failed ts=%s err=%s", ts, e)

    # ---- introspection ---------------------------------------------------

    def stats(self) -> dict:
        return {
            "writes_total": self._writes_total,
            "writes_failed": self._writes_failed,
            "has_account": self.state.account_payload is not None,
            "has_btc_index": self.state.btc_index_price is not None,
            "positions_cached": len(self.state.positions),
        }
