"""Prometheus counters/gauges for the WS collector (plan §7, Phase 8).

Single module that owns the metric registry. Every other module imports the
counter/gauge it touches from here. No global mutable state beyond the
prometheus_client default REGISTRY.

Exposed via `realtime_ws.http_server` at GET /metrics.
"""
from __future__ import annotations

import time

from prometheus_client import Counter, Gauge

# ---------------------------------------------------------------------------
# WebSocket connection lifecycle
# ---------------------------------------------------------------------------

ws_reconnects_total = Counter(
    "ws_collector_reconnects_total",
    "Number of times the WS client has reconnected to Deribit after the first connect.",
)

ws_connection_state = Gauge(
    "ws_collector_connection_state",
    "1 if currently connected to Deribit, 0 otherwise.",
)

# Downtime tracking - gap between a disconnect and the next successful reconnect.
ws_downtime_seconds_total = Counter(
    "ws_collector_downtime_seconds_total",
    "Cumulative seconds the WS has been disconnected from Deribit since start.",
)

ws_last_downtime_seconds = Gauge(
    "ws_collector_last_downtime_seconds",
    "Duration of the most recent disconnect→reconnect gap, in seconds.",
)

ws_longest_downtime_seconds = Gauge(
    "ws_collector_longest_downtime_seconds",
    "Longest disconnect→reconnect gap observed since start, in seconds.",
)

ws_current_downtime_seconds = Gauge(
    "ws_collector_current_downtime_seconds",
    "Seconds since the current outage began, or 0 if currently connected.",
)


def refresh_current_downtime() -> None:
    """Push the current ongoing-outage duration so a scrape between WS events
    still sees a fresh value."""
    from .health import HEALTH

    snap = HEALTH.snapshot()
    ws_current_downtime_seconds.set(float(snap.get("current_downtime_s") or 0.0))

# ---------------------------------------------------------------------------
# Inbound messages
# ---------------------------------------------------------------------------

ws_messages_received_total = Counter(
    "ws_collector_messages_received_total",
    "Total Deribit WS messages received, by source channel.",
    ["channel"],
)

ws_last_message_age_seconds = Gauge(
    "ws_collector_last_message_age_seconds",
    "Seconds since the last WS message of any kind was received.",
)


def observe_message(channel: str) -> None:
    """Called from the WS read loop for every subscription message."""
    ws_messages_received_total.labels(channel=channel).inc()
    _LAST_MSG_TS["t"] = time.time()


# A gauge that needs "seconds since X" is awkward in pure prometheus_client
# because we'd need a callback. We push the update from a background task in
# http_server every few seconds instead.
_LAST_MSG_TS: dict[str, float] = {"t": 0.0}


def refresh_last_message_age() -> None:
    last = _LAST_MSG_TS["t"]
    ws_last_message_age_seconds.set(time.time() - last if last else 0.0)


# ---------------------------------------------------------------------------
# Token refresh
# ---------------------------------------------------------------------------

ws_token_refresh_total = Counter(
    "ws_collector_token_refresh_total",
    "Number of access-token refresh attempts, by outcome.",
    ["outcome"],
)
"""outcome ∈ {success, failed}."""

# ---------------------------------------------------------------------------
# Redis publisher
# ---------------------------------------------------------------------------

redis_publish_total = Counter(
    "ws_collector_redis_publish_total",
    "Number of Redis publish calls, by outcome.",
    ["outcome"],
)
"""outcome ∈ {success, failed}."""

redis_subscribers_seen = Gauge(
    "ws_collector_redis_subscribers_last",
    "Subscriber count returned by the most recent PUBLISH on each topic.",
    ["topic"],
)

# ---------------------------------------------------------------------------
# SQLite mirror
# ---------------------------------------------------------------------------

sqlite_writes_total = Counter(
    "ws_collector_sqlite_writes_total",
    "Number of SQLite flush cycles that wrote at least one row.",
)

sqlite_writes_failed_total = Counter(
    "ws_collector_sqlite_writes_failed_total",
    "Number of SQLite flush cycles that raised an exception.",
)

# ---------------------------------------------------------------------------
# Redis latest-snapshot cache
# ---------------------------------------------------------------------------

snapshot_writes_total = Counter(
    "ws_collector_snapshot_writes_total",
    "Number of Redis SET cycles writing app.*.latest snapshot keys.",
)

snapshot_writes_failed_total = Counter(
    "ws_collector_snapshot_writes_failed_total",
    "Number of Redis snapshot SET cycles that raised an exception.",
)

# ---------------------------------------------------------------------------
# Aggregator
# ---------------------------------------------------------------------------

aggregator_writes_total = Counter(
    "ws_collector_aggregator_writes_total",
    "Number of hedge_engine_aggregated_metrics rows written.",
)

# ---------------------------------------------------------------------------
# Subscriptions
# ---------------------------------------------------------------------------

subscriptions_active = Gauge(
    "ws_collector_subscriptions_active",
    "Number of Deribit channels currently subscribed.",
)

# ---------------------------------------------------------------------------
# Phase 9 - watchdog + crash-loop detection
# ---------------------------------------------------------------------------

watchdog_force_reconnects_total = Counter(
    "ws_collector_watchdog_force_reconnects_total",
    "Reconnects forced by the staleness watchdog (a subscribed channel went "
    "silent past WS_STALENESS_THRESHOLD_S).",
)

crash_loop_active = Gauge(
    "ws_collector_crash_loop_active",
    "1 if reconnects in the trailing 10-minute window exceeded the threshold "
    "(default 5), 0 otherwise.",
)

reconnect_window_count = Gauge(
    "ws_collector_reconnect_window_count",
    "Reconnects in the trailing 10-minute window.",
)

channel_last_message_age_seconds = Gauge(
    "ws_collector_channel_last_message_age_seconds",
    "Seconds since the last message on each subscribed channel.",
    ["channel"],
)
