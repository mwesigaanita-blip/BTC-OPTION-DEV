# realtime_ws

Deribit WebSocket collector. Self-contained - **must not import from `realtime/`, `mm_alert_bot/`, `backend_api/`, `hedge_engine/`, or `shared/`**. See plan: [02_priority1_backend_ws_implementation_plan.md](../new_dashboard_plan_doc/02_priority1_backend_ws_implementation_plan.md).

## Phase 1 status
Skeleton only. Connects to Redis, idles, exits cleanly on SIGTERM. No Deribit traffic yet.

## Run locally
```
python -m realtime_ws.run
```

## Isolation guard
Run before commit:
```
# linux/mac
bash scripts/check_ws_isolation.sh
# windows
powershell -File scripts/check_ws_isolation.ps1
```
Must return zero matches.
