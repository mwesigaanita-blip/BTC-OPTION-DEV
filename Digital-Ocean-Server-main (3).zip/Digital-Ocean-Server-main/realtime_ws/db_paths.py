"""Local copy of the database path constants we need.

# Copied from shared/db_paths.py on 2026-05-10.
# Per plan §5: realtime_ws must not import from shared/. Only the two
# constants this package uses (REALTIME_DB, HEDGE_ENGINE_DB) live here.
# The resolution rule is reproduced verbatim.

Resolution order for the data directory (first match wins):
  1. DB_BASE_DIR env var
  2. DATA_DIR env var
  3. <project_root>/data
"""
from __future__ import annotations

import os
from pathlib import Path

PROJECT_ROOT: Path = Path(
    os.getenv("PROJECT_ROOT", str(Path(__file__).resolve().parents[1]))
).resolve()


def _resolve_data_dir() -> Path:
    for var in ("DB_BASE_DIR", "DATA_DIR"):
        value = os.environ.get(var)
        if value:
            return Path(value).expanduser().resolve()
    return (PROJECT_ROOT / "data").resolve()


DATA_DIR: Path = _resolve_data_dir()
DATA_DIR.mkdir(parents=True, exist_ok=True)

REALTIME_DB: Path = DATA_DIR / "realtime.sqlite"
HEDGE_ENGINE_DB: Path = DATA_DIR / "hedge_engine.sqlite"

__all__ = ["DATA_DIR", "REALTIME_DB", "HEDGE_ENGINE_DB"]
