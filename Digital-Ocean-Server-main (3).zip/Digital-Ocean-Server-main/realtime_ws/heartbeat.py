"""Deribit heartbeat helpers.

Deribit's heartbeat protocol:
  - Client calls `public/set_heartbeat` with `interval` (seconds).
  - Server then sends two kinds of unsolicited messages on `method == "heartbeat"`:
      * params.type == "heartbeat"     → no action required.
      * params.type == "test_request"  → client MUST reply with `public/test`.
  - If we don't reply to test_request, Deribit considers the connection dead.

See: https://docs.deribit.com/#public-set_heartbeat
"""
from __future__ import annotations

import json
from typing import Any

_TEST_RPC_ID_BASE = 9_000_000  # high range so it doesn't clash with subscribe IDs


def build_set_heartbeat(rpc_id: int, interval_s: int) -> str:
    """JSON for `public/set_heartbeat`."""
    return json.dumps(
        {
            "jsonrpc": "2.0",
            "id": rpc_id,
            "method": "public/set_heartbeat",
            "params": {"interval": int(interval_s)},
        }
    )


def build_test_response(rpc_id: int | None = None) -> str:
    """JSON for `public/test` - sent in reply to a `test_request` heartbeat."""
    return json.dumps(
        {
            "jsonrpc": "2.0",
            "id": rpc_id or _TEST_RPC_ID_BASE,
            "method": "public/test",
            "params": {},
        }
    )


def is_heartbeat_message(msg: dict[str, Any]) -> bool:
    return msg.get("method") == "heartbeat"


def is_test_request(msg: dict[str, Any]) -> bool:
    if not is_heartbeat_message(msg):
        return False
    params = msg.get("params") or {}
    return params.get("type") == "test_request"
