"""Lightweight in-process health counters for the collector.

Phase 1: just enough state to expose "alive + redis ok". Later phases extend
with last_msg_at per channel, reconnect counts, disconnect durations, etc.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from threading import Lock


@dataclass
class Health:
    started_at: float = field(default_factory=time.time)
    redis_ok: bool = False
    last_redis_ping_at: float = 0.0
    last_msg_at: float = 0.0
    reconnects: int = 0
    disconnected_at: float = 0.0
    last_downtime_s: float = 0.0
    total_downtime_s: float = 0.0
    longest_downtime_s: float = 0.0
    # Deribit-side maintenance: set when the exchange rejects the WS handshake
    # with HTTP 503 or an RPC returns `system_maintenance` (code 11051).
    maintenance_since: float = 0.0
    maintenance_reason: str = ""
    _lock: Lock = field(default_factory=Lock, repr=False)

    def mark_redis(self, ok: bool) -> None:
        with self._lock:
            self.redis_ok = ok
            self.last_redis_ping_at = time.time()

    def mark_message(self) -> None:
        with self._lock:
            self.last_msg_at = time.time()

    def mark_disconnect(self) -> None:
        """Mark the WS as down. Idempotent within a single outage - repeated
        calls before a successful reconnect keep the original disconnect
        timestamp."""
        with self._lock:
            if self.disconnected_at == 0.0:
                self.disconnected_at = time.time()

    def mark_reconnect(self) -> float:
        """Mark a successful reconnect. Returns the downtime delta in seconds
        (0.0 if no prior disconnect was recorded)."""
        with self._lock:
            self.reconnects += 1
            if self.disconnected_at <= 0.0:
                return 0.0
            delta = time.time() - self.disconnected_at
            if delta < 0.0:
                delta = 0.0
            self.last_downtime_s = delta
            self.total_downtime_s += delta
            if delta > self.longest_downtime_s:
                self.longest_downtime_s = delta
            self.disconnected_at = 0.0
            return delta

    def mark_maintenance(self, reason: str = "") -> None:
        """Flag that Deribit is in maintenance. Idempotent - keeps the original
        start timestamp across repeated calls within one maintenance window."""
        with self._lock:
            if self.maintenance_since == 0.0:
                self.maintenance_since = time.time()
            self.maintenance_reason = reason or self.maintenance_reason

    def clear_maintenance(self) -> None:
        """Clear the maintenance flag - call once Deribit accepts a connection."""
        with self._lock:
            self.maintenance_since = 0.0
            self.maintenance_reason = ""

    def snapshot(self) -> dict:
        with self._lock:
            now = time.time()
            current_downtime_s = (
                round(now - self.disconnected_at, 1)
                if self.disconnected_at > 0.0
                else 0.0
            )
            return {
                "uptime_s": round(now - self.started_at, 1),
                "redis_ok": self.redis_ok,
                "last_redis_ping_age_s": round(now - self.last_redis_ping_at, 1)
                if self.last_redis_ping_at
                else None,
                "last_msg_age_s": round(now - self.last_msg_at, 1)
                if self.last_msg_at
                else None,
                "reconnects": self.reconnects,
                "current_downtime_s": current_downtime_s,
                "last_downtime_s": round(self.last_downtime_s, 1),
                "total_downtime_s": round(self.total_downtime_s, 1),
                "longest_downtime_s": round(self.longest_downtime_s, 1),
                "deribit_maintenance": self.maintenance_since > 0.0,
                "maintenance_since_s": round(now - self.maintenance_since, 1)
                if self.maintenance_since > 0.0
                else None,
                "maintenance_reason": self.maintenance_reason or None,
            }


HEALTH = Health()
