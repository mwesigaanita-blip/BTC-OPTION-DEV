"""Redis pub/sub publisher.

Two topic namespaces (plan §4):
  * `deribit.raw.<channel>`  - unmodified Deribit message (debug only).
  * `app.<topic>`            - normalized payload with `schema_v` + `fetched_at`.

A `REDIS_PUBSUB_PREFIX` env var (default empty) is prepended to every channel
name to allow multiple environments to share a Redis instance. Single-droplet
deployments leave it blank.
"""
from __future__ import annotations

import json
import logging
from dataclasses import dataclass
from typing import Any, Optional

import redis.asyncio as aioredis

from .metrics import redis_publish_total, redis_subscribers_seen

log = logging.getLogger("realtime_ws.publisher")

RAW_PREFIX = "deribit.raw."
APP_PREFIX = "app."


@dataclass
class Publisher:
    redis: aioredis.Redis
    pubsub_prefix: str = ""
    """Prepended to every Redis channel name. Usually empty."""

    def _topic(self, name: str) -> str:
        return f"{self.pubsub_prefix}{name}" if self.pubsub_prefix else name

    async def publish_raw(self, source_channel: str, msg: dict[str, Any]) -> int:
        """Publish a Deribit message verbatim to deribit.raw.<source_channel>."""
        topic = self._topic(f"{RAW_PREFIX}{source_channel}")
        try:
            n = int(await self.redis.publish(topic, json.dumps(msg, default=str)))
            redis_publish_total.labels(outcome="success").inc()
            redis_subscribers_seen.labels(topic=topic).set(n)
            return n
        except Exception as e:
            redis_publish_total.labels(outcome="failed").inc()
            log.warning("publish_raw failed topic=%s err=%s", topic, e)
            return 0

    async def publish_app(self, app_topic: str, payload: dict[str, Any]) -> int:
        """Publish a normalized payload to app.<topic>.

        `app_topic` is the suffix without the `app.` prefix - e.g. "market",
        "account", "positions", "alerts.mmp", "alerts.lock".
        """
        topic = self._topic(f"{APP_PREFIX}{app_topic}")
        try:
            n = int(await self.redis.publish(topic, json.dumps(payload, default=str)))
            redis_publish_total.labels(outcome="success").inc()
            redis_subscribers_seen.labels(topic=topic).set(n)
            return n
        except Exception as e:
            redis_publish_total.labels(outcome="failed").inc()
            log.warning("publish_app failed topic=%s err=%s", topic, e)
            return 0
