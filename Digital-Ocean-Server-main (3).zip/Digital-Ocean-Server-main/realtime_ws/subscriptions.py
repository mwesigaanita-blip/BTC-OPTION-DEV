"""Deribit channel registry.

Phase 2: only public channels (no auth required). Private channels land in
Phase 3 alongside auth.

V1 channel set (locked in plan §1):
  - user.portfolio.btc                    (private)
  - user.portfolio.usdt                   (private)
  - user.portfolio.usdc                   (private)
  - user.changes.future.BTC.raw           (private)
  - user.changes.option.BTC.raw           (private)
  - deribit_price_index.btc_usd           (public)
  - ticker.BTC-PERPETUAL.100ms            (public)
  - user.mmp_trigger.btc_usd              (private)
  - user.lock                             (private)
"""
from __future__ import annotations

PUBLIC_CHANNELS_DEFAULT: tuple[str, ...] = (
    "deribit_price_index.btc_usd",
)

PUBLIC_CHANNELS_ALL: tuple[str, ...] = (
    "deribit_price_index.btc_usd",
    "deribit_volatility_index.btc_usd",
    "ticker.BTC-PERPETUAL.100ms",
)

PRIVATE_CHANNELS_ALL: tuple[str, ...] = (
    "user.portfolio.btc",
    "user.portfolio.usdt",
    "user.portfolio.usdc",
    "user.changes.future.BTC.raw",
    "user.changes.option.BTC.raw",
    "user.mmp_trigger.btc_usd",
    "user.lock",
)

# The locked V1 set from plan §1.
V1_CHANNELS_ALL: tuple[str, ...] = PUBLIC_CHANNELS_ALL + PRIVATE_CHANNELS_ALL


def is_private(channel: str) -> bool:
    return channel.startswith("user.")


def resolve_channels(spec: str) -> tuple[str, ...]:
    """Translate a CLI/env channel spec into a concrete tuple.

    Accepted shorthands:
      "v1"        → V1_CHANNELS_ALL
      "public"    → PUBLIC_CHANNELS_ALL
      "private"   → PRIVATE_CHANNELS_ALL
      "default"   → PUBLIC_CHANNELS_DEFAULT
      otherwise   → comma-split with whitespace stripped
    """
    if not spec:
        return ()
    s = spec.strip().lower()
    if s == "v1":
        return V1_CHANNELS_ALL
    if s == "public":
        return PUBLIC_CHANNELS_ALL
    if s == "private":
        return PRIVATE_CHANNELS_ALL
    if s == "default":
        return PUBLIC_CHANNELS_DEFAULT
    return tuple(c.strip() for c in spec.split(",") if c.strip())
