"""Tiny aiohttp server exposing /healthz + /metrics for the WS collector.

Plan §7 Phase 8: "Prometheus metrics enabled (collector + backend_ws expose
/metrics)". The collector is a pure asyncio loop with no HTTP surface until
now - this module adds one.

Binds to BACKEND_WS_COLLECTOR_PORT (default 8101) on 0.0.0.0 inside the
container; docker-compose publishes only on 127.0.0.1.
"""
from __future__ import annotations

import asyncio
import json
import logging
from typing import Optional

from aiohttp import web
from prometheus_client import CONTENT_TYPE_LATEST, generate_latest

from .health import HEALTH
from .metrics import refresh_current_downtime, refresh_last_message_age

log = logging.getLogger("realtime_ws.http_server")


async def _healthz(_request: web.Request) -> web.Response:
    snap = HEALTH.snapshot()
    body = json.dumps({"ok": snap.get("redis_ok", False), **snap})
    return web.Response(text=body, content_type="application/json")


async def _metrics(_request: web.Request) -> web.Response:
    # Refresh on every scrape so prometheus sees current age, not the value
    # from the last background tick.
    refresh_last_message_age()
    refresh_current_downtime()
    return web.Response(body=generate_latest(), content_type=CONTENT_TYPE_LATEST.split(";")[0])


def build_app() -> web.Application:
    app = web.Application()
    app.router.add_get("/healthz", _healthz)
    app.router.add_get("/metrics", _metrics)
    return app


class HttpServer:
    """Owns the aiohttp runner so the run.py lifecycle can stop it cleanly."""

    def __init__(self, *, host: str = "0.0.0.0", port: int = 8101) -> None:
        self.host = host
        self.port = int(port)
        self._runner: Optional[web.AppRunner] = None
        self._site: Optional[web.BaseSite] = None
        self._gauge_task: Optional[asyncio.Task] = None
        self._stop = asyncio.Event()

    async def start(self) -> None:
        self._runner = web.AppRunner(build_app())
        await self._runner.setup()
        self._site = web.TCPSite(self._runner, host=self.host, port=self.port)
        await self._site.start()
        self._gauge_task = asyncio.create_task(self._gauge_loop(), name="ws-metrics-gauges")
        log.info("metrics http server listening on http://%s:%d", self.host, self.port)

    async def stop(self) -> None:
        self._stop.set()
        if self._gauge_task is not None:
            self._gauge_task.cancel()
            try:
                await self._gauge_task
            except (asyncio.CancelledError, Exception):
                pass
        if self._runner is not None:
            try:
                await self._runner.cleanup()
            except Exception:
                pass

    async def _gauge_loop(self) -> None:
        """Push the time-based gauges every few seconds so a Prometheus
        scrape that happens to land between WS messages still sees current
        values."""
        try:
            while not self._stop.is_set():
                refresh_last_message_age()
                refresh_current_downtime()
                try:
                    await asyncio.wait_for(self._stop.wait(), timeout=5.0)
                except asyncio.TimeoutError:
                    pass
        except asyncio.CancelledError:
            return
