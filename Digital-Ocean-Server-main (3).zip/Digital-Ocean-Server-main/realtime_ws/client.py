"""Deribit WebSocket client.

Phase 2 scope:
  - Open connection to Deribit (testnet or mainnet).
  - Subscribe to PUBLIC channels via `public/subscribe`.
  - Send `public/set_heartbeat` and reply to `test_request`.
  - Auto-reconnect with exponential backoff (mirrors realtime/_deribit.py:_backoff).

Phase 3 scope (added):
  - Authenticate via `public/auth` (client_credentials) before subscribing.
  - Subscribe to PRIVATE channels via `private/subscribe` with access_token.
  - Background token refresh ~15 s before expiry (refresh_token grant).
  - On 13009 / invalid_token from any RPC ack: force reconnect + reauth.
"""
from __future__ import annotations

import asyncio
import json
import logging
import time
from collections import deque
from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable, Iterable, Optional

import websockets
from websockets.exceptions import ConnectionClosed, InvalidStatusCode

from .auth import (
    Credentials,
    TokenState,
    build_auth_client_credentials,
    build_auth_refresh,
    is_invalid_token_error,
    parse_auth_result,
)
from .config import Config
from .heartbeat import (
    build_set_heartbeat,
    build_test_response,
    is_heartbeat_message,
    is_test_request,
)
from .health import HEALTH
from .metrics import (
    channel_last_message_age_seconds,
    crash_loop_active,
    observe_message,
    reconnect_window_count,
    subscriptions_active,
    watchdog_force_reconnects_total,
    ws_connection_state,
    ws_current_downtime_seconds,
    ws_downtime_seconds_total,
    ws_last_downtime_seconds,
    ws_longest_downtime_seconds,
    ws_reconnects_total,
    ws_token_refresh_total,
)

CRASH_LOOP_WINDOW_S = 600.0  # 10 min
CRASH_LOOP_THRESHOLD = 5
WATCHDOG_TICK_S = 5.0
from .reconnect import sleep_backoff
from .subscriptions import is_private

log = logging.getLogger("realtime_ws.client")

OnMessage = Callable[[str, dict], Awaitable[None]]


@dataclass
class _RpcCounter:
    next_id: int = 1

    def take(self) -> int:
        v = self.next_id
        self.next_id += 1
        return v


@dataclass
class DeribitWSClient:
    cfg: Config
    channels: tuple[str, ...]
    on_message: OnMessage
    """Caller-supplied async handler invoked on every subscription message."""

    credentials: Optional[Credentials] = None
    """Required iff any of `channels` is a private channel."""

    force_token_ttl_seconds: float = 0.0
    """DEBUG: if > 0, clamp every parsed token's expires_at to this many seconds
    from `time.time()`. Used to exercise the refresh path on long-lived API keys.
    Has no effect at 0."""

    on_connect: Optional["Callable[[], Awaitable[None]]"] = None
    """Optional async hook fired after WS auth + subscribe complete on every
    (re)connect. Used by the reconciler to push a REST snapshot before the
    next WS message arrives."""

    on_connect_failed: Optional["Callable[[], Awaitable[None]]"] = None
    """Optional async hook fired after a *failed* connection attempt. Wired to
    the reconciler so a REST snapshot still refreshes the dashboard while the
    WS cannot connect - e.g. during Deribit maintenance when the handshake is
    rejected with HTTP 503. Best-effort: REST may also be down, in which case
    the dashboard falls back to its last SQLite snapshot."""

    _rpc: _RpcCounter = field(default_factory=_RpcCounter, repr=False)
    _stop: asyncio.Event = field(default_factory=asyncio.Event, repr=False)

    # Per-connection state (reset on every (re)connect).
    _token: Optional[TokenState] = field(default=None, repr=False)
    _refresh_task: Optional[asyncio.Task] = field(default=None, repr=False)
    _ws_lock: asyncio.Lock = field(default_factory=asyncio.Lock, repr=False)
    _auth_rpc_ids: set[int] = field(default_factory=set, repr=False)
    _auth_done: Optional[asyncio.Event] = field(default=None, repr=False)

    # Phase 9: watchdog + crash-loop tracking.
    _last_msg_at_per_channel: dict[str, float] = field(default_factory=dict, repr=False)
    _connect_at: float = field(default=0.0, repr=False)
    _reconnect_history: deque = field(default_factory=lambda: deque(maxlen=64), repr=False)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def stop(self) -> None:
        self._stop.set()

    async def run_forever(self) -> None:
        public_ch = tuple(c for c in self.channels if not is_private(c))
        private_ch = tuple(c for c in self.channels if is_private(c))

        if private_ch and self.credentials is None:
            raise RuntimeError(
                f"private channels {list(private_ch)} require credentials="
                "Credentials.from_env(testnet=...)"
            )

        attempt = 0
        was_connected = False
        url = self.cfg.active_deribit_url
        log.info(
            "ws client starting: url=%s public=%s private=%s heartbeat=%.0fs",
            url,
            list(public_ch),
            list(private_ch),
            self.cfg.heartbeat_interval_s,
        )

        while not self._stop.is_set():
            self._token = None
            self._cancel_refresh_task()
            self._auth_rpc_ids.clear()
            self._auth_done = asyncio.Event()

            connected_this_round = False
            read_task: Optional[asyncio.Task] = None
            watchdog_task: Optional[asyncio.Task] = None
            try:
                async with websockets.connect(
                    url,
                    ping_interval=20,
                    ping_timeout=20,
                    close_timeout=5,
                    max_size=2**22,
                ) as ws:
                    log.info("ws connected (attempt=%d)", attempt)
                    connected_this_round = True
                    HEALTH.clear_maintenance()
                    self._connect_at = time.time()
                    self._last_msg_at_per_channel.clear()
                    if attempt > 0:
                        delta = HEALTH.mark_reconnect()
                        ws_reconnects_total.inc()
                        self._record_reconnect()
                        if delta > 0.0:
                            ws_downtime_seconds_total.inc(delta)
                            ws_last_downtime_seconds.set(delta)
                            snap = HEALTH.snapshot()
                            ws_longest_downtime_seconds.set(
                                float(snap.get("longest_downtime_s") or 0.0)
                            )
                            log.info("ws downtime resolved: %.2fs", delta)
                    ws_current_downtime_seconds.set(0.0)
                    ws_connection_state.set(1)
                    was_connected = True
                    subscriptions_active.set(len(self.channels))
                    attempt = 0  # reset backoff on successful connect

                    # Start the read loop FIRST so RPC responses (including
                    # auth ack) are consumed concurrently with our sends.
                    read_task = asyncio.create_task(
                        self._read_loop(ws), name="ws-read"
                    )

                    await self._set_heartbeat(ws)

                    if self.credentials is not None:
                        await self._authenticate(ws)
                        if self._token is not None:
                            self._refresh_task = asyncio.create_task(
                                self._refresh_loop(ws), name="auth-refresh"
                            )

                    if public_ch:
                        await self._subscribe_public(ws, public_ch)
                    if private_ch:
                        await self._subscribe_private(ws, private_ch)

                    # Reconcile snapshot AFTER subscribe so the legacy schema
                    # is hot before the first WS event lands.
                    if self.on_connect is not None:
                        try:
                            await self.on_connect()
                        except Exception as e:
                            log.warning("on_connect hook failed: %s", e)

                    watchdog_task = asyncio.create_task(
                        self._watchdog_loop(ws), name="ws-watchdog"
                    )

                    # Block on the read task - it exits when the connection
                    # closes (clean disconnect, server kick, or invalid_token).
                    await read_task
            except asyncio.CancelledError:
                raise
            except ConnectionClosed as e:
                log.warning("ws connection closed: %s", e)
            except InvalidStatusCode as e:
                # Deribit rejects the WS handshake with HTTP 503 while the
                # platform is in maintenance. Treat as a transient, expected
                # outage - flag it for the dashboard, no scary traceback.
                if e.status_code == 503:
                    HEALTH.mark_maintenance("Deribit WS handshake rejected (HTTP 503)")
                    log.warning(
                        "ws handshake rejected HTTP 503 - Deribit maintenance, "
                        "will keep retrying"
                    )
                else:
                    log.warning("ws handshake rejected: HTTP %s", e.status_code)
            except Exception as e:
                log.exception("ws loop error: %s", e)
            finally:
                ws_connection_state.set(0)
                if was_connected:
                    HEALTH.mark_disconnect()
                    was_connected = False
                self._cancel_refresh_task()
                if watchdog_task is not None and not watchdog_task.done():
                    watchdog_task.cancel()
                    try:
                        await watchdog_task
                    except (asyncio.CancelledError, Exception):
                        pass
                if read_task is not None and not read_task.done():
                    read_task.cancel()
                    try:
                        await read_task
                    except (asyncio.CancelledError, Exception):
                        pass

            if self._stop.is_set():
                break

            # WS never came up this round (handshake rejected, network down,
            # Deribit maintenance). Fire the REST fallback so the dashboard
            # still shows live numbers instead of zeros. Best-effort.
            if not connected_this_round and self.on_connect_failed is not None:
                log.info("ws offline - running REST fallback snapshot")
                try:
                    await self.on_connect_failed()
                except Exception as e:
                    log.warning("on_connect_failed hook failed: %s", e)

            delay = await sleep_backoff(
                attempt,
                base=self.cfg.reconnect_backoff_base_s,
                cap=self.cfg.reconnect_backoff_cap_s,
                jitter=self.cfg.reconnect_jitter_s,
            )
            log.info("reconnecting after %.2fs (attempt=%d)", delay, attempt + 1)
            attempt += 1

        log.info("ws client stopped")

    # ------------------------------------------------------------------
    # Auth
    # ------------------------------------------------------------------

    async def _authenticate(self, ws) -> None:
        assert self.credentials is not None
        assert self._auth_done is not None
        rpc_id = self._rpc.take()
        self._auth_rpc_ids.add(rpc_id)
        log.info("authenticating (testnet=%s)", self.credentials.testnet)
        async with self._ws_lock:
            await ws.send(build_auth_client_credentials(rpc_id, self.credentials))
        # The read loop (already running concurrently) will parse the auth
        # response, set self._token, and signal _auth_done. Block here until
        # that happens or we time out.
        try:
            await asyncio.wait_for(self._auth_done.wait(), timeout=10.0)
        except asyncio.TimeoutError:
            raise RuntimeError("auth timeout: no public/auth response within 10s")
        if self._token is not None:
            log.info(
                "authenticated, token expires_in=%.0fs",
                max(0.0, self._token.expires_at - time.time()),
            )

    async def _refresh_loop(self, ws) -> None:
        try:
            while not self._stop.is_set() and self._token is not None:
                wait_s = self._token.time_until_refresh()
                if wait_s > 0:
                    try:
                        await asyncio.wait_for(self._stop.wait(), timeout=wait_s)
                        return  # stop requested
                    except asyncio.TimeoutError:
                        pass
                if self._stop.is_set() or self._token is None:
                    return
                # Guard: if the token was refreshed by another in-flight ack
                # landing during our sleep, skip this iteration.
                if self._token.time_until_refresh() > 0.5:
                    continue

                rpc_id = self._rpc.take()
                self._auth_rpc_ids.add(rpc_id)
                if self._auth_done is not None:
                    self._auth_done.clear()
                log.info("refreshing access token")
                async with self._ws_lock:
                    await ws.send(build_auth_refresh(rpc_id, self._token.refresh_token))

                # Wait for the refresh response to be parsed by the read loop
                # before computing the next sleep. Without this we'd iterate on
                # stale token state and double-fire.
                if self._auth_done is not None:
                    try:
                        await asyncio.wait_for(self._auth_done.wait(), timeout=10.0)
                        ws_token_refresh_total.labels(outcome="success").inc()
                    except asyncio.TimeoutError:
                        ws_token_refresh_total.labels(outcome="failed").inc()
                        log.warning(
                            "refresh response timeout - forcing reconnect"
                        )
                        await ws.close(code=4002, reason="refresh_timeout")
                        return
        except asyncio.CancelledError:
            return
        except Exception as e:
            log.warning("refresh loop error: %s", e)

    def _cancel_refresh_task(self) -> None:
        t = self._refresh_task
        self._refresh_task = None
        if t is not None and not t.done():
            t.cancel()

    # ------------------------------------------------------------------
    # Subscribe
    # ------------------------------------------------------------------

    async def _set_heartbeat(self, ws) -> None:
        async with self._ws_lock:
            await ws.send(
                build_set_heartbeat(
                    self._rpc.take(), int(self.cfg.heartbeat_interval_s)
                )
            )

    async def _subscribe_public(self, ws, channels: Iterable[str]) -> None:
        async with self._ws_lock:
            await ws.send(
                json.dumps(
                    {
                        "jsonrpc": "2.0",
                        "id": self._rpc.take(),
                        "method": "public/subscribe",
                        "params": {"channels": list(channels)},
                    }
                )
            )

    async def _subscribe_private(self, ws, channels: Iterable[str]) -> None:
        if self._token is None:
            raise RuntimeError("private subscribe attempted before auth completed")
        async with self._ws_lock:
            await ws.send(
                json.dumps(
                    {
                        "jsonrpc": "2.0",
                        "id": self._rpc.take(),
                        "method": "private/subscribe",
                        "params": {
                            "channels": list(channels),
                            "access_token": self._token.access_token,
                        },
                    }
                )
            )

    # ------------------------------------------------------------------
    # Read
    # ------------------------------------------------------------------

    async def _read_loop(self, ws) -> None:
        while not self._stop.is_set():
            raw = await ws.recv()
            try:
                msg = json.loads(raw)
            except Exception:
                log.warning("non-json frame ignored: %s", str(raw)[:200])
                continue

            HEALTH.mark_message()

            if is_heartbeat_message(msg):
                if is_test_request(msg):
                    async with self._ws_lock:
                        await ws.send(build_test_response())
                    log.debug("replied to test_request")
                continue

            method = msg.get("method")
            if method == "subscription":
                params = msg.get("params") or {}
                channel = params.get("channel")
                if channel:
                    observe_message(channel)
                    self._last_msg_at_per_channel[channel] = time.time()
                    try:
                        await self.on_message(channel, msg)
                    except Exception as e:
                        log.exception("on_message handler error: %s", e)
                continue

            # RPC response (subscribe ack, set_heartbeat ack, public/auth, etc.)
            if "id" in msg and ("result" in msg or "error" in msg):
                rpc_id = msg.get("id")
                err = msg.get("error")

                if err:
                    if is_invalid_token_error(err):
                        log.warning("invalid_token error - forcing reconnect: %s", err)
                        self._token = None
                        await ws.close(code=4000, reason="invalid_token")
                        return
                    log.warning("rpc error id=%s err=%s", rpc_id, err)
                    continue

                # Auth responses → harvest token state.
                if rpc_id in self._auth_rpc_ids:
                    self._auth_rpc_ids.discard(rpc_id)
                    try:
                        self._token = parse_auth_result(msg.get("result") or {})
                    except Exception as e:
                        log.error("auth parse failed: %s", e)
                        if self._auth_done is not None:
                            self._auth_done.set()
                        await ws.close(code=4001, reason="auth_parse_failed")
                        return
                    if self.force_token_ttl_seconds > 0:
                        self._token.expires_at = time.time() + float(
                            self.force_token_ttl_seconds
                        )
                        log.warning(
                            "DEBUG: token expires_at clamped to %.0fs from now "
                            "(--force-token-ttl-seconds)",
                            self.force_token_ttl_seconds,
                        )
                    log.info(
                        "auth ack id=%s token_ttl=%.0fs",
                        rpc_id,
                        max(0.0, self._token.expires_at - time.time()),
                    )
                    if self._auth_done is not None:
                        self._auth_done.set()
                    continue

                log.info("rpc ack id=%s result=%s", rpc_id, _short(msg.get("result")))
                continue

            log.debug("unhandled frame: %s", _short(msg))

    # ------------------------------------------------------------------
    # Phase 9: watchdog + crash-loop
    # ------------------------------------------------------------------

    def _record_reconnect(self) -> None:
        """Append now to the rolling window, prune old, refresh gauges."""
        now = time.time()
        self._reconnect_history.append(now)
        cutoff = now - CRASH_LOOP_WINDOW_S
        while self._reconnect_history and self._reconnect_history[0] < cutoff:
            self._reconnect_history.popleft()
        n = len(self._reconnect_history)
        reconnect_window_count.set(n)
        crash_loop_active.set(1 if n >= CRASH_LOOP_THRESHOLD else 0)
        if n >= CRASH_LOOP_THRESHOLD:
            log.warning(
                "crash-loop detected: %d reconnects in trailing %.0fs window",
                n, CRASH_LOOP_WINDOW_S,
            )

    async def _watchdog_loop(self, ws) -> None:
        """Force a reconnect when the connection has been *globally* silent
        past cfg.staleness_threshold_s. Also pushes per-channel age gauges
        for the Streamlit panel.

        IMPORTANT: we measure the **newest** last-message timestamp across
        all subscribed channels, not per-channel. Several subscribed channels
        (`user.changes.*`, `user.mmp_trigger.*`, `user.lock`) are event-only
        and stay silent for hours on a quiet account - that is normal and
        must not trip the watchdog. As long as *any* channel produced a
        message in the window, the WS connection is alive.

        Grace window: don't trip until cfg.staleness_threshold_s has elapsed
        since the latest connect.
        """
        threshold = float(self.cfg.staleness_threshold_s)
        try:
            while not self._stop.is_set():
                try:
                    await asyncio.wait_for(self._stop.wait(), timeout=WATCHDOG_TICK_S)
                    return
                except asyncio.TimeoutError:
                    pass

                now = time.time()
                # Push per-channel age gauges every tick (display only).
                for ch in self.channels:
                    last = self._last_msg_at_per_channel.get(ch)
                    age = (now - last) if last else 0.0
                    channel_last_message_age_seconds.labels(channel=ch).set(age)

                if (now - self._connect_at) < threshold:
                    continue  # grace window

                # Global staleness = age of the newest message we've seen on
                # any channel. If even one channel is active, the link is up.
                newest = max(self._last_msg_at_per_channel.values(), default=0.0)
                global_age = (now - newest) if newest else (now - self._connect_at)

                if global_age > threshold:
                    log.warning(
                        "watchdog: forcing reconnect - no message on any "
                        "channel for %.1fs (threshold=%.1fs)",
                        global_age, threshold,
                    )
                    watchdog_force_reconnects_total.inc()
                    try:
                        await ws.close(code=4003, reason="watchdog_stale")
                    except Exception:
                        pass
                    return
        except asyncio.CancelledError:
            return
        except Exception as e:
            log.warning("watchdog loop error: %s", e)


def _short(obj, n: int = 200) -> str:
    s = json.dumps(obj, default=str) if not isinstance(obj, str) else obj
    return s if len(s) <= n else s[:n] + "…"
