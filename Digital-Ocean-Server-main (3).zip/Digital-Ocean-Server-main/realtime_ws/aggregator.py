"""60-second aggregator - roll raw ticks into hedge-engine metrics.

# Copied from realtime/aggregator.py on 2026-05-10.
# Per plan §5: must not import from realtime/. Adapted to async (60s timer
# task spawned by realtime_ws.run.py) and sources REALTIME_DB / HEDGE_ENGINE_DB
# from realtime_ws.db_paths instead of shared/.

Reads from `realtime.sqlite` (account_ticks + positions_ticks + market_ticks),
extracts the latest tick in a 60s window, computes greeks/margin/ROC, and
writes one row to `hedge_engine.sqlite.hedge_engine_aggregated_metrics`.

Output schema (table created on first run):
    ts_utc      TEXT PRIMARY KEY  -- end of window, ISO UTC
    delta       REAL              -- portfolio delta (BTC)
    gamma       REAL
    vega        REAL
    mm_pct      REAL              -- maintenance_margin / margin_balance * 100
    btc_price   REAL              -- last index price in window
    btc_roc     REAL              -- (last - first) / first
    sample_n    INTEGER           -- count of market_ticks in window
    created_at  TEXT
"""
from __future__ import annotations

import asyncio
import json
import logging
import sqlite3
import time
from datetime import datetime, timedelta, timezone
from typing import Any, Optional

from .db_paths import HEDGE_ENGINE_DB, REALTIME_DB
from .metrics import aggregator_writes_total

log = logging.getLogger("realtime_ws.aggregator")

LOOKBACK_S = 60
AGG_INTERVAL_S = 60.0
TABLE_NAME = "hedge_engine_aggregated_metrics"

_SCHEMA_SQL = f"""
CREATE TABLE IF NOT EXISTS {TABLE_NAME} (
    ts_utc     TEXT PRIMARY KEY,
    delta      REAL,
    gamma      REAL,
    vega       REAL,
    mm_pct     REAL,
    btc_price  REAL,
    btc_roc    REAL,
    sample_n   INTEGER,
    created_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_{TABLE_NAME}_ts ON {TABLE_NAME}(ts_utc);
"""


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _sf(v: Any, default: float = 0.0) -> float:
    try:
        if v is None:
            return default
        return float(v)
    except Exception:
        return default


def _utc_now_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f") + "Z"


def _window_start_iso(seconds: int = LOOKBACK_S) -> str:
    start = datetime.now(timezone.utc) - timedelta(seconds=seconds)
    return start.strftime("%Y-%m-%dT%H:%M:%S.%f") + "Z"


def _ensure_hedge_engine_table() -> None:
    HEDGE_ENGINE_DB.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(HEDGE_ENGINE_DB), timeout=10.0)
    try:
        conn.executescript(_SCHEMA_SQL)
        conn.commit()
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Greek / margin extraction (verbatim formulas from origin)
# ---------------------------------------------------------------------------


def _extract_greeks_and_margin(account_payload: dict, positions_payload: list) -> dict:
    """Account-first, positions-fallback: same formulas as realtime/aggregator.py."""
    acct = account_payload or {}
    positions = positions_payload or []

    # delta: account-level → options+futures sum → positions sum (final fallback)
    delta = _sf(acct.get("delta_total"))
    if delta == 0.0:
        od = _sf(acct.get("options_delta"))
        fd = _sf(acct.get("futures_delta"))
        if od or fd:
            delta = od + fd
        else:
            delta = sum(_sf(p.get("net_delta", p.get("delta"))) for p in positions)

    gamma = _sf(acct.get("options_gamma")) or sum(_sf(p.get("gamma")) for p in positions)
    vega = _sf(acct.get("options_vega")) or sum(_sf(p.get("vega")) for p in positions)

    # margin %: USD-aggregate first, BTC-denominated fallback
    mb = _sf(acct.get("total_margin_balance_usd")) or _sf(acct.get("margin_balance"))
    mm = _sf(acct.get("total_maintenance_margin_usd")) or _sf(acct.get("maintenance_margin"))
    mm_pct = (mm / mb * 100.0) if mb > 0 else 0.0

    return {"delta": delta, "gamma": gamma, "vega": vega, "mm_pct": mm_pct}


# ---------------------------------------------------------------------------
# Window readers
# ---------------------------------------------------------------------------


def _fetch_window(conn: sqlite3.Connection, since_iso: str) -> dict:
    out: dict[str, Any] = {
        "account": None,
        "positions": None,
        "ts_account": None,
        "ts_positions": None,
        "ts_market_last": None,
        "btc_first": None,
        "btc_last": None,
        "sample_n": 0,
    }

    row = conn.execute(
        "SELECT ts_utc, payload_json FROM account_ticks "
        "WHERE ts_utc >= ? ORDER BY ts_utc DESC LIMIT 1;",
        (since_iso,),
    ).fetchone()
    if row:
        try:
            out["account"] = json.loads(row["payload_json"])
            out["ts_account"] = row["ts_utc"]
        except Exception as e:
            log.warning("bad account_ticks payload: %s", e)

    row = conn.execute(
        "SELECT ts_utc, payload_json FROM positions_ticks "
        "WHERE ts_utc >= ? ORDER BY ts_utc DESC LIMIT 1;",
        (since_iso,),
    ).fetchone()
    if row:
        try:
            out["positions"] = json.loads(row["payload_json"])
            out["ts_positions"] = row["ts_utc"]
        except Exception as e:
            log.warning("bad positions_ticks payload: %s", e)

    rows = conn.execute(
        "SELECT ts_utc, btc_price FROM market_ticks "
        "WHERE ts_utc >= ? ORDER BY ts_utc ASC;",
        (since_iso,),
    ).fetchall()
    if rows:
        out["btc_first"] = float(rows[0]["btc_price"])
        out["btc_last"] = float(rows[-1]["btc_price"])
        out["ts_market_last"] = rows[-1]["ts_utc"]
        out["sample_n"] = len(rows)

    return out


# ---------------------------------------------------------------------------
# Aggregation step (sync - runs in a thread executor to keep the event loop snappy)
# ---------------------------------------------------------------------------


def run_once() -> Optional[dict]:
    _ensure_hedge_engine_table()

    t0 = time.perf_counter()
    since = _window_start_iso(LOOKBACK_S)
    rt_conn = sqlite3.connect(str(REALTIME_DB), timeout=5.0)
    rt_conn.row_factory = sqlite3.Row
    try:
        win = _fetch_window(rt_conn, since)
    finally:
        rt_conn.close()

    if not any([win["account"], win["positions"], win["btc_last"]]):
        log.warning("no ticks in window since=%s - skipping aggregation", since)
        return None

    metrics = _extract_greeks_and_margin(win["account"] or {}, win["positions"] or [])

    btc_price = _sf(win["btc_last"])
    btc_first = _sf(win["btc_first"])
    btc_roc = ((btc_price - btc_first) / btc_first) if btc_first > 0 else 0.0

    ts_utc = (
        win["ts_market_last"]
        or win["ts_account"]
        or win["ts_positions"]
        or _utc_now_iso()
    )
    created_at = _utc_now_iso()

    row = {
        "ts_utc": ts_utc,
        "delta": metrics["delta"],
        "gamma": metrics["gamma"],
        "vega": metrics["vega"],
        "mm_pct": metrics["mm_pct"],
        "btc_price": btc_price,
        "btc_roc": btc_roc,
        "sample_n": int(win["sample_n"]),
        "created_at": created_at,
    }

    he_conn = sqlite3.connect(str(HEDGE_ENGINE_DB), timeout=10.0)
    try:
        he_conn.execute(
            f"INSERT OR REPLACE INTO {TABLE_NAME} "
            "(ts_utc, delta, gamma, vega, mm_pct, btc_price, btc_roc, sample_n, created_at) "
            "VALUES (:ts_utc, :delta, :gamma, :vega, :mm_pct, :btc_price, :btc_roc, :sample_n, :created_at);",
            row,
        )
        he_conn.commit()
        aggregator_writes_total.inc()
    finally:
        he_conn.close()

    elapsed_ms = (time.perf_counter() - t0) * 1000.0
    log.info(
        "aggregated ts=%s delta=%.4f gamma=%.6f vega=%.4f mm%%=%.2f btc=%.2f roc=%+.4f%% n=%d ms=%.1f",
        ts_utc,
        row["delta"],
        row["gamma"],
        row["vega"],
        row["mm_pct"],
        row["btc_price"],
        row["btc_roc"] * 100,
        row["sample_n"],
        elapsed_ms,
    )
    return row


# ---------------------------------------------------------------------------
# Async loop - used by run.py as a background task
# ---------------------------------------------------------------------------


class Aggregator:
    def __init__(self, *, interval_s: float = AGG_INTERVAL_S) -> None:
        self.interval_s = float(interval_s)
        self._task: Optional[asyncio.Task] = None
        self._stop = asyncio.Event()
        self._runs_total = 0
        self._runs_failed = 0

    def start(self) -> asyncio.Task:
        if self._task is not None:
            return self._task
        log.info("aggregator starting interval=%.1fs lookback=%ds", self.interval_s, LOOKBACK_S)
        self._task = asyncio.create_task(self._loop(), name="aggregator")
        return self._task

    def stop(self) -> None:
        self._stop.set()

    async def aclose(self) -> None:
        self.stop()
        if self._task is not None:
            try:
                await self._task
            except (asyncio.CancelledError, Exception):
                pass

    async def _loop(self) -> None:
        # Initial 5 s grace so the mirror has at least one flushed window.
        try:
            await asyncio.wait_for(self._stop.wait(), timeout=min(5.0, self.interval_s))
            return
        except asyncio.TimeoutError:
            pass
        try:
            while not self._stop.is_set():
                cycle_start = time.perf_counter()
                try:
                    await asyncio.get_running_loop().run_in_executor(None, run_once)
                    self._runs_total += 1
                except Exception as e:
                    self._runs_failed += 1
                    log.exception("aggregator failed: %s", e)
                elapsed = time.perf_counter() - cycle_start
                sleep_for = max(0.0, self.interval_s - elapsed)
                try:
                    await asyncio.wait_for(self._stop.wait(), timeout=sleep_for)
                    return
                except asyncio.TimeoutError:
                    pass
        except asyncio.CancelledError:
            return

    def stats(self) -> dict:
        return {"runs_total": self._runs_total, "runs_failed": self._runs_failed}
