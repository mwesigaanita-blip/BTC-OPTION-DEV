"""Phase 6c aggregator tests.

Math verified against the realtime/aggregator.py origin (verbatim formulas).
End-to-end DB write validated against a tmp realtime.sqlite + tmp hedge_engine.sqlite.
"""
from __future__ import annotations

import json
import sqlite3
from datetime import datetime, timedelta, timezone

import pytest


def _iso(dt) -> str:
    return dt.strftime("%Y-%m-%dT%H:%M:%S.%f") + "Z"


def test_extract_greeks_account_first() -> None:
    from realtime_ws.aggregator import _extract_greeks_and_margin

    acct = {
        "delta_total": 0.5,
        "options_gamma": 0.001,
        "options_vega": 0.3,
        "total_margin_balance_usd": 1000.0,
        "total_maintenance_margin_usd": 100.0,
    }
    out = _extract_greeks_and_margin(acct, [])
    assert out["delta"] == 0.5
    assert out["gamma"] == 0.001
    assert out["vega"] == 0.3
    assert out["mm_pct"] == pytest.approx(10.0)


def test_extract_greeks_options_plus_futures_fallback() -> None:
    from realtime_ws.aggregator import _extract_greeks_and_margin

    acct = {"options_delta": 0.4, "futures_delta": 0.1}
    out = _extract_greeks_and_margin(acct, [])
    assert out["delta"] == pytest.approx(0.5)


def test_extract_greeks_positions_fallback() -> None:
    from realtime_ws.aggregator import _extract_greeks_and_margin

    positions = [
        {"net_delta": 0.3},
        {"delta": 0.2},
        {"net_delta": -0.1},
    ]
    out = _extract_greeks_and_margin({}, positions)
    assert out["delta"] == pytest.approx(0.4)


def test_mm_pct_btc_fallback() -> None:
    from realtime_ws.aggregator import _extract_greeks_and_margin

    acct = {"margin_balance": 2.0, "maintenance_margin": 0.5}
    out = _extract_greeks_and_margin(acct, [])
    assert out["mm_pct"] == pytest.approx(25.0)


def test_mm_pct_handles_zero_balance() -> None:
    from realtime_ws.aggregator import _extract_greeks_and_margin

    out = _extract_greeks_and_margin({}, [])
    assert out["mm_pct"] == 0.0


def test_run_once_writes_aggregated_row(tmp_path, monkeypatch) -> None:
    """End-to-end: pre-populate realtime.sqlite, run aggregator, inspect hedge_engine.sqlite."""
    rt_db = tmp_path / "realtime.sqlite"
    he_db = tmp_path / "hedge_engine.sqlite"

    # Point both DB constants at tmp paths in the aggregator module.
    import realtime_ws.aggregator as agg_mod

    monkeypatch.setattr(agg_mod, "REALTIME_DB", rt_db)
    monkeypatch.setattr(agg_mod, "HEDGE_ENGINE_DB", he_db)

    # Build a synthetic 60s window: account + 5 market ticks (price 80000 → 80400)
    now = datetime.now(timezone.utc)
    ticks = [
        (_iso(now - timedelta(seconds=50)), 80000.0),
        (_iso(now - timedelta(seconds=40)), 80100.0),
        (_iso(now - timedelta(seconds=30)), 80200.0),
        (_iso(now - timedelta(seconds=20)), 80300.0),
        (_iso(now - timedelta(seconds=10)), 80400.0),
    ]
    account_payload = {
        "currency": "BTC",
        "delta_total": 0.5,
        "options_gamma": 0.001,
        "options_vega": 0.3,
        "margin_balance": 2.0,
        "maintenance_margin": 0.5,
    }
    account_ts = _iso(now - timedelta(seconds=5))

    # Hand-roll the schema (mirrors sqlite_mirror.py)
    rt_conn = sqlite3.connect(str(rt_db))
    rt_conn.executescript(
        """
        CREATE TABLE account_ticks   (ts_utc TEXT PRIMARY KEY, payload_json TEXT NOT NULL);
        CREATE TABLE positions_ticks (ts_utc TEXT PRIMARY KEY, payload_json TEXT NOT NULL);
        CREATE TABLE market_ticks    (ts_utc TEXT PRIMARY KEY, btc_price REAL NOT NULL);
        """
    )
    rt_conn.execute(
        "INSERT INTO account_ticks VALUES (?, ?);",
        (account_ts, json.dumps(account_payload)),
    )
    for ts, price in ticks:
        rt_conn.execute("INSERT INTO market_ticks VALUES (?, ?);", (ts, price))
    rt_conn.commit()
    rt_conn.close()

    row = agg_mod.run_once()
    assert row is not None
    assert row["delta"] == pytest.approx(0.5)
    assert row["gamma"] == pytest.approx(0.001)
    assert row["vega"] == pytest.approx(0.3)
    assert row["mm_pct"] == pytest.approx(25.0)
    assert row["btc_price"] == pytest.approx(80400.0)
    assert row["btc_roc"] == pytest.approx((80400 - 80000) / 80000)
    assert row["sample_n"] == 5

    # Verify the row landed in hedge_engine.sqlite.
    he_conn = sqlite3.connect(str(he_db))
    try:
        rows = he_conn.execute(
            f"SELECT delta, btc_price, sample_n FROM {agg_mod.TABLE_NAME};"
        ).fetchall()
        assert len(rows) == 1
        assert rows[0][0] == pytest.approx(0.5)
        assert rows[0][1] == pytest.approx(80400.0)
        assert rows[0][2] == 5
    finally:
        he_conn.close()


def test_run_once_returns_none_when_window_empty(tmp_path, monkeypatch) -> None:
    rt_db = tmp_path / "realtime.sqlite"
    he_db = tmp_path / "hedge_engine.sqlite"

    import realtime_ws.aggregator as agg_mod

    monkeypatch.setattr(agg_mod, "REALTIME_DB", rt_db)
    monkeypatch.setattr(agg_mod, "HEDGE_ENGINE_DB", he_db)

    rt_conn = sqlite3.connect(str(rt_db))
    rt_conn.executescript(
        """
        CREATE TABLE account_ticks   (ts_utc TEXT PRIMARY KEY, payload_json TEXT NOT NULL);
        CREATE TABLE positions_ticks (ts_utc TEXT PRIMARY KEY, payload_json TEXT NOT NULL);
        CREATE TABLE market_ticks    (ts_utc TEXT PRIMARY KEY, btc_price REAL NOT NULL);
        """
    )
    rt_conn.commit()
    rt_conn.close()

    assert agg_mod.run_once() is None
