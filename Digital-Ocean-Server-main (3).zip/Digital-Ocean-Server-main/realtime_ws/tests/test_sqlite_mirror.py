"""Phase 6b SQLite mirror tests.

Uses an in-memory mirror state to verify cache updates and the snapshot
shape without touching the real DB. The DB write path is exercised via a
short integration that points REALTIME_DB at a tmp file.
"""
from __future__ import annotations

import os
import sqlite3
from pathlib import Path

import pytest


def test_state_cache_updates_account(tmp_path) -> None:
    from realtime_ws.sqlite_mirror import MirrorState

    s = MirrorState()
    s.update_account({"equity": 1.5, "currency": "BTC"})
    a, idx, pos = s.snapshot()
    assert a == {"equity": 1.5, "currency": "BTC"}
    assert idx is None
    assert pos == []


def test_state_cache_updates_btc_index() -> None:
    from realtime_ws.sqlite_mirror import MirrorState

    s = MirrorState()
    s.update_btc_index(80000.5)
    _, idx, _ = s.snapshot()
    assert idx == 80000.5


def test_state_cache_merges_positions_by_instrument() -> None:
    from realtime_ws.sqlite_mirror import MirrorState

    s = MirrorState()
    s.update_positions(
        [{"instrument_name": "BTC-PERPETUAL", "size": 5}]
    )
    s.update_positions(
        [{"instrument_name": "BTC-PERPETUAL", "size": -3}]  # later update wins
    )
    s.update_positions(
        [{"instrument_name": "BTC-30MAY26-90000-C", "size": 10}]
    )
    _, _, pos = s.snapshot()
    by_inst = {p["instrument_name"]: p for p in pos}
    assert by_inst["BTC-PERPETUAL"]["size"] == -3
    assert by_inst["BTC-30MAY26-90000-C"]["size"] == 10
    assert len(by_inst) == 2


def test_state_cache_ignores_positions_without_instrument() -> None:
    from realtime_ws.sqlite_mirror import MirrorState

    s = MirrorState()
    s.update_positions([{"size": 5}])  # no instrument_name → skipped
    _, _, pos = s.snapshot()
    assert pos == []


def _ws_msg(channel: str, data) -> dict:
    return {
        "method": "subscription",
        "params": {"channel": channel, "data": data},
    }


def test_on_message_routes_raw_payloads() -> None:
    """`SqliteMirror.on_message` receives the RAW Deribit message and
    dispatches the right slice into the cache. The mirror stores raw because
    the aggregator reads `delta_total` / `options_gamma` from raw shape."""
    from realtime_ws.sqlite_mirror import SqliteMirror

    m = SqliteMirror(flush_interval_s=999.0)
    # account - raw Deribit fields (delta_total, options_gamma)
    m.on_message(
        "user.portfolio.btc",
        _ws_msg(
            "user.portfolio.btc",
            {
                "currency": "BTC",
                "equity": 1.5,
                "delta_total": 0.5,
                "options_gamma": 0.001,
            },
        ),
    )
    # market (index)
    m.on_message(
        "deribit_price_index.btc_usd",
        _ws_msg("deribit_price_index.btc_usd", {"price": 80000.0, "timestamp": 1}),
    )
    # market (perp ticker - must NOT overwrite the index)
    m.on_message(
        "ticker.BTC-PERPETUAL.100ms",
        _ws_msg(
            "ticker.BTC-PERPETUAL.100ms",
            {"mark_price": 80050.0, "index_price": 79999.0, "timestamp": 2},
        ),
    )
    # positions
    m.on_message(
        "user.changes.future.BTC.raw",
        _ws_msg(
            "user.changes.future.BTC.raw",
            {
                "instrument_name": "BTC-PERPETUAL",
                "positions": [{"instrument_name": "BTC-PERPETUAL", "size": 1}],
            },
        ),
    )
    a, idx, pos = m.state.snapshot()
    assert a is not None
    assert a["delta_total"] == 0.5  # raw field preserved
    assert a["options_gamma"] == 0.001
    assert idx == 80000.0  # not 79999 - perp didn't clobber
    assert len(pos) == 1


def test_on_message_ignores_unknown_channel() -> None:
    from realtime_ws.sqlite_mirror import SqliteMirror

    m = SqliteMirror(flush_interval_s=999.0)
    m.on_message(
        "trades.BTC-PERPETUAL.raw", _ws_msg("trades.BTC-PERPETUAL.raw", {"foo": 1})
    )
    a, idx, pos = m.state.snapshot()
    assert a is None and idx is None and pos == []


def test_on_message_handles_missing_data() -> None:
    from realtime_ws.sqlite_mirror import SqliteMirror

    m = SqliteMirror(flush_interval_s=999.0)
    m.on_message("user.portfolio.btc", {"params": {}})  # no data field
    m.on_message("user.portfolio.btc", {})  # no params at all
    a, _, _ = m.state.snapshot()
    assert a is None


def test_flush_writes_three_tables_with_shared_ts(tmp_path, monkeypatch) -> None:
    """End-to-end DB write - pin REALTIME_DB at a tmp file."""
    db_file = tmp_path / "realtime.sqlite"

    # Reset the module-level singleton state and redirect REALTIME_DB.
    import realtime_ws.sqlite_mirror as mod

    monkeypatch.setattr(mod, "REALTIME_DB", db_file)
    monkeypatch.setattr(mod, "_initialized", False)
    monkeypatch.setattr(mod, "_tls", __import__("threading").local())

    m = mod.SqliteMirror(flush_interval_s=999.0)
    m.state.update_account({"equity": 1.5, "currency": "BTC"})
    m.state.update_btc_index(80000.0)
    m.state.update_positions(
        [{"instrument_name": "BTC-PERPETUAL", "size": 1, "delta": 1.0}]
    )

    # Run the synchronous flush directly (no event loop needed).
    m._flush_sync()

    conn = sqlite3.connect(str(db_file))
    try:
        ts_a = conn.execute("SELECT ts_utc FROM account_ticks").fetchone()
        ts_p = conn.execute("SELECT ts_utc FROM positions_ticks").fetchone()
        ts_m = conn.execute("SELECT ts_utc, btc_price FROM market_ticks").fetchone()
        assert ts_a is not None
        assert ts_p is not None
        assert ts_m is not None
        # All three rows share the same ts_utc (single flush call).
        assert ts_a[0] == ts_p[0] == ts_m[0]
        assert ts_m[1] == pytest.approx(80000.0)

        # Idempotent: re-flushing the same state writes one new row each
        # because ts_utc differs by microseconds.
        m._flush_sync()
        assert conn.execute("SELECT COUNT(*) FROM account_ticks").fetchone()[0] == 2
    finally:
        conn.close()


def test_flush_skips_when_state_empty(tmp_path, monkeypatch) -> None:
    """Production path calls init_realtime_db() in start() before flushes;
    when nothing is cached the flush is a no-op."""
    db_file = tmp_path / "realtime.sqlite"
    import realtime_ws.sqlite_mirror as mod

    monkeypatch.setattr(mod, "REALTIME_DB", db_file)
    monkeypatch.setattr(mod, "_initialized", False)
    monkeypatch.setattr(mod, "_tls", __import__("threading").local())

    mod.init_realtime_db()  # mirrors what SqliteMirror.start() does

    m = mod.SqliteMirror(flush_interval_s=999.0)
    m._flush_sync()  # nothing cached → nothing written

    conn = sqlite3.connect(str(db_file))
    try:
        assert conn.execute("SELECT COUNT(*) FROM account_ticks").fetchone()[0] == 0
        assert conn.execute("SELECT COUNT(*) FROM positions_ticks").fetchone()[0] == 0
        assert conn.execute("SELECT COUNT(*) FROM market_ticks").fetchone()[0] == 0
    finally:
        conn.close()
