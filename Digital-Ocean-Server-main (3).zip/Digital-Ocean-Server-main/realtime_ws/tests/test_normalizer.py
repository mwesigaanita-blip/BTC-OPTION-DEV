"""Phase 4 normalizer tests.

Plan §7 Phase 4 exit criterion: "Normalizer unit tests cover happy path + 2
malformed-payload cases."
"""
from __future__ import annotations

from realtime_ws.normalizer import (
    SCHEMA_VERSION,
    normalize,
    normalize_index_price,
    normalize_user_portfolio,
)


# ---------------------------------------------------------------------------
# deribit_price_index.btc_usd → app.market
# ---------------------------------------------------------------------------

def test_index_price_happy_path() -> None:
    msg = {
        "method": "subscription",
        "params": {
            "channel": "deribit_price_index.btc_usd",
            "data": {
                "timestamp": 1778416966741,
                "price": 80911.0,
                "index_name": "btc_usd",
            },
        },
    }
    out = normalize("deribit_price_index.btc_usd", msg)
    assert out is not None
    topic, payload = out
    assert topic == "market"
    assert payload["schema_v"] == SCHEMA_VERSION
    assert payload["source_channel"] == "deribit_price_index.btc_usd"
    assert payload["data"]["btc_index"] == 80911.0
    assert payload["data"]["btc_index_ts_ms"] == 1778416966741
    assert payload["data"]["index_name"] == "btc_usd"
    assert "fetched_at" in payload and payload["fetched_at"].endswith("Z")


def test_index_price_missing_price_returns_none() -> None:
    """Malformed case 1: missing required `price` field."""
    msg = {
        "method": "subscription",
        "params": {
            "channel": "deribit_price_index.btc_usd",
            "data": {"timestamp": 1778416966741, "index_name": "btc_usd"},
        },
    }
    assert normalize("deribit_price_index.btc_usd", msg) is None


def test_index_price_data_not_dict_returns_none() -> None:
    """Malformed case 2: params.data is not a dict."""
    msg = {
        "method": "subscription",
        "params": {
            "channel": "deribit_price_index.btc_usd",
            "data": "oops, a string",
        },
    }
    assert normalize("deribit_price_index.btc_usd", msg) is None


def test_index_price_garbage_numeric_coerces_to_none() -> None:
    """Malformed case 3 (extra): non-numeric `price` string."""
    msg = {
        "method": "subscription",
        "params": {
            "channel": "deribit_price_index.btc_usd",
            "data": {"timestamp": 1778416966741, "price": "not-a-number"},
        },
    }
    assert normalize("deribit_price_index.btc_usd", msg) is None


# ---------------------------------------------------------------------------
# user.portfolio.btc → app.account  (DRAFT - verify against testnet)
# ---------------------------------------------------------------------------

def test_user_portfolio_happy_path() -> None:
    msg = {
        "method": "subscription",
        "params": {
            "channel": "user.portfolio.btc",
            "data": {
                "currency": "BTC",
                "equity": 1.234,
                "balance": 1.0,
                "available_funds": 0.95,
                "margin_balance": 1.234,
                "maintenance_margin": 0.05,
                "initial_margin": 0.10,
                "total_pl": 0.012,
                "session_upl": 0.001,
                "session_rpl": 0.002,
                "delta_total": 0.5,
                "options_gamma": 0.001,
                "options_theta": -0.02,
                "options_vega": 0.3,
            },
        },
    }
    out = normalize("user.portfolio.btc", msg)
    assert out is not None
    topic, payload = out
    assert topic == "account"
    assert payload["schema_v"] == SCHEMA_VERSION
    d = payload["data"]
    assert d["currency"] == "BTC"
    assert d["equity"] == 1.234
    assert d["greeks_total"] == {
        "delta": 0.5,
        "gamma": 0.001,
        "theta": -0.02,
        "vega": 0.3,
    }


def test_user_portfolio_missing_equity_returns_none() -> None:
    msg = {
        "method": "subscription",
        "params": {
            "channel": "user.portfolio.btc",
            "data": {"currency": "BTC", "balance": 1.0},
        },
    }
    assert normalize("user.portfolio.btc", msg) is None


# ---------------------------------------------------------------------------
# ticker.BTC-PERPETUAL.100ms → app.market (perp slice)
# ---------------------------------------------------------------------------

def test_perp_ticker_happy_path() -> None:
    msg = {
        "params": {
            "channel": "ticker.BTC-PERPETUAL.100ms",
            "data": {
                "type": "snapshot",
                "instrument_name": "BTC-PERPETUAL",
                "timestamp": 1778419800000,
                "state": "open",
                "mark_price": 80950.5,
                "index_price": 80949.7,
                "last_price": 80951.0,
                "best_bid_price": 80950.0,
                "best_ask_price": 80951.0,
                "best_bid_amount": 5000.0,
                "best_ask_amount": 4000.0,
                "open_interest": 12345.0,
                "funding_8h": 0.0001,
                "current_funding": 0.00005,
                "mark_iv": 0.62,
            },
        }
    }
    out = normalize("ticker.BTC-PERPETUAL.100ms", msg)
    assert out is not None
    topic, payload = out
    assert topic == "market"
    d = payload["data"]
    assert d["perp_mark"] == 80950.5
    assert d["perp_funding_8h"] == 0.0001
    assert d["perp_iv"] == 0.62
    assert d["perp_state"] == "open"
    assert d["perp_instrument"] == "BTC-PERPETUAL"


def test_perp_ticker_missing_mark_returns_none() -> None:
    msg = {"params": {"channel": "ticker.BTC-PERPETUAL.100ms", "data": {"state": "open"}}}
    assert normalize("ticker.BTC-PERPETUAL.100ms", msg) is None


# ---------------------------------------------------------------------------
# user.changes.* → app.positions
# ---------------------------------------------------------------------------

def test_user_changes_option_happy_path() -> None:
    msg = {
        "params": {
            "channel": "user.changes.option.BTC.raw",
            "data": {
                "instrument_name": "BTC-30MAY26-90000-C",
                "trades": [{"trade_id": "abc", "price": 0.05}],
                "positions": [{"size": 10, "delta": 0.4}],
                "orders": [],
            },
        }
    }
    out = normalize("user.changes.option.BTC.raw", msg)
    assert out is not None
    topic, payload = out
    assert topic == "positions"
    d = payload["data"]
    assert d["instrument_name"] == "BTC-30MAY26-90000-C"
    assert d["kind"] == "option"
    assert len(d["trades"]) == 1
    assert len(d["positions"]) == 1


def test_user_changes_future_happy_path() -> None:
    msg = {
        "params": {
            "channel": "user.changes.future.BTC.raw",
            "data": {
                "instrument_name": "BTC-PERPETUAL",
                "trades": [],
                "positions": [{"size": -5, "delta": -1.0}],
                "orders": [],
            },
        }
    }
    out = normalize("user.changes.future.BTC.raw", msg)
    assert out is not None
    _, payload = out
    assert payload["data"]["kind"] == "future"


def test_user_changes_missing_instrument_returns_none() -> None:
    msg = {
        "params": {
            "channel": "user.changes.option.BTC.raw",
            "data": {"trades": [], "positions": [], "orders": []},
        }
    }
    assert normalize("user.changes.option.BTC.raw", msg) is None


# ---------------------------------------------------------------------------
# user.mmp_trigger / user.lock
# ---------------------------------------------------------------------------

def test_mmp_trigger_happy_path() -> None:
    msg = {
        "params": {
            "channel": "user.mmp_trigger.btc_usd",
            "data": {
                "index_name": "btc_usd",
                "frozen_until": 1778419800000,
                "mmp_group": "default",
                "block_rfq": False,
            },
        }
    }
    out = normalize("user.mmp_trigger.btc_usd", msg)
    assert out is not None
    topic, payload = out
    assert topic == "alerts.mmp"
    assert payload["data"]["frozen_until_ms"] == 1778419800000
    assert payload["data"]["block_rfq"] is False


def test_user_lock_happy_path() -> None:
    msg = {
        "params": {
            "channel": "user.lock",
            "data": {"currency": "BTC", "locked": True},
        }
    }
    out = normalize("user.lock", msg)
    assert out is not None
    topic, payload = out
    assert topic == "alerts.lock"
    assert payload["data"]["locked"] is True
    assert payload["data"]["currency"] == "BTC"


def test_user_lock_missing_locked_returns_none() -> None:
    msg = {"params": {"channel": "user.lock", "data": {"currency": "BTC"}}}
    assert normalize("user.lock", msg) is None


# ---------------------------------------------------------------------------
# Dispatch
# ---------------------------------------------------------------------------

def test_unknown_channel_returns_none() -> None:
    assert normalize("trades.BTC-PERPETUAL.raw", {"params": {"data": {}}}) is None


# ---------------------------------------------------------------------------
# resolve_channels (subscription shorthand)
# ---------------------------------------------------------------------------

def test_resolve_channels_v1_returns_full_set() -> None:
    from realtime_ws.subscriptions import resolve_channels, V1_CHANNELS_ALL

    assert resolve_channels("v1") == V1_CHANNELS_ALL
    assert len(V1_CHANNELS_ALL) == 7


def test_resolve_channels_csv_passthrough() -> None:
    from realtime_ws.subscriptions import resolve_channels

    out = resolve_channels("foo, bar.baz , quux")
    assert out == ("foo", "bar.baz", "quux")
