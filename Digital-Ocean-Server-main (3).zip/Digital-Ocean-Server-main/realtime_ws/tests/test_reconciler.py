"""Phase 6d reconciler tests.

Mocks the REST client and asserts the on_message handler receives synthetic
WS-shaped messages for every required channel.
"""
from __future__ import annotations

import asyncio
import sys

import pytest


class _FakeRest:
    """Minimal stand-in for DeribitRestClient - just returns canned data."""

    def __init__(
        self,
        *,
        account: dict | None = None,
        positions: list[dict] | None = None,
        index_price: float = 0.0,
        raise_on: set[str] | None = None,
    ):
        self._account = account or {}
        self._positions = positions or []
        self._index = index_price
        self._raise_on = raise_on or set()

    async def get_account_summary(self, *, currency="BTC", extended=True):
        if "account" in self._raise_on:
            from realtime_ws.rest_client import DeribitRestError

            raise DeribitRestError("simulated")
        return self._account

    async def get_positions(self, *, currency="BTC"):
        if "positions" in self._raise_on:
            from realtime_ws.rest_client import DeribitRestError

            raise DeribitRestError("simulated")
        return list(self._positions)

    async def get_index_price(self, *, index_name="btc_usd"):
        if "index" in self._raise_on:
            from realtime_ws.rest_client import DeribitRestError

            raise DeribitRestError("simulated")
        return self._index


def test_reconciler_pushes_account_positions_and_index() -> None:
    from realtime_ws.reconciler import Reconciler

    captured: list[tuple[str, dict]] = []

    async def on_msg(channel, msg):
        captured.append((channel, msg))

    rest = _FakeRest(
        account={"currency": "BTC", "equity": 1.5, "delta_total": 0.5},
        positions=[
            {"instrument_name": "BTC-PERPETUAL", "kind": "future", "size": 1},
            {"instrument_name": "BTC-30MAY26-90000-C", "kind": "option", "size": 5},
        ],
        index_price=80123.45,
    )
    reconciler = Reconciler(rest=rest, on_message=on_msg)
    asyncio.run(reconciler.reconcile())

    channels = [c for c, _ in captured]
    assert "user.portfolio.btc" in channels
    assert "user.changes.future.BTC.raw" in channels
    assert "user.changes.option.BTC.raw" in channels
    assert "deribit_price_index.btc_usd" in channels
    # 1 account + 2 positions + 1 index = 4 messages
    assert len(captured) == 4


def test_reconciler_skips_failures_isolated() -> None:
    """A REST failure on one endpoint shouldn't block the others."""
    from realtime_ws.reconciler import Reconciler

    captured: list[tuple[str, dict]] = []

    async def on_msg(channel, msg):
        captured.append((channel, msg))

    rest = _FakeRest(
        account={"currency": "BTC", "equity": 1.0},
        positions=[],
        index_price=80000.0,
        raise_on={"positions"},  # positions endpoint blows up
    )
    reconciler = Reconciler(rest=rest, on_message=on_msg)
    asyncio.run(reconciler.reconcile())

    channels = [c for c, _ in captured]
    assert "user.portfolio.btc" in channels
    assert "deribit_price_index.btc_usd" in channels
    assert not any("user.changes" in c for c in channels)


def test_reconciler_message_shape_matches_ws_subscription() -> None:
    """Synthetic messages must have method=subscription + params.channel + params.data
    so they pass through the existing on_message handler unchanged."""
    from realtime_ws.reconciler import Reconciler

    captured: list[tuple[str, dict]] = []

    async def on_msg(channel, msg):
        captured.append((channel, msg))

    rest = _FakeRest(
        account={"currency": "BTC", "equity": 1.5, "delta_total": 0.5},
        positions=[],
        index_price=80000.0,
    )
    asyncio.run(Reconciler(rest=rest, on_message=on_msg).reconcile())

    for channel, msg in captured:
        assert msg.get("method") == "subscription"
        assert msg["params"]["channel"] == channel
        assert isinstance(msg["params"]["data"], dict)
