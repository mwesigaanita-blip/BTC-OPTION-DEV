"""realtime_ws - Deribit WebSocket collector.

Self-contained package. MUST NOT import from realtime/, mm_alert_bot/,
backend_api/, hedge_engine/, or shared/. See:
new_dashboard_plan_doc/02_priority1_backend_ws_implementation_plan.md §5.
"""
