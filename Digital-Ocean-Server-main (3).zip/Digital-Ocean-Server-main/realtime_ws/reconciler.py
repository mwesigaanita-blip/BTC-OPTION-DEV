"""REST snapshot publish on (re)connect - plan §6 / §7 Phase 6.

Why this exists:
  When the WS reconnects (network blip, droplet reboot, Deribit rolling
  restart), there is a 10–30 s gap before normal subscription messages
  start flowing again. Consumers (bots, agent, dashboard) would see stale
  data during that gap. The reconciler closes that hole by issuing a
  one-shot REST snapshot on every (re)connect and pushing it through the
  same handler as a synthetic WS subscription event. From the consumer's
  point of view it looks like a fresh WS message arrived just after the
  reconnect.

What it publishes (synthesized as Deribit-shaped subscription messages):
  * `user.portfolio.{btc,usdt,usdc}`  - from REST `private/get_account_summary`
  * `user.changes.future.BTC.raw`     - one msg per future position
  * `user.changes.option.BTC.raw`     - one msg per option position
  * `deribit_price_index.btc_usd`     - from REST `public/get_index_price`

The synthetic messages flow through the existing on_message handler so the
publisher, normalizer and SQLite mirror all stay on a single code path.
"""
from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from typing import Awaitable, Callable, Dict, Optional

from .health import HEALTH
from .rest_client import DeribitRestClient, DeribitRestError

log = logging.getLogger("realtime_ws.reconciler")

OnMessage = Callable[[str, dict], Awaitable[None]]


def _flag_if_maintenance(err: Exception) -> None:
    """If a REST error is Deribit's `system_maintenance` (code 11051), flag it
    on HEALTH so the dashboard can surface a maintenance banner."""
    text = str(err)
    if "system_maintenance" in text or "11051" in text:
        HEALTH.mark_maintenance("Deribit REST returned system_maintenance (11051)")


def _synth(channel: str, data: dict) -> dict:
    """Build a message that looks like a Deribit `subscription` notification."""
    return {
        "jsonrpc": "2.0",
        "method": "subscription",
        "params": {"channel": channel, "data": data},
    }


@dataclass
class Reconciler:
    rest: DeribitRestClient
    on_message: OnMessage
    currency: str = "BTC"
    index_name: str = "btc_usd"
    account_currencies: tuple[str, ...] = ("BTC", "USDT", "USDC")
    """Currencies whose portfolio summary is reconciled on (re)connect.
    Each maps to a `user.portfolio.<lower>` synthetic channel."""

    _known_positions: Dict[str, str] = field(default_factory=dict, repr=False)
    """instrument_name → kind, from the most recent positions refresh. Used to
    detect positions that were closed between refreshes so a size=0 update can
    be pushed for them."""

    async def reconcile(self) -> None:
        """Fetch snapshots and push them through `on_message`. Best-effort -
        each section catches its own exceptions so a transient REST failure
        on one endpoint doesn't block the others."""
        log.info("reconcile starting (currency=%s, index=%s)", self.currency, self.index_name)
        await self._reconcile_account()
        await self.reconcile_positions()
        await self._reconcile_index()
        log.info("reconcile complete")

    async def _reconcile_account(self) -> None:
        for currency in self.account_currencies:
            channel = f"user.portfolio.{currency.lower()}"
            try:
                acct = await self.rest.get_account_summary(currency=currency)
            except DeribitRestError as e:
                _flag_if_maintenance(e)
                log.warning("reconcile account_summary %s failed: %s", currency, e)
                continue
            if not acct:
                log.warning("reconcile account_summary %s returned empty", currency)
                continue
            await self.on_message(channel, _synth(channel, acct))
            log.info(
                "reconcile account %s: equity=%s margin_balance=%s",
                currency,
                acct.get("equity"),
                acct.get("margin_balance"),
            )

    async def reconcile_positions(self) -> None:
        """Fetch the full position book via REST and push it through
        `on_message`.

        Also drives the **periodic positions refresh**: `user.changes.*` only
        fires on actual trades, so between trades position mark price / PnL /
        greeks would sit frozen. Re-pushing the REST snapshot on a timer keeps
        those values live. Positions that vanished since the last refresh were
        closed - a size=0 update is pushed so downstream snapshot caches drop
        them."""
        try:
            positions = await self.rest.get_positions(currency=self.currency)
        except DeribitRestError as e:
            _flag_if_maintenance(e)
            log.warning("reconcile positions failed: %s", e)
            return
        positions = positions or []

        # Group by kind so each gets routed to the right user.changes channel
        # by the existing on_message handler. The mirror caches them all in
        # the per-instrument map regardless.
        current: Dict[str, str] = {}
        for p in positions:
            kind = (p.get("kind") or "").lower()
            inst = p.get("instrument_name")
            if not inst or kind not in ("future", "option"):
                continue
            current[inst] = kind
            channel = f"user.changes.{kind}.BTC.raw"
            data = {
                "instrument_name": inst,
                "trades": [],
                "positions": [p],
                "orders": [],
            }
            await self.on_message(channel, _synth(channel, data))

        # Closed positions: present last refresh, absent now → push size=0.
        for inst, kind in self._known_positions.items():
            if inst in current:
                continue
            channel = f"user.changes.{kind}.BTC.raw"
            data = {
                "instrument_name": inst,
                "trades": [],
                "positions": [{"instrument_name": inst, "kind": kind, "size": 0.0}],
                "orders": [],
            }
            await self.on_message(channel, _synth(channel, data))

        closed = len(set(self._known_positions) - set(current))
        self._known_positions = current
        log.info("reconcile positions: pushed %d, closed %d", len(current), closed)

    async def _reconcile_index(self) -> None:
        try:
            price = await self.rest.get_index_price(index_name=self.index_name)
        except DeribitRestError as e:
            _flag_if_maintenance(e)
            log.warning("reconcile index_price failed: %s", e)
            return
        if not price:
            log.warning("reconcile index_price returned 0")
            return
        data = {
            "price": float(price),
            "timestamp": int(time.time() * 1000),
            "index_name": self.index_name,
        }
        await self.on_message(
            "deribit_price_index.btc_usd",
            _synth("deribit_price_index.btc_usd", data),
        )
        log.info("reconcile index: btc=%.2f", price)
