"""Redis latest-snapshot cache.

Redis pub/sub is ephemeral - a poll-based consumer (the Streamlit dashboard)
cannot read it. This component keeps an in-process snapshot of the latest
state and SETs it under stable `app.<topic>.latest` keys on a fixed cadence,
so any consumer can `GET` the current value on demand.

Design mirrors `SqliteMirror`: a state cache fed from the WS handler plus a
periodic flush task. We flush every ~1 s rather than per-event because the
perp ticker fires every 100 ms - a per-event SET would be wasteful.

Keys written (with `REDIS_PUBSUB_PREFIX` prepended, usually blank):
  * `app.account.latest`   → {"BTC": {...}, "USDT": {...}, "USDC": {...}}
  * `app.market.latest`    → merged index + perp fields
  * `app.positions.latest` → list of current position dicts (size != 0)

Each value carries a `schema_v` + `fetched_at` envelope so readers can detect
staleness.
"""
from __future__ import annotations

import asyncio
import json
import logging
from datetime import datetime, timezone
from typing import Any, Optional

import redis.asyncio as aioredis

from .metrics import snapshot_writes_failed_total, snapshot_writes_total

log = logging.getLogger("realtime_ws.snapshot_cache")

SCHEMA_VERSION = "v1"
DEFAULT_FLUSH_INTERVAL_S = 1.0

ACCOUNT_KEY = "app.account.latest"
MARKET_KEY = "app.market.latest"
POSITIONS_KEY = "app.positions.latest"


def _now_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ")


class SnapshotCache:
    """In-process latest-state cache + periodic Redis SET flush task.

    Lifecycle (start/aclose) is managed by `run.py`, like `SqliteMirror`.
    `update()` and the flush loop both run on the asyncio event loop, so no
    locking is needed.
    """

    def __init__(
        self,
        redis: aioredis.Redis,
        *,
        pubsub_prefix: str = "",
        flush_interval_s: float = DEFAULT_FLUSH_INTERVAL_S,
    ) -> None:
        self.redis = redis
        self.pubsub_prefix = pubsub_prefix
        self.flush_interval_s = float(flush_interval_s)

        # Latest account portfolio keyed by upper-case currency (BTC/USDT/USDC).
        self._account: dict[str, dict] = {}
        # Merged market state - index price + perp ticker fields.
        self._market: dict[str, Any] = {}
        # Full position book keyed by instrument_name. size==0 is dropped.
        self._positions: dict[str, dict] = {}

        self._task: Optional[asyncio.Task] = None
        self._stop = asyncio.Event()
        self._writes_total = 0
        self._writes_failed = 0

    def _key(self, name: str) -> str:
        return f"{self.pubsub_prefix}{name}" if self.pubsub_prefix else name

    # ---- handler hook ----------------------------------------------------

    def update(self, app_topic: str, payload: dict) -> None:
        """Fold one normalized `(app_topic, payload)` into the cache.

        `payload` is the normalizer envelope: {schema_v, fetched_at,
        source_channel, data}. Never raises - a malformed message must not
        break the WS read path.
        """
        try:
            data = payload.get("data")
            if not isinstance(data, dict):
                return

            if app_topic == "account":
                currency = str(data.get("currency") or "").upper()
                if currency:
                    self._account[currency] = data
            elif app_topic == "market":
                # Index and perp ticker both feed app.market with disjoint
                # field sets - merge so neither source clobbers the other.
                self._market.update(data)
            elif app_topic == "positions":
                positions = data.get("positions")
                if not isinstance(positions, list):
                    return
                for p in positions:
                    if not isinstance(p, dict):
                        continue
                    inst = p.get("instrument_name")
                    if not inst:
                        continue
                    try:
                        size = float(p.get("size") or 0.0)
                    except (TypeError, ValueError):
                        size = 0.0
                    if size == 0.0:
                        self._positions.pop(inst, None)
                    else:
                        self._positions[inst] = p
        except Exception as e:
            log.warning("snapshot cache update failed (topic=%s): %s", app_topic, e)

    # ---- task lifecycle --------------------------------------------------

    def start(self) -> asyncio.Task:
        if self._task is not None:
            return self._task
        log.info(
            "snapshot cache starting: prefix=%r flush=%.1fs",
            self.pubsub_prefix,
            self.flush_interval_s,
        )
        self._task = asyncio.create_task(self._flush_loop(), name="snapshot-cache")
        return self._task

    def stop(self) -> None:
        self._stop.set()

    async def aclose(self) -> None:
        self.stop()
        if self._task is not None:
            try:
                await self._task
            except (asyncio.CancelledError, Exception):
                pass

    async def _flush_loop(self) -> None:
        try:
            while not self._stop.is_set():
                try:
                    await asyncio.wait_for(
                        self._stop.wait(), timeout=self.flush_interval_s
                    )
                    break  # stop requested
                except asyncio.TimeoutError:
                    pass
                await self._flush_once()
        except asyncio.CancelledError:
            return
        except Exception as e:
            log.exception("snapshot flush loop crashed: %s", e)

    def _envelope(self, data: Any) -> str:
        return json.dumps(
            {
                "schema_v": SCHEMA_VERSION,
                "fetched_at": _now_iso(),
                "data": data,
            },
            default=str,
        )

    async def _flush_once(self) -> None:
        wrote = False
        try:
            if self._account:
                await self.redis.set(
                    self._key(ACCOUNT_KEY), self._envelope(dict(self._account))
                )
                wrote = True
            if self._market:
                await self.redis.set(
                    self._key(MARKET_KEY), self._envelope(dict(self._market))
                )
                wrote = True
            if self._positions:
                await self.redis.set(
                    self._key(POSITIONS_KEY),
                    self._envelope(list(self._positions.values())),
                )
                wrote = True
            if wrote:
                self._writes_total += 1
                snapshot_writes_total.inc()
        except Exception as e:
            self._writes_failed += 1
            snapshot_writes_failed_total.inc()
            log.warning("snapshot cache write failed: %s", e)

    # ---- introspection ---------------------------------------------------

    def stats(self) -> dict:
        return {
            "writes_total": self._writes_total,
            "writes_failed": self._writes_failed,
            "currencies": sorted(self._account.keys()),
            "has_market": bool(self._market),
            "positions_cached": len(self._positions),
        }
