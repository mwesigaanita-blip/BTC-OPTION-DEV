"""Async Deribit REST client - minimal subset needed for snapshot reconcile.

# Pattern adapted from mm_alert_bot/api/deribit_client.py on 2026-05-10.
# Modify here only - do not re-sync from origin.
# Per plan §5: must not import from mm_alert_bot/. The full origin client
# carries 600+ lines of sync+async code, retry adapters, pooled HTTP - we
# only need three private GETs plus token-bearer auth, so we write a thin
# aiohttp-based version here.

Three RPCs only:
  * private/get_account_summary
  * private/get_positions
  * public/get_index_price

Auth flow: client_credentials over HTTP (separate from the WS auth in
auth.py). Token cached in memory; refreshed 15 s before expiry or on a
13009/invalid_token RPC error.
"""
from __future__ import annotations

import asyncio
import logging
import time
from dataclasses import dataclass, field
from typing import Any, Optional

import aiohttp

from .auth import Credentials

log = logging.getLogger("realtime_ws.rest_client")

REFRESH_LEAD_S = 15.0
INVALID_TOKEN_CODES = (13004, 13009)


@dataclass
class _Token:
    access_token: str = ""
    expires_at: float = 0.0

    def is_valid(self) -> bool:
        return bool(self.access_token) and time.time() < (self.expires_at - REFRESH_LEAD_S)


class DeribitRestError(RuntimeError):
    pass


@dataclass
class DeribitRestClient:
    creds: Credentials
    timeout_s: float = 10.0
    """Per-request timeout."""

    _session: Optional[aiohttp.ClientSession] = field(default=None, repr=False)
    _token: _Token = field(default_factory=_Token, repr=False)

    @property
    def base_url(self) -> str:
        return (
            "https://test.deribit.com"
            if self.creds.testnet
            else "https://www.deribit.com"
        )

    async def _ensure_session(self) -> aiohttp.ClientSession:
        if self._session is None or self._session.closed:
            self._session = aiohttp.ClientSession(
                timeout=aiohttp.ClientTimeout(total=self.timeout_s)
            )
        return self._session

    async def aclose(self) -> None:
        if self._session is not None and not self._session.closed:
            await self._session.close()
            self._session = None

    # ------------------------------------------------------------------
    # Auth
    # ------------------------------------------------------------------

    async def _ensure_token(self, *, force: bool = False) -> str:
        if not force and self._token.is_valid():
            return self._token.access_token
        url = f"{self.base_url}/api/v2/public/auth"
        params = {
            "grant_type": "client_credentials",
            "client_id": self.creds.client_id,
            "client_secret": self.creds.client_secret,
        }
        session = await self._ensure_session()
        async with session.get(url, params=params) as resp:
            data = await resp.json()
        result = data.get("result") or {}
        access = str(result.get("access_token", "") or "")
        ttl = float(result.get("expires_in", 0) or 0)
        if not access or ttl <= 0:
            raise DeribitRestError(f"auth failed: {data!r}")
        self._token = _Token(access_token=access, expires_at=time.time() + ttl)
        log.info("rest auth ok (testnet=%s, ttl=%.0fs)", self.creds.testnet, ttl)
        return access

    # ------------------------------------------------------------------
    # RPC
    # ------------------------------------------------------------------

    async def _rpc(self, method: str, params: dict[str, Any], *, auth: bool) -> Any:
        url = f"{self.base_url}/api/v2/{method}"
        session = await self._ensure_session()
        for attempt in range(2):  # one retry on invalid_token
            headers = {}
            if auth:
                token = await self._ensure_token(force=(attempt == 1))
                headers["Authorization"] = f"Bearer {token}"
            async with session.get(url, params=params, headers=headers) as resp:
                status = resp.status
                # Always try to parse the body as JSON-RPC first. Deribit
                # returns 13009/session_not_found with HTTP 400, so we MUST
                # see the JSON error code to trigger the auto-reauth path
                # - short-circuiting on HTTP status alone hides 13009 as
                # an opaque "HTTP 400" and the retry never fires.
                try:
                    data = await resp.json(content_type=None)
                except Exception:
                    text = await resp.text()
                    raise DeribitRestError(f"HTTP {status} {method}: {text[:300]}")

            err = data.get("error")
            if err:
                code = int((err or {}).get("code") or 0)
                if code in INVALID_TOKEN_CODES and attempt == 0:
                    log.warning(
                        "rest %s got invalid_token/session_not_found (code=%d) - "
                        "re-authing and retrying once",
                        method, code,
                    )
                    self._token = _Token()
                    continue
                raise DeribitRestError(f"rpc error {method}: {err}")

            if status >= 400 and not err:
                # Non-RPC HTTP error (network/gateway) - surface verbatim.
                raise DeribitRestError(f"HTTP {status} {method}: {data!r}")
            return data.get("result")
        raise DeribitRestError(f"rpc {method} failed after retries")

    # ------------------------------------------------------------------
    # Public methods
    # ------------------------------------------------------------------

    async def get_account_summary(
        self, *, currency: str = "BTC", extended: bool = True
    ) -> dict:
        return await self._rpc(
            "private/get_account_summary",
            params={"currency": currency.upper(), "extended": str(bool(extended)).lower()},
            auth=True,
        ) or {}

    async def get_positions(self, *, currency: str = "BTC") -> list[dict]:
        return await self._rpc(
            "private/get_positions",
            params={"currency": currency.upper()},
            auth=True,
        ) or []

    async def get_index_price(self, *, index_name: str = "btc_usd") -> float:
        result = await self._rpc(
            "public/get_index_price",
            params={"index_name": index_name},
            auth=False,
        ) or {}
        return float(result.get("index_price", 0.0) or 0.0)
