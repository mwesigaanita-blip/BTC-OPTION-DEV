"""Entrypoint for the WS collector.

Phase 1: idle skeleton (Redis ping only).
Phase 2: optional Deribit WS client (public channels) wired in via CLI flags.

Usage:
  python -m realtime_ws.run                                # idle (Phase 1 mode)
  python -m realtime_ws.run --testnet \\
      --channels=deribit_price_index.btc_usd               # Phase 2 smoke test
"""
from __future__ import annotations

import argparse
import asyncio
import json
import logging
import os
import signal
import sys
from dataclasses import replace
from typing import Optional

import redis.asyncio as aioredis

from .aggregator import Aggregator
from .auth import Credentials
from .client import DeribitWSClient
from .config import Config, load_config
from .health import HEALTH
from .http_server import HttpServer
from .normalizer import normalize
from .publisher import Publisher
from .reconciler import Reconciler
from .rest_client import DeribitRestClient
from .snapshot_cache import SnapshotCache
from .sqlite_mirror import SqliteMirror
from .subscriptions import is_private, resolve_channels

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(name)s %(message)s",
    force=True,
)
log = logging.getLogger("realtime_ws")


async def _ping_redis_loop(client: aioredis.Redis, stop: asyncio.Event) -> None:
    while not stop.is_set():
        try:
            pong = await client.ping()
            HEALTH.mark_redis(bool(pong))
        except Exception as e:
            HEALTH.mark_redis(False)
            log.warning("redis ping failed: %s", e)
        try:
            await asyncio.wait_for(stop.wait(), timeout=5.0)
        except asyncio.TimeoutError:
            pass


async def _idle_loop(stop: asyncio.Event) -> None:
    log.info("ws_collector idle (no Deribit subscriptions configured)")
    tick = 0
    while not stop.is_set():
        tick += 1
        if tick % 6 == 0:  # every ~30s
            log.info("health=%s", json.dumps(HEALTH.snapshot()))
        try:
            await asyncio.wait_for(stop.wait(), timeout=5.0)
        except asyncio.TimeoutError:
            pass


async def _health_log_loop(stop: asyncio.Event, interval_s: float = 30.0) -> None:
    while not stop.is_set():
        try:
            await asyncio.wait_for(stop.wait(), timeout=interval_s)
        except asyncio.TimeoutError:
            log.info("health=%s", json.dumps(HEALTH.snapshot()))


async def _positions_refresh_loop(
    reconciler: Reconciler, stop: asyncio.Event, interval_s: float
) -> None:
    """Periodically re-pull the REST position book.

    `user.changes.*` only fires on actual trades, so position mark price / PnL
    / greeks would otherwise sit frozen between trades. This timer keeps them
    live by re-pushing the REST snapshot through the same handler."""
    while not stop.is_set():
        try:
            await asyncio.wait_for(stop.wait(), timeout=interval_s)
            return  # stop requested
        except asyncio.TimeoutError:
            pass
        try:
            await reconciler.reconcile_positions()
        except Exception as e:
            log.warning("periodic positions refresh failed: %s", e)


def _make_message_handler(
    publisher: Optional[Publisher],
    mirror: Optional[SqliteMirror],
    snapshot: Optional[SnapshotCache],
    stdout: bool,
):
    """Build the on_message callback.

    Each WS message is fanned out four ways:
      * publisher.publish_raw  → deribit.raw.<channel>
      * publisher.publish_app  → app.<topic> (if a normalizer is registered)
      * snapshot.update        → folds normalized payload into the latest cache
      * mirror.on_message      → updates in-memory cache for SQLite flush
      * stdout one-liner       → only when --quiet is not set
    """

    async def _handler(channel: str, msg: dict) -> None:
        # 1. Raw broadcast.
        if publisher is not None:
            await publisher.publish_raw(channel, msg)

        # 2. Normalize.
        normalized: Optional[tuple[str, dict]] = normalize(channel, msg)
        if normalized is not None:
            app_topic, payload = normalized
            if publisher is not None:
                await publisher.publish_app(app_topic, payload)
            # 3. Latest-snapshot cache (Redis SET keys for poll-based readers).
            if snapshot is not None:
                snapshot.update(app_topic, payload)

        # 4. SQLite mirror (raw payload - legacy schema compatibility).
        if mirror is not None:
            mirror.on_message(channel, msg)

        # 4. Optional stdout.
        if stdout:
            params = msg.get("params") or {}
            data = params.get("data")
            if isinstance(data, dict):
                keys = list(data.keys())[:6]
                snippet = {k: data.get(k) for k in keys}
                log.info(
                    "msg channel=%s data=%s norm=%s",
                    channel,
                    json.dumps(snippet, default=str),
                    normalized[0] if normalized else "-",
                )
            elif isinstance(data, list):
                log.info("msg channel=%s len=%d", channel, len(data))
            else:
                log.info("msg channel=%s data=%r", channel, data)

    return _handler


def _install_signal_handlers(loop: asyncio.AbstractEventLoop, stop: asyncio.Event) -> None:
    def _trigger(*_):
        log.info("shutdown signal received")
        loop.call_soon_threadsafe(stop.set)

    for sig_name in ("SIGINT", "SIGTERM"):
        sig = getattr(signal, sig_name, None)
        if sig is None:
            continue
        try:
            loop.add_signal_handler(sig, _trigger)
        except (NotImplementedError, RuntimeError):
            signal.signal(sig, _trigger)


def _parse_args(argv: Optional[list[str]]) -> argparse.Namespace:
    p = argparse.ArgumentParser(prog="realtime_ws.run")
    p.add_argument(
        "--testnet",
        action="store_true",
        help="Force WS_USE_TESTNET=1 for this run.",
    )
    p.add_argument(
        "--channels",
        type=str,
        default=os.getenv("WS_CHANNELS", ""),
        help="Comma-separated list of Deribit channels, OR a shorthand: "
        "'v1' (full V1 set per plan §1), 'public', 'private', 'default'.",
    )
    p.add_argument(
        "--no-publish",
        action="store_true",
        help="Skip Redis publishing (stdout-only). Use for smoke tests.",
    )
    p.add_argument(
        "--quiet",
        action="store_true",
        help="Suppress per-message stdout lines (recommended in production).",
    )
    p.add_argument(
        "--force-token-ttl-seconds",
        type=float,
        default=0.0,
        help="DEBUG: clamp the access-token expires_at to N seconds from now "
        "after auth, forcing a refresh ~15s before that. Used to verify the "
        "refresh loop on accounts whose real token TTL is too long.",
    )
    p.add_argument(
        "--no-mirror",
        action="store_true",
        help="Skip writes to realtime.sqlite (in-memory cache only). Use for "
        "smoke tests where you don't want to touch the legacy DB.",
    )
    p.add_argument(
        "--no-snapshot",
        action="store_true",
        help="Skip the Redis latest-snapshot cache (app.*.latest keys). Use for "
        "smoke tests that should not touch those keys.",
    )
    p.add_argument(
        "--mirror-flush-seconds",
        type=float,
        default=0.0,
        help="Override the SQLite mirror flush cadence (default 5.0 s, "
        "matches the legacy poller).",
    )
    p.add_argument(
        "--no-aggregator",
        action="store_true",
        help="Skip the 60s aggregator that writes hedge_engine_aggregated_metrics. "
        "Use when running a smoke that should not touch hedge_engine.sqlite.",
    )
    p.add_argument(
        "--aggregator-interval-seconds",
        type=float,
        default=0.0,
        help="Override aggregator cadence (default 60.0 s).",
    )
    p.add_argument(
        "--no-reconcile",
        action="store_true",
        help="Skip the REST snapshot push on (re)connect. Useful when running "
        "with public-only channels (no creds available).",
    )
    p.add_argument(
        "--positions-refresh-seconds",
        type=float,
        default=10.0,
        help="Interval for the periodic REST position-book refresh that keeps "
        "position mark/PnL/greeks live between trades. 0 disables it.",
    )
    return p.parse_args(argv)


async def _amain(argv: Optional[list[str]]) -> int:
    args = _parse_args(argv)

    cfg = load_config()
    if args.testnet:
        cfg = replace(cfg, use_testnet=True)
    if not cfg.enabled:
        log.warning("WS_COLLECTOR_ENABLED=0 - exiting")
        return 0

    channels = resolve_channels(args.channels)

    log.info(
        "starting ws_collector: redis=%s testnet=%s channels=%s",
        cfg.redis_url,
        cfg.use_testnet,
        list(channels) or "(none - idle)",
    )

    stop = asyncio.Event()
    _install_signal_handlers(asyncio.get_running_loop(), stop)

    redis_client: Optional[aioredis.Redis] = None
    ws_client: Optional[DeribitWSClient] = None
    rest: Optional[DeribitRestClient] = None
    http_server: Optional[HttpServer] = None
    mirror: Optional[SqliteMirror] = None
    snapshot: Optional[SnapshotCache] = None
    aggregator: Optional[Aggregator] = None
    try:
        redis_client = aioredis.from_url(cfg.redis_url, decode_responses=True)

        http_server = HttpServer(port=cfg.http_port)
        await http_server.start()

        tasks = [
            asyncio.create_task(_ping_redis_loop(redis_client, stop), name="redis-ping"),
        ]

        if channels:
            creds = None
            if any(is_private(c) for c in channels):
                creds = Credentials.from_env(testnet=cfg.use_testnet)
                log.info(
                    "private channels detected; loaded creds (testnet=%s, client_id=%s***)",
                    creds.testnet,
                    creds.client_id[:4],
                )

            publisher: Optional[Publisher] = None
            if not args.no_publish:
                publisher = Publisher(
                    redis=redis_client, pubsub_prefix=cfg.redis_pubsub_prefix
                )
                log.info(
                    "publisher enabled: prefix=%r → topics deribit.raw.* + app.*",
                    cfg.redis_pubsub_prefix,
                )
            else:
                log.info("publisher disabled (--no-publish)")

            if not args.no_mirror and cfg.mirror_to_sqlite:
                flush = args.mirror_flush_seconds or 5.0
                mirror = SqliteMirror(flush_interval_s=flush)
                tasks.append(mirror.start())
                log.info("sqlite mirror enabled: flush=%.1fs", flush)
            else:
                log.info(
                    "sqlite mirror disabled (--no-mirror=%s, WS_MIRROR_TO_SQLITE=%s)",
                    args.no_mirror,
                    cfg.mirror_to_sqlite,
                )

            # Latest-snapshot cache - SETs app.*.latest keys for poll-based
            # readers (the Streamlit dashboard). Needs the Redis client and
            # the publisher's prefix; skipped with --no-publish or --no-snapshot.
            if not args.no_snapshot and not args.no_publish:
                snapshot = SnapshotCache(
                    redis=redis_client, pubsub_prefix=cfg.redis_pubsub_prefix
                )
                tasks.append(snapshot.start())
                log.info("snapshot cache enabled → app.account/market/positions.latest")
            else:
                log.info(
                    "snapshot cache disabled (--no-snapshot=%s, --no-publish=%s)",
                    args.no_snapshot,
                    args.no_publish,
                )

            # Aggregator runs only when the SQLite mirror is also writing -
            # there's nothing to aggregate from otherwise.
            if not args.no_aggregator and mirror is not None:
                interval = args.aggregator_interval_seconds or 60.0
                aggregator = Aggregator(interval_s=interval)
                tasks.append(aggregator.start())
                log.info("aggregator enabled: interval=%.1fs", interval)
            else:
                log.info("aggregator disabled (--no-aggregator=%s)", args.no_aggregator)

            handler = _make_message_handler(
                publisher=publisher, mirror=mirror, snapshot=snapshot,
                stdout=not args.quiet,
            )

            # Reconciler runs only when we have credentials (private channels)
            # and it's not explicitly disabled. It re-uses the same handler
            # so its snapshot flows through publish + mirror identically.
            on_connect_hook = None
            on_connect_failed_hook = None
            if not args.no_reconcile and creds is not None:
                rest = DeribitRestClient(creds=creds)
                reconciler = Reconciler(rest=rest, on_message=handler)
                on_connect_hook = reconciler.reconcile
                # Same REST snapshot, fired after a *failed* connection attempt
                # so the dashboard keeps live numbers while the WS is offline.
                on_connect_failed_hook = reconciler.reconcile
                log.info("reconciler enabled: REST snapshot will fire on each (re)connect")
                # Periodic position-book refresh - user.changes.* only fires on
                # trades, so without this positions freeze between trades.
                refresh_s = float(args.positions_refresh_seconds or 0.0)
                if refresh_s > 0.0:
                    tasks.append(asyncio.create_task(
                        _positions_refresh_loop(reconciler, stop, refresh_s),
                        name="positions-refresh",
                    ))
                    log.info("periodic positions refresh enabled: every %.1fs", refresh_s)
                else:
                    log.info("periodic positions refresh disabled (interval=0)")
            else:
                log.info(
                    "reconciler disabled (--no-reconcile=%s, has_creds=%s)",
                    args.no_reconcile,
                    creds is not None,
                )

            ws_client = DeribitWSClient(
                cfg=cfg,
                channels=channels,
                on_message=handler,
                credentials=creds,
                force_token_ttl_seconds=float(args.force_token_ttl_seconds or 0.0),
                on_connect=on_connect_hook,
                on_connect_failed=on_connect_failed_hook,
            )
            tasks.append(asyncio.create_task(ws_client.run_forever(), name="ws-client"))
            tasks.append(asyncio.create_task(_health_log_loop(stop), name="health-log"))
        else:
            tasks.append(asyncio.create_task(_idle_loop(stop), name="idle"))

        await stop.wait()

        # Phase 9 graceful shutdown ordering:
        #   1. Tell the WS client to stop accepting new messages.
        #   2. Flush the SQLite mirror so the last 5 s window lands.
        #   3. Cancel remaining background tasks.
        #   4. Close REST + Redis clients.
        #   5. Keep /metrics scrapeable until the very last step.
        log.info("shutdown: stopping ws client")
        if ws_client is not None:
            ws_client.stop()
        log.info("shutdown: flushing sqlite mirror")
        if mirror is not None:
            try:
                await asyncio.wait_for(mirror.aclose(), timeout=10.0)
            except Exception as e:
                log.warning("mirror flush on shutdown failed: %s", e)
        log.info("shutdown: stopping snapshot cache")
        if snapshot is not None:
            try:
                await asyncio.wait_for(snapshot.aclose(), timeout=10.0)
            except Exception as e:
                log.warning("snapshot cache stop on shutdown failed: %s", e)
        log.info("shutdown: cancelling background tasks")
        for t in tasks:
            t.cancel()
        await asyncio.gather(*tasks, return_exceptions=True)
    finally:
        if rest is not None:
            try:
                await rest.aclose()
            except Exception:
                pass
        if redis_client is not None:
            try:
                await redis_client.aclose()
            except Exception:
                pass
        if http_server is not None:
            try:
                await http_server.stop()
            except Exception:
                pass
    log.info("ws_collector stopped")
    return 0


def main(argv: Optional[list[str]] = None) -> int:
    try:
        return asyncio.run(_amain(argv))
    except KeyboardInterrupt:
        return 0


if __name__ == "__main__":
    sys.exit(main())
