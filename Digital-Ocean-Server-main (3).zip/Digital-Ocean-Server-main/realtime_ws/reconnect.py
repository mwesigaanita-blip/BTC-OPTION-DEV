"""Exponential backoff with jitter for WS reconnect attempts.

# Copied from realtime/_deribit.py:_backoff on 2026-05-10.
# Adapted to async + parameterized via Config; do not re-sync from origin.
"""
from __future__ import annotations

import asyncio
import random


def compute_backoff(
    attempt: int,
    *,
    base: float = 0.35,
    cap: float = 30.0,
    jitter: float = 0.5,
) -> float:
    """Return seconds to sleep before reconnect attempt N (0-indexed).

    Mirrors realtime/_deribit.py:_backoff but with the larger cap/jitter
    appropriate for a long-lived WS connection (vs short REST retries).
    """
    raw = min(cap, base * (2 ** attempt))
    return max(0.0, raw + random.uniform(-jitter, jitter))


async def sleep_backoff(
    attempt: int,
    *,
    base: float = 0.35,
    cap: float = 30.0,
    jitter: float = 0.5,
) -> float:
    delay = compute_backoff(attempt, base=base, cap=cap, jitter=jitter)
    if delay > 0:
        await asyncio.sleep(delay)
    return delay
