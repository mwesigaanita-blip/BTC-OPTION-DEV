"""Env-driven config for the WS collector.

Phase 1: only the variables the skeleton uses (Redis URL + a few flags).
More vars will land as later phases add Deribit auth, channels, etc.
"""
from __future__ import annotations

import os
from dataclasses import dataclass

try:
    from dotenv import load_dotenv

    load_dotenv()
except Exception:
    pass


def _bool(name: str, default: str = "0") -> bool:
    return os.getenv(name, default).strip().lower() in ("1", "true", "yes", "on")


def _float(name: str, default: float) -> float:
    raw = os.getenv(name, "").strip()
    if not raw:
        return default
    try:
        return float(raw)
    except ValueError:
        return default


def _int(name: str, default: int) -> int:
    raw = os.getenv(name, "").strip()
    if not raw:
        return default
    try:
        return int(raw)
    except ValueError:
        return default


@dataclass(frozen=True)
class Config:
    enabled: bool
    redis_url: str
    redis_pubsub_prefix: str
    use_testnet: bool
    deribit_url: str
    deribit_testnet_url: str
    heartbeat_interval_s: float
    reconnect_backoff_base_s: float
    reconnect_backoff_cap_s: float
    reconnect_jitter_s: float
    staleness_threshold_s: float
    retention_hours: float
    mirror_to_sqlite: bool
    http_port: int

    @property
    def active_deribit_url(self) -> str:
        return self.deribit_testnet_url if self.use_testnet else self.deribit_url


def load_config() -> Config:
    return Config(
        enabled=_bool("WS_COLLECTOR_ENABLED", "1"),
        redis_url=os.getenv("REDIS_URL", "redis://redis:6379/0"),
        redis_pubsub_prefix=os.getenv("REDIS_PUBSUB_PREFIX", ""),
        use_testnet=_bool("WS_USE_TESTNET", "0"),
        deribit_url=os.getenv("WS_DERIBIT_URL", "wss://www.deribit.com/ws/api/v2"),
        deribit_testnet_url=os.getenv(
            "WS_DERIBIT_TESTNET_URL", "wss://test.deribit.com/ws/api/v2"
        ),
        heartbeat_interval_s=_float("WS_HEARTBEAT_INTERVAL_S", 60.0),
        reconnect_backoff_base_s=_float("WS_RECONNECT_BACKOFF_BASE_S", 0.35),
        reconnect_backoff_cap_s=_float("WS_RECONNECT_BACKOFF_CAP_S", 30.0),
        reconnect_jitter_s=_float("WS_RECONNECT_JITTER_S", 0.5),
        staleness_threshold_s=_float("WS_STALENESS_THRESHOLD_S", 90.0),
        retention_hours=_float("WS_RETENTION_HOURS", 72.0),
        mirror_to_sqlite=_bool("WS_MIRROR_TO_SQLITE", "1"),
        http_port=_int("WS_COLLECTOR_HTTP_PORT", 8101),
    )
