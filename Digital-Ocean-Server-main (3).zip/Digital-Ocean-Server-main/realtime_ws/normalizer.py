"""Per-channel normalizer: raw Deribit subscription → canonical app.* payload.

Output envelope (constant across topics - see plan §4):
  {
    "schema_v":       "v1",
    "fetched_at":     "<ISO-8601 UTC>",
    "source_channel": "<deribit channel>",
    "data":           { ...topic-specific fields... }
  }

`normalize(channel, msg)` returns `(app_topic, payload) | None`.
None means "ignore - wrong shape or unknown channel". Callers still publish
the raw message even when normalize returns None, so debugging is unaffected.
"""
from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Any, Callable, Optional

log = logging.getLogger("realtime_ws.normalizer")

SCHEMA_VERSION = "v1"

NormalizedResult = tuple[str, dict[str, Any]]
"""(app_topic_suffix, payload). Topic suffix is the part after `app.`."""

ChannelNormalizer = Callable[[str, dict[str, Any]], Optional[NormalizedResult]]


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _now_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ")


def _envelope(
    source_channel: str, app_topic: str, data: dict[str, Any]
) -> NormalizedResult:
    return app_topic, {
        "schema_v": SCHEMA_VERSION,
        "fetched_at": _now_iso(),
        "source_channel": source_channel,
        "data": data,
    }


def _get_subscription_data(msg: dict[str, Any]) -> Optional[dict[str, Any]]:
    """Extract `params.data` from a Deribit subscription message."""
    params = msg.get("params")
    if not isinstance(params, dict):
        return None
    data = params.get("data")
    if not isinstance(data, dict):
        return None
    return data


def _f(d: dict[str, Any], key: str, default: Optional[float] = None) -> Optional[float]:
    """Coerce a numeric field; return default on missing/unparseable."""
    if key not in d or d[key] is None:
        return default
    try:
        return float(d[key])
    except (TypeError, ValueError):
        return default


# ---------------------------------------------------------------------------
# Per-channel normalizers
# ---------------------------------------------------------------------------

def normalize_index_price(
    channel: str, msg: dict[str, Any]
) -> Optional[NormalizedResult]:
    """deribit_price_index.btc_usd  → app.market

    Sample payload:
      {"timestamp": 1778416966741, "price": 80911.0, "index_name": "btc_usd"}
    """
    d = _get_subscription_data(msg)
    if d is None:
        return None
    price = _f(d, "price")
    ts_ms = _f(d, "timestamp")
    if price is None or ts_ms is None:
        log.warning("index_price malformed: missing price/timestamp: %s", d)
        return None
    return _envelope(
        channel,
        "market",
        {
            "btc_index": price,
            "btc_index_ts_ms": int(ts_ms),
            "index_name": d.get("index_name"),
        },
    )


def normalize_volatility_index(
    channel: str, msg: dict[str, Any]
) -> Optional[NormalizedResult]:
    """deribit_volatility_index.btc_usd  → app.market

    Sample payload:
      {"timestamp": 1778416966741, "volatility": 56.32, "index_name": "btc_usd"}
    """
    d = _get_subscription_data(msg)
    if d is None:
        return None
    vol = _f(d, "volatility")
    ts_ms = _f(d, "timestamp")
    if vol is None or ts_ms is None:
        log.warning("volatility_index malformed: missing volatility/timestamp: %s", d)
        return None
    return _envelope(
        channel,
        "market",
        {
            "dvol": vol,
            "dvol_ts_ms": int(ts_ms),
            "dvol_index_name": d.get("index_name"),
        },
    )


def normalize_user_portfolio(
    channel: str, msg: dict[str, Any]
) -> Optional[NormalizedResult]:
    """user.portfolio.{btc|usdt|usdc}  → app.account

    Currency-agnostic - the topic is always `account`; consumers split by the
    `currency` field in the payload.

    DRAFT - fields based on Deribit docs; field shape will be validated against
    the first Phase 3 testnet log and adjusted as needed.

    Plan §4 requires (at minimum): equity, margins, balances, greeks_total,
    liquidation_ratio_map, ts_utc, schema_v.
    """
    d = _get_subscription_data(msg)
    if d is None:
        return None

    equity = _f(d, "equity")
    if equity is None:
        log.warning("portfolio malformed: missing equity: %s", list(d.keys()))
        return None

    out = {
        "currency": d.get("currency"),
        "equity": equity,
        "balance": _f(d, "balance"),
        "available_funds": _f(d, "available_funds"),
        "margin_balance": _f(d, "margin_balance"),
        "maintenance_margin": _f(d, "maintenance_margin"),
        "initial_margin": _f(d, "initial_margin"),
        "total_pl": _f(d, "total_pl"),
        "session_upl": _f(d, "session_upl"),
        "session_rpl": _f(d, "session_rpl"),
        "greeks_total": {
            "delta": _f(d, "delta_total"),
            "gamma": _f(d, "options_gamma"),
            "theta": _f(d, "options_theta"),
            "vega": _f(d, "options_vega"),
        },
    }
    # Optional liquidation ratio map (not always present in payload).
    lrm = d.get("liquidation_ratio_map")
    if isinstance(lrm, dict):
        out["liquidation_ratio_map"] = lrm
    return _envelope(channel, "account", out)


def normalize_perp_ticker(
    channel: str, msg: dict[str, Any]
) -> Optional[NormalizedResult]:
    """ticker.BTC-PERPETUAL.100ms  → app.market

    Emits the perp-specific subset of the market topic (mark, funding, IV).
    Co-exists with `normalize_index_price` on `app.market`; consumers merge by
    accumulating known fields (different fetched_at per source).
    """
    d = _get_subscription_data(msg)
    if d is None:
        return None
    mark_price = _f(d, "mark_price")
    if mark_price is None:
        return None
    return _envelope(
        channel,
        "market",
        {
            "perp_mark": mark_price,
            "perp_index": _f(d, "index_price"),
            "perp_last": _f(d, "last_price"),
            "perp_bid": _f(d, "best_bid_price"),
            "perp_ask": _f(d, "best_ask_price"),
            "perp_bid_size": _f(d, "best_bid_amount"),
            "perp_ask_size": _f(d, "best_ask_amount"),
            "perp_open_interest": _f(d, "open_interest"),
            "perp_funding_8h": _f(d, "funding_8h"),
            "perp_current_funding": _f(d, "current_funding"),
            "perp_iv": _f(d, "mark_iv"),
            "perp_state": d.get("state"),
            "perp_ts_ms": int(_f(d, "timestamp") or 0) or None,
            "perp_instrument": d.get("instrument_name"),
        },
    )


def normalize_user_changes(
    channel: str, msg: dict[str, Any]
) -> Optional[NormalizedResult]:
    """user.changes.{future|option}.BTC.raw  → app.positions

    The channel emits incremental "changes" - each message contains:
      * `instrument_name`
      * `trades` (list of trade dicts, may be empty)
      * `positions` (list of position dicts, may be empty)
      * `orders` (list of order dicts, may be empty)
    We expose all four; downstream consumers (incl. SQLite mirror state cache)
    decide what to do.
    """
    d = _get_subscription_data(msg)
    if d is None:
        return None
    instrument = d.get("instrument_name")
    if not instrument:
        return None
    return _envelope(
        channel,
        "positions",
        {
            "instrument_name": instrument,
            "kind": "future" if "future" in channel else "option" if "option" in channel else None,
            "trades": d.get("trades") or [],
            "positions": d.get("positions") or [],
            "orders": d.get("orders") or [],
        },
    )


def normalize_mmp_trigger(
    channel: str, msg: dict[str, Any]
) -> Optional[NormalizedResult]:
    """user.mmp_trigger.{index_name}  → app.alerts.mmp"""
    d = _get_subscription_data(msg)
    if d is None:
        return None
    return _envelope(
        channel,
        "alerts.mmp",
        {
            "index_name": d.get("index_name"),
            "frozen_until_ms": int(_f(d, "frozen_until") or 0),
            "mmp_group": d.get("mmp_group"),
            "block_rfq": bool(d.get("block_rfq", False)),
        },
    )


def normalize_user_lock(
    channel: str, msg: dict[str, Any]
) -> Optional[NormalizedResult]:
    """user.lock  → app.alerts.lock"""
    d = _get_subscription_data(msg)
    if d is None:
        return None
    if "locked" not in d:
        return None
    return _envelope(
        channel,
        "alerts.lock",
        {
            "currency": d.get("currency"),
            "locked": bool(d.get("locked")),
        },
    )


# ---------------------------------------------------------------------------
# Dispatch
# ---------------------------------------------------------------------------

# Channels handled by exact match.
_EXACT: dict[str, ChannelNormalizer] = {
    "deribit_price_index.btc_usd": normalize_index_price,
    "deribit_volatility_index.btc_usd": normalize_volatility_index,
    "user.portfolio.btc": normalize_user_portfolio,
    "user.portfolio.usdt": normalize_user_portfolio,
    "user.portfolio.usdc": normalize_user_portfolio,
    "ticker.BTC-PERPETUAL.100ms": normalize_perp_ticker,
    "user.changes.future.BTC.raw": normalize_user_changes,
    "user.changes.option.BTC.raw": normalize_user_changes,
    "user.mmp_trigger.btc_usd": normalize_mmp_trigger,
    "user.lock": normalize_user_lock,
}


def normalize(channel: str, msg: dict[str, Any]) -> Optional[NormalizedResult]:
    """Dispatch to the right normalizer for `channel`.

    Returns None if no normalizer is registered or the payload is malformed.
    Callers should still publish the raw message either way.
    """
    fn = _EXACT.get(channel)
    if fn is None:
        return None
    try:
        return fn(channel, msg)
    except Exception as e:
        log.exception("normalizer %s crashed: %s", channel, e)
        return None
