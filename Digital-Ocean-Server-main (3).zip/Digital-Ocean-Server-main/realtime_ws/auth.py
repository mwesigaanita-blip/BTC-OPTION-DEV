"""Deribit WS auth: client_credentials flow + token refresh.

# Pattern adapted from realtime/_deribit.py:_access_token on 2026-05-10.
# Original is sync HTTP; this is async over an open WS connection.
# Modify here only - do not re-sync from origin.

Deribit's auth model on WebSocket:
  - Send `public/auth` with grant_type=client_credentials over the ws.
  - Server replies with access_token, refresh_token, expires_in (seconds).
  - For private channels, include `access_token` on `private/subscribe`.
  - To refresh: send `public/auth` with grant_type=refresh_token + refresh_token.
  - If a private call ever returns error code 13009 (invalid_token), the token
    is dead - we drop the connection and reconnect+reauth from scratch.

Env vars (mainnet):  DERIBIT_CLIENT_ID, DERIBIT_CLIENT_SECRET
Env vars (testnet):  DERIBIT_TEST_CLIENT_ID, DERIBIT_TEST_CLIENT_SECRET
"""
from __future__ import annotations

import json
import logging
import os
import time
from dataclasses import dataclass, field
from typing import Optional

log = logging.getLogger("realtime_ws.auth")

INVALID_TOKEN_CODE = 13009  # also 13004 in some old Deribit responses
REFRESH_LEAD_S = 15.0  # refresh this many seconds before expiry


class AuthError(RuntimeError):
    pass


@dataclass
class Credentials:
    client_id: str
    client_secret: str
    testnet: bool

    @staticmethod
    def from_env(*, testnet: bool) -> "Credentials":
        if testnet:
            cid = os.getenv("DERIBIT_TEST_CLIENT_ID", "").strip()
            sec = os.getenv("DERIBIT_TEST_CLIENT_SECRET", "").strip()
            label = "DERIBIT_TEST_CLIENT_ID / DERIBIT_TEST_CLIENT_SECRET"
        else:
            cid = os.getenv("DERIBIT_CLIENT_ID", "").strip()
            sec = os.getenv("DERIBIT_CLIENT_SECRET", "").strip()
            label = "DERIBIT_CLIENT_ID / DERIBIT_CLIENT_SECRET"
        if not cid or not sec:
            raise AuthError(f"missing {label} in env")
        return Credentials(client_id=cid, client_secret=sec, testnet=testnet)


@dataclass
class TokenState:
    access_token: str = ""
    refresh_token: str = ""
    expires_at: float = 0.0  # absolute epoch seconds

    def is_valid(self, *, now: Optional[float] = None) -> bool:
        t = now if now is not None else time.time()
        return bool(self.access_token) and t < (self.expires_at - REFRESH_LEAD_S)

    def time_until_refresh(self, *, now: Optional[float] = None) -> float:
        t = now if now is not None else time.time()
        return max(0.0, (self.expires_at - REFRESH_LEAD_S) - t)


def is_invalid_token_error(rpc_error: dict) -> bool:
    """Inspect a Deribit JSON-RPC error object for the invalid-token signal."""
    if not rpc_error:
        return False
    code = rpc_error.get("code")
    msg = str(rpc_error.get("message", "") or "").lower()
    return code == INVALID_TOKEN_CODE or code == 13004 or "invalid_token" in msg


def build_auth_client_credentials(rpc_id: int, creds: Credentials) -> str:
    return json.dumps(
        {
            "jsonrpc": "2.0",
            "id": rpc_id,
            "method": "public/auth",
            "params": {
                "grant_type": "client_credentials",
                "client_id": creds.client_id,
                "client_secret": creds.client_secret,
            },
        }
    )


def build_auth_refresh(rpc_id: int, refresh_token: str) -> str:
    return json.dumps(
        {
            "jsonrpc": "2.0",
            "id": rpc_id,
            "method": "public/auth",
            "params": {
                "grant_type": "refresh_token",
                "refresh_token": refresh_token,
            },
        }
    )


def parse_auth_result(result: dict) -> TokenState:
    access = str(result.get("access_token", "") or "")
    refresh = str(result.get("refresh_token", "") or "")
    ttl = float(result.get("expires_in", 0) or 0)
    if not access or ttl <= 0:
        raise AuthError(f"auth result missing access_token/expires_in: {result!r}")
    return TokenState(
        access_token=access,
        refresh_token=refresh,
        expires_at=time.time() + ttl,
    )
