"""Live reader for the WS→Redis latest-snapshot keys.

The WS collector (`realtime_ws`) keeps the latest state in three Redis keys via
`realtime_ws.snapshot_cache`:
  * `app.account.latest`   → {"BTC": {...}, "USDT": {...}, "USDC": {...}}
  * `app.market.latest`    → merged index + perp ticker fields
  * `app.positions.latest` → list of raw Deribit position dicts

This module reads those keys and reshapes them so the Streamlit dashboard gets
the **same dict shapes** it already consumes from the SQLite snapshot path
(`shared.data_service.get_account_today` / `get_positions_today`). The page can
therefore swap data sources without changing its display code.

Each getter returns `(data, fetched_at_iso)`. If the key is missing, malformed
or stale (older than `STALE_AFTER_S`), it returns `(None, None)` so the page can
fall back / show a staleness banner.
"""
from __future__ import annotations

import json
import logging
import os
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple

import redis as _redis

from shared.data_service import (
    assemble_account_payload,
    compute_account_greeks_from_positions,
    get_account_today,
)

log = logging.getLogger(__name__)

ACCOUNT_KEY = "app.account.latest"
MARKET_KEY = "app.market.latest"
POSITIONS_KEY = "app.positions.latest"

STALE_AFTER_S = float(os.getenv("REDIS_LIVE_STALE_AFTER_S", "30"))
"""A snapshot older than this (by its `fetched_at`) is treated as unavailable."""

_MONTHS = {"JAN": 1, "FEB": 2, "MAR": 3, "APR": 4, "MAY": 5, "JUN": 6,
           "JUL": 7, "AUG": 8, "SEP": 9, "OCT": 10, "NOV": 11, "DEC": 12}

_client: Optional[_redis.Redis] = None


def _redis_url() -> str:
    # REDIS_LIVE_URL lets a local dev run point at localhost while the
    # collector keeps its docker-network REDIS_URL ("redis://redis:6379/0").
    return (
        os.getenv("REDIS_LIVE_URL")
        or os.getenv("REDIS_URL")
        or "redis://localhost:6379/0"
    )


def get_client() -> _redis.Redis:
    """Lazily build a shared sync Redis client (decoded responses)."""
    global _client
    if _client is None:
        _client = _redis.from_url(
            _redis_url(), decode_responses=True,
            socket_timeout=2.0, socket_connect_timeout=2.0,
        )
    return _client


# ---------------------------------------------------------------------------
# Envelope handling
# ---------------------------------------------------------------------------

def _f(x: Any, default: float = 0.0) -> float:
    try:
        return float(x) if x is not None else default
    except (TypeError, ValueError):
        return default


def _read_envelope(key: str) -> Tuple[Optional[Any], Optional[str]]:
    """GET a snapshot key, validate the envelope + staleness.

    Returns `(data, fetched_at)` or `(None, None)`.
    """
    try:
        raw = get_client().get(key)
    except Exception as e:
        log.warning("redis_live: GET %s failed: %s", key, e)
        return None, None
    if not raw:
        return None, None
    try:
        env = json.loads(raw)
    except Exception:
        log.warning("redis_live: %s holds non-JSON", key)
        return None, None
    fetched_at = env.get("fetched_at")
    if _age_seconds(fetched_at) > STALE_AFTER_S:
        return None, None
    return env.get("data"), fetched_at


def _age_seconds(fetched_at: Optional[str]) -> float:
    """Seconds since `fetched_at` (ISO-8601). Returns +inf if unparseable."""
    if not fetched_at:
        return float("inf")
    try:
        ts = datetime.fromisoformat(str(fetched_at).replace("Z", "+00:00"))
        if ts.tzinfo is None:
            ts = ts.replace(tzinfo=timezone.utc)
        return (datetime.now(timezone.utc) - ts).total_seconds()
    except Exception:
        return float("inf")


# ---------------------------------------------------------------------------
# Market
# ---------------------------------------------------------------------------

def get_market_live() -> Tuple[Optional[Dict[str, Any]], Optional[str]]:
    """Latest merged market state (`btc_index`, `perp_*`). Never raises."""
    try:
        data, fetched_at = _read_envelope(MARKET_KEY)
        if not isinstance(data, dict):
            return None, None
        return data, fetched_at
    except Exception:
        log.exception("get_market_live failed")
        return None, None


def _btc_index_price() -> float:
    market, _ = get_market_live()
    if market:
        return _f(market.get("btc_index") or market.get("perp_index"))
    return 0.0


# ---------------------------------------------------------------------------
# Account
# ---------------------------------------------------------------------------

def _ws_account_to_per_currency(
    ws_account: Dict[str, Any], btc_index: float
) -> Dict[str, Any]:
    """Convert WS per-currency portfolio payloads into `fetch_account_capital`
    shape, so `assemble_account_payload` produces the canonical payload."""
    per_currency: Dict[str, Any] = {}
    for cur, d in (ws_account or {}).items():
        if not isinstance(d, dict):
            continue
        cur = str(cur).upper()
        # USDT/USDC are quoted ~1:1 with USD; only BTC needs the index.
        index_price = btc_index if cur == "BTC" else 1.0
        eq = _f(d.get("equity"))
        avail = _f(d.get("available_funds"))
        im = _f(d.get("initial_margin"))
        mm = _f(d.get("maintenance_margin"))
        mb = _f(d.get("margin_balance"))
        gt = d.get("greeks_total") or {}
        theta_btc = _f(gt.get("theta"))
        is_equity_valid = (cur == "BTC" and eq > 0)
        per_currency[cur] = {
            "currency": cur,
            "balance": _f(d.get("balance")),
            "equity": eq,
            "available_funds": avail,
            "initial_margin": im,
            "maintenance_margin": mm,
            "margin_balance": mb,
            "index_price_usd": index_price,
            "equity_usd": eq * index_price,
            "available_funds_usd": avail * index_price,
            "capital_basis": "equity",
            "capital_usd": eq * index_price,
            "im_pct_of_equity": (im / eq * 100.0) if is_equity_valid else None,
            "mm_pct_of_equity": (mm / eq * 100.0) if is_equity_valid else None,
            "im_pct_of_mb": (im / mb * 100.0) if mb > 0 else None,
            "mm_pct_of_mb": (mm / mb * 100.0) if mb > 0 else None,
            "portfolio_vega": _f(gt.get("vega")),
            "theta_btc": theta_btc,
            "theta_usd": theta_btc * index_price,
            "net_delta_btc": _f(gt.get("delta")),
        }
    return per_currency


def get_account_live() -> Tuple[Optional[Dict[str, Any]], Optional[str]]:
    """Latest account payload, shaped identically to
    `data_service.get_account_today()`'s payload (per_currency, greeks,
    total_equity_usd, …). `btc_changes` is left empty - that ROC block has no
    WS source and stays on the SQLite path. Never raises."""
    try:
        data, fetched_at = _read_envelope(ACCOUNT_KEY)
        if not isinstance(data, dict) or not data:
            return None, None
        btc_index = _btc_index_price()
        per_currency = _ws_account_to_per_currency(data, btc_index)
        if not per_currency:
            return None, None
        positions, _ = get_positions_live()
        greeks = compute_account_greeks_from_positions(positions or [])
        # The BTC rate-of-change block has no WS source (it is computed from
        # TradingView candles by the REST refresh worker). Carry it from the
        # latest SQLite account snapshot so the ROC strip still renders.
        # DVOL works the same way; the live DVOL tick (when present on
        # app.market.latest) overrides the snapshot's index_value.
        btc_changes: Dict[str, Any] = {}
        dvol_changes: Dict[str, Any] = {}
        try:
            snap, _ = get_account_today()
            if isinstance(snap, dict):
                btc_changes = snap.get("btc_changes") or {}
                dvol_changes = dict(snap.get("dvol_changes") or {})
        except Exception:
            log.warning("get_account_live: could not load btc/dvol changes from snapshot")
        # Prefer the live DVOL tick when the WS collector has one.
        market, _ = get_market_live()
        if market and market.get("dvol") is not None:
            dvol_changes["index_value"] = _f(market.get("dvol"))
        payload = assemble_account_payload(
            per_currency, greeks, btc_changes=btc_changes, dvol_changes=dvol_changes
        )
        return payload, fetched_at
    except Exception:
        log.exception("get_account_live failed")
        return None, None


def get_account_greeks_live() -> Tuple[Dict[str, float], Optional[str]]:
    """Portfolio greeks computed from the live position book - same shape as
    `data_service.get_account_greeks_today()`. Never raises."""
    try:
        positions, fetched_at = get_positions_live()
        return compute_account_greeks_from_positions(positions or []), fetched_at
    except Exception:
        log.exception("get_account_greeks_live failed")
        return {}, None


# ---------------------------------------------------------------------------
# Positions
# ---------------------------------------------------------------------------

def _parse_instrument(name: str) -> Optional[Dict[str, Any]]:
    """`BTC-26DEC25-100000-C` → {strike, expiry, type}. None for perp/future."""
    parts = (name or "").split("-")
    if len(parts) != 4:
        return None
    _sym, exp_str, strike_str, typ = parts
    if typ not in ("C", "P") or len(exp_str) < 6:
        return None
    try:
        day = int(exp_str[:-5])
        month = _MONTHS.get(exp_str[-5:-2].upper())
        year = 2000 + int(exp_str[-2:])
        if month is None:
            return None
        expiry = datetime(year, month, day, 8, 0, 0, tzinfo=timezone.utc)
        return {"strike": float(strike_str), "expiry": expiry, "type": typ}
    except (ValueError, KeyError):
        return None


def _ws_position_to_record(raw: Dict[str, Any], btc_index: float) -> Dict[str, Any]:
    """Reshape a raw Deribit position into the enriched record shape the
    Account Overview Positions tab expects (`get_positions_today()` shape)."""
    name = str(raw.get("instrument_name") or "")
    kind = str(raw.get("kind") or "").lower()
    size = _f(raw.get("size"))
    direction = str(raw.get("direction") or "").lower()
    if not direction:
        direction = "buy" if size >= 0 else "sell"
    side = "buy" if direction == "buy" else "sell"

    avg_btc = _f(raw.get("average_price"))
    avg_usd = _f(raw.get("average_price_usd"))
    mark = _f(raw.get("mark_price"))
    index_price = _f(raw.get("index_price")) or btc_index
    pnl_btc = _f(raw.get("total_profit_loss"))
    pnl_usd = pnl_btc * index_price if index_price else 0.0
    mark_usd = mark * index_price if kind == "option" else mark

    # ROI %: PnL over the position's cost basis. For options that's
    # premium × contracts; for a perp/future `size` is the USD notional.
    if kind == "option":
        cost_usd = abs(avg_usd * abs(size))
    else:
        cost_usd = abs(size)
    pnl_pct = (pnl_usd / cost_usd * 100.0) if cost_usd else None

    rec: Dict[str, Any] = {
        "instrument_name": name,
        "kind": kind,
        "direction": direction,
        "side": side,
        "size": size,
        "qty": abs(size),
        "avg_price_btc": avg_btc,
        "avg_price_usd": avg_usd,
        "mark_price_btc": mark,
        "mark_usd": mark_usd,
        "index_price": index_price,
        "total_profit_loss": pnl_btc,
        "floating_profit_loss": _f(raw.get("floating_profit_loss")),
        "realized_profit_loss": _f(raw.get("realized_profit_loss")),
        "pnl_btc_total_deribit": pnl_btc,
        "pnl_usd_total": pnl_usd,
        "pnl_usd_total_deribit": pnl_usd,
        "pnl_pct": pnl_pct,
        "delta": _f(raw.get("delta")),
        "gamma": _f(raw.get("gamma")),
        "theta": _f(raw.get("theta")),
        "vega": _f(raw.get("vega")),
        "initial_margin": _f(raw.get("initial_margin")),
        "maintenance_margin": _f(raw.get("maintenance_margin")),
    }
    parsed = _parse_instrument(name)
    if parsed is not None:
        rec["strike"] = parsed["strike"]
        rec["expiration"] = parsed["expiry"].isoformat()
        rec["expiry"] = rec["expiration"]
        dte = (parsed["expiry"] - datetime.now(timezone.utc)).total_seconds() / 86400.0
        rec["DTE"] = round(dte, 4)
    return rec


def get_raw_positions_live() -> Tuple[Optional[List[Dict[str, Any]]], Optional[str]]:
    """Latest position book as the **raw Deribit position dicts** (untouched).

    Unlike `get_positions_live()` (which reshapes into the enriched dashboard
    record), this returns the raw dicts straight from `app.positions.latest`.
    The stress / PnL engine (`run_scenario`) needs the raw fields - `mark_price`
    (to imply IV for Black-Scholes), `size`, `direction`, greeks - which the
    enriched records rename away. Never raises."""
    try:
        data, fetched_at = _read_envelope(POSITIONS_KEY)
        if not isinstance(data, list):
            return None, None
        raw = [p for p in data if isinstance(p, dict) and p.get("instrument_name")]
        return raw, fetched_at
    except Exception:
        log.exception("get_raw_positions_live failed")
        return None, None


def get_positions_live() -> Tuple[Optional[List[Dict[str, Any]]], Optional[str]]:
    """Latest position book, shaped like `data_service.get_positions_today()`.
    Returns `(None, None)` when the snapshot is missing/stale. Never raises;
    a single malformed position is skipped rather than failing the whole list.
    """
    try:
        data, fetched_at = _read_envelope(POSITIONS_KEY)
        if not isinstance(data, list):
            return None, None
        btc_index = _btc_index_price()
        records: List[Dict[str, Any]] = []
        for p in data:
            if not isinstance(p, dict) or not p.get("instrument_name"):
                continue
            try:
                records.append(_ws_position_to_record(p, btc_index))
            except Exception:
                log.warning("skipping malformed position: %s", p.get("instrument_name"))
        return records, fetched_at
    except Exception:
        log.exception("get_positions_live failed")
        return None, None
