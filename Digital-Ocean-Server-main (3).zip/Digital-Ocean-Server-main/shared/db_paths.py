"""Central registry for SQLite database paths.

All modules that talk to SQLite should import the relevant ``*_DB`` Path
constant from this module instead of hard-coding ``btc_trading.sqlite``
or building their own path. This is the **only** place that knows where
the data files live.

Resolution order for the data directory (first match wins):

1. ``DB_BASE_DIR`` env var (script-specific override; matches
   ``scripts/migrate_split_databases.py``).
2. ``DATA_DIR`` env var (used by the rest of the app - see
   ``multi_agent_system/config.py``). On the server this points at
   ``/opt/btc_app/data``.
3. ``<project_root>/data`` (local default).

``PROJECT_ROOT`` itself can be overridden via the ``PROJECT_ROOT`` env
var; otherwise it is computed from this file's location.

The ``data/`` directory is created on import so a fresh checkout works
without any manual setup.
"""
from __future__ import annotations

import os
import sqlite3
from pathlib import Path
from typing import Any

# ---------------------------------------------------------------------------
# Root resolution
# ---------------------------------------------------------------------------

PROJECT_ROOT: Path = Path(
    os.getenv("PROJECT_ROOT", str(Path(__file__).resolve().parents[1]))
).resolve()


def _resolve_data_dir() -> Path:
    for var in ("DB_BASE_DIR", "DATA_DIR"):
        value = os.environ.get(var)
        if value:
            return Path(value).expanduser().resolve()
    return (PROJECT_ROOT / "data").resolve()


DATA_DIR: Path = _resolve_data_dir()
DATA_DIR.mkdir(parents=True, exist_ok=True)


# ---------------------------------------------------------------------------
# DB paths
# ---------------------------------------------------------------------------

# Legacy monolith. Kept so callers that have not been migrated yet (DB
# management scripts, Streamlit pages, etc.) continue to work. New code
# should NOT reference this constant.
BTC_TRADING_DB: Path = DATA_DIR / "btc_trading.sqlite"

TRADING_DB:        Path = DATA_DIR / "trading.sqlite"
SNAPSHOTS_DB:      Path = DATA_DIR / "snapshots.sqlite"
MARKET_DATA_DB:    Path = DATA_DIR / "market_data.sqlite"
HEDGE_ENGINE_DB:   Path = DATA_DIR / "hedge_engine.sqlite"
MODELS_DB:         Path = DATA_DIR / "models.sqlite"
INFRA_DB:          Path = DATA_DIR / "infra.sqlite"
AUTH_DB:           Path = DATA_DIR / "auth.sqlite"
DECISION_BOARD_DB: Path = DATA_DIR / "decision_board.sqlite"
REALTIME_DB:       Path = DATA_DIR / "realtime.sqlite"
PORTFOLIO_ANALYSIS_DB: Path = DATA_DIR / "portfolio_analysis.sqlite"


# Convenience: ``shared.db_paths.ALL_DBS`` lets tests / health checks
# iterate over every domain DB without having to enumerate them again.
ALL_DBS: dict[str, Path] = {
    "trading":            TRADING_DB,
    "snapshots":          SNAPSHOTS_DB,
    "market_data":        MARKET_DATA_DB,
    "hedge_engine":       HEDGE_ENGINE_DB,
    "models":              MODELS_DB,
    "infra":               INFRA_DB,
    "auth":                AUTH_DB,
    "decision_board":     DECISION_BOARD_DB,
    "realtime":           REALTIME_DB,
    "portfolio_analysis": PORTFOLIO_ANALYSIS_DB,
}


# ---------------------------------------------------------------------------
# Helper: connection factory
# ---------------------------------------------------------------------------


def get_connection(db_path: Path | str, **kwargs: Any) -> sqlite3.Connection:
    """Open a SQLite connection to ``db_path``.

    Thin wrapper that:

    - Casts ``Path`` to ``str`` (sqlite3 accepts both, but the cast
      avoids surprises with older versions).
    - Sets ``row_factory`` to :class:`sqlite3.Row` so callers get
      dict-style row access by default. Callers can still override.
    - Forwards ``**kwargs`` to :func:`sqlite3.connect` (e.g.
      ``timeout``, ``check_same_thread``).

    This is offered as a convenience for new code. Existing modules that
    already have their own ``_connect()`` / ``get_conn()`` helpers can
    keep them - they should just use the right ``*_DB`` constant from
    this module.
    """
    conn = sqlite3.connect(str(db_path), **kwargs)
    conn.row_factory = sqlite3.Row
    return conn


__all__ = [
    "PROJECT_ROOT",
    "DATA_DIR",
    "BTC_TRADING_DB",
    "TRADING_DB",
    "SNAPSHOTS_DB",
    "MARKET_DATA_DB",
    "HEDGE_ENGINE_DB",
    "MODELS_DB",
    "INFRA_DB",
    "AUTH_DB",
    "DECISION_BOARD_DB",
    "REALTIME_DB",
    "PORTFOLIO_ANALYSIS_DB",
    "ALL_DBS",
    "get_connection",
]
