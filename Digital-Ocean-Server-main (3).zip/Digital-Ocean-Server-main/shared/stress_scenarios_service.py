"""Dashboard service: orchestrate + persist BTC option stress scenarios.

Wraps the pure-math `analysis.stress_scenarios` tool with:
  1. Live data fetch (positions + cross-margin account + spot).
  2. Daily snapshot persistence in `PORTFOLIO_ANALYSIS_DB`.
  3. Cheap read helpers for the Streamlit page (no Deribit calls).

The Streamlit page calls `get_stress_today()` first (instant, DB-only). If
nothing's saved for today it calls `compute_and_save_stress()` once (8–10s
including Deribit round-trips and per-instrument BS imply-IV).

Persistence pattern mirrors `shared/data_service.py`:
  - One row per UTC date (`date_key` PRIMARY KEY upsert).
  - Flat scalar columns for ad-hoc SQL filtering / future trend views.
  - Full `stress_scenarios()` output preserved as a JSON blob.
"""

from __future__ import annotations

import json
import logging
import sqlite3
import time
from datetime import datetime, timezone
from typing import Any, Optional

from shared.db_paths import PORTFOLIO_ANALYSIS_DB

# Stress tool + data fetchers it depends on.
from portfolio_analysis_AI_Agent.tools.analysis.stress_scenarios import (
    _classify_severity,
    _parse_option_name,
    _position_pnl_at_expiry,
    stress_scenarios,
    run_scenario,
)
from portfolio_analysis_AI_Agent.tools.datafetch.positions.get_positions import get_positions
from portfolio_analysis_AI_Agent.tools.datafetch.account.get_account_summaries import (
    get_account_summaries,
)
from portfolio_analysis_AI_Agent.tools.datafetch.market.get_index_price import get_index_price

log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# SQLite connection + schema
# ---------------------------------------------------------------------------


def _connect_portfolio_analysis() -> sqlite3.Connection:
    """Connection to `PORTFOLIO_ANALYSIS_DB` with WAL + Row factory.

    Mirrors `data_service._connect_snapshots` (line 52–58) so behavior
    matches the rest of the dashboard's snapshot infrastructure.
    """
    conn = sqlite3.connect(str(PORTFOLIO_ANALYSIS_DB), check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL;")
    conn.execute("PRAGMA synchronous=NORMAL;")
    return conn


def _utc_date() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%d")


def _utc_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")


_DDL = """
CREATE TABLE IF NOT EXISTS stress_scenarios_daily (
    date_key            TEXT PRIMARY KEY,
    snapshot_ts         TEXT NOT NULL,
    spot_usd            REAL,
    equity_usd          REAL,
    position_count      INTEGER,
    scenario_count      INTEGER,
    worst_scenario_name TEXT,
    worst_loss_pct      REAL,
    best_gain_pct       REAL,
    severity_safe       INTEGER,
    severity_warning    INTEGER,
    severity_dangerous  INTEGER,
    severity_critical   INTEGER,
    payload_json        TEXT NOT NULL
)
"""


def _ensure_table() -> None:
    """Idempotent table creation. Cheap; called from every public function."""
    with _connect_portfolio_analysis() as conn:
        conn.execute(_DDL)
        conn.commit()


# ---------------------------------------------------------------------------
# Compute + persist
# ---------------------------------------------------------------------------


def _build_row(payload: dict) -> dict[str, Any]:
    """Flatten the `stress_scenarios()` payload into the DB row's scalar columns."""
    summary = payload.get("summary") or {}
    severity = summary.get("severity_counts") or {}
    worst = summary.get("worst_loss") or {}
    best = summary.get("best_gain") or {}
    ctx = payload.get("context") or {}

    return {
        "snapshot_ts": _utc_iso(),
        "spot_usd": ctx.get("btc_index_price"),
        "equity_usd": ctx.get("equity_usd"),
        "position_count": ctx.get("position_count"),
        "scenario_count": ctx.get("scenario_count"),
        "worst_scenario_name": worst.get("name") if worst else None,
        "worst_loss_pct": worst.get("pnl_pct_equity") if worst else None,
        "best_gain_pct": best.get("pnl_pct_equity") if best else None,
        "severity_safe": severity.get("SAFE", 0),
        "severity_warning": severity.get("WARNING", 0),
        "severity_dangerous": severity.get("DANGEROUS", 0),
        "severity_critical": severity.get("CRITICAL", 0),
    }


def _upsert(payload: dict) -> str:
    """Insert (or replace) today's row. Returns the `date_key` written."""
    _ensure_table()
    day = _utc_date()
    flat = _build_row(payload)
    cols = (
        "date_key, snapshot_ts, spot_usd, equity_usd, position_count, "
        "scenario_count, worst_scenario_name, worst_loss_pct, best_gain_pct, "
        "severity_safe, severity_warning, severity_dangerous, severity_critical, "
        "payload_json"
    )
    placeholders = ",".join(["?"] * 14)
    sql = (
        f"INSERT INTO stress_scenarios_daily ({cols}) VALUES ({placeholders}) "
        f"ON CONFLICT(date_key) DO UPDATE SET "
        f"snapshot_ts=excluded.snapshot_ts, "
        f"spot_usd=excluded.spot_usd, "
        f"equity_usd=excluded.equity_usd, "
        f"position_count=excluded.position_count, "
        f"scenario_count=excluded.scenario_count, "
        f"worst_scenario_name=excluded.worst_scenario_name, "
        f"worst_loss_pct=excluded.worst_loss_pct, "
        f"best_gain_pct=excluded.best_gain_pct, "
        f"severity_safe=excluded.severity_safe, "
        f"severity_warning=excluded.severity_warning, "
        f"severity_dangerous=excluded.severity_dangerous, "
        f"severity_critical=excluded.severity_critical, "
        f"payload_json=excluded.payload_json"
    )
    params = (
        day,
        flat["snapshot_ts"],
        flat["spot_usd"],
        flat["equity_usd"],
        flat["position_count"],
        flat["scenario_count"],
        flat["worst_scenario_name"],
        flat["worst_loss_pct"],
        flat["best_gain_pct"],
        flat["severity_safe"],
        flat["severity_warning"],
        flat["severity_dangerous"],
        flat["severity_critical"],
        json.dumps(payload, ensure_ascii=False, default=str),
    )
    with _connect_portfolio_analysis() as conn:
        conn.execute(sql, params)
        conn.commit()
    return day


def compute_and_save_stress() -> dict:
    """Pull live data, run all stress scenarios, persist, return the result.

    This is the heavy call (~8–10 s). Callers that just want today's
    cached result should use `get_stress_today()` instead.
    """
    log.info("compute_and_save_stress: fetching live data...")
    pos = get_positions()
    summary = get_account_summaries()
    spot = float(get_index_price()["index_price"])
    equity_btc = float(summary.get("equity") or 0.0)

    # Prefer cross-margin total. Fall back to BTC-only × spot.
    equity_usd = summary.get("total_equity_usd")
    if not equity_usd:
        equity_usd = equity_btc * spot if (equity_btc and spot) else None

    out = stress_scenarios(
        positions=pos["positions"],
        btc_index_price=spot,
        equity_usd=equity_usd,
    )

    # Stash the inputs we used so the page can show "computed against
    # X positions / $Y equity" without re-deriving from the payload.
    out.setdefault("context", {})
    out["context"]["equity_btc"] = equity_btc
    out["context"]["cross_totals_source"] = summary.get("cross_totals_source")
    out["context"]["currencies_aggregated"] = list(
        (summary.get("cross_totals_factors") or {}).keys()
    )

    day = _upsert(out)
    log.info("compute_and_save_stress: saved snapshot for %s", day)
    return out


# ---------------------------------------------------------------------------
# Readers (no API calls)
# ---------------------------------------------------------------------------


def _row_to_payload(row: sqlite3.Row | None) -> Optional[dict]:
    if row is None:
        return None
    try:
        payload = json.loads(row["payload_json"])
    except Exception:
        log.exception("Failed to decode stress payload_json for %s", row["date_key"])
        return None
    # Attach the snapshot timestamp so the UI can show "Computed N minutes ago".
    payload.setdefault("_meta", {})
    payload["_meta"]["date_key"] = row["date_key"]
    payload["_meta"]["snapshot_ts"] = row["snapshot_ts"]
    return payload


def get_stress_today() -> Optional[dict]:
    """Return today's stress snapshot, or None if not computed yet today."""
    _ensure_table()
    day = _utc_date()
    with _connect_portfolio_analysis() as conn:
        row = conn.execute(
            "SELECT date_key, snapshot_ts, payload_json "
            "FROM stress_scenarios_daily WHERE date_key=?",
            (day,),
        ).fetchone()
    return _row_to_payload(row)


def get_stress_latest() -> Optional[dict]:
    """Return the most recent snapshot regardless of date. Useful when
    the page opens on a fresh day before the first compute has run -
    we can still show yesterday's data while the new one is fetched."""
    _ensure_table()
    with _connect_portfolio_analysis() as conn:
        row = conn.execute(
            "SELECT date_key, snapshot_ts, payload_json "
            "FROM stress_scenarios_daily ORDER BY date_key DESC LIMIT 1"
        ).fetchone()
    return _row_to_payload(row)


def run_custom_scenario(
    btc_pct: float = 0.0,
    iv_points: float = 0.0,
    days_forward: int = 0,
) -> dict:
    """Run a single ad-hoc scenario against live data. Not persisted.

    Each invocation re-fetches positions / account / spot from Deribit so
    the custom scenario always reflects the current portfolio state.
    Returns `{scenario, context}` - `scenario` matches the per-scenario
    shape from `stress_scenarios()`.
    """
    log.info(
        "run_custom_scenario: btc_pct=%+g iv_points=%+g days_forward=%d",
        btc_pct, iv_points, days_forward,
    )
    pos = get_positions()
    summary = get_account_summaries()
    spot = float(get_index_price()["index_price"])
    equity_btc = float(summary.get("equity") or 0.0)
    equity_usd = summary.get("total_equity_usd")
    if not equity_usd:
        equity_usd = equity_btc * spot if (equity_btc and spot) else None

    scenario = run_scenario(
        positions=pos["positions"],
        btc_index_price=spot,
        btc_pct=btc_pct,
        iv_points=iv_points,
        days_forward=days_forward,
        equity_usd=equity_usd,
    )
    return {
        "scenario": scenario,
        "context": {
            "btc_index_price": spot,
            "equity_usd": equity_usd,
            "equity_btc": equity_btc,
            "position_count": pos["count"],
            "cross_totals_source": summary.get("cross_totals_source"),
            "currencies_aggregated": list(
                (summary.get("cross_totals_factors") or {}).keys()
            ),
        },
    }


def _zero_crossings(points: list[dict], spot_tol: float) -> list[float]:
    """BTC prices where a curve's `pnl_usd` crosses zero (linear interpolation),
    de-duplicated within `spot_tol`. `points` are dicts with btc_price/pnl_usd."""
    raw: list[float] = []
    for a, b in zip(points, points[1:]):
        y0, y1 = a["pnl_usd"], b["pnl_usd"]
        if y0 == 0.0:
            raw.append(a["btc_price"])
        elif (y0 < 0.0) != (y1 < 0.0) and (y1 - y0) != 0.0:
            t = -y0 / (y1 - y0)
            raw.append(round(a["btc_price"] + t * (b["btc_price"] - a["btc_price"]), 2))
    out: list[float] = []
    for be in raw:
        if not any(abs(be - kept) <= spot_tol for kept in out):
            out.append(be)
    return out


def build_hypothetical_option(
    option_type: str,
    expiry: Any,
    strike: float,
    side: str = "buy",
    size: float = 1.0,
    iv_pct: float = 60.0,
) -> dict:
    """Build a raw-position-shaped dict for a hypothetical Deribit option.

    Lets `run_pnl_curve(extra_positions=[...])` price a position the user is
    considering opening. `option_type` is "C"/"P"; `expiry` a date/datetime;
    `strike` in USD; `side` "buy"/"sell"; `size` in contracts; `iv_pct` the
    implied vol in percent - mandatory, since a synthetic option carries no
    `mark_price` for the engine to imply IV from.
    """
    opt = "C" if str(option_type).upper().startswith("C") else "P"
    name = (
        f"BTC-{expiry.strftime('%d%b%y').upper()}"
        f"-{int(round(float(strike)))}-{opt}"
    )
    direction = "sell" if str(side).lower().startswith("s") else "buy"
    return {
        "instrument_name": name,
        "kind": "option",
        "size": abs(float(size)),
        "direction": direction,
        "mark_iv": float(iv_pct),
    }


def run_pnl_curve(
    pct_min: float = -25.0,
    pct_max: float = 25.0,
    points: int = 121,
    iv_points: float = 0.0,
    days_forward: float = 0.0,
    positions: Optional[list[dict]] = None,
    spot: Optional[float] = None,
    equity_usd: Optional[float] = None,
    extra_positions: Optional[list[dict]] = None,
    with_greeks: bool = False,
    eval_price: Optional[float] = None,
    annual_rate_shift_bps: float = 0.0,
    iv_pct_shift: float = 0.0,
) -> dict:
    """Sweep a PnL payoff curve across a range of BTC % moves.

    Reprices the whole book at each of `points` evenly-spaced BTC % shocks via
    `run_scenario` - a portfolio payoff curve plus a per-position breakdown
    (`legs`). Not persisted.

    Data source:
      - If `positions` + `spot` are passed (the live WS path) they are used
        directly - no Deribit REST call. `equity_usd` should be passed too
        (used for the % axis); if omitted the % values are None.
      - If omitted, positions / account / spot are fetched once from Deribit
        REST (back-compat).

    `extra_positions` are hypothetical positions (e.g. from
    `build_hypothetical_option`) added to the book for what-if curves.

    Returns `{context, curve, break_even, legs}`:
      - `curve`     : list of {btc_pct, btc_price, pnl_usd, pnl_pct, severity}
      - `break_even`: BTC prices where total PnL crosses zero (interpolated)
      - `legs`      : per-position {instrument_name, kind, is_hypothetical,
                      curve:[{btc_price,pnl_usd}], pnl_at_spot, break_even}
    """
    points = max(2, int(points))
    if pct_max < pct_min:
        pct_min, pct_max = pct_max, pct_min

    r = float(annual_rate_shift_bps) / 10_000.0

    log.info(
        "run_pnl_curve: pct=[%+g,%+g] points=%d iv_pts=%+g iv_pct=%+g days=%g r_bps=%+g injected=%s extra=%d",
        pct_min, pct_max, points, iv_points, iv_pct_shift, days_forward,
        annual_rate_shift_bps,
        positions is not None, len(extra_positions or []),
    )

    # ---- Resolve data: injected (WS) or fetched (REST back-compat) ----------
    equity_btc: Optional[float] = None
    if positions is not None and spot is not None:
        real_positions = list(positions)
        spot = float(spot)
    else:
        pos = get_positions()
        summary = get_account_summaries()
        spot = float(get_index_price()["index_price"])
        equity_btc = float(summary.get("equity") or 0.0)
        real_positions = list(pos["positions"])
        if equity_usd is None:
            equity_usd = summary.get("total_equity_usd")
            if not equity_usd:
                equity_usd = equity_btc * spot if (equity_btc and spot) else None

    extra_positions = list(extra_positions or [])
    all_positions = real_positions + extra_positions
    hypo_names = {str(p.get("instrument_name") or "") for p in extra_positions}

    # Per-position absolute-PnL anchors. Deribit reports `total_profit_loss`
    # per position in BTC; convert to USD at spot. `run_scenario` returns only
    # the *change* caused by a shock, so the anchor pins each curve onto the
    # real current PnL. Hypothetical positions have no PnL yet → anchor 0.
    anchor_by_inst: dict[str, float] = {}
    current_pnl_usd = 0.0
    for p in real_positions:
        name = str(p.get("instrument_name") or "")
        a = float(p.get("total_profit_loss") or 0.0) * spot
        anchor_by_inst[name] = anchor_by_inst.get(name, 0.0) + a
        current_pnl_usd += a

    # Single shared timestamp so every point ages consistently.
    now_ms = int(time.time() * 1000)
    step = (pct_max - pct_min) / (points - 1)

    legs_kind: dict[str, str] = {}
    for p in all_positions:
        legs_kind.setdefault(
            str(p.get("instrument_name") or ""), str(p.get("kind") or "")
        )

    curve: list[dict] = []
    legs_pnl: dict[str, list[float]] = {name: [] for name in legs_kind}
    legs_size: dict[str, float] = {}
    # Per-leg, per-curve-point BS-priced mark (USD). At the eval index we
    # expose this to the frontend so the Custom What-If's positions table
    # can show the *scenario* mark instead of the live Deribit quote.
    legs_new_price_usd: dict[str, list[float]] = {name: [] for name in legs_kind}
    # Parallel "static expiration" sweep - intrinsic-only payoff per leg.
    # Independent of iv_points / days_forward / r so the dashed line on the
    # frontend stays put when those sliders move; only the underlying
    # position list / overrides / hypotheticals change it.
    expiration_curve: list[dict] = []
    legs_expiration_pnl: dict[str, list[float]] = {name: [] for name in legs_kind}
    for i in range(points):
        btc_pct = pct_min + i * step
        sc = run_scenario(
            positions=all_positions,
            btc_index_price=spot,
            btc_pct=btc_pct,
            iv_points=iv_points,
            days_forward=days_forward,
            equity_usd=equity_usd,
            now_ms=now_ms,
            r=r,
            iv_pct_shift=iv_pct_shift,
        )
        abs_pnl = current_pnl_usd + float(sc["pnl_usd"] or 0.0)
        abs_pct = (abs_pnl / equity_usd * 100.0) if equity_usd else None
        curve.append({
            "btc_pct": round(btc_pct, 4),
            "btc_price": sc["new_btc_index_price"],
            "pnl_usd": round(abs_pnl, 2),
            "pnl_pct": round(abs_pct, 4) if abs_pct is not None else None,
            "severity": sc["severity"],
        })
        # Per-position: sum scenario-delta rows by instrument, add the anchor.
        point_pnl: dict[str, float] = {}
        point_new_price: dict[str, float] = {}
        for row in sc.get("positions") or []:
            name = str(row.get("instrument_name") or "")
            point_pnl[name] = point_pnl.get(name, 0.0) + float(row.get("pnl_usd") or 0.0)
            legs_size[name] = float(row.get("size") or 0.0)
            # `new_price_usd` is the per-contract BS-priced mark for this leg
            # at the current scenario point. run_scenario emits it for every
            # leg that's been priced (options + futures). Use the last value
            # if multiple rows share an instrument (shouldn't happen in
            # practice but stay defensive).
            np_usd = row.get("new_price_usd")
            if np_usd is not None:
                point_new_price[name] = float(np_usd)
        for name in legs_kind:
            legs_pnl[name].append(
                round(anchor_by_inst.get(name, 0.0) + point_pnl.get(name, 0.0), 2)
            )
            legs_new_price_usd[name].append(
                float(point_new_price.get(name, 0.0))
            )

        # ---- Static expiration sweep -------------------------------------
        new_S = spot * (1.0 + btc_pct / 100.0)
        exp_total = 0.0
        exp_pnl: dict[str, float] = {}
        for p in all_positions:
            row = _position_pnl_at_expiry(p, spot, new_S, now_ms)
            n = str(row.get("instrument_name") or "")
            v = float(row.get("pnl_usd") or 0.0)
            exp_pnl[n] = exp_pnl.get(n, 0.0) + v
            exp_total += v
        abs_exp_pnl = current_pnl_usd + exp_total
        abs_exp_pct = (abs_exp_pnl / equity_usd * 100.0) if equity_usd else None
        expiration_curve.append({
            "btc_pct": round(btc_pct, 4),
            "btc_price": round(new_S, 2),
            "pnl_usd": round(abs_exp_pnl, 2),
            "pnl_pct": round(abs_exp_pct, 4) if abs_exp_pct is not None else None,
            "severity": _classify_severity(
                round(abs_exp_pct, 4) if abs_exp_pct is not None else None
            ),
        })
        for name in legs_kind:
            legs_expiration_pnl[name].append(
                round(anchor_by_inst.get(name, 0.0) + exp_pnl.get(name, 0.0), 2)
            )

    spot_tol = spot * 0.005
    break_even = _zero_crossings(curve, spot_tol)

    # Evaluation point for greeks + `pnl_at_spot`: the curve point nearest
    # `eval_price` (the frozen/selected price), or the live spot by default.
    # Pricing/IV/anchor always use `spot` (live) - only the evaluation index
    # shifts - so a frozen-BTC scenario keeps correct implied vols.
    eval_target = float(eval_price) if eval_price and eval_price > 0 else spot
    spot_idx = min(
        range(points), key=lambda i: abs(curve[i]["btc_price"] - eval_target)
    )

    # ---- Optional per-leg greeks (finite-difference on the curve) -----------
    # delta/gamma are the 1st/2nd derivative of each leg's PnL curve at the
    # centre; theta/vega come from two extra scenarios at the centre price.
    # Keeping greeks per-leg lets the frontend re-sum them on include/exclude
    # without a recompute.
    leg_greeks: dict[str, dict] = {}
    if with_greeks and points >= 3:
        si = min(max(spot_idx, 1), points - 2)
        h = curve[si + 1]["btc_price"] - curve[si]["btc_price"]
        h2 = curve[si + 1]["btc_price"] - curve[si - 1]["btc_price"]
        centre_pct = curve[si]["btc_pct"]
        try:
            sc_t = run_scenario(
                positions=all_positions, btc_index_price=spot,
                btc_pct=centre_pct, iv_points=iv_points,
                days_forward=float(days_forward) + 1.0,
                equity_usd=equity_usd, now_ms=now_ms, r=r,
                iv_pct_shift=iv_pct_shift,
            )
            sc_v = run_scenario(
                positions=all_positions, btc_index_price=spot,
                btc_pct=centre_pct, iv_points=iv_points + 1.0,
                days_forward=float(days_forward),
                equity_usd=equity_usd, now_ms=now_ms, r=r,
                iv_pct_shift=iv_pct_shift,
            )
        except Exception:
            sc_t = sc_v = None
        theta_raw: dict[str, float] = {}
        vega_raw: dict[str, float] = {}
        for row in (sc_t or {}).get("positions") or []:
            n = str(row.get("instrument_name") or "")
            theta_raw[n] = theta_raw.get(n, 0.0) + float(row.get("pnl_usd") or 0.0)
        for row in (sc_v or {}).get("positions") or []:
            n = str(row.get("instrument_name") or "")
            vega_raw[n] = vega_raw.get(n, 0.0) + float(row.get("pnl_usd") or 0.0)
        for name, pnl_list in legs_pnl.items():
            centre_sc = pnl_list[si] - anchor_by_inst.get(name, 0.0)
            delta = (pnl_list[si + 1] - pnl_list[si - 1]) / h2 if h2 else 0.0
            gamma = (
                (pnl_list[si + 1] - 2 * pnl_list[si] + pnl_list[si - 1]) / (h * h)
                if h else 0.0
            )
            theta = (theta_raw.get(name, centre_sc) - centre_sc) if sc_t else 0.0
            vega = (vega_raw.get(name, centre_sc) - centre_sc) if sc_v else 0.0
            leg_greeks[name] = {
                "delta": round(delta, 6),
                "gamma": round(gamma, 9),
                "theta": round(theta, 2),
                "vega": round(vega, 2),
            }

    legs: list[dict] = []
    eval_btc_price = float(curve[spot_idx]["btc_price"]) if curve else 0.0
    for name, pnl_list in legs_pnl.items():
        leg_points = [
            {"btc_price": curve[i]["btc_price"], "pnl_usd": pnl_list[i]}
            for i in range(points)
        ]
        # BS-priced mark at the evaluation point. `new_price_usd` is per
        # contract in USD; the BTC-native mark Deribit shows is the USD
        # price divided by the scenario's BTC index.
        mark_usd_at_eval = (
            legs_new_price_usd.get(name, [])[spot_idx]
            if legs_new_price_usd.get(name)
            else 0.0
        )
        mark_btc_at_eval = (
            mark_usd_at_eval / eval_btc_price if eval_btc_price > 0 else 0.0
        )
        exp_pnl_list = legs_expiration_pnl.get(name, [0.0] * points)
        exp_leg_points = [
            {"btc_price": curve[i]["btc_price"], "pnl_usd": exp_pnl_list[i]}
            for i in range(points)
        ]
        parsed_name = _parse_option_name(name)
        leg: dict = {
            "instrument_name": name,
            "kind": legs_kind.get(name, ""),
            "size": legs_size.get(name, 0.0),
            "is_hypothetical": name in hypo_names,
            "curve": leg_points,
            "expiration_curve": exp_leg_points,
            "pnl_at_spot": pnl_list[spot_idx],
            "break_even": _zero_crossings(leg_points, spot_tol),
            "mark_price_usd": round(mark_usd_at_eval, 4),
            "mark_price_btc": round(mark_btc_at_eval, 8),
            "expiry_ms": parsed_name["expiry_ms"] if parsed_name else None,
        }
        if with_greeks:
            leg["greeks"] = leg_greeks.get(
                name, {"delta": 0.0, "gamma": 0.0, "theta": 0.0, "vega": 0.0}
            )
        legs.append(leg)
    legs.sort(key=lambda L: -abs(L["pnl_at_spot"]))

    return {
        "context": {
            "btc_index_price": spot,
            "equity_usd": equity_usd,
            "equity_btc": equity_btc,
            "position_count": len(real_positions),
            "hypothetical_count": len(extra_positions),
            "current_pnl_usd": round(current_pnl_usd, 2),
            "iv_points": iv_points,
            "iv_pct_shift": float(iv_pct_shift),
            "days_forward": float(days_forward),
            "annual_rate_shift_bps": float(annual_rate_shift_bps),
        },
        "curve": curve,
        "expiration_curve": expiration_curve,
        "break_even": break_even,
        "legs": legs,
    }


def list_stress_history(limit: int = 30) -> list[dict]:
    """Light reader for a future trend view. Returns the flat scalar
    columns only (no payload) for the last `limit` snapshots, newest first."""
    _ensure_table()
    with _connect_portfolio_analysis() as conn:
        rows = conn.execute(
            "SELECT date_key, snapshot_ts, spot_usd, equity_usd, "
            "position_count, worst_scenario_name, worst_loss_pct, best_gain_pct, "
            "severity_safe, severity_warning, severity_dangerous, severity_critical "
            "FROM stress_scenarios_daily ORDER BY date_key DESC LIMIT ?",
            (int(limit),),
        ).fetchall()
    return [dict(r) for r in rows]


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    out = compute_and_save_stress()
    print(f"equity_usd  = ${out['context']['equity_usd']:,.2f}")
    print(f"worst loss  = {out['summary']['worst_loss']}")
    print(f"severity    = {out['summary']['severity_counts']}")
    print(f"DB row      = {_utc_date()}")


# Run from Digital-Ocean-Server:
#   python -m shared.stress_scenarios_service
