# shared\data_service.py
import os, sys, time, json, threading, traceback, sqlite3
from typing import Optional, Dict, Any, Tuple, List
import numpy as np
import pandas as pd
import streamlit as st
from datetime import datetime, timezone
import base64
import io
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
# deployment/data_service.py
import os, sys, time, threading, traceback
from typing import Optional, Dict, Any
import logging

import streamlit as st
import requests
import math
import numpy as np
from typing import Any, Dict, List
# --- repo root on sys.path (deployment/ -> project root) ---
REPO_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if REPO_ROOT not in sys.path:
    sys.path.insert(0, REPO_ROOT)

# --- ALSO add the package dir itself, because btc_options.py does `from config import *`
PKG_DIR = os.path.join(REPO_ROOT, "multi_agent_system")
if PKG_DIR not in sys.path:
    sys.path.insert(0, PKG_DIR)
# Where we store snapshots
 

# Your own fetchers (no Streamlit inside them!)
from multi_agent_system.config import *  # noqa: F401,F403  (keep for non-DB constants)
from multi_agent_system.btc_options import fetch_current_deribit_positions
from .forecast_service import refresh_forecast_message
from shared.db_paths import SNAPSHOTS_DB, TRADING_DB, MARKET_DATA_DB

print(f"[DB] Using SNAPSHOTS_DB={SNAPSHOTS_DB}, TRADING_DB={TRADING_DB}, "
      f"MARKET_DATA_DB={MARKET_DATA_DB} in {__file__}", flush=True)

# Backward-compat alias for any external code that still imports
# ``DB_PATH`` from this module. Points at the snapshots DB (the
# historical primary domain of this file).
DB_PATH = SNAPSHOTS_DB

# -----------------------------
# SQLite helpers
# -----------------------------
def _connect_snapshots():
    """Connection to ``SNAPSHOTS_DB`` (account/positions/vol/worker_status)."""
    conn = sqlite3.connect(str(SNAPSHOTS_DB), check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL;")
    conn.execute("PRAGMA synchronous=NORMAL;")
    return conn


def _connect_trading():
    """Connection to ``TRADING_DB`` (trade_log)."""
    conn = sqlite3.connect(str(TRADING_DB), check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL;")
    conn.execute("PRAGMA synchronous=NORMAL;")
    return conn


def _connect_market():
    """Connection to ``MARKET_DATA_DB`` (btc_prices)."""
    conn = sqlite3.connect(str(MARKET_DATA_DB), check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL;")
    conn.execute("PRAGMA synchronous=NORMAL;")
    return conn


# Backward-compat: ``_connect()`` historically returned the (single) DB
# this module managed. Default it to the snapshots DB.
_connect = _connect_snapshots


def _utc_date() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%d")

def _utc_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")

def _ensure_snapshots_db():
    """Ensure snapshot tables exist in ``SNAPSHOTS_DB``."""
    with sqlite3.connect(str(SNAPSHOTS_DB)) as conn:
        cur = conn.cursor()
        cur.execute("""
        CREATE TABLE IF NOT EXISTS account_snapshots (
            date TEXT PRIMARY KEY,                 -- UTC day, e.g. 2025-09-29
            payload_json TEXT NOT NULL,            -- JSON dict from fetch_account_capital
            updated_at TEXT NOT NULL               -- UTC ISO timestamp
        )
        """)
        cur.execute("""
        CREATE TABLE IF NOT EXISTS positions_snapshots (
            date TEXT PRIMARY KEY,                 -- UTC day
            payload_json TEXT NOT NULL,            -- JSON array of positions (records)
            updated_at TEXT NOT NULL               -- UTC ISO timestamp
        )
        """)
        cur.execute("""
        CREATE TABLE IF NOT EXISTS vol_metrics_snapshots (
            date TEXT PRIMARY KEY,                 -- UTC day
            payload_json TEXT NOT NULL,            -- JSON dict: IV/HV metrics + config
            images_json  TEXT NOT NULL,            -- JSON dict: base64 PNGs (smile/surface/skew)
            updated_at   TEXT NOT NULL             -- UTC ISO timestamp
        )
        """)
        conn.execute("""
        CREATE TABLE IF NOT EXISTS worker_status (
        id INTEGER PRIMARY KEY CHECK (id = 1),
        updated_at_utc TEXT NOT NULL,
        payload_json TEXT NOT NULL
        )
        """)


def _ensure_trading_db():
    """Ensure trade-related tables exist in ``TRADING_DB``."""
    with sqlite3.connect(str(TRADING_DB)) as conn:
        cur = conn.cursor()
        cur.execute("""
        CREATE TABLE IF NOT EXISTS trade_log (
            trade_id        TEXT PRIMARY KEY,
            timestamp_ms    INTEGER NOT NULL,
            trade_date      TEXT NOT NULL,
            instrument_name TEXT NOT NULL,
            side            TEXT NOT NULL,
            amount          REAL,
            price           REAL,
            index_price     REAL,
            commission      REAL,
            info            TEXT,
            is_liquidation  INTEGER NOT NULL DEFAULT 0,
            raw_json        TEXT,
            inserted_at_utc TEXT NOT NULL,
            comments        TEXT NOT NULL DEFAULT ''
        )
        """)
        # Add comments column to existing tables that were created before this column existed
        try:
            cur.execute("ALTER TABLE trade_log ADD COLUMN comments TEXT NOT NULL DEFAULT ''")
        except Exception:
            pass


def _ensure_db():
    """Backward-compat wrapper that ensures every domain DB this module
    talks to has its tables in place."""
    _ensure_snapshots_db()
    _ensure_trading_db()


def _upsert_account(payload: Dict[str, Any]) -> None:
    _ensure_db()
    day = _utc_date()
    ts  = _utc_iso()
    with sqlite3.connect(str(SNAPSHOTS_DB)) as conn:
        conn.execute(
            "INSERT INTO account_snapshots(date, payload_json, updated_at) VALUES(?,?,?) "
            "ON CONFLICT(date) DO UPDATE SET payload_json=excluded.payload_json, updated_at=excluded.updated_at",
            (day, json.dumps(payload, ensure_ascii=False), ts),
        )
        conn.commit()

def _upsert_vol_metrics(payload: Dict[str, Any], images_b64: Dict[str, str]) -> None:
    _ensure_db()
    day = _utc_date()
    ts  = _utc_iso()
    with sqlite3.connect(str(SNAPSHOTS_DB)) as conn:
        conn.execute(
            """
            INSERT INTO vol_metrics_snapshots(date, payload_json, images_json, updated_at)
            VALUES(?,?,?,?)
            ON CONFLICT(date) DO UPDATE SET
              payload_json=excluded.payload_json,
              images_json =excluded.images_json,
              updated_at  =excluded.updated_at
            """,
            (day, json.dumps(payload, ensure_ascii=False), json.dumps(images_b64, ensure_ascii=False), ts),
        )
        conn.commit()

def read_vol_metrics_from_db(day: Optional[str] = None) -> Tuple[Optional[Dict[str, Any]], Optional[Dict[str, str]], Optional[str]]:
    _ensure_db()
    day = day or _utc_date()
    with sqlite3.connect(str(SNAPSHOTS_DB)) as conn:
        cur = conn.execute("SELECT payload_json, images_json, updated_at FROM vol_metrics_snapshots WHERE date=?", (day,))
        row = cur.fetchone()
        if not row:
            return None, None, None
        payload_json, images_json, updated_at = row
        try:
            payload = json.loads(payload_json)
        except Exception:
            payload = None
        try:
            images = json.loads(images_json)
        except Exception:
            images = None
        return payload, images, updated_at

def get_vol_metrics_today() -> Tuple[Optional[Dict[str, Any]], Optional[Dict[str, str]], Optional[str]]:
    return read_vol_metrics_from_db()

# ---- JSON-safe conversion helpers ----


def _df_to_json_records(df: pd.DataFrame) -> list[dict]:
    """Return list[dict] safe for json.dumps (no Timestamp/NaN/np types)."""
    if df is None or df.empty:
        return []

    df2 = df.copy()

    # 1) Datetime -> UTC ISO8601 strings
    for col in df2.columns:
        if pd.api.types.is_datetime64_any_dtype(df2[col]):
            s = df2[col]
            try:
                tz = getattr(s.dtype, "tz", None)
                if tz is None:
                    s = s.dt.tz_localize("UTC")
                else:
                    s = s.dt.tz_convert("UTC")
                df2[col] = s.dt.strftime("%Y-%m-%dT%H:%M:%SZ")
            except Exception:
                # fallback: plain string
                df2[col] = s.astype(str)

    # 2) Replace NaN/NaT with None (JSON null)
    df2 = df2.where(pd.notnull(df2), None)

    # 3) NumPy scalars -> native Python types
    def _to_py(x):
        if isinstance(x, (np.integer, np.int32, np.int64)):
            return int(x)
        if isinstance(x, (np.floating, np.float32, np.float64)):
            return float(x)
        if isinstance(x, (np.bool_,)):
            return bool(x)
        return x

    df2 = df2.applymap(_to_py)

    return df2.to_dict(orient="records")


def _upsert_positions(df) -> None:
    """df is a pandas DataFrame of positions. We store records as JSON array."""
    _ensure_db()
    day = _utc_date()
    ts  = _utc_iso()

    # Normalize to list[dict]
    if df is None:
        records = []
    else:
        try:
            records = _df_to_json_records(df)
        except Exception:
            records = []

    with sqlite3.connect(str(SNAPSHOTS_DB)) as conn:
        cur = conn.cursor()
        cur.execute("""
            INSERT INTO positions_snapshots(date, payload_json, updated_at)
            VALUES (?, ?, ?)
            ON CONFLICT(date) DO UPDATE SET
              payload_json = excluded.payload_json,
              updated_at   = excluded.updated_at
        """, (day, json.dumps(records, ensure_ascii=False), ts))
        conn.commit()


def read_account_from_db(day: Optional[str] = None) -> Tuple[Optional[Dict[str, Any]], Optional[str]]:
    """Return (payload_dict, updated_at) for given UTC date or today if None."""
    _ensure_db()
    day = day or _utc_date()
    with sqlite3.connect(str(SNAPSHOTS_DB)) as conn:
        cur = conn.execute("SELECT payload_json, updated_at FROM account_snapshots WHERE date=?", (day,))
        row = cur.fetchone()
        if not row:
            return None, None
        payload_json, updated_at = row
        try:
            payload = json.loads(payload_json)
        except Exception:
            payload = None
        return payload, updated_at

def read_positions_from_db(day: Optional[str] = None) -> Tuple[List[Dict[str, Any]], Optional[str]]:
    """Return (records_list, updated_at) for given UTC date or today if None."""
    _ensure_db()
    day = day or _utc_date()
    with sqlite3.connect(str(SNAPSHOTS_DB)) as conn:
        cur = conn.execute("SELECT payload_json, updated_at FROM positions_snapshots WHERE date=?", (day,))
        row = cur.fetchone()
        if not row:
            return [], None
        payload_json, updated_at = row
        try:
            records = json.loads(payload_json)
        except Exception:
            records = []
        return records, updated_at


def _safe_call(fn, *args, **kwargs):
    try:
        return fn(*args, **kwargs), None
    except Exception as e:
        return None, f"{e}\n{traceback.format_exc()}"

def _fetch_btc_tv_candles(
    resolution: str = "5",          # 5-minute candles
    lookback_hours: int = 24,
) -> Tuple[Optional[Dict[str, Any]], Optional[str]]:
    """
    Fetch BTC-PERPETUAL TradingView candles from Deribit for the last `lookback_hours`.
    resolution: string in minutes ('1','3','5',...,'720') or '1D'
    """
    import requests
    now_ms = int(time.time() * 1000)
    start_ts_ms = now_ms - lookback_hours * 3600 * 1000

    url = "https://www.deribit.com/api/v2/public/get_tradingview_chart_data"
    params = {
        "instrument_name": "BTC-PERPETUAL",
        "resolution": resolution,       # <-- STRING, e.g. "5"
        "start_timestamp": start_ts_ms,
        "end_timestamp": now_ms,
    }

    try:
        resp = requests.get(url, params=params, timeout=10)
        resp.raise_for_status()
        data = resp.json()
        result = data.get("result") or {}
        if result.get("status") != "ok":
            return None, f"tv_status={result.get('status')}"
        return result, None
    except Exception as e:
        return None, str(e)


def _fetch_dvol_history(
    currency: str = "BTC",
    resolution: str = "60",          # seconds → 1-min candles
    lookback_hours: int = 36,
) -> Tuple[Optional[Dict[str, Any]], Optional[str]]:
    """Fetch Deribit DVOL history via `public/get_volatility_index_data`.

    Returns a TradingView-like dict {ticks: [...ms], close: [...]} so the same
    ROC helper that handles BTC candles can consume it.

    Deribit response shape:
      result.data = [[timestamp_ms, open, high, low, close], ...]
    """
    import requests
    now_ms = int(time.time() * 1000)
    start_ts_ms = now_ms - lookback_hours * 3600 * 1000

    url = "https://www.deribit.com/api/v2/public/get_volatility_index_data"
    params = {
        "currency": currency,
        "start_timestamp": start_ts_ms,
        "end_timestamp": now_ms,
        "resolution": resolution,
    }
    try:
        resp = requests.get(url, params=params, timeout=10)
        resp.raise_for_status()
        result = (resp.json() or {}).get("result") or {}
        rows = result.get("data") or []
        if not isinstance(rows, list) or not rows:
            return None, "dvol_empty"
        ticks = [int(r[0]) for r in rows if isinstance(r, list) and len(r) >= 5]
        closes = [float(r[4]) for r in rows if isinstance(r, list) and len(r) >= 5]
        if not ticks or len(ticks) != len(closes):
            return None, "dvol_malformed"
        return {"ticks": ticks, "close": closes}, None
    except Exception as e:
        return None, str(e)


def _compute_dvol_rate_of_change(dvol_result: Dict[str, Any]) -> Dict[str, Any]:
    """DVOL analogue of `_compute_btc_rate_of_change`.

    Returns:
      {"index_value": <latest dvol>, "roc_pct": {"15m","30m","1h","12h","1d"}}
    """
    base = _compute_btc_rate_of_change(dvol_result)
    if not base:
        return {}
    # Rename `index_price_usd` → `index_value` (DVOL is a vol number, not USD).
    return {
        "index_value": base.get("index_price_usd"),
        "roc_pct": base.get("roc_pct") or {},
    }


def _compute_btc_rate_of_change(tv_result: Dict[str, Any]) -> Dict[str, Any]:
    """
    Given TradingView-style result with ticks + close, compute
    % changes over 15m, 30m, 1h, 12h, 1d.
    Returns:
      {
        "index_price_usd": float,
        "roc_pct": {
            "15m": float|None,
            "30m": float|None,
            "1h":  float|None,
            "12h": float|None,
            "1d":  float|None,
        }
      }
    """
    ticks = tv_result.get("ticks") or []
    closes = tv_result.get("close") or []

    if not ticks or not closes or len(ticks) != len(closes):
        return {}

    # Assume ticks are sorted ascending
    last_ts_ms = int(ticks[-1])
    last_close = float(closes[-1])

    horizons = [
        ("15m", 15 * 60),
        ("30m", 30 * 60),
        ("1h",  60 * 60),
        ("12h", 12 * 60 * 60),
        ("1d",  24 * 60 * 60),
    ]

    roc_pct: Dict[str, Optional[float]] = {}

    for label, seconds in horizons:
        target_ts_ms = last_ts_ms - seconds * 1000

        # Find the last candle whose timestamp <= target_ts_ms
        idx = None
        for i in range(len(ticks) - 1, -1, -1):
            if int(ticks[i]) <= target_ts_ms:
                idx = i
                break

        if idx is None:
            roc_pct[label] = None
            continue

        ref_price = float(closes[idx])
        if ref_price <= 0:
            roc_pct[label] = None
        else:
            roc_pct[label] = (last_close - ref_price) / ref_price * 100.0

    return {
        "index_price_usd": last_close,
        "roc_pct": roc_pct,
    }

def get_status() -> Dict[str, Any]:
    S = _store()
    with S["lock"]:
        return {
            "running": S["thread"] is not None and S["thread"].is_alive(),
            "last_acc_ts": S["last_acc_ts"],
            "last_pos_ts": S["last_pos_ts"],
            "cfg": dict(S["cfg"]),
            "errors": list(S["errors"][-5:]),
            "db_path": DB_PATH,
            "today": _utc_date(),
        }

# Public read API for pages (DB-backed)
def get_account_today() -> Tuple[Optional[Dict[str, Any]], Optional[str]]:
    return read_account_from_db()

def get_positions_today() -> Tuple[List[Dict[str, Any]], Optional[str]]:
    return read_positions_from_db()


def persist_daily_snapshot(
    account_payload: Optional[Dict[str, Any]] = None,
    positions_records: Optional[List[Dict[str, Any]]] = None,
) -> None:
    """Upsert today's account + positions snapshot into SNAPSHOTS_DB.

    Keeps a daily historical row even when the dashboard is fed by the live
    WS→Redis path (which would otherwise bypass the SQLite snapshot tables).
    Idempotent - ``ON CONFLICT(date)`` updates today's row, so repeated calls
    through the day simply keep it current. Empty inputs are skipped so a
    momentary gap in the live feed never overwrites a good snapshot with blanks.
    """
    if account_payload:
        _upsert_account(account_payload)
    if positions_records:
        _upsert_positions(pd.DataFrame(positions_records))

import math

def _finite_float(x, default=0.0) -> float:
    try:
        v = float(x)
        return v if math.isfinite(v) else default
    except Exception:
        return default



def _looks_like_usd_notional(size_f: float, idx_f: float) -> bool:
    """
    Heuristic:
    - If size is much larger than plausible BTC units, it's probably USD notional.
    - Example: size=350000 and idx=80000 -> size/idx ~ 4.3 BTC
    - If size is small like 0.5, 4.35, 10, it's probably BTC.
    """
    if idx_f <= 0:
        return False
    # If size is huge compared to BTC units, treat as USD notional
    return abs(size_f) > 50.0 and abs(size_f) > 2.0 * idx_f * 0.01  # mild guard

def _is_perp_or_future(pos: Dict[str, Any]) -> bool:
    kind = str(pos.get("kind") or "").lower()
    instr = str(pos.get("instrument_name") or pos.get("symbol") or "").upper()
    return bool(pos.get("is_perpetual")) or kind in ("perpetual", "future") or "PERPETUAL" in instr

def compute_account_greeks_from_positions(positions: List[Dict[str, Any]]) -> Dict[str, float]:
    delta_btc = 0.0
    gamma = 0.0
    theta_usd_per_day = 0.0
    vega_usd = 0.0
    vols: List[float] = []

    for pos in positions or []:
        is_linear = _is_perp_or_future(pos)

        if is_linear:
            # ----- PERPETUAL/FUTURE: delta is linear; greeks are ~0 -----
            # Prefer "size" / "qty" / "amount" as the position size
            size_f = _finite_float(pos.get("size", pos.get("qty", pos.get("quantity", pos.get("amount")))), 0.0)

            # If size is unsigned and side/direction exists, apply sign
            # (If your size is already signed, this will still work if side is missing or consistent.)
            side = str(pos.get("side") or pos.get("direction") or "").lower()
            if side in ("sell", "short"):
                size_signed = -abs(size_f)
            elif side in ("buy", "long"):
                size_signed = abs(size_f)
            else:
                size_signed = size_f  # assume already signed or unknown

            # Convert to BTC delta:
            # - If size looks like BTC, delta_btc = size_signed
            # - If size looks like USD notional, delta_btc = size_signed / index_price
            idx_f = _finite_float(pos.get("index_price", pos.get("index_price_usd", pos.get("mark_price_usd"))), 0.0)

            if _looks_like_usd_notional(size_signed, idx_f):
                delta_btc += (size_signed / idx_f) if idx_f > 0 else 0.0
            else:
                delta_btc += size_signed

            # gamma/theta/vega for perps/futures contribute 0 by definition
            # (we still add safe-floats below, but these are usually missing/0 anyway)
        else:
            # ----- OPTIONS: use provided greeks -----
            delta_btc += _finite_float(pos.get("delta"), 0.0)

        # Other greeks: options contribute; perps usually 0/missing (safe-float keeps totals stable)
        gamma += _finite_float(pos.get("gamma"), 0.0)
        theta_usd_per_day += _finite_float(pos.get("theta"), 0.0)
        vega_usd += _finite_float(pos.get("vega"), 0.0)

        iv = pos.get("iv", pos.get("implied_volatility"))
        ivv = _finite_float(iv, default=float("nan"))
        if math.isfinite(ivv):
            vols.append(ivv)

    volatility = float(np.mean(vols)) if vols else 0.0

    # Final safety
    delta_btc = delta_btc if math.isfinite(delta_btc) else 0.0
    gamma     = gamma     if math.isfinite(gamma)     else 0.0
    theta_usd_per_day = theta_usd_per_day if math.isfinite(theta_usd_per_day) else 0.0
    vega_usd  = vega_usd  if math.isfinite(vega_usd)  else 0.0
    volatility = volatility if math.isfinite(volatility) else 0.0

    return {
        "delta_btc": delta_btc,
        "gamma": gamma,
        "theta_usd_per_day": theta_usd_per_day,
        "vega_usd": vega_usd,
        "volatility": volatility,
    }



def get_account_greeks_today() -> Tuple[Dict[str, float], Optional[str]]:
    """
    Convenience wrapper for pages:
      - reads today's positions from SQLite
      - aggregates portfolio Greeks
      - returns (greeks_dict, updated_at_str)
    """
    positions, updated_at = get_positions_today()
    greeks = compute_account_greeks_from_positions(positions or [])
    return greeks, updated_at

def utc_now_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

def utc_now_compact() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")

def ms_to_utc_iso(ms: int) -> str:
    return datetime.fromtimestamp(ms / 1000, tz=timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _fig_to_b64_png(fig) -> str:
    buf = io.BytesIO()
    fig.tight_layout()
    fig.savefig(buf, format="png", dpi=150)
    plt.close(fig)
    return base64.b64encode(buf.getvalue()).decode("ascii")

def _deribit_public_get(path: str, params: dict, base: str = "https://www.deribit.com/api/v2") -> dict:
    # Deribit wants lowercase booleans
    clean_params = {}
    for k, v in (params or {}).items():
        if isinstance(v, bool):
            clean_params[k] = str(v).lower()   # True->"true", False->"false"
        else:
            clean_params[k] = v

    r = requests.get(f"{base}/{path}", params=clean_params, timeout=25)
    r.raise_for_status()
    j = r.json()
    if "result" not in j:
        raise RuntimeError(f"Deribit response missing result: {j}")
    return j["result"]


def _get_spot_index_btc() -> float:
    res = _deribit_public_get("public/get_index_price", {"index_name": "btc_usd"})
    return float(res["index_price"])

def _get_instruments_btc_options() -> list:
    return _deribit_public_get(
        "public/get_instruments",
        {"currency": "BTC", "kind": "option", "expired": False},
    )

############################# BTC Price History from SQLite (for charts and rate-of-change metrics) #############################
def get_btc_prices_latest(limit: int = 20) -> pd.DataFrame:
    """
    Return latest BTC daily rows from btc_prices, newest first.
    """
    with _connect_market() as conn:
        query = """
            SELECT
                date,
                open,
                high,
                low,
                close,
                change,
                percent_change,
                volume
            FROM btc_prices
            ORDER BY date DESC
            LIMIT ?
        """
        return pd.read_sql_query(query, conn, params=(limit,))

def get_btc_prices_full() -> pd.DataFrame:
    """
    Return full BTC price history from btc_prices, newest first.
    """
    with _connect_market() as conn:
        query = """
            SELECT
                date,
                open,
                high,
                low,
                close,
                change,
                percent_change,
                volume
            FROM btc_prices
            ORDER BY date DESC
        """
        return pd.read_sql_query(query, conn)

def get_btc_prices_last_date() -> Optional[str]:
    """
    Return latest available date in btc_prices.
    """
    with _connect_market() as conn:
        row = conn.execute(
            "SELECT MAX(date) AS last_date FROM btc_prices"
        ).fetchone()

    if not row:
        return None

    try:
        return row["last_date"]
    except Exception:
        return row[0] if row and row[0] else None

##########################################################################################################

def _ticker(name: str) -> dict:
    return _deribit_public_get("public/ticker", {"instrument_name": name})

def _get_hv_annualized(days: int = 30) -> float:
    # Uses TradingView candles on BTC-PERPETUAL (daily)
    now = int(time.time() * 1000)
    start = now - int((days + 5) * 24 * 60 * 60 * 1000)
    res = _deribit_public_get(
        "public/get_tradingview_chart_data",
        {
            "instrument_name": "BTC-PERPETUAL",
            "resolution": "1D",
            "start_timestamp": start,
            "end_timestamp": now,
        },
    )
    if (res.get("status") or "").lower() != "ok":
        raise RuntimeError(f"TradingView status not ok: {res.get('status')}")
    closes = np.array(res.get("close") or [], dtype=float)
    if len(closes) < days + 1:
        raise RuntimeError("Not enough candle closes for HV")
    logret = np.diff(np.log(closes[-(days + 1):]))
    sigma = float(np.std(logret, ddof=1))
    hv = sigma * float(np.sqrt(365.0)) * 100.0
    return hv

def _pick_expiry_closest(inst: list, target_days: float) -> Tuple[int, float]:
    now_ms = datetime.now(timezone.utc).timestamp() * 1000.0
    exp_to_dte = {}
    for x in inst:
        exp = int(x["expiration_timestamp"])
        dte = (exp - now_ms) / (1000 * 60 * 60 * 24)
        if dte > 0:
            exp_to_dte[exp] = dte
    exp_ms, dte = min(exp_to_dte.items(), key=lambda kv: abs(kv[1] - target_days))
    return exp_ms, float(dte)

def _subset_by_expiry_and_band(inst: list, expiry_ms: int, spot: float, band=(0.7, 1.3)) -> List[Tuple[float, str]]:
    lo = band[0] * spot
    hi = band[1] * spot
    out = []
    for x in inst:
        if int(x["expiration_timestamp"]) != int(expiry_ms):
            continue
        strike = float(x["strike"])
        if lo <= strike <= hi:
            out.append((strike, x["instrument_name"]))
    out.sort(key=lambda t: t[0])
    return out

def _downsample(items: List[Any], max_n: int) -> List[Any]:
    if len(items) <= max_n:
        return items
    step = max(1, len(items) // max_n)
    return items[::step][:max_n]

def compute_vol_metrics_and_plots(
    *,
    targets_days: List[float] = [15.0, 30.0, 60.0, 120.0],
    smile_band=(0.6, 1.4),
    surface_band=(0.7, 1.3),
    max_tickers_smile: int = 80,
    max_tickers_surface: int = 60,
    sleep_s: float = 0.01,
) -> Tuple[Dict[str, Any], Dict[str, str]]:
    """
    Returns:
      payload dict: {spot, hv_30d_pct, iv_smile_by_tenor{...}, expiry_used{...}, ...}
      images dict (base64 PNG): {"smile_png_b64":..., "surface_png_b64":..., "skew_png_b64":...}
    """
    spot = _get_spot_index_btc()
    inst = _get_instruments_btc_options()

    # --- HV
    hv_30d = _get_hv_annualized(30)

    # --- SMILE multi-expiry (use closest expiry to target)
    smile_series = []
    smile_meta = []
    for td in targets_days:
        expiry_ms, dte = _pick_expiry_closest(inst, td)
        items = _subset_by_expiry_and_band(inst, expiry_ms, spot, band=smile_band)
        sampled = _downsample(items, max_tickers_smile)

        strikes = []
        ivs = []
        for strike, name in sampled:
            try:
                t = _ticker(name)
                iv = t.get("mark_iv")
            except Exception:
                iv = None
            if iv is None:
                continue
            strikes.append(float(strike))
            ivs.append(float(iv))
            if sleep_s:
                time.sleep(sleep_s)

        if len(strikes) < 8:
            continue

        strikes_arr = np.array(strikes)
        iv_arr = np.array(ivs)
        atm_idx = int(np.argmin(np.abs(strikes_arr - spot)))
        smile_series.append((td, dte, strikes_arr, iv_arr))
        smile_meta.append({
            "target_days": td,
            "actual_dte_days": dte,
            "expiry_utc": ms_to_utc_iso(expiry_ms),
            "points": int(len(strikes_arr)),
            "atm_strike": float(strikes_arr[atm_idx]),
            "atm_iv_pct": float(iv_arr[atm_idx]),
            "iv_min": float(np.min(iv_arr)),
            "iv_max": float(np.max(iv_arr)),
            "iv_avg": float(np.mean(iv_arr)),
        })

    # --- Smile plot
    fig1 = plt.figure()
    ax1 = fig1.add_subplot(111)
    for td, dte, strikes_arr, iv_arr in smile_series:
        ax1.plot(strikes_arr, iv_arr, marker=".", label=f"~{int(td)}D (DTE {dte:.1f})")
    ax1.axvline(spot, linestyle="--", linewidth=1)
    ax1.set_title("Volatility Smile (Mark IV% vs Strike)")
    ax1.set_xlabel("Strike")
    ax1.set_ylabel("Mark IV (%)")
    ax1.grid(True, alpha=0.3)
    ax1.legend()

    smile_png_b64 = _fig_to_b64_png(fig1)

    # --- Surface (scatter) from same expiries
    X_days, Y_strike, Z_iv = [], [], []
    surface_meta = []
    for td in targets_days:
        expiry_ms, dte = _pick_expiry_closest(inst, td)
        items = _subset_by_expiry_and_band(inst, expiry_ms, spot, band=surface_band)
        sampled = _downsample(items, max_tickers_surface)

        iv_list = []
        plotted = 0
        for strike, name in sampled:
            t = _ticker(name)
            iv = t.get("mark_iv")
            if iv is None:
                continue
            X_days.append(float(dte))
            Y_strike.append(float(strike))
            Z_iv.append(float(iv))
            iv_list.append(float(iv))
            plotted += 1
            if sleep_s:
                time.sleep(sleep_s)

        if iv_list:
            surface_meta.append({
                "target_days": td,
                "actual_dte_days": dte,
                "expiry_utc": ms_to_utc_iso(expiry_ms),
                "plotted": plotted,
                "iv_min": float(np.min(iv_list)),
                "iv_max": float(np.max(iv_list)),
                "iv_avg": float(np.mean(iv_list)),
            })

    fig2 = plt.figure()
    ax2 = fig2.add_subplot(111, projection="3d")
    ax2.scatter(np.array(X_days), np.array(Y_strike), np.array(Z_iv), s=10)
    ax2.set_title("Volatility Surface (Scatter) - DTE x Strike x IV")
    ax2.set_xlabel("DTE (days)")
    ax2.set_ylabel("Strike")
    ax2.set_zlabel("Mark IV (%)")
    surface_png_b64 = _fig_to_b64_png(fig2)

    # --- Simple skew summary (RR25/BF25 proxy not exact, but useful diagnostic)
    # Here we just chart IV spread between low-strike and high-strike buckets per expiry.
    skew_rows = []
    for td, dte, strikes_arr, iv_arr in smile_series:
        if len(strikes_arr) < 10:
            continue
        q1 = np.quantile(strikes_arr, 0.25)
        q3 = np.quantile(strikes_arr, 0.75)
        low_iv = float(np.mean(iv_arr[strikes_arr <= q1]))
        high_iv = float(np.mean(iv_arr[strikes_arr >= q3]))
        skew_rows.append((td, dte, high_iv - low_iv))

    fig3 = plt.figure()
    ax3 = fig3.add_subplot(111)
    if skew_rows:
        xs = np.arange(len(skew_rows))
        labels = [f"{int(td)}D" for td, _, _ in skew_rows]
        vals = [v for _, _, v in skew_rows]
        ax3.plot(xs, vals, marker="o")
        ax3.set_xticks(xs)
        ax3.set_xticklabels(labels)
    ax3.set_title("Skew Diagnostic (HighStrikeIV - LowStrikeIV)")
    ax3.set_xlabel("Tenor")
    ax3.set_ylabel("Vol points")
    ax3.grid(True, alpha=0.3)
    skew_png_b64 = _fig_to_b64_png(fig3)

    # payload
    payload = {
        "ts_utc": utc_now_iso(),
        "spot_index_usd": float(spot),
        "hv_30d_pct": float(hv_30d),
        "targets_days": targets_days,
        "smile_meta": smile_meta,
        "surface_meta": surface_meta,
    }

    images = {
        "smile_png_b64": smile_png_b64,
        "surface_png_b64": surface_png_b64,
        "skew_png_b64": skew_png_b64,
    }
    return payload, images


def _upsert_worker_status(payload: Dict[str, Any]) -> None:
    with _connect_snapshots() as conn:
        conn.execute("""
        INSERT INTO worker_status (id, updated_at_utc, payload_json)
        VALUES (1, ?, ?)
        ON CONFLICT(id) DO UPDATE SET
          updated_at_utc = excluded.updated_at_utc,
          payload_json   = excluded.payload_json
        """, (_utc_iso(), json.dumps(payload, ensure_ascii=False)))
        conn.commit()

def get_status() -> Dict[str, Any]:
    with _connect_snapshots() as conn:
        row = conn.execute(
            "SELECT updated_at_utc, payload_json FROM worker_status WHERE id=1"
        ).fetchone()

    if not row:
        return {"ok": False, "error": "No worker status written yet"}

    try:
        payload = json.loads(row["payload_json"])
    except Exception:
        payload = {"raw": row["payload_json"]}

    return {
        "ok": True,
        "updated_at_utc": row["updated_at_utc"],
        "payload": payload,
    }

def _calc_total_equity_usd(per_currency: dict) -> float:
    """
    True total account value across currencies:
      sum of equity_usd (or equity * index_price_usd fallback).
    This is what you want for the "equity over time" chart.
    """
    total = 0.0
    if not isinstance(per_currency, dict):
        return 0.0

    for acc in per_currency.values():
        if not isinstance(acc, dict):
            continue

        # Prefer explicit USD
        v = acc.get("equity_usd") or acc.get("capital_usd")
        if v is not None:
            try:
                total += float(v)
                continue
            except Exception:
                pass

        # Fallback: equity * index_price_usd
        eq = acc.get("equity")
        px = acc.get("index_price_usd") or acc.get("index_price") or 1.0
        try:
            total += float(eq or 0.0) * float(px or 1.0)
        except Exception:
            pass

    return float(total)


def _calc_portfolio_margin_balance_usd(per_currency: dict) -> float:
    """
    Cross-margin portfolio margin_balance is effectively portfolio-level and
    appears repeated across currencies. So DO NOT SUM.
    Use MAX(margin_balance * index_price_usd).
    """
    best = 0.0
    if not isinstance(per_currency, dict):
        return 0.0

    for acc in per_currency.values():
        if not isinstance(acc, dict):
            continue

        mb = acc.get("margin_balance")
        px = acc.get("index_price_usd") or acc.get("index_price") or 1.0
        try:
            mb_usd = float(mb or 0.0) * float(px or 1.0)
        except Exception:
            continue

        if mb_usd > best:
            best = mb_usd

    return float(best)


def assemble_account_payload(
    per_currency: Dict[str, Any],
    greeks: Dict[str, Any],
    btc_changes: Optional[Dict[str, Any]] = None,
    dvol_changes: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Build the canonical account payload from per-currency account dicts.

    `per_currency` maps currency → account dict in `fetch_account_capital`
    shape. Shared by the REST refresh path (`refresh_now`) and the live Redis
    path (`shared.redis_live`) so both produce an identical payload shape and
    the dashboard needs no branching.
    """
    per_currency = {k: v for k, v in (per_currency or {}).items() if v is not None}
    # Legacy single-currency view mirrors BTC (or the first available currency).
    legacy = (
        per_currency.get("BTC")
        or next((v for v in per_currency.values() if v), None)
        or {}
    )
    payload: Dict[str, Any] = {
        **legacy,
        "multi_currency": True,
        "per_currency": per_currency,
        "greeks": greeks or {},
        "btc_changes": btc_changes or {},
        "dvol_changes": dvol_changes or {},
    }
    total_equity_usd = _calc_total_equity_usd(per_currency)
    payload["total_equity_usd"] = total_equity_usd
    payload["capital_usd"] = total_equity_usd
    payload["equity_usd"] = total_equity_usd
    payload["portfolio_margin_balance_usd"] = _calc_portfolio_margin_balance_usd(
        per_currency
    )
    return payload


def _to_float(x, default: float = 0.0) -> float:
    try:
        v = float(x)
        if np.isfinite(v):
            return v
        return default
    except Exception:
        return default


def _safe_json_loads(s: str) -> Dict[str, Any]:
    try:
        obj = json.loads(s)
        return obj if isinstance(obj, dict) else {}
    except Exception:
        return {}


def _extract_account_history_row(snapshot_date: str, payload: Dict[str, Any], updated_at: Optional[str]) -> Dict[str, Any]:
    """
    Build one historical row from account_snapshots.payload_json.

    Required output columns:
    Date, EOD Value, Spot Price, % MM, % IM, BTC Amount, USDT Amount, USDC Amount, Total USD (AUM)

    Notes:
    - EOD Value is total account equity expressed in BTC
    - total_equity_usd is preferred for AUM
    - Spot Price uses BTC index_price_usd from per_currency.BTC first
    - %MM / %IM use mm_pct_of_mb / im_pct_of_mb
    """
    per_cur = payload.get("per_currency") or {}

    btc_acc = per_cur.get("BTC") or {}
    usdt_acc = per_cur.get("USDT") or {}
    usdc_acc = per_cur.get("USDC") or {}

    spot_price = _to_float(
        btc_acc.get("index_price_usd")
        or payload.get("btc_changes", {}).get("index_price_usd")
        or payload.get("index_price_usd")
    )

    total_usd_aum = _to_float(payload.get("total_equity_usd") or payload.get("equity_usd") or payload.get("capital_usd"))

    # EOD value in BTC = total USD equity / BTC spot
    eod_value_btc = (total_usd_aum / spot_price) if spot_price > 0 else 0.0

    btc_amount = _to_float(btc_acc.get("equity"))
    usdt_amount = _to_float(usdt_acc.get("equity"))
    usdc_amount = _to_float(usdc_acc.get("equity"))

    mm_pct = _to_float(
        payload.get("mm_pct_of_mb")
        or btc_acc.get("mm_pct_of_mb")
        or usdt_acc.get("mm_pct_of_mb")
        or usdc_acc.get("mm_pct_of_mb")
    )

    im_pct = _to_float(
        payload.get("im_pct_of_mb")
        or btc_acc.get("im_pct_of_mb")
        or usdt_acc.get("im_pct_of_mb")
        or usdc_acc.get("im_pct_of_mb")
    )

    return {
        "Date": snapshot_date,
        "updated_at": updated_at,
        "EOD Value": eod_value_btc,
        "Spot Price": spot_price,
        "% MM": mm_pct,
        "% IM": im_pct,
        "BTC Amount": btc_amount,
        "USDT Amount": usdt_amount,
        "USDC Amount": usdc_amount,
        "Total USD (AUM)": total_usd_aum,
    }


def get_account_equity_history() -> pd.DataFrame:
    """
    Build daily account equity history from account_snapshots.

    Output columns:
    Date
    BOD Value
    EOD Value
    % Change
    Change BTC
    Change $
    Spot Price
    % MM
    % IM
    BTC Amount
    USDT Amount
    USDC Amount
    Total USD (AUM)

    Rules:
    - EOD Value = same-day total equity in BTC
    - BOD Value = previous day's EOD Value
    - Change BTC = EOD - BOD
    - Change $ = current Total USD (AUM) - previous Total USD (AUM)
    - % Change = (EOD - BOD) / BOD * 100
    """
    _ensure_db()

    with _connect_snapshots() as conn:
        df = pd.read_sql_query(
            """
            SELECT date, payload_json, updated_at
            FROM account_snapshots
            ORDER BY date ASC
            """,
            conn,
        )

    if df.empty:
        return pd.DataFrame(columns=[
            "Date",
            "BOD Value",
            "EOD Value",
            "% Change",
            "Change BTC",
            "Change $",
            "Spot Price",
            "% MM",
            "% IM",
            "BTC Amount",
            "USDT Amount",
            "USDC Amount",
            "Total USD (AUM)",
        ])

    rows: List[Dict[str, Any]] = []

    for _, r in df.iterrows():
        payload = _safe_json_loads(r["payload_json"])
        row = _extract_account_history_row(
            snapshot_date=str(r["date"]),
            payload=payload,
            updated_at=r.get("updated_at"),
        )
        rows.append(row)

    out = pd.DataFrame(rows)

    if out.empty:
        return out

    out["Date"] = pd.to_datetime(out["Date"], errors="coerce")
    out = out.sort_values("Date").reset_index(drop=True)

    # Replace zero values with nearest non-zero (forward-fill then back-fill)
    _zero_fill_cols = ["EOD Value", "Spot Price", "BTC Amount", "USDT Amount", "USDC Amount", "Total USD (AUM)"]
    for _col in _zero_fill_cols:
        if _col in out.columns:
            out[_col] = out[_col].replace(0, pd.NA)
            out[_col] = out[_col].ffill().bfill()
            out[_col] = out[_col].fillna(0)

    out["BOD Value"] = out["EOD Value"].shift(1)
    out["Change BTC"] = out["EOD Value"] - out["BOD Value"]
    out["Change $"] = out["Total USD (AUM)"] - out["Total USD (AUM)"].shift(1)

    out["% Change"] = np.where(
        (out["BOD Value"].notna()) & (out["BOD Value"] != 0),
        (out["Change BTC"] / out["BOD Value"]) * 100.0,
        np.nan,
    )

    # keep display date as string
    out["Date"] = out["Date"].dt.strftime("%Y-%m-%d")
    COLUMN_ORDER = [
        "Date",
        "BOD Value",
        "EOD Value",
        "% Change",
        "Change BTC",
        "Change $",
        "Spot Price",
        "% MM",
        "% IM",
        "BTC Amount",
        "USDT Amount",
        "USDC Amount",
        "Total USD (AUM)",
    ]

    out = out[COLUMN_ORDER]
    return out

def get_account_equity_history_latest(limit: int = 20) -> pd.DataFrame:
    df = get_account_equity_history()
    if df.empty:
        return df
    return df.sort_values("Date", ascending=False).head(limit).reset_index(drop=True)


def get_account_equity_history_last_date() -> Optional[str]:
    df = get_account_equity_history()
    if df.empty:
        return None
    return str(df["Date"].iloc[-1])


# ─────────────────────────────────────────────────────────────────────────────
# Trade Log - transaction-log-based persistence
# ─────────────────────────────────────────────────────────────────────────────

def ingest_trade_log(days_back: int = 365, cooldown_minutes: int = 60) -> int:
    """
    Fetch actual trade events from Deribit /private/get_transaction_log and
    persist them in the trade_log table.  Uses INSERT OR IGNORE so it is safe
    to call repeatedly - existing rows are never overwritten.

    Skips the API call if the last ingest was less than cooldown_minutes ago.

    Returns the number of NEW rows inserted, or -1 if skipped (cooldown active).
    """
    _ensure_db()

    # ── Cooldown check: skip API call if recently ingested ────────────
    try:
        with sqlite3.connect(str(TRADING_DB)) as conn:
            row = conn.execute("SELECT MAX(inserted_at_utc) FROM trade_log").fetchone()
        last_inserted = row[0] if row and row[0] else None
        if last_inserted:
            last_dt = datetime.fromisoformat(last_inserted.replace("Z", "+00:00"))
            elapsed = (datetime.now(timezone.utc) - last_dt).total_seconds()
            if elapsed < cooldown_minutes * 60:
                return -1  # skip - still fresh
    except Exception:
        pass  # if check fails, proceed with ingestion

    try:
        from multi_agent_system.btc_options import fetch_trade_types
        trade_types = fetch_trade_types(days_back=days_back)
    except Exception as exc:
        logging.warning("ingest_trade_log: fetch_trade_types failed – %s", exc)
        return 0

    if not trade_types:
        return 0

    now_utc = _utc_iso()
    rows = []
    for iname, info in trade_types.items():
        for t in info.get("trades", []):
            trade_id = t.get("trade_id")
            if not trade_id:
                continue
            ts_ms = t.get("timestamp")
            try:
                trade_date = datetime.fromtimestamp(ts_ms / 1000, tz=timezone.utc).strftime("%Y-%m-%d")
            except Exception:
                trade_date = ""
            rows.append((
                str(trade_id),
                int(ts_ms) if ts_ms is not None else 0,
                trade_date,
                iname,
                str(t.get("side") or ""),
                t.get("amount"),
                t.get("price"),
                t.get("index_price"),
                t.get("commission"),
                str(t.get("info") or ""),
                1 if t.get("is_liquidation") else 0,
                json.dumps(t, ensure_ascii=False),
                now_utc,
            ))

    if not rows:
        return 0

    inserted = 0
    with sqlite3.connect(str(TRADING_DB)) as conn:
        for row in rows:
            cur = conn.execute(
                """
                INSERT OR IGNORE INTO trade_log
                  (trade_id, timestamp_ms, trade_date, instrument_name, side,
                   amount, price, index_price, commission, info,
                   is_liquidation, raw_json, inserted_at_utc)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)
                """,
                row,
            )
            inserted += cur.rowcount
        conn.commit()

    return inserted


def get_trade_log_df() -> pd.DataFrame:
    """Return all rows from trade_log ordered by timestamp ASC."""
    _ensure_db()
    with sqlite3.connect(str(TRADING_DB)) as conn:
        df = pd.read_sql_query(
            "SELECT * FROM trade_log ORDER BY timestamp_ms ASC",
            conn,
        )
    return df


def save_trade_comment(trade_id: str, comment: str) -> None:
    """Persist a user comment for a specific trade."""
    _ensure_db()
    with sqlite3.connect(str(TRADING_DB)) as conn:
        conn.execute(
            "UPDATE trade_log SET comments = ? WHERE trade_id = ?",
            (str(comment), str(trade_id)),
        )
        conn.commit()


# ADD near your other imports
from typing import Optional, Dict, Any
import os, time
import logging
import traceback
from datetime import datetime, timezone

def refresh_now(client_id: Optional[str] = None,
                client_secret: Optional[str] = None,
                basis: str = "equity") -> Dict[str, Any]:
    """
    One-shot fetch:
      - account capital for BTC, USDT, USDC (packed into ONE payload_json)
      - current positions
    Writes to SQLite via existing _upsert_* helpers WITHOUT changing the DB schema.
    Returns a status dict for the UI.

    Backward-compat:
      - Top-level keys mirror BTC snapshot (legacy)
      - New key: per_currency = {"BTC": {...}, "USDT": {...}, "USDC": {...}}
      - New key: multi_currency = True
      - New key: greeks = {delta_btc, gamma, theta_usd_per_day, vega_usd, volatility}
      - New key: btc_changes = {index_price_usd, roc_pct{15m,30m,1h,12h,1d}}
    """
    cid  = client_id or os.getenv("DERIBIT_CLIENT_ID")
    csec = client_secret or os.getenv("DERIBIT_CLIENT_SECRET")

    res: Dict[str, Any] = {"updated_at": _utc_iso(), "account": {}}

    # ---- 1) Fetch accounts per currency (independent, tolerant to partial failures)
    per_currency: Dict[str, Optional[Dict[str, Any]]] = {}
    for cur in ("BTC", "USDT", "USDC"):
        acc, err = _safe_call(
            fetch_account_capital,
            client_id=cid,
            client_secret=csec,
            currency=cur,
            basis=basis,
        )
        res["account"][cur] = {"ok": (not err and acc is not None), "error": err}
        per_currency[cur] = acc if not err and acc is not None else None

    # Flat flag for legacy checks
    res["account_ok"] = any(v.get("ok") for v in res["account"].values())

    # ---- 2) Fetch positions (once) and persist them
    pos_df, err2 = _safe_call(fetch_current_deribit_positions)
    res["positions_error"] = err2
    positions_records: List[Dict[str, Any]] = []

    if not err2 and pos_df is not None:
        # Enrich option positions with mark_iv from public/ticker
        try:
            if "mark_iv" not in pos_df.columns:
                pos_df["mark_iv"] = float("nan")
            for idx_row in pos_df.index:
                kind = str(pos_df.at[idx_row, "kind"] if "kind" in pos_df.columns else "").lower()
                iname = str(pos_df.at[idx_row, "instrument_name"] if "instrument_name" in pos_df.columns else "")
                if kind == "option" and iname:
                    try:
                        tk = _ticker(iname)
                        miv = tk.get("mark_iv")
                        if miv is not None:
                            pos_df.at[idx_row, "mark_iv"] = float(miv)
                    except Exception:
                        pass
        except Exception as e:
            logging.warning("mark_iv enrichment failed (non-fatal): %s", e)

        _upsert_positions(pos_df)
        res["positions_ok"] = True
        try:
            positions_records = _df_to_json_records(pos_df)
        except Exception:
            positions_records = []
    else:
        res["positions_ok"] = False

    # ---- 3) Compute portfolio Greeks from today's positions
    greeks = compute_account_greeks_from_positions(positions_records or [])
    res["greeks"] = greeks
    
    try:
        refresh_forecast_message(db_path=DB_PATH)
    except Exception as e:
        logging.warning("Forecast refresh failed (non-fatal): %s", e)
        
    # ---- 4) BTC rate of change via TradingView endpoint
    btc_changes: Dict[str, Any] = {}
    tv_result, tv_err = _fetch_btc_tv_candles(resolution="5", lookback_hours=24)
    # logging.info(f"TradingView BTC fetch result: {tv_result}, error: {tv_err}")
    if tv_err:
        res["btc_changes_error"] = tv_err
        logging.error(f"Error fetching TradingView BTC candles: {tv_err}")
    else:
        btc_changes = _compute_btc_rate_of_change(tv_result) or {}
        res["btc_changes_error"] = None

    # ---- 4b) DVOL rate of change via Deribit volatility-index endpoint
    dvol_changes: Dict[str, Any] = {}
    dvol_result, dvol_err = _fetch_dvol_history(lookback_hours=36)
    if dvol_err:
        res["dvol_changes_error"] = dvol_err
        logging.warning("DVOL history fetch failed: %s", dvol_err)
    else:
        dvol_changes = _compute_dvol_rate_of_change(dvol_result) or {}
        res["dvol_changes_error"] = None

    # ---- 5) Build payload_json in a backward-compatible shape
    payload = assemble_account_payload(
        per_currency, greeks, btc_changes, dvol_changes=dvol_changes
    )
    total_equity_usd = payload["total_equity_usd"]

    # Guard: never overwrite a good snapshot with zeros (API failure)
    if total_equity_usd <= 0:
        logging.warning(
            "Skipping account snapshot upsert: total_equity_usd=%.2f (API likely failed)",
            total_equity_usd,
        )
        res["account_row_upserted"] = False
        res["account_upsert_error"] = "skipped_zero_equity"
    else:
        try:
            _upsert_account(payload)
            res["account_row_upserted"] = True
        except Exception as e:
            res["account_row_upserted"] = False
            res["account_upsert_error"] = str(e)

    # ---- 6) Vol metrics (IV/HV + charts) saved to DB (rate-limited)
    try:
        vol_enabled = os.getenv("VOL_METRICS_ENABLED", "1").strip().lower() in ("1","true","yes","y","on")
        vol_min_seconds = int(os.getenv("VOL_METRICS_MIN_SECONDS", "30"))

        if not vol_enabled:
            res["vol_metrics_ok"] = False
        else:
            v_updated = None
            try:
                _, _, v_updated = read_vol_metrics_from_db()
            except Exception:
                v_updated = None

            should_run = True
            if v_updated:
                try:
                    last_ts = datetime.fromisoformat(v_updated.replace("Z", "+00:00")).timestamp()
                    should_run = (time.time() - last_ts) >= vol_min_seconds
                except Exception:
                    should_run = True

            if should_run:
                vp, vi = compute_vol_metrics_and_plots(
                    targets_days=[15.0, 30.0, 60.0, 120.0, 200.0],
                    max_tickers_smile=int(os.getenv("VOL_MAX_TICKERS_SMILE", "80")),
                    max_tickers_surface=int(os.getenv("VOL_MAX_TICKERS_SURFACE", "60")),
                    sleep_s=float(os.getenv("VOL_SLEEP_S", "0.01")),
                )
                _upsert_vol_metrics(vp, vi)

            res["vol_metrics_ok"] = True

    except Exception as e:
        res["vol_metrics_ok"] = False
        res["vol_metrics_error"] = str(e)
        res["vol_metrics_trace"] = traceback.format_exc()
        logging.exception("Vol metrics failed")

    try:
        _upsert_worker_status(res)
    except Exception:
        pass


    return res