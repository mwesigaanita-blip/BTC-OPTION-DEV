# shared/auth/crypto.py
import logging
import bcrypt

logger = logging.getLogger(__name__)

# ── Constants ─────────────────────────────────────────────────────────────────
# bcrypt work factor - 12 is the production standard (balances security vs speed)
# higher = slower to brute-force, but also slower to login (~300ms at 12)
BCRYPT_ROUNDS: int = 12


# ── Public API ────────────────────────────────────────────────────────────────

def hash_password(plain: str) -> str:
    """
    Hash a plaintext password using bcrypt.

    Args:
        plain: raw password string from user input

    Returns:
        bcrypt hash string (safe to store in DB)

    Raises:
        ValueError: if plain is empty
    """
    if not plain or not plain.strip():
        raise ValueError("Password cannot be empty.")

    salt = bcrypt.gensalt(rounds=BCRYPT_ROUNDS)
    hashed = bcrypt.hashpw(plain.encode("utf-8"), salt)
    return hashed.decode("utf-8")  # store as TEXT in SQLite


def verify_password(plain: str, hashed: str) -> bool:
    """
    Verify a plaintext password against a stored bcrypt hash.
    Always runs in constant time to prevent timing attacks.

    Args:
        plain:  raw password string from login form
        hashed: bcrypt hash string retrieved from DB

    Returns:
        True if password matches, False otherwise
        Returns False (never raises) on any error - login just fails safely
    """
    if not plain or not hashed:
        return False

    try:
        return bcrypt.checkpw(
            plain.encode("utf-8"),
            hashed.encode("utf-8"),
        )
    except Exception as e:
        # bcrypt raises on malformed hash - treat as failed login, never crash
        logger.warning(f"Password verification error: {e}")
        return False


# ── CLI test ──────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    import getpass

    print("=== crypto.py test ===")
    pw = getpass.getpass("Enter a password to hash: ")

    hashed = hash_password(pw)
    print(f"\nHash: {hashed}")

    confirm = getpass.getpass("Re-enter to verify: ")
    result = verify_password(confirm, hashed)
    print(f"Verification: {'✓ PASS' if result else '✗ FAIL'}")