# shared/auth/db.py
import json
import sqlite3
import logging
from datetime import datetime, timezone

from shared.db_paths import AUTH_DB

logger = logging.getLogger(__name__)
print(f"[DB] Using {AUTH_DB} in {__file__}", flush=True)


def _resolve_db_path(db_path) -> str:
    """All auth tables live in AUTH_DB.

    The ``db_path`` parameter on every function in this module is kept
    for backward compatibility with existing callers (Streamlit pages,
    create_operator script) but is no longer consulted: every connection
    is opened against ``AUTH_DB``.
    """
    return str(AUTH_DB)

# ── Canonical page list ──────────────────────────────────────────────────────
# Under the simplified role-only security model (operator = all, viewer =
# everything except User Management), per-page grants are no longer enforced
# at request time. This list survives because:
#   * `streamlit_users.pages` is still written for backward compat with the
#     old Streamlit UI / scripts that read it.
#   * If we ever want fine-grained ACLs back, this is the canonical set of
#     stems to choose from.
#
# Keep in sync with `React/src/lib/pageMap.ts` (stem field).
ALL_PAGES: list[str] = [
    "Account_Overview",
    "Positions_History",
    "BTC_Prices",
    "Volatility",
    "Model_Decisions_History",
    "Decision_Board",
    "WS_Layer_Health",
    "X_Sentiment",
    "Hedge_Engine",
    "MM_IM_Simulator",
    "RTI_Portfolio_Management",
    "Portfolio_Analysis_Bot",
    "AI_Models",
    "AI_Models_Scheduler",
    "Live_Options_Scheduler",
    "MM_Alerts",
    "Trading_Fees",
    "LLM_Fees",
    "User_Management",
]

ROLES: list[str] = ["operator", "viewer"]


# ── Table creation ────────────────────────────────────────────────────────────

def create_streamlit_users_table(db_path: str) -> None:
    """
    Creates streamlit_users table if it does not exist.
    Safe to call on every app startup - fully idempotent.

    Columns:
        id          INTEGER  PK autoincrement
        username    TEXT     unique login name
        password    TEXT     bcrypt hash - never stored as plaintext
        role        TEXT     'operator' | 'viewer'
        pages       TEXT     JSON list of page names accessible to this user
                             operators always get all pages (enforced in auth layer)
                             viewers get only what is listed here
        is_active   INTEGER  1 = active | 0 = disabled (soft delete, row kept)
        created_at  TEXT     ISO-8601 UTC
        last_login  TEXT     ISO-8601 UTC, nullable
    """
    sql = """
        CREATE TABLE IF NOT EXISTS streamlit_users (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            username    TEXT    NOT NULL UNIQUE,
            password    TEXT    NOT NULL,
            role        TEXT    NOT NULL CHECK(role IN ('operator', 'viewer')),
            pages       TEXT    NOT NULL DEFAULT '[]',
            is_active   INTEGER NOT NULL DEFAULT 1
                                CHECK(is_active IN (0, 1)),
            created_at  TEXT    NOT NULL,
            last_login  TEXT
        );
    """
    try:
        with sqlite3.connect(_resolve_db_path(db_path)) as conn:
            conn.execute(sql)
            conn.commit()
        logger.info("streamlit_users table ready.")
    except sqlite3.Error as e:
        logger.error(f"Failed to create streamlit_users table: {e}")
        raise


# ── Read ──────────────────────────────────────────────────────────────────────

def get_user(db_path: str, username: str) -> dict | None:
    """
    Fetch one active user by username.
    Returns dict with all columns, or None if not found / disabled.
    pages is returned as a Python list (deserialized from JSON).
    """
    sql = """
        SELECT id, username, password, role, pages,
               is_active, created_at, last_login
        FROM streamlit_users
        WHERE username = ? AND is_active = 1
    """
    try:
        with sqlite3.connect(_resolve_db_path(db_path)) as conn:
            conn.row_factory = sqlite3.Row
            row = conn.execute(sql, (username,)).fetchone()
        if row is None:
            return None
        user = dict(row)
        user["pages"] = json.loads(user["pages"])  # TEXT → list
        return user
    except sqlite3.Error as e:
        logger.error(
            f"get_user failed for '{username}' against {_resolve_db_path(db_path)}: {e}. "
            f"If this says 'no such table: streamlit_users', run "
            f"`python scripts/create_operator.py` on the server to seed the table and an operator."
        )
        return None


def get_all_users(db_path: str) -> list[dict]:
    """
    Fetch all users (active + inactive) ordered by role then username.
    Used by the User Management page.
    pages is returned as a Python list.
    """
    sql = """
        SELECT id, username, role, pages,
               is_active, created_at, last_login
        FROM streamlit_users
        ORDER BY role, username
    """
    try:
        with sqlite3.connect(_resolve_db_path(db_path)) as conn:
            conn.row_factory = sqlite3.Row
            rows = conn.execute(sql).fetchall()
        users = []
        for r in rows:
            u = dict(r)
            u["pages"] = json.loads(u["pages"])
            users.append(u)
        return users
    except sqlite3.Error as e:
        logger.error(f"get_all_users failed: {e}")
        return []


def username_exists(db_path: str, username: str) -> bool:
    """Check if a username already exists (active or inactive)."""
    sql = "SELECT 1 FROM streamlit_users WHERE username = ?"
    with sqlite3.connect(_resolve_db_path(db_path)) as conn:
        row = conn.execute(sql, (username,)).fetchone()
    return row is not None


# ── Write ─────────────────────────────────────────────────────────────────────

def insert_user(
    db_path: str,
    username: str,
    hashed_password: str,
    role: str,
    pages: list[str],
) -> None:
    """
    Insert a new user row.
    - hashed_password must already be bcrypt-hashed by the caller (crypto.py)
    - pages is a Python list, serialized to JSON for storage
    - role must be 'operator' or 'viewer' (DB constraint enforces this)
    Raises ValueError if username already exists.
    Raises sqlite3.Error on DB failure.
    """
    if role not in ROLES:
        raise ValueError(f"Invalid role '{role}'. Must be one of {ROLES}.")
    if username_exists(db_path, username):
        raise ValueError(f"Username '{username}' already exists.")

    sql = """
        INSERT INTO streamlit_users
            (username, password, role, pages, created_at)
        VALUES (?, ?, ?, ?, ?)
    """
    now = datetime.now(timezone.utc).isoformat()
    with sqlite3.connect(_resolve_db_path(db_path)) as conn:
        conn.execute(sql, (username, hashed_password, role, json.dumps(pages), now))
        conn.commit()
    logger.info(f"User '{username}' created with role '{role}'.")


def update_user(
    db_path: str,
    user_id: int,
    role: str,
    pages: list[str],
    is_active: int,
    hashed_password: str | None = None,
) -> None:
    """
    Update an existing user.
    - hashed_password: pass only if resetting password, else leave None
    - is_active: 1 = active, 0 = disabled
    """
    if role not in ROLES:
        raise ValueError(f"Invalid role '{role}'. Must be one of {ROLES}.")
    if is_active not in (0, 1):
        raise ValueError("is_active must be 0 or 1.")

    if hashed_password:
        sql = """
            UPDATE streamlit_users
            SET role = ?, pages = ?, is_active = ?, password = ?
            WHERE id = ?
        """
        params = (role, json.dumps(pages), is_active, hashed_password, user_id)
    else:
        sql = """
            UPDATE streamlit_users
            SET role = ?, pages = ?, is_active = ?
            WHERE id = ?
        """
        params = (role, json.dumps(pages), is_active, user_id)

    with sqlite3.connect(_resolve_db_path(db_path)) as conn:
        conn.execute(sql, params)
        conn.commit()
    logger.info(f"User id={user_id} updated. role={role}, active={is_active}.")


def update_last_login(db_path: str, username: str) -> None:
    """
    Stamp last_login with current UTC time on successful login.
    Called by streamlit_auth.py after password verification passes.
    """
    now = datetime.now(timezone.utc).isoformat()
    try:
        with sqlite3.connect(_resolve_db_path(db_path)) as conn:
            conn.execute(
                "UPDATE streamlit_users SET last_login = ? WHERE username = ?",
                (now, username),
            )
            conn.commit()
    except sqlite3.Error as e:
        logger.warning(f"Could not update last_login for '{username}': {e}")    