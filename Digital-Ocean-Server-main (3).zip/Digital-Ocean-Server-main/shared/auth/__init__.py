# shared/auth/__init__.py
#
# Public API for the auth package.
# Any file that needs auth functionality imports from here:
#
#   from shared.auth import hash_password, verify_password
#   from shared.auth import get_user, insert_user, update_user
#   from shared.auth import ALL_PAGES, ROLES
#
# Nothing should import directly from shared.auth.db or shared.auth.crypto
# outside of this package - keeps the internal structure flexible.

from shared.auth.crypto import (
    hash_password,
    verify_password,
)

from shared.auth.db import (
    # constants
    ALL_PAGES,
    ROLES,
    # table setup
    create_streamlit_users_table,
    # read
    get_user,
    get_all_users,
    username_exists,
    # write
    insert_user,
    update_user,
    update_last_login,
)

__all__ = [
    # crypto
    "hash_password",
    "verify_password",
    # constants
    "ALL_PAGES",
    "ROLES",
    # db
    "create_streamlit_users_table",
    "get_user",
    "get_all_users",
    "username_exists",
    "insert_user",
    "update_user",
    "update_last_login",
]