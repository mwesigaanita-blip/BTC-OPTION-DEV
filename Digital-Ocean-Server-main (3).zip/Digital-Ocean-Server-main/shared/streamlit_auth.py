# shared/streamlit_auth.py
#
# Drop-in replacement for the original single-user auth.
# Every existing page already calls require_login() - no import changes needed.
#
# Usage per page:
#   from shared.streamlit_auth import require_login, require_page_access
#   require_login()                           ← always first
#   require_page_access("1_Account_Overview") ← enforces per-page access
#
# Operator-only pages (e.g. User Management):
#   from shared.streamlit_auth import require_login, require_operator
#   require_login()
#   require_operator()
#
# To disable all auth (e.g. local dev), set in .env:
#   AUTH_ENABLED=0

import os
import logging
import streamlit as st

from shared.auth import (
    create_streamlit_users_table,
    get_user,
    update_last_login,
    verify_password,
    ALL_PAGES,
)
from shared.db_paths import AUTH_DB

logger = logging.getLogger(__name__)

# All auth functions in shared/auth/db.py auto-resolve to AUTH_DB and
# ignore the db_path argument; we pass AUTH_DB explicitly here so the
# code reads honestly. We also ensure the streamlit_users table exists
# on import - without this, a fresh server (or one where the DB split
# migration was never executed) fails every login with a silent
# "Invalid credentials" because the table is missing.
DB_PATH = str(AUTH_DB)
try:
    create_streamlit_users_table(DB_PATH)
except Exception as e:
    logger.error(f"Could not ensure streamlit_users table in {AUTH_DB}: {e}")

# ── Auth flag ─────────────────────────────────────────────────────────────────
# AUTH_ENABLED=1 → full auth active (production)
# AUTH_ENABLED=0 → all gates bypassed (local dev only)
_AUTH_ENABLED: bool = os.getenv("AUTH_ENABLED", "0").strip() == "1"

if not _AUTH_ENABLED:
    logger.warning(
        "AUTH_ENABLED=0 - all authentication is DISABLED. "
        "Never use this setting in production."
    )

# ── Session state keys ────────────────────────────────────────────────────────
_KEY_AUTH     = "auth_ok"
_KEY_USERNAME = "auth_username"
_KEY_ROLE     = "auth_role"
_KEY_PAGES    = "auth_pages"


# ── Internal helpers ──────────────────────────────────────────────────────────

def _set_session(username: str, role: str, pages: list[str]) -> None:
    """Write auth result into session state."""
    st.session_state[_KEY_AUTH]     = True
    st.session_state[_KEY_USERNAME] = username
    st.session_state[_KEY_ROLE]     = role
    # operators always get all pages regardless of DB value
    st.session_state[_KEY_PAGES]    = ALL_PAGES if role == "operator" else pages


def _clear_session() -> None:
    """Wipe all auth keys from session state (logout)."""
    for key in (_KEY_AUTH, _KEY_USERNAME, _KEY_ROLE, _KEY_PAGES):
        st.session_state.pop(key, None)


def _is_authenticated() -> bool:
    return st.session_state.get(_KEY_AUTH, False)


def _set_dev_session() -> None:
    """
    When AUTH_ENABLED=0, inject a fake operator session so all
    downstream calls to get_current_user() and is_operator() work
    normally without any code changes in the pages.
    """
    if not _is_authenticated():
        _set_session(
            username="dev",
            role="operator",
            pages=ALL_PAGES,
        )


def _render_login_form() -> None:
    """
    Render the login form and handle submission.
    Calls st.stop() after rendering so the rest of the page never executes.
    """
    st.title("🔐 Login")
    st.markdown("---")

    col, _ = st.columns([1.2, 1])
    with col:
        username = st.text_input("Username", key="_login_username")
        password = st.text_input("Password", type="password", key="_login_password")

        if st.button("Sign in", use_container_width=True):
            # --- empty field guard ---
            if not username or not password:
                st.error("Please enter both username and password.")
                st.stop()

            # --- DB lookup ---
            user = get_user(DB_PATH, username)

            if user is None:
                # same message for unknown user and wrong password
                logger.warning(f"Login failed: unknown or inactive user '{username}'.")
                st.error("Invalid credentials.")
                st.stop()

            # --- password check ---
            if not verify_password(password, user["password"]):
                logger.warning(f"Login failed: wrong password for '{username}'.")
                st.error("Invalid credentials.")
                st.stop()

            # --- success ---
            _set_session(username, user["role"], user["pages"])
            update_last_login(DB_PATH, username)
            logger.info(f"User '{username}' logged in (role={user['role']}).")
            st.rerun()

    st.stop()


# ── Public API ────────────────────────────────────────────────────────────────

def require_login(render_sidebar: bool = True) -> None:
    """
    Gate: user must be logged in.
    Call this as the FIRST line of every Streamlit page.

    AUTH_ENABLED=0 → injects a dev operator session and returns immediately.
    AUTH_ENABLED=1 → full login flow.

    Args:
        render_sidebar: when True (default), renders the user info + Logout
            button in the sidebar. The top-level app entrypoint (app.py) should
            pass False, since the selected page will render it itself via its
            own require_login() call - otherwise the sidebar shows two Logout
            buttons (one from app.py, one from the page).
    """
    if not _AUTH_ENABLED:
        _set_dev_session()
        return

    if not _is_authenticated():
        _render_login_form()

    if not render_sidebar:
        return

    # Authenticated - render sidebar user info + logout
    with st.sidebar:
        st.markdown(f"👤 **{st.session_state[_KEY_USERNAME]}**")
        st.caption(f"Role: `{st.session_state[_KEY_ROLE]}`")
        st.markdown("---")
        if st.button("Logout", use_container_width=True):
            _clear_session()
            st.rerun()


def require_page_access(page_name: str) -> None:
    """
    Gate: logged-in user must have access to this specific page.
    Call this immediately after require_login() on every page.

    AUTH_ENABLED=0 → always passes (dev session has all pages).

    Args:
        page_name: must match exactly one entry in ALL_PAGES
                   e.g. "1_Account_Overview", "14_Hedge_Engine"
    """
    if not _AUTH_ENABLED:
        return

    allowed_pages: list[str] = st.session_state.get(_KEY_PAGES, [])

    if page_name not in allowed_pages:
        st.error("🚫 Access denied. You do not have permission to view this page.")
        logger.warning(
            f"User '{st.session_state.get(_KEY_USERNAME)}' "
            f"attempted to access '{page_name}' without permission."
        )
        st.stop()


def require_operator() -> None:
    """
    Gate: logged-in user must have the 'operator' role.
    Call this on operator-only pages (e.g. User Management).

    AUTH_ENABLED=0 → always passes (dev session is operator).
    """
    if not _AUTH_ENABLED:
        return

    role = st.session_state.get(_KEY_ROLE, "")
    if role != "operator":
        st.error("🚫 Access denied. This page is restricted to operators only.")
        logger.warning(
            f"User '{st.session_state.get(_KEY_USERNAME)}' "
            f"(role='{role}') attempted to access an operator-only page."
        )
        st.stop()


def get_current_user() -> dict:
    """
    Returns the current logged-in user's session info as a dict.
    Safe to call only after require_login() has passed.

    Returns:
        {
            "username": str,
            "role":     str,   # 'operator' | 'viewer'
            "pages":    list[str]
        }
    """
    return {
        "username": st.session_state.get(_KEY_USERNAME, ""),
        "role":     st.session_state.get(_KEY_ROLE, ""),
        "pages":    st.session_state.get(_KEY_PAGES, []),
    }


def is_operator() -> bool:
    """
    Convenience check - use this to conditionally show/hide UI elements
    without hard-stopping the page.

    Example:
        if is_operator():
            st.page_link("pages/0_User_Management.py", label="Manage Users")
    """
    return st.session_state.get(_KEY_ROLE, "") == "operator"