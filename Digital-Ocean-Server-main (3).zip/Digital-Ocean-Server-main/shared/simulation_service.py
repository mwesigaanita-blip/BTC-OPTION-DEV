# shared\simulation_service.py
from __future__ import annotations

import os
import time
import math
from typing import Any, Dict, List, Optional

import requests # type: ignore


DEFAULT_BASE_URL = os.getenv("DERIBIT_API_BASE", "https://www.deribit.com/api/v2")
SUPPORTED_CURRENCIES = ("BTC", "USDT", "USDC")
SIMULATION_MIN_INTERVAL_SECONDS = 1.05


# ---------------------------------------------------------------------------
# Small utilities
# ---------------------------------------------------------------------------

def _now_ms() -> int:
    return int(time.time() * 1000)


def _safe_float(value: Any, default: float = 0.0) -> float:
    try:
        v = float(value)
        return v if math.isfinite(v) else default
    except Exception:
        return default


def _normalize_side(value: Any) -> str:
    s = str(value or "").strip().lower()
    if s in {"buy", "long"}:
        return "long"
    if s in {"sell", "short"}:
        return "short"
    return s


def _normalize_option_type(value: Any) -> Optional[str]:
    s = str(value or "").strip().lower()
    if s in {"call", "c"}:
        return "call"
    if s in {"put", "p"}:
        return "put"
    return None


def _normalize_action(value: Any) -> str:
    s = str(value or "").strip().lower()
    aliases = {
        "close": "decrease",
        "reduce": "decrease",
        "decrease": "decrease",
        "increase": "increase",
        "add": "increase",
    }
    if s not in aliases:
        raise ValueError(f"Unsupported action: {value}")
    return aliases[s]


# ---------------------------------------------------------------------------
# Deribit client
# ---------------------------------------------------------------------------

class DeribitAPIError(RuntimeError):
    pass


class DeribitClient:
    def __init__(
        self,
        client_id: str,
        client_secret: str,
        *,
        base_url: str = DEFAULT_BASE_URL,
        timeout_s: int = 20,
    ) -> None:
        self.client_id = (client_id or "").strip()
        self.client_secret = (client_secret or "").strip()
        if not self.client_id or not self.client_secret:
            raise ValueError("Missing Deribit client_id or client_secret")

        self.base_url = base_url.rstrip("/")
        self.timeout_s = int(timeout_s)
        self.session = requests.Session()
        self._token: Optional[str] = None
        self._expiry_ts: float = 0.0
        self._last_simulation_ts: float = 0.0

    def _rpc(self, method: str, params: Optional[Dict[str, Any]] = None, *, auth: bool = False) -> Any:
        if auth:
            self._ensure_token()

        payload = {
            "jsonrpc": "2.0",
            "id": _now_ms() % 1_000_000_000,
            "method": method,
            "params": params or {},
        }
        headers = {"Content-Type": "application/json"}
        if auth and self._token:
            headers["Authorization"] = f"Bearer {self._token}"

        response = self.session.post(self.base_url, json=payload, headers=headers, timeout=self.timeout_s)
        response.raise_for_status()
        data = response.json()
        if data.get("error"):
            raise DeribitAPIError(f"{method} error: {data['error']}")
        return data.get("result")

    def _ensure_token(self) -> None:
        if self._token and time.time() < self._expiry_ts - 20:
            return

        result = self._rpc(
            "public/auth",
            {
                "grant_type": "client_credentials",
                "client_id": self.client_id,
                "client_secret": self.client_secret,
            },
            auth=False,
        )
        self._token = result["access_token"]
        self._expiry_ts = time.time() + float(result.get("expires_in", 300))

    def public_call(self, method: str, params: Optional[Dict[str, Any]] = None) -> Any:
        return self._rpc(method, params=params, auth=False)

    def private_call(self, method: str, params: Optional[Dict[str, Any]] = None) -> Any:
        if method == "private/simulate_portfolio":
            elapsed = time.time() - self._last_simulation_ts
            if elapsed < SIMULATION_MIN_INTERVAL_SECONDS:
                time.sleep(SIMULATION_MIN_INTERVAL_SECONDS - elapsed)

        result = self._rpc(method, params=params, auth=True)

        if method == "private/simulate_portfolio":
            self._last_simulation_ts = time.time()

        return result


# ---------------------------------------------------------------------------
# Position normalization
# ---------------------------------------------------------------------------

def _instrument_kind(position: Dict[str, Any]) -> str:
    kind = str(position.get("kind") or "").lower()
    instrument_name = str(position.get("instrument_name") or "").upper()
    if kind:
        return kind
    if instrument_name == "BTC-PERPETUAL":
        return "future"
    if instrument_name.endswith("-C") or instrument_name.endswith("-P"):
        return "option"
    return "unknown"


def _signed_size_from_position(position: Dict[str, Any]) -> float:
    raw_size = _safe_float(position.get("size"), 0.0)
    direction = _normalize_side(position.get("direction") or position.get("side"))
    if direction == "short":
        return -abs(raw_size)
    if direction == "long":
        return abs(raw_size)
    return raw_size


def _option_type_from_instrument_name(instrument_name: str) -> Optional[str]:
    name = (instrument_name or "").upper()
    if name.endswith("-C"):
        return "call"
    if name.endswith("-P"):
        return "put"
    return None


_MONTHS = {
    "JAN": 1, "FEB": 2, "MAR": 3, "APR": 4, "MAY": 5, "JUN": 6,
    "JUL": 7, "AUG": 8, "SEP": 9, "OCT": 10, "NOV": 11, "DEC": 12,
}


def _parse_instrument_meta(instrument_name: str) -> Dict[str, Any]:
    """Best-effort parse of strike / expiry timestamp / option type from a
    Deribit instrument name like `BTC-30MAY26-100000-C`. Returns the keys
    that could be resolved; missing ones are absent from the dict."""
    out: Dict[str, Any] = {}
    name = (instrument_name or "").upper()
    parts = name.split("-")
    if len(parts) < 2:
        return out
    expiry_token = parts[1]
    if len(expiry_token) >= 7 and expiry_token != "PERPETUAL":
        # Pattern: DDMMMYY (e.g. 30MAY26).
        try:
            from datetime import datetime, timezone
            day = int(expiry_token[:-5])
            mon = _MONTHS.get(expiry_token[-5:-2])
            year = 2000 + int(expiry_token[-2:])
            if mon is not None:
                dt = datetime(year, mon, day, 8, 0, 0, tzinfo=timezone.utc)
                out["expiration_timestamp"] = int(dt.timestamp() * 1000)
        except Exception:
            pass
    if len(parts) >= 3:
        try:
            out["strike"] = float(parts[2])
        except (TypeError, ValueError):
            pass
    if len(parts) >= 4:
        if parts[3] == "C":
            out["option_type"] = "call"
        elif parts[3] == "P":
            out["option_type"] = "put"
    return out


def _normalize_position(position: Dict[str, Any], currency: str) -> Dict[str, Any]:
    instrument_name = str(position.get("instrument_name") or "").strip()
    kind = _instrument_kind(position)
    signed_size = _signed_size_from_position(position)
    abs_size = abs(signed_size)
    side = "long" if signed_size >= 0 else "short"

    strike = position.get("strike")
    expiration_timestamp = position.get("expiration_timestamp")
    option_type = (
        _normalize_option_type(position.get("option_type"))
        or _option_type_from_instrument_name(instrument_name)
    )

    # If Deribit didn't ship strike/expiry inline (some private/get_positions
    # responses omit them), fall back to parsing the instrument name. This is
    # what the BS-based mark-price recalculation on the front-end consumes.
    meta = _parse_instrument_meta(instrument_name)
    if strike is None and "strike" in meta:
        strike = meta["strike"]
    if expiration_timestamp is None and "expiration_timestamp" in meta:
        expiration_timestamp = meta["expiration_timestamp"]
    if option_type is None and "option_type" in meta:
        option_type = meta["option_type"]

    mark_iv = position.get("mark_iv")
    if mark_iv is None:
        mark_iv = position.get("iv")  # alt key Deribit sometimes uses

    return {
        "currency": currency,
        "instrument_name": instrument_name,
        "kind": kind,
        "option_type": option_type,
        "direction": side,
        "size": abs_size,
        "signed_size": signed_size,
        "size_currency": _safe_float(position.get("size_currency"), 0.0),
        "average_price": _safe_float(position.get("average_price"), 0.0),
        "mark_price": _safe_float(position.get("mark_price"), 0.0),
        "index_price": _safe_float(position.get("index_price"), 0.0),
        "mark_iv": _safe_float(mark_iv, 0.0) if mark_iv is not None else None,
        "delta": _safe_float(position.get("delta"), 0.0),
        "gamma": _safe_float(position.get("gamma"), 0.0),
        "vega": _safe_float(position.get("vega"), 0.0),
        "theta": _safe_float(position.get("theta"), 0.0),
        "initial_margin": _safe_float(position.get("initial_margin"), 0.0),
        "maintenance_margin": _safe_float(position.get("maintenance_margin"), 0.0),
        "strike": _safe_float(strike, 0.0) if strike is not None else None,
        "expiration_timestamp": int(expiration_timestamp) if expiration_timestamp is not None else None,
        "raw": position,
    }


def fetch_current_positions_for_simulation(
    client_id: str,
    client_secret: str,
    *,
    currencies: Optional[List[str]] = None,
    base_url: str = DEFAULT_BASE_URL,
) -> List[Dict[str, Any]]:
    client = DeribitClient(client_id, client_secret, base_url=base_url)
    out: List[Dict[str, Any]] = []

    for currency in (currencies or list(SUPPORTED_CURRENCIES)):
        rows = client.private_call("private/get_positions", {"currency": currency, "kind": "any"}) or []
        for row in rows:
            normalized = _normalize_position(row, currency)
            if normalized["size"] > 0:
                out.append(normalized)

    out.sort(key=lambda x: (x["currency"], x["kind"], x["instrument_name"]))
    return out


# ---------------------------------------------------------------------------
# Market helpers
# ---------------------------------------------------------------------------

def fetch_btc_instruments(
    *,
    kind: Optional[str] = None,
    expired: bool = False,
    base_url: str = DEFAULT_BASE_URL,
) -> List[Dict[str, Any]]:
    params: Dict[str, Any] = {"currency": "BTC", "expired": bool(expired)}
    if kind:
        params["kind"] = kind

    response = requests.get(
        f"{base_url.rstrip('/')}/public/get_instruments",
        params={k: (str(v).lower() if isinstance(v, bool) else v) for k, v in params.items()},
        timeout=20,
    )
    response.raise_for_status()
    data = response.json()
    if data.get("error"):
        raise DeribitAPIError(f"public/get_instruments error: {data['error']}")

    result = data.get("result") or []
    result.sort(key=lambda x: (x.get("expiration_timestamp") or 0, x.get("strike") or 0, x.get("instrument_name") or ""))
    return result


def fetch_instrument_quote(instrument_name: str, *, base_url: str = DEFAULT_BASE_URL) -> Dict[str, Any]:
    response = requests.get(
        f"{base_url.rstrip('/')}/public/ticker",
        params={"instrument_name": instrument_name},
        timeout=20,
    )
    response.raise_for_status()
    data = response.json()
    if data.get("error"):
        raise DeribitAPIError(f"public/ticker error: {data['error']}")

    raw = data.get("result") or {}
    return {
        "instrument_name": instrument_name,
        "bid_price": raw.get("best_bid_price"),
        "ask_price": raw.get("best_ask_price"),
        "mark_price": raw.get("mark_price"),
        "index_price": raw.get("index_price"),
        "mark_iv": raw.get("mark_iv"),
        "best_bid_amount": raw.get("best_bid_amount"),
        "best_ask_amount": raw.get("best_ask_amount"),
        "raw": raw,
    }


def fetch_recent_trades(instrument_name: str, count: int = 20, *, base_url: str = DEFAULT_BASE_URL) -> List[Dict[str, Any]]:
    response = requests.get(
        f"{base_url.rstrip('/')}/public/get_last_trades_by_instrument",
        params={"instrument_name": instrument_name, "count": max(1, int(count))},
        timeout=20,
    )
    response.raise_for_status()
    data = response.json()
    if data.get("error"):
        raise DeribitAPIError(f"public/get_last_trades_by_instrument error: {data['error']}")

    result = data.get("result") or {}
    return result.get("trades") or []


def get_option_chain_selection_data(*, base_url: str = DEFAULT_BASE_URL) -> Dict[str, Any]:
    instruments = fetch_btc_instruments(kind="option", expired=False, base_url=base_url)
    expiries: Dict[int, Dict[str, Any]] = {}

    for inst in instruments:
        expiry_ts = int(inst.get("expiration_timestamp") or 0)
        strike = _safe_float(inst.get("strike"), 0.0)
        option_type = _normalize_option_type(inst.get("option_type")) or _option_type_from_instrument_name(inst.get("instrument_name", ""))

        if expiry_ts not in expiries:
            expiries[expiry_ts] = {
                "expiration_timestamp": expiry_ts,
                "strikes": set(),
                "calls": {},
                "puts": {},
            }

        expiries[expiry_ts]["strikes"].add(strike)
        if option_type == "call":
            expiries[expiry_ts]["calls"][strike] = inst.get("instrument_name")
        elif option_type == "put":
            expiries[expiry_ts]["puts"][strike] = inst.get("instrument_name")

    ordered = []
    for expiry_ts, payload in sorted(expiries.items(), key=lambda kv: kv[0]):
        ordered.append(
            {
                "expiration_timestamp": expiry_ts,
                "strikes": sorted(payload["strikes"]),
                "calls": payload["calls"],
                "puts": payload["puts"],
            }
        )

    return {"expiries": ordered, "count": len(instruments)}


# ---------------------------------------------------------------------------
# Validation
# ---------------------------------------------------------------------------

def validate_adjustments(current_positions: List[Dict[str, Any]], adjustments: Optional[List[Dict[str, Any]]]) -> List[str]:
    errors: List[str] = []
    if not adjustments:
        return errors

    by_name = {p["instrument_name"]: p for p in current_positions}

    for idx, adj in enumerate(adjustments):
        inst = str(adj.get("instrument_name") or "").strip()
        if not inst:
            errors.append(f"adjustments[{idx}]: missing instrument_name")
            continue
        if inst not in by_name:
            errors.append(f"adjustments[{idx}]: instrument not found in current positions: {inst}")
            continue

        action = str(adj.get("action") or "").strip().lower()
        if action not in {"close", "decrease", "reduce", "increase", "add"}:
            errors.append(f"adjustments[{idx}]: unsupported action for {inst}: {action}")
            continue

        amount = _safe_float(adj.get("amount"), -1.0)
        if amount <= 0:
            errors.append(f"adjustments[{idx}]: amount must be > 0 for {inst}")
            continue

        position = by_name[inst]
        current_size = abs(_safe_float(position.get("signed_size"), 0.0))
        normalized_action = _normalize_action(action)
        if normalized_action == "decrease" and amount > current_size:
            errors.append(
                f"adjustments[{idx}]: decrease amount {amount} exceeds current size {current_size} for {inst}"
            )

    return errors


def validate_new_trades(new_trades: Optional[List[Dict[str, Any]]], known_instruments: Optional[List[Dict[str, Any]]] = None) -> List[str]:
    errors: List[str] = []
    if not new_trades:
        return errors

    known_names = None
    if known_instruments is not None:
        known_names = {str(x.get("instrument_name") or "").strip() for x in known_instruments}

    for idx, trade in enumerate(new_trades):
        inst = str(trade.get("instrument_name") or "").strip()
        if not inst:
            errors.append(f"new_trades[{idx}]: missing instrument_name")
            continue
        if known_names is not None and inst not in known_names:
            errors.append(f"new_trades[{idx}]: unknown instrument_name {inst}")

        side = _normalize_side(trade.get("side"))
        if side not in {"long", "short"}:
            errors.append(f"new_trades[{idx}]: side must be long or short for {inst}")

        amount = _safe_float(trade.get("amount"), -1.0)
        if amount <= 0:
            errors.append(f"new_trades[{idx}]: amount must be > 0 for {inst}")

    return errors


# ---------------------------------------------------------------------------
# Simulation instruction builders
# ---------------------------------------------------------------------------

def _copy_positions_by_name(current_positions: List[Dict[str, Any]]) -> Dict[str, Dict[str, Any]]:
    out: Dict[str, Dict[str, Any]] = {}
    for row in current_positions:
        out[row["instrument_name"]] = dict(row)
    return out


def apply_position_adjustments(current_positions: List[Dict[str, Any]], adjustments: Optional[List[Dict[str, Any]]]) -> List[Dict[str, Any]]:
    errors = validate_adjustments(current_positions, adjustments)
    if errors:
        raise ValueError("; ".join(errors))

    positions = _copy_positions_by_name(current_positions)

    for adj in adjustments or []:
        inst = str(adj["instrument_name"]).strip()
        action = _normalize_action(adj["action"])
        amount = abs(_safe_float(adj["amount"], 0.0))

        row = positions[inst]
        signed_size = _safe_float(row.get("signed_size"), 0.0)
        sign = 1.0 if signed_size >= 0 else -1.0

        if action == "decrease":
            new_abs = abs(signed_size) - amount
        else:
            new_abs = abs(signed_size) + amount

        if new_abs <= 0:
            positions.pop(inst, None)
            continue

        new_signed = sign * new_abs
        row["signed_size"] = new_signed
        row["size"] = abs(new_signed)
        row["direction"] = "long" if new_signed >= 0 else "short"
        positions[inst] = row

    return sorted(positions.values(), key=lambda x: (x["currency"], x["kind"], x["instrument_name"]))


def _infer_currency_from_instrument_name(instrument_name: str) -> str:
    prefix = (instrument_name or "").split("-", 1)[0].upper()
    if prefix in SUPPORTED_CURRENCIES:
        return prefix
    return "BTC"


def _infer_kind_from_instrument_name(instrument_name: str) -> str:
    name = (instrument_name or "").upper()
    if name == "BTC-PERPETUAL":
        return "future"
    if name.endswith("-C") or name.endswith("-P"):
        return "option"
    return "unknown"


def merge_new_simulated_trades(
    positions_after_adjustment: List[Dict[str, Any]],
    new_trades: Optional[List[Dict[str, Any]]],
) -> List[Dict[str, Any]]:
    positions = _copy_positions_by_name(positions_after_adjustment)

    for trade in new_trades or []:
        inst = str(trade["instrument_name"]).strip()
        side = _normalize_side(trade["side"])
        amount = abs(_safe_float(trade["amount"], 0.0))
        sign = 1.0 if side == "long" else -1.0
        add_signed = sign * amount

        existing = positions.get(inst)
        if existing:
            current_signed = _safe_float(existing.get("signed_size"), 0.0)
            new_signed = current_signed + add_signed
            if abs(new_signed) < 1e-12:
                positions.pop(inst, None)
                continue
            existing["signed_size"] = new_signed
            existing["size"] = abs(new_signed)
            existing["direction"] = "long" if new_signed >= 0 else "short"
            positions[inst] = existing
            continue

        positions[inst] = {
            "currency": _infer_currency_from_instrument_name(inst),
            "instrument_name": inst,
            "kind": _infer_kind_from_instrument_name(inst),
            "option_type": _option_type_from_instrument_name(inst),
            "direction": side,
            "size": abs(add_signed),
            "signed_size": add_signed,
            "size_currency": 0.0,
            "average_price": _safe_float(trade.get("entry_price"), 0.0),
            "mark_price": _safe_float(trade.get("entry_price"), 0.0),
            "index_price": _safe_float(trade.get("index_price"), 0.0),
            "delta": 0.0,
            "gamma": 0.0,
            "vega": 0.0,
            "theta": 0.0,
            "initial_margin": 0.0,
            "maintenance_margin": 0.0,
            "strike": trade.get("strike"),
            "expiration_timestamp": trade.get("expiration_timestamp"),
            "raw": {"created_by": "merge_new_simulated_trades", **trade},
        }

    return sorted(positions.values(), key=lambda x: (x["currency"], x["kind"], x["instrument_name"]))


def build_simulated_positions_map(positions: List[Dict[str, Any]], currency: str) -> Dict[str, float]:
    out: Dict[str, float] = {}
    for row in positions:
        if str(row.get("currency") or "").upper() != currency.upper():
            continue
        out[row["instrument_name"]] = float(row["signed_size"])
    return out


# ---------------------------------------------------------------------------
# Quote enrichment for new trades
# ---------------------------------------------------------------------------

def attach_entry_prices_from_quotes(
    new_trades: Optional[List[Dict[str, Any]]],
    *,
    base_url: str = DEFAULT_BASE_URL,
) -> List[Dict[str, Any]]:
    enriched: List[Dict[str, Any]] = []

    for trade in new_trades or []:
        inst = str(trade.get("instrument_name") or "").strip()
        if not inst:
            continue

        # If the caller already locked an entry_price (e.g. via the IV-based
        # recalc in the MM/IM simulator), honor it. Skip the quote round-trip
        # for the price, but still fetch the quote envelope so downstream
        # metadata (index_price, bid/ask, etc.) is populated.
        preset = trade.get("entry_price")
        try:
            preset_val = float(preset) if preset is not None else None
        except (TypeError, ValueError):
            preset_val = None

        side = _normalize_side(trade.get("side"))
        quote = fetch_instrument_quote(inst, base_url=base_url)

        if preset_val is not None and preset_val > 0:
            entry_price = preset_val
        else:
            if side == "long":
                entry_price = quote.get("ask_price")
            else:
                entry_price = quote.get("bid_price")
            if entry_price in (None, 0, 0.0):
                entry_price = quote.get("mark_price")

        row = dict(trade)
        row["entry_price"] = _safe_float(entry_price, 0.0)
        row["entry_price_source"] = (
            "user_locked" if preset_val is not None and preset_val > 0 else "live_quote"
        )
        row["index_price"] = _safe_float(quote.get("index_price"), 0.0)
        row["mark_price"] = _safe_float(quote.get("mark_price"), 0.0)
        row["bid_price"] = quote.get("bid_price")
        row["ask_price"] = quote.get("ask_price")
        row["mark_iv"] = quote.get("mark_iv")
        row["quote_raw"] = quote.get("raw")
        enriched.append(row)

    return enriched


# ---------------------------------------------------------------------------
# Simulation parsing
# ---------------------------------------------------------------------------

def _pick_first_number(payload: Dict[str, Any], keys: List[str]) -> Optional[float]:
    for key in keys:
        if key in payload and payload[key] is not None:
            try:
                return float(payload[key])
            except Exception:
                pass
    return None


def _calc_pct(numerator: Optional[float], denominator: Optional[float]) -> Optional[float]:
    if numerator is None or denominator is None or denominator == 0:
        return None
    return (numerator / denominator) * 100.0


def _extract_simulation_metrics(raw: Dict[str, Any]) -> Dict[str, Any]:
    initial_margin = _pick_first_number(raw, ["projected_initial_margin", "initial_margin"])
    maintenance_margin = _pick_first_number(raw, ["projected_maintenance_margin", "maintenance_margin"])
    margin_balance = _pick_first_number(raw, ["margin_balance"])
    equity = _pick_first_number(raw, ["equity"])

    delta = _pick_first_number(raw, ["projected_delta_total", "delta_total", "options_delta"])
    gamma = _pick_first_number(raw, ["options_gamma", "gamma"])
    vega = _pick_first_number(raw, ["options_vega", "vega"])
    theta = _pick_first_number(raw, ["options_theta", "theta"])

    return {
        "currency": raw.get("currency"),
        "initial_margin": initial_margin,
        "maintenance_margin": maintenance_margin,
        "margin_balance": margin_balance,
        "equity": equity,
        "im_pct": _calc_pct(initial_margin, margin_balance),
        "mm_pct": _calc_pct(maintenance_margin, margin_balance),
        "delta": delta,
        "gamma": gamma,
        "vega": vega,
        "theta": theta,
        "portfolio_margining_enabled": raw.get("portfolio_margining_enabled"),
        "cross_collateral_enabled": raw.get("cross_collateral_enabled"),
    }


def _metrics_change(before: Dict[str, Any], after: Dict[str, Any]) -> Dict[str, Any]:
    out: Dict[str, Any] = {}
    keys = [
        "initial_margin",
        "maintenance_margin",
        "margin_balance",
        "equity",
        "im_pct",
        "mm_pct",
        "delta",
        "gamma",
        "vega",
        "theta",
    ]
    for key in keys:
        b = before.get(key)
        a = after.get(key)
        if b is None or a is None:
            out[key] = None
        else:
            out[key] = a - b
    return out


# ---------------------------------------------------------------------------
# Simulation execution
# ---------------------------------------------------------------------------

def simulate_portfolio_state(
    simulated_positions_map: Dict[str, float],
    client_id: str,
    client_secret: str,
    *,
    currency: str = "BTC",
    add_positions: bool = False,
    base_url: str = DEFAULT_BASE_URL,
) -> Dict[str, Any]:
    client = DeribitClient(client_id, client_secret, base_url=base_url)
    params: Dict[str, Any] = {
        "currency": currency,
        "add_positions": bool(add_positions),
        "simulated_positions": simulated_positions_map,
    }
    raw = client.private_call("private/simulate_portfolio", params)
    return {"metrics": _extract_simulation_metrics(raw), "raw": raw}


def _run_single_currency_compare(
    client: DeribitClient,
    *,
    currency: str,
    current_positions: List[Dict[str, Any]],
    final_positions: List[Dict[str, Any]],
) -> Dict[str, Any]:
    base_raw = client.private_call(
        "private/simulate_portfolio",
        {"currency": currency, "add_positions": True},
    )
    base_metrics = _extract_simulation_metrics(base_raw)

    simulated_map = build_simulated_positions_map(final_positions, currency)
    after_raw = client.private_call(
        "private/simulate_portfolio",
        {
            "currency": currency,
            "add_positions": False,
            "simulated_positions": simulated_map,
        },
    )
    after_metrics = _extract_simulation_metrics(after_raw)

    return {
        "currency": currency,
        "current_positions": [p for p in current_positions if p["currency"] == currency],
        "simulated_positions": [p for p in final_positions if p["currency"] == currency],
        "before": base_metrics,
        "after": after_metrics,
        "change": _metrics_change(base_metrics, after_metrics),
        "raw_before": base_raw,
        "raw_after": after_raw,
    }


def run_portfolio_simulation_compare(
    client_id: str,
    client_secret: str,
    *,
    adjustments: Optional[List[Dict[str, Any]]] = None,
    new_trades: Optional[List[Dict[str, Any]]] = None,
    base_url: str = DEFAULT_BASE_URL,
) -> Dict[str, Any]:
    try:
        current_positions = fetch_current_positions_for_simulation(
            client_id,
            client_secret,
            currencies=list(SUPPORTED_CURRENCIES),
            base_url=base_url,
        )

        known_instruments = fetch_btc_instruments(kind=None, expired=False, base_url=base_url)

        validation_errors = []
        validation_errors.extend(validate_adjustments(current_positions, adjustments))
        validation_errors.extend(validate_new_trades(new_trades, known_instruments=known_instruments))

        if validation_errors:
            return {
                "ok": False,
                "errors": validation_errors,
                "current_positions": current_positions,
                "simulated_positions": [],
                "results_by_currency": {},
            }

        adjusted = apply_position_adjustments(current_positions, adjustments)
        priced_new_trades = attach_entry_prices_from_quotes(new_trades, base_url=base_url)
        final_positions = merge_new_simulated_trades(adjusted, priced_new_trades)

        client = DeribitClient(client_id, client_secret, base_url=base_url)
        results_by_currency: Dict[str, Any] = {}

        for currency in SUPPORTED_CURRENCIES:
            has_current = any(p["currency"] == currency for p in current_positions)
            has_final = any(p["currency"] == currency for p in final_positions)
            if not has_current and not has_final:
                continue

            results_by_currency[currency] = _run_single_currency_compare(
                client,
                currency=currency,
                current_positions=current_positions,
                final_positions=final_positions,
            )

        return {
            "ok": True,
            "errors": [],
            "current_positions": current_positions,
            "simulated_positions": final_positions,
            "priced_new_trades": priced_new_trades,
            "results_by_currency": results_by_currency,
        }

    except Exception as exc:
        return {
            "ok": False,
            "errors": [str(exc)],
            "current_positions": [],
            "simulated_positions": [],
            "results_by_currency": {},
            "raw_error": repr(exc),
        }


# ---------------------------------------------------------------------------
# Convenience helpers
# ---------------------------------------------------------------------------

def fetch_mm_im_only_summary(client_id: str, client_secret: str, *, base_url: str = DEFAULT_BASE_URL) -> Dict[str, Any]:
    client = DeribitClient(client_id, client_secret, base_url=base_url)
    out: Dict[str, Any] = {}

    for currency in SUPPORTED_CURRENCIES:
        raw = client.private_call("private/simulate_portfolio", {"currency": currency, "add_positions": True})
        metrics = _extract_simulation_metrics(raw)
        out[currency] = {
            "im_pct": metrics.get("im_pct"),
            "mm_pct": metrics.get("mm_pct"),
            "raw": raw,
        }

    return out


def find_option_instrument(
    *,
    expiry_timestamp: int,
    strike: float,
    option_type: str,
    base_url: str = DEFAULT_BASE_URL,
) -> Optional[str]:
    option_type_normalized = _normalize_option_type(option_type)
    if option_type_normalized is None:
        raise ValueError("option_type must be call/C or put/P")

    instruments = fetch_btc_instruments(kind="option", expired=False, base_url=base_url)
    for inst in instruments:
        if int(inst.get("expiration_timestamp") or 0) != int(expiry_timestamp):
            continue

        inst_strike = _safe_float(inst.get("strike"), 0.0)
        if abs(inst_strike - float(strike)) > 1e-12:
            continue

        inst_type = _normalize_option_type(inst.get("option_type")) or _option_type_from_instrument_name(inst.get("instrument_name", ""))
        if inst_type == option_type_normalized:
            return str(inst.get("instrument_name") or "")

    return None



from dotenv import load_dotenv
load_dotenv()

import json
import os
from pathlib import Path


def save_json(name: str, data):
    """
    Save JSON debug output to ./debug_simulation/
    """
    out_dir = Path("debug_simulation")
    out_dir.mkdir(exist_ok=True)

    path = out_dir / f"{name}.json"

    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, default=str)

    print(f"Saved -> {path}")


if __name__ == "__main__":

    CLIENT_ID = os.getenv("DERIBIT_CLIENT_ID")
    CLIENT_SECRET = os.getenv("DERIBIT_CLIENT_SECRET")

    if not CLIENT_ID or not CLIENT_SECRET:
        raise RuntimeError("Missing DERIBIT_CLIENT_ID / DERIBIT_CLIENT_SECRET")

    print("\n===== SIMULATION TEST START =====\n")

    # -------------------------------------------------
    # 1 Fetch positions
    # -------------------------------------------------

    current_positions = fetch_current_positions_for_simulation(
        CLIENT_ID,
        CLIENT_SECRET,
    )

    save_json("01_current_positions", current_positions)

    # -------------------------------------------------
    # 2 Fetch instruments
    # -------------------------------------------------

    instruments = fetch_btc_instruments(kind=None, expired=False)

    save_json("02_btc_instruments", instruments)

    # -------------------------------------------------
    # 3 Option chain data
    # -------------------------------------------------

    chain = get_option_chain_selection_data()

    save_json("03_option_chain", chain)

    # -------------------------------------------------
    # 4 Quote
    # -------------------------------------------------

    quote = fetch_instrument_quote("BTC-PERPETUAL")

    save_json("04_quote", quote)

    # -------------------------------------------------
    # 5 Recent trades
    # -------------------------------------------------

    trades = fetch_recent_trades("BTC-PERPETUAL", 5)

    save_json("05_recent_trades", trades)

    # -------------------------------------------------
    # 6 IM / MM summary
    # -------------------------------------------------

    margin_summary = fetch_mm_im_only_summary(
        CLIENT_ID,
        CLIENT_SECRET,
    )

    save_json("06_margin_summary", margin_summary)

    # -------------------------------------------------
    # 7 Adjustments test
    # -------------------------------------------------

    test_adjustments = []

    if current_positions:
        p = current_positions[0]

        test_adjustments.append(
            {
                "instrument_name": p["instrument_name"],
                "action": "decrease",
                "amount": float(p["size"]) * 0.25,
            }
        )

    errors = validate_adjustments(current_positions, test_adjustments)

    save_json("07_adjustment_errors", errors)

    adjusted_positions = apply_position_adjustments(
        current_positions,
        test_adjustments,
    )

    save_json("08_adjusted_positions", adjusted_positions)

    # -------------------------------------------------
    # 8 New trades test
    # -------------------------------------------------

    test_new_trades = [
        {
            "instrument_name": "BTC-PERPETUAL",
            "side": "long",
            "amount": 100,
        }
    ]

    trade_errors = validate_new_trades(
        test_new_trades,
        known_instruments=instruments,
    )

    save_json("09_new_trade_errors", trade_errors)

    priced_trades = attach_entry_prices_from_quotes(test_new_trades)

    save_json("10_priced_new_trades", priced_trades)

    merged_positions = merge_new_simulated_trades(
        adjusted_positions,
        priced_trades,
    )

    save_json("11_merged_positions", merged_positions)

    # -------------------------------------------------
    # 9 Build simulation map
    # -------------------------------------------------

    sim_map = build_simulated_positions_map(
        merged_positions,
        "BTC",
    )

    save_json("12_simulated_positions_map", sim_map)

    # -------------------------------------------------
    # 10 Direct simulation
    # -------------------------------------------------

    try:
        btc_sim = simulate_portfolio_state(
            simulated_positions_map=sim_map,
            client_id=CLIENT_ID,
            client_secret=CLIENT_SECRET,
            currency="BTC",
            add_positions=False,
        )

        save_json("13_direct_simulation", btc_sim)

    except Exception as e:
        save_json("13_direct_simulation_error", {"error": str(e)})

    # -------------------------------------------------
    # 11 Full compare simulation
    # -------------------------------------------------

    compare = run_portfolio_simulation_compare(
        CLIENT_ID,
        CLIENT_SECRET,
        adjustments=test_adjustments,
        new_trades=test_new_trades,
    )

    save_json("14_full_compare_simulation", compare)

    print("\n===== SIMULATION TEST COMPLETE =====")