# shared/trade_recap_service.py
#
# Delegates to the new trade_recap module for all trade reconstruction.
# Kept as a thin wrapper so existing imports continue to work.

import logging

from trade_recap.service import (
    get_trade_recap,
    save_trade_comment,
    init_db,
    ingest,
    get_summary,
    export_debug_snapshot,
)

logger = logging.getLogger(__name__)

__all__ = [
    "get_trade_recap",
    "save_trade_comment",
    "init_db",
    "ingest",
    "get_summary",
    "export_debug_snapshot",
]
