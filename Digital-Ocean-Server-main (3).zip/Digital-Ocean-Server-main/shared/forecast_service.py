# shared/forecast_store.py (or wherever your DB helpers live)

import sqlite3
from typing import Optional, Tuple
from datetime import datetime, timezone
import json
from multi_agent_system.runner_db_helper import build_forecast_line_safe
from shared.db_paths import SNAPSHOTS_DB

# ``forecast_messages`` lives in the snapshots DB. We expose it under the
# legacy ``DB_PATH`` name so any downstream importer that grabbed
# ``DB_PATH`` from this module keeps working without changes.
DB_PATH = SNAPSHOTS_DB
print(f"[DB] Using {DB_PATH} in {__file__}", flush=True)
def _utc_day_key(dt: Optional[datetime] = None) -> str:
    dt = dt or datetime.now(timezone.utc)
    return dt.strftime("%Y-%m-%d")

def ensure_forecast_tables(con: sqlite3.Connection) -> None:
    cur = con.cursor()
    cur.execute("""
    CREATE TABLE IF NOT EXISTS forecast_messages (
        day_utc TEXT PRIMARY KEY,
        message_text TEXT NOT NULL,
        payload_json TEXT,              -- optional: store the full forecast_obj if you want
        updated_at_utc TEXT NOT NULL
    )
    """)
    cur.execute("CREATE INDEX IF NOT EXISTS idx_forecast_messages_updated ON forecast_messages(updated_at_utc)")
    con.commit()

def upsert_forecast_message(
    con: sqlite3.Connection,
    *,
    day_utc: Optional[str] = None,
    message_text: str,
    payload_json: Optional[str] = None,
    updated_at_utc: Optional[str] = None,
) -> None:
    day_utc = day_utc or _utc_day_key()
    updated_at_utc = updated_at_utc or datetime.now(timezone.utc).isoformat()

    cur = con.cursor()
    cur.execute("""
    INSERT INTO forecast_messages(day_utc, message_text, payload_json, updated_at_utc)
    VALUES(?, ?, ?, ?)
    ON CONFLICT(day_utc) DO UPDATE SET
        message_text=excluded.message_text,
        payload_json=excluded.payload_json,
        updated_at_utc=excluded.updated_at_utc
    """, (day_utc, message_text, payload_json, updated_at_utc))
    con.commit()

def get_forecast_message_today(con: sqlite3.Connection) -> Tuple[Optional[str], Optional[str]]:
    day_utc = _utc_day_key()
    cur = con.cursor()
    cur.execute("""
    SELECT message_text, updated_at_utc
    FROM forecast_messages
    WHERE day_utc = ?
    """, (day_utc,))
    row = cur.fetchone()
    if not row:
        return None, None
    return row[0], row[1]

def get_latest_forecast_message(con: sqlite3.Connection) -> Tuple[Optional[str], Optional[str], Optional[str]]:
    cur = con.cursor()
    cur.execute("""
    SELECT day_utc, message_text, updated_at_utc
    FROM forecast_messages
    ORDER BY updated_at_utc DESC
    LIMIT 1
    """)
    row = cur.fetchone()
    if not row:
        return None, None, None
    return row[0], row[1], row[2]



def refresh_forecast_message(
    *,
    db_path: str = "",
    store_full_payload: bool = False,
) -> Tuple[str, Optional[str]]:
    """
    Returns: (message_text, updated_at_utc)
    Raises only on hard DB errors; forecast failures return "" and do not upsert.

    The ``db_path`` parameter is retained for backward compatibility but
    is no longer consulted: forecast messages live in ``SNAPSHOTS_DB``
    and the upstream forecast builder owns its own DB choice.
    """
    msg = build_forecast_line_safe()
    msg = (msg or "").strip()
    if not msg:
        return "", None

    con = sqlite3.connect(str(SNAPSHOTS_DB))
    try:
        ensure_forecast_tables(con)
        upsert_forecast_message(
            con,
            message_text=msg,
            payload_json=None if not store_full_payload else json.dumps({"message": msg}),
        )
        # read back updated_at for UI (optional)
        cur = con.cursor()
        cur.execute("SELECT updated_at_utc FROM forecast_messages WHERE day_utc = strftime('%Y-%m-%d','now')")
        row = cur.fetchone()
        return msg, (row[0] if row else None)
    finally:
        con.close()
        
        
def get_forecast_message(con: sqlite3.Connection) -> Tuple[Optional[str], Optional[str], Optional[str]]:
    """
    Returns: (message, updated_at_utc, note)
    note is None unless we fall back to latest row.
    """
    ensure_forecast_tables(con)

    msg, updated = get_forecast_message_today(con)
    if msg:
        return msg, updated, None

    day_latest, msg_latest, updated_latest = get_latest_forecast_message(con)
    if msg_latest:
        return msg_latest, updated_latest, f"Showing latest saved forecast ({day_latest})"

    return None, None, None


def get_today_forecast_message() -> Tuple[Optional[str], Optional[str], Optional[str]]:
    """
    Returns: (message_today_or_latest, updated_at, note)
    """
    con = sqlite3.connect(str(SNAPSHOTS_DB))
    try:
        return get_forecast_message(con)
    finally:
        con.close()