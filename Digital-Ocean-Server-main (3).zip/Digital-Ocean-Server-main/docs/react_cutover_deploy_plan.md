# React Cutover Deployment Plan

Goal: replace the Streamlit dashboard with the React SPA on the Digital Ocean
server. Streamlit code stays on disk as a backup but is removed from Docker
Compose and from git tracking. The public domain (Caddy) routes traffic to the
React container instead of Streamlit.

Topology after cutover:

```
Internet ──► Caddy (host) ──► btc_react:80   (SPA + /api + /ws reverse-proxied)
                                ├── /api/  ──► btc_api:8000
                                └── /ws/   ──► btc_backend_ws:8100
```

Backend containers (api, backend_ws, ws_collector, worker, realtime,
mm_alert, simple_hedge_engine, portfolio_analysis_*) keep running unchanged.

---

## Phase 0 — Prep (local, before touching the server)

- [ ] Confirm `git status` is clean except for the in-progress migration
      changes. Decide whether to commit the migration first or bundle with the
      cutover commit.
- [ ] Sanity-check the React build locally:
      ```powershell
      cd React
      npm ci
      npm run build
      ```
      Build should finish with no TS errors. Note bundle size for the PR.
- [ ] Confirm `React/nginx.conf` still proxies `/api/` → `api:8000` and
      `/ws/` → `backend_ws:8100` (it does, as of this commit).
- [ ] Confirm every page that is still set `migrated: false` in
      [pageMap.ts](../React/src/lib/pageMap.ts) is intentional (those pages are
      hidden from the sidebar and render the placeholder if visited directly).

## Phase 1 — Decide the rollout shape

Pick one:

**Option A — Hard cutover (recommended).** Remove the `streamlit` service from
`docker-compose.yml` in the same commit that flips Caddy to React. Streamlit
files stay on disk locally as a backup but are git-ignored.

**Option B — Soft cutover.** Keep `streamlit` running on `127.0.0.1:8501`
alongside React for one week. Caddy still points the public domain at React;
operators reach Streamlit via SSH tunnel only. Drop the service after the
soak.

Option A is simpler and what the rest of this doc assumes. If you pick B,
skip the "remove streamlit service" step in Phase 3 for now.

## Phase 2 — Stop tracking Streamlit in git (keep files on disk)

The `Streamlit/` directory currently has tracked files. We want to **stop
tracking them without deleting them locally**.

- [ ] Add to [.gitignore](../.gitignore) (append near the top-level project
      sections):
      ```
      ########################################
      # Streamlit (legacy — kept locally as backup, not deployed)
      ########################################
      /Streamlit/
      ```
- [ ] Remove from the index but keep on disk:
      ```powershell
      git rm -r --cached Streamlit
      ```
- [ ] Verify `git status` shows only deletions under `Streamlit/` and the
      `.gitignore` change. The folder still exists on your filesystem.
- [ ] Commit:
      ```
      chore: stop tracking Streamlit (kept locally as backup, React is now the dashboard)
      ```

> Note: this commit only stops tracking. The next phase removes Streamlit
> from the running deployment.

## Phase 3 — Edit `docker-compose.yml`

- [ ] Delete the entire `streamlit:` service block
      ([docker-compose.yml](../docker-compose.yml) lines 74–95).
- [ ] Confirm the `react:` service block is correct (it is, as of this commit
      — see [docker-compose.yml](../docker-compose.yml) lines 127–136). It
      builds from `./React`, exposes `127.0.0.1:8502:80`, and depends on
      `api` + `backend_ws`.
- [ ] Optional hardening for the `react:` service:
      ```yaml
          depends_on:
            api:
              condition: service_healthy
            backend_ws:
              condition: service_healthy
          healthcheck:
            test: ["CMD", "wget", "-qO-", "http://localhost/"]
            interval: 30s
            timeout: 5s
            retries: 3
            start_period: 10s
      ```
- [ ] Commit:
      ```
      chore(deploy): remove streamlit service from compose; react is the dashboard
      ```

## Phase 4 — Server prep (SSH onto the box)

- [ ] SSH in: `ssh root@<server>`.
- [ ] `cd /opt/btc_app/app` (or wherever the repo lives — verify with
      `docker inspect btc_api | jq '.[0].Config.Labels'` or check the running
      compose dir).
- [ ] Confirm the working tree is clean: `git status`. If there are local
      tweaks, stash or commit them first.
- [ ] Pull the cutover commits: `git pull --ff-only`.
- [ ] Confirm `.env` is present and has every variable the backend needs.
      Nothing React-specific needs to be added (the SPA reads from the same
      origin via the nginx proxy).

## Phase 5 — Build and start React, stop Streamlit

Order matters — bring up React first so there's no window where the public
domain has nowhere to land.

- [ ] Build the React image on the server:
      ```bash
      docker compose build react
      ```
- [ ] Start it (and ensure api/backend_ws are healthy):
      ```bash
      docker compose up -d api backend_ws react
      ```
- [ ] Verify the container is healthy:
      ```bash
      docker ps --filter name=btc_react
      curl -fsS http://127.0.0.1:8502/ | head -20
      curl -fsS http://127.0.0.1:8502/api/healthz
      ```
      The first should return HTML, the second the API health JSON (proves
      the nginx → api proxy works).
- [ ] Stop and remove the streamlit container (only if Phase 3 removed it
      from compose; otherwise just `docker compose stop streamlit`):
      ```bash
      docker compose stop streamlit
      docker compose rm -f streamlit
      ```

## Phase 6 — Flip Caddy to React

The host-level `Caddyfile` is git-ignored (see [.gitignore](../.gitignore)
line 134). It lives on the server, typically at `/etc/caddy/Caddyfile` or
`/opt/btc_app/Caddyfile`. Find it:

```bash
sudo find / -name Caddyfile 2>/dev/null
```

- [ ] Back up the current Caddyfile:
      ```bash
      sudo cp /etc/caddy/Caddyfile /etc/caddy/Caddyfile.bak.$(date +%Y%m%d)
      ```
- [ ] Edit the site block. The existing config likely reverse-proxies the
      public domain to `127.0.0.1:8501` (Streamlit). Change it to
      `127.0.0.1:8502` (React). Streamlit's nginx-in-container already
      handles `/api/` and `/ws/` so a single `reverse_proxy` line is enough:
      ```caddy
      your.domain.com {
          reverse_proxy 127.0.0.1:8502
      }
      ```
      If WebSocket upgrades aren't already working through Caddy, add the
      upgrade headers (Caddy v2 handles this automatically for `reverse_proxy`,
      so usually nothing extra is needed).
- [ ] Validate and reload:
      ```bash
      sudo caddy validate --config /etc/caddy/Caddyfile
      sudo systemctl reload caddy
      ```
- [ ] Smoke-test from your laptop:
      ```
      https://your.domain.com/                   → React login page
      https://your.domain.com/api/healthz        → 200 OK
      ```
      Open DevTools → Network → confirm the `/ws/...` connection upgrades to
      `101 Switching Protocols`.

## Phase 7 — Functional smoke test (operator + viewer)

Log in as an **operator** account and walk each migrated page; confirm no
500s in the API logs and no console errors:

- [ ] Account Overview — KPIs render, staleness banner not stuck.
- [ ] Positions History — table populated, filters work.
- [ ] BTC Prices — chart renders, time-range buttons work.
- [ ] Decision Board.
- [ ] WS Layer Health — green dots, last-message timestamps tick.
- [ ] Hedge Engine.
- [ ] MM / IM Simulator.
- [ ] RTI Portfolio Management.
- [ ] Portfolio Analysis Bot.
- [ ] Live Options Scheduler.
- [ ] MM Alerts.
- [ ] Trading Fees — "Sync now" returns OK.
- [ ] LLM Cost — date filters, stacked area renders.
- [ ] User Management — visible only to operator; add/edit user round-trip
      works; self-edit role/active inputs are disabled with the amber banner.

Then log in as a **viewer** and confirm:

- [ ] Sidebar hides User Management.
- [ ] Sidebar hides any pages the viewer doesn't have grants for.
- [ ] No locked/coming-soon entries appear (we removed those).

Tail logs in another terminal:
```bash
docker compose logs -f --tail=200 api backend_ws react
```

## Phase 8 — Cleanup

- [ ] Remove the old streamlit image to reclaim disk:
      ```bash
      docker image prune -f
      ```
- [ ] If you used Option A, the Streamlit code is now neither tracked nor
      deployed. The `Streamlit/` folder still exists locally as a reference
      — leave it.
- [ ] Update [MIGRATION_PROGRESS.md](../React/MIGRATION_PROGRESS.md): mark
      §9 "deploy" complete and note the cutover date.
- [ ] Tag the release on the server side for easy rollback:
      ```bash
      git tag -a react-cutover-$(date +%Y%m%d) -m "React replaces Streamlit"
      git push origin --tags
      ```

## Rollback (if something is broken on prod)

Fast path — point Caddy back at Streamlit (assumes Option B, or that the
streamlit image still exists locally on the server):

```bash
# Restore Caddyfile
sudo cp /etc/caddy/Caddyfile.bak.YYYYMMDD /etc/caddy/Caddyfile
sudo systemctl reload caddy

# Bring Streamlit back up
docker compose up -d streamlit
```

If Streamlit was already removed from compose (Option A), check out the
pre-cutover commit and `docker compose up -d streamlit` from there:

```bash
git log --oneline | head -5          # find the commit before cutover
git checkout <sha> -- docker-compose.yml
docker compose up -d streamlit
```

Investigate from logs (`docker compose logs api backend_ws react`) and the
browser console before re-attempting.

---

## Quick reference

| What                  | Where                                             |
| --------------------- | ------------------------------------------------- |
| React build context   | [React/](../React/)                               |
| React Dockerfile      | [React/Dockerfile](../React/Dockerfile)           |
| In-container nginx    | [React/nginx.conf](../React/nginx.conf)           |
| Host reverse proxy    | `/etc/caddy/Caddyfile` (git-ignored)              |
| Compose file          | [docker-compose.yml](../docker-compose.yml)       |
| API service           | `btc_api` on `127.0.0.1:8000`                     |
| WS service            | `btc_backend_ws` on `127.0.0.1:8100`              |
| React service         | `btc_react` on `127.0.0.1:8502`                   |
| Streamlit (legacy)    | was `btc_streamlit` on `127.0.0.1:8501`           |
