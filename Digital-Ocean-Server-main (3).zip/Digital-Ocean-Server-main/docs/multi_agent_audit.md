# Multi-Agent System - Known Weaknesses (Code Audit)

Companion document to [multi_agent_system.md](multi_agent_system.md).
Lists concrete technical debt, bugs, and fragility risks uncovered in a
full scan of `multi_agent_system/`. Each row points at `file:line` so
the finding can be verified directly.

> **Note on file:line references.** Line numbers reflect the repository
> state at the time of the audit and drift as code changes. When a line
> reference no longer resolves, search for the symbol/function name
> listed alongside it.

Severity:
- **HIGH** - correctness / security / data-integrity risk.
- **MEDIUM** - reliability or operational pain.
- **LOW** - stylistic or latent.

---

## 1. Top-priority (HIGH) findings

| # | Area | File:Line | Issue |
|---|---|---|---|
| 1 | LLM contract | `Sentiment_agent.py:247-290` | **`build_llm_prompt` is the Fundamental agent's prompt copy-pasted**: system line says *"You are the BTC Fundamental Agent"*, `agent` field is `"fundamental"`, inputs listed are `macro_now/7D/30D + on_chain + supply` - the Sentiment agent never actually sends funding / OI / X / F&G data to its LLM. |
| 2 | Bug | `Sentiment_agent.py:211` | Rule baseline reads `n["x_score"]`, but `normalize_inputs` only produces `x_score_now / 7d / 30d` - the X-sentiment rule branch either `KeyError`s or never fires. |
| 3 | Bug | `multi_agents.py:835-847` | `open_with_margin_list = []` is defined locally then immediately iterated - the entire **TOP 10 OPEN IDEAS** CSV block is dead code and writes only headers. The same empty list is then passed to `save_open_trades_daily`, so `open_trades` DB saves are always empty. |
| 4 | Bug | `multi_agents.py:170-172` (Structurer) | LLM-returned `quantity ≤ 0` is silently coerced to `1` instead of rejecting the row - can *inflate* positions if the Structurer hallucinates. |
| 5 | Bug | `multi_agents.py:509` | In the no-LLM `else` branch, `total_cost += close_cost` is computed, but the successful LLM branch above never adds `close_cost` to `total_cost` → cost accounting under-reports. |
| 6 | Bug | `mm_enricher.py:54-58` | `raw_qty = 1` hard-coded; the subsequent `if raw_qty is None` check is unreachable. Every MM-estimate trade is simulated at qty=1 regardless of requested size. |
| 7 | Bug | `btc_price.py:86-91` | `CREATE TABLE btc_daily(...)` DDL is missing the closing `)` and `;` - raises `sqlite3.OperationalError` if this path is hit. |
| 8 | Portability | `multi_agents.py:714`, `close_engine.py:45, 610`, `config.py:32` | `MODEL_OUTPUT_DIR` / `DEFAULT_DATA_DIR` default to `/data` - breaks on Windows dev unless the env var is set. |
| 9 | Concurrency | `Sentiment_agent.py:46-58` (`_persist_oi`) | Local JSON cache `.sentiment_cache/oi_btc.json` is read-then-written without a lock; two parallel model runs clobber each other and produce a bogus "24h OI delta". |
| 10 | Financial correctness | `Sentiment_agent.py:102-115` | The `oi_24h_delta` field is really "delta since the last pipeline invocation" (could be minutes) - the 24h naming misleads downstream weighting. |
| 11 | Financial correctness | `Valuation_agent.py:21-52`, `multi_agents.py:247-252` | `POP = 1 − |delta|` baked into the pipeline. This ignores IV, time-value, and risk-neutral adjustments - acceptable as a shortcut, but shouldn't be called *probability of profit*. |
| 12 | Financial correctness | `close_engine.py:197-202, 370-377` | Short-option "in-range danger" hard-coded at `spot ≥ 0.97·strike` (CALL) / `spot ≤ 1.03·strike` (PUT). A fixed 3% band is far too tight for 90+ DTE contracts and far too loose for 1-DTE weeklies - no vol / DTE scaling. The same constants also leak into the LLM prompt. |
| 13 | External source | `fundemantal_agent.py:53`, `sentiment.py:61` | `http://feeds.reuters.com/reuters/topNews` was **deprecated by Reuters in 2020–2021** and returns 404/redirect - every run wastes a network attempt with no signal. |
| 14 | External source | `sentiment.py:63, 67`, `fundemantal_agent.py:54` | Bloomberg RSS feeds (`/crypto/rss`, `/markets/economics/rss`) are paywall-gated and actively block non-browser user agents - they carry `SOURCE_WEIGHTS` up to 1.12 but usually contribute zero items. |
| 15 | Performance | `sentiment.py` RSS loop, `fundemantal_agent.py:59-75` | **RSS fetches are sequential**: 8 feeds × 2–12s timeout per feed can add up to 40–90s per run. No `ThreadPoolExecutor` / `asyncio.gather`. |
| 16 | Performance | `sentiment.py:131-143` | FinBERT `pipeline(...)` is (re-)loaded inside `get_macro_sentiment_score` on **every call** - ~1–3s + ~500MB RAM churn per invocation. No module-level cache. |
| 17 | Performance | `open_scenarios.py:273-301` | Default `max_candidates=50_000` random bundles + `preselect_k=1000` Deribit `simulate_portfolio` calls per run → **near-certain rate limit** and long pipeline latency. Pipeline currently passes smaller values (10_000 / 500) but defaults remain dangerous. |
| 18 | Concurrency | `persistence.py`, `sentiment.py:156-167, 863` | `sqlite3.connect(..., check_same_thread=False)` with ad-hoc `DELETE + INSERT` under `BEGIN IMMEDIATE;` that is **not wrapped in a clean try/commit** - on exception the transaction can stay open and lock subsequent writers. |
| 19 | Error handling | `sentiment.py:878-881` | `conn.close()` in `finally` where `conn` was assigned *inside* the preceding `try` - if `sqlite3.connect()` raised, the `finally` itself raises `NameError`, masking the original error. |
| 20 | Observability | entire package | **Zero unit tests** for agents, validators, close engine, scenario search, or POP math. No integration tests for the Deribit margin paths. |
| 21 | Observability | `Sentiment_agent.py:41`, `btc_price.py:22-29`, `stage_1.py:30`, `deribit_access.py:22-29`, `config.py:60-67` | Multiple modules call `logging.basicConfig(...)` at import time, each overriding the previous handler - final log format depends on import order. |
| 22 | Integrity | `multi_agents.py:126-175` (Structurer) | Structurer LLM output is never **diff-checked** against the LOCKED CLOSE/HOLD + OPEN legs it was given. A model that drops a symbol or flips a field produces a silently incorrect final decision set. |
| 23 | Integrity | `decision_parsing.py:163-167, 222` | `validate_decisions` drops invalid rows with a single aggregated warning - no per-row JSON captured, so operators can't tell *what* the LLM got wrong. |
| 24 | LLM failure mode | `fundemantal_agent.py:394-396` | LLM schema errors + any exception in the LLM block are caught by a broad `except Exception` that silently returns the rule baseline with `cost=0` - violations never surface in monitoring. |
| 25 | Config | `multi_agents.py:67-73` | Comments explicitly mark these as *"for testing"*: `OPEN_QTY_GRID_EVEN`, `OPEN_MM_CAP_PCT=70`, `OPEN_MAX_CANDIDATES_FOR_MM=25`. They run in production without env overrides. |

## 2. MEDIUM findings

| Area | File:Line | Issue |
|---|---|---|
| Bug | `Sentiment_agent.py:363` | After parsing the LLM JSON, `parsed["horizon_days"] = 10` silently overrides whatever the LLM returned (and the prompt itself demands `15`). |
| Bug | `fundemantal_agent.py:324-327` | Baseline `key_signals` is built as a *tuple of two lists* rather than a flat list - violates the agent's own schema; `validate_agent_output` would reject it. |
| Bug | `multi_agents.py:978-999` | The "no decisions" Telegram branch is placed inside the `else:` of the CSV-send flag, so the fallback message only fires when CSV-send is **disabled**, then re-reads the same flag with default `"0"` to decide whether to actually send - logic inversion. |
| Bug | `runner.py:34` | `setup_console_logging(logging.INFO)` runs at **import time**, mutating the root logger globally and conflicting with `config.py`'s `force=True` basicConfig. |
| Financial | `close_engine.py:188, 207-216` | `pnl_pct` and `DTE` are parsed from the free-text `positions_text` via regex (`close_engine.py:188`). Any format drift in `format_positions_for_llm` silently breaks take-profit / short-danger rules. |
| Financial | `config.py:100-111, 311-317, 359-372` | `MAX_MARGIN`, `MIN_POP`, `DAYS_AHEAD`, `MIN_VEGA_THRESHOLD` and `CFG` thresholds are hard-coded at module load - no volatility, capital, or strategy scaling. |
| External source | `fundemantal_agent.py:80-91` | Blockchain.com Charts JSON shape (`values[].y`) is assumed stable; no schema or version check. Any upstream change quietly nulls out the on-chain section. |
| External source | `Sentiment_agent.py:84-89` | Funding-rate key probe iterates `("funding_8h", "interest_8h", "funding_rate")` - the first non-null wins, but Deribit historically returns multiple of these with different meanings. |
| Performance | `llm_io.py:733-739`, `multi_agents.py:372-398, 458` | Every LLM call rebuilds a fresh LangChain client (`_build_openai_model(int(request_timeout))`), defeating HTTP connection reuse. `make_llm_client` is called at least 3× per pipeline. |
| Performance | `Deribit_margin.py:547` | Global `_DERIBIT_SIM_LOCK` serializes simulate calls within a process - unavoidable for rate limits but also blocks the `run_all_models` concurrent path. |
| Error handling | `multi_agents.py:509` cost path | See HIGH #5 - cost accounting bug. |
| Error handling | `fundemantal_agent.py:63-75`, `Sentiment_agent.py:57-58, 69` | Bare `except Exception:` with no structured logging in RSS and Deribit helpers - persistent failures degrade silently. |
| Error handling | `Sentiment_agent.py:16, 17, 20`, `fundemantal_agent.py:10-21`, `sentiment.py:16` | Wildcard `from .x import *` in multiple modules hides symbol provenance and risks shadowing. |
| Concurrency | `snapshot_pipeline.py:87-92`, `persistence.py:84-159` | Shared state writes without `BEGIN IMMEDIATE` or row-level locks; parallel model runs can race on the DB. |
| Concurrency | `Deribit_margin.py:419, 544-547` | Per-process globals track last-sim timestamps; two runner processes still hammer Deribit in parallel and hit error `10028` (too many requests). |
| LLM contract | `close_engine.py:488` vs `multi_agents.py:135-142` | `run_close_hold_llm_agent` uses `temperature=0.05`, Structurer uses `0.0`; determinism is inconsistent across stages. |
| LLM contract | `llm_io.py:423-431, 655-665` | For GPT-5, payload forces `"reasoning": {"effort": "low"}` and drops `max_tokens`; two factories use different `"verbosity"` values (`"low"` vs `"medium"`) - two behaviors depending on code path. |
| LLM contract | `decision_parsing.py:151-161, 190` | Schema validation silently drops rows with invalid `action/side/right`; `quantity` is clamped to `max(1, int(...))` with no error on non-numeric. |
| Security | `llm_io.py:505` | `raise LLMError(f"HTTP {resp.status_code}: {resp.text[:800]}")` - leaks up to 800 chars of upstream response (may contain echoed API inputs) into logs. |
| Security | `account_flows_ingestion.py:38-39` | `sqlite3.connect(db_path)` without `timeout=` - concurrent writers can busy-wait with default 5s and raise `OperationalError: database is locked`. |
| Observability | codebase-wide | Mixed `print(...)` / `logging.info(...)` / `logger.info(...)` (e.g. `Sentiment_agent.py:414`, `llm_io.py:527`, `delete_last_row_x.py`). Any structured log aggregator will miss the `print` lines. |
| Config | `config.py:32-33, 21` | `DEPLOYMENT_ROOT = Path(__file__).resolve().parents[1]` ties the layout to a 2-deep folder structure; moving the module breaks `.env` discovery. `IS_DOCKER` detection via `/.dockerenv` is brittle. |
| Config | `config.py:359-372` | `CFG` and `RISK_RULES` - no env override, no per-strategy switch, unclear sign convention on `max_vega_allowed = -8500.0` (no unit comment). |
| Config | `historical_context_agent.py:79-84` | `OPEN_TRADES_TABLE_MAP` keys by human-readable label (`"GPT-5"`, `"Claude 4 Sonnet"`) - renaming a model in the UI silently breaks history joins. |

## 3. LOW findings (stylistic / latent)

- `fundemantal_agent.py:151-167` - `check_requirements` defined twice (shadowing).
- `fundemantal_agent.py:355` - `if not (0.0 < c <= 1.0)` rejects a legitimate `confidence == 0.0`.
- `fundemantal_agent.py:409` - Param typo `marco_7D`; caller happens to match.
- `fundemantal_agent.py:415` - `macro_now = macro_now` no-op.
- `multi_agents.py:235` - `row.get("average_price_usd", row.get("average_price_usd", ...))` - same key twice.
- `multi_agents.py:468` - `qty = int(abs(sz)) if float(abs(sz)).is_integer() else int(round(abs(sz)))` - identical branches, silently drops fractional contracts.
- `inference_pop_calibrated.py:259-263` - Two consecutive `reindex(columns=REQUIRED_FEATS, ...)` calls, second overrides first.
- `delete_last_row_x.py` - Destructive SQLite helper with no confirmation or role check.
- `Sentiment_agent.py:38, 189` - `Bias = Literal[...]` redeclared.
- `runner.py:17` vs `runner.py:98` - Duplicate import paths at module and function scope.
- `persistence.py:139` - `hasattr(pd, "isna") if ... else False` - dead check (`pd.isna` always exists).
- `fundemantal_agent.py:124` - Halving countdown uses constant `avg_block_minutes = 10.0`; ignores recent block-time drift.
- `config.py:110-111` - Crucial thresholds only configurable via env; no documentation of legal ranges.

## 4. Thematic summary

Cutting across the list, the four patterns most worth addressing first:

1. **The Sentiment Agent's LLM is running the wrong prompt.** It is effectively a second Fundamental Agent with the wrong input schema. Fixing this in isolation will materially change the bias stream feeding CLOSE/HOLD and OPEN Selector.
2. **Hidden data loss through silent fallbacks.** Validators, LLM error handlers, and Telegram branches swallow errors into a blanket rule baseline or empty list without surfacing a counter or alert. Operators cannot see when the LLM is silently bypassed.
3. **The pipeline's "facts" often aren't.** `POP`, `oi_24h_delta`, the 0.97/1.03 in-range band, and `avg_block_minutes=10` are all *named* as if they were exact measures but are approximations with no confidence interval or warning label attached.
4. **The "locked" guarantee is advisory, not enforced.** The LOCKED text blocks *tell* the Structurer not to change anything, but nothing in code verifies the Structurer's output equals its inputs. A single rogue LLM call could drop or invent a decision and the rest of the pipeline would happily persist it.

Each of the items above is a small, local change - none require a re-architecture - but together they would meaningfully improve correctness, observability, and portability of the multi-agent system.
