# DB Connection Refactor Plan

Companion to `docs/db_split_rollback_plan.md` and
`scripts/migrate_split_databases.py`. This document describes the
**code-level** changes that need to follow the data split.

> Status: planning only. No application code is modified in this step.

## Current problem

Roughly twenty modules open `data/btc_trading.sqlite` directly - either
via a hard-coded relative path or via per-module `DB_PATH` constants
that all happen to point at the same monolith. Symptoms:

- All domains compete for the same SQLite writer lock, so a slow
  `account_snapshots` write can stall a `fee_events` insert.
- A schema change for one domain forces a backup of the entire monolith.
- Restoring after a corruption incident means restoring everything.
- It's hard to reason about which module owns which table.

The split into domain-specific databases solves this, but only if
modules stop opening the monolith directly.

## New DB ownership map

| Target DB | Owning modules | Tables |
| --- | --- | --- |
| `data/trading.sqlite` | `trade_recap/db.py`, `backend_api/db/fees_repo.py`, `multi_agent_system/account_flows_ingestion.py`, `shared/data_service.py` (for `trade_log` only) | `transaction_log`, `trade_recap_comments`, `trade_log`, `fee_events`, `account_flows` |
| `data/snapshots.sqlite` | `shared/data_service.py`, `shared/forecast_service.py` | `account_snapshots`, `positions_snapshots`, `vol_metrics_snapshots`, `worker_status`, `forecast_messages` |
| `data/market_data.sqlite` | `multi_agent_system/btc_price.py`, `multi_agent_system/btc_ohlcv.py`, `multi_agent_system/btc_options.py`, `multi_agent_system/sentiment.py` | `btc_daily`, `btc_prices`, `deribit_current_positions_daily`, `macro_daily` |
| `data/hedge_engine.sqlite` | `hedge_engine/core/snapshot_builder.py`, `hedge_engine/data/state_store.py` | `hedge_engine_*_ticks`, `hedge_engine_state`, `hedge_ticks`, `ml_regime_ticks`, `ml_vol_ticks`, `hedge_decisions_log` |
| `data/models.sqlite` | `multi_agent_system/runner_db_helper.py`, `multi_agent_system/historical_context_agent.py`, `multi_agent_system/multi_agents_lib/persistence.py` | `x_score`, `strategy_text_store`, `model_run_meta`, `model_quality_daily`, `MM_IM`, `decisions_*_multi_agent`, `open_trades_*` |
| `data/infra.sqlite` | `backend_api/jobs.py`, `backend_api/mm_alert_config_store.py`, `simple_hedge/config_store.py` | `api_jobs`, `scheduler_config`, `scheduler_state`, `mm_alert_config`, `simple_hedge_config`, `simple_hedge_log` |
| `data/auth.sqlite` | `shared/auth/db.py` | `streamlit_users` |
| `data/decision_board.sqlite` (already separate) | `decision_board/db.py`, `decision_board/repository.py` | `decisions`, `decision_actions`, `decision_comments`, `decision_event_log` |

Note: `shared/data_service.py` is the one module that legitimately needs
references to **two** new DBs - `trade_log` belongs in `trading.sqlite`
while the snapshot tables belong in `snapshots.sqlite`. The cleanest fix
is to move the `trade_log` accessors into a new helper that imports from
`trading.sqlite`, leaving the rest pointing at `snapshots.sqlite`.

## Modules requiring DB-path updates

| File | New target |
| --- | --- |
| [trade_recap/db.py](../trade_recap/db.py) | `TRADING_DB_PATH` |
| [backend_api/db/fees_repo.py](../backend_api/db/fees_repo.py) | `TRADING_DB_PATH` |
| [multi_agent_system/account_flows_ingestion.py](../multi_agent_system/account_flows_ingestion.py) | `TRADING_DB_PATH` |
| [shared/data_service.py](../shared/data_service.py) | `SNAPSHOTS_DB_PATH` (split out `trade_log` to `TRADING_DB_PATH`) |
| [shared/forecast_service.py](../shared/forecast_service.py) | `SNAPSHOTS_DB_PATH` |
| [multi_agent_system/btc_price.py](../multi_agent_system/btc_price.py) | `MARKET_DATA_DB_PATH` |
| [multi_agent_system/btc_ohlcv.py](../multi_agent_system/btc_ohlcv.py) | `MARKET_DATA_DB_PATH` |
| [multi_agent_system/btc_options.py](../multi_agent_system/btc_options.py) | `MARKET_DATA_DB_PATH` |
| [multi_agent_system/sentiment.py](../multi_agent_system/sentiment.py) | `MARKET_DATA_DB_PATH` |
| [hedge_engine/core/snapshot_builder.py](../hedge_engine/core/snapshot_builder.py) | `HEDGE_ENGINE_DB_PATH` |
| [hedge_engine/data/state_store.py](../hedge_engine/data/state_store.py) | `HEDGE_ENGINE_DB_PATH` |
| [multi_agent_system/runner_db_helper.py](../multi_agent_system/runner_db_helper.py) | `MODELS_DB_PATH` |
| [multi_agent_system/historical_context_agent.py](../multi_agent_system/historical_context_agent.py) | `MODELS_DB_PATH` |
| [multi_agent_system/multi_agents_lib/persistence.py](../multi_agent_system/multi_agents_lib/persistence.py) | `MODELS_DB_PATH` |
| [backend_api/jobs.py](../backend_api/jobs.py) | `INFRA_DB_PATH` |
| [backend_api/mm_alert_config_store.py](../backend_api/mm_alert_config_store.py) | `INFRA_DB_PATH` |
| [simple_hedge/config_store.py](../simple_hedge/config_store.py) | `INFRA_DB_PATH` |
| [shared/auth/db.py](../shared/auth/db.py) | `AUTH_DB_PATH` |

Indirect importers (e.g. `backend_api/settings.py` which exposes
`DB_PATH`, and `multi_agent_system/config.py` which defines the
canonical `DB_PATH`) should be updated to re-export the new constants
from the central module rather than continuing to expose a single
`DB_PATH`.

## Recommended: central DB-path module

Create `shared/db_paths.py` so every consumer imports from one place.
This is also what `scripts/migrate_split_databases.py` aligns with.

```python
# shared/db_paths.py
from __future__ import annotations

import os
from pathlib import Path

PROJECT_ROOT: Path = Path(__file__).resolve().parents[1]


def _resolve_data_dir() -> Path:
    env_value = os.environ.get("DB_BASE_DIR")
    if env_value:
        return Path(env_value).expanduser().resolve()
    return (PROJECT_ROOT / "data").resolve()


DATA_DIR: Path = _resolve_data_dir()
DATA_DIR.mkdir(parents=True, exist_ok=True)

OLD_MONOLITH_DB_PATH: Path = DATA_DIR / "btc_trading.sqlite"

TRADING_DB_PATH:       Path = DATA_DIR / "trading.sqlite"
SNAPSHOTS_DB_PATH:     Path = DATA_DIR / "snapshots.sqlite"
MARKET_DATA_DB_PATH:   Path = DATA_DIR / "market_data.sqlite"
HEDGE_ENGINE_DB_PATH:  Path = DATA_DIR / "hedge_engine.sqlite"
MODELS_DB_PATH:        Path = DATA_DIR / "models.sqlite"
INFRA_DB_PATH:         Path = DATA_DIR / "infra.sqlite"
DECISION_BOARD_DB_PATH: Path = DATA_DIR / "decision_board.sqlite"
AUTH_DB_PATH:          Path = DATA_DIR / "auth.sqlite"
```

Why a single module:

- One place to override paths in tests (monkeypatch `DATA_DIR`).
- One place to honour `DB_BASE_DIR` for Docker / cron / CI.
- Rollback to the monolith becomes a one-line change (point all paths at
  `OLD_MONOLITH_DB_PATH`).

## Suggested rollout order

1. **Land this plan + migration script** (no app changes). ← *current PR*
2. **Add `shared/db_paths.py`** and migrate the easiest leaf modules
   first (e.g. `trade_recap/db.py`, `backend_api/jobs.py`,
   `simple_hedge/config_store.py`). These have a single owner per table
   and are low-risk.
3. **Migrate `multi_agent_system/*`** - these share `multi_agent_system/config.DB_PATH`,
   so update `config.py` to re-export the new constants and migrate
   modules one by one.
4. **Migrate `hedge_engine/*`** in a single PR (snapshot_builder and
   state_store are coupled).
5. **Split `shared/data_service.py`** - move `trade_log` accessors into a
   `shared/trading_log.py` (or similar) wired to `TRADING_DB_PATH`; keep
   the rest on `SNAPSHOTS_DB_PATH`.
6. **Move `shared/auth/db.py`** to `AUTH_DB_PATH` (only meaningful if
   `streamlit_users` was actually present in the monolith - the migration
   script reports this).
7. **Final pass**: grep for `btc_trading.sqlite` and any remaining
   per-module `DB_PATH` constants and remove them.

After each step, run:

```bash
python scripts/migrate_split_databases.py --verify-only
pytest tests/test_migrate_split_databases.py
```

## Risk notes

- **Two writers, one file** is fine in SQLite, but **one writer per
  domain DB** is the whole point of the split. Make sure no module ends
  up holding a connection to two DBs in the same transaction - there is
  no cross-DB transaction guarantee.
- **`ATTACH DATABASE`** is tempting for cross-DB queries; avoid it in
  application code. If a query genuinely needs two DBs, do two queries
  and join in Python.
- **Cron / Docker**: the new `shared/db_paths.py` must be importable by
  every entrypoint. If you have any scripts that set `sys.path`
  manually, add them to the migration checklist.
- **Tests**: any test that opened the monolith directly will need to be
  updated to point at the relevant new DB (or to monkeypatch
  `shared.db_paths.DATA_DIR`).
