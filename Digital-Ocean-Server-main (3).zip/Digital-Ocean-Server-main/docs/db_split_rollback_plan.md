# DB Split - Rollback Plan

This document describes how to safely roll back the database split
performed by `scripts/migrate_split_databases.py`.

## Guiding principle

**The old monolithic database `data/btc_trading.sqlite` is never modified
or deleted by the migration.** The migration only **copies** data into
new files. Rolling back is therefore primarily a code-level change
(pointing modules back at the monolith), not a data restore.

## Files involved

| Path | Role |
| --- | --- |
| `data/btc_trading.sqlite`                  | Original monolith - source of truth, untouched. |
| `data/trading.sqlite`                      | New: trading events. |
| `data/snapshots.sqlite`                    | New: portfolio snapshots and forecast text. |
| `data/market_data.sqlite`                  | New: market data ingestion. |
| `data/hedge_engine.sqlite`                 | New: hedge engine state and ticks. |
| `data/models.sqlite`                       | New: model outputs and dynamic decision tables. |
| `data/infra.sqlite`                        | New: jobs, schedulers, alert config. |
| `data/auth.sqlite`                         | New: streamlit users (only if migrated). |
| `data/decision_board.sqlite`               | Already separate - never touched. |
| `data/backups/db_split/<UTC_TIMESTAMP>/`   | Per-run backup of any pre-existing target DB files. |
| `logs/db_split_migration.log`              | Append-only run log. |
| `logs/db_split_migration_report.json`      | Machine-readable report from the most recent run. |

## Rollback at the code level (preferred)

If the application is misbehaving after the refactor, the fastest
rollback is to stop reading from the new DBs and read from the monolith
instead. Concretely:

1. Stop the app (API container, workers, Streamlit).
2. In `shared/db_paths.py` (once introduced - see
   `docs/db_connection_refactor_plan.md`), temporarily point all per-domain
   constants at the monolith:
   ```python
   TRADING_DB_PATH      = OLD_MONOLITH_DB_PATH
   SNAPSHOTS_DB_PATH    = OLD_MONOLITH_DB_PATH
   MARKET_DATA_DB_PATH  = OLD_MONOLITH_DB_PATH
   HEDGE_ENGINE_DB_PATH = OLD_MONOLITH_DB_PATH
   MODELS_DB_PATH       = OLD_MONOLITH_DB_PATH
   INFRA_DB_PATH        = OLD_MONOLITH_DB_PATH
   AUTH_DB_PATH         = OLD_MONOLITH_DB_PATH  # only if it was migrated
   ```
   Or, if the refactor PR is the suspected cause: revert it.
3. Restart the app. It will read/write the monolith again.

This works because the migration is a copy. Any writes that landed in the
new DBs after cutover need to be reconciled (see
"Re-syncing writes after partial cutover" below).

## Restoring a target DB from backup

Each `--execute` run creates `data/backups/db_split/<UTC_TIMESTAMP>/`
containing copies of the target DB files (and any `-wal` / `-shm`
siblings) **as they existed before that run**.

To restore one:

```bash
# 1. Stop the app so nothing is holding the file open.
# 2. Replace the live DB with the backup.
cp data/backups/db_split/<UTC_TIMESTAMP>/trading.sqlite data/trading.sqlite
# Repeat for any other DBs you need to roll back.
# 3. Restart the app.
```

On Windows PowerShell:

```powershell
Copy-Item "data\backups\db_split\<UTC_TIMESTAMP>\trading.sqlite" "data\trading.sqlite" -Force
```

If you need to discard the new DBs entirely and rerun the migration from
scratch:

```bash
rm data/trading.sqlite data/snapshots.sqlite data/market_data.sqlite \
   data/hedge_engine.sqlite data/models.sqlite data/infra.sqlite
python scripts/migrate_split_databases.py --execute
```

The monolith is not affected.

## Validation commands

After any rollback or re-migration, verify row counts match between the
monolith and the new DBs.

Built-in (recommended):

```bash
python scripts/migrate_split_databases.py --verify-only
```

This runs `SELECT COUNT(*)` on every expected table in both source and
target and exits non-zero if any mismatch is found.

Ad-hoc with the `sqlite3` CLI:

```bash
# source
sqlite3 data/btc_trading.sqlite "SELECT COUNT(*) FROM transaction_log;"
# target
sqlite3 data/trading.sqlite     "SELECT COUNT(*) FROM transaction_log;"
```

Repeat per table you care about. The full table list lives in
`scripts/migrate_split_databases.py` (`TABLE_GROUPS`).

## Re-syncing writes after a partial cutover

If the app was already writing to the new DBs (e.g. live for a few hours)
and you then roll back to the monolith, those writes are stranded in the
new DBs. Options:

1. **Cheapest**: accept the small data gap and resume on the monolith.
2. **Replay**: open both DBs, identify rows in the new DB whose primary
   key is not in the monolith, and `INSERT` them into the monolith. Most
   of the affected tables use timestamp- or auto-id-based primary keys, so
   `INSERT OR IGNORE` is usually safe - but check each table's schema
   before doing this and take a manual `cp` backup of the monolith first.
3. **Re-run cutover**: fix the issue, run the migration again with
   `--execute --overwrite` (which will back up the new DBs first), and
   restart the app pointing at the new DBs.

## Emergency steps if the app fails after refactor

1. **Snapshot everything first** (do this before any other action):
   ```bash
   ts=$(date -u +%Y%m%d_%H%M%S)
   mkdir -p data/backups/emergency/$ts
   cp data/*.sqlite* data/backups/emergency/$ts/
   ```
2. **Capture logs**: copy `logs/db_split_migration.log` and the latest
   `logs/db_split_migration_report.json` somewhere safe.
3. **Roll back code**: revert the refactor PR (or hard-code DB paths back
   to the monolith as shown above) and redeploy.
4. **Restart app** and confirm functionality on the monolith.
5. **Diagnose offline** using the snapshots and the JSON report - do not
   re-run the migration against production until the root cause is
   understood.

## Pre-flight checklist (before running `--execute` in production)

- [ ] App is stopped, or at least the writers (workers, schedulers) are
      paused, so no new rows land in the monolith mid-copy.
- [ ] Free disk space ≥ 2× the size of `data/btc_trading.sqlite`.
- [ ] You've taken a manual `cp` snapshot of `data/btc_trading.sqlite` -
      defence in depth, even though the script will not modify it.
- [ ] You've run `--dry-run` and reviewed the output.
- [ ] If target DBs already exist from a previous attempt, you've decided
      whether to use `--overwrite` (replaces tables, backs up first) or
      delete them first.
- [ ] After `--execute`, run `--verify-only` and confirm zero validation
      errors.
