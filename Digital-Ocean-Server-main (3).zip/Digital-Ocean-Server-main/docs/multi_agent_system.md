# Multi-Agent System - BTC Options Decision Pipeline

This document describes how the multi-agent decision pipeline in
`multi_agent_system/` works end-to-end: what each agent does, which
inputs/outputs it produces, how it calls the LLMs, and how the final
OPEN/CLOSE/HOLD decisions are assembled, margin-checked against Deribit,
and persisted.

The orchestration entry point is `run_multi_agent_pipeline()` in
[multi_agents.py](multi_agent_system/multi_agents.py). The runner
(`runner.py`) is a thin wrapper that prepares inputs (positions, BTC
price, capital, strategy text, forecast, macro & X scores) and calls that
pipeline for a chosen model.

> **Companion doc:** known bugs, tech debt, and fragility risks live in
> [multi_agent_audit.md](multi_agent_audit.md) so this file stays focused
> on how the pipeline is designed to work.

---

## TL;DR

- **Inputs:** live Deribit options chain, current positions, account
  equity, BTC index price, precomputed macro/X scores, a TA summary,
  and a strategy text block.
- **Output:** a JSON list of OPEN / CLOSE / HOLD decisions, projected
  MM/IM before vs. after, a CSV at `/data/final_runs/`, an optional
  Telegram delivery, and DB rows in the per-model decisions table.
- **LLM calls per run:** up to 5 - Fundamental, Sentiment, CLOSE/HOLD
  finalizer, OPEN selector, Structurer. All at `temperature ∈ {0.0,
  0.05}`, all with schema-validated JSON output.
- **Guarantees:** the LLMs never compute margin (Deribit
  `simulate_portfolio` is the ground truth), never invent symbols or
  quantities (whitelist + `positions_side_qty` enforcement), and a
  rule-only fallback always produces a conservative answer if any LLM
  or remote source fails.
- **Safety rail:** every OPEN scenario is rejected unless Deribit-
  simulated `MM% ≤ 70%` (target ≈63%).

---

## Table of contents

1. [High-level architecture](#1-high-level-architecture)
2. [Stage-by-stage walkthrough](#2-stage-by-stage-walkthrough)
   - 2.0 [Pre-stage: account flows + TA summary](#20-pre-stage-account-flows--ta-summary)
   - 2.1 [Fundamental Agent](#21-fundamental-agent--fundemantal_agentpy)
   - 2.2 [Sentiment Agent](#22-sentiment-agent--sentiment_agentpy)
   - 2.3 [Valuation Agent](#23-valuation-agent--valuation_agentpy)
   - 2.4 [Deribit baseline snapshot](#24-deribit-baseline-snapshot)
   - 2.5 [CLOSE/HOLD engine](#25-closehold-engine--multi_agents_libclose_enginepy)
   - 2.6 [OPEN engine](#26-open-engine--multi_agents_libopen_scenariospy)
   - 2.7 [Structurer LLM](#27-structurer-llm--multi_agentspy-run_structurer_llm)
   - 2.8 [Final portfolio MM/IM](#28-final-portfolio-mmim-after-open)
   - 2.9 [Enrichment](#29-enrichment)
   - 2.10 [Export (CSV + Telegram)](#210-export-csv--telegram)
   - 2.11 [DB persistence](#211-db-persistence)
   - 2.12 [Return value](#212-return-value)
3. [Supporting modules](#3-supporting-modules)
4. [Agents vs. engines: who has authority](#4-agents-vs-engines-who-has-authority-over-what)
5. [Key constants and knobs](#5-key-constants-and-knobs)
6. [Running the pipeline](#6-running-the-pipeline)
7. [Consolidated data-source map](#7-consolidated-data-source-map-fundamental--sentiment)
8. [Prompt contracts and schemas](#8-prompt-contracts-and-schemas)
9. [Valuation - Phase-1 filter details](#9-valuation-agent--phase-1-filter-details)
10. [CLOSE / OPEN rule math](#10-close--open-rule-math-quick-reference)
11. [Outputs you can inspect](#11-outputs-you-can-inspect-after-a-run)
12. [Failure modes and fallbacks](#12-failure-modes-and-fallbacks)
13. [Example outputs](#13-example-outputs)
14. [Debugging a run](#14-debugging-a-run)
15. [Known weaknesses (pointer)](#15-known-weaknesses-code-audit)
16. [End-to-end data flow at a glance](#16-end-to-end-data-flow-at-a-glance)

Known issues and code-audit findings: see
[multi_agent_audit.md](multi_agent_audit.md).

---

## 1. High-level architecture

The pipeline is a **staged agent chain**. Agents are not independent
workers talking over a bus - they are sequential stages where the
output of one becomes the input (context) of the next. Determinism
comes first; the LLM is used as a *final decision authority* with
strict guardrails (JSON schemas, whitelist symbols, locked decisions,
and Deribit-simulated margin caps).

```
             ┌──────────────────────────────┐
             │  0) Sync Deribit account     │
             │     flows + TA summary       │
             └───────────────┬──────────────┘
                             │
       ┌─────────────────────┼─────────────────────┐
       ▼                     ▼                     ▼
 ┌──────────┐         ┌──────────┐           ┌──────────┐
 │ 1) FUND. │         │ 2) SENT. │           │ 3) VAL.  │
 │  Agent   │         │  Agent   │           │  Agent   │
 │  (LLM)   │         │  (LLM)   │           │(deterministic│
 │          │         │          │           │  Phase-1)│
 └────┬─────┘         └────┬─────┘           └────┬─────┘
      │  bias/conf text    │ bias/conf text       │ filtered options DF
      │                    │                      │
      └──────────┬─────────┴──────────┬───────────┘
                 ▼                    ▼
        ┌─────────────────────────────────────────┐
        │ 4) Deribit BASELINE IM/MM snapshot      │
        └───────────────────┬─────────────────────┘
                            ▼
        ┌─────────────────────────────────────────┐
        │ 5) CLOSE/HOLD engine (Options only)     │
        │   5a) Deterministic rules (Take-profit, │
        │       short-ITM-near-expiry, MM excep.) │
        │   5b) LLM finalizer (override only in   │
        │       documented emergencies) → LOCKED  │
        │   5c) Deribit simulate_portfolio for    │
        │       BEFORE/AFTER-close MM/IM/greeks   │
        └───────────────────┬─────────────────────┘
                            ▼
        ┌─────────────────────────────────────────┐
        │ 6) OPEN engine                          │
        │   6a) Build OPEN candidates from        │
        │       valuation_df (eligible==1)        │
        │   6b) generate_mm_acceptable_open_      │
        │       scenarios → SCN_* bundles that    │
        │       PASS strict MM-cap Deribit sim    │
        │   6c) LLM selector picks ONE SCN_*      │
        │       or NONE                           │
        │   6d) simulate_mm_im_after_open         │
        └───────────────────┬─────────────────────┘
                            ▼
        ┌─────────────────────────────────────────┐
        │ 7) STRUCTURER LLM                       │
        │   Merges LOCKED CLOSE/HOLD + LOCKED     │
        │   OPEN → final JSON decisions           │
        │   (no thinking, no rewriting)           │
        └───────────────────┬─────────────────────┘
                            ▼
        ┌─────────────────────────────────────────┐
        │ 8) FINAL Deribit simulate_portfolio     │
        │    AFTER close + allocation             │
        └───────────────────┬─────────────────────┘
                            ▼
        ┌─────────────────────────────────────────┐
        │ 9) Enrich decisions (POP/avg/mark/BTC)  │
        │ 10) CSV export + Telegram send          │
        │ 11) DB persist (model decisions, open   │
        │     trades, MM_IM snapshot)             │
        └─────────────────────────────────────────┘
```

Each numbered stage below maps directly to the sections 0–11 inside
`run_multi_agent_pipeline()` in
[multi_agents.py](multi_agent_system/multi_agents.py).

---

## 2. Stage-by-stage walkthrough

### 2.0 Pre-stage: account flows + TA summary

Before anything else, the pipeline calls
[account_flows_ingestion.sync_account_flows](multi_agent_system/account_flows_ingestion.py)
to pull deposits / withdrawals / transfers (BTC, USDT, USDC, last 90d)
from Deribit so the **Historical Context PnL** consumed downstream is
fresh, and calls
[btc_ta_summary.get_btc_ta_summary](multi_agent_system/btc_ta_summary.py)
to produce a technical-analysis text block (trend, RSI, Ichimoku,
Fibonacci zones) used later by the Fundamental and Sentiment prompts.

### 2.1 Fundamental Agent - `fundemantal_agent.py`

Purpose: collapse macro + on-chain + headlines + TA into a single
`bias ∈ {bullish, bearish, neutral}` with confidence.

File: [fundemantal_agent.py](multi_agent_system/fundemantal_agent.py)

#### 2.1.1 Exact input sources

**A. Macro scores (`macro_now`, `macro_7D`, `macro_30D` ∈ [-1, 1])**

These are *precomputed upstream* by
`sentiment.get_macro_sentiment_scores_llm()` in
[sentiment.py:547](multi_agent_system/sentiment.py) and passed into the
Fundamental Agent via the runner. The score itself is built from the
following concrete sources:

| Source | URL | Weight |
|---|---|---|
| Federal Reserve press releases | `https://www.federalreserve.gov/feeds/rss` | 1.10 |
| Reuters Top News † | `http://feeds.reuters.com/reuters/topNews` | 1.15 |
| WSJ / Dow Jones Markets | `https://feeds.a.dj.com/rss/RSSMarketsMain.xml` | 1.10 |
| Bloomberg Economics † | `https://www.bloomberg.com/markets/economics/rss` | 1.12 |
| Bloomberg Crypto † | `https://www.bloomberg.com/crypto/rss` | 1.00 |
| Yahoo Finance | `https://finance.yahoo.com/news/rssindex` | 0.95 |
| CoinDesk | `https://www.coindesk.com/arc/outboundfeeds/rss/` | 0.90 |
| Cointelegraph | `https://cointelegraph.com/rss` | 0.85 |

> † Known-broken at time of writing: Reuters `topNews` was retired
> in 2020–2021 and returns 404/redirect; Bloomberg feeds are paywall-
> gated and block non-browser user agents. Both stay in the code so
> the weighting still sums, but they typically contribute zero items.
> See [multi_agent_audit.md §1 HIGH-13/14](multi_agent_audit.md#1-top-priority-high-findings).

Each headline is scored for *macro/crypto relevance* using two keyword
lexicons (crypto terms: `bitcoin, btc, satoshi, crypto, cryptocurrency,
ethereum, eth, blockchain, etf, spot etf, halving, hashrate, miners,
lightning`; macro terms: `inflation, cpi, ppi, pce, fed, federal
reserve, powell, interest rate, rate hike, rate cut, dot plot, qe, qt,
yields, treasury, jobs, nfp, unemployment, manufacturing, ism, gdp,
recession, liquidity, volatility, market breadth`). Only items with
relevance ≥ `min_relevance=0.15` are kept (max 600 articles total, max
300 per source, 2 days back).

Relevant headlines are scored with:
- Primary model: **FinBERT** (`ProsusAI/finbert`, HuggingFace
  `text-classification`, device = GPU if available else CPU,
  truncation at 512 tokens).
- Fallback model: **VADER** (`vaderSentiment`) if Torch/Transformers
  aren't importable.
- Final fallback: an LLM-based aggregation in
  `get_macro_sentiment_scores_llm` (provider/model from runner;
  defaults `openai / gpt-5-mini`).

Final weighting combines source weight × relevance × time-decay with
`half_life_hours=24`. The three horizons (`score_now`, `score_7d`,
`score_30d`) are persisted per run into SQLite table `macro_daily`
(`asof_utc, sentence, score_now, score_7d, score_30d, model_provider,
model_id, features_json, meta_json`). Save mode is controlled by env
`MACRO_SAVE_MODE` = `override` (default) | `skip`.

**B. Technical analysis summary (`ta_summary`)**

Produced by `get_btc_ta_summary()` in
[btc_ta_summary.py](multi_agent_system/btc_ta_summary.py), which reads
the `btc_prices` SQLite table (populated by
[btc_price.py](multi_agent_system/btc_price.py) /
[btc_ohlcv.py](multi_agent_system/btc_ohlcv.py) - Deribit BTC daily
candles) and computes:
- **EMAs** 21 / 50 / 200 → trend direction.
- **RSI(14)** → overbought / neutral / oversold label.
- **Ichimoku cloud** (Tenkan, Kijun, Senkou A/B) → above/below/inside
  cloud.
- **Fibonacci retracements** (0.382, 0.5, 0.618, 1.0, 1.272, 1.618)
  over a 200-day swing window → nearest support/resistance band.

The output is a single short sentence like:

> "As of 2025-11-25 close 87,906: uptrend (price above EMA200 and EMA50,
> EMA21 > EMA50), RSI 62 (neutral-high), price above Ichimoku cloud,
> near 1.618 Fib resistance (~90,500)."

**C. RSS headlines (titles only)** - a *lightweight, independent* RSS
pass inside the Fundamental Agent itself (`fetch_rss_headlines()`),
separate from the macro-score RSS pass:

- `https://www.coindesk.com/arc/outboundfeeds/rss/`
- `https://cointelegraph.com/rss`
- `https://www.federalreserve.gov/feeds/rss`
- `https://feeds.a.dj.com/rss/RSSMarketsMain.xml`
- `http://feeds.reuters.com/reuters/topNews`
- `https://www.bloomberg.com/crypto/rss`

Window: last 36h. Up to 50 titles per feed, trimmed to ≤ 200 titles
total, each title ≤ 1024 chars. No sentiment scoring here - titles are
passed verbatim to the LLM for qualitative context.

#### How RSS Fetching Works (feedparser)

**What is an RSS feed?** RSS (Really Simple Syndication) is a standard
XML format that publishers expose at a stable URL. Each feed contains
an ordered list of recent articles with structured metadata - title,
summary, link, author, publication date - so consumers can read new
items without scraping the publisher's HTML.

**What `feedparser.parse(url)` does internally:**

1. Performs an HTTP GET against the URL (with sensible default headers
   and gzip/deflate handling).
2. Reads the XML response body (supports RSS 0.9x/1.0/2.0 and Atom).
3. Parses the XML tree into a normalized Python object regardless of
   which dialect the feed uses.
4. Returns a `FeedParserDict` where `feed.entries` is the list of
   articles and each entry exposes fields like `title`, `summary`,
   `link`, `published`, `published_parsed` (a time-struct tuple), and
   `updated_parsed`.

**Small example:**

```python
import feedparser

feed = feedparser.parse(url)
for entry in feed.entries:
    print(entry.title)
```

In this project, the agents read `entry.title` and
`entry.published_parsed` (or `entry.updated_parsed` as a fallback), then
filter by a UTC time window and keyword relevance before passing the
surviving items to FinBERT / VADER / the LLM. No HTML parsing and no
headless browser is involved - `feedparser` is pure-Python and handles
the HTTP fetch and XML decoding in a single call.

**D. On-chain basics (Blockchain.com Charts API, free, no key)**

`fetch_on_chain_basics()` pulls the latest value (last 14 days window)
from `https://api.blockchain.info/charts/<slug>?timespan=14days&format=json`
for:

| Slug | Field in payload |
|---|---|
| `hash-rate` | `hash_rate` → converted TH/s → EH/s (divide by 1e6) |
| `estimated-transaction-volume-usd` | `tx_volume` (USD) |
| `n-unique-addresses` | `active_addresses` (count) |

**E. Supply context (`fetch_supply_context()`)**

- `https://blockchain.info/q/getblockcount` → current block height
  (plain-text integer).
- `https://api.blockchain.info/charts/total-bitcoins?...` → circulating
  supply (BTC).
- `days_to_halving` = `ceil((next_halving_block − height) × 10 min /
  (60 × 24))` with `HALVING_INTERVAL = 210,000`.

All on-chain endpoints have a 12-second request timeout and fail
silently (`None`) so the agent can always run.

Flow (`run_fundamental` → `run_fundamental_agent`):
1. `pull_fundamental_inputs()` aggregates all inputs.
2. `check_requirements()` - if `macro_now` missing, returns a safe
   neutral/low-confidence baseline (no LLM call).
3. `normalize_inputs()` adds units (hash rate TH/s→EH/s) and `asof_utc`.
4. Rule-only baseline: `macro_to_bias_confidence()` maps
   `0.65*now + 0.35*0.5*(7D+30D)` → bias/confidence with same-sign
   boost / disagreement penalty.
5. If `use_llm=True`: build the schema-first prompt
   (`build_llm_prompt`), call the client returned by
   `llm_io.make_llm_client(provider, model)`, parse JSON, clamp
   confidence to `[0,1]`, attach LLM token usage and USD cost to
   `metrics`. On schema errors, fall back to the rule baseline with a
   soft red-flag.
6. Persist both `inputs.json` and `fundamental_decision.json` to
   `fundamental_runs/<model>_<UTC ts>/`.

Enforced decision rules the prompt hands the LLM:
- `score ≥ +0.15 ⇒ bullish`, `≤ -0.15 ⇒ bearish`, else neutral.
- Same-sign trend confirmation boosts confidence (+0.10, cap 0.95);
  disagreement drops it (−0.10, floor 0.05) and adds
  `CONFLICTING_SIGNALS` red-flag.
- `horizon_days` is fixed to 15.

Output: `(result_dict, cost_usd)`. The dict follows a strict schema
(`agent=fundamental`, `bias`, `confidence`, `horizon_days`, `rationale`,
`key_signals`, `red_flags`, `recommendations`, `metrics`).
`format_fundamental_for_llm()` (in
[multi_agents_lib/formatting.py](multi_agent_system/multi_agents_lib/formatting.py))
compresses it into a one-line "pipe-separated" string that downstream
agents consume.

### 2.2 Sentiment Agent - `Sentiment_agent.py`

Purpose: produce a `bias / confidence` from **market-structure and
crowd** signals rather than macro/news ones.

File: [Sentiment_agent.py](multi_agent_system/Sentiment_agent.py)

#### 2.2.1 Exact input sources

**A. Deribit funding rate (BTC-PERPETUAL, 8-hour)**

Public REST base: `https://www.deribit.com/api/v2`.

Primary call: `/public/get_funding_rate_history` with:
```
instrument_name = "BTC-PERPETUAL"
start_timestamp = now - 2 days (ms)
end_timestamp   = now (ms)
count           = 200
include_old     = True
```
From the last row the agent reads the first non-null of
`funding_8h`, `interest_8h`, `funding_rate`.

Fallback call: `/public/get_funding_rate_value` for the last 9h.

Normalization: `funding_bps_8h = funding × 10_000`, rounded to 3
decimals. A *deadband* flag is set if `|funding_bps_8h| ≤ 1.5`
(≤0.015% per 8h → treated as noise).

**B. Deribit options Open Interest (BTC, all option instruments)**

`/public/get_book_summary_by_currency` with `currency=BTC,
kind=option`. The agent sums `open_interest` across every returned row
→ `oi_now` (BTC).

The previous `oi_now` from the last run is persisted to
`.sentiment_cache/oi_btc.json` (`{ts, oi_now}`) and read back on the
next run to compute `oi_24h_delta = oi_now − oi_prev`. If the file
doesn't exist yet, `oi_24h_delta` is `None` on first run.

**C. Fear & Greed Index**

`https://api.alternative.me/fng/?limit=1&format=json` → extracts
`{value: int, classification: str}`. 12-second timeout; on failure the
field is dropped.

**D. X / Twitter sentiment (precomputed, stored in SQLite)**

Passed into `run_sentiment()` as `x_score_now`, `x_score_7D`,
`x_score_30D`, `x_sentence`. These are loaded by `get_x_for_run()` in
[runner_db_helper.py](multi_agent_system/runner_db_helper.py) from the
SQLite table `x_score` (columns `date, score_now, score_7d, score_30d,
x_sentiment_sentence`). The runner selects the row whose `date` =
today (UTC), falling back to the most recent row with a warning.

The `x_score` table itself is populated outside the multi-agent
pipeline by a separate ingestion job (see `mm_alert_bot` / `backend_api`
jobs) that collects BTC-related posts and produces scores in `[-1, 1]`.

**E. Technical analysis summary (`ta_summary`)**

Identical to the Fundamental Agent (see §2.1.1 B) - the same
`get_btc_ta_summary()` output is handed to both agents so their
interpretations share a common technical view.

#### 2.2.2 Rule baseline and LLM path

Rule baseline (`sentiment_to_bias_conf`):
- Funding > +1.5 bps/8h → `+0.4` (signal tag `funding_pos`), < −1.5 bps
  → `−0.4` (`funding_neg`).
- OI delta up → `+0.2` (`oi_up`), down → `−0.2` (`oi_down`).
- X score > +0.15 → `+0.25` (`x_pos`); < −0.15 → `−0.25` (`x_neg`).
- Fear & Greed value ≥ 70 → `+0.05` (`fg_greedy`); ≤ 30 → `−0.05`
  (`fg_fear`).
- Sum → `score`. Map to bias:
  - `score ≥ +0.25` → **bullish**, `conf = 0.45 + min(0.45, score)`.
  - `score ≤ −0.25` → **bearish**, `conf = 0.45 + min(0.45, −score)`.
  - else **neutral**, `conf = 0.35 + 0.3 · |score| / 0.25`.
  - `conf` capped at 0.9.

If `use_llm=True`, the agent calls the LLM with a JSON-schema prompt
asking for the same schema (`agent`, `bias`, `confidence`,
`horizon_days=10`, `rationale`, `key_signals`, `red_flags`,
`recommendations`, `metrics`). Call config: `temperature=0`,
`max_tokens=5000`, `retries=3`, `request_timeout=300s`. On parse
failure, returns a conservative baseline with an `LLM_ERROR` red-flag
and zero cost.

Outputs are persisted under
`sentiment_runs/<model>_<UTC ts>/{inputs.json, sentiment_decision.json}`
and handed to downstream agents via `format_sentiment_for_llm()`, which
renders the dict as a compact pipe-separated line such as:

```
bias:bullish | horizon_days:10 | key_signals:funding-pos,oi-up,x-pos | confidence:0.78 | rationale:... | recs:...
```

### 2.3 Valuation Agent - `Valuation_agent.py`

Purpose: turn the live options universe into a **candidate slate** the
OPEN agent is allowed to pick from. No LLM here - fully deterministic.

File: [Valuation_agent.py](multi_agent_system/Valuation_agent.py)

Pipeline inside `run_valuation_filter_with_pop`:
1. `_apply_phase1_filters()` wraps `stage_1.phase1_screen_and_rank`
   (see [stage_1.py](multi_agent_system/stage_1.py)), which applies
   deterministic screening and ranking (DTE windows, OI/volume
   thresholds, spread %, Vega-bucket diversification, POP/edge ranking,
   capital/MM-cap budgets). Returns a ranked DataFrame with an
   `eligible` column.
2. `_exclude_positions_from_candidates()` - removes instruments that
   are already in the current book.
3. `_ensure_pop()` - computes `POP = clip(1 − |delta|, 0, 1)`.
4. `_ensure_basic_derivatives()` - ensures `DTE`, `mid_price`,
   `spread_pct`, `iv_spread_abs`, `moneyness`.

Output `valuation_df` is filtered to `eligible == 1` inside
`run_multi_agent_pipeline` before being handed to the OPEN engine and
converted into context text with
`format_valuation_for_llm_from_out()`.

### 2.4 Deribit baseline snapshot

Immediately before the CLOSE engine, the pipeline takes a baseline
`im_before_run`, `mm_before_run`, and `mm_pct_start` from
`account_info` (preferring `per_currency.BTC.margin_balance`,
falling back to top-level `margin_balance`, then `equity`). These
numbers anchor all later delta computations.

### 2.5 CLOSE/HOLD engine - `multi_agents_lib/close_engine.py`

Purpose: decide per-position CLOSE or HOLD for **options only**.
Perpetuals and dated futures are `HOLD` by policy and never reach the
LLM. The engine is two-pass: **deterministic first, LLM finalizer
second**.

File: [multi_agents_lib/close_engine.py](multi_agent_system/multi_agents_lib/close_engine.py)

#### 2.5a Deterministic pass - `run_close_hold_deterministic`

- Parses `positions_text` to extract per-symbol `pnl_pct` and `DTE`.
- Applies three rules per option leg:
  - **D1** Take-profit: `pnl_pct ≥ +50%` → `CLOSE`.
  - **D2** Short danger near expiry: `SELL` + `DTE ≤ 7` + in/near-range
    (spot ≥ 0.97·strike for calls, spot ≤ 1.03·strike for puts) →
    `CLOSE`.
  - **D3** Otherwise → `HOLD`.
- **MM exception**: simulates the proposed closes via Deribit
  `calc_margin_for_positions`. If the post-close `mm_%` is *higher*
  than the baseline (portfolio-margin offsets can make closes increase
  MM), every `CLOSE` is flipped back to `HOLD` with the reason
  "HOLD due to MM exception".

Returns `(sentence, deterministic_decisions, 0.0, mm_im_calc_bundle)`.

#### 2.5b LLM finalizer - `run_close_hold_llm_agent`

- Builds the `CLOSE/HOLD` prompt (`build_close_hold_prompt`) with
  strict guardrails:
  - May only use symbols in `POSITIONS`.
  - Must NOT propose `OPEN` or output perp/future symbols.
  - Default behavior: FOLLOW the deterministic recommendation.
  - Override allowed **only** under documented emergency conditions
    (E1–E4: near-expiry deep-ITM short, margin emergency near
    `HARD_MM_CAP_PCT` (`OPEN_MM_CAP_PCT = 70%`), thesis invalidation,
    crash-risk asymmetry).
  - `quantity` must equal the full current quantity (no partial close).
- Calls the LLM (`temperature=0.05`, 3 retries, 300s timeout), parses
  JSON with a fallback to `extract_first_json_object` on malformed
  output.
- Strips out any PERPETUAL symbols that slipped through.
- `validate_decisions` enforces the `CLOSE_ONLY_SPEC` schema and
  rewrites `qty`/`side` from `positions_side_qty` so the LLM can never
  reduce size or flip side.
- Guarantees a decision exists for *every* existing option symbol,
  defaulting to `HOLD` if the LLM omitted it.

#### 2.5c Margin simulation - `simulate_mm_im_after_close`

Calls Deribit `private/simulate_portfolio` twice (baseline and with
`simulated_positions` that negate each CLOSE amount) to produce
`before`/`after` IM, MM, MB, `mm_pct_of_mb`, portfolio greeks, and
absolute diffs. These numbers are written into the final CSV and into
the `MM_IM` DB table.

#### 2.5d Locked text - `close_decisions_to_text`

The validated close decisions are serialized into a **LOCKED** JSON
block with a clear header stating that the Allocation/OPEN agent must
not modify, remove, or override any of them. The block is saved to
`/data/prompt_debug/close_locked_decisions_<ts>.txt` for audit.

### 2.6 OPEN engine - `multi_agents_lib/open_scenarios.py`

Purpose: propose a single multi-leg OPEN scenario that strictly
satisfies the Deribit-simulated MM cap.

File: [multi_agents_lib/open_scenarios.py](multi_agent_system/multi_agents_lib/open_scenarios.py)
(and [open_candidates.py](multi_agent_system/multi_agents_lib/open_candidates.py) for candidate prep).

#### 2.6a Candidate construction

`build_open_candidates_from_valuation_df` projects the (eligible) rows
of `valuation_df` into normalized leg dicts:
`{symbol, action="OPEN", side (default SELL), right, quantity, POP, _theta_eff}`.

#### 2.6b Scenario search - `generate_mm_acceptable_open_scenarios`

1. **Atomic best-leg per symbol**: iterate the candidates over a
   quantity grid (`OPEN_QTY_GRID_EVEN = [4,6,...,20]`) and keep the leg
   with the highest `theta_eff * qty` per symbol. Cap per side via
   `max_atomic_legs_per_side`.
2. **Random bundle generation**: sample `N calls + M puts` (1..2 each
   by default: `max_calls_legs=2`, `max_puts_legs=2`) from the atomic
   pool, enforcing unique symbols, up to `max_candidates=10,000`.
3. **Preselect top `preselect_k=500`** bundles by summed theta.
4. **Strict Deribit simulation**: for each preselected bundle, call
   `apply_allocation_decisions(positions_after_close, legs)` and then
   `calc_margin_for_positions` to get the **projected** `mm_%`. Keep
   only bundles with `mm_% ≤ OPEN_MM_CAP_PCT=70%`. A signature cache
   dedups duplicate combos.
5. **Score**: `theta_total * 10` if `mm_delta ≤ 0` (i.e., the bundle
   reduces MM), else `theta_total / mm_delta`. Sort descending.
6. Return `SCN_*` scenarios with legs, `mm_pct_after`,
   `mm_pct_delta`, `_theta_eff_total`, `score`, and the raw Deribit
   `explanation`.

`build_open_context_from_scenarios` renders the top 40 scenarios as
lines the selector LLM reads.

#### 2.6c LLM selector - `run_open_selector_llm`

System prompt: "pick ONE `SCN_*` or NONE; CLOSE/HOLD are already
locked; keep projected MM% ≤ 70% (target ~63%); never invent symbols
or quantities; do NOT choose `BND_*` bundles (they aren't strictly
simulated)." Output JSON is
`{sentence, chosen_open_scenario_id}`. The locked close text is
embedded in the user message so the OPEN LLM is aware of the
book-after-close.

#### 2.6d Final OPEN sim - `simulate_mm_im_after_open`

Applies the chosen `SCN_*` legs on top of `positions_after_close` and
re-runs Deribit simulate for a final mm/im bundle, then
`open_legs_to_text` writes a LOCKED OPEN JSON block (sibling of the
close-locked text) for the Structurer.

### 2.7 Structurer LLM - `multi_agents.py: run_structurer_llm`

A **no-think** JSON merger. System prompt forbids it from modifying,
adding, removing, or reinterpreting any decision. It just concatenates
the LOCKED CLOSE/HOLD list and the LOCKED OPEN legs into a single
strict JSON with:

```
{
  "sentence": "<string>",
  "decisions": [
    { "symbol", "action", "right", "side", "quantity", "reason", "when_to_close" },
    ...
  ]
}
```

Temperature 0.0, retries 2. Quantities are coerced to positive ints.
If LLM is disabled, the pipeline falls back to the deterministic
concatenation directly.

### 2.8 Final portfolio MM/IM (after open)

If a Deribit client is available, the pipeline:
1. Rebuilds `current_positions_list` from `positions_df`.
2. Applies CLOSE decisions → `positions_after_close`.
3. Applies ALLOCATION (CLOSE + OPEN) decisions on top
   (`apply_allocation_decisions`) → `positions_after_allocation`.
4. Calls `calc_margin_for_positions` on the final book to get
   `im_after_open`, `mm_after_open`, `mb_after_open`, and
   `mm_pct_after_open`. These numbers feed the
   `margin_engine.after_open` section of the return dict, the
   `MM_IM` DB table, and the CSV `MARGIN_AFTER_FINAL_*` rows.

### 2.9 Enrichment

`enrich_decisions_for_db` (`multi_agents.py`) adds to every decision
row:
- `POP = 1 − |delta|` (clipped to `[0,1]`), resolved from
  positions → valuation → live map.
- `btc_price`, `avg_price_btc`, `avg_price_usd`, `mark_price_btc`,
  `mark_price_usd`.

### 2.10 Export (CSV + Telegram)

If `save_data=True`, decisions are written to
`/data/final_runs/decisions_<ts>_<model_id>.csv` with appended rows
for: margin before/after, total LLM cost, UTC + Africa/Cairo run
timestamps, CLOSE sentence, ALLOCATION sentence, formatted fundamental
and sentiment texts (in column F, Excel wraps automatically). If
`TELEGRAM_SEND_MODEL_CSV=1` and `TELEGRAM_BOT_TOKEN` is set, the CSV
is sent as a document to every chat id in `TELEGRAM_CHAT_IDS` (JSON
env) with a caption showing model id, cost, and MM% transition.

### 2.11 DB persistence

- `save_model_decisions_daily` (in
  [multi_agents_lib/persistence.py](multi_agent_system/multi_agents_lib/persistence.py))
  appends the final decisions to the per-model daily table (one of
  `decisions_gpt_5_multi_agent`, `decisions_gpt_5_mini_multi_agent`,
  `decisions_gpt_4o_multi_agent`, `decisions_grok4_multi_agent`,
  `decisions_claude_sonnet_multi_agent` - selected by
  `_pick_decisions_table`).
- `save_open_trades_daily` saves top open candidates (valuation +
  margin-enriched).
- `_save_mm_im_row` inserts a snapshot into the `MM_IM` table with
  `im_before/after`, `mm_before/after`, and percentages of margin
  balance - keyed by `run_time_utc`, `provider`, `model_id`.

### 2.12 Return value

`run_multi_agent_pipeline` returns a dict consumed by the backend API /
Streamlit UI, containing:
- `provider`, `model_id`, `decisions_table`, `total_cost`.
- `run_time` (utc + Africa/Cairo).
- `margin_engine`: `before_any_decision`, `after_close`, `after_open`
  (each with `im_btc`, `mm_btc`, `mm_pct_of_mb`, raw `explanation`).
- `formatted_fundamental_text`, `formatted_sentiment_text`.
- `close_sentence`, `allocation_sentence`.
- `counts` (`close_n`, `open_n`, `total_n`).
- `saved_to_db` flag.
- `decisions_preview` (first 50 rows).
- `margin_preview` (UI block: current / new / delta).
- `artifacts.margin_preview_json`.

---

## 3. Supporting modules

| Module | Purpose |
|---|---|
| [llm_io.py](multi_agent_system/llm_io.py) | `make_llm_client(provider, model)` unifies OpenAI, xAI (grok), and Anthropic clients. Returns a callable that reports `{json_str, raw, usage, usd_est}`. |
| [config.py](multi_agent_system/config.py) | `DB_PATH`, `DATA_DIR`, `CFG` phase-1 config, `DAYS_AHEAD`, `fetch_account_capital`, `get_strategy_text`. |
| [Deribit_margin.py](multi_agent_system/Deribit_margin.py) | Deribit simulate_portfolio helpers, `calc_margin_for_positions`, `apply_close_decisions`, `apply_allocation_decisions`. |
| [multi_agents_lib/deribit_client.py](multi_agent_system/multi_agents_lib/deribit_client.py) | Cached Deribit REST client, margin-explain helpers, `mm_pct`. |
| [multi_agents_lib/decision_parsing.py](multi_agent_system/multi_agents_lib/decision_parsing.py) | `extract_first_json_object`, `validate_decisions`, `norm_decisions`, `sanitize_for_console`. |
| [multi_agents_lib/persistence.py](multi_agent_system/multi_agents_lib/persistence.py) | `save_model_decisions_daily`, `save_open_trades_daily`. |
| [multi_agents_lib/positions_formatting.py](multi_agent_system/multi_agents_lib/positions_formatting.py) | Turns `positions_df` into the multi-line `positions_text` the LLMs consume. |
| [multi_agents_lib/instrument_utils.py](multi_agent_system/multi_agents_lib/instrument_utils.py) | `is_option / is_perp / is_dated_future`, `parse_symbol_strike`, `parse_deribit_option_symbol`, `infer_right_from_symbol`. |
| [multi_agents_lib/logging_utils.py](multi_agent_system/multi_agents_lib/logging_utils.py) | `setup_cli_logging`. |
| [stage_1.py](multi_agent_system/stage_1.py) | Phase-1 screening & ranking used by the Valuation Agent. |
| [account_flows_ingestion.py](multi_agent_system/account_flows_ingestion.py) | Syncs Deribit deposits/withdrawals/transfers into the local DB. |
| [btc_ta_summary.py](multi_agent_system/btc_ta_summary.py) | Builds the TA text block. |
| [runner.py](multi_agent_system/runner.py) | UI-agnostic entry point with `MODEL_MAP`, progress/stop hooks, X-score loader. |
| [runner_db_helper.py](multi_agent_system/runner_db_helper.py) | Strategy pair, forecast line, X-score-for-run helpers. |

---

## 4. Agents vs. engines: who has authority over what

| Agent / Engine | Authority | Can the LLM override? |
|---|---|---|
| Fundamental LLM | Produces bias/confidence text; does NOT place trades. | N/A |
| Sentiment LLM | Produces bias/confidence text; does NOT place trades. | N/A |
| Valuation (deterministic) | Produces eligible OPEN candidates slate. | No LLM; Phase-1 rules are authoritative. |
| CLOSE deterministic | Default CLOSE/HOLD recommendation per option leg + MM-exception flip. | - |
| CLOSE LLM finalizer | **Final** CLOSE/HOLD authority. | Only on E1–E4 emergencies, same qty, no perps. |
| OPEN scenario generator | Produces only `SCN_*` bundles that strictly pass `mm_% ≤ 70%`. | No LLM. |
| OPEN selector LLM | Picks exactly ONE `SCN_*` or NONE. | May NOT invent symbols, quantities, or choose `BND_*`. |
| Structurer LLM | No-think merge of LOCKED CLOSE/HOLD and LOCKED OPEN into final JSON. | May NOT modify any decision. |

The system is intentionally **defense-in-depth**:
- Schemas + `validate_decisions` + `positions_side_qty` enforcement
  prevent side/qty tampering.
- Deribit `simulate_portfolio` is the ground truth for MM/IM - the
  LLMs never compute margin themselves.
- LOCKED text blocks make each stage's output immutable for the
  next stage.
- Fallbacks (no-LLM mode, baseline rule-only agents) let the pipeline
  always produce a conservative answer even when an LLM call fails.

---

## 5. Key constants and knobs

> **Source of truth is the code, not this table.** The values below
> were copied from the modules listed. If something looks off, trust
> the file - grep for the constant name and update this section.

Defined at the top of
[multi_agents.py](multi_agent_system/multi_agents.py) (module-level
globals, lines ~67–73):

```python
OPEN_QTY_GRID_EVEN = [4, 6, 8, 10, 12, 14, 16, 18, 20]  # contracts
OPEN_MM_CAP_PCT = 70                                    # Deribit-UI style
OPEN_MAX_CANDIDATES_FOR_MM = 25                         # cap on symbols fed to MM search
```

Passed to `generate_mm_acceptable_open_scenarios` from
`run_multi_agent_pipeline` (multi_agents.py):
`max_candidates=10_000`, `preselect_k=500`, `max_calls_legs=2`,
`max_puts_legs=2`.

**Caution:** the *function's own defaults* in
[open_scenarios.py](multi_agent_system/multi_agents_lib/open_scenarios.py)
are much larger (`max_candidates=50_000`, `preselect_k=1000`,
`max_atomic_legs_per_side=40`). Any caller that doesn't override them
will hit Deribit rate limits.

Environment variables read by the pipeline:
- `MODEL_OUTPUT_DIR` (default `/data`) - output CSVs and prompt dumps.
- `TELEGRAM_SEND_MODEL_CSV`, `TELEGRAM_BOT_TOKEN`, `TELEGRAM_CHAT_IDS`
  (JSON) - Telegram delivery of the CSV.
- `OPENAI_API_KEY`, `DERIBIT_CLIENT_ID`, `DERIBIT_CLIENT_SECRET`.
- `SMOKE_CAPITAL_USD`, `SMOKE_MAX_CANDIDATES`, `SMOKE_MAX_ROWS_TO_LLM`
  - overrides for the `__main__` smoke test at the bottom of
  `multi_agents.py`.

---

## 6. Running the pipeline

From the runner (production path):

```python
from multi_agent_system.runner import normalize_model_key
# runner.py orchestrates: prepare inputs → run_multi_agent_pipeline(...)
```

Directly (smoke test / debugging):

```bash
python -m multi_agent_system.multi_agents
```

The `__main__` block loads live options, positions, BTC price,
strategy, macro + X scores, and calls
`run_multi_agent_pipeline(..., use_llm=False, save_data=False)` by
default so you can exercise the plumbing without spending tokens or
writing to the DB.

---

## 7. Consolidated data-source map (Fundamental + Sentiment)

This is every external endpoint or internal store the two "analysis"
agents touch, in one place.

### 7.1 Fundamental Agent data sources

| Category | Source | URL / Table | Purpose |
|---|---|---|---|
| Macro score | Federal Reserve RSS | `federalreserve.gov/feeds/rss` | Rate policy, FOMC statements |
| Macro score | Reuters Top News RSS | `feeds.reuters.com/reuters/topNews` | Global macro headlines |
| Macro score | WSJ / DJ Markets RSS | `feeds.a.dj.com/rss/RSSMarketsMain.xml` | Markets news |
| Macro score | Bloomberg Economics RSS | `bloomberg.com/markets/economics/rss` | Macro econ news |
| Macro score | Bloomberg Crypto RSS | `bloomberg.com/crypto/rss` | Crypto-focused news |
| Macro score | Yahoo Finance RSS | `finance.yahoo.com/news/rssindex` | Broad finance news |
| Macro score | CoinDesk RSS | `coindesk.com/arc/outboundfeeds/rss/` | Crypto news |
| Macro score | Cointelegraph RSS | `cointelegraph.com/rss` | Crypto news |
| NLP model | FinBERT (HuggingFace) | `ProsusAI/finbert` | Headline sentiment scoring |
| NLP fallback | VADER | `vaderSentiment` | Lightweight fallback scorer |
| Macro persistence | SQLite | `macro_daily` table | Stores score_now/7d/30d + sentence per run |
| Direct headlines | Same 6 crypto+macro RSS feeds (subset) | see §2.1.1 C | Qualitative LLM context |
| On-chain | Blockchain.com Charts API | `api.blockchain.info/charts/hash-rate` | Hash rate TH/s |
| On-chain | Blockchain.com Charts API | `api.blockchain.info/charts/estimated-transaction-volume-usd` | Tx volume USD |
| On-chain | Blockchain.com Charts API | `api.blockchain.info/charts/n-unique-addresses` | Active addresses |
| On-chain | Blockchain.com Charts API | `api.blockchain.info/charts/total-bitcoins` | Circulating supply |
| On-chain | Blockchain.info Query API | `blockchain.info/q/getblockcount` | Block height for halving calc |
| Technical | SQLite | `btc_prices` table | EMA/RSI/Ichimoku/Fib via `btc_ta_summary.py` |

### 7.2 Sentiment Agent data sources

| Category | Source | URL / Table | Purpose |
|---|---|---|---|
| Derivatives | Deribit public REST | `deribit.com/api/v2/public/get_funding_rate_history` | BTC-PERPETUAL 8h funding |
| Derivatives (fallback) | Deribit public REST | `deribit.com/api/v2/public/get_funding_rate_value` | Last 9h funding fallback |
| Derivatives | Deribit public REST | `deribit.com/api/v2/public/get_book_summary_by_currency` | BTC option open interest |
| OI persistence | Local JSON cache | `.sentiment_cache/oi_btc.json` | Previous-run OI for 24h delta |
| Crowd | alternative.me | `api.alternative.me/fng/?limit=1&format=json` | Fear & Greed index |
| Crowd (X) | SQLite | `x_score` table | score_now / 7d / 30d + sentence |
| Technical | SQLite | `btc_prices` table (via `btc_ta_summary`) | Shared TA summary |

### 7.3 Inputs that come from the runner (not from an agent's own fetch)

The runner (`runner.py` / `multi_agents.py.__main__`) assembles these
before calling `run_multi_agent_pipeline`:

| Input | Source |
|---|---|
| `live_options_df` | `btc_options.load_or_fetch_live_options(DAYS_AHEAD)` - Deribit public options chain |
| `positions_df` | `btc_options.fetch_current_deribit_positions()` - Deribit private |
| `btc_price` | `btc_price.get_btc_price()` - Deribit index |
| `account_info` | `config.fetch_account_capital(DERIBIT_CLIENT_ID, DERIBIT_CLIENT_SECRET, currency=BTC, basis=equity)` |
| `strategy_text` | `runner_db_helper.get_strategy_pair()` → SQLite strategy table |
| `forecast_message` | `runner_db_helper.build_forecast_line_safe()` → SQLite forecast table |
| Macro scores (`macro_now/7D/30D`) | `sentiment.get_macro_sentiment_scores_llm()` |
| X scores + sentence | `runner_db_helper.get_x_for_run()` → SQLite `x_score` table |

---

## 8. Prompt contracts and schemas

Each LLM in the chain has a strict contract. This table is the
quick reference for what each stage is allowed to output.

### 8.1 Fundamental Agent prompt

Built by `build_llm_prompt(norm, ta_summary)` in `fundemantal_agent.py`.

- **System line**: "You are the BTC Fundamental Agent. Return ONLY
  valid JSON per schema."
- **Schema the model must fill**:
  ```json
  {
    "agent": "fundamental",
    "bias": "bullish|bearish|neutral",
    "confidence": 0.0,
    "horizon_days": 15,
    "rationale": "≤300 words",
    "key_signals": ["short tags"],
    "red_flags": [{"code":"LOW_DATA","severity":"soft","note":"short"}],
    "recommendations": [],
    "metrics": {"pop_est": 0.70}
  }
  ```
- **Decision rules embedded in the prompt**: macro_now threshold
  ±0.15, trend-confirmer logic with macro_7D / macro_30D, same-sign
  confidence boost +0.10, disagreement penalty −0.10 with
  `CONFLICTING_SIGNALS` flag, `horizon_days=15` hard-coded.
- **Temperature**: 0 (deterministic). **max_tokens**: 5000.

### 8.2 Sentiment Agent prompt

Same shape, but `agent="sentiment"` and `horizon_days=10`. The prompt
references funding-bps-8h, deadband flag, oi_now / oi_24h_delta, X
scores and sentence, F&G, and TA summary.

### 8.3 CLOSE/HOLD prompt

Built by `build_close_hold_prompt`. Key guardrails:
- Symbols restricted to those in `POSITIONS`.
- `HARD_MM_CAP_PCT = 70.0%`; `TARGET_MM_PCT = max(0, cap − max(1,
  min(5, 0.10·cap)))`. With `cap=70`, target = 63%.
- Perps/futures forbidden from output.
- Default to deterministic recommendation; override only under
  E1–E4 emergencies (near-expiry deep-ITM short; margin emergency;
  thesis invalidation; crash-risk asymmetry).
- `quantity` must equal full current quantity (no partial close).
- Output:
  ```json
  { "sentence": "...", "decisions": [
    { "symbol", "action": "CLOSE|HOLD", "right": "CALL|PUT",
      "side": "BUY|SELL", "quantity": <int>,
      "reason": "...", "when_to_close": "..." }
  ]}
  ```
- Temperature: 0.05. Retries: 3. Timeout: 300s.

### 8.4 OPEN Selector prompt

Built by `build_open_selector_prompt`. Guardrails:
- CLOSE/HOLD are locked - **do not emit any CLOSE or HOLD**.
- Pick exactly one `SCN_*` or `NONE`. `BND_*` forbidden (not strictly
  simulated).
- Keep projected `MM% ≤ 70%`, target `63%`.
- May not invent symbols or quantities.
- Output: `{ "sentence", "chosen_open_scenario_id" }`.

### 8.5 Structurer prompt

"STRICT JSON STRUCTURER. You DO NOT make trading decisions. You MUST
NOT change, rewrite, add, remove, or reinterpret any decision."
- Temperature: 0.0. Retries: 2. Timeout: 120s.
- Merges LOCKED CLOSE/HOLD + LOCKED OPEN into one `decisions[]` array
  with the standard key set.

---

## 9. Valuation Agent - Phase-1 filter details

`run_valuation_filter_with_pop` delegates to
`stage_1.phase1_screen_and_rank`, which applies a stack of
deterministic screens before any LLM touches options. The list below
is the set of columns/filters the downstream agents depend on.

Typical filters (see `stage_1.py` and `CFG` in `config.py` for actual
thresholds):
- **Liquidity**: minimum Open Interest and volume; max bid-ask
  `spread_pct`; max `iv_spread_abs`.
- **DTE window**: e.g. 10–60 days (avoid expiration gamma and
  far-dated illiquid).
- **Greeks window**: `|delta|` between ~0.10 and ~0.40 (OTM credit
  zone).
- **Moneyness**: computed as `spot / strike − 1`.
- **Vega-bucket diversification**: keeps share of exposure per
  bucket under thresholds (`share_bucket_now`, `share_bucket_proj`,
  `share_total_now`, `share_total_proj`, `eligible_vega`).
- **Capital & MM-cap budgets**: `qty_max_sell`, `qty_max_buy`, `qty`
  computed from the account snapshot and `MM_CAP_RATIO`.
- **POP**: appended from `1 − |delta|` clipped to `[0, 1]`.
- **Derived columns**: `DTE`, `mid_price`, `spread_pct`,
  `iv_spread_abs`, `moneyness`.
- **Final rank** + `eligible` flag. Only `eligible == 1` rows survive
  into `build_open_candidates_from_valuation_df`.

The Valuation Agent also enriches with a reference MM-per-contract
estimate via `ref_mm_per_contract_btc_calc`
([open_candidates.py](multi_agent_system/multi_agents_lib/open_candidates.py))
using a percentile of live-sampled MM deltas - either via a true
simulate-based `margin_estimator` or the heuristic
`1.2 · mark_btc + 0.003` when no estimator is wired. Defaults to
`0.02` BTC when data is insufficient.

---

## 10. CLOSE / OPEN rule math (quick reference)

### 10.1 Deterministic CLOSE rules (options only)

Let `spot = btc_price`, and for each option leg parse strike from
the Deribit symbol.

- **D1 Take-profit**: `pnl_pct ≥ +50%` → `CLOSE`.
- **D2 Short danger near expiry**: `side=SELL ∧ DTE ≤ 7 ∧ in_range`
  where:
  - for a CALL: `in_range ⇔ spot ≥ 0.97 · strike`
  - for a PUT: `in_range ⇔ spot ≤ 1.03 · strike`
  → `CLOSE`.
- **D3**: else `HOLD`.
- Futures / perps: `CLOSE` only if `pnl_pct ≥ +50%`, else `HOLD`
  (they're dropped from the LLM prompt anyway).

### 10.2 MM exception (portfolio-margin paradox)

Closing can *increase* `MM%` because of portfolio-margin offsets. The
engine runs `calc_margin_for_positions` BEFORE and AFTER applying the
proposed closes; if `mm_after_pct > mm_before_pct`, every `CLOSE` is
flipped to `HOLD` with reason "HOLD due to MM exception".

### 10.3 OPEN scenario generation

1. Atomic best-leg per symbol by `theta_eff × quantity` over the grid
   `OPEN_QTY_GRID_EVEN = [4, 6, 8, 10, 12, 14, 16, 18, 20]`.
2. Cap the atomic pool to `max_atomic_legs_per_side = 40` per side
   (calls / puts separately).
3. Random bundle sampling: `n_calls = rand(1..2)`, `n_puts =
   rand(1..2)`, unique symbols. Up to `max_candidates = 10,000` bundles
   with `seed=7` for reproducibility.
4. Preselect top `preselect_k = 500` bundles by `sum(theta_eff_total)`.
5. Deribit `simulate_portfolio` each preselected bundle to get true
   projected MM; **drop** any bundle with `mm_pct_after >
   OPEN_MM_CAP_PCT (70%)`.
6. Score:
   - if `mm_delta ≤ 0`: `score = theta_total × 10`
   - else: `score = theta_total / mm_delta`
7. Sort descending. Top `max_lines = 40` become the LLM context.

### 10.4 Final margin computation

```
positions_after_close       = apply_close_decisions(current, close_decisions)
positions_after_allocation  = apply_allocation_decisions(after_close, allocation_decisions)
res_after_open              = calc_margin_for_positions(deribit, BTC, after_allocation)
mm_pct_after_open           = min(100, 100 * mm / margin_balance)
```

These three snapshots (`before_any_decision`, `after_close`,
`after_open`) are the authoritative margin numbers returned to the UI
and persisted to `MM_IM`.

---

## 11. Outputs you can inspect after a run

- `/data/final_runs/decisions_<ts>_<model_id>.csv` - main
  human-readable output.
- `/data/prompt_debug/close_hold_prompt_<ts>.txt`,
  `.../open_selector_prompt_<ts>.txt`,
  `.../close_locked_decisions_<ts>.txt`,
  `.../open_scenarios_debug.json` - LLM prompts and scenario debug.
- `fundamental_runs/<model>_<ts>/{inputs,fundamental_decision}.json`.
- `sentiment_runs/<model>_<ts>/{inputs,sentiment_decision}.json`.
- SQLite tables (`btc_trading.sqlite`): per-model decisions table,
  `open_trades_*`, `MM_IM`, `account_flows`, `macro_daily`,
  `x_score`, `btc_prices`.

---

## 12. Failure modes and fallbacks

The pipeline is built to *always return a usable answer*. Where a
remote source can fail, there is a defined fallback:

| Stage | Failure | Fallback |
|---|---|---|
| Account flow sync | Deribit auth error / rate limit | Log warning, continue with existing `account_flows`. |
| TA summary | `btc_prices` missing / short history | String "Technical summary unavailable…". |
| Fundamental headlines | RSS feed down | Skipped; red-flag `LOW_DATA` added. |
| Fundamental on-chain | blockchain.info timeout | Fields set to `None`; rule baseline unaffected. |
| Fundamental LLM | Parse/schema error | Rule-baseline output with `DATA_GAP` red-flag + LLM cost still recorded. |
| Sentiment funding | Deribit 500 / empty | Funding omitted; score from OI + X + F&G only. |
| Sentiment OI | Deribit error | `oi_24h_delta` left `None`. |
| Sentiment LLM | Exception | Conservative baseline `{score: 0.0, red_flags:[LLM_ERROR]}`. |
| Valuation | Empty `df_live` | Returns empty DataFrame → OPEN engine generates zero scenarios → LLM picks `NONE`. |
| CLOSE LLM | JSON parse fail | `extract_first_json_object` fallback; then `LLMError`; caller catches and reverts to deterministic decisions. |
| OPEN scenario gen | No Deribit client | Returns `[]` → selector sees "No MM-safe…" → `NONE`. |
| OPEN LLM | Invalid `chosen_open_scenario_id` | `scenario_id_to_open_legs` returns `[]` → no open legs in final decisions. |
| Structurer | LLM disabled | Deterministic concatenation of LOCKED CLOSE/HOLD + OPEN legs. |
| Final margin sim | Deribit error | Re-uses `after_close` values for `after_open`. |
| DB save | `sqlite3.OperationalError` | Logged; pipeline still returns the result dict. |
| Telegram send | Bad token / network | Logged per-chat-id; other chat IDs still attempted. |

---

## 13. Example outputs

### 13.1 Structurer JSON (final decision set)

What the Structurer returns and what ends up in the per-model
decisions DB table (before enrichment):

```json
{
  "sentence": "Close 1 short call that hit +55% PnL; open 1 short-put scenario SCN_017 (projected MM 61%).",
  "decisions": [
    {
      "symbol": "BTC-27DEC24-100000-C",
      "action": "CLOSE",
      "right": "CALL",
      "side": "SELL",
      "quantity": 6,
      "reason": "D1 take-profit: pnl_pct=+55%",
      "when_to_close": "now"
    },
    {
      "symbol": "BTC-24JAN25-85000-P",
      "action": "HOLD",
      "right": "PUT",
      "side": "SELL",
      "quantity": 4,
      "reason": "Outside short-danger band; HOLD",
      "when_to_close": "at +50% PnL or DTE≤7 and in-range"
    },
    {
      "symbol": "BTC-28FEB25-75000-P",
      "action": "OPEN",
      "right": "PUT",
      "side": "SELL",
      "quantity": 8,
      "reason": "Part of SCN_017; theta-weighted leg; projected MM 61%",
      "when_to_close": "at +50% PnL or DTE≤7 and in-range"
    }
  ]
}
```

### 13.2 Enriched CSV row (`/data/final_runs/decisions_<ts>_<model>.csv`)

After `enrich_decisions_for_db` adds POP / avg / mark / BTC price:

| symbol | action | right | side | quantity | reason | when_to_close | POP | btc_price | avg_price_btc | avg_price_usd | mark_price_btc | mark_price_usd |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| BTC-27DEC24-100000-C | CLOSE | CALL | SELL | 6 | D1 take-profit: pnl_pct=+55% | now | 0.78 | 87906 | 0.0142 | 1248.30 | 0.0064 | 562.60 |
| BTC-24JAN25-85000-P | HOLD | PUT | SELL | 4 | Outside short-danger band; HOLD | at +50% PnL … | 0.81 | 87906 | 0.0089 | 782.36 | 0.0073 | 641.71 |
| BTC-28FEB25-75000-P | OPEN | PUT | SELL | 8 | Part of SCN_017; … | at +50% PnL … | 0.84 | 87906 | - | - | 0.0041 | 360.41 |

The same file appends summary rows (`MARGIN_BEFORE_*`,
`MARGIN_AFTER_CLOSE_*`, `MARGIN_AFTER_FINAL_*`, `TOTAL_COST`,
`RUN_TIME_UTC`, `RUN_TIME_CAIRO`, `CLOSE_SENTENCE`,
`ALLOCATION_SENTENCE`, formatted fundamental/sentiment lines).

### 13.3 Fundamental / Sentiment decision dicts (on-disk)

Written to `fundamental_runs/<model>_<ts>/fundamental_decision.json`
and `sentiment_runs/<model>_<ts>/sentiment_decision.json`:

```json
{
  "agent": "fundamental",
  "bias": "bullish",
  "confidence": 0.72,
  "horizon_days": 15,
  "rationale": "Macro score +0.31 with 7D/30D confirming; hashrate ATH; no dovish Fed signals in last 36h.",
  "key_signals": ["macro-pos", "trend-confirm", "hashrate-ath"],
  "red_flags": [],
  "recommendations": [],
  "metrics": {"pop_est": 0.70, "tokens_in": 2104, "tokens_out": 312, "usd_est": 0.018}
}
```

### 13.4 `margin_engine` block (returned to the UI)

```json
{
  "before_any_decision": {"im_btc": 0.412, "mm_btc": 0.201, "mm_pct_of_mb": 58.1, "explanation": {...}},
  "after_close":         {"im_btc": 0.358, "mm_btc": 0.174, "mm_pct_of_mb": 50.3, "explanation": {...}},
  "after_open":          {"im_btc": 0.441, "mm_btc": 0.214, "mm_pct_of_mb": 61.8, "explanation": {...}}
}
```

---

## 14. Debugging a run

All debug artifacts are written under `$MODEL_OUTPUT_DIR` (default
`/data`). To replay a run without spending tokens or touching the DB:

```bash
python -m multi_agent_system.multi_agents      # runs with use_llm=False, save_data=False
```

### Where to look first when a run looks wrong

| Symptom | Start here |
|---|---|
| Final decision missing a symbol | `close_locked_decisions_<ts>.txt` vs. final CSV - if they disagree, the Structurer dropped it (see [audit #22](multi_agent_audit.md#1-top-priority-high-findings)). |
| "Why did it pick SCN_X?" | `open_selector_prompt_<ts>.txt` shows the top 40 scenarios the LLM saw; `open_scenarios_debug.json` has all `SCN_*` with scores and simulated MM. |
| CLOSE decisions unexpectedly flipped to HOLD | CLOSE engine logs emit `"HOLD due to MM exception"`. Compare `margin_engine.before_any_decision` vs. a simulated after-close snapshot. |
| Fundamental/Sentiment output looks stale | `fundamental_runs/<model>_<ts>/inputs.json` and `sentiment_runs/<model>_<ts>/inputs.json` are the exact inputs the LLM saw. |
| MM% over cap | `_save_mm_im_row` wrote a `MM_IM` row for the run; join by `run_time_utc` + `model_id`. |
| LLM cost looks wrong | `total_cost` in the return dict. See [audit #5](multi_agent_audit.md#1-top-priority-high-findings) - there is a known under-report in the LLM branch. |
| Telegram not sending | Check `TELEGRAM_SEND_MODEL_CSV=1` and `TELEGRAM_CHAT_IDS` env. Per-chat failures are logged but do not raise. |

### Useful DB queries

```sql
-- Latest run for a model
SELECT * FROM decisions_gpt_5_multi_agent ORDER BY run_time_utc DESC LIMIT 20;

-- Margin timeline
SELECT run_time_utc, model_id, im_before, im_after, mm_before, mm_after,
       mm_pct_before, mm_pct_after
FROM MM_IM ORDER BY run_time_utc DESC LIMIT 20;

-- Most recent X-sentiment row the runner would pick up
SELECT date, score_now, score_7d, score_30d, x_sentiment_sentence
FROM x_score ORDER BY date DESC LIMIT 1;
```

### Known-issue cross reference

For recurring failure modes (silent LLM fallback, POP = 1 − |delta|
caveat, sequential RSS latency, broken Reuters/Bloomberg feeds, dead
`open_trades` writes, etc.) see
[multi_agent_audit.md](multi_agent_audit.md).

---

## 15. Known weaknesses (code audit)

Moved out for readability - see
[multi_agent_audit.md](multi_agent_audit.md) for the full list of
HIGH / MEDIUM / LOW findings with `file:line` references and a
thematic summary. A quick preview of the top themes:

1. **The Sentiment Agent's LLM is running the wrong prompt** (it's
   the Fundamental prompt copy-pasted).
2. **Hidden data loss through silent fallbacks** - validators and
   broad `except Exception:` swallow errors without surfacing them.
3. **The pipeline's "facts" often aren't** - `POP`, `oi_24h_delta`,
   the 0.97/1.03 in-range band, and `avg_block_minutes=10` are named
   as if they were exact measures but are approximations.
4. **The "locked" guarantee is advisory** - nothing in code verifies
   the Structurer's output equals its inputs.

---

## 16. End-to-end data flow at a glance

```
┌──────────────┐   RSS × 8  FinBERT / VADER   ┌────────────────────┐
│ sentiment.py │──────────────────────────────▶│ macro_daily (SQL) │
│ macro scores │                               └──────────┬────────┘
└──────┬───────┘                                          │
       ▼                                                  ▼
┌──────────────────────────────┐         ┌─────────────────────────────┐
│ Fundamental Agent            │         │ Sentiment Agent             │
│  • macro_now/7D/30D          │         │  • Deribit funding (8h)     │
│  • TA summary (btc_prices)   │         │  • Deribit option OI (BTC)  │
│  • RSS titles (6 feeds)      │         │  • F&G (alternative.me)     │
│  • Blockchain.com on-chain   │         │  • X scores (x_score SQL)   │
│  • Halving countdown         │         │  • TA summary               │
└───────────────┬──────────────┘         └───────────────┬─────────────┘
                │ formatted_fundamental_text              │ formatted_sentiment_text
                ▼                                         ▼
        ┌───────────────────────────────────────────────────┐
        │ Valuation Agent  (Phase-1 filter + POP + DTE)      │
        │  • live_options_df from Deribit                    │
        │  • excludes held positions                         │
        │  • eligible == 1 subset                            │
        └───────────────┬───────────────────────────────────┘
                        ▼
        ┌───────────────────────────────────────────────────┐
        │ CLOSE/HOLD deterministic → LLM finalizer → LOCKED │
        │ Deribit simulate_portfolio BEFORE vs AFTER close  │
        └───────────────┬───────────────────────────────────┘
                        ▼
        ┌───────────────────────────────────────────────────┐
        │ OPEN scenarios (SCN_*, MM-capped @ 70%)            │
        │ → OPEN selector LLM picks ONE or NONE → LOCKED     │
        └───────────────┬───────────────────────────────────┘
                        ▼
        ┌───────────────────────────────────────────────────┐
        │ Structurer LLM merges LOCKED + LOCKED              │
        └───────────────┬───────────────────────────────────┘
                        ▼
        ┌───────────────────────────────────────────────────┐
        │ Final Deribit sim  →  enrich  →  CSV  →  Telegram │
        │                                   ↳ DB persist    │
        └───────────────────────────────────────────────────┘
```
