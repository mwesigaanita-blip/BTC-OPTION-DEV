# HV vs IV — Volatility Page

> Status: shipped 2026-05-22
> Page: **Volatility (HV vs IV)** → `/volatility`
> Backend: `GET /api/vol/hv-iv`
> Live ticker: `vol_ticks` table in `data/portfolio_analysis.sqlite`

---

## Part 1 — Plain-English summary

### What this feature does

The page shows two numbers traders care about most, side by side, over any time range from 7 days to 5 years:

- **HV (Historical Volatility)** — how much BTC actually moved in the past, expressed as an annualized percentage. This is **realized** vol.
- **IV (Implied Volatility, via DVOL)** — how much option buyers *expect* BTC to move going forward. This is the market's **forecast** of vol, derived from option prices.

The gap between them (`IV − HV`, called the **vol risk premium**) is the single most-used signal in options trading:

- **IV > HV (positive spread)** → options are *expensive* (rich). Selling premium is statistically favoured.
- **IV < HV (negative spread)** → options are *cheap* (crushed). Buying optionality is statistically favoured.

### What you see on the page

1. **Range picker**: 7D / 30D / 90D / 1Y / 5Y buttons.
2. **Resolution toggle**: Daily / Hourly. Hourly is disabled when the range > 90 days (a 5-year hourly view would be 44,000 points and useless).
3. **Four summary tiles**: latest HV, latest IV, current spread, 30-bucket mean spread.
4. **Main chart**: HV vs IV as two overlaid lines.
   - The HV line has **two visual styles**: solid for the older portion we computed ourselves, dashed for the recent ~16 days where we use Deribit's authoritative HV. The dash boundary is intentional — it tells you exactly where the data source switches.
5. **Spread chart**: `IV − HV` as a filled area, with a zero reference line. Visual quick-read of whether vol is rich or crushed right now.
6. **CSV button**: one click downloads every visible row as a CSV (Excel-compatible UTF-8 BOM).

### What's new in the background

A small worker now writes one HV/IV/spot snapshot to the database every 5 minutes, so over time we accumulate our own permanent record. The chart itself does **not** depend on that record (it fetches fresh Deribit data on demand and caches for 5 min), but the table is being filled for future analytics (alerts, ML features, audit history).

### Why "hybrid" HV?

Deribit only exposes ~16 days of HV history. If you ask for a 1-year chart, the rest has to come from somewhere — so we compute it ourselves from BTC perpetual-futures candles using the standard textbook recipe (rolling 30-day annualized stdev of log returns).

We measured the disagreement between our HV and Deribit's HV on the overlapping 16-day window: **~2 percentage points mean bias, max ~6pp on any single point**. Almost all of that comes from one structural reason: Deribit's HV uses the multi-exchange BTC *index*, and Deribit doesn't expose that index's historical price series — so we use BTC perpetual closes as a proxy. That introduces a small persistent bias but the *shape* of the curve and the *spread signal* both read identically either way.

Rather than hide the discrepancy, the chart shows it: the boundary between "computed" (solid) and "Deribit" (dashed) is right there in plain sight.

### Honest caveats

- **Hourly is capped at 90 days of lookback.** Anything longer must be Daily. Pure pragmatism — bigger payloads are slower and the eye can't read 44k hourly points.
- **5-year IV depth is real** (DVOL began ~mid-2021 on Deribit — we pull all of it). For HV the depth is whatever the BTC perp has been listed for, which is also ~5+ years.
- **No backfill of computed HV into the long-term `vol_ticks` table.** The DB only fills forward from "now"; the chart's deep history is recomputed live from Deribit on each request, cached for 5 min.
- **Tracking error vs Deribit's exact HV recipe is unavoidable.** Their methodology has undocumented details (sampling cadence, gap handling, whether they use close-to-close or a Yang-Zhang estimator). We use straightforward close-to-close, which is the standard public definition.

---

## Part 2 — Technical reference

### Data flow

```
                   Deribit JSON-RPC
                          │
        ┌─────────────────┼──────────────────────┐
        ▼                 ▼                      ▼
get_historical_     get_volatility_      get_tradingview_
   volatility       index_data           chart_data
  (last 16d HV)    (DVOL OHLC)           (BTC perp candles)
        │                 │                      │
        │                 │                      ▼
        │                 │             compute_hv_series
        │                 │             (rolling stdev)
        │                 │                      │
        └───────┬─────────┴──────────────────────┘
                ▼
       hv_iv_series (composite)
       └ bucket-aligns to 1D / 1H
       └ prefer Deribit HV when present, fallback to computed
       └ tags each row with hv_source ∈ {"deribit","computed",None}
                │
                ▼
       backend_api/routes_vol.py
       GET /api/vol/hv-iv?days=&resolution=
       └ 5-min TTL cache keyed on (days, resolution)
       └ 422 when resolution=1H and days>90
                │
                ▼
       React: VolatilityPage.tsx
       └ TanStack Query, placeholderData=(prev)=>prev
       └ Recharts ComposedChart, two HV series + IV
       └ Client-side CSV export
```

### File map

| File | Role |
|---|---|
| [portfolio_analysis_AI_Agent/tools/datafetch/market/get_btc_index_candles.py](../portfolio_analysis_AI_Agent/tools/datafetch/market/get_btc_index_candles.py) | Paginated BTC-PERPETUAL TradingView candles. Used as proxy for the BTC index (Deribit doesn't expose historical index series). Chunks across the ~5000-bar per-call limit. |
| [portfolio_analysis_AI_Agent/tools/datafetch/market/get_dvol_full_history.py](../portfolio_analysis_AI_Agent/tools/datafetch/market/get_dvol_full_history.py) | Paginated DVOL fetcher. Walks `public/get_volatility_index_data` backwards in 1000-sample windows until `days` covered or inception reached. |
| [portfolio_analysis_AI_Agent/tools/datafetch/market/get_historical_volatility.py](../portfolio_analysis_AI_Agent/tools/datafetch/market/get_historical_volatility.py) | Deribit's authoritative 16d HV series (single call, no pagination). |
| [portfolio_analysis_AI_Agent/tools/analysis/compute_hv_series.py](../portfolio_analysis_AI_Agent/tools/analysis/compute_hv_series.py) | Pure math: rolling annualized stdev of log returns. `compute_hv_from_deribit(days, resolution)` is the convenience wrapper that pulls candles and returns `[{ts_ms, hv_pct}]`. |
| [portfolio_analysis_AI_Agent/tools/composite/hv_iv_series.py](../portfolio_analysis_AI_Agent/tools/composite/hv_iv_series.py) | The orchestrator. Pulls IV + Deribit HV + computed HV, bucket-aligns on `resolution`, returns the unified rowset with `hv_source` tags. |
| [portfolio_analysis_AI_Agent/tools/jobs/vol_tick.py](../portfolio_analysis_AI_Agent/tools/jobs/vol_tick.py) | Live ticker `collect_vol_tick()` (single sample) + `backfill_vol_history(days)` (one-shot seed). |
| [portfolio_analysis/vol_worker.py](../portfolio_analysis/vol_worker.py) | Daemon thread that runs the ticker every `VOL_TICK_INTERVAL_S` (default 300 s). On first run with empty `vol_ticks`, runs the 90-day backfill. |
| [portfolio_analysis/storage.py](../portfolio_analysis/storage.py) | `vol_ticks` table DDL + `insert_vol_tick / insert_vol_ticks_bulk / count_vol_ticks` helpers. |
| [portfolio_analysis/scheduler.py](../portfolio_analysis/scheduler.py) | Wires `VolTickWorker` into the existing `PortfolioScheduler` lifecycle. |
| [backend_api/routes_vol.py](../backend_api/routes_vol.py) | `GET /api/vol/hv-iv` with 5-min process-local TTL cache + Pydantic guard for `1H × days>90`. |
| [React/src/api/vol.ts](../React/src/api/vol.ts) | Frontend fetcher. |
| [React/src/types/vol.ts](../React/src/types/vol.ts) | Response type. |
| [React/src/pages/VolatilityPage.tsx](../React/src/pages/VolatilityPage.tsx) | The page. |

### Volatility math — exact recipe

**Computed HV** in `compute_hv_series`:

```
log_ret[i] = ln(close[i] / close[i-1])

For each bar i starting at i = window_bars (warm-up):
    window = log_ret[i - window_bars : i]
    mean   = sum(window) / window_bars
    var    = sum((r - mean)^2 for r in window) / (window_bars - 1)   # ddof=1
    sd     = sqrt(var)
    hv[i]  = sd * sqrt(bars_per_year) * 100   # annualized %
```

Constants:

| Resolution | `window_bars` | `bars_per_year` |
|---|---|---|
| `"60"` (hourly) | `30 × 24 = 720` | `24 × 365 = 8760` |
| `"1D"` (daily)  | `30` | `365` |

`window_bars` always represents a **rolling 30-day** window — the conventional 30-day HV that matches DVOL's 30-day forward-looking IV measure.

### Deribit endpoint catalog

| Endpoint | What it gives | Pagination | Used for |
|---|---|---|---|
| `public/get_historical_volatility` | ~384 hourly HV points (last ~16 days). No time params. | None — fixed window | Authoritative HV for recent end of chart |
| `public/get_volatility_index_data` | DVOL OHLC, 1h/12h/1D resolution. Accepts `start_timestamp`/`end_timestamp`. 1000-sample per-call cap. | Yes (walk backwards) | IV history, both backfill and chart |
| `public/get_tradingview_chart_data` | OHLCV candles for any instrument. ~5000-bar per-call cap. | Yes (walk backwards) | BTC-PERPETUAL closes for computed HV |
| `public/get_index_price` | Current BTC index price (point-in-time). | No | Live `btc_price` in the 5-min ticker |

### Hybrid HV merge logic

Per resolution-sized bucket:

```python
if bucket in deribit_hv:
    hv_pct, hv_source = deribit_hv[bucket], "deribit"
elif bucket in computed_hv:
    hv_pct, hv_source = computed_hv[bucket], "computed"
else:
    hv_pct, hv_source = None, None
```

The bucket size for `1D` is 86_400_000 ms (UTC day floor). For `1H` it's 3_600_000 ms. Deribit's HV samples (hourly) get down-sampled to daily buckets by **last-value-wins** when the chart resolution is Daily, which produces a one-row-per-day series matching the others.

IV is always sourced from DVOL — there's no fallback path or alternate source. If DVOL is unreachable for a bucket, the row carries `iv_pct: null` and the chart renders a gap.

### Backend route contract

```
GET /api/vol/hv-iv?days=<int>&resolution=<1D|1H>
```

| Param | Type | Range | Default |
|---|---|---|---|
| `days` | int | 1..1825 | 30 |
| `resolution` | str | `"1D" | "1H"` | `"1D"` |

**Response (200):**

```json
{
  "resolution": "1D",
  "from_ms": 1747699200000,
  "to_ms": 1779408000000,
  "rows": [
    {
      "ts_ms": 1747699200000,
      "ts_utc": "2025-05-20T00:00:00Z",
      "hv_pct": 33.39,
      "hv_source": "computed",
      "iv_pct": null
    },
    /* … */
    {
      "ts_ms": 1779408000000,
      "ts_utc": "2026-05-22T00:00:00Z",
      "hv_pct": 30.36,
      "hv_source": "deribit",
      "iv_pct": 35.84
    }
  ],
  "fetched_at": 1779458000
}
```

**Errors:**

| Status | When |
|---|---|
| `401` | No JWT or expired JWT. |
| `403` | User lacks the `Volatility` page grant (operators bypass this). |
| `422` | `resolution=1H` and `days > 90`. |
| `502` | Underlying Deribit call failed (`Failed to build HV/IV series: …`). |

**Caching:** 5-minute process-local TTL keyed on `(days, resolution)`. Vol moves slowly; this is mostly to prevent UI hammering on every range/resolution toggle.

### Storing the live ticker

| Column | Type | Notes |
|---|---|---|
| `ts_utc` | TEXT (PK) | ISO-8601 with microseconds + `Z`. |
| `hv30` | REAL | Deribit's latest HV sample, % annualized. |
| `iv30` | REAL | Latest DVOL hourly close, % annualized. |
| `btc_price` | REAL | Live BTC index price (left NULL during backfill). |

Index: `idx_vol_ticks_ts ON vol_ticks(ts_utc)`.

The worker is **not** the source of truth for the chart — the chart pulls fresh from Deribit on each cache miss. The table accumulates for future use: alerts that key off rolling vol spread, ML features, or just an audit trail of "what did we see at the time."

### Environment variables

| Var | Default | Used by |
|---|---|---|
| `VOL_TICK_INTERVAL_S` | `300` (5 min) | `VolTickWorker` cadence |
| `VOL_TICK_BACKFILL_DAYS` | `90` | One-shot seed window on empty table |
| `VOL_TICK_ENABLED` | `1` | Kill switch — set to `0` to keep the worker idle without code changes |

### Page access control

The route is gated by `require_page("Volatility")`. Operators bypass — works immediately for any operator JWT. To grant viewer accounts, add `"Volatility"` to their `pages` JSON column in `auth.sqlite.streamlit_users` via the **User Management** page.

### Performance characteristics (measured)

| Scenario | Deribit calls | Approx wall-time | Payload rows |
|---|---|---|---|
| `?days=30&resolution=1D` | 3 (HV + DVOL × 1 page + perp candles × 1 chunk) | ~1.5 s cold, <50 ms cached | ~33 |
| `?days=365&resolution=1D` | 3 (same shape, larger windows) | ~3 s cold | ~368 |
| `?days=1825&resolution=1D` | 4 (DVOL × 2 pages + others) | ~5 s cold | ~1828 |
| `?days=90&resolution=1H` | 4 (DVOL × 3 pages of 1000 hourly + candles × 1 chunk) | ~4 s cold | ~2160 |
| `?days=365&resolution=1H` | — | 422 (rejected) | — |

The 5-min cache means the warm hit on any combination is sub-50 ms.

### How the agent can use these tools

Each agent tool is callable directly from the multi-agent system or the chatbot:

```python
from portfolio_analysis_AI_Agent.tools.composite.hv_iv_series import hv_iv_series
out = hv_iv_series(days=30, resolution="1D")
# → {"resolution":"1D","from_ms":...,"to_ms":...,"rows":[...],"fetched_at":...}

from portfolio_analysis_AI_Agent.tools.analysis.compute_hv_series import compute_hv_from_deribit
hv = compute_hv_from_deribit(days=90, resolution="60")
# → [{"ts_ms":..., "hv_pct": 32.5}, ...]
```

The composite is the right entry point for "give me HV vs IV." The lower-level fetchers are exposed so the agent can answer narrower questions (e.g. "what's DVOL been since Jan 2024?") without paying for the full composite assembly.

---

## Part 3 — Operations

### Adding the route to a new user (viewer role)

1. Open **User Management** in the dashboard.
2. Edit the user.
3. Tick **Volatility** in the page-grant list.
4. Save. Next login, the user can hit `/volatility`.

### Deploying to the server

No docker-compose changes are required for the chart itself — `backend_api` picks up `routes_vol.py` on container rebuild. The worker is wired into the existing `portfolio_analysis_scheduler` service in compose, so it starts automatically on next deploy.

```sh
git pull
docker compose build api portfolio_analysis_scheduler react
docker compose up -d
docker compose logs -f portfolio_analysis_scheduler | grep vol_tick
```

You should see, on first start:

```
INFO  portfolio_analysis.vol_worker  VolTickWorker started (interval=300s backfill=90d)
INFO  portfolio_analysis.vol_worker  vol_ticks empty - backfilling 90 days from Deribit...
INFO  portfolio_analysis.vol_worker  vol_ticks backfill complete: ~2400 rows inserted
```

Then one INFO line per ~12 ticks (one per hour at the 5-min cadence).

### Health checks

- DB row growth:
  ```sh
  sqlite3 data/portfolio_analysis.sqlite \
    "SELECT count(*), min(ts_utc), max(ts_utc) FROM vol_ticks"
  ```
- Route smoke test (operator JWT required):
  ```sh
  curl -H "Authorization: Bearer $TOK" \
       "http://localhost:8000/api/vol/hv-iv?days=7&resolution=1D" | jq .
  ```
- Scheduler health summary includes the `vol` worker:
  ```sh
  python -m portfolio_analysis.scheduler --health
  # → {"workers": {"alert": true, "heartbeat": true, "report": true, "vol": true}, ...}
  ```

### Things to watch / known limitations

- **Deribit rate limits**: 5-min route cache + 5-min worker cadence keeps us well under any reasonable limit. The full-history 5y/1D call uses 4 Deribit requests once every 5 min in the worst case.
- **BTC perp vs index bias**: documented above. Will not disappear without a different price source. If a vendor with historical Deribit *index* prices becomes available, swap `get_btc_index_candles` to read from it and the bias goes to zero.
- **No automatic alerting** wired off `vol_ticks` yet — that's the obvious next thing to build on top (e.g. alert when `IV − HV` crosses ±N standard deviations of its own 30-day baseline).
- **The chart's deep history is not authoritative**. Every refresh recomputes from Deribit. For an audit-grade view of "what did HV look like exactly at time T," use `vol_ticks` directly.
