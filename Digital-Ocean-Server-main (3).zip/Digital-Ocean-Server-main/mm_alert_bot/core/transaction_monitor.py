# mm_alert_bot\core\transaction_monitor.py
"""
Transaction & Trade Activity Monitor - REST polling

Monitors:
- New trades opened (options, futures, all instruments)
- Trades closed / reduced
- Liquidation events
- Ledger events (deposits, withdrawals, settlements, fees, funding)
- Position changes (new positions, closed positions, size changes)

All via REST polling - no WebSocket dependency.
"""

from __future__ import annotations

import asyncio
import logging
import time
from collections import deque
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Dict, Optional, List, Callable, Deque, Set

logger = logging.getLogger(__name__)


class EventType(Enum):
    TRADE_OPEN = "trade_open"
    TRADE_CLOSE = "trade_close"
    TRADE_PARTIAL_CLOSE = "trade_partial_close"
    LIQUIDATION = "liquidation"
    SETTLEMENT = "settlement"
    LEDGER = "ledger"
    POSITION_OPENED = "position_opened"
    POSITION_CLOSED = "position_closed"
    POSITION_CHANGED = "position_changed"
    FUNDING = "funding"
    DEPOSIT = "deposit"
    WITHDRAWAL = "withdrawal"
    TRANSFER = "transfer"
    DELIVERY = "delivery"


@dataclass
class TxEvent:
    event_type: str
    currency: str
    channel: str
    data: Any
    timestamp: datetime = field(default_factory=lambda: datetime.now(timezone.utc))

    @property
    def as_dict(self) -> Dict[str, Any]:
        return {
            "event_type": self.event_type,
            "currency": self.currency,
            "channel": self.channel,
            "timestamp": self.timestamp.isoformat(),
            "data": self.data,
        }


@dataclass
class PositionSnapshot:
    instrument_name: str
    size: float
    direction: str
    average_price: float
    mark_price: float
    floating_pnl: float
    kind: str
    timestamp: float

    @classmethod
    def from_api(cls, p: Dict[str, Any]) -> "PositionSnapshot":
        size = float(p.get("size", 0) or 0)
        return cls(
            instrument_name=str(p.get("instrument_name", "")),
            size=size,
            direction=str(p.get("direction", "zero")).lower(),
            average_price=float(p.get("average_price", 0) or 0),
            mark_price=float(p.get("mark_price", 0) or 0),
            floating_pnl=float(p.get("floating_profit_loss", 0) or 0),
            kind=str(p.get("kind", "")).lower(),
            timestamp=time.time(),
        )


class TransactionMonitor:
    """
    REST-only trade activity and transaction monitor.

    Polling strategy:
    1. get_user_trades_by_currency -> detect new trades (open/close)
    2. get_positions -> detect position changes (new/closed/modified)
    3. get_transaction_log -> detect ledger events (deposit/withdrawal/settlement/fee)
    4. Liquidation detection from trade data + margin status
    """

    def __init__(
        self,
        deribit_client: Any,
        *,
        currencies: Optional[List[str]] = None,
        on_event: Optional[Callable[[TxEvent], Any]] = None,
        mm_status_provider: Optional[Callable[[str], Any]] = None,
        liquidation_cooldown_seconds: int = 60,
        dedup_max: int = 10000,
        trade_poll_seconds: int = 10,
        position_poll_seconds: int = 15,
        ledger_poll_seconds: int = 30,
        ledger_types: Optional[List[str]] = None,
    ) -> None:
        self.deribit = deribit_client
        self.currencies = [str(c).upper() for c in (currencies or ["BTC"])]
        self.on_event = on_event
        self.mm_status_provider = mm_status_provider

        self._liq_cooldown_seconds = int(liquidation_cooldown_seconds)
        self._last_liq_ts: Dict[str, float] = {}

        self._running = False
        self._trade_task: Optional[asyncio.Task] = None
        self._position_task: Optional[asyncio.Task] = None
        self._ledger_task: Optional[asyncio.Task] = None

        self._seen_trade_ids: Dict[str, int] = {}
        self._seen_trade_order: Deque[str] = deque(maxlen=dedup_max)
        self._seen_ledger: Dict[str, int] = {}
        self._seen_ledger_order: Deque[str] = deque(maxlen=dedup_max)
        self._dedup_max = int(dedup_max)

        self._trade_poll_seconds = max(5, int(trade_poll_seconds))
        self._position_poll_seconds = max(10, int(position_poll_seconds))
        self._ledger_poll_seconds = max(10, int(ledger_poll_seconds))

        self._ledger_types = ledger_types or [
            "deposit", "withdrawal", "transfer",
            "settlement", "funding", "fee", "delivery",
        ]

        self._last_trade_ts: Dict[str, int] = {}
        self._last_ledger_ts: Dict[str, int] = {}

        self._known_positions: Dict[str, Dict[str, PositionSnapshot]] = {}
        self._positions_initialized: Set[str] = set()

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------
    async def start(self) -> None:
        if self._running:
            return
        self._running = True

        now_ms = int(time.time() * 1000)
        for cur in self.currencies:
            self._last_trade_ts.setdefault(cur, now_ms - 120_000)
            self._last_ledger_ts.setdefault(cur, now_ms - 60_000)
            self._known_positions.setdefault(cur, {})

        await self._initialize_positions()

        self._trade_task = asyncio.create_task(self._trade_poll_loop())
        self._position_task = asyncio.create_task(self._position_poll_loop())
        self._ledger_task = asyncio.create_task(self._ledger_poll_loop())

        logger.info(
            "TransactionMonitor started | currencies=%s | "
            "trade_poll=%ds | position_poll=%ds | ledger_poll=%ds",
            self.currencies, self._trade_poll_seconds,
            self._position_poll_seconds, self._ledger_poll_seconds,
        )

    async def stop(self) -> None:
        self._running = False
        for task in (self._trade_task, self._position_task, self._ledger_task):
            if task:
                task.cancel()
                try:
                    await task
                except asyncio.CancelledError:
                    pass
        logger.info("TransactionMonitor stopped")

    # ------------------------------------------------------------------
    # Dedup helpers
    # ------------------------------------------------------------------
    def _remember_trade(self, key: str) -> bool:
        if key in self._seen_trade_ids:
            return False
        if len(self._seen_trade_order) >= self._dedup_max:
            old = self._seen_trade_order[0]
            self._seen_trade_ids.pop(old, None)
        self._seen_trade_ids[key] = 1
        self._seen_trade_order.append(key)
        return True

    def _remember_ledger(self, key: str) -> bool:
        if key in self._seen_ledger:
            return False
        if len(self._seen_ledger_order) >= self._dedup_max:
            old = self._seen_ledger_order[0]
            self._seen_ledger.pop(old, None)
        self._seen_ledger[key] = 1
        self._seen_ledger_order.append(key)
        return True

    # ------------------------------------------------------------------
    # Position snapshot initialization
    # ------------------------------------------------------------------
    async def _initialize_positions(self) -> None:
        for cur in self.currencies:
            try:
                positions = await self.deribit.get_positions(cur)
                for p in positions:
                    size = float(p.get("size", 0) or 0)
                    if size == 0:
                        continue
                    snap = PositionSnapshot.from_api(p)
                    self._known_positions[cur][snap.instrument_name] = snap
                self._positions_initialized.add(cur)
                logger.info(
                    "Initialized %d positions for %s",
                    len(self._known_positions[cur]), cur,
                )
            except Exception as e:
                logger.error("Failed to initialize positions for %s: %s", cur, e)

    # ------------------------------------------------------------------
    # Event emission
    # ------------------------------------------------------------------
    async def _emit(self, ev: TxEvent) -> None:
        if not self._running or not self.on_event:
            return
        try:
            if asyncio.iscoroutinefunction(self.on_event):
                await self.on_event(ev)
            else:
                self.on_event(ev)
        except Exception as e:
            logger.error("on_event handler failed: %s", e, exc_info=True)

    # ------------------------------------------------------------------
    # Liquidation detection
    # ------------------------------------------------------------------
    def _is_liquidation_trade(self, trade: Dict[str, Any]) -> bool:
        liq_field = trade.get("liquidation")
        if liq_field and str(liq_field).upper() != "NONE":
            return True

        label = str(trade.get("label") or "").lower()
        if "liquidat" in label:
            return True

        trade_type = str(trade.get("type") or "").lower()
        if "liquidat" in trade_type:
            return True

        return False

    def _is_liquidation_from_margin(self, currency: str) -> bool:
        if not self.mm_status_provider:
            return False
        try:
            s = self.mm_status_provider(currency)
            if s:
                lvl = str(getattr(s, "alert_level", "") or "")
                mm_pct = getattr(s, "mm_percentage", None)
                if "LIQUIDATION" in lvl.upper():
                    return True
                if mm_pct is not None and float(mm_pct) >= 100.0:
                    return True
        except Exception:
            pass
        return False

    def _liquidation_cooldown_ok(self, currency: str) -> bool:
        now = time.time()
        last = self._last_liq_ts.get(currency, 0.0)
        if now - last < self._liq_cooldown_seconds:
            return False
        self._last_liq_ts[currency] = now
        return True

    # ------------------------------------------------------------------
    # Trade classification
    # ------------------------------------------------------------------
    @staticmethod
    def _classify_trade(trade: Dict[str, Any]) -> str:
        direction = str(trade.get("direction", "")).lower()
        instrument = str(trade.get("instrument_name", ""))

        reduce_only = trade.get("reduce_only", False)
        if reduce_only:
            return EventType.TRADE_CLOSE.value

        state = str(trade.get("state", "")).lower()
        if state == "closed":
            return EventType.TRADE_CLOSE.value

        if "close" in str(trade.get("label") or "").lower():
            return EventType.TRADE_CLOSE.value

        return EventType.TRADE_OPEN.value

    # ------------------------------------------------------------------
    # Trade polling loop
    # ------------------------------------------------------------------
    async def _trade_poll_loop(self) -> None:
        while self._running:
            try:
                for cur in self.currencies:
                    if not self._running:
                        break
                    await self._poll_trades(cur)
                    await asyncio.sleep(0.5)

                await asyncio.sleep(self._trade_poll_seconds)
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error("Trade poll error: %s", e, exc_info=True)
                await asyncio.sleep(5)

    async def _poll_trades(self, currency: str) -> None:
        start_ts = self._last_trade_ts.get(currency, int(time.time() * 1000) - 120_000)
        end_ts = int(time.time() * 1000)

        try:
            result = await self.deribit.get_user_trades_by_currency(
                currency,
                count=100,
                start_timestamp=start_ts,
                end_timestamp=end_ts,
                sorting="asc",
            )
        except Exception as e:
            logger.error("Trade poll error for %s: %s", currency, e)
            return

        trades = result.get("trades") or []
        if not trades:
            return

        for trade in trades:
            trade_id = trade.get("trade_id")
            if not trade_id:
                continue

            key = f"trade:{currency}:{trade_id}"
            if not self._remember_trade(key):
                continue

            is_liq = self._is_liquidation_trade(trade)

            if is_liq and self._liquidation_cooldown_ok(currency):
                await self._emit(TxEvent(
                    event_type=EventType.LIQUIDATION.value,
                    currency=currency,
                    channel="user_trades",
                    data=trade,
                ))

            event_type = self._classify_trade(trade)

            await self._emit(TxEvent(
                event_type=event_type,
                currency=currency,
                channel="user_trades",
                data=trade,
            ))

            ts = int(trade.get("timestamp", end_ts) or end_ts)
            self._last_trade_ts[currency] = max(
                self._last_trade_ts.get(currency, 0), ts + 1,
            )

    # ------------------------------------------------------------------
    # Position polling loop
    # ------------------------------------------------------------------
    async def _position_poll_loop(self) -> None:
        while self._running:
            try:
                for cur in self.currencies:
                    if not self._running:
                        break
                    await self._poll_positions(cur)
                    await asyncio.sleep(0.5)

                await asyncio.sleep(self._position_poll_seconds)
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error("Position poll error: %s", e, exc_info=True)
                await asyncio.sleep(5)

    async def _poll_positions(self, currency: str) -> None:
        try:
            positions = await self.deribit.get_positions(currency)
        except Exception as e:
            logger.error("Position poll error for %s: %s", currency, e)
            return

        current_instruments: Set[str] = set()
        known = self._known_positions.get(currency, {})

        for p in positions:
            instrument = str(p.get("instrument_name", ""))
            size = float(p.get("size", 0) or 0)

            if size == 0:
                continue

            current_instruments.add(instrument)
            snap = PositionSnapshot.from_api(p)

            if instrument not in known:
                known[instrument] = snap
                if currency in self._positions_initialized:
                    await self._emit(TxEvent(
                        event_type=EventType.POSITION_OPENED.value,
                        currency=currency,
                        channel="positions",
                        data=p,
                    ))
            else:
                old = known[instrument]
                if abs(snap.size - old.size) > 1e-12 or snap.direction != old.direction:
                    known[instrument] = snap
                    await self._emit(TxEvent(
                        event_type=EventType.POSITION_CHANGED.value,
                        currency=currency,
                        channel="positions",
                        data={
                            "instrument_name": instrument,
                            "old_size": old.size,
                            "new_size": snap.size,
                            "old_direction": old.direction,
                            "new_direction": snap.direction,
                            "mark_price": snap.mark_price,
                            "floating_pnl": snap.floating_pnl,
                            "kind": snap.kind,
                        },
                    ))

        closed = set(known.keys()) - current_instruments
        for instrument in closed:
            old_snap = known.pop(instrument)
            if currency in self._positions_initialized:
                await self._emit(TxEvent(
                    event_type=EventType.POSITION_CLOSED.value,
                    currency=currency,
                    channel="positions",
                    data={
                        "instrument_name": instrument,
                        "last_size": old_snap.size,
                        "last_direction": old_snap.direction,
                        "average_price": old_snap.average_price,
                        "kind": old_snap.kind,
                    },
                ))

        self._known_positions[currency] = known

    # ------------------------------------------------------------------
    # Ledger polling loop
    # ------------------------------------------------------------------
    async def _ledger_poll_loop(self) -> None:
        while self._running:
            try:
                for cur in self.currencies:
                    if not self._running:
                        break
                    await self._poll_ledger(cur)
                    await asyncio.sleep(1.0)

                await asyncio.sleep(self._ledger_poll_seconds)
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error("Ledger poll error: %s", e, exc_info=True)
                await asyncio.sleep(5)

    async def _poll_ledger(self, currency: str) -> None:
        start_ts = self._last_ledger_ts.get(currency, int(time.time() * 1000) - 60_000)
        end_ts = int(time.time() * 1000)

        try:
            res = await self.deribit.get_transaction_log(
                currency,
                start_timestamp=start_ts,
                end_timestamp=end_ts,
                count=100,
                types=self._ledger_types,
            )
        except Exception as e:
            logger.error("Ledger poll error for %s: %s", currency, e)
            return

        logs = (res or {}).get("logs") or []
        if not logs:
            self._last_ledger_ts[currency] = max(
                self._last_ledger_ts.get(currency, 0), end_ts - 10_000,
            )
            return

        logs_sorted = sorted(logs, key=lambda x: int(x.get("timestamp", 0) or 0))

        for row in logs_sorted:
            log_id = row.get("id")
            ts = row.get("timestamp")
            ttype = str(row.get("type") or "unknown").lower()

            key = f"ledger:{currency}:{log_id}:{ts}:{ttype}"
            if log_id is not None and not self._remember_ledger(key):
                continue

            event_type = self._map_ledger_type(ttype)

            await self._emit(TxEvent(
                event_type=event_type,
                currency=currency,
                channel="transaction_log",
                data=row,
            ))

        last_ts = int(logs_sorted[-1].get("timestamp", end_ts) or end_ts)
        self._last_ledger_ts[currency] = max(
            self._last_ledger_ts[currency], last_ts + 1,
        )

    @staticmethod
    def _map_ledger_type(ttype: str) -> str:
        mapping = {
            "deposit": EventType.DEPOSIT.value,
            "withdrawal": EventType.WITHDRAWAL.value,
            "transfer": EventType.TRANSFER.value,
            "settlement": EventType.SETTLEMENT.value,
            "funding": EventType.FUNDING.value,
            "delivery": EventType.DELIVERY.value,
        }
        return mapping.get(ttype, EventType.LEDGER.value)