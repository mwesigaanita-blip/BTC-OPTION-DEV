# mm_alert_bot\core\margin_monitor.py
"""
Margin Monitor
Core logic for monitoring maintenance margin and triggering alerts.

- Hot-reloads thresholds/cooldowns/interval/currencies from DB via async config_provider
- Cross-portfolio mode (single API call) or per-currency mode
- Cooldown logic to prevent alert spam
- Single consistent MM% formula
"""

from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from enum import Enum
from typing import Optional, Dict, Any, Callable, List

logger = logging.getLogger(__name__)


class AlertLevel(Enum):
    NORMAL = "NORMAL"
    WARNING = "WARNING"
    CRITICAL = "CRITICAL"
    LIQUIDATION = "LIQUIDATION"


@dataclass
class AlertConfig:
    """Alert thresholds in PERCENT (e.g. 60.0 = 60%)."""
    warning_threshold: float = 80.0
    critical_threshold: float = 95.0
    liquidation_threshold: float = 100.0
    warning_cooldown_minutes: int = 5
    critical_cooldown_minutes: int = 1
    check_interval_seconds: int = 30
    alert_on_portfolio_total: bool = True
    alert_on_each_currency: bool = False


@dataclass
class MarginStatus:
    """Snapshot of current margin state."""
    mm_percentage: float
    im_percentage: float
    equity: float
    maintenance_margin: float
    initial_margin: float
    available_funds: float
    margin_balance: float
    currency: str
    warning_threshold: float
    critical_threshold: float
    timestamp: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    alert_level: AlertLevel = field(init=False)

    def __post_init__(self) -> None:
        if self.mm_percentage >= 100:
            self.alert_level = AlertLevel.LIQUIDATION
        elif self.mm_percentage >= self.critical_threshold:
            self.alert_level = AlertLevel.CRITICAL
        elif self.mm_percentage >= self.warning_threshold:
            self.alert_level = AlertLevel.WARNING
        else:
            self.alert_level = AlertLevel.NORMAL

    @property
    def as_dict(self) -> Dict[str, Any]:
        return {
            "mm_percentage": self.mm_percentage,
            "im_percentage": self.im_percentage,
            "equity": self.equity,
            "maintenance_margin": self.maintenance_margin,
            "initial_margin": self.initial_margin,
            "available_funds": self.available_funds,
            "margin_balance": self.margin_balance,
            "currency": self.currency,
            "alert_level": self.alert_level.value,
            "timestamp": self.timestamp.isoformat(),
            "warning_threshold": self.warning_threshold,
            "critical_threshold": self.critical_threshold,
        }


def _apply_config(config: AlertConfig, cfg: Dict[str, Any]) -> None:
    """Apply DB config values to AlertConfig (mutates in place)."""
    fields = {
        "warning_threshold": float,
        "critical_threshold": float,
        "warning_cooldown_minutes": int,
        "critical_cooldown_minutes": int,
        "check_interval_seconds": int,
    }
    for key, cast in fields.items():
        if key in cfg:
            setattr(config, key, cast(cfg[key]))


class MarginMonitor:
    """
    Polls Deribit account summary and fires alert callbacks
    when MM% exceeds configured thresholds (with cooldown).
    """

    PORTFOLIO_KEY = "PORTFOLIO"

    def __init__(
        self,
        deribit_client: Any,
        alert_config: Optional[AlertConfig] = None,
        currencies: Optional[List[str]] = None,
        config_provider: Optional[Callable[[], Any]] = None,
        config_refresh_seconds: int = 10,
        normalize_mm_units: bool = True,
        base_currency: str = "BTC",
        cross_portfolio_mode: bool = True,
    ) -> None:
        self.deribit = deribit_client
        self.config = alert_config or AlertConfig()
        self.currencies = currencies or ["BTC"]
        self.base_currency = str(base_currency).upper()
        self.cross_portfolio_mode = bool(cross_portfolio_mode)

        self._config_provider = config_provider
        self._config_refresh_seconds = max(1, int(config_refresh_seconds))
        self._last_config_fetch: Optional[datetime] = None
        self._is_enabled: bool = True

        self._normalize_mm_units = bool(normalize_mm_units)
        self._running = False
        self._monitor_task: Optional[asyncio.Task] = None

        self._last_alert_time: Dict[str, Dict[str, datetime]] = {}
        self._alert_callbacks: List[Callable] = []
        self._current_status: Dict[str, MarginStatus] = {}

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------
    async def start_monitoring(self) -> None:
        if self._running:
            logger.warning("Monitoring already running")
            return
        self._running = True
        self._monitor_task = asyncio.create_task(self._monitoring_loop())
        logger.info(
            "Started monitoring | cross=%s | base=%s | currencies=%s | interval=%ds",
            self.cross_portfolio_mode, self.base_currency,
            self.currencies, self.config.check_interval_seconds,
        )

    async def stop_monitoring(self) -> None:
        self._running = False
        if self._monitor_task:
            self._monitor_task.cancel()
            try:
                await self._monitor_task
            except asyncio.CancelledError:
                pass
        logger.info("Monitoring stopped")

    def get_current_status(self, currency: str = "BTC") -> Optional[MarginStatus]:
        return self._current_status.get(currency)

    def add_alert_callback(self, callback: Callable[[MarginStatus, Dict], Any]) -> None:
        self._alert_callbacks.append(callback)
        logger.info("Alert callback registered: %s", getattr(callback, "__name__", str(callback)))

    # ------------------------------------------------------------------
    # Config hot-reload
    # ------------------------------------------------------------------
    async def _refresh_config_if_needed(self) -> None:
        if not self._config_provider:
            return

        now = datetime.now(timezone.utc)
        if (
            self._last_config_fetch is not None
            and (now - self._last_config_fetch).total_seconds() < self._config_refresh_seconds
        ):
            return

        try:
            cfg = await self._config_provider()
            if not isinstance(cfg, dict):
                logger.warning("Config provider returned non-dict: %s", type(cfg))
                self._last_config_fetch = now
                return

            _apply_config(self.config, cfg)

            ccs = cfg.get("currencies")
            if isinstance(ccs, list) and ccs:
                self.currencies = [str(x) for x in ccs]

            self._is_enabled = bool(cfg.get("is_enabled", True))
            self._last_config_fetch = now

            logger.info(
                "Config refreshed: warn=%.1f crit=%.1f warn_cd=%dm crit_cd=%dm "
                "interval=%ds enabled=%s currencies=%s",
                self.config.warning_threshold, self.config.critical_threshold,
                self.config.warning_cooldown_minutes, self.config.critical_cooldown_minutes,
                self.config.check_interval_seconds, self._is_enabled, self.currencies,
            )
        except Exception as e:
            logger.error("Config refresh failed: %s", e, exc_info=True)
            self._last_config_fetch = now

    # ------------------------------------------------------------------
    # Main loop
    # ------------------------------------------------------------------
    async def _monitoring_loop(self) -> None:
        while self._running:
            try:
                await self._refresh_config_if_needed()

                if self.cross_portfolio_mode:
                    await self._check_cross_portfolio()
                else:
                    await self._check_per_currency()

                await asyncio.sleep(self.config.check_interval_seconds)

            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error("Monitoring error: %s", e, exc_info=True)
                await asyncio.sleep(5)

    async def _check_cross_portfolio(self) -> None:
        acct = await self._fetch_account(self.base_currency)
        if acct is None:
            return

        status = self._build_status(self.PORTFOLIO_KEY, acct)
        self._current_status[self.PORTFOLIO_KEY] = status

        logger.info(
            "%s (CROSS) MM=%.2f%% | Level=%s | warn=%.1f crit=%.1f",
            self.PORTFOLIO_KEY, status.mm_percentage,
            status.alert_level.value, status.warning_threshold,
            status.critical_threshold,
        )

        if self._is_enabled and self.config.alert_on_portfolio_total:
            await self._maybe_alert(self.PORTFOLIO_KEY, status, {
                "mode": "CROSS",
                "base_currency": self.base_currency,
                "account": acct,
            })

    async def _check_per_currency(self) -> None:
        for ccy in self.currencies:
            acct = await self._fetch_account(ccy)
            if acct is None:
                continue

            status = self._build_status(ccy, acct)
            self._current_status[ccy] = status

            logger.info(
                "%s MM=%.2f%% | Level=%s",
                ccy, status.mm_percentage, status.alert_level.value,
            )

            if self._is_enabled and self.config.alert_on_each_currency:
                await self._maybe_alert(ccy, status, acct)

    async def _fetch_account(self, currency: str) -> Optional[Dict[str, Any]]:
        try:
            return await self.deribit.get_account_summary(
                str(currency).upper(), extended=True,
            )
        except Exception as e:
            logger.error("Error fetching account summary %s: %s", currency, e, exc_info=True)
            return None

    # ------------------------------------------------------------------
    # MM% & IM% calculation
    # ------------------------------------------------------------------
    def _build_status(self, label: str, acct: Dict[str, Any]) -> MarginStatus:
        """
        MM% = maintenance_margin / margin_balance * 100
        IM% = initial_margin / margin_balance * 100
        Falls back to equity if margin_balance is 0/missing.
        """
        equity = float(acct.get("equity", 0) or 0)
        maint = float(acct.get("maintenance_margin", 0) or 0)
        initm = float(acct.get("initial_margin", 0) or 0)
        avail = float(acct.get("available_funds", 0) or 0)
        margin_balance = float(acct.get("margin_balance", 0) or 0)

        denom = margin_balance if margin_balance > 0 else equity
        mm_pct = (maint / denom) * 100.0 if denom > 0 and maint > 0 else 0.0
        im_pct = (initm / denom) * 100.0 if denom > 0 and initm > 0 else 0.0

        return MarginStatus(
            mm_percentage=mm_pct,
            im_percentage=im_pct,
            equity=equity,
            maintenance_margin=maint,
            initial_margin=initm,
            available_funds=avail,
            margin_balance=margin_balance,
            currency=label,
            warning_threshold=self.config.warning_threshold,
            critical_threshold=self.config.critical_threshold,
        )

    # ------------------------------------------------------------------
    # Alert logic
    # ------------------------------------------------------------------
    async def _maybe_alert(self, key: str, status: MarginStatus, account_data: Dict) -> None:
        if self._should_alert(key, status.alert_level):
            self._mark_alert_sent(key, status.alert_level)
            await self._trigger_callbacks(status, account_data)

    def _should_alert(self, key: str, level: AlertLevel) -> bool:
        if level == AlertLevel.NORMAL:
            return False

        self._last_alert_time.setdefault(key, {})
        last = self._last_alert_time[key].get(level.value)
        if not last:
            return True

        cooldown = timedelta(minutes=self._get_cooldown_minutes(level))
        return datetime.now(timezone.utc) - last >= cooldown

    def _get_cooldown_minutes(self, level: AlertLevel) -> int:
        if level in (AlertLevel.CRITICAL, AlertLevel.LIQUIDATION):
            return self.config.critical_cooldown_minutes
        if level == AlertLevel.WARNING:
            return self.config.warning_cooldown_minutes
        return 999_999

    def _mark_alert_sent(self, key: str, level: AlertLevel) -> None:
        self._last_alert_time.setdefault(key, {})
        self._last_alert_time[key][level.value] = datetime.now(timezone.utc)

    async def _trigger_callbacks(self, status: MarginStatus, account_data: Dict) -> None:
        for callback in self._alert_callbacks:
            try:
                if asyncio.iscoroutinefunction(callback):
                    await callback(status, account_data)
                else:
                    callback(status, account_data)
            except Exception as e:
                logger.error("Callback error: %s", e, exc_info=True)