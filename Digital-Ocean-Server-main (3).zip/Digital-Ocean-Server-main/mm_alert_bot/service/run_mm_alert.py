# mm_alert_bot\service\run_mm_alert.py
"""
MM Alert Service - Process Entry Point
Handles graceful shutdown on SIGINT/SIGTERM with timeout.
"""

import asyncio
import logging
import sys
import signal

from mm_alert_bot.service.mm_alert_service import MMAlertService

logger = logging.getLogger(__name__)

_SHUTDOWN_TIMEOUT = 15.0


def _setup_logging() -> None:
    """Configure root logger to stdout with consistent format."""
    root = logging.getLogger()
    root.setLevel(logging.INFO)

    handler = logging.StreamHandler(sys.stdout)
    handler.setLevel(logging.INFO)
    handler.setFormatter(logging.Formatter(
        "%(asctime)s | %(levelname)s | %(name)s | %(message)s"
    ))

    # Replace all handlers (avoid duplicates on re-run)
    root.handlers = [handler]

    # Ensure mm_alert_bot loggers propagate to root
    pkg_logger = logging.getLogger("mm_alert_bot")
    pkg_logger.propagate = True
    pkg_logger.setLevel(logging.INFO)


async def _run_service() -> None:
    """Initialize, run, and gracefully shut down the service."""
    svc = MMAlertService()
    stop_event = asyncio.Event()

    def _request_stop(*_: object) -> None:
        logger.info("Shutdown signal received")
        stop_event.set()

    # Register OS signal handlers
    loop = asyncio.get_running_loop()
    for sig in (signal.SIGINT, signal.SIGTERM):
        try:
            loop.add_signal_handler(sig, _request_stop)
        except NotImplementedError:
            # Windows fallback
            signal.signal(sig, _request_stop)

    try:
        logger.info("Initializing MM Alert Service...")
        await svc.initialize()

        logger.info("Starting MM Alert Service...")
        await svc.start()

        logger.info("Service running - waiting for shutdown signal")
        await stop_event.wait()

    except Exception:
        logger.exception("Fatal error during service lifecycle")
    finally:
        logger.info("Shutting down MM Alert Service...")
        try:
            await asyncio.wait_for(svc.stop(), timeout=_SHUTDOWN_TIMEOUT)
        except asyncio.TimeoutError:
            logger.error(
                "Shutdown timed out after %.0fs - forcing exit", _SHUTDOWN_TIMEOUT,
            )
        except Exception:
            logger.exception("Error during shutdown")


def main() -> None:
    """Entry point."""
    _setup_logging()
    logger.info("run_mm_alert: process started")

    try:
        asyncio.run(_run_service())
    except KeyboardInterrupt:
        logger.info("KeyboardInterrupt - exiting")
    finally:
        logger.info("run_mm_alert: process exited")


if __name__ == "__main__":
    main()