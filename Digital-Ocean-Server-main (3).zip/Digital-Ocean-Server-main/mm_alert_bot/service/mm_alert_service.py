# mm_alert_bot\service\mm_alert_service.py
"""
MM Alert Service (REST-only)
Orchestrates Deribit (HTTP JSON-RPC) + Telegram + MarginMonitor + TradeMonitor.

Key behavior:
- Reads MM alert config directly from SQLite via mm_alert_config_store
- MarginMonitor hot-reloads config periodically via config_provider
- Full trade activity monitoring (opens, closes, liquidations, positions)
- Telegram sends alerts to multiple members from .env
- Rich formatted messages for all event types
"""

from __future__ import annotations

import asyncio
import logging
import os
from pathlib import Path
from typing import TYPE_CHECKING, Optional, Dict, Any, List, Set
from datetime import datetime, timezone, timedelta
import sqlite3
import yaml

from mm_alert_bot.api.deribit_client import DeribitClient
from mm_alert_bot.api.telegram_client import TelegramClient
from mm_alert_bot.api.telegram_handler import TelegramCommandHandler
from mm_alert_bot.core.margin_monitor import MarginMonitor, AlertConfig, MarginStatus
from backend_api.mm_alert_config_store import read_config
from multi_agent_system.config import DB_PATH


if TYPE_CHECKING:
    from mm_alert_bot.core.transaction_monitor import TransactionMonitor, TxEvent

logger = logging.getLogger(__name__)

_TELEGRAM_RETRY_ATTEMPTS = 2
_TELEGRAM_RETRY_DELAY = 1.0
_CONFIG_REFRESH_SECONDS = 10
_TX_MONITOR_TRUTHY = frozenset({"1", "true", "yes", "y", "on"})


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def _ts_to_iso(ts: Any, fallback_iso: str) -> str:
    if ts is None:
        return fallback_iso
    try:
        val = int(ts) if isinstance(ts, str) and ts.isdigit() else ts
        if isinstance(val, (int, float)):
            return datetime.fromtimestamp(
                val / 1000.0 if val > 1e10 else val, tz=timezone.utc,
            ).strftime("%Y-%m-%d %H:%M:%S UTC")
        return str(val)
    except Exception:
        return fallback_iso

_TELEGRAM_MAX_LENGTH = 4000


def _split_message(text: str, max_len: int = _TELEGRAM_MAX_LENGTH) -> List[str]:
    if not text or not text.strip():
        return []

    if len(text) <= max_len:
        return [text]

    chunks: List[str] = []
    while text:
        if len(text) <= max_len:
            chunks.append(text)
            break

        split_at = text.rfind("\n", 0, max_len)
        if split_at <= 0:
            split_at = max_len

        chunks.append(text[:split_at])
        text = text[split_at:].lstrip("\n")

    return [c for c in chunks if c.strip()]

def _instrument_kind_label(instrument_name: str) -> str:
    name = instrument_name.upper()
    if "-C" in name or "-P" in name:
        return "OPTION"
    if "PERPETUAL" in name:
        return "PERPETUAL"
    if any(c.isdigit() for c in name.split("-")[-1]) and "-C" not in name and "-P" not in name:
        return "FUTURE"
    return "UNKNOWN"


def _direction_emoji(direction: str) -> str:
    d = str(direction).lower()
    if d == "buy":
        return "🟢 BUY"
    if d == "sell":
        return "🔴 SELL"
    return f"⚪ {direction.upper()}"


def _pnl_emoji(pnl: float) -> str:
    if pnl > 0:
        return f"🟢 +{pnl:.6f}"
    if pnl < 0:
        return f"🔴 {pnl:.6f}"
    return f"⚪ {pnl:.6f}"


# ---------------------------------------------------------------------------
# Message formatters
# ---------------------------------------------------------------------------
def _fmt_margin_alert(
    status,
    btc_price,
    portfolio_equity_usd,
    usdt_equity,
    usdc_equity,
    aum_usd,
    aum_pct,
):
    level = status.alert_level.value.upper()
    if level == "LIQUIDATION":
        header = "💀 LIQUIDATION"
        bar = "🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴"
    elif level == "CRITICAL":
        header = "🔴 CRITICAL"
        bar = "🔴🔴🔴🔴🔴🔴🔴🔴"
    else:
        header = "🟡 WARNING"
        bar = "🟡🟡🟡🟡🟡🟡"

    return (
        f"━━━━━━━━━━━━━━\n"
        f"<b>{header} MARGIN</b>\n"
        f"━━━━━━━━━━━━━━\n\n"
        f"┌─────────────────\n"
        f"│ MM: <code>{status.mm_percentage:.2f}%</code>\n"
        f"│ IM: <code>{status.im_percentage:.2f}%</code>\n"
        f"│\n"
        f"│ <b>Equity</b>\n"
        f"│ USD:  <code>${portfolio_equity_usd}</code>\n"
        f"│ BTC:  <code>{status.equity:.6f}</code>\n"
        f"│ USDT: <code>{usdt_equity}</code>\n"
        f"│ USDC: <code>{usdc_equity}</code>\n"
        f"│ Px:   <code>${btc_price}</code>\n"
        f"│\n"
        f"│ <b>Margin (BTC)</b>\n"
        f"│ Mnt: <code>{status.maintenance_margin:.6f}</code>\n"
        f"│ Ini: <code>{status.initial_margin:.6f}</code>\n"
        f"│ Avl: <code>{status.available_funds:.6f}</code>\n"
        f"│ Bal: <code>{status.margin_balance:.6f}</code>\n"
        f"│\n"
        f"│ <b>AUM Δ</b>\n"
        f"│ 1d: <code>{aum_usd['1d']} ({aum_pct['1d']})</code>\n"
        f"│ 3d: <code>{aum_usd['3d']} ({aum_pct['3d']})</code>\n"
        f"│ 1w: <code>{aum_usd['1w']} ({aum_pct['1w']})</code>\n"
        f"│\n"
        f"│ <b>Thresholds</b>\n"
        f"│ 🟡 <code>{status.warning_threshold:.1f}%</code>"
        f"  🔴 <code>{status.critical_threshold:.1f}%</code>\n"
        f"└─────────────────\n\n"
        f"<i>⏰ {status.timestamp.strftime('%Y-%m-%d %H:%M:%S UTC')}</i>"
    )


def _fmt_trade_open(ev: "TxEvent") -> str:
    t = ev.data or {}
    instrument = str(t.get("instrument_name", "N/A"))
    kind = _instrument_kind_label(instrument)
    direction = _direction_emoji(str(t.get("direction", "")))
    amount = t.get("amount") or t.get("quantity", "N/A")
    price = t.get("price", "N/A")
    fee = t.get("fee", "N/A")

    return (
        f"━━━━━━━━━━━━━━\n"
        f"<b>🟢 TRADE OPEN</b>\n"
        f"━━━━━━━━━━━━━━\n\n"
        f"┌─────────────────\n"
        f"│ <code>{instrument}</code>\n"
        f"│ {kind} · {direction}\n"
        f"│ Size: <code>{amount}</code>\n"
        f"│ Px:   <code>{price}</code>\n"
        f"│ Fee:  <code>{fee}</code>\n"
        f"│ TID:  <code>{t.get('trade_id', 'N/A')}</code>\n"
        f"│ OID:  <code>{t.get('order_id', 'N/A')}</code>\n"
        f"└─────────────────\n\n"
        f"<i>⏰ {_ts_to_iso(t.get('timestamp'), ev.timestamp.isoformat())}</i>"
    )


def _fmt_trade_close(ev: "TxEvent") -> str:
    t = ev.data or {}
    instrument = str(t.get("instrument_name", "N/A"))
    kind = _instrument_kind_label(instrument)
    direction = _direction_emoji(str(t.get("direction", "")))
    amount = t.get("amount") or t.get("quantity", "N/A")
    price = t.get("price", "N/A")
    fee = t.get("fee", "N/A")
    pnl = t.get("profit_loss") or t.get("realized_profit_loss")
    pnl_line = f"│ PnL:  {_pnl_emoji(float(pnl))}\n" if pnl is not None else ""

    return (
        f"━━━━━━━━━━━━━━\n"
        f"<b>🔴 TRADE CLOSE</b>\n"
        f"━━━━━━━━━━━━━━\n\n"
        f"┌─────────────────\n"
        f"│ <code>{instrument}</code>\n"
        f"│ {kind} · {direction}\n"
        f"│ Size: <code>{amount}</code>\n"
        f"│ Px:   <code>{price}</code>\n"
        f"│ Fee:  <code>{fee}</code>\n"
        f"{pnl_line}"
        f"│ TID:  <code>{t.get('trade_id', 'N/A')}</code>\n"
        f"└─────────────────\n\n"
        f"<i>⏰ {_ts_to_iso(t.get('timestamp'), ev.timestamp.isoformat())}</i>"
    )


def _fmt_liquidation(ev: "TxEvent", mm_line: str) -> str:
    d = ev.data or {}
    instrument = "N/A"
    if isinstance(d, dict):
        instrument = d.get("instrument_name") or d.get("instrument") or "N/A"

    direction = _direction_emoji(str(d.get("direction", ""))) if isinstance(d, dict) else ""
    amount = d.get("amount", "N/A") if isinstance(d, dict) else "N/A"
    price = d.get("price", "N/A") if isinstance(d, dict) else "N/A"

    return (
        f"━━━━━━━━━━━━━━\n"
        f"<b>💀 LIQUIDATION</b>\n"
        f"━━━━━━━━━━━━━━\n\n"
        f"<b>⚠️ ACT NOW</b>\n\n"
        f"┌─────────────────\n"
        f"│ Ccy:  <code>{ev.currency}</code>\n"
        f"│ <code>{instrument}</code>\n"
        f"│ {direction}\n"
        f"│ Size: <code>{amount}</code>\n"
        f"│ Px:   <code>{price}</code>\n"
        f"{mm_line}"
        f"│ TID:  <code>{d.get('trade_id', 'N/A') if isinstance(d, dict) else 'N/A'}</code>\n"
        f"└─────────────────\n\n"
        f"<i>⏰ {ev.timestamp.strftime('%Y-%m-%d %H:%M:%S UTC')}</i>"
    )


def _fmt_position_opened(ev: "TxEvent") -> str:
    p = ev.data or {}
    instrument = str(p.get("instrument_name", "N/A"))
    kind = _instrument_kind_label(instrument)
    direction = str(p.get("direction", "")).upper()
    size = p.get("size", "N/A")

    return (
        f"━━━━━━━━━━━━━━\n"
        f"<b>📈 POSITION OPEN</b>\n"
        f"━━━━━━━━━━━━━━\n\n"
        f"┌─────────────────\n"
        f"│ <code>{instrument}</code>\n"
        f"│ {kind} · <code>{direction}</code>\n"
        f"│ Size: <code>{size}</code>\n"
        f"│ Avg:  <code>{p.get('average_price', 'N/A')}</code>\n"
        f"│ Mark: <code>{p.get('mark_price', 'N/A')}</code>\n"
        f"│ PnL:  <code>{p.get('floating_profit_loss', 'N/A')}</code>\n"
        f"└─────────────────\n\n"
        f"<i>⏰ {ev.timestamp.strftime('%Y-%m-%d %H:%M:%S UTC')}</i>"
    )


def _fmt_position_closed(ev: "TxEvent") -> str:
    p = ev.data or {}
    instrument = str(p.get("instrument_name", "N/A"))
    kind = p.get("kind", _instrument_kind_label(instrument)).upper()

    return (
        f"━━━━━━━━━━━━━━\n"
        f"<b>📉 POSITION CLOSE</b>\n"
        f"━━━━━━━━━━━━━━\n\n"
        f"┌─────────────────\n"
        f"│ <code>{instrument}</code>\n"
        f"│ {kind} · <code>{str(p.get('last_direction', '')).upper()}</code>\n"
        f"│ Size: <code>{p.get('last_size', 'N/A')}</code>\n"
        f"│ Avg:  <code>{p.get('average_price', 'N/A')}</code>\n"
        f"└─────────────────\n\n"
        f"<i>⏰ {ev.timestamp.strftime('%Y-%m-%d %H:%M:%S UTC')}</i>"
    )


def _fmt_position_changed(ev: "TxEvent") -> str:
    p = ev.data or {}
    instrument = str(p.get("instrument_name", "N/A"))
    kind = p.get("kind", _instrument_kind_label(instrument)).upper()

    return (
        f"━━━━━━━━━━━━━━\n"
        f"<b>🔄 POSITION Δ</b>\n"
        f"━━━━━━━━━━━━━━\n\n"
        f"┌─────────────────\n"
        f"│ <code>{instrument}</code>\n"
        f"│ {kind} · <code>{str(p.get('new_direction', '')).upper()}</code>\n"
        f"│ Old:  <code>{p.get('old_size', 'N/A')}</code>\n"
        f"│ New:  <code>{p.get('new_size', 'N/A')}</code>\n"
        f"│ Mark: <code>{p.get('mark_price', 'N/A')}</code>\n"
        f"│ PnL:  <code>{p.get('floating_pnl', 'N/A')}</code>\n"
        f"└─────────────────\n\n"
        f"<i>⏰ {ev.timestamp.strftime('%Y-%m-%d %H:%M:%S UTC')}</i>"
    )


def _fmt_ledger(ev: "TxEvent") -> str:
    r = ev.data or {}
    ttype = str(r.get("type", "unknown")).upper()

    type_emoji = {
        "DEPOSIT": "💰",
        "WITHDRAWAL": "💸",
        "TRANSFER": "🔄",
        "SETTLEMENT": "📋",
        "FUNDING": "💵",
        "FEE": "🏷",
        "DELIVERY": "📦",
    }.get(ttype, "🧾")

    return (
        f"━━━━━━━━━━━━━━\n"
        f"<b>{type_emoji} {ttype}</b>\n"
        f"━━━━━━━━━━━━━━\n\n"
        f"┌─────────────────\n"
        f"│ Ccy:  <code>{ev.currency}</code>\n"
        f"│ <code>{r.get('instrument_name', 'N/A')}</code>\n"
        f"│ Δ:    <code>{r.get('change', 'N/A')}</code>\n"
        f"│ Cash: <code>{r.get('cashflow', 'N/A')}</code>\n"
        f"│ Bal:  <code>{r.get('balance', 'N/A')}</code>\n"
        f"│ TID:  <code>{r.get('trade_id', 'N/A')}</code>\n"
        f"│ LID:  <code>{r.get('id', 'N/A')}</code>\n"
        f"└─────────────────\n\n"
        f"<i>⏰ {_ts_to_iso(r.get('timestamp'), ev.timestamp.isoformat())}</i>"
    )


def _fmt_deposit(ev: "TxEvent") -> str:
    r = ev.data or {}
    return (
        f"━━━━━━━━━━━━━━\n"
        f"<b>💰 DEPOSIT</b>\n"
        f"━━━━━━━━━━━━━━\n\n"
        f"┌─────────────────\n"
        f"│ Ccy: <code>{ev.currency}</code>\n"
        f"│ Amt: <code>{r.get('change') or r.get('amount', 'N/A')}</code>\n"
        f"│ Bal: <code>{r.get('balance', 'N/A')}</code>\n"
        f"│ ID:  <code>{r.get('id', 'N/A')}</code>\n"
        f"└─────────────────\n\n"
        f"<i>⏰ {_ts_to_iso(r.get('timestamp'), ev.timestamp.isoformat())}</i>"
    )


def _fmt_withdrawal(ev: "TxEvent") -> str:
    r = ev.data or {}
    return (
        f"━━━━━━━━━━━━━━\n"
        f"<b>💸 WITHDRAWAL</b>\n"
        f"━━━━━━━━━━━━━━\n\n"
        f"┌─────────────────\n"
        f"│ Ccy: <code>{ev.currency}</code>\n"
        f"│ Amt: <code>{r.get('change') or r.get('amount', 'N/A')}</code>\n"
        f"│ Bal: <code>{r.get('balance', 'N/A')}</code>\n"
        f"│ ID:  <code>{r.get('id', 'N/A')}</code>\n"
        f"└─────────────────\n\n"
        f"<i>⏰ {_ts_to_iso(r.get('timestamp'), ev.timestamp.isoformat())}</i>"
    )


def _fmt_settlement(ev: "TxEvent") -> str:
    r = ev.data or {}
    return (
        f"━━━━━━━━━━━━━━\n"
        f"<b>📋 SETTLEMENT</b>\n"
        f"━━━━━━━━━━━━━━\n\n"
        f"┌─────────────────\n"
        f"│ Ccy: <code>{ev.currency}</code>\n"
        f"│ <code>{r.get('instrument_name', 'N/A')}</code>\n"
        f"│ Δ:   <code>{r.get('change', 'N/A')}</code>\n"
        f"│ Bal: <code>{r.get('balance', 'N/A')}</code>\n"
        f"│ ID:  <code>{r.get('id', 'N/A')}</code>\n"
        f"└─────────────────\n\n"
        f"<i>⏰ {_ts_to_iso(r.get('timestamp'), ev.timestamp.isoformat())}</i>"
    )


# ---------------------------------------------------------------------------
# Service
# ---------------------------------------------------------------------------
class MMAlertService:
    """REST-only margin monitoring service with full trade activity alerts."""

    __slots__ = (
        "config_path", "config", "deribit", "telegram",
        "monitor", "tx_monitor", "cmd_handler", "_running", "_alert_chat_ids", "_db_cfg_cache",
    )

    def __init__(self, config_path: Optional[str] = None) -> None:
        self.config_path: str = (
            config_path
            or os.getenv("MM_ALERT_CONFIG_PATH", "mm_alert_config.yml")
        )
        self.config: Dict[str, Any] = {}
        self.deribit: Optional[DeribitClient] = None
        self.telegram: Optional[TelegramClient] = None
        self.monitor: Optional[MarginMonitor] = None
        self.tx_monitor: Optional[Any] = None
        self.cmd_handler: Optional[TelegramCommandHandler] = None
        self._running: bool = False
        self._alert_chat_ids: List[str] = []
        self._db_cfg_cache: Dict[str, Any] = {}

    # ------------------------------------------------------------------
    # Config
    # ------------------------------------------------------------------
    def _load_yaml(self) -> Dict[str, Any]:
        p = Path(self.config_path)
        if not p.exists():
            logger.warning("Config file not found: %s (using env/defaults)", p.resolve())
            return {}
        with p.open("r", encoding="utf-8") as f:
            return yaml.safe_load(f) or {}

    def _read_db_config(self) -> Dict[str, Any]:
        try:
            self._db_cfg_cache = read_config() or {}
        except Exception as e:
            logger.error("Failed to read DB config: %s", e)
            self._db_cfg_cache = {}
        return self._db_cfg_cache

    async def _fetch_mm_config(self) -> Dict[str, Any]:
        return read_config()

    def _load_alert_chat_ids(self) -> List[str]:
        import os
        import json

        raw = os.getenv("TELEGRAM_CHAT_IDS", "{}")

        try:
            data = json.loads(raw)
        except Exception:
            data = {}

        result: List[str] = []
        seen: Set[str] = set()

        for chat_id in data.values():
            cid = str(chat_id).strip()

            if cid and cid not in seen:
                seen.add(cid)
                result.append(cid)

        return result

    # ------------------------------------------------------------------
    # Telegram helpers
    # ------------------------------------------------------------------
    async def _send_message_to_all(self, message: str) -> None:
        if not self.telegram or not self._alert_chat_ids:
            return
        for chunk in _split_message(message):
            tasks = [
                self._send_with_retry(chunk, chat_id)
                for chat_id in self._alert_chat_ids
            ]
            await asyncio.gather(*tasks, return_exceptions=True)

    async def _send_with_retry(self, message: str, chat_id: str) -> None:
        last_err: Optional[Exception] = None
        for attempt in range(_TELEGRAM_RETRY_ATTEMPTS):
            try:
                await self.telegram.send_message(message, chat_id=chat_id)
                return
            except Exception as e:
                last_err = e
                if attempt < _TELEGRAM_RETRY_ATTEMPTS - 1:
                    logger.warning(
                        "Telegram send to %s failed (attempt %d/%d): %s",
                        chat_id, attempt + 1, _TELEGRAM_RETRY_ATTEMPTS, e,
                    )
                    await asyncio.sleep(_TELEGRAM_RETRY_DELAY)
        logger.error(
            "Telegram send to %s failed after %d attempts: %s",
            chat_id, _TELEGRAM_RETRY_ATTEMPTS, last_err, exc_info=True,
        )

    async def _fetch_btc_price_str(self) -> str:
        try:
            price = await self.deribit.get_btc_price_usd()
            return f"{price:,.2f}"
        except Exception as e:
            logger.warning("Failed to fetch BTC price: %s", e, exc_info=True)
            return "N/A"

    # ------------------------------------------------------------------
    # Initialize
    # ------------------------------------------------------------------
    async def initialize(self) -> None:
        self.config = self._load_yaml()

        deribit_cfg = self.config.get("deribit") or {}
        self.deribit = DeribitClient({
            "client_id": os.getenv("DERIBIT_CLIENT_ID", deribit_cfg.get("client_id")),
            "client_secret": os.getenv("DERIBIT_CLIENT_SECRET", deribit_cfg.get("client_secret")),
            "testnet": bool(int(os.getenv(
                "DERIBIT_TESTNET", str(int(deribit_cfg.get("testnet", 0))),
            ))),
            "http_base": os.getenv("DERIBIT_HTTP_BASE", deribit_cfg.get("http_base")),
        })
        logger.info("Deribit client ready (REST-only)")

        await self._init_telegram()

        self._alert_chat_ids = self._load_alert_chat_ids()
        logger.info(
            "Loaded %d Telegram alert recipient(s): %s",
            len(self._alert_chat_ids), self._alert_chat_ids,
        )

        db_cfg = self._read_db_config()

        alert_config = AlertConfig(
            warning_threshold=float(db_cfg.get("warning_threshold", 80.0)),
            critical_threshold=float(db_cfg.get("critical_threshold", 95.0)),
            warning_cooldown_minutes=int(db_cfg.get("warning_cooldown_minutes", 5)),
            critical_cooldown_minutes=int(db_cfg.get("critical_cooldown_minutes", 1)),
            check_interval_seconds=int(db_cfg.get("check_interval_seconds", 30)),
            alert_on_portfolio_total=True,
            alert_on_each_currency=False,
        )
        currencies = db_cfg.get("currencies") or ["BTC"]

        logger.info(
            "DB config: warn=%.1f crit=%.1f interval=%ds currencies=%s",
            alert_config.warning_threshold, alert_config.critical_threshold,
            alert_config.check_interval_seconds, currencies,
        )

        base_ccy = os.getenv("MM_ALERT_BASE_CURRENCY", "BTC").upper()
        self.monitor = MarginMonitor(
            deribit_client=self.deribit,
            alert_config=alert_config,
            currencies=currencies,
            config_provider=self._fetch_mm_config,
            config_refresh_seconds=_CONFIG_REFRESH_SECONDS,
            normalize_mm_units=True,
            base_currency=base_ccy,
            cross_portfolio_mode=True,
        )
        self.monitor.add_alert_callback(self._on_alert)

        await self._init_tx_monitor(currencies)
        await self._init_command_handler()

    async def _init_telegram(self) -> None:
        notify_cfg = (self.config.get("notifications") or {}).get("telegram") or {}
        self.telegram = TelegramClient(
            bot_token=os.getenv("TELEGRAM_BOT_TOKEN", notify_cfg.get("bot_token", "")),
            owner_chat_id=os.getenv("TELEGRAM_OWNER_CHAT_ID", notify_cfg.get("admin", "")),
            client_chat_id=os.getenv("TELEGRAM_CLIENT_CHAT_ID", notify_cfg.get("client", "")),
        )
        if await self.telegram.test_connection():
            logger.info("Telegram connected")
        else:
            logger.error("Telegram connection failed - continuing WITHOUT alerts")
            await self._safe_close(self.telegram)
            self.telegram = None

    async def _init_tx_monitor(self, currencies: List[str]) -> None:
        enable_tx = os.getenv("MM_ALERT_ENABLE_TX_MONITOR", "0").strip().lower()
        if enable_tx not in _TX_MONITOR_TRUTHY:
            self.tx_monitor = None
            logger.info("Transaction Monitor disabled")
            return

        from mm_alert_bot.core.transaction_monitor import TransactionMonitor

        self.tx_monitor = TransactionMonitor(
            deribit_client=self.deribit,
            currencies=currencies,
            on_event=self._on_transaction_event,
            mm_status_provider=lambda cur: (
                self.monitor.get_current_status(cur) if self.monitor else None
            ),
            liquidation_cooldown_seconds=60,
            trade_poll_seconds=10,
            position_poll_seconds=15,
            ledger_poll_seconds=30,
        )
        logger.info("Transaction Monitor ready (trade + position + ledger polling)")

    # ------------------------------------------------------------------
    # Start / Stop
    # ------------------------------------------------------------------
    async def start(self) -> None:
        if not self.monitor:
            raise RuntimeError("Service not initialized - call initialize() first")
        if self._running:
            logger.warning("Service already running")
            return

        self._running = True

        await self._send_startup_notification()

        await self.monitor.start_monitoring()
        logger.info("Margin Monitor started")

        if self.tx_monitor:
            try:
                await self.tx_monitor.start()
                logger.info("Transaction Monitor started (trades + positions + ledger)")
            except Exception as e:
                logger.warning(
                    "TransactionMonitor failed to start; MM alerts still running: %s",
                    e, exc_info=True,
                )
                self.tx_monitor = None

        if self.cmd_handler:
            try:
                await self.cmd_handler.start()
                logger.info("Command handler started (listening for commands)")
            except Exception as e:
                logger.warning("Command handler failed to start: %s", e, exc_info=True)
                self.cmd_handler = None

        logger.info("MM Alert Service running (REST-only)")

    async def stop(self) -> None:
        self._running = False

        await self._safe_stop(self.cmd_handler)
        await self._safe_stop(self.tx_monitor)

        if self.telegram:
            try:
                await self._send_shutdown_notification()
            except Exception as e:
                logger.warning("Shutdown notification failed: %s", e, exc_info=True)

        await self._safe_stop(self.monitor, attr="stop_monitoring")
        await self._safe_close(self.telegram)
        await self._safe_close(self.deribit)

        logger.info("MM Alert Service stopped")

    # ------------------------------------------------------------------
    # Startup / Shutdown notifications
    # ------------------------------------------------------------------
    async def _send_startup_notification(self) -> None:
        if not self.telegram:
            return
        try:
            db = self._db_cfg_cache
            currencies = db.get("currencies", ["BTC"])
            warning = db.get("warning_threshold", 80)
            critical = db.get("critical_threshold", 95)
            warning_cd = db.get("warning_cooldown_minutes", 5)
            critical_cd = db.get("critical_cooldown_minutes", 1)
            interval = db.get("check_interval_seconds", 30)

            tx_status = "🟢 Active" if self.tx_monitor else "🔴 Disabled"

            message = (
                f"━━━━━━━━━━━━━━\n"
                f"<b>🟢 BOT ONLINE</b>\n"
                f"━━━━━━━━━━━━━━\n\n"
                f"┌─────────────────\n"
                f"│ Status: Active\n"
                f"│ Watch: <code>{', '.join(currencies)}</code>\n"
                f"│ Recipients: <code>{len(self._alert_chat_ids)}</code>\n"
                f"│\n"
                f"│ <b>Monitors</b>\n"
                f"│ Margin: 🟢\n"
                f"│ Trades: {tx_status}\n"
                f"│ Liquid: {tx_status}\n"
                f"│ Positn: {tx_status}\n"
                f"│ Ledger: {tx_status}\n"
                f"│ <i>(deposit/withdraw/fee/\n"
                f"│  funding/settlement)</i>\n"
                f"│\n"
                f"│ <b>Thresholds</b>\n"
                f"│ 🟡 ≥<code>{warning}%</code> cd <code>{warning_cd}m</code>\n"
                f"│ 🔴 ≥<code>{critical}%</code> cd <code>{critical_cd}m</code>\n"
                f"│\n"
                f"│ <b>Poll (s)</b>\n"
                f"│ Mgn:<code>{interval}</code> Trd:<code>10</code>"
                f" Pos:<code>15</code> Lgr:<code>30</code>\n"
                f"└─────────────────\n\n"
                f"<i>Monitoring all account activity.</i>"
            )
            await self._send_message_to_all(message)
        except Exception as e:
            logger.warning("Startup notification failed: %s", e, exc_info=True)

    async def _send_shutdown_notification(self) -> None:
        if not self.telegram:
            return
        ts = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
        message = (
            f"━━━━━━━━━━━━━━\n"
            f"<b>🔴 MM ALERT BOT OFFLINE</b>\n"
            f"━━━━━━━━━━━━━━\n\n"
            f"┌─────────────────\n"
            f"│ Status:  Stopped\n"
            f"│ Time:    <code>{ts}</code>\n"
            f"└─────────────────\n\n"
            f"<i>⚠️ All monitoring paused: margin, trades, "
            f"positions, liquidations, ledger.</i>"
        )
        await self._send_message_to_all(message)

    # ------------------------------------------------------------------
    # Alert callbacks
    # ------------------------------------------------------------------
    async def _on_alert(self, status: MarginStatus, account_data: Dict[str, Any]) -> None:
        if not self.telegram or not self.deribit:
            return

        is_cross = self.monitor and getattr(self.monitor, "cross_portfolio_mode", False)
        if is_cross and str(status.currency).upper() != "PORTFOLIO":
            return

        btc_price = await self._fetch_btc_price_str()
        portfolio_equity_usd = await self._fetch_portfolio_equity_str()
        usdt_equity = await self._fetch_currency_equity_str("USDT")
        usdc_equity = await self._fetch_currency_equity_str("USDC")
        aum_usd, aum_pct = await self._fetch_aum()

        msg = _fmt_margin_alert(
            status,
            btc_price,
            portfolio_equity_usd,
            usdt_equity,
            usdc_equity,
            aum_usd,
            aum_pct,
        )
        logger.info("Sending margin alert to %d recipient(s)", len(self._alert_chat_ids))
        await self._send_message_to_all(msg)

    async def _fetch_portfolio_equity_str(self) -> str:
        try:
            equity = await self.deribit.get_portfolio_equity_usd()
            return f"{equity:,.2f}"
        except Exception as e:
            logger.warning("Failed to fetch portfolio equity: %s", e, exc_info=True)
            return "N/A"

    async def _fetch_currency_equity_str(self, currency: str) -> str:
        try:
            summary = await self.deribit.get_account_summary(currency, extended=True)
            equity = float(summary.get("equity", 0) or 0)
            return f"{equity:,.2f}"
        except Exception as e:
            logger.warning("Failed to fetch %s equity: %s", currency, e, exc_info=True)
            return "N/A"
    

    # ------------------------------------------------------------------
    # AUM change (reads from account_snapshots, updated by worker every 30s)
    # ------------------------------------------------------------------
    async def _fetch_aum(self):
        """
        AUM change over 1d / 3d / 1w.

        Current value:  live from Deribit (get_portfolio_equity_usd)
        Past values:    from account_snapshots table (updated by worker every 30s)
                        Each row = 1 day, payload_json contains total_equity_usd
        """
        import json as _json

        na = {"1d": "N/A", "3d": "N/A", "1w": "N/A"}

        # ---- current AUM: live from Deribit ----
        try:
            current_usd = await self.deribit.get_portfolio_equity_usd()
        except Exception as e:
            logger.warning("_fetch_aum: live equity fetch failed: %s", e)
            return dict(na), dict(na)

        if not current_usd or current_usd <= 0:
            return dict(na), dict(na)

        # ---- past AUM: from account_snapshots (worker writes here every 30s) ----
        try:
            db_path = str(DB_PATH)
            with sqlite3.connect(db_path) as conn:
                rows = conn.execute(
                    "SELECT date, payload_json FROM account_snapshots ORDER BY date DESC LIMIT 10"
                ).fetchall()
        except Exception as e:
            logger.warning("_fetch_aum: DB read failed: %s", e)
            return dict(na), dict(na)

        if not rows:
            return dict(na), dict(na)

        # Parse snapshots: [{date: "2026-03-22", equity_usd: 95621.53}, ...]
        snapshots = []
        for date_str, payload_str in rows:
            try:
                payload = _json.loads(payload_str) if isinstance(payload_str, str) else {}
                equity = float(
                    payload.get("total_equity_usd")
                    or payload.get("equity_usd")
                    or payload.get("capital_usd")
                    or 0
                )
                if equity > 0:
                    snapshots.append({"date": date_str, "equity_usd": equity})
            except Exception:
                continue

        if not snapshots:
            return dict(na), dict(na)

        today = datetime.now(timezone.utc).strftime("%Y-%m-%d")

        def _get(days):
            """Find snapshot from ~N days ago."""
            target = (datetime.now(timezone.utc) - timedelta(days=days)).strftime("%Y-%m-%d")

            # Find closest snapshot on or before target date
            best = None
            for snap in snapshots:
                if snap["date"] <= target:
                    if best is None or snap["date"] > best["date"]:
                        best = snap

            if best is None:
                return "N/A", "N/A"

            # Tolerance: accept if within days + max(days*0.5, 2)
            try:
                snap_date = datetime.strptime(best["date"], "%Y-%m-%d")
                target_date = datetime.strptime(target, "%Y-%m-%d")
                actual_days = (target_date - snap_date).days
                tolerance = max(int(days * 0.5), 2)
                if actual_days > tolerance:
                    return "N/A", "N/A"
            except Exception:
                pass

            past_val = best["equity_usd"]
            diff = current_usd - past_val
            pct = (diff / past_val) * 100

            return f"{diff:,.2f}", f"{pct:+.2f}%"

        aum_usd = {}
        aum_pct = {}

        for label, days in {
            "1d": 1,
            "3d": 3,
            "1w": 7,
        }.items():
            usd, pct = _get(days)
            aum_usd[label] = usd
            aum_pct[label] = pct

        return aum_usd, aum_pct

    async def _on_transaction_event(self, ev: "TxEvent") -> None:
        if not self.telegram:
            return
        try:
            msg = self._format_tx_event(ev)
            if msg:
                await self._send_message_to_all(msg)
        except Exception as e:
            logger.error("Transaction alert failed: %s", e, exc_info=True)

    # ------------------------------------------------------------------
    # TX event formatting router
    # ------------------------------------------------------------------
    def _format_tx_event(self, ev: "TxEvent") -> Optional[str]:
        etype = ev.event_type

        if etype == "liquidation":
            mm_line = ""
            try:
                st = self.monitor.get_current_status(ev.currency) if self.monitor else None
                if st:
                    mm_line = f"│ MM:   <code>{st.mm_percentage:.2f}%</code>\n"
            except Exception:
                pass
            return _fmt_liquidation(ev, mm_line)

        if etype == "trade_open":
            return _fmt_trade_open(ev)

        if etype in ("trade_close", "trade_partial_close"):
            return _fmt_trade_close(ev)

        if etype == "position_opened":
            return _fmt_position_opened(ev)

        if etype == "position_closed":
            return _fmt_position_closed(ev)

        if etype == "position_changed":
            return _fmt_position_changed(ev)

        if etype == "deposit":
            return _fmt_deposit(ev)

        if etype == "withdrawal":
            return _fmt_withdrawal(ev)

        if etype == "settlement":
            return _fmt_settlement(ev)

        if etype in ("ledger", "funding", "transfer", "delivery"):
            return _fmt_ledger(ev)

        return _fmt_ledger(ev)
    
    # ------------------------------------------------------------------
    # Command Handler
    # ------------------------------------------------------------------
    async def _init_command_handler(self) -> None:
        bot_token = os.getenv("TELEGRAM_BOT_TOKEN", "")
        if not bot_token or not self._alert_chat_ids:
            logger.info("Command handler disabled (no token or no chat IDs)")
            return

        self.cmd_handler = TelegramCommandHandler(
            bot_token=bot_token,
            allowed_chat_ids=self._alert_chat_ids,
        )
        self.cmd_handler.set_send_callback(self._cmd_send)

        self.cmd_handler.register("info", self._cmd_info)
        self.cmd_handler.register("equity", self._cmd_equity)
        self.cmd_handler.register("greeks", self._cmd_greeks)
        self.cmd_handler.register("pnl", self._cmd_pnl)
        self.cmd_handler.register("iv", self._cmd_iv)
        self.cmd_handler.register("hv", self._cmd_hv)
        self.cmd_handler.register("roc", self._cmd_roc)
        self.cmd_handler.register("positions", self._cmd_positions)
        self.cmd_handler.register("margins", self._cmd_margins)
        self.cmd_handler.register("risk", self._cmd_risk)
        self.cmd_handler.register("orders", self._cmd_orders)
        self.cmd_handler.register("help", self._cmd_help)

        logger.info("Command handler initialized with %d commands", 12)

    async def _cmd_send(self, text: str, chat_id: str) -> None:
        if not self.telegram or not text:
            return
        for chunk in _split_message(text):
            if chunk.strip():
                await self.telegram.send_message(chunk, chat_id=chat_id)

    # ------------------------------------------------------------------
    # /help
    # ------------------------------------------------------------------
    async def _cmd_help(self, args: str, chat_id: str) -> str:
        return (
            "━━━━━━━━━━━━━━\n"
            "<b>📖 AVAILABLE COMMANDS</b>\n"
            "━━━━━━━━━━━━━━\n\n"
            "┌─────────────────\n"
            "│ /info       Full account overview\n"
            "│ /equity     Portfolio equity\n"
            "│ /greeks     Account greeks\n"
            "│ /pnl        Profit &amp; loss\n"
            "│ /iv         Implied volatility (30d)\n"
            "│ /hv         Historical volatility (30d)\n"
            "│ /roc        Rate of change\n"
            "│ /positions  Open positions\n"
            "│ /margins    Margin status\n"
            "│ /risk       Risk summary\n"
            "│ /orders     Open orders\n"
            "│ /help       This message\n"
            "└─────────────────"
        )

    # ------------------------------------------------------------------
    # /equity
    # ------------------------------------------------------------------
    async def _cmd_equity(self, args: str, chat_id: str) -> str:
        portfolio_usd = await self._fetch_portfolio_equity_str()
        btc_price = await self._fetch_btc_price_str()

        btc_summary = await self.deribit.get_account_summary("BTC", extended=True)
        btc_equity = float(btc_summary.get("equity", 0) or 0)

        usdt_equity = await self._fetch_currency_equity_str("USDT")
        usdc_equity = await self._fetch_currency_equity_str("USDC")

        eth_equity = "N/A"
        try:
            eth_summary = await self.deribit.get_account_summary("ETH", extended=True)
            eth_eq = float(eth_summary.get("equity", 0) or 0)
            eth_equity = f"{eth_eq:,.4f}"
        except Exception:
            pass

        sol_equity = "N/A"
        try:
            sol_summary = await self.deribit.get_account_summary("SOL", extended=True)
            sol_eq = float(sol_summary.get("equity", 0) or 0)
            sol_equity = f"{sol_eq:,.4f}"
        except Exception:
            pass

        return (
            "━━━━━━━━━━━━━━\n"
            "<b>💰 EQUITY</b>\n"
            "━━━━━━━━━━━━━━\n\n"
            "┌─────────────────\n"
            f"│ <b>USD</b>  <code>${portfolio_usd}</code>\n"
            "│\n"
            f"│ BTC:  <code>{btc_equity:.6f}</code>\n"
            f"│ USDT: <code>{usdt_equity}</code>\n"
            f"│ USDC: <code>{usdc_equity}</code>\n"
            f"│ ETH:  <code>{eth_equity}</code>\n"
            f"│ SOL:  <code>{sol_equity}</code>\n"
            "│\n"
            f"│ Px:   <code>${btc_price}</code>\n"
            "└─────────────────"
        )

    # ------------------------------------------------------------------
    # /greeks
    # ------------------------------------------------------------------
    async def _cmd_greeks(self, args: str, chat_id: str) -> str:
        greeks = await self.deribit.get_account_greeks("BTC")

        def _g(val: float) -> str:
            prefix = "+" if val > 0 else ""
            return f"{prefix}{val:.6f}"

        return (
            "━━━━━━━━━━━━━━\n"
            "<b>📐 GREEKS (BTC)</b>\n"
            "━━━━━━━━━━━━━━\n\n"
            "┌─────────────────\n"
            f"│ Δ <code>{_g(greeks['delta'])}</code>\n"
            f"│ Γ <code>{_g(greeks['gamma'])}</code>\n"
            f"│ ν <code>{_g(greeks['vega'])}</code>\n"
            f"│ Θ <code>{_g(greeks['theta'])}</code>\n"
            f"│ ρ <code>{_g(greeks['rho'])}</code>\n"
            "└─────────────────"
        )

    # ------------------------------------------------------------------
    # /pnl
    # ------------------------------------------------------------------
    async def _cmd_pnl(self, args: str, chat_id: str) -> str:
        pnl = await self.deribit.get_portfolio_pnl("BTC")

        def _n(val: float) -> str:
            sign = "+" if val > 0 else ("" if val == 0 else "")
            return f"{sign}{val:.8f}"

        total = pnl["total_pnl"]
        total_emoji = "🟢" if total > 0 else ("🔴" if total < 0 else "⚪")

        return (
            "━━━━━━━━━━━━━━\n"
            "<b>📊 PNL (BTC)</b>\n"
            "━━━━━━━━━━━━━━\n\n"
            "┌─────────────────\n"
            f"│ {total_emoji} <b>Tot</b> <code>{_n(total)}</code>\n"
            f"│ RPL <code>{_n(pnl['session_rpl'])}</code>\n"
            f"│ UPL <code>{_n(pnl['session_upl'])}</code>\n"
            "│\n"
            "│ <b>Futures</b>\n"
            f"│ RPL <code>{_n(pnl['futures_session_rpl'])}</code>\n"
            f"│ UPL <code>{_n(pnl['futures_session_upl'])}</code>\n"
            "│ <b>Options</b>\n"
            f"│ RPL <code>{_n(pnl['options_session_rpl'])}</code>\n"
            f"│ UPL <code>{_n(pnl['options_session_upl'])}</code>\n"
            "└─────────────────"
        )

    # ------------------------------------------------------------------
    # /iv
    # ------------------------------------------------------------------
    async def _cmd_iv(self, args: str, chat_id: str) -> str:
        try:
            vol_data = await self.deribit.get_volatility_index("BTC")
            data_points = vol_data.get("data") or []

            if not data_points:
                return "No IV data available."

            recent = data_points[-1]
            current_iv = float(recent[1]) if isinstance(recent, list) else float(recent.get("close", 0))

            ivs = [
                float(p[1]) if isinstance(p, list) else float(p.get("close", 0))
                for p in data_points[-720:]
            ]

            avg_30d = sum(ivs) / len(ivs) if ivs else 0
            max_30d = max(ivs) if ivs else 0
            min_30d = min(ivs) if ivs else 0

            return (
                "━━━━━━━━━━━━━━\n"
                "<b>📈 IV (DVOL)</b>\n"
                "━━━━━━━━━━━━━━\n\n"
                "┌─────────────────\n"
                f"│ Now: <code>{current_iv:.2f}%</code>\n"
                f"│ Avg: <code>{avg_30d:.2f}%</code>\n"
                f"│ Hi:  <code>{max_30d:.2f}%</code>\n"
                f"│ Lo:  <code>{min_30d:.2f}%</code>\n"
                "└─────────────────"
            )
        except Exception as e:
            logger.error("IV command failed: %s", e, exc_info=True)
            return f"Failed to fetch IV data: {str(e)[:200]}"

    # ------------------------------------------------------------------
    # /hv
    # ------------------------------------------------------------------
    async def _cmd_hv(self, args: str, chat_id: str) -> str:
        try:
            hv_data = await self.deribit.get_historical_volatility("BTC")

            if not hv_data or not isinstance(hv_data, list):
                return "No HV data available."

            recent = hv_data[-1] if hv_data else None
            if recent is None:
                return "No HV data available."

            current_hv = float(recent[1]) if isinstance(recent, list) else float(recent)

            hvs = [
                float(p[1]) if isinstance(p, list) else float(p)
                for p in hv_data[-30:]
            ]

            avg_30d = sum(hvs) / len(hvs) if hvs else 0
            max_30d = max(hvs) if hvs else 0
            min_30d = min(hvs) if hvs else 0

            iv_vs_hv = ""
            try:
                vol_data = await self.deribit.get_volatility_index("BTC")
                data_points = vol_data.get("data") or []
                if data_points:
                    last_iv = data_points[-1]
                    iv_val = float(last_iv[1]) if isinstance(last_iv, list) else float(last_iv.get("close", 0))
                    spread = iv_val - current_hv
                    spread_emoji = "🟢" if spread > 0 else "🔴"
                    iv_vs_hv = (
                        f"\n\n<b>IV vs HV</b>\n"
                        f"┌─────────────────\n"
                        f"│ IV:  <code>{iv_val:.2f}%</code>\n"
                        f"│ HV:  <code>{current_hv:.2f}%</code>\n"
                        f"│ Spr: {spread_emoji} <code>{spread:+.2f}%</code>\n"
                        f"└─────────────────"
                    )
            except Exception:
                pass

            return (
                "━━━━━━━━━━━━━━\n"
                "<b>📉 HV (BTC)</b>\n"
                "━━━━━━━━━━━━━━\n\n"
                "┌─────────────────\n"
                f"│ Now: <code>{current_hv:.2f}%</code>\n"
                f"│ Avg: <code>{avg_30d:.2f}%</code>\n"
                f"│ Hi:  <code>{max_30d:.2f}%</code>\n"
                f"│ Lo:  <code>{min_30d:.2f}%</code>\n"
                f"└─────────────────"
                f"{iv_vs_hv}"
            )
        except Exception as e:
            logger.error("HV command failed: %s", e, exc_info=True)
            return f"Failed to fetch HV data: {str(e)[:200]}"

    # ------------------------------------------------------------------
    # /roc
    # ------------------------------------------------------------------
    async def _cmd_roc(self, args: str, chat_id: str) -> str:
        try:
            chart = await self.deribit.get_index_price_history(
                "BTC", resolution=1, count=1440,
            )

            closes = chart.get("close") or []

            if not closes or len(closes) < 2:
                return "Not enough price data for ROC calculation."

            try:
                spot_price = await self.deribit.get_index_price("BTC")
            except Exception:
                spot_price = closes[-1]

            current = spot_price

            def _roc(minutes: int) -> str:
                if len(closes) < minutes + 1:
                    return "N/A"
                past = closes[-(minutes + 1)]
                if past == 0:
                    return "N/A"
                change = ((current - past) / past) * 100
                emoji = "🟢" if change >= 0 else "🔴"
                return f"{emoji} {change:+.4f}%"

            # ✅ 24h Change = أول candle في الـ 1440 (قبل 24 ساعة بالظبط)
            if len(closes) >= 1440:
                price_24h_ago = closes[0]
            elif len(closes) > 0:
                price_24h_ago = closes[0]
            else:
                price_24h_ago = 0

            if price_24h_ago > 0:
                daily_roc = ((current - price_24h_ago) / price_24h_ago) * 100
                daily_emoji = "🟢" if daily_roc >= 0 else "🔴"
                daily_str = f"{daily_emoji} {daily_roc:+.4f}%"
            else:
                daily_str = "N/A"

            return (
                "━━━━━━━━━━━━━━\n"
                "<b>📊 ROC (BTC)</b>\n"
                "━━━━━━━━━━━━━━\n\n"
                "┌─────────────────\n"
                f"│ Spot: <code>${current:,.2f}</code>\n"
                "│\n"
                f"│ <b>Intraday</b>\n"
                f"│ 5m:   {_roc(5)}\n"
                f"│ 15m:  {_roc(15)}\n"
                f"│ 30m:  {_roc(30)}\n"
                f"│ 60m:  {_roc(60)}\n"
                f"│ 120m: {_roc(120)}\n"
                "│\n"
                f"│ <b>24h</b>\n"
                f"│ Δ:   {daily_str}\n"
                f"│ Ref: <code>${price_24h_ago:,.2f}</code>\n"
                "└─────────────────"
            )
        except Exception as e:
            logger.error("ROC command failed: %s", e, exc_info=True)
            return f"Failed to calculate ROC: {str(e)[:200]}"

    # ------------------------------------------------------------------
    # /positions
    # ------------------------------------------------------------------
    async def _cmd_positions(self, args: str, chat_id: str) -> str:
        try:
            positions = await self.deribit.get_positions("BTC")
            active = [p for p in positions if float(p.get("size", 0) or 0) != 0]

            if not active:
                return "No open positions."

            # --- Separate options vs non-options ---
            options = []
            non_options = []
            for p in active:
                inst = str(p.get("instrument_name", "")).upper()
                kind = str(p.get("kind", "")).lower()

                if kind == "option":
                    options.append(p)
                elif kind in ("future", "future_combo"):
                    non_options.append(p)
                elif "PERPETUAL" in inst:
                    non_options.append(p)
                elif inst.endswith("-C") or inst.endswith("-P"):
                    options.append(p)
                else:
                    non_options.append(p)

            # --- Parse expiry ---
            def _parse_expiry(name: str) -> datetime:
                parts = name.upper().split("-")
                if len(parts) >= 2:
                    try:
                        return datetime.strptime(parts[1], "%d%b%y")
                    except ValueError:
                        pass
                return datetime(2099, 12, 31)

            def _expiry_label(name: str) -> str:
                parts = name.upper().split("-")
                if len(parts) >= 2:
                    try:
                        dt = datetime.strptime(parts[1], "%d%b%y")
                        return dt.strftime("%d %b %Y").upper()
                    except ValueError:
                        pass
                return "OTHER"

            # --- Sort options by expiry ---
            options.sort(key=lambda p: (
                _parse_expiry(str(p.get("instrument_name", ""))),
                str(p.get("instrument_name", "")),
            ))

            # --- Net contracts per expiry ---
            from collections import OrderedDict
            expiry_stats: Dict[str, Dict[str, float]] = OrderedDict()
            total_long = 0.0
            total_short = 0.0

            for p in options:
                inst = str(p.get("instrument_name", ""))
                label = _expiry_label(inst)
                size = float(p.get("size", 0) or 0)
                if label not in expiry_stats:
                    expiry_stats[label] = {"long": 0.0, "short": 0.0}
                if size > 0:
                    expiry_stats[label]["long"] += size
                    total_long += size
                else:
                    expiry_stats[label]["short"] += size
                    total_short += size

            total_net = total_long + total_short
            net_emoji = "🟢" if total_net > 0 else ("🔴" if total_net < 0 else "⚪")

            # === MESSAGE 1: Net Summary ===
            net_lines = [
                "━━━━━━━━━━━━━━",
                "<b>📊 NET OPTION CONTRACTS (BTC)</b>",
                "━━━━━━━━━━━━━━",
                "",
                "┌─────────────────",
                f"│ Positions: <code>{len(active)}</code> "
                f"(<code>{len(options)}</code> opt, "
                f"<code>{len(non_options)}</code> other)",
                "│",
                "│ <b>By Expiry</b>",
            ]

            for label, s in expiry_stats.items():
                net = s["long"] + s["short"]
                e = "🟢" if net > 0 else ("🔴" if net < 0 else "⚪")
                net_lines.append(
                    f"│   {label}:  L<code>{s['long']:+.1f}</code> "
                    f"S<code>{s['short']:+.1f}</code> "
                    f"{e}<code>{net:+.1f}</code>"
                )

            net_lines.append(
                f"│   <b>Total</b>: L<code>{total_long:+.1f}</code> "
                f"S<code>{total_short:+.1f}</code> "
                f"{net_emoji}<code>{total_net:+.1f}</code>"
            )

            if non_options:
                net_lines.append("│")
                net_lines.append("│ <b>Futures / Perps</b>")
                for p in non_options:
                    inst = p.get("instrument_name", "N/A")
                    size = float(p.get("size", 0) or 0)
                    pnl = float(p.get("floating_profit_loss", 0) or 0)
                    pe = "🟢" if pnl >= 0 else "🔴"
                    d = "LONG" if size > 0 else "SHORT"
                    net_lines.append(
                        f"│   {inst}: <code>{d} {abs(size):.0f}</code> "
                        f"{pe}<code>{pnl:+.6f}</code>"
                    )

            net_lines.append("└─────────────────")

            await self._cmd_send("\n".join(net_lines), chat_id)

            # === MESSAGE 2+: Positions detail ===
            pos_lines = [
                "━━━━━━━━━━━━━━",
                "<b>📋 OPEN POSITIONS (BTC)</b>",
                "━━━━━━━━━━━━━━",
            ]

            current_expiry = None
            for p in options:
                instrument = str(p.get("instrument_name", "N/A"))
                expiry = _expiry_label(instrument)
                size = float(p.get("size", 0) or 0)
                direction = str(p.get("direction", "")).upper()
                mark = p.get("mark_price", "N/A")
                pnl = float(p.get("floating_profit_loss", 0) or 0)
                pnl_emoji = "🟢" if pnl >= 0 else "🔴"

                if expiry != current_expiry:
                    current_expiry = expiry
                    pos_lines.append(f"\n<b>📅 {expiry}</b>")

                pos_lines.append(
                    f"\n<b>{instrument}</b>\n"
                    f"┌─────────────────\n"
                    f"│ <code>{direction}</code> · <code>{size}</code>\n"
                    f"│ Mk:  <code>{mark}</code>\n"
                    f"│ PnL: {pnl_emoji} <code>{pnl:+.8f}</code>\n"
                    f"└─────────────────"
                )

            if non_options:
                pos_lines.append("\n<b>📈 FUTURES / PERPETUALS</b>")
                for p in non_options:
                    instrument = p.get("instrument_name", "N/A")
                    size = float(p.get("size", 0) or 0)
                    direction = str(p.get("direction", "")).upper()
                    mark = p.get("mark_price", "N/A")
                    pnl = float(p.get("floating_profit_loss", 0) or 0)
                    pnl_emoji = "🟢" if pnl >= 0 else "🔴"
                    kind = str(p.get("kind", "")).upper()

                    pos_lines.append(
                        f"\n<b>{instrument}</b> <i>[{kind}]</i>\n"
                        f"┌─────────────────\n"
                        f"│ <code>{direction}</code> · <code>{size}</code>\n"
                        f"│ Mk:  <code>{mark}</code>\n"
                        f"│ PnL: {pnl_emoji} <code>{pnl:+.8f}</code>\n"
                        f"└─────────────────"
                    )

            await self._cmd_send("\n".join(pos_lines), chat_id)
            return ""

        except Exception as e:
            logger.error("Positions command failed: %s", e, exc_info=True)
            return f"Failed to fetch positions: {str(e)[:200]}"

    # ------------------------------------------------------------------
    # /margins
    # ------------------------------------------------------------------
    async def _cmd_margins(self, args: str, chat_id: str) -> str:
        try:
            summary = await self.deribit.get_account_summary("BTC", extended=True)
            equity = float(summary.get("equity", 0) or 0)
            maint = float(summary.get("maintenance_margin", 0) or 0)
            initial = float(summary.get("initial_margin", 0) or 0)
            avail = float(summary.get("available_funds", 0) or 0)
            margin_balance = float(summary.get("margin_balance", 0) or 0)

            denom = margin_balance if margin_balance > 0 else equity
            mm_pct = (maint / denom) * 100.0 if denom > 0 and maint > 0 else 0.0
            im_pct = (initial / denom) * 100.0 if denom > 0 and initial > 0 else 0.0

            if mm_pct >= 100:
                level = "💀 LIQUIDATION"
            elif mm_pct >= 95:
                level = "🔴 CRITICAL"
            elif mm_pct >= 80:
                level = "🟡 WARNING"
            else:
                level = "🟢 NORMAL"

            portfolio_usd = await self._fetch_portfolio_equity_str()

            return (
                "━━━━━━━━━━━━━━\n"
                "<b>📊 MARGIN</b>\n"
                "━━━━━━━━━━━━━━\n\n"
                "┌─────────────────\n"
                f"│ {level}\n"
                "│\n"
                f"│ MM: <code>{mm_pct:.2f}%</code>\n"
                f"│ IM: <code>{im_pct:.2f}%</code>\n"
                "│\n"
                f"│ USD: <code>${portfolio_usd}</code>\n"
                f"│ BTC: <code>{equity:.6f}</code>\n"
                "│\n"
                f"│ Mnt: <code>{maint:.6f}</code>\n"
                f"│ Ini: <code>{initial:.6f}</code>\n"
                f"│ Avl: <code>{avail:.6f}</code>\n"
                f"│ Bal: <code>{margin_balance:.6f}</code>\n"
                "└─────────────────"
            )
        except Exception as e:
            logger.error("Margins command failed: %s", e, exc_info=True)
            return f"Failed to fetch margin data: {str(e)[:200]}"

    # ------------------------------------------------------------------
    # /orders
    # ------------------------------------------------------------------
    async def _cmd_orders(self, args: str, chat_id: str) -> str:
        try:
            orders = await self.deribit.get_open_orders_by_currency("BTC")

            if not orders:
                return "No open orders."

            lines = [
                "━━━━━━━━━━━━━━\n"
                "<b>📋 OPEN ORDERS (BTC)</b>\n"
                "━━━━━━━━━━━━━━\n"
                f"\nTotal: <code>{len(orders)}</code> orders"
            ]

            for o in orders[:15]:
                instrument = o.get("instrument_name", "N/A")
                direction = str(o.get("direction", "")).upper()
                amount = o.get("amount", "N/A")
                price = o.get("price", "N/A")
                order_type = str(o.get("order_type", "")).upper()
                state = str(o.get("order_state", "")).upper()

                lines.append(
                    f"\n<b>{instrument}</b>\n"
                    f"┌─────────────────\n"
                    f"│ {_direction_emoji(direction)} · <code>{order_type}</code>\n"
                    f"│ Amt: <code>{amount}</code>\n"
                    f"│ Px:  <code>{price}</code>\n"
                    f"│ St:  <code>{state}</code>\n"
                    f"└─────────────────"
                )

            if len(orders) > 15:
                lines.append(f"\n<i>... and {len(orders) - 15} more</i>")

            return "\n".join(lines)
        except Exception as e:
            logger.error("Orders command failed: %s", e, exc_info=True)
            return f"Failed to fetch orders: {str(e)[:200]}"

    # ------------------------------------------------------------------
    # /risk
    # ------------------------------------------------------------------
    async def _cmd_risk(self, args: str, chat_id: str) -> str:
        try:
            margin_msg = await self._cmd_margins("", chat_id)
            greeks_msg = await self._cmd_greeks("", chat_id)

            positions = await self.deribit.get_positions("BTC")
            active = [p for p in positions if float(p.get("size", 0) or 0) != 0]

            sorted_by_pnl = sorted(
                active,
                key=lambda p: abs(float(p.get("floating_profit_loss", 0) or 0)),
                reverse=True,
            )[:5]

            top_lines = []
            for p in sorted_by_pnl:
                pnl = float(p.get("floating_profit_loss", 0) or 0)
                emoji = "🟢" if pnl >= 0 else "🔴"
                top_lines.append(
                    f"│ {emoji} {p.get('instrument_name', 'N/A')}  "
                    f"<code>{pnl:+.8f}</code>"
                )

            top_section = (
                "\n\n━━━━━━━━━━━━━━\n"
                "<b>🏆 TOP 5 POSITIONS BY |PnL|</b>\n"
                "━━━━━━━━━━━━━━\n\n"
                "┌─────────────────\n"
                + "\n".join(top_lines) +
                "\n└─────────────────"
            ) if top_lines else ""

            return f"{margin_msg}\n\n{greeks_msg}{top_section}"
        except Exception as e:
            logger.error("Risk command failed: %s", e, exc_info=True)
            return f"Failed to generate risk summary: {str(e)[:200]}"

    # ------------------------------------------------------------------
    # /info (full overview)
    # ------------------------------------------------------------------
    async def _cmd_info(self, args: str, chat_id: str) -> str:
        try:
            equity_msg = await self._cmd_equity("", chat_id)
            greeks_msg = await self._cmd_greeks("", chat_id)
            pnl_msg = await self._cmd_pnl("", chat_id)

            iv_short = ""
            try:
                vol_data = await self.deribit.get_volatility_index("BTC")
                data_points = vol_data.get("data") or []
                if data_points:
                    last = data_points[-1]
                    iv = float(last[1]) if isinstance(last, list) else float(last.get("close", 0))
                    iv_short = f"│ IV:  <code>{iv:.2f}%</code>\n"
            except Exception:
                pass

            hv_short = ""
            try:
                hv_data = await self.deribit.get_historical_volatility("BTC")
                if hv_data:
                    last = hv_data[-1]
                    hv = float(last[1]) if isinstance(last, list) else float(last)
                    hv_short = f"│ HV:  <code>{hv:.2f}%</code>\n"
            except Exception:
                pass

            roc_short = ""
            try:
                chart = await self.deribit.get_index_price_history(
                    "BTC", resolution=1, count=130,
                )
                closes = chart.get("close") or []
                if len(closes) > 60:
                    current = closes[-1]
                    p60 = closes[-61]
                    if p60 != 0:
                        roc60 = ((current - p60) / p60) * 100
                        emoji = "🟢" if roc60 >= 0 else "🔴"
                        roc_short = f"│ ROC: {emoji} <code>{roc60:+.4f}%</code>\n"
            except Exception:
                pass

            vol_section = ""
            if iv_short or hv_short or roc_short:
                vol_section = (
                    "\n\n━━━━━━━━━━━━━━\n"
                    "<b>📊 VOL &amp; ROC</b>\n"
                    "━━━━━━━━━━━━━━\n\n"
                    "┌─────────────────\n"
                    f"{iv_short}{hv_short}{roc_short}"
                    "└─────────────────"
                )

            margin_str = ""
            try:
                summary = await self.deribit.get_account_summary("BTC", extended=True)
                equity = float(summary.get("equity", 0) or 0)
                maint = float(summary.get("maintenance_margin", 0) or 0)
                initm = float(summary.get("initial_margin", 0) or 0)
                mb = float(summary.get("margin_balance", 0) or 0)
                denom = mb if mb > 0 else equity
                mm_pct = (maint / denom) * 100 if denom > 0 and maint > 0 else 0
                im_pct = (initm / denom) * 100 if denom > 0 and initm > 0 else 0
                margin_str = (
                    "\n\n━━━━━━━━━━━━━━\n"
                    "<b>📊 MARGIN</b>\n"
                    "━━━━━━━━━━━━━━\n\n"
                    "┌─────────────────\n"
                    f"│ MM: <code>{mm_pct:.2f}%</code>\n"
                    f"│ IM: <code>{im_pct:.2f}%</code>\n"
                    "└─────────────────"
                )
            except Exception:
                pass

            return f"{equity_msg}\n\n{greeks_msg}\n\n{pnl_msg}{vol_section}{margin_str}"
        except Exception as e:
            logger.error("Info command failed: %s", e, exc_info=True)
            return f"Failed to generate account info: {str(e)[:200]}"

    # ------------------------------------------------------------------
    # Safe cleanup helpers
    # ------------------------------------------------------------------
    @staticmethod
    async def _safe_close(obj: Any) -> None:
        if obj is None:
            return
        try:
            await obj.close()
        except Exception:
            pass

    @staticmethod
    async def _safe_stop(obj: Any, attr: str = "stop") -> None:
        if obj is None:
            return
        try:
            await getattr(obj, attr)()
        except Exception:
            pass