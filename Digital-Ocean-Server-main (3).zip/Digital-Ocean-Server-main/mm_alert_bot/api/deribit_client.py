# mm_alert_bot\api\deribit_client.py
"""
Deribit HTTP JSON-RPC Client (REST-only) - MM Alert Bot

- NO WebSocket usage
- HTTP JSON-RPC POST for all calls (/api/v2)
- Private calls use Authorization: Bearer <token> header
- Robust retries + timeouts + token refresh
- Session reuse for performance

Used by:
- MarginMonitor: get_account_summary()
- MMAlertService: get_btc_price_usd()
- TradeActivityMonitor: get_user_trades_by_currency(), get_positions()
- TransactionMonitor: get_transaction_log()
"""

from __future__ import annotations

import asyncio
import json
import logging
import random
import time
from typing import Optional, Dict, Any, List, Tuple

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

logger = logging.getLogger(__name__)

_AUTH_RETRIES = 4
_AUTH_BACKOFF_BASE = 1.6
_AUTH_BACKOFF_JITTER = 0.4
_TOKEN_REFRESH_BUFFER = 30
_DEFAULT_TIMEOUT = 12
_RETRY_STATUS_CODES = (408, 425, 429, 500, 502, 503, 504, 522)


def _build_retry(methods: List[str]) -> Retry:
    return Retry(
        total=6,
        connect=6,
        read=6,
        backoff_factor=0.6,
        status_forcelist=_RETRY_STATUS_CODES,
        allowed_methods=methods,
        raise_on_status=False,
    )


class DeribitClient:
    """REST-only Deribit client using HTTP JSON-RPC."""

    __slots__ = (
        "api_key", "api_secret", "testnet",
        "http_base", "http_rpc_url", "http_auth_url",
        "access_token", "_token_expires_at", "_auth_lock",
        "_rpc_id", "_get_session", "_post_session",
    )

    def __init__(self, config: Dict[str, Any]) -> None:
        self.api_key: str = config.get("client_id") or ""
        self.api_secret: str = config.get("client_secret") or ""
        self.testnet: bool = bool(config.get("testnet", False))

        if not self.api_key or not self.api_secret:
            raise ValueError("Deribit API credentials missing")

        self.http_base: str = (
            config.get("http_base")
            or ("https://test.deribit.com" if self.testnet else "https://www.deribit.com")
        )
        self.http_rpc_url: str = f"{self.http_base}/api/v2"
        self.http_auth_url: str = f"{self.http_base}/api/v2/public/auth"

        self.access_token: Optional[str] = None
        self._token_expires_at: float = 0.0
        self._auth_lock = asyncio.Lock()
        self._rpc_id: int = 0

        self._get_session: Optional[requests.Session] = None
        self._post_session: Optional[requests.Session] = None

        logger.info(
            "DeribitClient init (REST-only) | testnet=%s | http_base=%s",
            self.testnet, self.http_base,
        )

    # ------------------------------------------------------------------
    # Session management
    # ------------------------------------------------------------------
    def _ensure_get_session(self) -> requests.Session:
        if self._get_session is None:
            s = requests.Session()
            adapter = HTTPAdapter(
                max_retries=_build_retry(["GET"]),
                pool_connections=5,
                pool_maxsize=10,
            )
            s.mount("https://", adapter)
            s.mount("http://", adapter)
            s.headers.update({"Accept": "application/json"})
            self._get_session = s
        return self._get_session

    def _ensure_post_session(self) -> requests.Session:
        if self._post_session is None:
            s = requests.Session()
            adapter = HTTPAdapter(
                max_retries=_build_retry(["POST"]),
                pool_connections=10,
                pool_maxsize=20,
            )
            s.mount("https://", adapter)
            s.mount("http://", adapter)
            s.headers.update({
                "Accept": "application/json",
                "Content-Type": "application/json",
            })
            self._post_session = s
        return self._post_session

    def _next_id(self) -> int:
        self._rpc_id += 1
        return self._rpc_id

    # ------------------------------------------------------------------
    # Authentication
    # ------------------------------------------------------------------
    def _get_access_token_sync(self) -> Tuple[str, float]:
        session = self._ensure_get_session()
        params = {
            "grant_type": "client_credentials",
            "client_id": self.api_key,
            "client_secret": self.api_secret,
        }

        last_err: Optional[Exception] = None
        for attempt in range(_AUTH_RETRIES):
            try:
                resp = session.get(self.http_auth_url, params=params, timeout=10)
                resp.raise_for_status()
                data = resp.json() or {}
                result = data.get("result") or {}
                token = result.get("access_token")
                expires_in = float(result.get("expires_in") or 0.0)
                if not token:
                    raise RuntimeError(f"No access_token in response: {data}")
                return token, time.time() + max(0.0, expires_in)
            except (requests.exceptions.Timeout, requests.exceptions.ConnectionError) as e:
                last_err = e
                time.sleep((_AUTH_BACKOFF_BASE ** attempt) + random.uniform(0, _AUTH_BACKOFF_JITTER))
            except Exception as e:
                last_err = e
                break

        raise RuntimeError(f"REST auth failed after {_AUTH_RETRIES} attempts: {last_err}")

    async def _ensure_token(self, *, force: bool = False) -> None:
        async with self._auth_lock:
            if not force and self.access_token and time.time() < (self._token_expires_at - _TOKEN_REFRESH_BUFFER):
                return
            token, exp_at = await asyncio.to_thread(self._get_access_token_sync)
            self.access_token = token
            self._token_expires_at = exp_at
            logger.info("REST access_token obtained/refreshed")

    # ------------------------------------------------------------------
    # JSON-RPC
    # ------------------------------------------------------------------
    def _http_rpc_sync(
        self, method: str, params: Optional[dict], *, is_private: bool, timeout: int,
    ) -> dict:
        session = self._ensure_post_session()
        headers: Dict[str, str] = {}

        if is_private:
            if not self.access_token:
                raise RuntimeError("Missing access_token for private HTTP call")
            headers["Authorization"] = f"Bearer {self.access_token}"

        payload = {
            "jsonrpc": "2.0",
            "id": self._next_id(),
            "method": method,
            "params": params or {},
        }

        resp = session.post(
            self.http_rpc_url, headers=headers,
            data=json.dumps(payload), timeout=timeout,
        )

        if resp.status_code >= 400:
            raise RuntimeError(f"HTTP {resp.status_code} error: {resp.text}")

        data = resp.json() or {}
        if data.get("error"):
            raise RuntimeError(f"Deribit RPC error ({method}): {data['error']}")
        return data.get("result") or {}

    async def rpc(
        self, method: str, params: Optional[dict] = None,
        *, is_private: bool, timeout: int = _DEFAULT_TIMEOUT,
    ) -> dict:
        if is_private:
            await self._ensure_token(force=False)
        return await asyncio.to_thread(
            self._http_rpc_sync, method, params,
            is_private=is_private, timeout=timeout,
        )

    # ------------------------------------------------------------------
    # Account
    # ------------------------------------------------------------------
    async def get_account_summary(self, currency: str = "BTC", extended: bool = True) -> Dict[str, Any]:
        return await self.rpc(
            "private/get_account_summary",
            {"currency": str(currency).upper(), "extended": bool(extended)},
            is_private=True, timeout=15,
        )

    # ------------------------------------------------------------------
    # Transaction log
    # ------------------------------------------------------------------
    async def get_transaction_log(
        self, currency: str, *,
        start_timestamp: int, end_timestamp: int,
        count: int = 100, continuation: Optional[int] = None,
        types: Optional[List[str]] = None,
    ) -> dict:
        params: dict = {
            "currency": str(currency).upper(),
            "start_timestamp": int(start_timestamp),
            "end_timestamp": int(end_timestamp),
            "count": int(count),
        }
        if continuation is not None:
            params["continuation"] = continuation
        if types:
            params["types"] = types
        return await self.rpc(
            "private/get_transaction_log", params,
            is_private=True, timeout=20,
        )

    # ------------------------------------------------------------------
    # User trades
    # ------------------------------------------------------------------
    async def get_user_trades_by_currency(
        self, currency: str = "BTC",
        kind: Optional[str] = None,
        count: int = 50,
        start_timestamp: Optional[int] = None,
        end_timestamp: Optional[int] = None,
        sorting: str = "desc",
    ) -> Dict[str, Any]:
        params: dict = {
            "currency": str(currency).upper(),
            "count": int(count),
            "sorting": sorting,
        }
        if kind:
            params["kind"] = kind
        if start_timestamp is not None:
            params["start_timestamp"] = int(start_timestamp)
        if end_timestamp is not None:
            params["end_timestamp"] = int(end_timestamp)
        return await self.rpc(
            "private/get_user_trades_by_currency", params,
            is_private=True, timeout=15,
        )

    # ------------------------------------------------------------------
    # Portfolio total equity in USD
    # ------------------------------------------------------------------
    async def get_portfolio_equity_usd(self) -> float:
        currencies = ["BTC", "ETH", "USDC", "USDT", "SOL"]
        total_usd = 0.0

        for cur in currencies:
            try:
                summary = await self.rpc(
                    "private/get_account_summary",
                    {"currency": cur.upper(), "extended": True},
                    is_private=True, timeout=15,
                )
                equity = float(summary.get("equity", 0) or 0)
                if equity == 0:
                    continue

                if cur.upper() in ("USDC", "USDT"):
                    total_usd += equity
                else:
                    try:
                        perp = f"{cur.upper()}-PERPETUAL"
                        ticker = await self.rpc(
                            "public/ticker",
                            {"instrument_name": perp},
                            is_private=False, timeout=10,
                        )
                        price = float(
                            ticker.get("index_price")
                            or ticker.get("mark_price")
                            or ticker.get("last_price")
                            or 0
                        )
                        total_usd += equity * price
                    except Exception:
                        pass
            except Exception as e:
                logger.debug("Skipping %s for portfolio equity: %s", cur, e)
                continue

        return total_usd

    async def get_user_trades_by_instrument(
        self, instrument_name: str,
        count: int = 50,
        start_timestamp: Optional[int] = None,
        end_timestamp: Optional[int] = None,
        sorting: str = "desc",
    ) -> Dict[str, Any]:
        params: dict = {
            "instrument_name": instrument_name,
            "count": int(count),
            "sorting": sorting,
        }
        if start_timestamp is not None:
            params["start_timestamp"] = int(start_timestamp)
        if end_timestamp is not None:
            params["end_timestamp"] = int(end_timestamp)
        return await self.rpc(
            "private/get_user_trades_by_instrument", params,
            is_private=True, timeout=15,
        )

    # ------------------------------------------------------------------
    # Positions
    # ------------------------------------------------------------------
    async def get_positions(
        self, currency: str = "BTC", kind: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        params: dict = {"currency": str(currency).upper()}
        if kind:
            params["kind"] = kind
        result = await self.rpc(
            "private/get_positions", params,
            is_private=True, timeout=15,
        )
        if isinstance(result, list):
            return result
        return result.get("positions", []) if isinstance(result, dict) else []

    async def get_position(self, instrument_name: str) -> Dict[str, Any]:
        return await self.rpc(
            "private/get_position",
            {"instrument_name": instrument_name},
            is_private=True, timeout=15,
        )

    # ------------------------------------------------------------------
    # Open orders
    # ------------------------------------------------------------------
    async def get_open_orders_by_currency(
        self, currency: str = "BTC", kind: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        params: dict = {"currency": str(currency).upper()}
        if kind:
            params["kind"] = kind
        result = await self.rpc(
            "private/get_open_orders_by_currency", params,
            is_private=True, timeout=15,
        )
        return result if isinstance(result, list) else []

    # ------------------------------------------------------------------
    # Settlement history
    # ------------------------------------------------------------------
    async def get_settlement_history_by_currency(
        self, currency: str = "BTC",
        count: int = 20,
        settlement_type: Optional[str] = None,
    ) -> Dict[str, Any]:
        params: dict = {
            "currency": str(currency).upper(),
            "count": int(count),
        }
        if settlement_type:
            params["type"] = settlement_type
        return await self.rpc(
            "private/get_settlement_history_by_currency", params,
            is_private=True, timeout=15,
        )

    # ------------------------------------------------------------------
    # Market data
    # ------------------------------------------------------------------
    async def get_btc_price_usd(self) -> float:
        res = await self.rpc(
            "public/ticker", {"instrument_name": "BTC-PERPETUAL"},
            is_private=False, timeout=12,
        )
        price = res.get("index_price") or res.get("mark_price") or res.get("last_price")
        if price is None:
            raise RuntimeError(f"BTC price not found in ticker keys={list(res.keys())}")
        return float(price)

    async def get_ticker(self, instrument_name: str) -> Dict[str, Any]:
        return await self.rpc(
            "public/ticker", {"instrument_name": instrument_name},
            is_private=False, timeout=12,
        )

    async def get_instruments(
        self, currency: str = "BTC", kind: Optional[str] = None, expired: bool = False,
    ) -> List[Dict[str, Any]]:
        params: dict = {
            "currency": str(currency).upper(),
            "expired": expired,
        }
        if kind:
            params["kind"] = kind
        result = await self.rpc(
            "public/get_instruments", params,
            is_private=False, timeout=15,
        )
        return result if isinstance(result, list) else []

    # ------------------------------------------------------------------
    # Account greeks using account summary only (no rho)
    # ------------------------------------------------------------------
    # async def get_account_greeks(self, currency: str = "BTC") -> Dict[str, float]:
    #     summary = await self.get_account_summary(currency, extended=True)

    #     delta = (
    #         summary.get("delta_total")
    #         or summary.get("delta_total_map", {}).get(currency.upper())
    #         or summary.get("total_delta")
    #         or 0
    #     )
    #     gamma = (
    #         summary.get("gamma_total")
    #         or summary.get("total_gamma")
    #         or summary.get("options_gamma")
    #         or 0
    #     )
    #     vega = (
    #         summary.get("vega_total")
    #         or summary.get("total_vega")
    #         or summary.get("options_vega")
    #         or 0
    #     )
    #     theta = (
    #         summary.get("theta_total")
    #         or summary.get("total_theta")
    #         or summary.get("options_theta")
    #         or 0
    #     )

    #     logger.info(
    #         "Raw greeks fields from API: %s",
    #         {k: v for k, v in summary.items() if any(
    #             g in k.lower() for g in ["delta", "gamma", "vega", "theta", "greek"]
    #         )},
    #     )

    #     return {
    #         "delta": float(delta),
    #         "gamma": float(gamma),
    #         "vega": float(vega),
    #         "theta": float(theta),
    #     }
    # ------------------------------------------------------------------
    # Account greeks with per-position rho aggregation
    # ------------------------------------------------------------------
    async def get_account_greeks(self, currency: str = "BTC") -> Dict[str, float]:
        """
        Aggregate greeks from account summary + per-position rho from tickers.
        Rho is not available in account summary, so we sum it from each option position.
        """
        summary = await self.get_account_summary(currency, extended=True)

        delta = float(
            summary.get("delta_total")
            or summary.get("delta_total_map", {}).get(currency.upper())
            or summary.get("total_delta")
            or 0
        )
        gamma = float(
            summary.get("gamma_total")
            or summary.get("total_gamma")
            or summary.get("options_gamma")
            or 0
        )
        vega = float(
            summary.get("vega_total")
            or summary.get("total_vega")
            or summary.get("options_vega")
            or 0
        )
        theta = float(
            summary.get("theta_total")
            or summary.get("total_theta")
            or summary.get("options_theta")
            or 0
        )

        # Rho: aggregate from individual option tickers
        rho_total = 0.0
        try:
            positions = await self.get_positions(currency, kind="option")
            for pos in positions:
                size = float(pos.get("size", 0) or 0)
                if size == 0:
                    continue
                instrument = pos.get("instrument_name")
                if not instrument:
                    continue
                try:
                    ticker = await self.get_ticker(instrument)
                    greeks = ticker.get("greeks") or {}
                    per_contract_rho = float(greeks.get("rho", 0) or 0)
                    # size is already signed: positive=long, negative=short
                    rho_total += per_contract_rho * size
                except Exception:
                    pass
        except Exception:
            pass

        logger.info(
            "Account greeks: delta=%.4f gamma=%.6f vega=%.2f theta=%.2f rho=%.2f",
            delta, gamma, vega, theta, rho_total,
        )

        return {
            "delta": delta,
            "gamma": gamma,
            "vega": vega,
            "theta": theta,
            "rho": rho_total,
        }

    # ------------------------------------------------------------------
    # Portfolio PnL
    # ------------------------------------------------------------------
    async def get_portfolio_pnl(self, currency: str = "BTC") -> Dict[str, float]:
        summary = await self.get_account_summary(currency, extended=True)

        session_rpl = float(summary.get("session_rpl", 0) or 0)
        session_upl = float(summary.get("session_upl", 0) or 0)
        total_pl = float(summary.get("total_pl", session_rpl + session_upl) or 0)

        return {
            "session_rpl": session_rpl,
            "session_upl": session_upl,
            "total_pnl": total_pl,
            "futures_session_rpl": float(summary.get("futures_session_rpl", 0) or 0),
            "futures_session_upl": float(summary.get("futures_session_upl", 0) or 0),
            "options_session_rpl": float(summary.get("options_session_rpl", 0) or 0),
            "options_session_upl": float(summary.get("options_session_upl", 0) or 0),
        }

    # ------------------------------------------------------------------
    # Volatility data
    # ------------------------------------------------------------------
    async def get_historical_volatility(self, currency: str = "BTC") -> List[Any]:
        return await self.rpc(
            "public/get_historical_volatility",
            {"currency": str(currency).upper()},
            is_private=False, timeout=15,
        )

    async def get_volatility_index(self, currency: str = "BTC") -> Dict[str, Any]:
        resolution = 3600
        now_ms = int(time.time() * 1000)
        start_ms = now_ms - (30 * 24 * 3600 * 1000)

        return await self.rpc(
            "public/get_volatility_index_data",
            {
                "currency": str(currency).upper(),
                "start_timestamp": start_ms,
                "end_timestamp": now_ms,
                "resolution": resolution,
            },
            is_private=False, timeout=15,
        )

    # ------------------------------------------------------------------
    # Price history for ROC calculation
    # ------------------------------------------------------------------
    async def get_price_history(
        self, instrument: str = "BTC-PERPETUAL",
        resolution: int = 1, count: int = 1440,
    ) -> List[Any]:
        now_ms = int(time.time() * 1000)
        start_ms = now_ms - (count * resolution * 60 * 1000)

        result = await self.rpc(
            "public/get_tradingview_chart_data",
            {
                "instrument_name": instrument,
                "start_timestamp": start_ms,
                "end_timestamp": now_ms,
                "resolution": str(resolution),
            },
            is_private=False, timeout=15,
        )
        return result

    async def get_index_price_history(
        self, currency: str = "BTC",
        resolution: int = 1, count: int = 1440,
    ) -> List[Any]:
        """
        Deribit doesn't support index as chart instrument.
        Use BTC-PERPETUAL chart data - the close prices track spot closely.
        For current spot, use index_price from ticker separately.
        """
        instrument = f"{currency.upper()}-PERPETUAL"
        now_ms = int(time.time() * 1000)
        start_ms = now_ms - (count * resolution * 60 * 1000)

        result = await self.rpc(
            "public/get_tradingview_chart_data",
            {
                "instrument_name": instrument,
                "start_timestamp": start_ms,
                "end_timestamp": now_ms,
                "resolution": str(resolution),
            },
            is_private=False, timeout=15,
        )
        return result

    async def get_index_price(self, currency: str = "BTC") -> float:
        """Get current spot (index) price."""
        res = await self.rpc(
            "public/get_index_price",
            {"index_name": f"{currency.lower()}_usd"},
            is_private=False, timeout=10,
        )
        return float(res.get("index_price", 0))

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------
    async def connect(self) -> None:
        pass

    async def close(self) -> None:
        for session in (self._get_session, self._post_session):
            if session is not None:
                try:
                    session.close()
                except Exception:
                    pass
        self._get_session = None
        self._post_session = None
        logger.info("DeribitClient sessions closed")