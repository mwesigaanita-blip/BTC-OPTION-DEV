# mm_alert_bot\api\telegram_client.py
"""
Telegram Bot Client
Sends alerts to configured recipients.
"""
from __future__ import annotations

import asyncio
import logging
import socket
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional, List, Dict, Any

import aiohttp

logger = logging.getLogger(__name__)

_BASE_URL = "https://api.telegram.org/bot{token}/{method}"
_DEFAULT_RETRIES = 3
_TIMEOUT = aiohttp.ClientTimeout(total=30, connect=10, sock_read=10)


class TelegramClient:
    """Telegram Bot client for sending margin alerts."""

    __slots__ = (
        "bot_token", "owner_chat_id", "client_chat_id", "_session",
    )

    def __init__(
        self,
        bot_token: str,
        owner_chat_id: Optional[str] = None,
        client_chat_id: Optional[str] = None,
    ) -> None:
        self.bot_token = bot_token
        self.owner_chat_id = owner_chat_id
        self.client_chat_id = client_chat_id
        self._session: Optional[aiohttp.ClientSession] = None

    @property
    def all_recipients(self) -> List[str]:
        recipients: List[str] = []
        if self.owner_chat_id:
            recipients.append(self.owner_chat_id)
        if self.client_chat_id and self.client_chat_id != self.owner_chat_id:
            recipients.append(self.client_chat_id)
        return recipients

    async def _get_session(self) -> aiohttp.ClientSession:
        if self._session is None or self._session.closed:
            connector = aiohttp.TCPConnector(
                family=socket.AF_INET,
                ttl_dns_cache=300,
            )
            self._session = aiohttp.ClientSession(timeout=_TIMEOUT, connector=connector)
        return self._session

    async def _make_request(
        self, method: str, params: Dict[str, Any], retries: int = _DEFAULT_RETRIES,
    ) -> Dict[str, Any]:
        url = _BASE_URL.format(token=self.bot_token, method=method)
        session = await self._get_session()

        last_err: Optional[Exception] = None
        for attempt in range(retries):
            try:
                async with session.post(url, json=params) as response:
                    result = await response.json()
                    if not result.get("ok"):
                        raise RuntimeError(
                            f"Telegram API error: {result.get('description', 'Unknown')}"
                        )
                    return result
            except Exception as e:
                last_err = e
                logger.warning(
                    "Request failed (attempt %d/%d): %s", attempt + 1, retries, e,
                )
                if attempt < retries - 1:
                    await asyncio.sleep(2 ** attempt)

        raise RuntimeError(f"Telegram request failed after {retries} attempts: {last_err}")

    async def _make_request_form(
        self, method: str, form: aiohttp.FormData, retries: int = _DEFAULT_RETRIES,
    ) -> Dict[str, Any]:
        url = _BASE_URL.format(token=self.bot_token, method=method)
        session = await self._get_session()

        last_err: Optional[Exception] = None
        for attempt in range(retries):
            try:
                async with session.post(url, data=form) as response:
                    result = await response.json()
                    if not result.get("ok"):
                        raise RuntimeError(
                            f"Telegram API error: {result.get('description', 'Unknown')}"
                        )
                    return result
            except Exception as e:
                last_err = e
                logger.warning(
                    "Form request failed (attempt %d/%d): %s", attempt + 1, retries, e,
                )
                if attempt < retries - 1:
                    await asyncio.sleep(2 ** attempt)

        raise RuntimeError(f"Telegram form request failed after {retries} attempts: {last_err}")

    async def send_message(
        self,
        text: str,
        chat_id: Optional[str] = None,
        parse_mode: str = "HTML",
    ) -> Dict[str, Any]:
        target = chat_id or self.owner_chat_id
        if not target:
            raise ValueError("No chat_id provided")
        result = await self._make_request("sendMessage", {
            "chat_id": target,
            "text": text,
            "parse_mode": parse_mode,
        })
        logger.debug("Message sent to %s", target)
        return result

    async def send_document(
        self,
        file_path: str,
        caption: str = "",
        chat_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        target = chat_id or self.owner_chat_id
        if not target:
            raise ValueError("No chat_id provided")

        p = Path(file_path)
        if not p.is_file():
            raise FileNotFoundError(f"File not found: {file_path}")

        form = aiohttp.FormData()
        form.add_field("chat_id", str(target))
        if caption:
            form.add_field("caption", caption)

        with open(p, "rb") as f:
            form.add_field("document", f, filename=p.name, content_type="text/csv")
            result = await self._make_request_form("sendDocument", form)

        logger.debug("Document sent to %s: %s", target, p.name)
        return result

    async def send_to_all(self, text: str) -> List[Dict[str, Any]]:
        results: List[Dict[str, Any]] = []
        for cid in self.all_recipients:
            try:
                result = await self.send_message(text=text, chat_id=cid)
                results.append({"chat_id": cid, "success": True, "result": result})
            except Exception as e:
                logger.error("Failed to send to %s: %s", cid, e)
                results.append({"chat_id": cid, "success": False, "error": str(e)})
        return results

    async def send_startup_notification(self, config: Dict[str, Any]) -> List[Dict[str, Any]]:
        currencies = config.get("currencies", ["BTC"])
        critical = config.get("critical_threshold", 95)
        warning = config.get("warning_threshold", 80)
        warning_cd = config.get("warning_cooldown_minutes", 5)
        critical_cd = config.get("critical_cooldown_minutes", 1)
        interval = config.get("check_interval_seconds", 30)

        message = (
            "━━━━━━━━━━━━━━━━━━━━\n"
            "🟢 <b>MM MONITOR ONLINE</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n\n"
            f"<b>📡 Status:</b> Active\n"
            f"<b>💰 Monitoring:</b> <code>{', '.join(currencies)}</code>\n"
            f"<b>👥 Recipients:</b> {len(self.all_recipients)}\n\n"
            "<b>🧠 Active Monitors:</b>\n"
            "┌─────────────────────────\n"
            "│ 📊 Margin usage (MM%)\n"
            "│ 📌 Order lifecycle\n"
            "│ ✅ Trade executions\n"
            "│ 🔄 Position & portfolio changes\n"
            "│ 💀 Liquidation detection\n"
            "│ 🧾 Ledger events:\n"
            "│    • Deposits / Withdrawals\n"
            "│    • Fees & Funding\n"
            "│    • Settlement & Transfers\n"
            "└─────────────────────────\n\n"
            "<b>⚙️ Alert Configuration:</b>\n"
            "┌─────────────────────────\n"
            f"│ 🟡 Warning:  >= {warning}%\n"
            f"│    Alert every {warning_cd} min\n"
            "│\n"
            f"│ 🔴 Critical: >= {critical}%\n"
            f"│    Alert every {critical_cd} min\n"
            "│\n"
            f"│ ⏱ Check interval: {interval}s\n"
            "└─────────────────────────\n\n"
            "<i>Bot is actively monitoring your account activity and risk in real time.</i>"
        )
        return await self.send_to_all(text=message)

    async def send_shutdown_notification(self) -> List[Dict[str, Any]]:
        ts = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
        message = (
            "━━━━━━━━━━━━━━━━━━━━\n"
            "🔴 <b>MM MONITOR OFFLINE</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n\n"
            f"<b>Status:</b> Stopped\n"
            f"<b>Time:</b> {ts}\n\n"
            "<i>⚠️ Margin, transaction, liquidation, and ledger alerts are paused.</i>"
        )
        return await self.send_to_all(text=message)

    async def test_connection(self) -> bool:
        try:
            result = await self._make_request("getMe", {})
            bot_info = result.get("result", {})
            logger.info("Connected to bot: @%s", bot_info.get("username"))
            return True
        except Exception as e:
            logger.error("Connection test failed: %s", e)
            return False

    async def close(self) -> None:
        if self._session and not self._session.closed:
            await self._session.close()
            logger.info("Telegram client closed")