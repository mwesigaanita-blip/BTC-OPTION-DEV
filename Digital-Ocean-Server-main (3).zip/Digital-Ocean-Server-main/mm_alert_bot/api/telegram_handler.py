# mm_alert_bot\api\telegram_handler.py
"""
Telegram Command Handler
Processes incoming bot commands and returns account information.
Uses long-polling to receive updates from Telegram.
"""

from __future__ import annotations

import asyncio
import logging
import time
from typing import Optional, Dict, Any, Callable, Awaitable, List

import aiohttp
import socket
logger = logging.getLogger(__name__)

_BASE_URL = "https://api.telegram.org/bot{token}/{method}"
_POLL_TIMEOUT = 30
_POLL_INTERVAL = 1


class TelegramCommandHandler:
    """Listens for Telegram commands via long-polling and dispatches to handlers."""

    def __init__(
        self,
        bot_token: str,
        allowed_chat_ids: List[str],
    ) -> None:
        self.bot_token = bot_token
        self.allowed_chat_ids = set(allowed_chat_ids)
        self._handlers: Dict[str, Callable[[str, str], Awaitable[str]]] = {}
        self._running = False
        self._poll_task: Optional[asyncio.Task] = None
        self._last_update_id: int = 0
        self._session: Optional[aiohttp.ClientSession] = None
        self._send_callback: Optional[Callable[[str, str], Awaitable[None]]] = None

    def set_send_callback(self, callback: Callable[[str, str], Awaitable[None]]) -> None:
        self._send_callback = callback

    def register(self, command: str, handler: Callable[[str, str], Awaitable[str]]) -> None:
        cmd = command.lower().strip().lstrip("/")
        self._handlers[cmd] = handler
        logger.info("Registered command: /%s", cmd)

    async def _get_session(self) -> aiohttp.ClientSession:
        if self._session is None or self._session.closed:
            connector = aiohttp.TCPConnector(
                family=socket.AF_INET,   # Force IPv4 - fixes IPv6 unreachable error
                ttl_dns_cache=300,
            )
            self._session = aiohttp.ClientSession(
                timeout=aiohttp.ClientTimeout(total=_POLL_TIMEOUT + 10),
                connector=connector,
            )
        return self._session

    async def start(self) -> None:
        if self._running:
            return
        self._running = True
        self._poll_task = asyncio.create_task(self._poll_loop())
        logger.info(
            "TelegramCommandHandler started | commands=%s | allowed_chats=%s",
            list(self._handlers.keys()), self.allowed_chat_ids,
        )

    async def stop(self) -> None:
        self._running = False
        if self._poll_task:
            self._poll_task.cancel()
            try:
                await self._poll_task
            except asyncio.CancelledError:
                pass
        if self._session and not self._session.closed:
            await self._session.close()
        logger.info("TelegramCommandHandler stopped")

    async def _poll_loop(self) -> None:
        while self._running:
            try:
                updates = await self._get_updates()
                for update in updates:
                    await self._process_update(update)
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error("Poll error: %s", e, exc_info=True)
                await asyncio.sleep(5)

    async def _get_updates(self) -> List[Dict[str, Any]]:
        session = await self._get_session()
        url = _BASE_URL.format(token=self.bot_token, method="getUpdates")
        params = {
            "offset": self._last_update_id + 1,
            "timeout": _POLL_TIMEOUT,
            "allowed_updates": ["message"],
        }
        try:
            async with session.get(url, params=params) as resp:
                data = await resp.json()
                if not data.get("ok"):
                    return []
                results = data.get("result", [])
                if results:
                    self._last_update_id = max(
                        u.get("update_id", 0) for u in results
                    )
                return results
        except asyncio.TimeoutError:
            return []
        except Exception as e:
            logger.error("getUpdates failed: %s", e)
            await asyncio.sleep(2)
            return []

    async def _process_update(self, update: Dict[str, Any]) -> None:
        message = update.get("message") or {}
        text = str(message.get("text") or "").strip()
        chat = message.get("chat") or {}
        chat_id = str(chat.get("id", ""))

        if not text or not chat_id:
            return

        if chat_id not in self.allowed_chat_ids:
            logger.warning("Unauthorized command from chat_id=%s: %s", chat_id, text)
            return

        if not text.startswith("/"):
            return

        parts = text.split(maxsplit=1)
        command = parts[0].lower().lstrip("/").split("@")[0]
        args = parts[1] if len(parts) > 1 else ""

        handler = self._handlers.get(command)
        if handler is None:
            if self._send_callback:
                await self._send_callback(
                    f"Unknown command: /{command}\nUse /help for available commands.",
                    chat_id,
                )
            return

        try:
            response = await handler(args, chat_id)
            if response and self._send_callback:
                await self._send_callback(response, chat_id)
        except Exception as e:
            logger.error("Command /%s failed: %s", command, e, exc_info=True)
            if self._send_callback:
                await self._send_callback(
                    f"Error processing /{command}: {str(e)[:200]}",
                    chat_id,
                )