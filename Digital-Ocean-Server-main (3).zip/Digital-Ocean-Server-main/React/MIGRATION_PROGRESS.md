# React Front-End Migration - Progress Tracker

Living document tracking the Streamlit → React migration. Designed as a
self-contained handoff: read this top-to-bottom and you should understand the
full state of the project without prior context.

Plan reference: `.claude/plans/okay-now-let-s-start-vast-sutherland.md`.

Status legend: ⬜ not started · 🟡 in progress · ✅ done

---

## 1. Architecture

```
                                                    ┌─────────────┐
React (nginx)  ──HTTP /api ──▶  backend_api:8000 ──▶│ shared/*    │──▶ SQLite
               ──WS   /ws  ──▶  backend_ws:8100  ──▶│ + redis_live│──▶ Redis
                                                    └─────────────┘
```

- React app lives in `React/` (sibling of `Streamlit/`), runs alongside the
  existing Streamlit dashboard - both UIs read the same data.
- Auth reuses `data/auth.sqlite` / `streamlit_users` table (same bcrypt hashes)
  via the existing `shared/auth` package. Operator/viewer + per-page grants are
  honored. Page identifiers MUST match the `Streamlit/pages/*.py` file stems
  (e.g. `Account_Overview`) so existing users' `pages` JSON keeps working.
- `backend_api` is the React backend. It exposes JWT-protected REST under
  `/api/*` and reuses every `shared/*` module unchanged.
- `backend_ws` exposes the live WebSocket streams. We added a JWT
  `?token=<jwt>` query-param path so browsers can connect (they can't set the
  service `X-Internal-API-Key` header).
- `react` Docker service: multi-stage build → nginx, serves the SPA on
  `127.0.0.1:8502`, reverse-proxies `/api`→`api:8000` and `/ws`→`backend_ws:8100`
  (single origin, no CORS in prod).

---

## 2. Foundation status

| Item | Status | Notes |
|------|--------|-------|
| `backend_api` JWT auth | ✅ | `POST /api/auth/login`, `GET /api/auth/me`, HS256, `JWT_SECRET` env (required, no default) |
| `backend_api` CORS + router registration | ✅ | `CORS_ORIGINS` env, used only for Vite dev (5173) |
| `backend_api` data routers | ✅ | account, positions, market, stress, history, btc-prices |
| `requirements.txt` - `PyJWT` | ✅ | `PyJWT==2.9.0` |
| `backend_ws` JWT query-param auth | ✅ | `auth.py:check_jwt`, gate in `routes/_ws_helper.py` |
| React scaffold (Vite/TS/Tailwind) | ✅ | `npm run build` passes; bundle ~760KB gzipped ~223KB |
| App shell (Sidebar/TopBar/Theme toggle) | ✅ | Dark/light persisted to `localStorage` |
| React auth (AuthContext/ProtectedRoute/Login) | ✅ | JWT in `localStorage`, route guards, polished login |
| Docker `react` service + `api` wiring | ✅ | `React/Dockerfile` + `nginx.conf`, `api` `depends_on: redis`. Image builds. Requires `JWT_SECRET` in server `.env`. |
| End-to-end server verification | ⬜ | login + live data + theme toggle + access control on deployed stack |

---

## 3. Page migration status

The user explicitly **dropped** these from scope: `Model_Decisions_History`,
`X_Sentiment`, `AI_Models`, `AI_Models_Scheduler`. The pages below are the
selected set, in build-priority order.

| # | Streamlit page | React component | Status |
|---|----------------|-----------------|--------|
| - | Account_Overview | `AccountOverviewPage` | ✅ Live Portfolio + Custom What-If PNL sub-tabs |
| 1 | Positions_History | `PositionsHistoryPage` | ✅ pending live verification |
| 2 | BTC_Prices | `BtcPricesPage` | ✅ pending live verification |
| 3 | Decision_Board | `DecisionBoardPage` | ✅ pending live verification |
| 4 | WS_Layer_Health | `WsLayerHealthPage` | ✅ pending live verification |
| 5 | Hedge_Engine | `HedgeEnginePage` | ✅ pending live verification |
| 6 | MM_IM_Simulator | `MmImSimulatorPage` | ✅ pending live verification |
| 7 | RTI_Portfolio_Management | `RtiPortfolioPage` | ✅ pending live verification |
| 8 | Portfolio_Analysis_Bot | `PortfolioAnalysisBotPage` | ✅ pending live verification |
| 9 | Live_Options_Scheduler | `LiveOptionsSchedulerPage` | ✅ pending live verification |
| 10 | MM_Alerts | `MmAlertsPage` | ✅ pending live verification |
| 11 | Trading_Fees | `TradingFeesPage` | ✅ pending live verification |
| 12 | LLM_Fees | `LlmFeesPage` | ✅ pending live verification |
| 13 | User_Management | `UserManagementPage` | ✅ pending live verification |

### Workflow rule (user-requested)
**Go page by page. After each page: stop, summarize, wait for the user to
test it. Do not start another page until the user gives the "go".**

---

## 4. API endpoints

| Method | Path | Backs | Status |
|--------|------|-------|--------|
| POST | `/api/auth/login` | Login | ✅ |
| GET  | `/api/auth/me` | Token re-hydration | ✅ |
| GET  | `/api/account/overview` | Account Overview | ✅ |
| GET  | `/api/account/vol-metrics` | Account Overview | ✅ |
| GET  | `/api/account/equity-history` | Account Overview equity card | ✅ |
| GET  | `/api/positions/live` | Account Overview | ✅ |
| GET  | `/api/market/live` | Account Overview | ✅ |
| GET  | `/api/stress/today` · `/latest` | Account Overview | ✅ |
| POST | `/api/stress/pnl-curve` | Live PnL curve | ✅ |
| POST | `/api/stress/whatif` | Custom What-If simulator | ✅ |
| GET  | `/api/history/positions/portfolio` | Positions History time series | ✅ |
| GET  | `/api/history/positions/day/{date}` | Positions History drilldown (lazy) | ✅ |
| GET  | `/api/btc-prices/summary` | BTC Prices KPIs | ✅ |
| GET  | `/api/btc-prices/series` | BTC Prices candles + table | ✅ |
| GET  | `/api/btc-prices/export.csv` | BTC Prices CSV download | ✅ |
| GET  | `/api/decisions` · `/metrics` · `/{id}` · `/{id}/comments` · `/{id}/events` | Decision Board reads | ✅ |
| POST · PATCH · DELETE | `/api/decisions{,/{id},/{id}/move,/{id}/finalize,/{id}/actions,/actions/{aid},/{id}/comments,/comments/{cid}}` | Decision Board writes | ✅ |
| GET  | `/api/ws-health` | WS Layer Health (proxies collector + backend_ws) | ✅ |
| GET · PATCH | `/api/hedge/config` | Hedge Engine config read/merge | ✅ |
| POST | `/api/hedge/toggle` · `/account-state` | Enable/disable + Deribit fetch | ✅ |
| GET  | `/api/hedge/logs` | Hedge execution history + summary | ✅ |
| GET  | `/api/mm-im/positions` · `/quote/{name}` | MM/IM positions + chain + quote | ✅ |
| POST | `/api/mm-im/find-option` · `/simulate` | MM/IM resolve + Deribit simulate | ✅ |
| GET  | `/api/rti/equity-history` · `/trade-recap` | RTI analytics + trade log | ✅ |
| POST | `/api/rti/trade-recap/refresh` · `/comment` | Deribit pull + per-trade comments | ✅ |
| GET  | `/api/portfolio-bot/dashboard` · `/reports/{name}` | Portfolio Bot read-only bundle + PDF download | ✅ |
| GET  | `/api/options-scheduler/state` · `/snapshot/today` · `/snapshot/latest` · `/ohlcv/{date}` | Snapshot + OHLCV state and parquet reads | ✅ |
| POST | `/api/options-scheduler/snapshot/run` | Manual snapshot trigger (blocking) | ✅ |
| GET · POST | `/api/mm-alerts/config` | MM alert bot config (JWT-gated parallel to legacy `/mm-alert/config`) | ✅ |
| GET  | `/api/trading-fees/events` | Fee events list (days_back/limit/only_unnotified params) | ✅ |
| POST | `/api/trading-fees/sync` | Trigger Deribit fee ingestion + Telegram notify | ✅ |
| GET  | `/api/llm-fees/runs` | model_run_meta rows + summary KPIs + daily/breakdown aggregates | ✅ |
| GET  | `/api/users` | List all users + ALL_PAGES + ROLES (operator-only) | ✅ |
| POST | `/api/users` | Create user (operator-only) | ✅ |
| PATCH | `/api/users/{id}` | Update role/pages/active/password (operator-only, self-protect) | ✅ |
| WS   | `/ws/account` · `/positions` · `/market` · `/alerts` | Live data (backend_ws) | ✅ JWT query-param |

---

## 5. Files map

### Backend (`backend_api/`)
- `auth_jwt.py` - JWT issue / decode / FastAPI deps (`get_current_user`,
  `require_page(stem)`, `require_operator`). HS256, `JWT_SECRET` env.
- `routes_auth.py`, `routes_account.py`, `routes_positions.py`,
  `routes_market.py`, `routes_stress.py`, `routes_history.py`,
  `routes_btc_prices.py`, `routes_decisions.py`, `routes_ws_health.py`,
  `routes_hedge.py`, `routes_mm_im.py`, `routes_rti.py`,
  `routes_portfolio_bot.py`, `routes_options_scheduler.py`,
  `routes_mm_alerts.py` - all wrap `shared/*` or domain modules
  (ws_health proxies the internal `ws_collector` + `backend_ws`
  `/healthz` + `/metrics`; hedge wraps `simple_hedge.config_store` +
  `simple_hedge.deribit_client`).
- `services/positions_history.py` - ports the Streamlit
  `Positions_History.py` compute logic (KPIs, day metrics, capital history,
  flow merge, performance windows). Adds ffill→bfill on numeric metric
  columns so charts stay continuous on missing days.
- `main.py` - registers all routers + `CORSMiddleware`.

### Shared (`shared/`)
- `stress_scenarios_service.py` - `run_pnl_curve` extended with `with_greeks`
  + `eval_price` params. Per-leg greeks computed via finite difference:
  delta/gamma from each leg's curve slope, theta/vega from two extra
  `run_scenario` calls at the centre. **Pricing always uses live spot** - a
  frozen-BTC override only shifts the curve window (the endpoint computes
  asymmetric `pct_min`/`pct_max` off live spot).

### Backend WS (`backend_ws/`)
- `auth.py` - added `check_jwt(token)` alongside `check_api_key(headers,...)`.
- `routes/_ws_helper.py` - gate accepts either auth path.

### React (`React/`)
- `Dockerfile` (multi-stage node → nginx), `nginx.conf` (SPA + proxy),
  `.dockerignore`.
- `src/lib/pageMap.ts` - single source of truth for nav (stem → route/label/icon/migrated/operatorOnly).
  Marks Account_Overview, Positions_History, BTC_Prices as migrated.
- `src/App.tsx` - `PAGE_COMPONENTS` registry maps stems to components;
  un-migrated stems render `PlaceholderPage`.
- `src/auth/` - `AuthContext`, `ProtectedRoute` (per-page-stem access guard).
- `src/api/` - `client.ts` (axios + JWT interceptor + `wsUrl()`),
  `auth.ts`, `account.ts`, `whatif.ts`, `history.ts`, `btcPrices.ts`,
  `decisions.ts`, `wsHealth.ts`, `hedge.ts`, `mmIm.ts`, `rti.ts`,
  `portfolioBot.ts`, `optionsScheduler.ts`, `mmAlerts.ts`.
- `src/components/ui/` - `Button`, `Card`, `Input`, `Badge`, `Spinner`,
  `Table`, `Tabs`, `Slider`.
- `src/components/shared/` - `MetricCard`, `PageHeader`, `LoadingState`,
  `ErrorState`, `StalenessBanner`, `PnlCurveChart` (Recharts + break-even
  dots; gaps fixed by inserting break-even as real data points so hover
  works), `PositionsTree` (collapsible Asset→Kind→Expiry tree with
  inverse-option `Net Delta = Δ − mark_btc × amount`, `$` prefix on
  futures-row Amount).
- `src/components/whatif/` - `CustomWhatIfPnl` (container), `BtcPriceControls`
  (3 synced controls with local-draft number input), `SimSliders` (IV/Time/Range),
  `HypotheticalManager` (add/remove simulated options, labeled fields),
  `WhatIfPositionsTable` (checkbox include/exclude + inline editable size/side),
  `ScenarioGreeksPanel`.
- `src/pages/` - `LoginPage`, `AccountOverviewPage`, `PositionsHistoryPage`,
  `BtcPricesPage`, `DecisionBoardPage`, `WsLayerHealthPage`,
  `HedgeEnginePage`, `MmImSimulatorPage`, `RtiPortfolioPage`,
  `PortfolioAnalysisBotPage`, `LiveOptionsSchedulerPage`,
  `MmAlertsPage`, `PlaceholderPage`, `NotFoundPage`, `AccessDeniedPage`.
- `src/components/decisions/` - `Badges`, `DecisionCard`, `NewDecisionForm`,
  `DecisionDetail`, `ActionsTab`, `DiscussionTab`, `AuditTab`, `styles.ts`.
- `src/lib/whatifCalc.ts` - client-side `sumCurve`, `sumGreeks`,
  `zeroCrossings` (instant include/exclude re-summing).

### Root
- `requirements.txt` - added `PyJWT==2.9.0`.
- `docker-compose.yml` - added `react` service, `api` `depends_on: redis`.
- `.dockerignore` - excludes `**/.env` so the stale baked-in `.env` problem
  cannot recur (see lessons below).
- `run_all_react.bat` - local dev launcher (5 windows: redis docker,
  ws_collector, backend_api, backend_ws, vite dev). Sets `JWT_SECRET`,
  `REDIS_URL`, `PROJECT_ROOT`, `DB_PATH` explicitly so a malformed `.env` can't
  poison the run.

---

## 6. Deployment & local dev

### Server deploy
```bash
# one-time: add a strong JWT secret to .env on the server
echo "JWT_SECRET=$(openssl rand -hex 32)" >> .env

docker compose build api backend_ws react
docker compose up -d
# React on 127.0.0.1:8502 (route via Caddyfile to expose publicly)
```

### Local dev (Windows)
```cmd
run_all_react.bat
```
Opens five windows (redis container, ws_collector, backend_api, backend_ws,
Vite dev on :5173). Auto-opens `http://localhost:5173`. To stop everything:
close the windows + `docker stop btc_redis_local`.

### Test user
`remo` / `remo1234` (operator) - re-create with the one-liner in scripts notes
if it's missing.

---

## 7. Critical context for a fresh session

Things that are easy to miss and have already burned cycles:

1. **DB sharing with Streamlit.** Both the `streamlit` and `api` containers
   mount `/opt/btc_app/data:/data` with `DATA_DIR=/data` `DB_BASE_DIR=/data`.
   `shared/db_paths.py` resolves every DB from `DATA_DIR`. **Never** add a
   second copy of any SQLite file. Switching off Streamlit doesn't move data.

2. **The BTC daily fetcher is *not* in the UI.** `upsert_btc_yday_from_deribit`
   in `multi_agent_system/btc_ohlcv.py` is called by
   `multi_agent_system/runner_db_helper.py:423` (the AI-agents runner). The
   React/Streamlit UI only *reads*. If the agents don't run, the table doesn't
   get new rows - independent of which UI is in use. If we want daily prices
   without the agents, add a separate cron/job calling the upsert (TODO,
   user-pending).

3. **Auth `pages` grant uses Streamlit file stems.** Every React route's
   `pageStem` MUST equal a `Streamlit/pages/*.py` file stem (`Account_Overview`,
   `Positions_History`, `BTC_Prices`, …). `pageMap.ts` is the single source of
   truth. The backend `require_page(stem)` dependency checks against the JWT's
   `pages` claim, which was populated from `streamlit_users.pages` at login.

4. **`.env` pitfalls we already hit:**
   - `REDIS_LIVE_URL=redis://localhost:6379/0` in `.env` makes containers point
     at *themselves*. Set it to `redis://redis:6379/0`.
   - A **baked** `/app/.env` inside images (from `COPY . /app`) overrode the
     correct runtime env via `load_dotenv()`. We added `**/.env` to
     `.dockerignore`. **Do not** revert that.
   - Path env values with **leading spaces** (`DB_PATH= D:\...`) make
     `pathlib.Path().resolve()` treat them as relative and prepend CWD -
     producing nonsense doubled paths. Trim values.

5. **Frozen-BTC math (Custom What-If).** `run_pnl_curve` **must** always be
   called with `spot = live_spot`. A user-frozen BTC price only shifts the
   curve window (asymmetric `pct_min`/`pct_max` computed in the endpoint),
   and is passed as `eval_price` for greeks/pnl_at_spot. Calling with
   `spot = frozen_price` corrupts IV implication (mark_btc was observed at
   live spot) and the PnL anchor. Bug already found and fixed - don't re-undo.

6. **Per-leg greeks are finite-difference.** Delta/gamma from each leg's
   curve slope/curvature; theta/vega from two extra `run_scenario` calls at
   `(centre_pct, iv, days+1)` and `(centre_pct, iv+1, days)`. They're
   consistent with the PnL curve by construction. They are NOT closed-form BS
   greeks. Sufficient for the simulator panel.

7. **Auto-refresh + Custom What-If interaction.** The Streamlit Account
   Overview page had a 2 s `st_autorefresh` that reset the what-if controls.
   We added a **Live auto-refresh toggle** (default on) in Streamlit so users
   can pause refreshes while building a scenario. Not a React issue - but if
   you touch `Streamlit/pages/Account_Overview.py`, don't remove that toggle.

8. **Number formatting in Streamlit.** `st.column_config.NumberColumn(format=...)`
   uses sprintf-js - Python's `,` thousands flag is invalid. We switched all
   occurrences to `format="dollar"`. If you add new columns in Streamlit, use
   `dollar` / `accounting` presets, never `$%,.0f`.

9. **Inverse-option Net Delta.** In `PositionsTree`,
   `net_delta = delta − (mark_btc × signed_amount)` for options;
   `net_delta = delta` for futures/perps. This matches the values shown in
   the real Streamlit positions table.

10. **Chart gap policy.** `services/positions_history.py` does
    `ffill().bfill()` on every numeric metric column. Charts stay continuous
    on missing days. The user explicitly asked for this. Apply the same
    pattern to any new history endpoint.

---

## 8. Pending on the server (one-time)

- Add `JWT_SECRET=<random>` to `.env`.
- `docker compose build api backend_ws react`
- `docker compose up -d`
- Optional: route public hostname to `react:80` via `Caddyfile`.

---

## 9. What's next

**All pages in scope are now migrated.** The remaining work is server deploy + end-to-end verification (§2 row marked ⬜).

---

## 10. Changelog

- **2026-05-19** - Phase 1 backend: JWT auth, data routers, `backend_ws` JWT
  query-param. React scaffold started.
- **2026-05-19** - React app complete through Account Overview: Vite/TS/Tailwind,
  app shell + dark/light theme, JWT auth + route guards, polished login,
  Account Overview page (metrics, per-currency, greeks, positions tree,
  Live PnL curve).
- **2026-05-19** - Account Overview split into Live Portfolio / Custom
  What-If PNL sub-tabs. Simulator: synced BTC controls, freeze-BTC
  (re-centers curve), IV/time/range sliders, include/exclude + inline
  size/side editing, add/remove simulated options, scenario Greeks panel,
  Reset. Backend: `run_pnl_curve` returns per-leg greeks; new
  `POST /api/stress/whatif`.
- **2026-05-19** - Fixed frozen-BTC math bug: `run_pnl_curve` now always
  prices from the live spot; freezing only shifts the curve window
  (asymmetric pct range + new `eval_price` param).
- **2026-05-20** - Docker wiring complete: `React/Dockerfile` + `nginx.conf`
  (SPA + reverse-proxy), `react` service in `docker-compose.yml`, `api`
  `depends_on: redis`. Image builds clean.
- **2026-05-20** - Page #1 **Positions_History** migrated.
  `services/positions_history.py` + `routes_history.py`; full React page
  with date-range controls, KPI strip, 8 performance cards, dual-axis
  equity chart with deposit/withdrawal markers (Recharts), 3 separate
  line charts (PnL/Open Positions/Greeks), lazy-loaded daily drilldown.
  Time-series gaps now ffill→bfill so charts stay continuous.
- **2026-05-20** - Page #2 **BTC_Prices** migrated.
  `routes_btc_prices.py` (`/summary`, `/series`, `/export.csv`).
  React page with preset + custom date range, KPI strip, **custom-shape
  candlestick chart in Recharts** (wick + body, green/red), latest-rows
  table with a row-count selector (10/25/50/100/200, default 10), full
  CSV download.
- **2026-05-20** - Page #10 **MM_Alerts** migrated.
  `routes_mm_alerts.py` exposes `GET /api/mm-alerts/config` and
  `POST /api/mm-alerts/config` - JWT-gated by the `MM_Alerts` page grant
  and wraps the existing `backend_api.mm_alert_config_store`. The
  pre-existing unauth'd `/mm-alert/config` route is left in place for the
  Streamlit page and the alert bot itself. React page has an Enable
  toggle, threshold + cooldown + interval fields with per-field help
  copy, a currency multiselect (BTC/ETH/USDC/USDT), client-side
  validation (warning ≤ critical, range bounds, at least one currency),
  a dirty-state Save button with Discard, and a raw DB JSON viewer.
- **2026-05-20** - Page #9 **Live_Options_Scheduler** migrated.
  `routes_options_scheduler.py` exposes `GET /api/options-scheduler/state`
  (combined OHLCV + snapshot pipeline state + env config + now/today),
  `GET /api/options-scheduler/snapshot/today` (row count),
  `GET /api/options-scheduler/snapshot/latest?limit` (latest parquet rows,
  walks back 7 days), `GET /api/options-scheduler/ohlcv/{date}?instrument&limit`
  (per-day 1-min OHLCV with optional instrument filter), and
  `POST /api/options-scheduler/snapshot/run` (blocking manual trigger,
  returns instruments/rows/duration/files-written breakdown). React page
  has two tabs: OHLCV 1-Minute (date picker + instrument filter + rows
  selector + KPI strip + dense parquet table + gap viewer) and Snapshot
  (state + config cards + now/last-run/last-date strip + ran-today banner +
  latest-rows table + manual trigger with per-day file-count badges).
- **2026-05-20** - Page #8 **Portfolio_Analysis_Bot** migrated.
  `routes_portfolio_bot.py` exposes a single
  `GET /api/portfolio-bot/dashboard` bundle (state + alerts +
  suppressions + audit + thresholds + latest_report_run + reports
  list + config) and `GET /api/portfolio-bot/reports/{filename}`
  (PDF download, filename-validated to `portfolio_*.pdf` inside
  `REPORT_DIR`, path-traversal-safe). Lazy-imports
  `portfolio_analysis` so a broken package surfaces as 503 rather
  than a startup crash. React page is **read-only** (every mutation
  still flows through Telegram, intentional): top Calm Score pill +
  bot liveness signal + 5-card KPI strip, then 4 tabs - Overview
  (state + reasoning + active alerts table + suppressions list +
  recent activity feed), Thresholds (full table with overridden
  highlight + override history table), Daily Reports (latest report
  card + all-reports table + JWT-aware blob download), Info
  (architecture + Calm Score states + Telegram commands + env vars +
  useful files). Page doc at
  [`React/docs/PORTFOLIO_ANALYSIS_BOT.md`](docs/PORTFOLIO_ANALYSIS_BOT.md).
- **2026-05-20** - Page #7 **RTI_Portfolio_Management** migrated.
  `routes_rti.py` exposes `GET /api/rti/equity-history` (full
  account-equity history from `account_snapshots`), `GET
  /api/rti/trade-recap` (KPIs + normalized transaction log + comments),
  `POST /api/rti/trade-recap/refresh` (Deribit pull), and
  `POST /api/rti/trade-recap/comment` (persist per-trade note). React
  page has two tabs: Analytics (KPIs + Download Full CSV + Latest
  Records table) and Trade Recap (Refresh button, KPI strip, 4 client-
  side filters, transaction table with action emoji + direction badge,
  Download CSV of the filtered view, Add/Edit Comment editor keyed by
  trade_id). Page doc at
  [`React/docs/RTI_PORTFOLIO_MANAGEMENT.md`](docs/RTI_PORTFOLIO_MANAGEMENT.md).
- **2026-05-20** - Page #6 **MM_IM_Simulator** migrated.
  `routes_mm_im.py` exposes `GET /api/mm-im/positions` (positions +
  option chain), `GET /api/mm-im/quote/{name}`, `POST /api/mm-im/find-option`,
  `POST /api/mm-im/simulate`. Wraps `shared/simulation_service.py` so
  the browser never holds Deribit creds. React page mirrors the
  Streamlit layout in 7 cards: current positions, per-row adjustments
  (no change / decrease / increase + amount with validation), new
  option trades (expiry → strike → type → side → amount with live
  quote preview), new perpetual trades, preview, run, per-currency
  before/after IM% MM% Delta with tone-coded change cards + raw JSON
  expanders. Page doc at
  [`React/docs/MM_IM_SIMULATOR.md`](docs/MM_IM_SIMULATOR.md).
- **2026-05-20** - Page #5 **Hedge_Engine** migrated.
  `routes_hedge.py` exposes `GET/PATCH /api/hedge/config`,
  `POST /api/hedge/toggle` and `/account-state`, `GET /api/hedge/logs`.
  Server-side wraps `simple_hedge.config_store` + `DeribitClient` so the
  browser never holds Deribit creds. React page mirrors the Streamlit
  layout: status pill + enable/disable button, Fetch-from-Deribit card
  with MM%/Net Delta/Equity/Margin/BTC metrics, 5 config tabs
  (MM Buckets / Sizing / Safety / Speed / General) with per-tab Save +
  inline saved/error hints, log history table (BUY/SELL badges, bucket
  emoji, error highlights) + summary strip.
- **2026-05-20** - Page #4 **WS_Layer_Health** migrated.
  `routes_ws_health.py` server-side proxies the internal
  `ws_collector:8101` and `backend_ws:8100` `/healthz` + `/metrics`
  endpoints (browsers can't reach them - they're on the docker network),
  parses Prometheus text into structured rows. React page mirrors the
  Streamlit layout: collector KPIs + downtime + watchdog block,
  per-channel staleness table, messages-per-channel, Redis subscriber
  counts, backend_ws KPIs, fanout topics table, Redis pubsub downtime
  table, raw `/metrics` excerpts on toggle. 5s React-Query polling.
- **2026-05-20** - Page #3 **Decision_Board** migrated.
  `routes_decisions.py` exposing full CRUD on decisions / actions /
  comments + metrics, move-status, finalize, audit-trail events; all
  wrapping `decision_board.service`. React page with KPI strip,
  search/status/priority filters + sort, date-grouped Kanban
  (Ideas/Under Review/Done) with collapsible day groups, new-decision
  form supporting multiple inline actions, full detail view with
  Overview/Actions/Discussion/Audit-Trail tabs, in-place edit for
  decision/actions/comments, finalize flow (locks the record),
  delete-decision danger zone.
- **2026-05-20** - Page #13 **User_Management** migrated (operator-only).
  `routes_user_management.py` exposes `GET /api/users` (list all users +
  ALL_PAGES + ROLES, operator-gated), `POST /api/users` (create with
  username/password/role/pages validation — password ≥8 chars, viewer must
  have ≥1 page, username uniqueness), `PATCH /api/users/{id}` (update
  role/pages/is_active/optional-password with self-protection: editing own
  account preserves role + active status). React page has three tabs — All
  Users (collapsible rows showing role badge, status dot, created/last-login,
  page grants), Add User (form with username, password + confirm, role
  select, page-access checklist with operator auto-lock, client-side
  validation, success banner), Edit User (user selector, same fields with
  self-warning banner, optional password reset). Redirects to All Users tab
  on successful create.
- **2026-05-20** - Page #12 **LLM_Fees** migrated.
  `routes_llm_fees.py` exposes `GET /api/llm-fees/runs` — reads `model_run_meta`
  from `models.sqlite`; accepts `start_date`, `end_date`, `provider`,
  `model_label`, `include_zero` query params; returns filtered rows, summary
  KPIs (total/n_runs/avg/last-7/last-30), daily time series, daily-by-model
  matrix for stacked area, by-model and by-provider breakdowns, and stable
  filter-option lists from the full unfiltered dataset. React page has a
  Filters card (date range, provider select, model-label select, include-zero
  toggle), 5-cell KPI strip, daily-cost area chart, stacked-area by-model
  (shown only when >1 model exists), horizontal-bar breakdowns for model and
  provider side by side, and a runs table (ID, label, provider, model ID,
  run-time UTC, cost).
- **2026-05-20** - Page #11 **Trading_Fees** migrated.
  `routes_trading_fees.py` exposes `GET /api/trading-fees/events` (fee events
  filtered by days_back/limit/only_unnotified, with per-row time_utc and a
  summary of total fees by currency + USD approx) and
  `POST /api/trading-fees/sync` (blocking Deribit ingestion via
  `ingest_fees_once`, returns fetched_trades/inserted/notified). React page
  has a Sync card (with success banner showing insert/notify counts), a
  Filters card (days_back input, max-rows input, only-unnotified checkbox),
  per-currency summary metric cards + total-USD card, and a dense fee-events
  table (time, instrument, side badge, fee amount, fee USD, price, amount,
  trade ID, Telegram-notified indicator).
- **2026-05-20** - Confirmed: BTC daily fetcher
  (`multi_agent_system/btc_ohlcv.py:upsert_btc_yday_from_deribit`, called
  from `runner_db_helper.py:423`) is independent of the UI swap. If
  agents don't run, the table is dormant - same in Streamlit or React.
