import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import path from "path";

// In dev, proxy /api and /ws to the backend services so the browser hits a
// single origin (no CORS). In prod the nginx config does the same.
export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: { "@": path.resolve(__dirname, "src") },
  },
  server: {
    host: true,
    port: 5173,
    proxy: {
      "/api": { target: "http://localhost:8000", changeOrigin: true },
      "/ws": { target: "ws://localhost:8100", ws: true, changeOrigin: true },
    },
  },
});
