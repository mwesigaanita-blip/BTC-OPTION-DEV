import { Navigate, Route, Routes } from "react-router-dom";
import { AppShell } from "@/components/layout/AppShell";
import { ProtectedRoute } from "@/auth/ProtectedRoute";
import { useAuth } from "@/auth/AuthContext";
import { LoadingState } from "@/components/shared/LoadingState";
import { LoginPage } from "@/pages/LoginPage";
import { AccountOverviewPage } from "@/pages/AccountOverviewPage";
import { PositionsHistoryPage } from "@/pages/PositionsHistoryPage";
import { BtcPricesPage } from "@/pages/BtcPricesPage";
import { VolatilityPage } from "@/pages/VolatilityPage";
import { DecisionBoardPage } from "@/pages/DecisionBoardPage";
import { WsLayerHealthPage } from "@/pages/WsLayerHealthPage";
import { HedgeEnginePage } from "@/pages/HedgeEnginePage";
import { MmImSimulatorPage } from "@/pages/MmImSimulatorPage";
import { RtiPortfolioPage } from "@/pages/RtiPortfolioPage";
import { PortfolioAnalysisBotPage } from "@/pages/PortfolioAnalysisBotPage";
import { LiveOptionsSchedulerPage } from "@/pages/LiveOptionsSchedulerPage";
import { MmAlertsPage } from "@/pages/MmAlertsPage";
import TradingFeesPage from "@/pages/TradingFeesPage";
import LlmFeesPage from "@/pages/LlmFeesPage";
import UserManagementPage from "@/pages/UserManagementPage";
import { PlaceholderPage } from "@/pages/PlaceholderPage";
import { NotFoundPage } from "@/pages/NotFoundPage";
import { PAGES } from "@/lib/pageMap";

/** Stem → page component registry. Missing stems render the placeholder. */
const PAGE_COMPONENTS: Record<string, React.ComponentType> = {
  Account_Overview: AccountOverviewPage,
  Positions_History: PositionsHistoryPage,
  BTC_Prices: BtcPricesPage,
  Volatility: VolatilityPage,
  Decision_Board: DecisionBoardPage,
  WS_Layer_Health: WsLayerHealthPage,
  Hedge_Engine: HedgeEnginePage,
  MM_IM_Simulator: MmImSimulatorPage,
  RTI_Portfolio_Management: RtiPortfolioPage,
  Portfolio_Analysis_Bot: PortfolioAnalysisBotPage,
  Live_Options_Scheduler: LiveOptionsSchedulerPage,
  MM_Alerts: MmAlertsPage,
  Trading_Fees: TradingFeesPage,
  LLM_Fees: LlmFeesPage,
  User_Management: UserManagementPage,
};

/** Auth gate for the whole app - renders the shell once logged in. */
function ProtectedLayout() {
  const { user, ready } = useAuth();
  if (!ready) return <LoadingState label="Loading…" full />;
  if (!user) return <Navigate to="/login" replace />;
  return <AppShell />;
}

export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<LoginPage />} />

      <Route element={<ProtectedLayout />}>
        <Route index element={<Navigate to="/account-overview" replace />} />

        {PAGES.map((p) => {
          const Page = PAGE_COMPONENTS[p.stem] ?? PlaceholderPage;
          return (
            <Route
              key={p.stem}
              path={p.route}
              element={
                <ProtectedRoute pageStem={p.stem} operatorOnly={p.operatorOnly}>
                  <Page />
                </ProtectedRoute>
              }
            />
          );
        })}

        <Route path="*" element={<NotFoundPage />} />
      </Route>
    </Routes>
  );
}
