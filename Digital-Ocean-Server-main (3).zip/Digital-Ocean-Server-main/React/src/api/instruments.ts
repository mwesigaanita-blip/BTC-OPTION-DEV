import { api } from "./client";

export interface OptionInstrument {
  instrument_name: string;
  strike: number;
  option_type: "C" | "P";
}

export interface OptionExpiry {
  expiry_label: string; // DDMMMYY token from Deribit (matches instrument_name)
  expiry_iso: string; // YYYY-MM-DD
  expiry_ts: number; // seconds
  instruments: OptionInstrument[];
}

export interface OptionInstrumentsResponse {
  currency: string;
  fetched_at: number;
  expiries: OptionExpiry[];
}

export async function fetchOptionInstruments(
  currency: string = "BTC",
): Promise<OptionInstrumentsResponse> {
  const { data } = await api.get<OptionInstrumentsResponse>(
    "/api/market/option-instruments",
    { params: { currency } },
  );
  return data;
}
