import { api } from "./client";

export interface MmAlertConfig {
  is_enabled: boolean;
  warning_threshold: number;
  critical_threshold: number;
  warning_cooldown_minutes: number;
  critical_cooldown_minutes: number;
  check_interval_seconds: number;
  currencies: string[];
  updated_at_utc?: string;
  [k: string]: unknown;
}

export type MmAlertConfigPatch = Partial<
  Pick<
    MmAlertConfig,
    | "is_enabled"
    | "warning_threshold"
    | "critical_threshold"
    | "warning_cooldown_minutes"
    | "critical_cooldown_minutes"
    | "check_interval_seconds"
    | "currencies"
  >
>;

export async function fetchMmAlertsConfig(): Promise<MmAlertConfig> {
  const { data } = await api.get<MmAlertConfig>("/api/mm-alerts/config");
  return data;
}

export async function saveMmAlertsConfig(
  patch: MmAlertConfigPatch,
): Promise<MmAlertConfig> {
  const { data } = await api.post<MmAlertConfig>(
    "/api/mm-alerts/config",
    patch,
  );
  return data;
}
