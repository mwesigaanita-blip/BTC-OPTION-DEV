import { api } from "./client";

export type DecisionStatus = "ideas" | "under_review" | "done";
export type Priority = "low" | "medium" | "high" | "critical";
export type FinalOutcome = "accepted" | "rejected" | "partial" | "informational";
export type ActionType = "open" | "close" | "adjust" | "hedge" | "note" | "other";
export type SortKey = "newest" | "oldest" | "recently_updated";

export interface Decision {
  id: number;
  title: string;
  description?: string | null;
  created_by: string;
  status: DecisionStatus;
  priority: Priority;
  final_outcome?: FinalOutcome | null;
  final_summary_reason?: string | null;
  locked_flag: number;
  finalized_by?: string | null;
  finalized_at_utc?: string | null;
  created_at_utc: string;
  updated_at_utc?: string | null;
}

export interface DecisionAction {
  id: number;
  decision_id: number;
  action_type: ActionType | string;
  reason_text: string;
  instrument_name?: string | null;
  side?: string | null;
  quantity?: number | null;
  price_reference?: number | null;
  sort_order?: number;
  created_at_utc: string;
}

export interface DecisionComment {
  id: number;
  decision_id: number;
  author: string;
  comment_text: string;
  created_at_utc: string;
  edited_at_utc?: string | null;
  deleted_flag?: number;
}

export interface DecisionEvent {
  id: number;
  decision_id: number;
  event_type: string;
  actor: string;
  event_payload_json?: string | null;
  created_at_utc: string;
}

export interface DecisionDetail extends Decision {
  actions: DecisionAction[];
  comments: DecisionComment[];
  events: DecisionEvent[];
  actions_total: number;
  comments_total: number;
  events_total: number;
}

export interface DecisionListResponse {
  decisions: Decision[];
  counts: Record<number, { actions: number; comments: number }>;
}

export interface DecisionMetrics {
  total: number;
  by_status: Record<string, number>;
  by_outcome: Record<string, number>;
}

export interface ActionInput {
  action_type: ActionType | string;
  reason_text?: string;
  instrument_name?: string | null;
  side?: string | null;
  quantity?: number | null;
  price_reference?: number | null;
  sort_order?: number;
}

export interface DecisionCreateInput {
  title: string;
  description?: string;
  priority?: Priority;
  actions?: ActionInput[];
}

export interface ListParams {
  status?: DecisionStatus;
  priority?: Priority;
  created_by?: string;
  final_outcome?: FinalOutcome;
  search?: string;
  sort?: SortKey;
  limit?: number;
  offset?: number;
}

export async function listDecisions(params: ListParams = {}): Promise<DecisionListResponse> {
  const { data } = await api.get<DecisionListResponse>("/api/decisions", { params });
  return data;
}

export async function fetchMetrics(): Promise<DecisionMetrics> {
  const { data } = await api.get<DecisionMetrics>("/api/decisions/metrics");
  return data;
}

export async function fetchDecision(id: number): Promise<DecisionDetail> {
  const { data } = await api.get<DecisionDetail>(`/api/decisions/${id}`);
  return data;
}

export async function createDecision(body: DecisionCreateInput): Promise<Decision> {
  const { data } = await api.post<Decision>("/api/decisions", body);
  return data;
}

export async function updateDecision(
  id: number,
  body: { title?: string; description?: string; priority?: Priority },
): Promise<Decision> {
  const { data } = await api.patch<Decision>(`/api/decisions/${id}`, body);
  return data;
}

export async function deleteDecision(id: number): Promise<void> {
  await api.delete(`/api/decisions/${id}`);
}

export async function moveStatus(
  id: number,
  new_status: DecisionStatus,
): Promise<Decision> {
  const { data } = await api.post<Decision>(`/api/decisions/${id}/move`, { new_status });
  return data;
}

export async function finalizeDecision(
  id: number,
  final_outcome: FinalOutcome,
  final_summary_reason: string,
): Promise<Decision> {
  const { data } = await api.post<Decision>(`/api/decisions/${id}/finalize`, {
    final_outcome,
    final_summary_reason,
  });
  return data;
}

export async function addAction(id: number, body: ActionInput): Promise<DecisionAction> {
  const { data } = await api.post<DecisionAction>(`/api/decisions/${id}/actions`, body);
  return data;
}

export async function updateAction(
  actionId: number,
  body: Partial<ActionInput>,
): Promise<DecisionAction> {
  const { data } = await api.patch<DecisionAction>(
    `/api/decisions/actions/${actionId}`,
    body,
  );
  return data;
}

export async function deleteAction(actionId: number): Promise<void> {
  await api.delete(`/api/decisions/actions/${actionId}`);
}

export async function listComments(
  id: number,
  limit = 50,
  offset = 0,
): Promise<{ comments: DecisionComment[]; total: number }> {
  const { data } = await api.get<{ comments: DecisionComment[]; total: number }>(
    `/api/decisions/${id}/comments`,
    { params: { limit, offset } },
  );
  return data;
}

export async function addComment(id: number, comment_text: string): Promise<DecisionComment> {
  const { data } = await api.post<DecisionComment>(`/api/decisions/${id}/comments`, {
    comment_text,
  });
  return data;
}

export async function updateComment(
  commentId: number,
  new_text: string,
): Promise<DecisionComment> {
  const { data } = await api.patch<DecisionComment>(
    `/api/decisions/comments/${commentId}`,
    { new_text },
  );
  return data;
}

export async function deleteComment(commentId: number): Promise<void> {
  await api.delete(`/api/decisions/comments/${commentId}`);
}

export async function listEvents(
  id: number,
  limit = 100,
  offset = 0,
): Promise<{ events: DecisionEvent[]; total: number }> {
  const { data } = await api.get<{ events: DecisionEvent[]; total: number }>(
    `/api/decisions/${id}/events`,
    { params: { limit, offset } },
  );
  return data;
}
