import { api } from "./client";
import type {
  AccountOverviewResponse,
  EquityHistoryResponse,
  MarketResponse,
  PnlCurveResponse,
  PositionsResponse,
} from "@/types/api";

export async function fetchAccountOverview(): Promise<AccountOverviewResponse> {
  const { data } = await api.get<AccountOverviewResponse>(
    "/api/account/overview",
  );
  return data;
}

export async function fetchEquityHistory(): Promise<EquityHistoryResponse> {
  const { data } = await api.get<EquityHistoryResponse>(
    "/api/account/equity-history",
  );
  return data;
}

export async function fetchPositions(): Promise<PositionsResponse> {
  const { data } = await api.get<PositionsResponse>("/api/positions/live");
  return data;
}

export async function fetchMarket(): Promise<MarketResponse> {
  const { data } = await api.get<MarketResponse>("/api/market/live");
  return data;
}

export interface PnlCurveParams {
  range_pct?: number;
  iv_points?: number;
  days_forward?: number;
}

export async function fetchPnlCurve(
  params: PnlCurveParams = {},
): Promise<PnlCurveResponse> {
  const { data } = await api.post<PnlCurveResponse>(
    "/api/stress/pnl-curve",
    params,
  );
  return data;
}
