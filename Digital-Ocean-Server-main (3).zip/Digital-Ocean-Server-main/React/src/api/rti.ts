import { api } from "./client";

export interface EquityHistoryResponseRti {
  rows: Record<string, unknown>[];
  columns: string[];
  last_date: string | null;
  total_rows: number;
}

export interface TradeRecapKpis {
  total_events: number;
  total_trades: number;
  total_fees_usd: number;
  total_premium_usd: number;
}

export interface TradeRecapResponse {
  available: boolean;
  kpis: TradeRecapKpis;
  rows: Record<string, unknown>[];
  columns: string[];
}

export interface RefreshPerCurrency {
  currency: string;
  new_rows: number;
  error: string | null;
}

export interface RefreshResponse {
  new_rows: number;
  per_currency?: RefreshPerCurrency[];
}

export async function fetchRtiEquityHistory(): Promise<EquityHistoryResponseRti> {
  const { data } = await api.get<EquityHistoryResponseRti>("/api/rti/equity-history");
  return data;
}

export async function fetchRtiTradeRecap(): Promise<TradeRecapResponse> {
  const { data } = await api.get<TradeRecapResponse>("/api/rti/trade-recap");
  return data;
}

export async function refreshRtiTradeRecap(
  days_back = 365,
  cooldown_minutes = 0,
): Promise<RefreshResponse> {
  const { data } = await api.post<RefreshResponse>(
    "/api/rti/trade-recap/refresh",
    { days_back, cooldown_minutes },
  );
  return data;
}

export async function saveRtiTradeComment(
  trade_id: string,
  comment: string,
): Promise<void> {
  await api.post("/api/rti/trade-recap/comment", { trade_id, comment });
}
