import { api, getToken } from "./client";

export type CalmScore =
  | "RELAX"
  | "TAKE_A_LOOK"
  | "ACTIVE_MONITORING"
  | "URGENT_ACTION"
  | string;

export type Severity = "INFO" | "WARNING" | "URGENT" | "EMERGENCY" | string;

export interface BotState {
  calm_score: CalmScore;
  ts_utc: string;
  reasoning?: string | null;
  [k: string]: unknown;
}

export interface BotAlert {
  ts_utc: string;
  severity: Severity;
  rule: string;
  dedup_key: string;
  message?: string | null;
  [k: string]: unknown;
}

export interface BotSuppression {
  dedup_key: string;
  set_by_user_name: string;
  expires_at_utc?: string | null;
  [k: string]: unknown;
}

export interface BotAuditRow {
  ts_utc: string;
  user_name: string;
  action: string;
  payload_json: string;
  [k: string]: unknown;
}

export interface BotThreshold {
  name: string;
  label: string;
  current: number;
  default: number;
  current_display: string;
  default_display: string;
  overridden: boolean;
  expires_at_utc?: string | null;
  set_by_user_name?: string | null;
  description: string;
  [k: string]: unknown;
}

export interface BotReportRun {
  ts_utc: string;
  [k: string]: unknown;
}

export interface BotReportFile {
  name: string;
  size_kb: number;
  modified_utc: string;
}

export interface BotConfig {
  report_dir: string;
  report_daily_utc_hour: number;
  report_daily_utc_minute: number;
}

export interface PortfolioBotDashboard {
  state: BotState | null;
  alerts: BotAlert[];
  suppressions: BotSuppression[];
  audit: BotAuditRow[];
  thresholds: BotThreshold[];
  latest_report_run: BotReportRun | null;
  reports: BotReportFile[];
  config: BotConfig;
}

export async function fetchPortfolioBotDashboard(
  audit_limit = 50,
): Promise<PortfolioBotDashboard> {
  const { data } = await api.get<PortfolioBotDashboard>(
    "/api/portfolio-bot/dashboard",
    { params: { audit_limit } },
  );
  return data;
}

/** Download a generated PDF report. Triggers a browser save dialog.
 * Uses fetch directly so we can attach the JWT and stream the blob. */
export async function downloadPortfolioBotReport(filename: string): Promise<void> {
  const token = getToken() ?? "";
  const resp = await fetch(
    `/api/portfolio-bot/reports/${encodeURIComponent(filename)}`,
    { headers: token ? { Authorization: `Bearer ${token}` } : {} },
  );
  if (!resp.ok) {
    throw new Error(`Download failed: ${resp.status} ${resp.statusText}`);
  }
  const blob = await resp.blob();
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}
