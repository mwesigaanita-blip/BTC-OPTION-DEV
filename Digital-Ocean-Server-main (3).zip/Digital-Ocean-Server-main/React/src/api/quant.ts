import { api } from "./client";
import type {
  CryptoVolumeResponse,
  QuantCorrelationResponse,
  QuantRelativeResponse,
  QuantReturnsResponse,
  QuantRollingCorrelationsResponse,
  QuantSnapshot,
} from "@/types/api";

const DEFAULT_ASSETS = "BTC,ETH,SOL,AVAX,ZEC,MSTR,MARA,RIOT,COIN";
const DEFAULT_BENCHMARKS = "SPX,GOLD,DXY";

export async function fetchQuantSnapshot(): Promise<QuantSnapshot> {
  const { data } = await api.get<QuantSnapshot>("/api/quant/snapshot");
  return data;
}

export async function fetchQuantReturns(
  assets: string = DEFAULT_ASSETS,
): Promise<QuantReturnsResponse> {
  const { data } = await api.get<QuantReturnsResponse>("/api/quant/returns", {
    params: { assets },
  });
  return data;
}

export async function fetchQuantRelative(
  base: string = "BTC",
  vs: string = DEFAULT_BENCHMARKS,
): Promise<QuantRelativeResponse> {
  const { data } = await api.get<QuantRelativeResponse>("/api/quant/relative", {
    params: { base, vs },
  });
  return data;
}

export async function fetchQuantVsBtc(
  assets: string = DEFAULT_ASSETS,
): Promise<QuantRelativeResponse> {
  const { data } = await api.get<QuantRelativeResponse>("/api/quant/vs-btc", {
    params: { assets },
  });
  return data;
}

export async function fetchQuantCorrelations(
  assets?: string,
  windows?: string,
): Promise<QuantCorrelationResponse> {
  const params: Record<string, string> = {};
  if (assets) params.assets = assets;
  if (windows) params.windows = windows;
  const { data } = await api.get<QuantCorrelationResponse>(
    "/api/quant/correlations",
    { params },
  );
  return data;
}

export async function fetchQuantRollingCorrelations(
  partners?: string,
  window?: number,
  historyDays?: number,
): Promise<QuantRollingCorrelationsResponse> {
  const params: Record<string, string | number> = {};
  if (partners) params.partners = partners;
  if (window) params.window = window;
  if (historyDays) params.history_days = historyDays;
  const { data } = await api.get<QuantRollingCorrelationsResponse>(
    "/api/quant/btc-rolling-correlations",
    { params },
  );
  return data;
}

export async function fetchCryptoVolume(
  assets?: string,
): Promise<CryptoVolumeResponse> {
  const params: Record<string, string> = {};
  if (assets) params.assets = assets;
  const { data } = await api.get<CryptoVolumeResponse>(
    "/api/quant/crypto-volume",
    { params },
  );
  return data;
}

/** Manual full rebuild of the Daily Quant SQLite tables. Blocking, 10-30s. */
export async function triggerQuantRefresh(): Promise<unknown> {
  const { data } = await api.post("/api/quant/refresh");
  return data;
}
