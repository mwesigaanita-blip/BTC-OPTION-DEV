import { api } from "./client";

export interface LlmRun {
  id: number;
  model_label: string | null;
  provider: string | null;
  model_id: string | null;
  run_time_utc: string | null;
  run_time_cairo: string | null;
  total_cost_usd: number;
  created_at: string | null;
  [k: string]: unknown;
}

export interface LlmSummary {
  total_cost_usd: number;
  n_runs: number;
  avg_cost_usd: number;
  last_7_days_usd: number;
  last_30_days_usd: number;
}

export interface DailyPoint {
  day: string;
  cost: number;
}

export interface BreakdownItem {
  model_label?: string;
  provider?: string;
  cost: number;
}

export interface LlmFeesResponse {
  rows: LlmRun[];
  total_rows: number;
  summary: LlmSummary;
  daily: DailyPoint[];
  daily_by_model: Array<Record<string, unknown>>;
  by_model: BreakdownItem[];
  by_provider: BreakdownItem[];
  filter_options: {
    providers: string[];
    model_labels: string[];
  };
}

export interface LlmFeesParams {
  start_date?: string;
  end_date?: string;
  provider?: string;
  model_label?: string;
  include_zero?: boolean;
}

export async function fetchLlmFees(params: LlmFeesParams): Promise<LlmFeesResponse> {
  const { data } = await api.get<LlmFeesResponse>("/api/llm-fees/runs", {
    params: {
      ...params,
      provider: params.provider || undefined,
      model_label: params.model_label || undefined,
    },
  });
  return data;
}
