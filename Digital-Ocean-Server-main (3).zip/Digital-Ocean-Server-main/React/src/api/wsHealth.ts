import { api } from "./client";

export interface CollectorHealth {
  last_msg_age_s?: number | null;
  reconnects?: number;
  redis_ok?: boolean;
  uptime_s?: number;
  current_downtime_s?: number | null;
  last_downtime_s?: number | null;
  longest_downtime_s?: number | null;
  total_downtime_s?: number | null;
  [k: string]: unknown;
}

export interface CollectorSummary {
  active_subscriptions: number;
  connection_state: "up" | "down" | string;
  sqlite_writes_total: number;
  aggregator_writes_total: number;
  crash_loop_active: boolean;
  reconnects_window_count: number;
  watchdog_force_reconnects_total: number;
}

export interface ChannelAgeRow {
  channel: string;
  age_s: number;
  stale: boolean;
}

export interface MessageRow {
  channel: string;
  count: number;
}

export interface SubscriberRow {
  topic: string;
  subscribers: number;
}

export interface CollectorBlock {
  url: string;
  health: CollectorHealth | null;
  health_error: string | null;
  metrics_text: string | null;
  metrics_error: string | null;
  summary: CollectorSummary | null;
  channels_age: ChannelAgeRow[];
  messages: MessageRow[];
  subscribers: SubscriberRow[];
}

export interface BackendWsHealth {
  redis?: string;
  ws_clients?: number;
  fanout_subs?: Record<string, number>;
  redis_sub?: Record<string, Record<string, number>>;
  [k: string]: unknown;
}

export interface BackendWsSummary {
  fanout_messages_total: number;
  fanout_drops_total: number;
  redis_ping_failures_total: number;
}

export interface FanoutRow {
  topic: string;
  clients: number;
}

export interface RedisSubRow {
  topic: string;
  current_s: number;
  last_s: number;
  longest_s: number;
  total_s: number;
}

export interface BackendWsBlock {
  url: string;
  health: BackendWsHealth | null;
  health_error: string | null;
  metrics_text: string | null;
  metrics_error: string | null;
  summary: BackendWsSummary | null;
  fanout: FanoutRow[];
  redis_sub: RedisSubRow[];
}

export interface WsHealthResponse {
  staleness_threshold_s: number;
  collector: CollectorBlock;
  backend_ws: BackendWsBlock;
}

export async function fetchWsHealth(): Promise<WsHealthResponse> {
  const { data } = await api.get<WsHealthResponse>("/api/ws-health");
  return data;
}
