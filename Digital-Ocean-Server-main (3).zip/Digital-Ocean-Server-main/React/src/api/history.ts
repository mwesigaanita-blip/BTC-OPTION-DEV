import { api } from "./client";
import type {
  DayPositionsResponse,
  PortfolioHistoryResponse,
} from "@/types/api";

export async function fetchPortfolioHistory(): Promise<PortfolioHistoryResponse> {
  const { data } = await api.get<PortfolioHistoryResponse>(
    "/api/history/positions/portfolio",
  );
  return data;
}

export async function fetchDayPositions(
  day: string,
): Promise<DayPositionsResponse> {
  const { data } = await api.get<DayPositionsResponse>(
    `/api/history/positions/day/${encodeURIComponent(day)}`,
  );
  return data;
}
