import axios from "axios";

const TOKEN_KEY = "btc_dash_token";

export function getToken(): string | null {
  return localStorage.getItem(TOKEN_KEY);
}

export function setToken(token: string | null): void {
  if (token) localStorage.setItem(TOKEN_KEY, token);
  else localStorage.removeItem(TOKEN_KEY);
}

/**
 * Axios instance. Base URL is empty by default so requests hit `/api/*` on the
 * same origin - the Vite dev proxy and the prod nginx config both forward it
 * to `backend_api`.
 */
export const api = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL ?? "",
});

api.interceptors.request.use((cfg) => {
  const token = getToken();
  if (token) cfg.headers.Authorization = `Bearer ${token}`;
  return cfg;
});

api.interceptors.response.use(
  (res) => res,
  (err) => {
    if (err?.response?.status === 401) {
      setToken(null);
      // AuthContext listens for this and redirects to /login.
      window.dispatchEvent(new Event("auth:logout"));
    }
    return Promise.reject(err);
  },
);

/** Build a WebSocket URL for a backend_ws topic, carrying the JWT. */
export function wsUrl(path: string): string {
  const base = import.meta.env.VITE_WS_BASE_URL;
  const origin = base
    ? base
    : `${location.protocol === "https:" ? "wss:" : "ws:"}//${location.host}`;
  const token = getToken() ?? "";
  return `${origin}${path}?token=${encodeURIComponent(token)}`;
}
