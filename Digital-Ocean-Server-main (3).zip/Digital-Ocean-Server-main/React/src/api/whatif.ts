import { api } from "./client";
import type { WhatIfResponse } from "@/types/api";

export interface HypotheticalSpec {
  instrument_name: string; // Deribit name e.g. "BTC-29MAY26-65000-C"
  side: "buy" | "sell";
  size: number;
}

export interface PositionOverride {
  instrument_name: string;
  size: number; // absolute contracts
  side: "buy" | "sell";
}

export interface WhatIfRequest {
  range_pct: number;
  points?: number;
  /** Multiplicative IV shift in % (-95...+500). Replaces the old additive
   * vol-points field; new_sigma = old_sigma * (1 + iv_pct_shift/100). */
  iv_pct_shift: number;
  /** Days forward; fractional so the timeline can land precisely on per-leg
   * expiries (where the dynamic curve collapses to the static one). */
  days_forward: number;
  annual_rate_shift_bps: number;
  spot_override?: number | null;
  overrides: PositionOverride[];
  hypotheticals: HypotheticalSpec[];
}

export async function fetchWhatIf(req: WhatIfRequest): Promise<WhatIfResponse> {
  const { data } = await api.post<WhatIfResponse>("/api/stress/whatif", req);
  return data;
}
