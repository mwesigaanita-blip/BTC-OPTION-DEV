import { api } from "./client";

export interface HedgeConfig {
  is_enabled: boolean;
  poll_interval_secs: number;
  mm_safe_below: number;
  mm_light_below: number;
  mm_medium_below: number;
  mm_aggressive_below: number;
  mm_bypass_cooldown: number;
  hedge_pct_of_equity: number;
  delta_hedge_ratio: number;
  min_trade_btc: number;
  max_single_trade_btc: number;
  delta_deadband_btc: number;
  cooldown_secs: number;
  cooldown_fast_secs: number;
  max_btc_per_5min: number;
  speed_warn_30s: number;
  speed_danger_30s: number;
  speed_warn_60s: number;
  speed_danger_60s: number;
  updated_at: string;
  [k: string]: unknown;
}

export type HedgeConfigPatch = Partial<HedgeConfig>;

export interface AccountState {
  mm_percent: number;
  net_delta: number;
  equity_usd: number;
  margin_balance: number;
  maintenance_margin: number;
  btc_price: number;
  bucket: string;
}

export interface HedgeLogRow {
  id?: number;
  executed_at: string;
  direction: string;
  size_btc: number;
  mm_before: number | null;
  mm_after: number | null;
  mm_bucket: string | null;
  net_delta: number | null;
  speed_30s: number | null;
  speed_60s: number | null;
  order_id: string | null;
  avg_price: number | null;
  error: string | null;
}

export interface HedgeLogsResponse {
  logs: HedgeLogRow[];
  summary: {
    total: number;
    errors: number;
    successful: number;
    sells: number;
    buys: number;
    total_btc: number;
  };
}

export async function fetchHedgeConfig(): Promise<HedgeConfig> {
  const { data } = await api.get<HedgeConfig>("/api/hedge/config");
  return data;
}

export async function patchHedgeConfig(
  patch: HedgeConfigPatch,
): Promise<HedgeConfig> {
  const { data } = await api.patch<HedgeConfig>("/api/hedge/config", patch);
  return data;
}

export async function toggleHedge(enabled: boolean): Promise<HedgeConfig> {
  const { data } = await api.post<HedgeConfig>("/api/hedge/toggle", { enabled });
  return data;
}

export async function fetchHedgeAccountState(): Promise<AccountState> {
  const { data } = await api.post<AccountState>("/api/hedge/account-state");
  return data;
}

export async function fetchHedgeLogs(limit = 25): Promise<HedgeLogsResponse> {
  const { data } = await api.get<HedgeLogsResponse>("/api/hedge/logs", {
    params: { limit },
  });
  return data;
}
