import { api } from "./client";

export interface PipelineState {
  last_run_at?: string | null;
  last_completed_date?: string | null;
  instruments_fetched?: number;
  rows_written?: number;
  gaps?: unknown[];
  [k: string]: unknown;
}

export interface PipelineConfig {
  enabled: string;
  interval_seconds: string;
  base_dir: string;
}

export interface SchedulerState {
  now_utc: string;
  today_utc: string;
  snapshot: { state: PipelineState; config: PipelineConfig };
  ohlcv: { state: PipelineState; config: PipelineConfig };
}

export interface SnapshotTodayResponse {
  date: string;
  rows: number;
}

export interface SnapshotLatestResponse {
  rows: Record<string, unknown>[];
  total: number;
  columns: string[];
}

export interface OhlcvForDateResponse {
  date: string;
  available: boolean;
  rows: Record<string, unknown>[];
  total: number;
  filtered?: number;
  columns: string[];
  instruments: string[];
  first_ts: string | null;
  last_ts: string | null;
}

export interface SnapshotRunResponse {
  ok: boolean;
  instruments_total: number;
  rows_written: number;
  duration_seconds: number;
  files_written: Record<string, number>;
}

export async function fetchSchedulerState(): Promise<SchedulerState> {
  const { data } = await api.get<SchedulerState>("/api/options-scheduler/state");
  return data;
}

export async function fetchSnapshotToday(): Promise<SnapshotTodayResponse> {
  const { data } = await api.get<SnapshotTodayResponse>(
    "/api/options-scheduler/snapshot/today",
  );
  return data;
}

export async function fetchSnapshotLatest(limit = 20): Promise<SnapshotLatestResponse> {
  const { data } = await api.get<SnapshotLatestResponse>(
    "/api/options-scheduler/snapshot/latest",
    { params: { limit } },
  );
  return data;
}

export async function fetchOhlcv(
  day: string,
  instrument?: string,
  limit = 50,
): Promise<OhlcvForDateResponse> {
  const params: Record<string, unknown> = { limit };
  if (instrument && instrument !== "All") params.instrument = instrument;
  const { data } = await api.get<OhlcvForDateResponse>(
    `/api/options-scheduler/ohlcv/${encodeURIComponent(day)}`,
    { params },
  );
  return data;
}

export async function runSnapshotNow(): Promise<SnapshotRunResponse> {
  const { data } = await api.post<SnapshotRunResponse>(
    "/api/options-scheduler/snapshot/run",
  );
  return data;
}
