import { api } from "./client";

export interface AppUser {
  id: number;
  username: string;
  role: "operator" | "viewer";
  pages: string[];
  is_active: number;
  created_at: string | null;
  last_login: string | null;
}

export interface UsersResponse {
  users: AppUser[];
  all_pages: string[];
  roles: string[];
}

export interface CreateUserPayload {
  username: string;
  password: string;
  role: string;
  pages: string[];
}

export interface UpdateUserPayload {
  role: string;
  pages: string[];
  is_active: boolean;
  new_password?: string;
}

export async function fetchUsers(): Promise<UsersResponse> {
  const { data } = await api.get<UsersResponse>("/api/users");
  return data;
}

export async function createUser(payload: CreateUserPayload): Promise<{ ok: boolean }> {
  const { data } = await api.post<{ ok: boolean }>("/api/users", payload);
  return data;
}

export async function updateUser(
  userId: number,
  payload: UpdateUserPayload,
): Promise<{ ok: boolean }> {
  const { data } = await api.patch<{ ok: boolean }>(`/api/users/${userId}`, payload);
  return data;
}
