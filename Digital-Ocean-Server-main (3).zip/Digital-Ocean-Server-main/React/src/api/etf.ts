import { api } from "./client";
import type { EtfFlowsResponse } from "@/types/api";

export async function fetchEtfFlows(
  days: number = 10,
  historyDays: number = 180,
): Promise<EtfFlowsResponse> {
  const { data } = await api.get<EtfFlowsResponse>("/api/etf/flows", {
    params: { days, history_days: historyDays },
  });
  return data;
}

/** Manual rebuild (also re-runs the Daily Quant refresh — shared job). */
export async function triggerEtfRefresh(): Promise<unknown> {
  const { data } = await api.post("/api/etf/refresh");
  return data;
}
