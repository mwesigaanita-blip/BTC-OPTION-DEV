import { api } from "./client";

export interface FeeEvent {
  id: number;
  source: string;
  trade_id: string | null;
  order_id: string | null;
  instrument_name: string | null;
  side: string | null;
  fee_currency: string | null;
  fee_amount: number;
  price: number | null;
  amount: number | null;
  timestamp_ms: number;
  fee_usd: number | null;
  index_price_usd: number | null;
  notified_telegram: number;
  time_utc: string | null;
}

export interface FeesSummary {
  total_fee_by_ccy: Record<string, number>;
  total_usd: number | null;
}

export interface FeesResponse {
  rows: FeeEvent[];
  total_rows: number;
  summary: FeesSummary;
}

export interface SyncResult {
  enabled?: boolean;
  fetched_trades?: number;
  fee_rows?: number;
  inserted?: number;
  notified?: number;
}

export async function fetchFeeEvents(params: {
  days_back?: number;
  limit?: number;
  only_unnotified?: boolean;
}): Promise<FeesResponse> {
  const { data } = await api.get<FeesResponse>("/api/trading-fees/events", {
    params,
  });
  return data;
}

export async function syncFees(): Promise<SyncResult> {
  const { data } = await api.post<SyncResult>("/api/trading-fees/sync");
  return data;
}
