import { api } from "./client";

export interface SimPosition {
  currency: string;
  instrument_name: string;
  kind: string;
  direction: string;
  size: number;
  mark_price?: number;
  index_price?: number;
  // Option-specific metadata used by the front-end BS recalculation. The
  // backend best-efforts these from the live position payload + parsed
  // instrument name. None of them are present for futures/perps.
  option_type?: "call" | "put" | null;
  strike?: number | null;
  expiration_timestamp?: number | null; // ms since epoch (UTC 08:00 settle)
  mark_iv?: number | null;              // vol points (e.g. 65.4)
  delta?: number;
  gamma?: number;
  vega?: number;
  theta?: number;
  [k: string]: unknown;
}

export interface ChainExpiry {
  expiration_timestamp: number;
  strikes: number[];
}

export interface OptionChain {
  expiries: ChainExpiry[];
  [k: string]: unknown;
}

export interface PositionsAndChain {
  positions: SimPosition[];
  option_chain: OptionChain;
}

export interface InstrumentQuote {
  instrument_name?: string;
  bid_price?: number | null;
  ask_price?: number | null;
  mark_price?: number | null;
  index_price?: number | null;
  mark_iv?: number | null;
  [k: string]: unknown;
}

export type AdjustmentAction = "no change" | "decrease" | "increase";

export interface Adjustment {
  instrument_name: string;
  action: AdjustmentAction;
  amount: number;
}

export type NewTradeSide = "long" | "short";

export interface NewTrade {
  instrument_name: string;
  side: NewTradeSide;
  amount: number;
  /** When set, overrides the live-quote pricing in the backend so the
   * simulation uses this exact entry price (in BTC, the Deribit native unit
   * for BTC options). */
  entry_price?: number | null;
}

export interface PriceOptionResult {
  spot: number;
  t_years: number;
  iv_decimal: number;
  iv_pct: number;
  usd_price: number;
  btc_price: number;
}

export interface CurrencyResult {
  before?: {
    im_pct?: number | null;
    mm_pct?: number | null;
    delta?: number | null;
    [k: string]: unknown;
  };
  after?: {
    im_pct?: number | null;
    mm_pct?: number | null;
    delta?: number | null;
    [k: string]: unknown;
  };
  change?: {
    im_pct?: number | null;
    mm_pct?: number | null;
    delta?: number | null;
    [k: string]: unknown;
  };
  current_positions?: SimPosition[];
  simulated_positions?: SimPosition[];
  raw_before?: Record<string, unknown>;
  raw_after?: Record<string, unknown>;
  [k: string]: unknown;
}

export interface PricedNewTrade extends NewTrade {
  entry_price?: number | null;
  [k: string]: unknown;
}

export interface SimulationResult {
  ok: boolean;
  errors: string[];
  current_positions: SimPosition[];
  simulated_positions: SimPosition[];
  priced_new_trades?: PricedNewTrade[];
  results_by_currency: Record<string, CurrencyResult>;
  [k: string]: unknown;
}

export async function fetchPositionsAndChain(): Promise<PositionsAndChain> {
  const { data } = await api.get<PositionsAndChain>("/api/mm-im/positions");
  return data;
}

export async function fetchQuote(instrument_name: string): Promise<InstrumentQuote> {
  const { data } = await api.get<InstrumentQuote>(
    `/api/mm-im/quote/${encodeURIComponent(instrument_name)}`,
  );
  return data;
}

export async function findOption(
  expiration_timestamp: number,
  strike: number,
  option_type: "call" | "put",
): Promise<string | null> {
  const { data } = await api.post<{ instrument_name: string | null }>(
    "/api/mm-im/find-option",
    { expiration_timestamp, strike, option_type },
  );
  return data.instrument_name ?? null;
}

export async function priceOption(
  expiration_timestamp: number,
  strike: number,
  option_type: "call" | "put",
  iv_pct: number,
): Promise<PriceOptionResult> {
  const { data } = await api.post<PriceOptionResult>("/api/mm-im/price-option", {
    expiration_timestamp,
    strike,
    option_type,
    iv_pct,
  });
  return data;
}

export async function runSimulation(
  adjustments: Adjustment[],
  new_trades: NewTrade[],
): Promise<SimulationResult> {
  const { data } = await api.post<SimulationResult>("/api/mm-im/simulate", {
    adjustments,
    new_trades,
  });
  return data;
}
