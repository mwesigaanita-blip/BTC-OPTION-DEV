import { api } from "./client";
import type {
  BtcPricesSeriesResponse,
  BtcPricesSummary,
} from "@/types/api";

export async function fetchBtcPricesSummary(): Promise<BtcPricesSummary> {
  const { data } = await api.get<BtcPricesSummary>("/api/btc-prices/summary");
  return data;
}

export async function fetchBtcPricesSeries(
  from?: string,
  to?: string,
): Promise<BtcPricesSeriesResponse> {
  const params: Record<string, string> = {};
  if (from) params.from = from;
  if (to) params.to = to;
  const { data } = await api.get<BtcPricesSeriesResponse>(
    "/api/btc-prices/series",
    { params },
  );
  return data;
}

/** Trigger the full-history CSV download via the auth'd API. */
export async function downloadBtcPricesCsv(): Promise<void> {
  const res = await api.get("/api/btc-prices/export.csv", {
    responseType: "blob",
  });
  const url = URL.createObjectURL(res.data as Blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "btc_prices_full.csv";
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}
