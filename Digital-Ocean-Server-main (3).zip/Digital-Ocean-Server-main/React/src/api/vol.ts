import { api } from "./client";
import type { HvIvResponse, VolDashboardResponse } from "@/types/vol";

export async function fetchHvIvSeries(
  days: number,
  resolution: "1D" | "1H",
): Promise<HvIvResponse> {
  const { data } = await api.get<HvIvResponse>("/api/vol/hv-iv", {
    params: { days, resolution },
  });
  return data;
}

export async function fetchVolDashboard(
  lookbackDays: number = 365,
): Promise<VolDashboardResponse> {
  const { data } = await api.get<VolDashboardResponse>("/api/vol/dashboard", {
    params: { lookback_days: lookbackDays },
  });
  return data;
}
