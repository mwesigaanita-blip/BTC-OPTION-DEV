import { useQuery } from "@tanstack/react-query";
import { fetchVolDashboard } from "@/api/vol";

const STALE_MS = 5 * 60_000;

export function useVolDashboard(lookbackDays: number = 365) {
  return useQuery({
    queryKey: ["vol", "dashboard", lookbackDays],
    queryFn: () => fetchVolDashboard(lookbackDays),
    staleTime: STALE_MS,
    refetchOnWindowFocus: false,
    retry: false,
  });
}
