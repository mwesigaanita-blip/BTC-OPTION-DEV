import { useQuery } from "@tanstack/react-query";
import { fetchEtfFlows } from "@/api/etf";

const STALE_MS = 5 * 60_000;

export function useEtfFlows(days: number = 10, historyDays: number = 180) {
  return useQuery({
    queryKey: ["etf", "flows", days, historyDays],
    queryFn: () => fetchEtfFlows(days, historyDays),
    staleTime: STALE_MS,
    refetchOnWindowFocus: false,
    retry: false,
  });
}
