import { useEffect, useRef, useState } from "react";
import { wsUrl } from "@/api/client";

export type WsStatus = "connecting" | "open" | "closed";

/**
 * Subscribe to a backend_ws topic. Reconnects with exponential backoff.
 * `onMessage` receives the parsed JSON payload (or the raw string if not JSON).
 */
export function useWebSocket(
  path: string,
  onMessage?: (data: unknown) => void,
): WsStatus {
  const [status, setStatus] = useState<WsStatus>("connecting");
  const onMessageRef = useRef(onMessage);
  onMessageRef.current = onMessage;

  useEffect(() => {
    let ws: WebSocket | null = null;
    let disposed = false;
    let attempt = 0;
    let timer: number | undefined;

    const connect = () => {
      setStatus("connecting");
      ws = new WebSocket(wsUrl(path));

      ws.onopen = () => {
        attempt = 0;
        setStatus("open");
      };
      ws.onmessage = (ev) => {
        let parsed: unknown = ev.data;
        try {
          parsed = JSON.parse(ev.data);
        } catch {
          /* keep raw */
        }
        onMessageRef.current?.(parsed);
      };
      ws.onclose = () => {
        setStatus("closed");
        if (disposed) return;
        attempt += 1;
        const delay = Math.min(1000 * 2 ** attempt, 15000);
        timer = window.setTimeout(connect, delay);
      };
      ws.onerror = () => ws?.close();
    };

    connect();
    return () => {
      disposed = true;
      if (timer) window.clearTimeout(timer);
      ws?.close();
    };
  }, [path]);

  return status;
}
