import { useQuery } from "@tanstack/react-query";
import {
  fetchCryptoVolume,
  fetchQuantCorrelations,
  fetchQuantRelative,
  fetchQuantReturns,
  fetchQuantRollingCorrelations,
  fetchQuantSnapshot,
  fetchQuantVsBtc,
} from "@/api/quant";

const STALE_MS = 5 * 60_000;

export function useQuantSnapshot() {
  return useQuery({
    queryKey: ["quant", "snapshot"],
    queryFn: fetchQuantSnapshot,
    staleTime: STALE_MS,
    refetchOnWindowFocus: false,
    retry: false,
  });
}

export function useQuantReturns(assets?: string) {
  return useQuery({
    queryKey: ["quant", "returns", assets ?? "default"],
    queryFn: () => fetchQuantReturns(assets),
    staleTime: STALE_MS,
    refetchOnWindowFocus: false,
    retry: false,
  });
}

export function useQuantRelative(base = "BTC", vs?: string) {
  return useQuery({
    queryKey: ["quant", "relative", base, vs ?? "default"],
    queryFn: () => fetchQuantRelative(base, vs),
    staleTime: STALE_MS,
    refetchOnWindowFocus: false,
    retry: false,
  });
}

export function useQuantCorrelations(assets?: string, windows?: string) {
  return useQuery({
    queryKey: ["quant", "correlations", assets ?? "default", windows ?? "default"],
    queryFn: () => fetchQuantCorrelations(assets, windows),
    staleTime: STALE_MS,
    refetchOnWindowFocus: false,
    retry: false,
  });
}

export function useQuantRollingCorrelations(
  partners?: string,
  window?: number,
  historyDays?: number,
) {
  return useQuery({
    queryKey: [
      "quant", "rolling-correlations",
      partners ?? "default",
      window ?? "default",
      historyDays ?? "default",
    ],
    queryFn: () => fetchQuantRollingCorrelations(partners, window, historyDays),
    staleTime: STALE_MS,
    refetchOnWindowFocus: false,
    retry: false,
  });
}

export function useCryptoVolume(assets?: string) {
  return useQuery({
    queryKey: ["quant", "crypto-volume", assets ?? "default"],
    queryFn: () => fetchCryptoVolume(assets),
    staleTime: STALE_MS,
    refetchOnWindowFocus: false,
    retry: false,
  });
}

export function useQuantVsBtc(assets?: string) {
  return useQuery({
    queryKey: ["quant", "vs-btc", assets ?? "default"],
    queryFn: () => fetchQuantVsBtc(assets),
    staleTime: STALE_MS,
    refetchOnWindowFocus: false,
    retry: false,
  });
}
