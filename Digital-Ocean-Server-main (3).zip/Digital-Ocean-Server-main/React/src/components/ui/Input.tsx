import { forwardRef, type InputHTMLAttributes } from "react";
import { cn } from "@/lib/utils";

export const Input = forwardRef<
  HTMLInputElement,
  InputHTMLAttributes<HTMLInputElement>
>(({ className, ...props }, ref) => (
  <input
    ref={ref}
    className={cn(
      "h-11 w-full rounded-lg border border-border bg-surface-2 px-3.5 text-sm",
      "text-fg placeholder:text-muted",
      "transition-colors focus:outline-none focus:ring-2 focus:ring-brand",
      "focus:border-brand disabled:opacity-50",
      className,
    )}
    {...props}
  />
));
Input.displayName = "Input";
