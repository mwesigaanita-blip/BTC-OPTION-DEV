import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

type Tone = "neutral" | "positive" | "negative" | "warning" | "brand";

const tones: Record<Tone, string> = {
  neutral: "bg-surface-2 text-muted border-border",
  positive: "bg-positive/15 text-positive border-positive/30",
  negative: "bg-negative/15 text-negative border-negative/30",
  warning: "bg-warning/15 text-warning border-warning/30",
  brand: "bg-brand/15 text-brand border-brand/30",
};

export function Badge({
  children,
  tone = "neutral",
  className,
}: {
  children: ReactNode;
  tone?: Tone;
  className?: string;
}) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-0.5",
        "text-xs font-medium",
        tones[tone],
        className,
      )}
    >
      {children}
    </span>
  );
}
