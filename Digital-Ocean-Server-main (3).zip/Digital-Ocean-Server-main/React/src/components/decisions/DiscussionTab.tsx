import { useState } from "react";
import { ChevronDown, Lock, Pencil, Trash2 } from "lucide-react";
import type { DecisionComment } from "@/api/decisions";
import {
  addComment,
  deleteComment,
  listComments,
  updateComment,
} from "@/api/decisions";
import { Button } from "@/components/ui/Button";
import { formatRelativeTime } from "./styles";

export function DiscussionTab({
  decisionId,
  initialComments,
  initialTotal,
  isLocked,
  onChanged,
}: {
  decisionId: number;
  initialComments: DecisionComment[];
  initialTotal: number;
  isLocked: boolean;
  onChanged: () => void;
}) {
  const [comments, setComments] = useState<DecisionComment[]>(initialComments);
  const [total, setTotal] = useState<number>(initialTotal);
  const [newText, setNewText] = useState("");
  const [editingId, setEditingId] = useState<number | null>(null);
  const [editText, setEditText] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  async function refresh(limit: number) {
    const data = await listComments(decisionId, limit, 0);
    setComments(data.comments);
    setTotal(data.total);
  }

  async function handlePost() {
    if (!newText.trim()) return;
    setBusy(true);
    setErr(null);
    try {
      await addComment(decisionId, newText.trim());
      setNewText("");
      await refresh(Math.max(comments.length + 1, 20));
      onChanged();
    } catch (e: any) {
      setErr(e?.response?.data?.detail ?? String(e));
    } finally {
      setBusy(false);
    }
  }

  async function handleSaveEdit(id: number) {
    if (!editText.trim()) return;
    setBusy(true);
    setErr(null);
    try {
      await updateComment(id, editText.trim());
      setEditingId(null);
      await refresh(comments.length);
    } catch (e: any) {
      setErr(e?.response?.data?.detail ?? String(e));
    } finally {
      setBusy(false);
    }
  }

  async function handleDelete(id: number) {
    if (!confirm("Delete this comment? This can't be undone from the UI.")) return;
    setBusy(true);
    try {
      await deleteComment(id);
      await refresh(comments.length);
      onChanged();
    } catch (e: any) {
      setErr(e?.response?.data?.detail ?? String(e));
    } finally {
      setBusy(false);
    }
  }

  async function loadMore() {
    await refresh(comments.length + 20);
  }

  return (
    <div className="space-y-3">
      {err ? <div className="text-xs text-negative">{err}</div> : null}

      {comments.length === 0 ? (
        <div className="rounded-lg border border-border bg-surface-2/30 py-10 text-center text-sm text-muted">
          💬 No comments yet. Start the discussion!
        </div>
      ) : (
        comments.map((c) => (
          <div key={c.id} className="rounded-xl bg-surface-2/60 p-3">
            <div className="flex items-center gap-2 text-xs">
              <span className="font-semibold text-brand">{c.author}</span>
              <span className="text-muted">
                {formatRelativeTime(c.created_at_utc)}
                {c.edited_at_utc ? " (edited)" : ""}
              </span>
            </div>
            {editingId === c.id ? (
              <div className="mt-2 space-y-2">
                <textarea
                  className="h-24 w-full resize-y rounded-md border border-border bg-surface-2 px-2 py-1.5 text-sm"
                  value={editText}
                  onChange={(e) => setEditText(e.target.value)}
                />
                <div className="flex gap-2">
                  <Button
                    size="sm"
                    onClick={() => handleSaveEdit(c.id)}
                    disabled={busy}
                  >
                    Save
                  </Button>
                  <Button size="sm" variant="secondary" onClick={() => setEditingId(null)}>
                    Cancel
                  </Button>
                </div>
              </div>
            ) : (
              <div className="mt-1.5 whitespace-pre-wrap text-sm text-fg">
                {c.comment_text}
              </div>
            )}

            {!isLocked && editingId !== c.id ? (
              <div className="mt-2 flex gap-2">
                <Button
                  size="sm"
                  variant="secondary"
                  onClick={() => {
                    setEditingId(c.id);
                    setEditText(c.comment_text);
                  }}
                >
                  <Pencil className="h-3 w-3" /> Edit
                </Button>
                <Button size="sm" variant="danger" onClick={() => handleDelete(c.id)}>
                  <Trash2 className="h-3 w-3" /> Delete
                </Button>
              </div>
            ) : null}
          </div>
        ))
      )}

      {comments.length < total ? (
        <Button variant="secondary" onClick={loadMore} className="w-full">
          <ChevronDown className="h-3.5 w-3.5" />
          Load more comments ({total - comments.length} remaining)
        </Button>
      ) : null}

      {isLocked ? (
        <div className="flex items-center gap-1.5 text-xs text-muted">
          <Lock className="h-3 w-3" /> This decision is finalized. Comments are locked.
        </div>
      ) : (
        <div className="space-y-2 rounded-lg border border-border bg-surface-2/30 p-3">
          <textarea
            className="h-20 w-full resize-y rounded-md border border-border bg-surface-2 px-2 py-1.5 text-sm"
            placeholder="Share your thoughts..."
            value={newText}
            onChange={(e) => setNewText(e.target.value)}
          />
          <Button onClick={handlePost} disabled={busy || !newText.trim()} className="w-full">
            💬 Post Comment
          </Button>
        </div>
      )}
    </div>
  );
}
