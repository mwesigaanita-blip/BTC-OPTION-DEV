import { Lock, MessageCircle, User, Zap } from "lucide-react";
import type { Decision } from "@/api/decisions";
import { Card } from "@/components/ui/Card";
import { OutcomeBadge, PriorityBadge } from "./Badges";
import { formatRelativeTime, truncate } from "./styles";

export function DecisionCard({
  decision,
  actionsCount,
  commentsCount,
  onOpen,
}: {
  decision: Decision;
  actionsCount: number;
  commentsCount: number;
  onOpen: () => void;
}) {
  const locked = decision.locked_flag === 1;
  const createdDate = (decision.created_at_utc ?? "").slice(0, 10);
  const updatedRaw = decision.updated_at_utc ?? decision.created_at_utc ?? "";
  const updatedDisplay = updatedRaw
    ? updatedRaw.slice(0, 16).replace("T", " ") + " UTC"
    : "";

  return (
    <Card className="p-4 hover:bg-surface-2/40 transition-colors">
      <div className="flex flex-wrap items-center gap-1.5">
        <PriorityBadge priority={decision.priority} />
        {locked && decision.final_outcome ? (
          <OutcomeBadge outcome={decision.final_outcome} />
        ) : null}
        {locked ? (
          <span className="inline-flex items-center gap-1 text-[0.7rem] text-muted">
            <Lock className="h-3 w-3" /> Locked
          </span>
        ) : null}
      </div>

      <div className="mt-2 text-sm font-bold leading-tight text-fg">
        {decision.title}
      </div>
      {decision.description ? (
        <div className="mt-1.5 text-xs text-muted leading-relaxed">
          {truncate(decision.description, 100)}
        </div>
      ) : null}

      <div className="mt-2 flex flex-wrap items-center gap-x-2 gap-y-1 text-[0.7rem] text-muted">
        <span className="inline-flex items-center gap-1">
          <User className="h-3 w-3" /> {decision.created_by}
        </span>
        <span>·</span>
        <span className="inline-flex items-center gap-1">
          <MessageCircle className="h-3 w-3" /> {commentsCount}
        </span>
        <span>·</span>
        <span className="inline-flex items-center gap-1">
          <Zap className="h-3 w-3" /> {actionsCount} actions
        </span>
        <span>·</span>
        <span>{formatRelativeTime(decision.created_at_utc)}</span>
      </div>

      {(createdDate || updatedDisplay) ? (
        <div className="mt-1 text-[0.7rem] text-muted">
          {createdDate ? `Created: ${createdDate}` : ""}
          {createdDate && updatedDisplay ? "  ·  " : ""}
          {updatedDisplay ? `Updated: ${updatedDisplay}` : ""}
        </div>
      ) : null}

      <button
        type="button"
        onClick={onOpen}
        className="mt-3 w-full rounded-md border border-border bg-surface-2 px-3 py-1.5 text-xs font-semibold text-fg hover:bg-surface"
      >
        Open
      </button>
    </Card>
  );
}
