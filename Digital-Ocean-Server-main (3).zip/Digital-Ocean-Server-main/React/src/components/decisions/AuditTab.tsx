import type { DecisionEvent } from "@/api/decisions";
import { formatRelativeTime } from "./styles";

const LABELS: Record<string, [string, string]> = {
  create_decision: ["🆕", "Created"],
  edit_decision: ["✏️", "Edited"],
  delete_decision: ["🗑️", "Deleted"],
  move_status: ["➡️", "Moved"],
  finalize_decision: ["✅", "Finalized"],
  add_action: ["⚡", "Action added"],
  edit_action: ["✏️", "Action edited"],
  delete_action: ["🗑️", "Action deleted"],
  add_comment: ["💬", "Comment added"],
  edit_comment: ["✏️", "Comment edited"],
  delete_comment: ["🗑️", "Comment deleted"],
  reopen_attempt_rejected: ["🚫", "Reopen rejected"],
};

function payloadHint(ev: DecisionEvent): string {
  try {
    const p = JSON.parse(ev.event_payload_json ?? "{}");
    if (ev.event_type === "move_status") {
      return ` (${p.from ?? "?"} → ${p.to ?? "?"})`;
    }
    if (ev.event_type === "finalize_decision") {
      return ` (outcome: ${p.outcome ?? "?"})`;
    }
    if (ev.event_type === "edit_decision") {
      const keys = Object.keys(p.new ?? {});
      if (keys.length) return ` (changed: ${keys.join(", ")})`;
    }
  } catch {
    // ignore
  }
  return "";
}

export function AuditTab({ events }: { events: DecisionEvent[] }) {
  if (events.length === 0) {
    return (
      <div className="rounded-lg border border-border bg-surface-2/30 py-10 text-center text-sm text-muted">
        📜 No events recorded.
      </div>
    );
  }
  return (
    <div className="space-y-1">
      {events.map((ev) => {
        const [emoji, label] = LABELS[ev.event_type] ?? ["📋", ev.event_type];
        return (
          <div
            key={ev.id}
            className="ml-2 border-l-2 border-border pl-3 py-1.5 text-sm"
          >
            <span className="mr-1">{emoji}</span>
            <span className="font-semibold text-brand">{ev.actor}</span>{" "}
            <span className="text-xs text-muted">
              {label}
              {payloadHint(ev)}
            </span>{" "}
            <span className="text-xs text-muted">
              · {formatRelativeTime(ev.created_at_utc)}
            </span>
          </div>
        );
      })}
    </div>
  );
}
