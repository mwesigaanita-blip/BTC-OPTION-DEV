import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { ArrowLeft, Lock, Trash2 } from "lucide-react";
import type {
  DecisionDetail as DecisionDetailT,
  DecisionStatus,
  FinalOutcome,
  Priority,
} from "@/api/decisions";
import {
  deleteDecision,
  fetchDecision,
  finalizeDecision,
  moveStatus,
  updateDecision,
} from "@/api/decisions";
import { Button } from "@/components/ui/Button";
import { Card, CardBody, CardHeader } from "@/components/ui/Card";
import { Input } from "@/components/ui/Input";
import { LoadingState } from "@/components/shared/LoadingState";
import { ErrorState } from "@/components/shared/ErrorState";
import { Tabs } from "@/components/ui/Tabs";
import { ActionsTab } from "./ActionsTab";
import { AuditTab } from "./AuditTab";
import { DiscussionTab } from "./DiscussionTab";
import { OutcomeBadge, PriorityBadge, StatusBadge } from "./Badges";
import { OUTCOMES, PRIORITIES, formatRelativeTime } from "./styles";

type Tab = "overview" | "actions" | "discussion" | "audit";

export function DecisionDetail({
  decisionId,
  onBack,
}: {
  decisionId: number;
  onBack: () => void;
}) {
  const qc = useQueryClient();
  const detailQ = useQuery({
    queryKey: ["decision", decisionId],
    queryFn: () => fetchDecision(decisionId),
  });
  const [tab, setTab] = useState<Tab>("overview");

  function invalidate() {
    qc.invalidateQueries({ queryKey: ["decision", decisionId] });
    qc.invalidateQueries({ queryKey: ["decisions"] });
    qc.invalidateQueries({ queryKey: ["decision-metrics"] });
  }

  if (detailQ.isLoading) return <LoadingState label="Loading decision…" />;
  if (detailQ.error || !detailQ.data) {
    return (
      <ErrorState
        message={(detailQ.error as Error)?.message ?? "Decision not found"}
        onRetry={() => detailQ.refetch()}
      />
    );
  }

  const detail = detailQ.data;
  const isLocked = detail.locked_flag === 1;

  return (
    <div className="space-y-4 animate-fade-in">
      <div className="flex items-center gap-3">
        <Button variant="secondary" size="sm" onClick={onBack}>
          <ArrowLeft className="h-3.5 w-3.5" /> Back
        </Button>
        <div className="flex flex-wrap items-center gap-2">
          <h2 className="text-lg font-semibold text-fg">{detail.title}</h2>
          {isLocked ? (
            <span className="inline-flex items-center gap-1 text-xs text-muted">
              <Lock className="h-3 w-3" /> FINALIZED
            </span>
          ) : null}
        </div>
      </div>

      <div className="flex flex-wrap items-center gap-2">
        <StatusBadge status={detail.status} />
        <PriorityBadge priority={detail.priority} />
        {isLocked && detail.final_outcome ? (
          <OutcomeBadge outcome={detail.final_outcome} />
        ) : null}
      </div>
      <div className="text-xs text-muted">
        Created by <span className="font-semibold text-fg">{detail.created_by}</span> ·{" "}
        {formatRelativeTime(detail.created_at_utc)}
      </div>

      {isLocked && detail.final_summary_reason ? (
        <Card>
          <CardBody className="pt-4">
            <div className="text-sm font-semibold text-fg">
              Final Outcome: {String(detail.final_outcome).toUpperCase()}
            </div>
            <div className="mt-1 whitespace-pre-wrap text-sm text-muted">
              {detail.final_summary_reason}
            </div>
            <div className="mt-2 text-xs text-muted">
              Finalized by {detail.finalized_by ?? "?"} ·{" "}
              {formatRelativeTime(detail.finalized_at_utc ?? "")}
            </div>
          </CardBody>
        </Card>
      ) : null}

      <Tabs
        active={tab}
        onChange={(id) => setTab(id as Tab)}
        tabs={[
          { id: "overview", label: "📝 Overview" },
          { id: "actions", label: `⚡ Actions (${detail.actions.length})` },
          {
            id: "discussion",
            label: `💬 Discussion (${detail.comments_total})`,
          },
          { id: "audit", label: "📜 Audit Trail" },
        ]}
      />

      <div className="pt-2">
        {tab === "overview" ? (
          <OverviewTab detail={detail} isLocked={isLocked} onChanged={invalidate} />
        ) : null}
        {tab === "actions" ? (
          <ActionsTab
            decisionId={decisionId}
            actions={detail.actions}
            isLocked={isLocked}
            onChanged={invalidate}
          />
        ) : null}
        {tab === "discussion" ? (
          <DiscussionTab
            decisionId={decisionId}
            initialComments={detail.comments}
            initialTotal={detail.comments_total}
            isLocked={isLocked}
            onChanged={invalidate}
          />
        ) : null}
        {tab === "audit" ? <AuditTab events={detail.events} /> : null}
      </div>

      <DangerZone
        decisionId={decisionId}
        title={detail.title}
        onDeleted={() => {
          invalidate();
          onBack();
        }}
      />
    </div>
  );
}

function OverviewTab({
  detail,
  isLocked,
  onChanged,
}: {
  detail: DecisionDetailT;
  isLocked: boolean;
  onChanged: () => void;
}) {
  const [editing, setEditing] = useState(false);
  const [title, setTitle] = useState(detail.title);
  const [desc, setDesc] = useState(detail.description ?? "");
  const [priority, setPriority] = useState<Priority>(detail.priority);
  const [showFinalize, setShowFinalize] = useState(false);
  const [outcome, setOutcome] = useState<FinalOutcome>("accepted");
  const [reason, setReason] = useState("");
  const [err, setErr] = useState<string | null>(null);

  const saveMut = useMutation({
    mutationFn: () =>
      updateDecision(detail.id, { title, description: desc, priority }),
    onSuccess: () => {
      setEditing(false);
      onChanged();
    },
    onError: (e: any) => setErr(e?.response?.data?.detail ?? String(e)),
  });

  const moveMut = useMutation({
    mutationFn: (s: DecisionStatus) => moveStatus(detail.id, s),
    onSuccess: onChanged,
    onError: (e: any) => setErr(e?.response?.data?.detail ?? String(e)),
  });

  const finalizeMut = useMutation({
    mutationFn: () => finalizeDecision(detail.id, outcome, reason.trim()),
    onSuccess: () => {
      setShowFinalize(false);
      setReason("");
      onChanged();
    },
    onError: (e: any) => setErr(e?.response?.data?.detail ?? String(e)),
  });

  return (
    <div className="space-y-4">
      {err ? <div className="text-xs text-negative">{err}</div> : null}

      {detail.description ? (
        <div className="whitespace-pre-wrap text-sm text-fg">{detail.description}</div>
      ) : (
        <div className="text-xs text-muted">No description provided.</div>
      )}

      {!isLocked ? (
        <>
          {editing ? (
            <Card>
              <CardHeader title="Edit decision" />
              <CardBody className="space-y-3">
                <Input value={title} onChange={(e) => setTitle(e.target.value)} />
                <textarea
                  className="h-28 w-full resize-y rounded-lg border border-border bg-surface-2 px-3.5 py-2 text-sm"
                  value={desc}
                  onChange={(e) => setDesc(e.target.value)}
                />
                <select
                  className="h-11 w-full rounded-lg border border-border bg-surface-2 px-3 text-sm"
                  value={priority}
                  onChange={(e) => setPriority(e.target.value as Priority)}
                >
                  {PRIORITIES.map((p) => (
                    <option key={p} value={p}>
                      {p}
                    </option>
                  ))}
                </select>
                <div className="flex gap-2">
                  <Button
                    onClick={() => saveMut.mutate()}
                    disabled={saveMut.isPending}
                    className="flex-1"
                  >
                    Save Changes
                  </Button>
                  <Button
                    variant="secondary"
                    onClick={() => setEditing(false)}
                    className="flex-1"
                  >
                    Cancel
                  </Button>
                </div>
              </CardBody>
            </Card>
          ) : (
            <Button variant="secondary" onClick={() => setEditing(true)}>
              ✏️ Edit Decision
            </Button>
          )}

          <div className="space-y-2">
            <h4 className="text-sm font-semibold text-fg">Move Status</h4>
            <div className="grid grid-cols-2 gap-2">
              {detail.status === "ideas" ? (
                <Button
                  variant="secondary"
                  onClick={() => moveMut.mutate("under_review")}
                >
                  🔍 Move to Under Review
                </Button>
              ) : null}
              {detail.status === "under_review" ? (
                <Button variant="secondary" onClick={() => moveMut.mutate("ideas")}>
                  💡 Move to Ideas
                </Button>
              ) : null}
              <Button onClick={() => setShowFinalize((v) => !v)}>
                ✅ Finalize Decision
              </Button>
            </div>
          </div>

          {showFinalize ? (
            <Card>
              <CardHeader title="Finalize decision" />
              <CardBody className="space-y-3">
                <div className="rounded-lg border border-warning/40 bg-warning/10 px-3 py-2 text-xs text-warning">
                  Once finalized, this decision becomes permanently locked and read-only.
                </div>
                <select
                  className="h-11 w-full rounded-lg border border-border bg-surface-2 px-3 text-sm"
                  value={outcome}
                  onChange={(e) => setOutcome(e.target.value as FinalOutcome)}
                >
                  {OUTCOMES.map((o) => (
                    <option key={o} value={o}>
                      {o}
                    </option>
                  ))}
                </select>
                <textarea
                  className="h-24 w-full resize-y rounded-lg border border-border bg-surface-2 px-3.5 py-2 text-sm"
                  placeholder="Final summary reason (required)…"
                  value={reason}
                  onChange={(e) => setReason(e.target.value)}
                />
                <div className="flex gap-2">
                  <Button
                    onClick={() => finalizeMut.mutate()}
                    disabled={!reason.trim() || finalizeMut.isPending}
                    className="flex-1"
                  >
                    ✅ Confirm Finalize
                  </Button>
                  <Button
                    variant="secondary"
                    onClick={() => setShowFinalize(false)}
                    className="flex-1"
                  >
                    Cancel
                  </Button>
                </div>
              </CardBody>
            </Card>
          ) : null}
        </>
      ) : null}
    </div>
  );
}

function DangerZone({
  decisionId,
  title,
  onDeleted,
}: {
  decisionId: number;
  title: string;
  onDeleted: () => void;
}) {
  const [confirming, setConfirming] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const mut = useMutation({
    mutationFn: () => deleteDecision(decisionId),
    onSuccess: onDeleted,
    onError: (e: any) => setErr(e?.response?.data?.detail ?? String(e)),
  });

  return (
    <div className="border-t border-border pt-4">
      {err ? <div className="mb-2 text-xs text-negative">{err}</div> : null}
      {!confirming ? (
        <Button variant="secondary" onClick={() => setConfirming(true)}>
          <Trash2 className="h-3.5 w-3.5" /> Delete this decision
        </Button>
      ) : (
        <Card>
          <CardBody className="space-y-2 pt-4">
            <div className="text-sm text-negative">
              Really delete <span className="font-semibold">{title}</span>? This will
              erase all associated actions, comments, and audit trail.
            </div>
            <div className="flex gap-2">
              <Button
                variant="danger"
                onClick={() => mut.mutate()}
                disabled={mut.isPending}
                className="flex-1"
              >
                ✅ Yes, delete permanently
              </Button>
              <Button
                variant="secondary"
                onClick={() => setConfirming(false)}
                className="flex-1"
              >
                Cancel
              </Button>
            </div>
          </CardBody>
        </Card>
      )}
    </div>
  );
}
