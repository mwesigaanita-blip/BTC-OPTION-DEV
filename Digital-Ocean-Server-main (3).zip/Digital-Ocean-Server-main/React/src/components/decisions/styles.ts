import type { Priority, FinalOutcome, ActionType, DecisionStatus } from "@/api/decisions";

export const STATUS_LABEL: Record<DecisionStatus, string> = {
  ideas: "Ideas",
  under_review: "Under Review",
  done: "Done",
};

export const STATUS_EMOJI: Record<DecisionStatus, string> = {
  ideas: "💡",
  under_review: "🔍",
  done: "✅",
};

export const STATUS_COLOR: Record<DecisionStatus, string> = {
  ideas: "#3b82f6",
  under_review: "#ffb300",
  done: "#16c784",
};

export const PRIORITY_STYLE: Record<Priority, { emoji: string; color: string }> = {
  critical: { emoji: "🔴", color: "#ff4d4f" },
  high: { emoji: "🟠", color: "#ffb300" },
  medium: { emoji: "🔵", color: "#3b82f6" },
  low: { emoji: "⚪", color: "#9ca3af" },
};

export const OUTCOME_STYLE: Record<FinalOutcome, { emoji: string; color: string }> = {
  accepted: { emoji: "✅", color: "#16c784" },
  rejected: { emoji: "❌", color: "#ff4d4f" },
  partial: { emoji: "⚠️", color: "#ffb300" },
  informational: { emoji: "ℹ️", color: "#3b82f6" },
};

export const ACTION_TYPE_LABEL: Record<string, string> = {
  open: "Open Position",
  close: "Close Position",
  adjust: "Adjust Position",
  hedge: "Hedge",
  note: "Note",
  other: "Other",
};

export const ACTION_TYPE_BORDER: Record<string, string> = {
  open: "#16c784",
  close: "#ff4d4f",
  adjust: "#ffb300",
  hedge: "#3b82f6",
  note: "#9ca3af",
  other: "#6b7280",
};

export const ACTION_TYPES: ActionType[] = ["open", "close", "adjust", "hedge", "note", "other"];

export const PRIORITIES: Priority[] = ["low", "medium", "high", "critical"];

export const OUTCOMES: FinalOutcome[] = ["accepted", "rejected", "partial", "informational"];

export function formatRelativeTime(iso: string | null | undefined): string {
  if (!iso) return "";
  let s = iso;
  // tolerant parsing: backend stores "YYYY-MM-DDTHH:MM:SS" (no tz) UTC
  if (!s.endsWith("Z") && !/[+\-]\d\d:?\d\d$/.test(s)) s = s + "Z";
  const ts = new Date(s).getTime();
  if (!Number.isFinite(ts)) return iso;
  const sec = Math.max(0, Math.round((Date.now() - ts) / 1000));
  if (sec < 60) return "just now";
  if (sec < 3600) return `${Math.floor(sec / 60)}m ago`;
  if (sec < 86400) return `${Math.floor(sec / 3600)}h ago`;
  const days = Math.floor(sec / 86400);
  if (days === 1) return "1 day ago";
  if (days < 30) return `${days} days ago`;
  return iso.slice(0, 10);
}

export function truncate(text: string, max = 100): string {
  if (!text) return "";
  if (text.length <= max) return text;
  return text.slice(0, max - 1).trimEnd() + "…";
}
