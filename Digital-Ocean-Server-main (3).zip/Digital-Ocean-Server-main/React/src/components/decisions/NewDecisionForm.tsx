import { useState } from "react";
import { Minus, Plus } from "lucide-react";
import type { ActionInput, DecisionCreateInput, Priority } from "@/api/decisions";
import { Button } from "@/components/ui/Button";
import { Input } from "@/components/ui/Input";
import { ACTION_TYPES, ACTION_TYPE_LABEL, PRIORITIES } from "./styles";

function emptyAction(): ActionInput {
  return {
    action_type: "note",
    reason_text: "",
    instrument_name: null,
    side: null,
    quantity: null,
    price_reference: null,
  };
}

export function NewDecisionForm({
  onCancel,
  onSubmit,
  submitting,
  error,
}: {
  onCancel: () => void;
  onSubmit: (body: DecisionCreateInput) => void;
  submitting: boolean;
  error?: string | null;
}) {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [priority, setPriority] = useState<Priority>("medium");
  const [actions, setActions] = useState<ActionInput[]>([emptyAction()]);

  function updateAction(idx: number, patch: Partial<ActionInput>) {
    setActions((arr) => arr.map((a, i) => (i === idx ? { ...a, ...patch } : a)));
  }

  function submit() {
    const cleanActions = actions.map((a) => ({
      action_type: a.action_type,
      reason_text: a.reason_text ?? "",
      instrument_name: a.instrument_name || null,
      side: a.side || null,
      quantity: a.quantity && Number(a.quantity) > 0 ? Number(a.quantity) : null,
      price_reference:
        a.price_reference && Number(a.price_reference) > 0
          ? Number(a.price_reference)
          : null,
    }));
    onSubmit({ title, description, priority, actions: cleanActions });
  }

  return (
    <div className="card animate-fade-in space-y-4 p-5">
      <h3 className="text-sm font-semibold text-fg">➕ New Decision</h3>

      <div className="space-y-3">
        <div>
          <label className="mb-1 block text-xs font-medium text-muted">Title *</label>
          <Input
            placeholder="What's the proposal?"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
          />
        </div>
        <div>
          <label className="mb-1 block text-xs font-medium text-muted">Description</label>
          <textarea
            className="h-24 w-full resize-y rounded-lg border border-border bg-surface-2 px-3.5 py-2 text-sm text-fg placeholder:text-muted focus:border-brand focus:outline-none focus:ring-2 focus:ring-brand"
            placeholder="Details, context, reasoning..."
            value={description}
            onChange={(e) => setDescription(e.target.value)}
          />
        </div>
        <div>
          <label className="mb-1 block text-xs font-medium text-muted">Priority</label>
          <select
            className="h-11 w-full rounded-lg border border-border bg-surface-2 px-3 text-sm text-fg"
            value={priority}
            onChange={(e) => setPriority(e.target.value as Priority)}
          >
            {PRIORITIES.map((p) => (
              <option key={p} value={p}>
                {p}
              </option>
            ))}
          </select>
        </div>
      </div>

      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h4 className="text-sm font-semibold text-fg">
            Actions <span className="text-xs text-muted">(at least one required)</span>
          </h4>
          <div className="flex gap-2">
            <Button
              variant="secondary"
              size="sm"
              type="button"
              onClick={() => setActions((a) => [...a, emptyAction()])}
            >
              <Plus className="h-3.5 w-3.5" /> Add
            </Button>
            {actions.length > 1 ? (
              <Button
                variant="secondary"
                size="sm"
                type="button"
                onClick={() => setActions((a) => a.slice(0, -1))}
              >
                <Minus className="h-3.5 w-3.5" /> Remove last
              </Button>
            ) : null}
          </div>
        </div>

        {actions.map((act, i) => (
          <div key={i} className="rounded-lg border border-border bg-surface-2/40 p-3 space-y-2">
            <div className="text-xs font-semibold text-muted">Action {i + 1}</div>
            <div className="grid grid-cols-1 gap-2 md:grid-cols-2">
              <div>
                <label className="mb-1 block text-[0.7rem] text-muted">Type *</label>
                <select
                  className="h-10 w-full rounded-md border border-border bg-surface-2 px-2 text-sm"
                  value={act.action_type}
                  onChange={(e) => updateAction(i, { action_type: e.target.value })}
                >
                  {ACTION_TYPES.map((t) => (
                    <option key={t} value={t}>
                      {ACTION_TYPE_LABEL[t]}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="mb-1 block text-[0.7rem] text-muted">Side</label>
                <select
                  className="h-10 w-full rounded-md border border-border bg-surface-2 px-2 text-sm"
                  value={act.side ?? ""}
                  onChange={(e) => updateAction(i, { side: e.target.value || null })}
                >
                  <option value="">-</option>
                  <option value="buy">buy</option>
                  <option value="sell">sell</option>
                </select>
              </div>
              <div className="md:col-span-2">
                <label className="mb-1 block text-[0.7rem] text-muted">Note</label>
                <textarea
                  className="h-16 w-full resize-y rounded-md border border-border bg-surface-2 px-2 py-1.5 text-sm"
                  placeholder="Any notes about this action..."
                  value={act.reason_text ?? ""}
                  onChange={(e) => updateAction(i, { reason_text: e.target.value })}
                />
              </div>
              <div>
                <label className="mb-1 block text-[0.7rem] text-muted">Instrument</label>
                <Input
                  placeholder="e.g. BTC-30JUN25-100000-C"
                  value={act.instrument_name ?? ""}
                  onChange={(e) =>
                    updateAction(i, { instrument_name: e.target.value || null })
                  }
                />
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="mb-1 block text-[0.7rem] text-muted">Quantity</label>
                  <Input
                    type="number"
                    step="0.0001"
                    min={0}
                    value={act.quantity ?? ""}
                    onChange={(e) =>
                      updateAction(i, {
                        quantity: e.target.value === "" ? null : Number(e.target.value),
                      })
                    }
                  />
                </div>
                <div>
                  <label className="mb-1 block text-[0.7rem] text-muted">Price ref</label>
                  <Input
                    type="number"
                    step="0.01"
                    min={0}
                    value={act.price_reference ?? ""}
                    onChange={(e) =>
                      updateAction(i, {
                        price_reference:
                          e.target.value === "" ? null : Number(e.target.value),
                      })
                    }
                  />
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {error ? <div className="text-xs text-negative">{error}</div> : null}

      <div className="flex gap-2">
        <Button onClick={submit} disabled={submitting || !title.trim()} className="flex-1">
          💡 Create Decision
        </Button>
        <Button variant="secondary" onClick={onCancel} className="flex-1">
          Cancel
        </Button>
      </div>
    </div>
  );
}
