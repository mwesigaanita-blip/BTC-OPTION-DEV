import type { DecisionStatus, FinalOutcome, Priority } from "@/api/decisions";
import {
  OUTCOME_STYLE,
  PRIORITY_STYLE,
  STATUS_COLOR,
  STATUS_EMOJI,
  STATUS_LABEL,
} from "./styles";

function Pill({
  color,
  children,
  size = "sm",
}: {
  color: string;
  children: React.ReactNode;
  size?: "sm" | "xs";
}) {
  return (
    <span
      className={
        size === "xs"
          ? "inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[0.7rem] font-bold uppercase tracking-wide text-white"
          : "inline-flex items-center gap-1 rounded-full px-2.5 py-0.5 text-xs font-semibold text-white"
      }
      style={{ backgroundColor: color }}
    >
      {children}
    </span>
  );
}

export function PriorityBadge({ priority }: { priority: Priority | string }) {
  const s = PRIORITY_STYLE[priority as Priority] ?? { emoji: "", color: "#9ca3af" };
  return (
    <Pill color={s.color}>
      <span>{s.emoji}</span>
      <span>{String(priority).toUpperCase()}</span>
    </Pill>
  );
}

export function StatusBadge({ status }: { status: DecisionStatus }) {
  return (
    <Pill color={STATUS_COLOR[status] ?? "#9ca3af"}>
      <span>{STATUS_EMOJI[status]}</span>
      <span>{STATUS_LABEL[status]}</span>
    </Pill>
  );
}

export function OutcomeBadge({ outcome }: { outcome: FinalOutcome | string }) {
  const s = OUTCOME_STYLE[outcome as FinalOutcome] ?? { emoji: "", color: "#9ca3af" };
  return (
    <Pill color={s.color} size="xs">
      <span>{s.emoji}</span>
      <span>{String(outcome).toUpperCase()}</span>
    </Pill>
  );
}
