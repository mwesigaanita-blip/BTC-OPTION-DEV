import { useState } from "react";
import { Pencil, Trash2 } from "lucide-react";
import type { ActionInput, DecisionAction } from "@/api/decisions";
import { addAction, deleteAction, updateAction } from "@/api/decisions";
import { Button } from "@/components/ui/Button";
import { Input } from "@/components/ui/Input";
import { ACTION_TYPES, ACTION_TYPE_BORDER, ACTION_TYPE_LABEL } from "./styles";

function ActionRowEditor({
  initial,
  onCancel,
  onSave,
  saving,
}: {
  initial: Partial<DecisionAction>;
  onCancel: () => void;
  onSave: (body: ActionInput) => void;
  saving: boolean;
}) {
  const [body, setBody] = useState<ActionInput>({
    action_type: initial.action_type ?? "note",
    reason_text: initial.reason_text ?? "",
    instrument_name: initial.instrument_name ?? null,
    side: initial.side ?? null,
    quantity: initial.quantity ?? null,
    price_reference: initial.price_reference ?? null,
  });

  function patch(p: Partial<ActionInput>) {
    setBody((b) => ({ ...b, ...p }));
  }

  return (
    <div className="rounded-lg border border-border bg-surface-2/40 p-3 space-y-2">
      <div className="grid grid-cols-1 gap-2 md:grid-cols-2">
        <select
          className="h-10 w-full rounded-md border border-border bg-surface-2 px-2 text-sm"
          value={body.action_type}
          onChange={(e) => patch({ action_type: e.target.value })}
        >
          {ACTION_TYPES.map((t) => (
            <option key={t} value={t}>
              {ACTION_TYPE_LABEL[t]}
            </option>
          ))}
        </select>
        <select
          className="h-10 w-full rounded-md border border-border bg-surface-2 px-2 text-sm"
          value={body.side ?? ""}
          onChange={(e) => patch({ side: e.target.value || null })}
        >
          <option value="">- side -</option>
          <option value="buy">buy</option>
          <option value="sell">sell</option>
        </select>
        <Input
          placeholder="Reason / note"
          value={body.reason_text ?? ""}
          onChange={(e) => patch({ reason_text: e.target.value })}
          className="md:col-span-2"
        />
        <Input
          placeholder="Instrument (optional)"
          value={body.instrument_name ?? ""}
          onChange={(e) => patch({ instrument_name: e.target.value || null })}
        />
        <div className="grid grid-cols-2 gap-2">
          <Input
            type="number"
            step="0.0001"
            min={0}
            placeholder="Qty"
            value={body.quantity ?? ""}
            onChange={(e) =>
              patch({ quantity: e.target.value === "" ? null : Number(e.target.value) })
            }
          />
          <Input
            type="number"
            step="0.01"
            min={0}
            placeholder="Price ref"
            value={body.price_reference ?? ""}
            onChange={(e) =>
              patch({
                price_reference:
                  e.target.value === "" ? null : Number(e.target.value),
              })
            }
          />
        </div>
      </div>
      <div className="flex gap-2">
        <Button size="sm" onClick={() => onSave(body)} disabled={saving} className="flex-1">
          Save
        </Button>
        <Button size="sm" variant="secondary" onClick={onCancel} className="flex-1">
          Cancel
        </Button>
      </div>
    </div>
  );
}

export function ActionsTab({
  decisionId,
  actions,
  isLocked,
  onChanged,
}: {
  decisionId: number;
  actions: DecisionAction[];
  isLocked: boolean;
  onChanged: () => void;
}) {
  const [editingId, setEditingId] = useState<number | null>(null);
  const [adding, setAdding] = useState(false);
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  async function handleSave(body: ActionInput, id?: number) {
    setSaving(true);
    setErr(null);
    try {
      if (id) await updateAction(id, body);
      else await addAction(decisionId, body);
      setEditingId(null);
      setAdding(false);
      onChanged();
    } catch (e: any) {
      setErr(e?.response?.data?.detail ?? String(e));
    } finally {
      setSaving(false);
    }
  }

  async function handleDelete(id: number) {
    if (!confirm("Delete this action?")) return;
    try {
      await deleteAction(id);
      onChanged();
    } catch (e: any) {
      setErr(e?.response?.data?.detail ?? String(e));
    }
  }

  return (
    <div className="space-y-3">
      {err ? <div className="text-xs text-negative">{err}</div> : null}
      {actions.length === 0 ? (
        <div className="rounded-lg border border-border bg-surface-2/30 py-10 text-center text-sm text-muted">
          ⚡ No proposed actions yet.
        </div>
      ) : (
        actions.map((a) => {
          const border = ACTION_TYPE_BORDER[a.action_type] ?? "#3b82f6";
          if (editingId === a.id) {
            return (
              <ActionRowEditor
                key={a.id}
                initial={a}
                onCancel={() => setEditingId(null)}
                onSave={(b) => handleSave(b, a.id)}
                saving={saving}
              />
            );
          }
          return (
            <div
              key={a.id}
              className="rounded-lg bg-surface-2/60 p-3"
              style={{ borderLeft: `3px solid ${border}` }}
            >
              <div className="text-[0.7rem] font-bold uppercase tracking-wide text-brand">
                {ACTION_TYPE_LABEL[a.action_type] ?? a.action_type}
              </div>
              <div className="mt-1 text-sm text-fg">{a.reason_text}</div>
              <div className="mt-1 flex flex-wrap items-center gap-x-2 gap-y-1 text-xs text-muted">
                {a.instrument_name ? <span>🎯 {a.instrument_name}</span> : null}
                {a.side ? (
                  <span
                    className={
                      a.side.toLowerCase() === "buy"
                        ? "font-semibold text-positive"
                        : "font-semibold text-negative"
                    }
                  >
                    {a.side.toUpperCase()}
                  </span>
                ) : null}
                {a.quantity != null ? <span>Qty: {a.quantity}</span> : null}
                {a.price_reference != null ? (
                  <span>Ref: ${a.price_reference.toLocaleString()}</span>
                ) : null}
              </div>
              {!isLocked ? (
                <div className="mt-2 flex gap-2">
                  <Button size="sm" variant="secondary" onClick={() => setEditingId(a.id)}>
                    <Pencil className="h-3 w-3" /> Edit
                  </Button>
                  <Button size="sm" variant="danger" onClick={() => handleDelete(a.id)}>
                    <Trash2 className="h-3 w-3" /> Delete
                  </Button>
                </div>
              ) : null}
            </div>
          );
        })
      )}

      {!isLocked ? (
        adding ? (
          <ActionRowEditor
            initial={{}}
            onCancel={() => setAdding(false)}
            onSave={(b) => handleSave(b)}
            saving={saving}
          />
        ) : (
          <Button variant="secondary" onClick={() => setAdding(true)} className="w-full">
            ⚡ Add Action
          </Button>
        )
      ) : null}
    </div>
  );
}
