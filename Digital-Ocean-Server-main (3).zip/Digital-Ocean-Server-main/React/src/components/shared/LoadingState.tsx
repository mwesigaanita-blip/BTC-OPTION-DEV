import { Spinner } from "@/components/ui/Spinner";
import { cn } from "@/lib/utils";

export function LoadingState({
  label = "Loading…",
  full = false,
}: {
  label?: string;
  full?: boolean;
}) {
  return (
    <div
      className={cn(
        "flex items-center justify-center gap-2 text-sm text-muted",
        full ? "h-screen" : "py-12",
      )}
    >
      <Spinner />
      <span>{label}</span>
    </div>
  );
}
