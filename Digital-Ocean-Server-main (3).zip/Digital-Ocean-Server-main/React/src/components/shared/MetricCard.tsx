import type { LucideIcon } from "lucide-react";
import { cn } from "@/lib/utils";

type Tone = "neutral" | "positive" | "negative" | "warning";

const toneText: Record<Tone, string> = {
  neutral: "text-fg",
  positive: "text-positive",
  negative: "text-negative",
  warning: "text-warning",
};

export function MetricCard({
  label,
  value,
  sub,
  icon: Icon,
  tone = "neutral",
}: {
  label: string;
  value: string;
  sub?: string;
  icon?: LucideIcon;
  tone?: Tone;
}) {
  return (
    <div className="card animate-fade-in p-4">
      <div className="flex items-center justify-between">
        <span className="text-xs font-medium uppercase tracking-wide text-muted">
          {label}
        </span>
        {Icon ? <Icon className="h-4 w-4 text-muted" /> : null}
      </div>
      <div className={cn("mt-2 text-2xl font-semibold tabular-nums", toneText[tone])}>
        {value}
      </div>
      {sub ? <div className="mt-1 text-xs text-muted">{sub}</div> : null}
    </div>
  );
}
