import { useMemo } from "react";
import {
  Area,
  ComposedChart,
  CartesianGrid,
  Line,
  ReferenceDot,
  ReferenceLine,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { useTheme } from "@/theme/ThemeProvider";
import { fmtUsd } from "@/lib/format";
import { Badge } from "@/components/ui/Badge";
import type { PnlCurvePoint } from "@/types/api";

interface Props {
  curve: PnlCurvePoint[];
  breakEven: number[];
  spot?: number;
  /** Optional static expiration payoff curve (intrinsic-only). Rendered as
   * a dashed overlay so the user can see how the dynamic curve converges
   * to expiration as time advances. */
  expirationCurve?: PnlCurvePoint[];
}

interface ChartPoint {
  btc_price: number;
  pnl_usd: number;
  pnl_pct: number | null;
  expiration_pnl_usd: number | null;
  isBreakEven: boolean;
}

/** Portfolio PnL payoff curve - PnL (USD) vs BTC price. */
export function PnlCurveChart({ curve, breakEven, spot, expirationCurve }: Props) {
  const { theme } = useTheme();
  const dark = theme === "dark";
  const axis = dark ? "#8b949e" : "#6b7280";
  const grid = dark ? "rgba(139,148,161,0.15)" : "rgba(107,114,128,0.18)";
  const brand = dark ? "#388bfd" : "#2563eb";
  const expColor = dark ? "#d29922" : "#b45309";
  const zero = dark ? "#f85149" : "#dc2626";
  const beColor = dark ? "#3fb950" : "#16a34a";

  const bePoints = useMemo(
    () => breakEven.filter((b) => Number.isFinite(b)),
    [breakEven],
  );

  /** Signed percent distance from spot to a break-even price.
   * `+5.2%` means BTC must rise 5.2% from the current/frozen price
   * to reach break-even; `-3.1%` means it must fall 3.1%. */
  const pctFromSpot = (be: number): string | null => {
    if (!spot || !Number.isFinite(spot) || spot <= 0) return null;
    const pct = ((be - spot) / spot) * 100;
    const sign = pct >= 0 ? "+" : "";
    return `${sign}${pct.toFixed(2)}%`;
  };

  const expByPrice = useMemo(() => {
    const m = new Map<number, number>();
    for (const p of expirationCurve ?? []) m.set(p.btc_price, p.pnl_usd);
    return m;
  }, [expirationCurve]);

  const hasExpiration = (expirationCurve?.length ?? 0) > 0;

  // Insert each break-even as a REAL data point (PnL = 0, which is its
  // definition) so hovering the marker lands on it instead of a neighbour.
  const data = useMemo<ChartPoint[]>(() => {
    const pts: ChartPoint[] = curve.map((p) => ({
      btc_price: p.btc_price,
      pnl_usd: p.pnl_usd,
      pnl_pct: p.pnl_pct,
      expiration_pnl_usd: expByPrice.get(p.btc_price) ?? null,
      isBreakEven: false,
    }));
    for (const be of bePoints) {
      pts.push({
        btc_price: be,
        pnl_usd: 0,
        pnl_pct: 0,
        expiration_pnl_usd: null,
        isBreakEven: true,
      });
    }
    pts.sort((a, b) => a.btc_price - b.btc_price);
    return pts;
  }, [curve, bePoints, expByPrice]);

  return (
    <div>
      {/* Break-even + spot summary inside the card */}
      <div className="mb-3 flex flex-wrap items-center gap-2 text-xs">
        <span className="text-muted">Break-even:</span>
        {bePoints.length ? (
          bePoints.map((be) => {
            const pct = pctFromSpot(be);
            return (
              <Badge key={be} tone="positive">
                {fmtUsd(be, 0)}
                {pct ? (
                  <span className="ml-1 opacity-80">({pct})</span>
                ) : null}
              </Badge>
            );
          })
        ) : (
          <span className="text-muted">none in range</span>
        )}
        {spot ? (
          <>
            <span className="ml-2 text-muted">Spot:</span>
            <Badge tone="brand">{fmtUsd(spot, 0)}</Badge>
          </>
        ) : null}
        <span className="ml-auto flex items-center gap-3 text-[11px] text-muted">
          <span className="flex items-center gap-1.5">
            <span
              aria-hidden
              className="inline-block h-[2px] w-4"
              style={{ background: brand }}
            />
            Dynamic
          </span>
          {hasExpiration ? (
            <span className="flex items-center gap-1.5">
              <span
                aria-hidden
                className="inline-block h-[2px] w-4"
                style={{
                  backgroundImage: `repeating-linear-gradient(to right, ${expColor} 0 4px, transparent 4px 8px)`,
                }}
              />
              At expiration
            </span>
          ) : null}
        </span>
      </div>

      <ResponsiveContainer width="100%" height={320}>
        <ComposedChart data={data} margin={{ top: 8, right: 12, bottom: 4, left: 4 }}>
          <defs>
            <linearGradient id="pnlFill" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor={brand} stopOpacity={0.35} />
              <stop offset="100%" stopColor={brand} stopOpacity={0.02} />
            </linearGradient>
          </defs>
          <CartesianGrid stroke={grid} vertical={false} />
          <XAxis
            dataKey="btc_price"
            type="number"
            domain={["dataMin", "dataMax"]}
            tickFormatter={(v) => `$${Math.round(Number(v) / 1000)}k`}
            tick={{ fill: axis, fontSize: 11 }}
            stroke={grid}
          />
          <YAxis
            tickFormatter={(v) => `$${Math.round(Number(v) / 1000)}k`}
            tick={{ fill: axis, fontSize: 11 }}
            stroke={grid}
            width={56}
          />
          <Tooltip
            content={({ active, payload }) => {
              if (!active || !payload?.length) return null;
              const p = payload[0].payload as ChartPoint;
              return (
                <div
                  style={{
                    background: dark ? "#161b22" : "#ffffff",
                    border: `1px solid ${grid}`,
                    borderRadius: 8,
                    fontSize: 12,
                    padding: "6px 10px",
                  }}
                >
                  <div style={{ color: p.isBreakEven ? beColor : axis }}>
                    {p.isBreakEven ? "Break-even" : "BTC"} {fmtUsd(p.btc_price, 0)}
                    {p.isBreakEven && pctFromSpot(p.btc_price) ? (
                      <span style={{ marginLeft: 4, opacity: 0.85 }}>
                        ({pctFromSpot(p.btc_price)})
                      </span>
                    ) : null}
                  </div>
                  <div style={{ color: dark ? "#e6e9ef" : "#111827" }}>
                    Dynamic: {fmtUsd(p.pnl_usd)}
                  </div>
                  {hasExpiration && p.expiration_pnl_usd !== null ? (
                    <div style={{ color: expColor }}>
                      At expiration: {fmtUsd(p.expiration_pnl_usd)}
                    </div>
                  ) : null}
                </div>
              );
            }}
          />
          <ReferenceLine y={0} stroke={zero} strokeDasharray="4 4" />
          {spot ? (
            <ReferenceLine
              x={spot}
              stroke={axis}
              strokeDasharray="3 3"
              label={{ value: "spot", fill: axis, fontSize: 10, position: "top" }}
            />
          ) : null}
          {bePoints.map((be) => (
            <ReferenceLine
              key={`l-${be}`}
              x={be}
              stroke={beColor}
              strokeDasharray="2 4"
            />
          ))}
          {bePoints.map((be) => (
            <ReferenceDot
              key={`d-${be}`}
              x={be}
              y={0}
              r={4}
              fill={beColor}
              stroke={dark ? "#0d1117" : "#ffffff"}
              strokeWidth={2}
            />
          ))}
          <Area
            type="monotone"
            dataKey="pnl_usd"
            stroke={brand}
            strokeWidth={2}
            fill="url(#pnlFill)"
            dot={false}
            activeDot={{ r: 4, fill: brand }}
            isAnimationActive={false}
          />
          {hasExpiration ? (
            <Line
              type="monotone"
              dataKey="expiration_pnl_usd"
              stroke={expColor}
              strokeWidth={2}
              strokeDasharray="6 4"
              dot={false}
              activeDot={{ r: 3, fill: expColor }}
              connectNulls
              isAnimationActive={false}
            />
          ) : null}
        </ComposedChart>
      </ResponsiveContainer>
    </div>
  );
}
