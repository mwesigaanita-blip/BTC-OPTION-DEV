import { Radio, Database } from "lucide-react";
import { cn } from "@/lib/utils";
import { ageLabel } from "@/lib/format";
import type { DataSource } from "@/types/api";

/** Live vs snapshot indicator - mirrors the Streamlit data-source caption. */
export function StalenessBanner({
  source,
  updatedAt,
}: {
  source: DataSource;
  updatedAt: string | null;
}) {
  const live = source === "live";
  return (
    <div
      className={cn(
        "flex items-center gap-2 rounded-lg border px-3 py-1.5 text-xs",
        live
          ? "border-positive/30 bg-positive/10 text-positive"
          : "border-warning/30 bg-warning/10 text-warning",
      )}
    >
      {live ? (
        <Radio className="h-3.5 w-3.5" />
      ) : (
        <Database className="h-3.5 w-3.5" />
      )}
      <span className="font-medium">{live ? "Live" : "Snapshot"}</span>
      <span className="opacity-70">
        {live
          ? `streaming from WS→Redis · ${ageLabel(updatedAt)}`
          : `live feed unavailable - last snapshot ${ageLabel(updatedAt)}`}
      </span>
    </div>
  );
}
