import { useMemo, useState } from "react";
import { ChevronDown, ChevronRight } from "lucide-react";
import { cn } from "@/lib/utils";
import type { PositionRecord } from "@/types/api";

/**
 * Deribit-style grouped positions tree:
 *   BTC ▸ Options/Futures ▸ Expiry ▸ instrument
 * Group rows carry subtotals; collapsible. Mirrors the Streamlit tree table.
 */

const SUM_KEYS = [
  "amount",
  "pnl_btc",
  "pnl_usd",
  "im",
  "mm",
  "net_delta",
  "delta",
  "gamma",
  "vega",
  "theta",
] as const;
type SumKey = (typeof SUM_KEYS)[number];

interface Derived {
  amount: number;
  avg_btc: number;
  avg_usd: number;
  mark_btc: number;
  mark_usd: number;
  pnl_btc: number;
  pnl_usd: number;
  roi: number | null;
  im: number;
  mm: number;
  net_delta: number;
  delta: number;
  gamma: number;
  vega: number;
  theta: number;
}

const num = (x: unknown): number => {
  const n = Number(x);
  return Number.isFinite(n) ? n : 0;
};

function derive(p: PositionRecord): Derived {
  const qty = Math.abs(num(p.qty ?? p.size));
  const sell = String(p.side ?? "").toLowerCase() === "sell";
  const amount = sell ? -qty : qty;
  const isOption = String(p.kind ?? "").toLowerCase() === "option";
  const mark_btc = num(p.mark_price_btc);
  const delta = num(p.delta);
  // Net delta (inverse options): the greek delta minus the BTC value tied up
  // in the position (mark price x signed contracts). Futures: net == delta.
  const net_delta = isOption ? delta - mark_btc * amount : delta;
  return {
    amount,
    avg_btc: num(p.avg_price_btc),
    avg_usd: num(p.avg_price_usd),
    mark_btc,
    mark_usd: num(p.mark_usd),
    pnl_btc: num(p.total_profit_loss),
    pnl_usd: num(p.pnl_usd_total),
    roi: p.pnl_pct == null ? null : num(p.pnl_pct),
    im: num(p.initial_margin),
    mm: num(p.maintenance_margin),
    net_delta,
    delta,
    gamma: num(p.gamma),
    vega: num(p.vega),
    theta: num(p.theta),
  };
}

/** Expiry token from the instrument name (BTC-22MAY26-73000-P -> 22MAY26). */
function expiryOf(name: string): string {
  const parts = (name || "").toUpperCase().split("-");
  if (parts.length >= 2 && parts[1] && parts[1] !== "PERPETUAL") return parts[1];
  return "PERPETUAL";
}

// ---- formatters (empty string for missing, unlike the global helpers) ------
const fNum = (v: unknown, d: number): string => {
  const n = Number(v);
  if (!Number.isFinite(n)) return "";
  return n.toLocaleString("en-US", {
    minimumFractionDigits: d,
    maximumFractionDigits: d,
  });
};
const fBtc = (v: unknown): string => {
  const n = Number(v);
  return Number.isFinite(n) ? `฿${n.toFixed(4)}` : "";
};
const fUsd = (v: unknown): string => {
  const n = Number(v);
  if (!Number.isFinite(n)) return "";
  return `$${n.toLocaleString("en-US", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  })}`;
};
const fRoi = (v: unknown): string => {
  const n = Number(v);
  return Number.isFinite(n) ? `${n.toFixed(1)}%` : "";
};

interface ColDef {
  key: keyof Derived;
  label: string;
  fmt: (v: unknown) => string;
  color: boolean; // green/red by sign
  onGroup: boolean; // show subtotal on group rows
}

const COLS: ColDef[] = [
  { key: "amount", label: "Amount", fmt: (v) => fNum(v, 1), color: true, onGroup: true },
  { key: "avg_btc", label: "Avg Price", fmt: fBtc, color: false, onGroup: false },
  { key: "avg_usd", label: "Avg Price (USD)", fmt: fUsd, color: false, onGroup: false },
  { key: "mark_btc", label: "Mark Price", fmt: fBtc, color: false, onGroup: false },
  { key: "mark_usd", label: "Mark Price (USD)", fmt: fUsd, color: false, onGroup: false },
  { key: "pnl_btc", label: "PNL", fmt: fBtc, color: true, onGroup: true },
  { key: "pnl_usd", label: "PNL (USD)", fmt: fUsd, color: true, onGroup: true },
  { key: "roi", label: "ROI", fmt: fRoi, color: true, onGroup: false },
  { key: "im", label: "IM", fmt: (v) => fNum(v, 2), color: false, onGroup: true },
  { key: "mm", label: "MM", fmt: (v) => fNum(v, 2), color: false, onGroup: true },
  { key: "net_delta", label: "Net Delta", fmt: (v) => fNum(v, 2), color: false, onGroup: true },
  { key: "delta", label: "Delta", fmt: (v) => fNum(v, 2), color: false, onGroup: true },
  { key: "gamma", label: "Gamma", fmt: (v) => fNum(v, 6), color: false, onGroup: true },
  { key: "vega", label: "Vega", fmt: (v) => fNum(v, 2), color: false, onGroup: true },
  { key: "theta", label: "Theta", fmt: (v) => fNum(v, 2), color: false, onGroup: true },
];

interface Leaf {
  type: "leaf";
  depth: number;
  name: string;
  d: Derived;
  isFuture: boolean;
}
type Flavor = "option" | "future" | "mixed";
interface Group {
  type: "group";
  id: string;
  depth: number;
  label: string;
  count: number;
  flavor: Flavor;
  agg: Record<SumKey, number>;
  children: TreeNode[];
}
type TreeNode = Leaf | Group;

function aggOf(leaves: Leaf[]): Record<SumKey, number> {
  const a = Object.fromEntries(SUM_KEYS.map((k) => [k, 0])) as Record<
    SumKey,
    number
  >;
  for (const lf of leaves)
    for (const k of SUM_KEYS) a[k] += num(lf.d[k]);
  return a;
}

function buildTree(positions: PositionRecord[]): Group | null {
  if (!positions.length) return null;

  const leaves: Array<Leaf & { kindLabel: string; expiry: string; dte: number }> =
    positions
      .map((p) => {
        const kindLabel =
          String(p.kind ?? "").toLowerCase() === "option"
            ? "Options"
            : "Futures";
        return {
          type: "leaf" as const,
          depth: 3,
          name: p.instrument_name,
          d: derive(p),
          isFuture: kindLabel === "Futures",
          kindLabel,
          expiry: expiryOf(p.instrument_name),
          dte: num(p.DTE),
        };
      })
      .sort((a, b) => a.dte - b.dte);

  const kindChildren: Group[] = [];
  for (const kindLabel of ["Options", "Futures"]) {
    const kindLeaves = leaves.filter((l) => l.kindLabel === kindLabel);
    if (!kindLeaves.length) continue;

    const expiryChildren: Group[] = [];
    const seen: string[] = [];
    for (const l of kindLeaves) if (!seen.includes(l.expiry)) seen.push(l.expiry);
    const flavor: Flavor = kindLabel === "Futures" ? "future" : "option";
    for (const expiry of seen) {
      const expLeaves = kindLeaves.filter((l) => l.expiry === expiry);
      expiryChildren.push({
        type: "group",
        id: `${kindLabel}/${expiry}`,
        depth: 2,
        label: expiry,
        count: expLeaves.length,
        flavor,
        agg: aggOf(expLeaves),
        children: expLeaves,
      });
    }
    kindChildren.push({
      type: "group",
      id: kindLabel,
      depth: 1,
      label: kindLabel,
      count: kindLeaves.length,
      flavor,
      agg: aggOf(kindLeaves),
      children: expiryChildren,
    });
  }

  return {
    type: "group",
    id: "BTC",
    depth: 0,
    label: "BTC",
    count: leaves.length,
    flavor: kindChildren.length > 1 ? "mixed" : (kindChildren[0]?.flavor ?? "mixed"),
    agg: aggOf(leaves),
    children: kindChildren,
  };
}

function signClass(v: number): string {
  if (!Number.isFinite(v) || v === 0) return "";
  return v > 0 ? "text-positive" : "text-negative";
}

export function PositionsTree({
  positions,
}: {
  positions: PositionRecord[];
}) {
  const tree = useMemo(() => buildTree(positions), [positions]);
  const [collapsed, setCollapsed] = useState<Set<string>>(new Set());

  if (!tree) {
    return (
      <p className="px-5 py-8 text-center text-sm text-muted">
        No open positions.
      </p>
    );
  }

  const toggle = (id: string) =>
    setCollapsed((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });

  const rows: TreeNode[] = [];
  const walk = (node: TreeNode) => {
    rows.push(node);
    if (node.type === "group" && !collapsed.has(node.id))
      node.children.forEach(walk);
  };
  walk(tree);

  return (
    <div className="overflow-x-auto">
      <table className="w-full border-collapse text-sm">
        <thead>
          <tr className="border-b border-border">
            <th className="sticky left-0 z-10 bg-surface px-3 py-2 text-left text-xs font-semibold uppercase tracking-wide text-muted">
              Instrument
            </th>
            {COLS.map((c) => (
              <th
                key={c.key}
                className="px-3 py-2 text-right text-xs font-semibold uppercase tracking-wide text-muted whitespace-nowrap"
              >
                {c.label}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((node, idx) => {
            const isGroup = node.type === "group";
            const depth = node.depth;
            return (
              <tr
                key={isGroup ? node.id : `${node.name}-${idx}`}
                className={cn(
                  "border-b border-border/60",
                  isGroup ? "bg-surface-2 font-semibold" : "hover:bg-surface-2/50",
                )}
              >
                <td
                  className={cn(
                    "sticky left-0 z-10 px-3 py-1.5 font-mono text-xs whitespace-nowrap",
                    isGroup ? "bg-surface-2" : "bg-surface",
                  )}
                  style={{ paddingLeft: 12 + depth * 18 }}
                >
                  {isGroup ? (
                    <button
                      type="button"
                      onClick={() => toggle(node.id)}
                      className="flex items-center gap-1 text-fg"
                    >
                      {collapsed.has(node.id) ? (
                        <ChevronRight className="h-3.5 w-3.5" />
                      ) : (
                        <ChevronDown className="h-3.5 w-3.5" />
                      )}
                      <span>
                        {node.label}{" "}
                        <span className="text-muted">({node.count})</span>
                      </span>
                    </button>
                  ) : (
                    <span className="text-fg">{node.name}</span>
                  )}
                </td>

                {COLS.map((c) => {
                  let raw: number | null;
                  if (isGroup) {
                    raw = c.onGroup
                      ? node.agg[c.key as SumKey]
                      : null;
                  } else {
                    raw = node.d[c.key] as number | null;
                  }
                  let text =
                    raw === null || raw === undefined ? "" : c.fmt(raw);
                  // Amount is a USD notional for futures ($ prefix), a contract
                  // count for options, and meaningless for the mixed BTC root.
                  if (c.key === "amount") {
                    if (node.type === "group" && node.flavor === "mixed") {
                      text = "";
                    } else {
                      const fut =
                        node.type === "group"
                          ? node.flavor === "future"
                          : node.isFuture;
                      if (text && fut) text = "$" + text;
                    }
                  }
                  const colorCls =
                    c.color && typeof raw === "number" ? signClass(raw) : "";
                  return (
                    <td
                      key={c.key}
                      className={cn(
                        "px-3 py-1.5 text-right tabular-nums whitespace-nowrap",
                        colorCls,
                      )}
                    >
                      {text}
                    </td>
                  );
                })}
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}
