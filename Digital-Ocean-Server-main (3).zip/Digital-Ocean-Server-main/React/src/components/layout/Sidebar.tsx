import { NavLink } from "react-router-dom";
import { Bitcoin, Lock } from "lucide-react";
import { cn } from "@/lib/utils";
import { PAGES } from "@/lib/pageMap";
import { useAuth } from "@/auth/AuthContext";

export function Sidebar({ onNavigate }: { onNavigate?: () => void }) {
  const { hasPage, user } = useAuth();
  const visible = PAGES.filter(
    (p) =>
      p.migrated &&
      hasPage(p.stem) &&
      (!p.operatorOnly || user?.role === "operator"),
  );

  return (
    <aside className="flex h-full w-64 flex-col border-r border-border bg-surface">
      <div className="flex items-center gap-2.5 px-5 py-4">
        <div className="rounded-lg bg-brand/15 p-1.5 text-brand">
          <Bitcoin className="h-5 w-5" />
        </div>
        <div className="leading-tight">
          <div className="text-sm font-semibold text-fg">BTC Options</div>
          <div className="text-[11px] text-muted">Trading Dashboard</div>
        </div>
      </div>

      <nav className="flex-1 space-y-0.5 overflow-y-auto px-3 pb-4">
        {visible.map((p) => {
          const Icon = p.icon;
          if (!p.migrated) {
            return (
              <div
                key={p.stem}
                className={cn(
                  "flex items-center gap-3 rounded-lg px-3 py-2 text-sm",
                  "cursor-not-allowed text-muted/60",
                )}
                title="Coming soon"
              >
                <Icon className="h-4 w-4 shrink-0" />
                <span className="truncate">{p.label}</span>
                <Lock className="ml-auto h-3 w-3 shrink-0" />
              </div>
            );
          }
          return (
            <NavLink
              key={p.stem}
              to={p.route}
              onClick={onNavigate}
              className={({ isActive }) =>
                cn(
                  "flex items-center gap-3 rounded-lg px-3 py-2 text-sm transition-colors",
                  isActive
                    ? "bg-brand/15 font-medium text-brand"
                    : "text-muted hover:bg-surface-2 hover:text-fg",
                )
              }
            >
              <Icon className="h-4 w-4 shrink-0" />
              <span className="truncate">{p.label}</span>
            </NavLink>
          );
        })}
      </nav>
    </aside>
  );
}
