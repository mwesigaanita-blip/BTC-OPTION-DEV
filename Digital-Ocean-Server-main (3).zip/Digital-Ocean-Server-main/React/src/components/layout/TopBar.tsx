import { useLocation } from "react-router-dom";
import { ExternalLink, LogOut, Menu } from "lucide-react";
import { Button } from "@/components/ui/Button";
import { Badge } from "@/components/ui/Badge";
import { ThemeToggle } from "./ThemeToggle";
import { useAuth } from "@/auth/AuthContext";
import { PAGE_BY_ROUTE } from "@/lib/pageMap";

const PAPER_DASHBOARD_URL = "https://paper.royaltrustinvestments.com";

export function TopBar({ onMenu }: { onMenu: () => void }) {
  const { user, logout } = useAuth();
  const { pathname } = useLocation();
  const page = PAGE_BY_ROUTE[pathname];

  return (
    <header className="flex h-14 items-center gap-3 border-b border-border bg-surface px-4">
      <Button
        variant="ghost"
        size="icon"
        className="lg:hidden"
        onClick={onMenu}
        aria-label="Open menu"
      >
        <Menu className="h-4 w-4" />
      </Button>

      <div className="text-sm font-medium text-fg">
        {page?.label ?? "Dashboard"}
      </div>

      <div className="ml-auto flex items-center gap-2">
        {user ? (
          <div className="hidden items-center gap-2 sm:flex">
            <span className="text-sm text-fg">{user.username}</span>
            <Badge tone={user.role === "operator" ? "brand" : "neutral"}>
              {user.role}
            </Badge>
          </div>
        ) : null}
        <a
          href={PAPER_DASHBOARD_URL}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex h-9 items-center gap-1.5 rounded-md border border-border bg-surface-2 px-3 text-sm font-medium text-fg transition-colors hover:bg-surface-3 hover:text-brand"
          title="Open the Paper Trading dashboard in a new tab"
        >
          <ExternalLink className="h-4 w-4" />
          <span className="hidden sm:inline">Paper Dashboard</span>
        </a>
        <ThemeToggle />
        <Button variant="ghost" size="icon" onClick={logout} aria-label="Log out">
          <LogOut className="h-4 w-4" />
        </Button>
      </div>
    </header>
  );
}
