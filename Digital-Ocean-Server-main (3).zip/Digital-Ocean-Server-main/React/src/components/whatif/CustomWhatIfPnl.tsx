import { useCallback, useMemo, useRef, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { RotateCcw } from "lucide-react";
import { fetchWhatIf } from "@/api/whatif";
import { fetchPositions } from "@/api/account";
import type { HypotheticalSpec } from "@/api/whatif";
import type { PositionRecord } from "@/types/api";
import { useDebounce } from "@/hooks/useDebounce";
import { useWebSocket } from "@/hooks/useWebSocket";
import {
  sumCurve,
  sumExpirationCurve,
  sumGreeks,
  zeroCrossings,
} from "@/lib/whatifCalc";
import { fmtUsd } from "@/lib/format";
import { PageHeader } from "@/components/shared/PageHeader";
import { LoadingState } from "@/components/shared/LoadingState";
import { ErrorState } from "@/components/shared/ErrorState";
import { PnlCurveChart } from "@/components/shared/PnlCurveChart";
import { Card, CardBody, CardHeader } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { Badge } from "@/components/ui/Badge";
import { BtcPriceControls } from "./BtcPriceControls";
import { SimSliders, DEFAULT_SIM, type SimParams } from "./SimSliders";
import { HypotheticalManager, type HypoItem } from "./HypotheticalManager";
import { WhatIfPositionsTable, type RowOverride } from "./WhatIfPositionsTable";
import { ScenarioGreeksPanel } from "./ScenarioGreeksPanel";
import { AccountEquityCard } from "./AccountEquityCard";

/** Custom What-If PnL simulator - isolated scenario state over the live book. */
export function CustomWhatIfPnl() {
  const qc = useQueryClient();

  // --- Isolated simulation state -------------------------------------------
  const [excluded, setExcluded] = useState<Set<string>>(new Set());
  const [overrides, setOverrides] = useState<Record<string, RowOverride>>({});
  const [hypotheticals, setHypotheticals] = useState<HypoItem[]>([]);
  const [sim, setSim] = useState<SimParams>(DEFAULT_SIM);
  const [btcOverride, setBtcOverride] = useState<number | null>(null);

  // --- Request (debounced) -------------------------------------------------
  const reqInputs = useMemo(
    () => ({
      range_pct: sim.rangePct,
      points: 121,
      iv_pct_shift: sim.ivPctShift,
      days_forward: sim.daysForward,
      annual_rate_shift_bps: sim.rateShiftBps,
      spot_override: btcOverride,
      overrides: Object.entries(overrides).map(([instrument_name, o]) => ({
        instrument_name,
        size: o.size,
        side: o.side,
      })),
      hypotheticals: hypotheticals.map(
        ({ id: _id, ...spec }): HypotheticalSpec => spec,
      ),
    }),
    [sim, btcOverride, overrides, hypotheticals],
  );
  const debouncedReq = useDebounce(reqInputs, 300);

  const q = useQuery({
    queryKey: ["whatif", JSON.stringify(debouncedReq)],
    queryFn: () => fetchWhatIf(debouncedReq),
    retry: false,
    placeholderData: (prev) => prev,
  });

  // Live positions - used to overlay avg/mark prices on the editor table.
  const positionsQ = useQuery({
    queryKey: ["positions-live"],
    queryFn: fetchPositions,
    refetchInterval: 5000,
    retry: false,
  });
  const positionsByName = useMemo<Record<string, PositionRecord>>(() => {
    const out: Record<string, PositionRecord> = {};
    for (const p of positionsQ.data?.positions ?? []) {
      out[p.instrument_name] = p;
    }
    return out;
  }, [positionsQ.data]);

  // --- Live refresh: a WS push nudges a refetch (throttled) ----------------
  const lastInv = useRef(0);
  const nudge = useCallback(() => {
    const now = Date.now();
    if (now - lastInv.current < 2500) return;
    lastInv.current = now;
    qc.invalidateQueries({ queryKey: ["whatif"] });
  }, [qc]);
  useWebSocket("/ws/positions", nudge);
  useWebSocket("/ws/account", nudge);
  useWebSocket("/ws/market", nudge);

  // --- Derived (client-side, instant) --------------------------------------
  const data = q.data;
  const liveSpot = data?.context.live_spot ?? 0;
  const equity = data?.context.equity_usd ?? null;
  const frozen = btcOverride !== null;
  const selectedPrice = btcOverride ?? liveSpot;

  const includedLegs = useMemo(
    () => (data?.legs ?? []).filter((L) => !excluded.has(L.instrument_name)),
    [data, excluded],
  );
  const summedCurve = useMemo(
    () => sumCurve(includedLegs, equity),
    [includedLegs, equity],
  );
  const summedExpirationCurve = useMemo(
    () => sumExpirationCurve(includedLegs, equity),
    [includedLegs, equity],
  );
  const breakEven = useMemo(() => zeroCrossings(summedCurve), [summedCurve]);
  const greeks = useMemo(() => sumGreeks(includedLegs), [includedLegs]);
  const scenarioPnl = useMemo(
    () => includedLegs.reduce((acc, L) => acc + (L.pnl_at_spot ?? 0), 0),
    [includedLegs],
  );

  // --- Timeline checkpoints from per-leg expiries --------------------------
  // `expiry_ms` is null for perps/futures - those don't contribute ticks (and
  // the timeline is hidden entirely when no options remain in the book).
  const timeline = useMemo(() => {
    const now = Date.now();
    const ticks = (data?.legs ?? [])
      .filter((L) => L.expiry_ms != null)
      .map((L) => {
        const ms = L.expiry_ms as number;
        return {
          days: (ms - now) / 86400000,
          label: new Date(ms).toLocaleDateString("en-GB", {
            day: "2-digit",
            month: "short",
            timeZone: "UTC",
          }),
          instrument: L.instrument_name,
        };
      })
      .filter((t) => t.days > 0)
      .sort((a, b) => a.days - b.days);
    const maxDays = ticks.length
      ? Math.max(ticks[ticks.length - 1].days * 1.05, 1)
      : 0;
    return { ticks, maxDays, nowMs: now };
  }, [data]);

  // --- Handlers ------------------------------------------------------------
  const toggle = useCallback((name: string) => {
    setExcluded((prev) => {
      const next = new Set(prev);
      if (next.has(name)) next.delete(name);
      else next.add(name);
      return next;
    });
  }, []);
  const toggleMany = useCallback((names: string[], include: boolean) => {
    setExcluded((prev) => {
      const next = new Set(prev);
      if (include) names.forEach((n) => next.delete(n));
      else names.forEach((n) => next.add(n));
      return next;
    });
  }, []);
  const editRow = useCallback((name: string, ov: RowOverride) => {
    setOverrides((prev) => ({ ...prev, [name]: ov }));
  }, []);
  const resetRow = useCallback((name: string) => {
    setOverrides((prev) => {
      const next = { ...prev };
      delete next[name];
      return next;
    });
  }, []);
  const addHypo = useCallback((spec: HypotheticalSpec) => {
    setHypotheticals((prev) => [
      ...prev,
      { ...spec, id: crypto.randomUUID() },
    ]);
  }, []);
  const removeHypo = useCallback((id: string) => {
    setHypotheticals((prev) => prev.filter((h) => h.id !== id));
  }, []);
  const reset = useCallback(() => {
    setExcluded(new Set());
    setOverrides({});
    setHypotheticals([]);
    setSim(DEFAULT_SIM);
    setBtcOverride(null);
  }, []);

  const dirty =
    frozen ||
    excluded.size > 0 ||
    Object.keys(overrides).length > 0 ||
    hypotheticals.length > 0 ||
    sim !== DEFAULT_SIM;

  return (
    <div className="space-y-5">
      <PageHeader
        title="Custom What-If PnL"
        description="Simulate BTC moves, IV shifts, time decay and position changes."
        actions={
          <Button
            variant={dirty ? "primary" : "secondary"}
            size="sm"
            onClick={reset}
            disabled={!dirty}
          >
            <RotateCcw className="h-3.5 w-3.5" />
            Reset Simulation
          </Button>
        }
      />

      {q.isLoading && !data ? (
        <LoadingState label="Building the scenario…" />
      ) : q.isError ? (
        <ErrorState
          message="Could not build the what-if scenario. Live positions may be unavailable."
          onRetry={() => q.refetch()}
        />
      ) : (
        <div className="space-y-4">
          {/* Row 1 - three control cards side by side */}
          <div className="grid gap-4 lg:grid-cols-3">
            <BtcPriceControls
              liveSpot={liveSpot}
              value={selectedPrice}
              frozen={frozen}
              onChange={(p) => setBtcOverride(Math.round(p))}
              onUnfreeze={() => setBtcOverride(null)}
            />
            <SimSliders
              sim={sim}
              onChange={setSim}
              timelineTicks={timeline.ticks}
              timelineMaxDays={timeline.maxDays}
              nowMs={timeline.nowMs}
            />
            <HypotheticalManager
              items={hypotheticals}
              onAdd={addHypo}
              onRemove={removeHypo}
              spotHint={liveSpot}
            />
          </div>

          {/* Row 2 - PnL curve full width with the equity panel inlined on the left */}
          <Card>
            <CardHeader
              title="What-If Payoff Curve"
              subtitle={
                frozen
                  ? `Curve re-centered on the frozen price ${fmtUsd(selectedPrice, 0)}`
                  : "Tracking the live BTC price"
              }
              action={
                <Badge tone={frozen ? "warning" : "positive"}>
                  {frozen ? "Frozen BTC" : "Live BTC"}
                </Badge>
              }
            />
            <CardBody>
              <div className="grid gap-4 lg:grid-cols-[minmax(220px,260px)_1fr]">
                <div className="space-y-3">
                  <div className="text-xs font-semibold uppercase tracking-wide text-muted">
                    Account Equity
                  </div>
                  <AccountEquityCard
                    liveEquity={equity}
                    scenarioPnl={scenarioPnl}
                    currentPnl={data?.context.current_pnl_usd ?? 0}
                    selectedPrice={selectedPrice}
                    frozen={frozen}
                    embedded
                    layout="vertical"
                  />
                </div>
                <div>
                  {summedCurve.length ? (
                    <PnlCurveChart
                      curve={summedCurve}
                      expirationCurve={summedExpirationCurve}
                      breakEven={breakEven}
                      spot={selectedPrice || undefined}
                    />
                  ) : (
                    <p className="py-10 text-center text-sm text-muted">
                      All positions excluded - include at least one.
                    </p>
                  )}
                  <p className="mt-3 text-xs text-muted">
                    Included {includedLegs.length}/{data?.legs.length ?? 0} ·
                    IV {sim.ivPctShift >= 0 ? "+" : ""}
                    {sim.ivPctShift}% · +{sim.daysForward.toFixed(1)}d · Break-even{" "}
                    {breakEven.length
                      ? breakEven
                          .map((b) => {
                            const ref = selectedPrice;
                            if (ref && Number.isFinite(ref) && ref > 0) {
                              const pct = ((b - ref) / ref) * 100;
                              const sign = pct >= 0 ? "+" : "";
                              return `${fmtUsd(b, 0)} (${sign}${pct.toFixed(2)}%)`;
                            }
                            return fmtUsd(b, 0);
                          })
                          .join(", ")
                      : "-"}
                  </p>
                </div>
              </div>
            </CardBody>
          </Card>

          {/* Row 3 - scenario greeks, full width */}
          <ScenarioGreeksPanel greeks={greeks} atPrice={selectedPrice} />

          {/* Row 4 - portfolio editor / positions table, full width */}
          <Card>
            <CardHeader
              title="Portfolio Editor"
              subtitle="Untick to exclude · edit size/side on live positions"
            />
            <CardBody className="px-0">
              <WhatIfPositionsTable
                legs={data?.legs ?? []}
                positionsByName={positionsByName}
                excluded={excluded}
                overrides={overrides}
                onToggle={toggle}
                onToggleMany={toggleMany}
                onEdit={editRow}
                onResetRow={resetRow}
              />
            </CardBody>
          </Card>
        </div>
      )}
    </div>
  );
}
