import { useEffect, useRef, useState } from "react";
import { ArrowDownRight, ArrowUpRight, Minus } from "lucide-react";
import { Card, CardBody, CardHeader } from "@/components/ui/Card";
import { Badge } from "@/components/ui/Badge";
import { cn } from "@/lib/utils";
import { fmtUsd } from "@/lib/format";

function signCls(v: number): string {
  if (!Number.isFinite(v) || v === 0) return "";
  return v > 0 ? "text-positive" : "text-negative";
}

function ArrowFor({ v }: { v: number }) {
  if (!Number.isFinite(v) || v === 0) return <Minus className="h-4 w-4" />;
  return v > 0 ? (
    <ArrowUpRight className="h-4 w-4" />
  ) : (
    <ArrowDownRight className="h-4 w-4" />
  );
}

/** Quick flash on numeric tick. */
function useFlash(value: number) {
  const [flash, setFlash] = useState<"up" | "down" | null>(null);
  const prev = useRef<number | null>(null);
  useEffect(() => {
    if (prev.current != null && Number.isFinite(value) && value !== prev.current) {
      setFlash(value > prev.current ? "up" : "down");
      const t = setTimeout(() => setFlash(null), 600);
      prev.current = value;
      return () => clearTimeout(t);
    }
    prev.current = value;
  }, [value]);
  return flash;
}

/**
 * Live Account Equity card for the Custom What-If tab. Mirrors the live
 * equity that drives the scenario PnL anchor, plus the scenario delta and
 * the projected equity after applying the included legs at the selected
 * price.
 */
export function AccountEquityCard({
  liveEquity,
  scenarioPnl,
  currentPnl,
  selectedPrice,
  frozen,
  embedded = false,
  layout = "horizontal",
}: {
  liveEquity: number | null;
  /** Sum of per-leg `pnl_at_spot` for included legs. Absolute scenario PnL,
   * with the position's current unrealized PnL already baked in via the
   * backend anchor. */
  scenarioPnl: number;
  /** Current unrealized PnL across the *real* positions (no hypotheticals),
   * straight from the backend's `context.current_pnl_usd`. Already inside
   * `liveEquity`. Subtract it from `scenarioPnl` to get the true delta. */
  currentPnl: number;
  selectedPrice: number;
  frozen: boolean;
  /** When true, render without the surrounding Card chrome (header, body
   * padding). Used when embedding this panel inside another Card. */
  embedded?: boolean;
  /** Stat tile arrangement. */
  layout?: "horizontal" | "vertical";
}) {
  const live = Number.isFinite(liveEquity as number) ? (liveEquity as number) : 0;
  const change = scenarioPnl - currentPnl;
  const projected = live + change;
  const pct = live > 0 ? (change / live) * 100 : 0;

  const flash = useFlash(live);

  const stats = (
    <div
      className={cn(
        "gap-3",
        layout === "vertical"
          ? "flex flex-col"
          : "grid grid-cols-1 sm:grid-cols-3",
      )}
    >
      <div
        className={cn(
          "rounded-lg bg-surface-2 p-3 transition-colors",
          flash === "up" && "bg-positive/15",
          flash === "down" && "bg-negative/15",
        )}
      >
        <div className="text-xs text-muted">Live Equity</div>
        <div className="mt-1 text-lg font-semibold tabular-nums text-fg">
          {liveEquity == null ? "-" : fmtUsd(live, 0)}
        </div>
      </div>

      <div className="rounded-lg bg-surface-2 p-3">
        <div className="text-xs text-muted">Scenario Δ vs Now</div>
        <div
          className={cn(
            "mt-1 flex items-center gap-1 text-lg font-semibold tabular-nums",
            signCls(change),
          )}
        >
          <ArrowFor v={change} />
          {`${change >= 0 ? "+" : ""}${fmtUsd(change, 0)}`}
        </div>
        <div className={cn("text-xs tabular-nums", signCls(pct))}>
          {Number.isFinite(pct) && pct !== 0
            ? `${pct >= 0 ? "+" : ""}${pct.toFixed(2)}%`
            : "0.00%"}
        </div>
      </div>

      <div className="rounded-lg bg-surface-2 p-3">
        <div className="text-xs text-muted">Projected Equity</div>
        <div
          className={cn(
            "mt-1 text-lg font-semibold tabular-nums",
            signCls(change),
          )}
        >
          {fmtUsd(projected, 0)}
        </div>
        <div className="mt-1 text-[0.7rem] text-muted">
          Live + Δ (no double-counting unrealized PnL)
        </div>
      </div>
    </div>
  );

  if (embedded) return stats;

  return (
    <Card>
      <CardHeader
        title="Account Equity"
        subtitle={
          frozen
            ? `Projected at frozen BTC ${fmtUsd(selectedPrice, 0)}`
            : "Live tick + scenario projection"
        }
        action={
          <Badge tone={frozen ? "warning" : "positive"}>
            {frozen ? "Frozen BTC" : "Live"}
          </Badge>
        }
      />
      <CardBody>{stats}</CardBody>
    </Card>
  );
}
