import { Card, CardBody, CardHeader } from "@/components/ui/Card";
import { Slider } from "@/components/ui/Slider";
import { TimelineSlider, type TimelineTick } from "./TimelineSlider";

export interface SimParams {
  rangePct: number;
  /** Multiplicative IV shift in percent (-70...+200 in the visible slider;
   * the backend accepts down to -95). new_sigma = old_sigma * (1 + pct/100). */
  ivPctShift: number;
  /** Days-forward (fractional). Drives the timeline slider. */
  daysForward: number;
  rateShiftBps: number;
}

export const DEFAULT_SIM: SimParams = {
  rangePct: 50,
  ivPctShift: 0,
  daysForward: 0,
  rateShiftBps: 0,
};

/** IV %, timeline-to-expiry, rate and curve-range sliders. */
export function SimSliders({
  sim,
  onChange,
  timelineTicks,
  timelineMaxDays,
  nowMs,
}: {
  sim: SimParams;
  onChange: (s: SimParams) => void;
  /** Per-option expiry checkpoints. When empty the timeline row is hidden. */
  timelineTicks?: TimelineTick[];
  timelineMaxDays?: number;
  nowMs?: number;
}) {
  const showTimeline =
    !!timelineTicks && timelineTicks.length > 0 && (timelineMaxDays ?? 0) > 0;
  return (
    <Card>
      <CardHeader
        title="Scenario Controls"
        subtitle="Volatility, time decay and curve range"
      />
      <CardBody className="space-y-4">
        <Slider
          label="Implied volatility shift"
          value={sim.ivPctShift}
          min={-70}
          max={200}
          step={1}
          onChange={(v) => onChange({ ...sim, ivPctShift: v })}
          format={(v) => `${v >= 0 ? "+" : ""}${v}%`}
          hint="Multiplicative shift on implied vol. At the floor extrinsic collapses → dynamic ≈ static. Static curve unaffected."
        />
        {showTimeline ? (
          <TimelineSlider
            value={sim.daysForward}
            onChange={(v) => onChange({ ...sim, daysForward: v })}
            maxDays={timelineMaxDays!}
            ticks={timelineTicks!}
            nowMs={nowMs}
          />
        ) : null}
        <Slider
          label="Annualized rate"
          value={sim.rateShiftBps}
          min={-500}
          max={500}
          step={10}
          onChange={(v) => onChange({ ...sim, rateShiftBps: v })}
          format={(v) => `${v >= 0 ? "+" : ""}${v} bps`}
          hint="Risk-free rate fed to Black-Scholes. Only affects the dynamic curve."
        />
        <Slider
          label="Curve range"
          value={sim.rangePct}
          min={10}
          max={80}
          step={5}
          onChange={(v) => onChange({ ...sim, rangePct: v })}
          format={(v) => `±${v}%`}
          hint="BTC price span swept by the payoff curve."
        />
      </CardBody>
    </Card>
  );
}
