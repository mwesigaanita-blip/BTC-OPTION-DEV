import { Card, CardBody, CardHeader } from "@/components/ui/Card";
import { cn } from "@/lib/utils";
import { fmtNum, fmtUsd } from "@/lib/format";
import type { LegGreeks } from "@/types/api";

function GreekStat({
  label,
  value,
  digits,
}: {
  label: string;
  value: number;
  digits: number;
}) {
  const tone =
    value === 0
      ? "text-fg"
      : value > 0
        ? "text-positive"
        : "text-negative";
  return (
    <div className="rounded-lg bg-surface-2 p-3">
      <div className="text-xs text-muted">{label}</div>
      <div className={cn("mt-1 text-lg font-semibold tabular-nums", tone)}>
        {fmtNum(value, digits)}
      </div>
    </div>
  );
}

/** Portfolio greeks for the scenario, summed from the included legs. */
export function ScenarioGreeksPanel({
  greeks,
  atPrice,
}: {
  greeks: LegGreeks;
  atPrice: number;
}) {
  return (
    <Card>
      <CardHeader
        title="Scenario Greeks"
        subtitle={`Evaluated at BTC ${fmtUsd(atPrice, 0)} - included positions only`}
      />
      <CardBody>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
          <GreekStat label="Delta (BTC)" value={greeks.delta} digits={4} />
          <GreekStat label="Gamma" value={greeks.gamma} digits={6} />
          <GreekStat label="Theta (USD/day)" value={greeks.theta} digits={2} />
          <GreekStat label="Vega (USD/pt)" value={greeks.vega} digits={2} />
        </div>
      </CardBody>
    </Card>
  );
}
