import { useEffect, useState } from "react";
import { Card, CardBody, CardHeader } from "@/components/ui/Card";
import { Badge } from "@/components/ui/Badge";
import { Button } from "@/components/ui/Button";
import { Input } from "@/components/ui/Input";
import { Slider } from "@/components/ui/Slider";
import { fmtUsd } from "@/lib/format";

interface Props {
  liveSpot: number;
  value: number; // currently selected BTC price
  frozen: boolean;
  onChange: (price: number) => void;
  onUnfreeze: () => void;
}

/** Three synchronized BTC-price controls: price slider, % slider, exact box. */
export function BtcPriceControls({
  liveSpot,
  value,
  frozen,
  onChange,
  onUnfreeze,
}: Props) {
  const lo = Math.max(1000, Math.round(liveSpot * 0.4));
  const hi = Math.round(liveSpot * 1.6) || 250000;
  const pct = liveSpot > 0 ? (value / liveSpot - 1) * 100 : 0;
  const sliderVal = Math.min(Math.max(value, lo), hi);

  // Exact-price box: local draft committed on blur / Enter so typing is smooth.
  const [draft, setDraft] = useState(String(Math.round(value)));
  useEffect(() => setDraft(String(Math.round(value))), [value]);
  const commit = () => {
    const n = Number(draft);
    if (Number.isFinite(n) && n > 0) onChange(n);
    else setDraft(String(Math.round(value)));
  };

  return (
    <Card>
      <CardHeader
        title="BTC Price"
        subtitle={frozen ? "Frozen at a simulation price" : "Tracking the live market"}
        action={
          <Badge tone={frozen ? "warning" : "positive"}>
            {frozen ? "Frozen" : "Live"}
          </Badge>
        }
      />
      <CardBody className="space-y-4">
        <Slider
          label="BTC price (USD)"
          value={sliderVal}
          min={lo}
          max={hi}
          step={50}
          onChange={onChange}
          format={(v) => fmtUsd(v, 0)}
        />
        <Slider
          label="% move from live price"
          value={Number(pct.toFixed(2))}
          min={-60}
          max={60}
          step={0.5}
          onChange={(p) => onChange(liveSpot * (1 + p / 100))}
          format={(v) => `${v >= 0 ? "+" : ""}${v.toFixed(1)}%`}
        />
        <div className="space-y-1.5">
          <label className="text-xs font-medium text-muted">
            Exact price (type a value)
          </label>
          <Input
            type="number"
            value={draft}
            step={100}
            min={1000}
            onChange={(e) => setDraft(e.target.value)}
            onBlur={commit}
            onKeyDown={(e) => {
              if (e.key === "Enter") commit();
            }}
          />
        </div>
        {frozen ? (
          <Button
            variant="secondary"
            size="sm"
            className="w-full"
            onClick={onUnfreeze}
          >
            Return to live price ({fmtUsd(liveSpot, 0)})
          </Button>
        ) : null}
      </CardBody>
    </Card>
  );
}
