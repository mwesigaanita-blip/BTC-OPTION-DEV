import { useEffect, useMemo, useRef, useState } from "react";
import { ChevronDown, ChevronRight, RotateCcw } from "lucide-react";
import { cn } from "@/lib/utils";
import { Badge } from "@/components/ui/Badge";
import { fmtNum } from "@/lib/format";
import type { PositionRecord, WhatIfLeg } from "@/types/api";

export interface RowOverride {
  size: number;
  side: "buy" | "sell";
}

interface Props {
  legs: WhatIfLeg[];
  positionsByName?: Record<string, PositionRecord>;
  excluded: Set<string>;
  overrides: Record<string, RowOverride>;
  onToggle: (name: string) => void;
  onToggleMany: (names: string[], include: boolean) => void;
  onEdit: (name: string, ov: RowOverride) => void;
  onResetRow: (name: string) => void;
}

// Formatters: empty string for missing values (matches PositionsTree).
const fBtc = (v: unknown): string => {
  const n = Number(v);
  return Number.isFinite(n) ? `฿${n.toFixed(4)}` : "";
};
const fUsd = (v: unknown): string => {
  const n = Number(v);
  if (!Number.isFinite(n)) return "";
  return `$${n.toLocaleString("en-US", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  })}`;
};

const signCls = (v: number) =>
  v === 0 ? "" : v > 0 ? "text-positive" : "text-negative";

/** Expiry token from an instrument name (BTC-22MAY26-73000-P → "22MAY26"). */
function expiryOf(name: string): string {
  const parts = (name || "").toUpperCase().split("-");
  if (parts.length >= 2 && parts[1] && parts[1] !== "PERPETUAL") return parts[1];
  return "PERPETUAL";
}

/** Sort key for an expiry token (parses "DDMMMYY" → epoch). PERPETUAL last. */
function expirySortKey(token: string): number {
  if (token === "PERPETUAL") return Number.POSITIVE_INFINITY;
  const m = /^(\d{1,2})([A-Z]{3})(\d{2})$/.exec(token);
  if (!m) return Number.POSITIVE_INFINITY;
  const day = Number(m[1]);
  const months: Record<string, number> = {
    JAN: 0, FEB: 1, MAR: 2, APR: 3, MAY: 4, JUN: 5,
    JUL: 6, AUG: 7, SEP: 8, OCT: 9, NOV: 10, DEC: 11,
  };
  const mo = months[m[2]];
  if (mo == null) return Number.POSITIVE_INFINITY;
  const year = 2000 + Number(m[3]);
  return Date.UTC(year, mo, day);
}

/** Editable size cell - local draft committed on blur / Enter. */
function SizeCell({
  value,
  onCommit,
}: {
  value: number;
  onCommit: (v: number) => void;
}) {
  const [draft, setDraft] = useState(String(value));
  useEffect(() => setDraft(String(value)), [value]);
  const commit = () => {
    const n = Number(draft);
    if (Number.isFinite(n) && n > 0) onCommit(n);
    else setDraft(String(value));
  };
  return (
    <input
      type="number"
      value={draft}
      min={0}
      step={1}
      onChange={(e) => setDraft(e.target.value)}
      onBlur={commit}
      onKeyDown={(e) => {
        if (e.key === "Enter") (e.target as HTMLInputElement).blur();
      }}
      className="w-20 rounded border border-border bg-surface-2 px-1.5 py-0.5 text-right text-sm tabular-nums focus:outline-none focus:ring-1 focus:ring-brand"
    />
  );
}

/** Tri-state checkbox - `state` "all" | "none" | "some" (some = indeterminate). */
function TriCheckbox({
  state,
  onChange,
  className,
  ariaLabel,
}: {
  state: "all" | "none" | "some";
  onChange: (nextChecked: boolean) => void;
  className?: string;
  ariaLabel?: string;
}) {
  const ref = useRef<HTMLInputElement>(null);
  useEffect(() => {
    if (ref.current) ref.current.indeterminate = state === "some";
  }, [state]);
  return (
    <input
      ref={ref}
      type="checkbox"
      aria-label={ariaLabel}
      checked={state === "all"}
      onChange={(e) => onChange(e.currentTarget.checked)}
      className={cn("h-4 w-4 accent-brand", className)}
    />
  );
}

// ---------------------------------------------------------------------------
// Tree model
// ---------------------------------------------------------------------------

interface LeafRow {
  type: "leaf";
  depth: number;
  leg: WhatIfLeg;
  side: "buy" | "sell";
  qty: number;
  modified: boolean;
  greeks: { delta: number; gamma: number; theta: number; vega: number };
  pnl: number;
  isFuture: boolean;
  isHypothetical: boolean;
  avgBtc: number | null;
  avgUsd: number | null;
  markBtc: number | null;
  markUsd: number | null;
  roiPct: number | null;
}

type Flavor = "option" | "future" | "mixed";

interface GroupRow {
  type: "group";
  id: string;
  depth: number;
  label: string;
  flavor: Flavor;
  leafNames: string[]; // membership for the group-level checkbox
  agg: { pnl: number; delta: number; gamma: number; theta: number; vega: number };
  totalCount: number;
  includedCount: number;
  children: TreeNode[];
}
type TreeNode = LeafRow | GroupRow;

function asNumOrNull(x: unknown): number | null {
  const n = Number(x);
  return Number.isFinite(n) ? n : null;
}

function makeLeaf(
  leg: WhatIfLeg,
  overrides: Record<string, RowOverride>,
  positionsByName: Record<string, PositionRecord>,
  depth: number,
): LeafRow {
  const ov = overrides[leg.instrument_name];
  const side: "buy" | "sell" = ov?.side ?? (leg.size >= 0 ? "buy" : "sell");
  const qty = ov ? ov.size : Math.abs(leg.size);
  const greeks = leg.greeks ?? { delta: 0, gamma: 0, theta: 0, vega: 0 };
  const isFuture = String(leg.kind).toLowerCase() !== "option";
  const pos = positionsByName[leg.instrument_name];
  // Prefer the scenario-computed BS mark from the backend response. When the
  // user resets the simulation (no IV/time/range shifts and no overrides),
  // the BS mark at the live spot ≈ the live Deribit mark, so the column
  // effectively "goes back" to the live value automatically.
  const scenarioMarkBtc = asNumOrNull(leg.mark_price_btc);
  const scenarioMarkUsd = asNumOrNull(leg.mark_price_usd);
  const avgUsd = pos ? asNumOrNull(pos.avg_price_usd) : null;

  // Scenario ROI: compute from the scenario PnL + cost basis (avg entry price
  // × current contract count). This recomputes every time the scenario fires
  // a new fetch - which is exactly what the user wants. Falls back to the
  // live snapshot pnl_pct when we can't derive it (e.g. hypothetical legs
  // that have no historical entry price).
  let roiPct: number | null = null;
  const sizeAbs = Math.abs(Number(leg.size) || 0);
  if (avgUsd != null && avgUsd > 0 && sizeAbs > 0) {
    const costBasisUsd = avgUsd * sizeAbs;
    const pnl = Number(leg.pnl_at_spot);
    if (Number.isFinite(pnl) && costBasisUsd > 0) {
      roiPct = (pnl / costBasisUsd) * 100;
    }
  } else if (pos) {
    roiPct = asNumOrNull(pos.pnl_pct);
  }

  return {
    type: "leaf",
    depth,
    leg,
    side,
    qty,
    modified: Boolean(ov),
    greeks,
    pnl: leg.pnl_at_spot,
    isFuture,
    isHypothetical: Boolean(leg.is_hypothetical),
    avgBtc: pos ? asNumOrNull(pos.avg_price_btc) : null,
    avgUsd,
    markBtc:
      scenarioMarkBtc != null && scenarioMarkBtc > 0
        ? scenarioMarkBtc
        : pos
          ? asNumOrNull(pos.mark_price_btc)
          : null,
    markUsd:
      scenarioMarkUsd != null && scenarioMarkUsd > 0
        ? scenarioMarkUsd
        : pos
          ? asNumOrNull(pos.mark_usd)
          : null,
    roiPct,
  };
}

const fRoi = (v: unknown): string => {
  const n = Number(v);
  return Number.isFinite(n) ? `${n.toFixed(1)}%` : "";
};

function aggOf(
  leaves: LeafRow[],
  excluded: Set<string>,
): GroupRow["agg"] & { includedCount: number } {
  let pnl = 0,
    delta = 0,
    gamma = 0,
    theta = 0,
    vega = 0,
    includedCount = 0;
  for (const lf of leaves) {
    if (excluded.has(lf.leg.instrument_name)) continue;
    pnl += lf.pnl;
    delta += lf.greeks.delta;
    gamma += lf.greeks.gamma;
    theta += lf.greeks.theta;
    vega += lf.greeks.vega;
    includedCount += 1;
  }
  return { pnl, delta, gamma, theta, vega, includedCount };
}

function checkboxState(
  names: string[],
  excluded: Set<string>,
): "all" | "none" | "some" {
  if (names.length === 0) return "none";
  let inc = 0;
  for (const n of names) if (!excluded.has(n)) inc += 1;
  if (inc === 0) return "none";
  if (inc === names.length) return "all";
  return "some";
}

function buildTree(
  legs: WhatIfLeg[],
  overrides: Record<string, RowOverride>,
  excluded: Set<string>,
  positionsByName: Record<string, PositionRecord>,
): GroupRow | null {
  if (!legs.length) return null;
  const leaves = legs.map((l) => makeLeaf(l, overrides, positionsByName, 3));

  const kindChildren: GroupRow[] = [];
  for (const kindLabel of ["Options", "Futures"] as const) {
    const kindLeaves = leaves.filter((l) =>
      kindLabel === "Options" ? !l.isFuture : l.isFuture,
    );
    if (!kindLeaves.length) continue;

    // Group by expiry, preserving first-seen order then sorting by date.
    const byExpiry = new Map<string, LeafRow[]>();
    for (const lf of kindLeaves) {
      const exp = expiryOf(lf.leg.instrument_name);
      const list = byExpiry.get(exp) ?? [];
      list.push(lf);
      byExpiry.set(exp, list);
    }
    const expiries = Array.from(byExpiry.keys()).sort(
      (a, b) => expirySortKey(a) - expirySortKey(b),
    );

    const flavor: Flavor = kindLabel === "Futures" ? "future" : "option";
    const expChildren: GroupRow[] = expiries.map((exp) => {
      const expLeaves = byExpiry.get(exp) ?? [];
      const a = aggOf(expLeaves, excluded);
      const names = expLeaves.map((l) => l.leg.instrument_name);
      return {
        type: "group",
        id: `${kindLabel}/${exp}`,
        depth: 2,
        label: exp,
        flavor,
        leafNames: names,
        agg: { pnl: a.pnl, delta: a.delta, gamma: a.gamma, theta: a.theta, vega: a.vega },
        totalCount: expLeaves.length,
        includedCount: a.includedCount,
        children: expLeaves,
      };
    });

    const a = aggOf(kindLeaves, excluded);
    const names = kindLeaves.map((l) => l.leg.instrument_name);
    kindChildren.push({
      type: "group",
      id: kindLabel,
      depth: 1,
      label: kindLabel,
      flavor,
      leafNames: names,
      agg: { pnl: a.pnl, delta: a.delta, gamma: a.gamma, theta: a.theta, vega: a.vega },
      totalCount: kindLeaves.length,
      includedCount: a.includedCount,
      children: expChildren,
    });
  }

  const a = aggOf(leaves, excluded);
  const names = leaves.map((l) => l.leg.instrument_name);
  return {
    type: "group",
    id: "BTC",
    depth: 0,
    label: "BTC",
    flavor: kindChildren.length > 1 ? "mixed" : kindChildren[0]?.flavor ?? "mixed",
    leafNames: names,
    agg: { pnl: a.pnl, delta: a.delta, gamma: a.gamma, theta: a.theta, vega: a.vega },
    totalCount: leaves.length,
    includedCount: a.includedCount,
    children: kindChildren,
  };
}

// ---------------------------------------------------------------------------
// Render
// ---------------------------------------------------------------------------

export function WhatIfPositionsTable({
  legs,
  positionsByName = {},
  excluded,
  overrides,
  onToggle,
  onToggleMany,
  onEdit,
  onResetRow,
}: Props) {
  const tree = useMemo(
    () => buildTree(legs, overrides, excluded, positionsByName),
    [legs, overrides, excluded, positionsByName],
  );
  const [collapsed, setCollapsed] = useState<Set<string>>(new Set());

  if (!tree) {
    return (
      <p className="px-5 py-8 text-center text-sm text-muted">
        No positions to display.
      </p>
    );
  }

  const toggleCollapse = (id: string) =>
    setCollapsed((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });

  const rows: TreeNode[] = [];
  const walk = (node: TreeNode) => {
    rows.push(node);
    if (node.type === "group" && !collapsed.has(node.id))
      node.children.forEach(walk);
  };
  walk(tree);

  return (
    <div className="overflow-x-auto">
      <table className="w-full border-collapse text-sm">
        <thead>
          <tr className="border-b border-border">
            <th className="w-10 px-2 py-2" />
            <th className="sticky left-10 z-10 bg-surface px-3 py-2 text-left text-xs font-semibold uppercase tracking-wide text-muted">
              Instrument
            </th>
            <th className="px-3 py-2 text-left text-xs font-semibold uppercase tracking-wide text-muted">
              Side
            </th>
            <th className="px-3 py-2 text-right text-xs font-semibold uppercase tracking-wide text-muted">
              Size
            </th>
            {["Avg Price", "Avg Price (USD)", "Mark Price", "Mark Price (USD)", "ROI", "PnL @ scenario", "Delta", "Gamma", "Theta", "Vega"].map((h) => (
              <th
                key={h}
                className="px-3 py-2 text-right text-xs font-semibold uppercase tracking-wide text-muted whitespace-nowrap"
              >
                {h}
              </th>
            ))}
            <th className="w-8 px-2 py-2" />
          </tr>
        </thead>
        <tbody>
          {rows.map((node) => {
            if (node.type === "group") {
              const state = checkboxState(node.leafNames, excluded);
              return (
                <tr
                  key={node.id}
                  className="border-b border-border/60 bg-surface-2 font-semibold"
                >
                  <td className="px-2 py-1.5 text-center">
                    <TriCheckbox
                      state={state}
                      ariaLabel={`Toggle all under ${node.label}`}
                      onChange={(nextChecked) =>
                        onToggleMany(node.leafNames, nextChecked)
                      }
                    />
                  </td>
                  <td
                    className="sticky left-10 z-10 bg-surface-2 px-3 py-1.5 font-mono text-xs whitespace-nowrap"
                    style={{ paddingLeft: 12 + node.depth * 18 }}
                  >
                    <button
                      type="button"
                      onClick={() => toggleCollapse(node.id)}
                      className="flex items-center gap-1 text-fg"
                    >
                      {collapsed.has(node.id) ? (
                        <ChevronRight className="h-3.5 w-3.5" />
                      ) : (
                        <ChevronDown className="h-3.5 w-3.5" />
                      )}
                      <span>
                        {node.label}{" "}
                        <span className="text-muted">
                          ({node.includedCount}/{node.totalCount})
                        </span>
                      </span>
                    </button>
                  </td>
                  {/* Side / Size / Avg / Mark / ROI - blank on group rows */}
                  <td className="px-3 py-1.5" />
                  <td className="px-3 py-1.5" />
                  <td className="px-3 py-1.5" />
                  <td className="px-3 py-1.5" />
                  <td className="px-3 py-1.5" />
                  <td className="px-3 py-1.5" />
                  <td className="px-3 py-1.5" />
                  <td
                    className={cn(
                      "px-3 py-1.5 text-right tabular-nums",
                      signCls(node.agg.pnl),
                    )}
                  >
                    {fmtNum(node.agg.pnl, 0)}
                  </td>
                  <td className="px-3 py-1.5 text-right tabular-nums">
                    {fmtNum(node.agg.delta, 4)}
                  </td>
                  <td className="px-3 py-1.5 text-right tabular-nums">
                    {fmtNum(node.agg.gamma, 6)}
                  </td>
                  <td className="px-3 py-1.5 text-right tabular-nums">
                    {fmtNum(node.agg.theta, 2)}
                  </td>
                  <td className="px-3 py-1.5 text-right tabular-nums">
                    {fmtNum(node.agg.vega, 2)}
                  </td>
                  <td className="px-2 py-1.5" />
                </tr>
              );
            }

            // ---------- Leaf ----------
            const name = node.leg.instrument_name;
            const isExcluded = excluded.has(name);
            const editable = !node.isHypothetical;
            return (
              <tr
                key={name}
                className={cn(
                  "border-b border-border/60 hover:bg-surface-2/50",
                  isExcluded && "opacity-40",
                )}
              >
                <td className="px-2 py-1.5 text-center">
                  <input
                    type="checkbox"
                    checked={!isExcluded}
                    onChange={() => onToggle(name)}
                    className="h-4 w-4 accent-brand"
                  />
                </td>
                <td
                  className="sticky left-10 z-10 bg-surface px-3 py-1.5 font-mono text-xs text-fg whitespace-nowrap"
                  style={{ paddingLeft: 12 + node.depth * 18 }}
                >
                  {node.isHypothetical ? "🧪 " : ""}
                  {name}
                  {node.modified ? (
                    <Badge tone="warning" className="ml-2">
                      edited
                    </Badge>
                  ) : null}
                </td>
                <td className="px-3 py-1.5">
                  {editable ? (
                    <button
                      type="button"
                      onClick={() =>
                        onEdit(name, {
                          size: node.qty,
                          side: node.side === "buy" ? "sell" : "buy",
                        })
                      }
                      className={cn(
                        "rounded border px-2 py-0.5 text-xs font-medium",
                        node.side === "buy"
                          ? "border-positive/30 bg-positive/15 text-positive"
                          : "border-negative/30 bg-negative/15 text-negative",
                      )}
                    >
                      {node.side}
                    </button>
                  ) : (
                    <Badge tone={node.side === "buy" ? "positive" : "negative"}>
                      {node.side}
                    </Badge>
                  )}
                </td>
                <td className="px-3 py-1.5 text-right">
                  {editable ? (
                    <SizeCell
                      value={node.qty}
                      onCommit={(v) => onEdit(name, { size: v, side: node.side })}
                    />
                  ) : (
                    <span className="tabular-nums">{fmtNum(node.qty, 2)}</span>
                  )}
                </td>
                <td className="px-3 py-1.5 text-right tabular-nums whitespace-nowrap">
                  {fBtc(node.avgBtc)}
                </td>
                <td className="px-3 py-1.5 text-right tabular-nums whitespace-nowrap">
                  {fUsd(node.avgUsd)}
                </td>
                <td className="px-3 py-1.5 text-right tabular-nums whitespace-nowrap">
                  {fBtc(node.markBtc)}
                </td>
                <td className="px-3 py-1.5 text-right tabular-nums whitespace-nowrap">
                  {fUsd(node.markUsd)}
                </td>
                <td
                  className={cn(
                    "px-3 py-1.5 text-right tabular-nums whitespace-nowrap",
                    typeof node.roiPct === "number" ? signCls(node.roiPct) : "",
                  )}
                >
                  {fRoi(node.roiPct)}
                </td>
                <td
                  className={cn(
                    "px-3 py-1.5 text-right tabular-nums",
                    signCls(node.pnl),
                  )}
                >
                  {fmtNum(node.pnl, 0)}
                </td>
                <td className="px-3 py-1.5 text-right tabular-nums">
                  {fmtNum(node.greeks.delta, 4)}
                </td>
                <td className="px-3 py-1.5 text-right tabular-nums">
                  {fmtNum(node.greeks.gamma, 6)}
                </td>
                <td className="px-3 py-1.5 text-right tabular-nums">
                  {fmtNum(node.greeks.theta, 2)}
                </td>
                <td className="px-3 py-1.5 text-right tabular-nums">
                  {fmtNum(node.greeks.vega, 2)}
                </td>
                <td className="px-2 py-1.5 text-center">
                  {editable && node.modified ? (
                    <button
                      type="button"
                      onClick={() => onResetRow(name)}
                      className="text-muted hover:text-fg"
                      aria-label="Reset row"
                    >
                      <RotateCcw className="h-3.5 w-3.5" />
                    </button>
                  ) : null}
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}
