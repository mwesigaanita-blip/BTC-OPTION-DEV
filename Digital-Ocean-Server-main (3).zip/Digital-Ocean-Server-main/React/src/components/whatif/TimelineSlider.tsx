import { useMemo } from "react";

export interface TimelineTick {
  /** Days from "now" (positive, fractional). */
  days: number;
  /** Short date label, e.g. "29 May". */
  label: string;
  /** Instrument name for the tooltip / aria. */
  instrument: string;
}

interface Props {
  value: number;
  onChange: (v: number) => void;
  /** Upper bound of the slider in days (typically max(expiry) + 5%). */
  maxDays: number;
  ticks: TimelineTick[];
  /** Optional reference time (UTC ms) so labels stay consistent across re-renders. */
  nowMs?: number;
}

const DATE_FMT = new Intl.DateTimeFormat("en-GB", {
  day: "2-digit",
  month: "short",
  hour: "2-digit",
  minute: "2-digit",
  timeZone: "UTC",
});

/** Group ticks falling within ~1% of the track width into a single visual marker. */
function clusterTicks(
  ticks: TimelineTick[],
  maxDays: number,
): { days: number; instruments: string[]; label: string }[] {
  if (!ticks.length) return [];
  const tol = Math.max(maxDays * 0.01, 0.25); // at least 6 hours
  const sorted = [...ticks].sort((a, b) => a.days - b.days);
  const out: { days: number; instruments: string[]; label: string }[] = [];
  for (const t of sorted) {
    const last = out[out.length - 1];
    if (last && t.days - last.days <= tol) {
      last.instruments.push(t.instrument);
    } else {
      out.push({ days: t.days, instruments: [t.instrument], label: t.label });
    }
  }
  return out;
}

/** Deribit-style timeline: continuous scrub + click-to-snap expiry checkpoints. */
export function TimelineSlider({
  value,
  onChange,
  maxDays,
  ticks,
  nowMs,
}: Props) {
  const safeMax = Math.max(maxDays, 1);
  const now = nowMs ?? Date.now();

  const clustered = useMemo(
    () => clusterTicks(ticks, safeMax),
    [ticks, safeMax],
  );

  const pctOf = (d: number) =>
    Math.max(0, Math.min(100, (d / safeMax) * 100));

  const selectedDate = useMemo(() => {
    const ms = now + value * 86400000;
    return DATE_FMT.format(new Date(ms)) + " UTC";
  }, [now, value]);

  return (
    <div className="space-y-1.5">
      <div className="flex items-center justify-between gap-2">
        <label className="text-xs font-medium text-muted">Time forward</label>
        <span className="text-sm font-semibold tabular-nums text-fg">
          +{value.toFixed(1)} d
          <span className="ml-2 text-[11px] font-normal text-muted">
            {selectedDate}
          </span>
        </span>
      </div>

      {/* Tick label row */}
      <div className="relative h-4">
        {clustered.map((c) => (
          <div
            key={`lbl-${c.days}`}
            className="absolute top-0 -translate-x-1/2 text-[10px] text-muted whitespace-nowrap"
            style={{ left: `${pctOf(c.days)}%` }}
            title={c.instruments.join("\n")}
          >
            {c.label}
            {c.instruments.length > 1 ? ` ·${c.instruments.length}` : ""}
          </div>
        ))}
      </div>

      {/* Track + range input + tick markers */}
      <div className="relative">
        <input
          type="range"
          min={0}
          max={safeMax}
          step={Math.max(safeMax / 2000, 0.05)}
          value={value}
          onChange={(e) => onChange(Number(e.target.value))}
          className="h-1.5 w-full cursor-pointer appearance-none rounded-full bg-surface-2 accent-brand"
          aria-label="Time forward in days"
        />
        {/* Tick markers — clickable, snap thumb to that exact day count. */}
        {clustered.map((c) => (
          <button
            key={`tk-${c.days}`}
            type="button"
            onClick={() => onChange(c.days)}
            title={`${c.instruments.join(" · ")}\n+${c.days.toFixed(2)} d`}
            aria-label={`Snap to ${c.label}`}
            className="absolute top-1/2 h-3 w-[3px] -translate-x-1/2 -translate-y-1/2 rounded-sm bg-brand opacity-70 hover:opacity-100"
            style={{ left: `${pctOf(c.days)}%` }}
          />
        ))}
      </div>

      <div className="flex justify-between text-[10px] text-muted">
        <span>Now</span>
        <span>+{safeMax.toFixed(0)} d</span>
      </div>
    </div>
  );
}
