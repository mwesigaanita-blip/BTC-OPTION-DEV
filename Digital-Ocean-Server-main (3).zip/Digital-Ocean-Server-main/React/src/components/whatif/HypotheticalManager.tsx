import { useMemo, useState, type ReactNode } from "react";
import { useQuery } from "@tanstack/react-query";
import { Plus, Trash2 } from "lucide-react";
import { Card, CardBody, CardHeader } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { Input } from "@/components/ui/Input";
import { fmtUsd } from "@/lib/format";
import type { HypotheticalSpec } from "@/api/whatif";
import {
  fetchOptionInstruments,
  type OptionExpiry,
  type OptionInstrument,
} from "@/api/instruments";

export interface HypoItem extends HypotheticalSpec {
  id: string;
}

const SELECT =
  "h-11 w-full rounded-lg border border-border bg-surface-2 px-2.5 text-sm text-fg focus:outline-none focus:ring-2 focus:ring-brand";

function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div className="space-y-1">
      <label className="block text-[11px] font-medium uppercase tracking-wide text-muted">
        {label}
      </label>
      {children}
    </div>
  );
}

function symbolLabel(inst: OptionInstrument): string {
  return `${fmtUsd(inst.strike, 0)} ${inst.option_type === "C" ? "Call" : "Put"}`;
}

/** Add / remove hypothetical option positions for the scenario. */
export function HypotheticalManager({
  items,
  onAdd,
  onRemove,
}: {
  items: HypoItem[];
  onAdd: (s: HypotheticalSpec) => void;
  onRemove: (id: string) => void;
  /** Reserved for future ATM defaulting in the UI. */
  spotHint?: number;
}) {
  const instrumentsQ = useQuery({
    queryKey: ["option-instruments", "BTC"],
    queryFn: () => fetchOptionInstruments("BTC"),
    staleTime: 10 * 60_000,
    refetchOnWindowFocus: false,
  });

  const expiries = instrumentsQ.data?.expiries ?? [];

  const [expiryLabel, setExpiryLabel] = useState<string>("");
  const [instrumentName, setInstrumentName] = useState<string>("");
  const [side, setSide] = useState<"buy" | "sell">("buy");
  const [size, setSize] = useState("1");

  const activeExpiry: OptionExpiry | undefined = useMemo(
    () => expiries.find((e) => e.expiry_label === expiryLabel),
    [expiries, expiryLabel],
  );

  const symbolOptions = activeExpiry?.instruments ?? [];

  const onExpiryChange = (v: string) => {
    setExpiryLabel(v);
    setInstrumentName("");
  };

  const canAdd =
    !!instrumentName && Number(size) > 0 && (side === "buy" || side === "sell");

  const add = () => {
    if (!canAdd) return;
    onAdd({ instrument_name: instrumentName, side, size: Number(size) });
  };

  return (
    <Card>
      <CardHeader
        title="Simulated Positions"
        subtitle="Pick a real Deribit option · live mark IV"
      />
      <CardBody className="space-y-3">
        {instrumentsQ.isLoading ? (
          <p className="text-xs text-muted">Loading available instruments…</p>
        ) : instrumentsQ.isError ? (
          <p className="text-xs text-negative">
            Could not load instruments.{" "}
            <button
              type="button"
              className="underline"
              onClick={() => instrumentsQ.refetch()}
            >
              Retry
            </button>
          </p>
        ) : (
          <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-2">
            <Field label="Expiry">
              <select
                value={expiryLabel}
                onChange={(e) => onExpiryChange(e.target.value)}
                className={SELECT}
              >
                <option value="">Select expiry…</option>
                {expiries.map((e) => (
                  <option key={e.expiry_label} value={e.expiry_label}>
                    {e.expiry_iso || e.expiry_label}
                  </option>
                ))}
              </select>
            </Field>
            <Field label="Symbol">
              <select
                value={instrumentName}
                onChange={(e) => setInstrumentName(e.target.value)}
                className={SELECT}
                disabled={!activeExpiry}
              >
                <option value="">
                  {activeExpiry ? "Select strike…" : "Pick expiry first"}
                </option>
                {symbolOptions.map((inst) => (
                  <option
                    key={inst.instrument_name}
                    value={inst.instrument_name}
                  >
                    {symbolLabel(inst)}
                  </option>
                ))}
              </select>
            </Field>
            <Field label="Position Side">
              <select
                value={side}
                onChange={(e) => setSide(e.target.value as "buy" | "sell")}
                className={SELECT}
              >
                <option value="buy">Buy</option>
                <option value="sell">Sell</option>
              </select>
            </Field>
            <Field label="Contract Size">
              <Input
                type="number"
                value={size}
                min={0.1}
                step={0.1}
                onChange={(e) => setSize(e.target.value)}
                placeholder="Contracts"
              />
            </Field>
          </div>
        )}
        <Button
          size="sm"
          className="w-full"
          onClick={add}
          disabled={!canAdd || instrumentsQ.isLoading}
        >
          <Plus className="h-4 w-4" />
          Add simulated position
        </Button>

        {items.length ? (
          <div className="space-y-1.5">
            {items.map((it) => (
              <div
                key={it.id}
                className="flex items-center justify-between rounded-lg bg-surface-2 px-3 py-2 text-xs"
              >
                <span className="font-mono text-fg">
                  {it.side === "buy" ? "+" : "-"}
                  {it.size} · {it.instrument_name}
                </span>
                <button
                  type="button"
                  onClick={() => onRemove(it.id)}
                  className="text-negative hover:opacity-80"
                  aria-label="Remove"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                </button>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-xs text-muted">No simulated positions added.</p>
        )}
      </CardBody>
    </Card>
  );
}
