export type HvSource = "saved" | "deribit" | "computed" | null;
export type IvSource = "saved" | "deribit" | null;

export interface HvIvRow {
  ts_ms: number;
  ts_utc: string;
  hv_pct: number | null;
  hv_source: HvSource;
  iv_pct: number | null;
  iv_source: IvSource;
}

export interface HvIvResponse {
  resolution: "1D" | "1H";
  from_ms: number | null;
  to_ms: number | null;
  rows: HvIvRow[];
  fetched_at: number;
}

// ---- Vol dashboard (Hedgeye-style panel) --------------------------------

export interface VolStatsBlock {
  latest: number | null;
  asof: string | null;
  pct_3m: number | null;
  pct_1y: number | null;
  min_1y: number | null;
  p25_1y: number | null;
  median_1y: number | null;
  p75_1y: number | null;
  max_1y: number | null;
  mean_1y: number | null;
  count: number;
}

export interface VolBtcSnapshot {
  rvol_30d: number | null;
  ivol_30d: number | null;
  ivol_premium_pct: number | null;
}

export interface VolDashboardSeries {
  rvol_30d: { date: string; value: number }[];
  rvol_90d: { date: string; value: number }[];
  ivol_30d: { date: string; value: number }[];
  ivol_premium: { date: string; value: number }[];
}

export interface VolDashboardResponse {
  asof: string | null;
  lookback_days: number;
  btc: VolBtcSnapshot;
  rvol_30d_stats: VolStatsBlock;
  rvol_90d_stats: VolStatsBlock;
  series: VolDashboardSeries;
  fetched_at: number;
}
