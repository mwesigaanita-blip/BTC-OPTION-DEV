/** TypeScript shapes for the backend_api JSON responses. */

export type Role = "operator" | "viewer";

export interface AuthUser {
  username: string;
  role: Role | string;
  pages: string[];
}

export interface LoginResponse {
  access_token: string;
  token_type: string;
  expires_at: number;
  user: AuthUser;
}

export type DataSource = "live" | "snapshot";

/** One currency's portfolio block (BTC / USDT / USDC). */
export interface PerCurrency {
  currency: string;
  balance?: number;
  equity?: number;
  available_funds?: number;
  initial_margin?: number;
  maintenance_margin?: number;
  margin_balance?: number;
  index_price_usd?: number;
  equity_usd?: number;
  available_funds_usd?: number;
  capital_basis?: string;
  capital_usd?: number;
  im_pct_of_equity?: number | null;
  mm_pct_of_equity?: number | null;
  im_pct_of_mb?: number | null;
  mm_pct_of_mb?: number | null;
  portfolio_vega?: number;
  theta_btc?: number;
  theta_usd?: number;
  net_delta_btc?: number;
  [k: string]: unknown;
}

/** Assembled account payload - shape from `assemble_account_payload`. */
export interface AccountPayload {
  multi_currency?: boolean;
  per_currency?: Record<string, PerCurrency>;
  currency?: string;
  total_equity_usd?: number;
  btc_changes?: Record<string, unknown>;
  dvol_changes?: Record<string, unknown>;
  [k: string]: unknown;
}

/** Portfolio greeks - keys from `compute_account_greeks_from_positions`. */
export interface AccountGreeks {
  delta_btc?: number;
  gamma?: number;
  theta_usd_per_day?: number;
  vega_usd?: number;
  volatility?: number;
  [k: string]: unknown;
}

export interface AccountOverviewResponse {
  source: DataSource;
  updated_at: string | null;
  account: AccountPayload | null;
  greeks: AccountGreeks;
}

export interface PositionRecord {
  instrument_name: string;
  kind: string;
  direction: string;
  side: string;
  size: number;
  qty: number;
  avg_price_btc?: number;
  avg_price_usd?: number;
  mark_price_btc?: number;
  mark_usd?: number;
  index_price?: number;
  total_profit_loss?: number;
  pnl_usd_total?: number;
  pnl_pct?: number | null;
  delta?: number;
  gamma?: number;
  theta?: number;
  vega?: number;
  initial_margin?: number;
  maintenance_margin?: number;
  strike?: number;
  expiry?: string;
  DTE?: number;
  [k: string]: unknown;
}

export interface PositionsResponse {
  source: DataSource;
  updated_at: string | null;
  positions: PositionRecord[];
}

export interface MarketResponse {
  updated_at: string | null;
  market: Record<string, number>;
}

export interface EquityHistoryResponse {
  current_usd: number | null;
  as_of: string | null;
  changes: Record<string, number | null>;
}

export interface PnlCurvePoint {
  btc_pct: number;
  btc_price: number;
  pnl_usd: number;
  pnl_pct: number | null;
  severity?: string;
}

export interface PnlCurveResponse {
  context: Record<string, unknown>;
  curve: PnlCurvePoint[];
  break_even: number[];
  legs: unknown[];
}

// ---- Custom What-If simulator ---------------------------------------------

export interface LegGreeks {
  delta: number;
  gamma: number;
  theta: number;
  vega: number;
}

export interface WhatIfLeg {
  instrument_name: string;
  kind: string;
  size: number;
  is_hypothetical: boolean;
  curve: { btc_price: number; pnl_usd: number }[];
  /** Static expiration payoff per spot point (intrinsic only). Same length
   * and btc_price grid as `curve`; independent of IV / time / rate sliders. */
  expiration_curve: { btc_price: number; pnl_usd: number }[];
  /** UTC ms timestamp of this leg's expiry (parsed from instrument_name).
   * Null for perpetuals / futures / unparseable names. Used by the timeline
   * slider on the What-If page to draw per-position checkpoints. */
  expiry_ms: number | null;
  pnl_at_spot: number;
  break_even: number[];
  greeks: LegGreeks;
  /** BS-priced mark at the scenario's evaluation point. USD per contract
   * (`mark_price_usd`) and the BTC-native equivalent (`mark_price_btc`,
   * which is `mark_price_usd / scenario_btc_price`). These replace the
   * live Deribit quote in the Portfolio Editor's Mark Price columns so
   * the displayed mark reflects the scenario, not the live tape. */
  mark_price_usd?: number;
  mark_price_btc?: number;
}

export interface WhatIfContext {
  btc_index_price: number;
  equity_usd: number | null;
  position_count: number;
  hypothetical_count: number;
  current_pnl_usd: number;
  iv_points: number;
  days_forward: number;
  live_spot: number;
  spot_frozen: boolean;
  [k: string]: unknown;
}

export interface WhatIfResponse {
  context: WhatIfContext;
  curve: PnlCurvePoint[];
  expiration_curve: PnlCurvePoint[];
  break_even: number[];
  legs: WhatIfLeg[];
}

// ---- Positions History ----------------------------------------------------

export interface PerfWindow {
  pct: number;
  abs: number;
}

export interface PortfolioTsRow {
  date: string;
  total_portfolio_usd: number | null;
  total_portfolio_btc: number | null;
  pnl_total_usd: number | null;
  pnl_float_usd: number | null;
  pnl_real_usd: number | null;
  pnl_total_btc: number | null;
  open_positions: number | null;
  contracts: number | null;
  delta_sum: number | null;
  gamma_sum: number | null;
  theta_sum: number | null;
  vega_sum: number | null;
  flow_val: number | null;
  event_type: string;
  index_price: number | null;
  min_dte: number | null;
  updated_at: string | null;
}

export interface PortfolioHistoryResponse {
  timeseries: PortfolioTsRow[];
  performance: Record<string, PerfWindow>;
  dates: string[];
  latest: PortfolioTsRow | null;
}

export interface DayKpis {
  pnl_total_usd?: number;
  pnl_float_usd?: number;
  pnl_real_usd?: number;
  total_qty?: number;
  total_pnl_btc?: number;
}

export interface DayPositionsResponse {
  date: string;
  updated_at: string | null;
  kpis: DayKpis;
  positions: Record<string, unknown>[];
}

// ---- BTC Prices -----------------------------------------------------------

export interface BtcPriceRow {
  date: string;
  open: number;
  high: number;
  low: number;
  close: number;
  change: number | null;
  percent_change: number | null;
  volume: number | null;
}

export interface BtcPricesSummary {
  last_date: string | null;
  total_rows: number;
  latest: BtcPriceRow | null;
}

export interface BtcPricesSeriesResponse {
  rows: BtcPriceRow[];
}

// ---- Daily Quant ----------------------------------------------------------

export type QuantHorizon =
  | "1D"
  | "5D"
  | "1M"
  | "3M"
  | "6M"
  | "1Y"
  | "QTD"
  | "YTD"
  | "52W_HIGH_PCT"
  | "52W_LOW_PCT";

export type QuantReturnRow = Partial<Record<QuantHorizon, number | null>>;

export interface QuantSnapshot {
  as_of: string;
  price: number;
  market_cap: number;
  circulating_supply: number;
  change_1d_pct: number | null;
  usd_vol_dd_pct: number | null;
  coin_vol_dd_pct: number | null;
  rvol_1m: number | null;
  ivol_1m: number | null;
  ivol_premium_pct: number | null;
  fetched_at: number;
}

export interface QuantReturnsResponse {
  as_of: string | null;
  horizons: QuantHorizon[];
  assets: string[];
  rows: Record<string, QuantReturnRow>;
  fetched_at: number;
}

export interface QuantRelativeResponse {
  base: string;
  horizons: QuantHorizon[];
  rows: Record<string, QuantReturnRow>;
  fetched_at: number;
}

// ---- BTC ETF Flows --------------------------------------------------------

export interface EtfFlowsDailyRow {
  date: string;
  flows: Record<string, number | null>;
  total: number | null;
}

export interface EtfFlowsHistoryPoint {
  date: string;
  total: number | null;
}

// ---- Correlation matrix ---------------------------------------------------

export interface QuantCorrelationWindow {
  label: string;
  window_days: number;
  asof: string | null;
  matrix: Record<string, Record<string, number | null>>;
  sample_counts: Record<string, Record<string, number>>;
}

export interface QuantCorrelationResponse {
  assets: string[];
  windows: QuantCorrelationWindow[];
  fetched_at: number;
}

export interface QuantRollingCorrelationStats {
  min: number | null;
  max: number | null;
  mean: number | null;
  latest: number | null;
}

export interface QuantRollingCorrelationSeries {
  dates: string[];
  values: (number | null)[];
  stats: QuantRollingCorrelationStats;
}

// ---- Crypto volume panel --------------------------------------------------

export interface VolumeMetrics {
  dd_pct: number | null;
  vs_1m_pct: number | null;
  vs_3m_pct: number | null;
  yy_qtrly_pct: number | null;
}

export interface VolumeAssetRow {
  asof?: string | null;
  coin?: VolumeMetrics;
  usd?: VolumeMetrics;
  coin_today?: number | null;
  usd_today?: number | null;
  count?: number;
  error?: string;
}

export type VolumeMetricKey = "dd_pct" | "vs_1m_pct" | "vs_3m_pct" | "yy_qtrly_pct";

export interface CryptoVolumeResponse {
  assets: string[];
  metrics: VolumeMetricKey[];
  rows: Record<string, VolumeAssetRow>;
  asof: string | null;
  fetched_at: number;
}

export interface QuantRollingCorrelationsResponse {
  base: string;
  window: number;
  partners: string[];
  history_days: number;
  series: Record<string, QuantRollingCorrelationSeries>;
  asof: string | null;
  fetched_at: number;
}

export interface EtfFlowsResponse {
  tickers: string[];
  rows: EtfFlowsDailyRow[];
  totals: Record<string, number | null>;
  history: EtfFlowsHistoryPoint[];
  count: number;
  fetched_at: number;
}
