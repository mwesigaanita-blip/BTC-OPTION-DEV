/**
 * Deterministic Black-Scholes pricing in TypeScript. Mirrors the Python
 * implementation in `hedge_engine/risk/stress/pricing_bs.py` so the React
 * UI can recompute marks instantly under user scenario inputs without an
 * extra backend round-trip per row.
 *
 * - `spot`, `strike` in USD
 * - `tYears` in years (e.g. days / 365.25)
 * - `iv` in decimal (0.65 for 65%)
 * - `r` continuous risk-free rate (decimal, default 0)
 * Returns the option premium in USD. Divide by `spot` to get the BTC-native
 * price Deribit uses for BTC options.
 */
export function bsPriceUsd({
  spot,
  strike,
  tYears,
  iv,
  r = 0,
  optionType,
}: {
  spot: number;
  strike: number;
  tYears: number;
  iv: number;
  r?: number;
  optionType: "call" | "put";
}): number {
  const s = Number(spot);
  const k = Number(strike);
  const t = Number(tYears);
  const sigma = Number(iv);
  const rr = Number(r) || 0;
  if (!(s > 0) || !(k > 0)) return 0;

  if (!(t > 0) || !(sigma > 0)) {
    const intrinsic =
      optionType === "call" ? Math.max(0, s - k) : Math.max(0, k - s);
    return intrinsic;
  }

  const sqrtT = Math.sqrt(t);
  const d1 = (Math.log(s / k) + (rr + 0.5 * sigma * sigma) * t) / (sigma * sqrtT);
  const d2 = d1 - sigma * sqrtT;
  const df = Math.exp(-rr * t);
  const Nd1 = stdNormCdf(d1);
  const Nd2 = stdNormCdf(d2);

  const price =
    optionType === "call"
      ? s * Nd1 - k * df * Nd2
      : k * df * stdNormCdf(-d2) - s * stdNormCdf(-d1);
  return Math.max(0, price);
}

/** Standard normal CDF via Abramowitz & Stegun 7.1.26 (5-term, ~1e-7). */
export function stdNormCdf(x: number): number {
  // Use the erf-based identity: N(x) = 0.5 * (1 + erf(x / sqrt(2)))
  return 0.5 * (1 + erf(x / Math.SQRT2));
}

function erf(x: number): number {
  // Abramowitz & Stegun 7.1.26 - max abs error ~1.5e-7
  const a1 = 0.254829592;
  const a2 = -0.284496736;
  const a3 = 1.421413741;
  const a4 = -1.453152027;
  const a5 = 1.061405429;
  const p = 0.3275911;
  const sign = x < 0 ? -1 : 1;
  const ax = Math.abs(x);
  const t = 1 / (1 + p * ax);
  const y =
    1 -
    (((((a5 * t + a4) * t) + a3) * t + a2) * t + a1) * t * Math.exp(-ax * ax);
  return sign * y;
}

/** Years remaining from `now` to a UTC ms timestamp. Clamped at >= 0. */
export function yearsUntil(expirationTimestampMs: number, nowMs = Date.now()): number {
  if (!Number.isFinite(expirationTimestampMs)) return 0;
  const ms = expirationTimestampMs - nowMs;
  if (ms <= 0) return 0;
  return ms / (365.25 * 24 * 3600 * 1000);
}
