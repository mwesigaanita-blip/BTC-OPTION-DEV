/** Display formatters - keep number rendering consistent across pages. */

export function fmtUsd(x: unknown, digits = 2): string {
  const n = Number(x);
  if (!Number.isFinite(n)) return "-";
  return n.toLocaleString("en-US", {
    style: "currency",
    currency: "USD",
    minimumFractionDigits: digits,
    maximumFractionDigits: digits,
  });
}

export function fmtNum(x: unknown, digits = 2): string {
  const n = Number(x);
  if (!Number.isFinite(n)) return "-";
  return n.toLocaleString("en-US", {
    minimumFractionDigits: digits,
    maximumFractionDigits: digits,
  });
}

export function fmtPct(x: unknown, digits = 2): string {
  const n = Number(x);
  if (!Number.isFinite(n)) return "-";
  return `${n.toFixed(digits)}%`;
}

export function fmtSignedPct(x: unknown, digits = 2): string {
  const n = Number(x);
  if (!Number.isFinite(n)) return "-";
  return `${n >= 0 ? "+" : ""}${n.toFixed(digits)}%`;
}

/** Seconds-ago label from an ISO-8601 timestamp. */
export function ageLabel(iso: string | null | undefined): string {
  if (!iso) return "no data";
  const ts = new Date(iso.replace("Z", "+00:00")).getTime();
  if (!Number.isFinite(ts)) return "no data";
  const sec = Math.max(0, Math.round((Date.now() - ts) / 1000));
  if (sec < 60) return `${sec}s ago`;
  if (sec < 3600) return `${Math.round(sec / 60)}m ago`;
  return `${Math.round(sec / 3600)}h ago`;
}
