import type { LegGreeks, PnlCurvePoint, WhatIfLeg } from "@/types/api";

/** Sum the per-leg PnL curves of the included legs into a portfolio curve. */
export function sumCurve(
  legs: WhatIfLeg[],
  equityUsd: number | null,
): PnlCurvePoint[] {
  if (!legs.length || !legs[0].curve?.length) return [];
  const n = legs[0].curve.length;
  const out: PnlCurvePoint[] = [];
  for (let i = 0; i < n; i++) {
    let pnl = 0;
    for (const L of legs) pnl += L.curve[i]?.pnl_usd ?? 0;
    out.push({
      btc_pct: 0,
      btc_price: legs[0].curve[i]?.btc_price ?? 0,
      pnl_usd: Math.round(pnl * 100) / 100,
      pnl_pct: equityUsd ? (pnl / equityUsd) * 100 : null,
    });
  }
  return out;
}

/** Sum the per-leg static-expiration curves into a portfolio expiration curve. */
export function sumExpirationCurve(
  legs: WhatIfLeg[],
  equityUsd: number | null,
): PnlCurvePoint[] {
  if (!legs.length || !legs[0].expiration_curve?.length) return [];
  const n = legs[0].expiration_curve.length;
  const out: PnlCurvePoint[] = [];
  for (let i = 0; i < n; i++) {
    let pnl = 0;
    for (const L of legs) pnl += L.expiration_curve?.[i]?.pnl_usd ?? 0;
    out.push({
      btc_pct: 0,
      btc_price: legs[0].expiration_curve[i]?.btc_price ?? 0,
      pnl_usd: Math.round(pnl * 100) / 100,
      pnl_pct: equityUsd ? (pnl / equityUsd) * 100 : null,
    });
  }
  return out;
}

/** Sum greeks across the included legs. */
export function sumGreeks(legs: WhatIfLeg[]): LegGreeks {
  return legs.reduce<LegGreeks>(
    (a, L) => ({
      delta: a.delta + (L.greeks?.delta ?? 0),
      gamma: a.gamma + (L.greeks?.gamma ?? 0),
      theta: a.theta + (L.greeks?.theta ?? 0),
      vega: a.vega + (L.greeks?.vega ?? 0),
    }),
    { delta: 0, gamma: 0, theta: 0, vega: 0 },
  );
}

/** BTC prices where the curve crosses zero PnL (linear interpolation). */
export function zeroCrossings(curve: PnlCurvePoint[]): number[] {
  const out: number[] = [];
  for (let i = 1; i < curve.length; i++) {
    const y0 = curve[i - 1].pnl_usd;
    const y1 = curve[i].pnl_usd;
    if (y0 === 0) {
      out.push(curve[i - 1].btc_price);
    } else if (y0 < 0 !== y1 < 0 && y1 !== y0) {
      const t = -y0 / (y1 - y0);
      out.push(
        Math.round(
          curve[i - 1].btc_price +
            t * (curve[i].btc_price - curve[i - 1].btc_price),
        ),
      );
    }
  }
  return out;
}
