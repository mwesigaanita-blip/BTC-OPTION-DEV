/** RFC-4180 cell escaping: wrap in quotes if it contains a comma, quote, or newline. */
function escapeCell(v: unknown): string {
  if (v === null || v === undefined) return "";
  const s = typeof v === "string" ? v : String(v);
  if (/[",\r\n]/.test(s)) return `"${s.replace(/"/g, '""')}"`;
  return s;
}

/** Build a CSV string from rows + column keys (preserves column order). */
export function rowsToCsv<T extends Record<string, unknown>>(
  rows: T[],
  columns: string[],
): string {
  const header = columns.map(escapeCell).join(",");
  const body = rows
    .map((r) => columns.map((c) => escapeCell(r[c])).join(","))
    .join("\r\n");
  return body ? `${header}\r\n${body}` : header;
}

/** Trigger a browser download of `content` as `filename` (text/csv). */
export function downloadCsv(filename: string, content: string): void {
  // BOM so Excel renders UTF-8 correctly.
  const blob = new Blob(["﻿", content], { type: "text/csv;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}
