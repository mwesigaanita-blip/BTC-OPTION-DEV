import {
  Activity,
  BarChart3,
  Bot,
  Brain,
  CalendarClock,
  ClipboardList,
  DollarSign,
  Gauge,
  History,
  LayoutDashboard,
  LineChart,
  Receipt,
  ShieldAlert,
  SlidersHorizontal,
  Sparkles,
  Users,
  Wallet,
  type LucideIcon,
} from "lucide-react";

/**
 * The single source of truth for navigation. `stem` MUST match the
 * `Streamlit/pages/*.py` file stem so existing users' `pages` grants
 * (operator/viewer access control) keep working unchanged.
 */
export interface PageDef {
  stem: string;
  label: string;
  route: string;
  icon: LucideIcon;
  phase: number;
  migrated: boolean;
  operatorOnly?: boolean;
}

export const PAGES: PageDef[] = [
  { stem: "Account_Overview", label: "Account Overview", route: "/account-overview", icon: LayoutDashboard, phase: 1, migrated: true },
  { stem: "Positions_History", label: "Positions History", route: "/positions-history", icon: History, phase: 2, migrated: true },
  { stem: "BTC_Prices", label: "BTC Prices", route: "/btc-prices", icon: LineChart, phase: 2, migrated: true },
  { stem: "Volatility", label: "Volatility (HV vs IV)", route: "/volatility", icon: Activity, phase: 2, migrated: true },
  { stem: "Model_Decisions_History", label: "Model Decisions History", route: "/model-decisions-history", icon: ClipboardList, phase: 2, migrated: false },
  { stem: "Decision_Board", label: "Decision Board", route: "/decision-board", icon: BarChart3, phase: 2, migrated: true },
  { stem: "WS_Layer_Health", label: "WS Layer Health", route: "/ws-layer-health", icon: Activity, phase: 2, migrated: true },
  { stem: "X_Sentiment", label: "X Sentiment", route: "/x-sentiment", icon: Sparkles, phase: 2, migrated: false },
  { stem: "Hedge_Engine", label: "Hedge Engine", route: "/hedge-engine", icon: Gauge, phase: 3, migrated: true },
  { stem: "MM_IM_Simulator", label: "MM / IM Simulator", route: "/mm-im-simulator", icon: SlidersHorizontal, phase: 3, migrated: true },
  { stem: "RTI_Portfolio_Management", label: "RTI Portfolio Management", route: "/rti-portfolio-management", icon: Wallet, phase: 3, migrated: true },
  { stem: "Portfolio_Analysis_Bot", label: "Portfolio Analysis Bot", route: "/portfolio-analysis-bot", icon: Bot, phase: 3, migrated: true },
  { stem: "AI_Models", label: "AI Models", route: "/ai-models", icon: Brain, phase: 4, migrated: false },
  { stem: "AI_Models_Scheduler", label: "AI Models Scheduler", route: "/ai-models-scheduler", icon: CalendarClock, phase: 4, migrated: false },
  { stem: "Live_Options_Scheduler", label: "Live Options Scheduler", route: "/live-options-scheduler", icon: CalendarClock, phase: 4, migrated: true },
  { stem: "MM_Alerts", label: "MM Alerts Bot", route: "/mm-alerts", icon: ShieldAlert, phase: 4, migrated: true },
  { stem: "Trading_Fees", label: "Trading Fees", route: "/trading-fees", icon: Receipt, phase: 4, migrated: true },
  { stem: "LLM_Fees", label: "LLM Cost", route: "/llm-fees", icon: DollarSign, phase: 4, migrated: true },
  { stem: "User_Management", label: "User Management", route: "/user-management", icon: Users, phase: 5, migrated: true, operatorOnly: true },
];

export const PAGE_BY_ROUTE: Record<string, PageDef> = Object.fromEntries(
  PAGES.map((p) => [p.route, p]),
);
