import { Navigate, useLocation } from "react-router-dom";
import { useAuth } from "./AuthContext";
import { AccessDenied } from "@/pages/AccessDeniedPage";
import { LoadingState } from "@/components/shared/LoadingState";

interface Props {
  /** Page stem for access control; omit for routes any logged-in user can see. */
  pageStem?: string;
  operatorOnly?: boolean;
  children: React.ReactNode;
}

/** Route guard - gates on authentication, page grant and operator role. */
export function ProtectedRoute({ pageStem, operatorOnly, children }: Props) {
  const { user, ready, hasPage } = useAuth();
  const location = useLocation();

  if (!ready) return <LoadingState label="Loading…" full />;

  if (!user) {
    return <Navigate to="/login" replace state={{ from: location.pathname }} />;
  }

  if (operatorOnly && user.role !== "operator") {
    return <AccessDenied reason="This page is restricted to operators." />;
  }

  if (pageStem && !hasPage(pageStem)) {
    return <AccessDenied reason="You do not have access to this page." />;
  }

  return <>{children}</>;
}
