import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import { fetchMe, login as apiLogin } from "@/api/auth";
import { getToken, setToken } from "@/api/client";
import type { AuthUser } from "@/types/api";

interface AuthContextValue {
  user: AuthUser | null;
  ready: boolean;
  login: (username: string, password: string) => Promise<void>;
  logout: () => void;
  hasPage: (stem: string) => boolean;
}

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [ready, setReady] = useState(false);

  // On mount: if a token is stored, validate it against /api/auth/me.
  useEffect(() => {
    let cancelled = false;
    (async () => {
      if (!getToken()) {
        setReady(true);
        return;
      }
      try {
        const me = await fetchMe();
        if (!cancelled) setUser(me);
      } catch {
        setToken(null);
      } finally {
        if (!cancelled) setReady(true);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  // The axios interceptor fires this on any 401.
  useEffect(() => {
    const onLogout = () => setUser(null);
    window.addEventListener("auth:logout", onLogout);
    return () => window.removeEventListener("auth:logout", onLogout);
  }, []);

  const login = useCallback(async (username: string, password: string) => {
    const res = await apiLogin(username, password);
    setToken(res.access_token);
    setUser(res.user);
  }, []);

  const logout = useCallback(() => {
    setToken(null);
    setUser(null);
  }, []);

  // Role-only security model:
  //   * operator  → every page
  //   * viewer    → every page **except** User Management
  // We deliberately ignore `user.pages` here. The backend still mirrors
  // this rule on each route (operator-only routes use `require_operator`;
  // everything else just needs an authenticated user).
  const hasPage = useCallback(
    (stem: string) => {
      if (!user) return false;
      if (user.role === "operator") return true;
      return stem !== "User_Management";
    },
    [user],
  );

  const value = useMemo<AuthContextValue>(
    () => ({ user, ready, login, logout, hasPage }),
    [user, ready, login, logout, hasPage],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}
