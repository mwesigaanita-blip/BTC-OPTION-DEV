import { useEffect, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  AlertTriangle,
  Pause,
  Play,
  RefreshCw,
  Save,
  Zap,
} from "lucide-react";
import {
  fetchHedgeAccountState,
  fetchHedgeConfig,
  fetchHedgeLogs,
  patchHedgeConfig,
  toggleHedge,
  type AccountState,
  type HedgeConfig,
  type HedgeConfigPatch,
} from "@/api/hedge";
import { PageHeader } from "@/components/shared/PageHeader";
import { MetricCard } from "@/components/shared/MetricCard";
import { LoadingState } from "@/components/shared/LoadingState";
import { ErrorState } from "@/components/shared/ErrorState";
import { Card, CardBody, CardHeader } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { Input } from "@/components/ui/Input";
import { Badge } from "@/components/ui/Badge";
import { Tabs } from "@/components/ui/Tabs";
import {
  Table,
  Tbody,
  Td,
  Th,
  Thead,
  Tr,
} from "@/components/ui/Table";
import { cn } from "@/lib/utils";
import { fmtUsd } from "@/lib/format";

const BUCKET_EMOJI: Record<string, string> = {
  safe: "✅",
  light: "🟡",
  medium: "🟠",
  aggressive: "🔴",
  emergency: "🚨",
};

type TabId = "mm" | "sizing" | "safety" | "speed" | "general";

export function HedgeEnginePage() {
  const qc = useQueryClient();
  const cfgQ = useQuery({
    queryKey: ["hedge-config"],
    queryFn: fetchHedgeConfig,
    refetchInterval: 10_000,
  });

  if (cfgQ.isLoading) return <LoadingState label="Loading hedge engine…" />;
  if (cfgQ.error || !cfgQ.data) {
    return (
      <ErrorState
        message={(cfgQ.error as Error)?.message ?? "Failed to load hedge config"}
        onRetry={() => cfgQ.refetch()}
      />
    );
  }

  return <HedgeEngineLoaded cfg={cfgQ.data} qc={qc} />;
}

function HedgeEngineLoaded({
  cfg,
  qc,
}: {
  cfg: HedgeConfig;
  qc: ReturnType<typeof useQueryClient>;
}) {
  const [tab, setTab] = useState<TabId>("mm");

  const toggleMut = useMutation({
    mutationFn: (enabled: boolean) => toggleHedge(enabled),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["hedge-config"] }),
  });

  const acctMut = useMutation({
    mutationFn: fetchHedgeAccountState,
  });
  const acct = acctMut.data ?? null;
  const acctErr =
    (acctMut.error as { response?: { data?: { detail?: string } }; message?: string } | null)
      ?.response?.data?.detail ??
    (acctMut.error as Error | null)?.message ??
    null;

  return (
    <div className="space-y-5 animate-fade-in">
      <PageHeader
        title="⚡ Simple Hedge Engine"
        description="BTC-PERPETUAL delta hedge engine - runs 24/7 in the background."
      />

      {/* Section 1 - engine status + toggle */}
      <Card>
        <CardBody className="flex flex-wrap items-center gap-4 pt-4">
          <div
            className={cn(
              "flex items-center gap-2 rounded-lg border px-3 py-2 text-sm font-semibold",
              cfg.is_enabled
                ? "border-positive/40 bg-positive/15 text-positive"
                : "border-negative/40 bg-negative/15 text-negative",
            )}
          >
            <span>{cfg.is_enabled ? "🟢" : "🔴"}</span>
            <span>Engine {cfg.is_enabled ? "ENABLED" : "DISABLED"}</span>
          </div>

          <Button
            variant={cfg.is_enabled ? "danger" : "primary"}
            onClick={() => toggleMut.mutate(!cfg.is_enabled)}
            disabled={toggleMut.isPending}
          >
            {cfg.is_enabled ? (
              <>
                <Pause className="h-4 w-4" /> Disable
              </>
            ) : (
              <>
                <Play className="h-4 w-4" /> Enable
              </>
            )}
          </Button>

          <div className="text-xs text-muted">
            Poll interval: <span className="font-semibold">{cfg.poll_interval_secs}s</span>
            {" · "}
            Last updated:{" "}
            <span className="font-mono">{cfg.updated_at ?? "-"}</span>
          </div>
        </CardBody>
      </Card>

      {/* Section 2 - live account state */}
      <Card>
        <CardHeader
          title="📊 Live Account State"
          subtitle="One-shot pull from Deribit REST (server-side; browser never holds creds)."
          action={
            <Button
              variant="secondary"
              size="sm"
              onClick={() => acctMut.mutate()}
              disabled={acctMut.isPending}
            >
              <RefreshCw className={cn("h-3.5 w-3.5", acctMut.isPending && "animate-spin")} />
              Fetch from Deribit
            </Button>
          }
        />
        <CardBody className="pt-0">
          {acctErr ? (
            <div className="flex items-center gap-2 rounded-lg border border-negative/40 bg-negative/10 px-3 py-2 text-sm text-negative">
              <AlertTriangle className="h-4 w-4" /> {acctErr}
            </div>
          ) : acct ? (
            <AccountStateMetrics acct={acct} />
          ) : (
            <div className="text-xs text-muted">
              Click <span className="font-semibold">Fetch from Deribit</span> to load the
              current snapshot.
            </div>
          )}
        </CardBody>
      </Card>

      {/* Section 3 - configuration tabs */}
      <Card>
        <CardHeader title="⚙️ Configuration" />
        <CardBody className="pt-0">
          <Tabs
            active={tab}
            onChange={(id) => setTab(id as TabId)}
            tabs={[
              { id: "mm", label: "🪣 MM Buckets" },
              { id: "sizing", label: "📐 Sizing" },
              { id: "safety", label: "🛡️ Safety" },
              { id: "speed", label: "⚡ Speed" },
              { id: "general", label: "🔧 General" },
            ]}
          />
          <div className="mt-4">
            {tab === "mm" ? <MMBucketsTab cfg={cfg} /> : null}
            {tab === "sizing" ? <SizingTab cfg={cfg} /> : null}
            {tab === "safety" ? <SafetyTab cfg={cfg} /> : null}
            {tab === "speed" ? <SpeedTab cfg={cfg} /> : null}
            {tab === "general" ? <GeneralTab cfg={cfg} /> : null}
          </div>
        </CardBody>
      </Card>

      {/* Section 4 - hedge execution history */}
      <HedgeLogSection />
    </div>
  );
}

function AccountStateMetrics({ acct }: { acct: AccountState }) {
  const bucketEmoji = BUCKET_EMOJI[acct.bucket] ?? "";
  const deltaSign = acct.net_delta > 0 ? "Long" : acct.net_delta < 0 ? "Short" : "Flat";
  return (
    <div className="grid grid-cols-2 gap-3 md:grid-cols-5">
      <MetricCard
        label="MM%"
        value={`${acct.mm_percent.toFixed(2)}%`}
        sub={`${bucketEmoji} ${acct.bucket.toUpperCase()}`}
        tone={acct.bucket === "safe" ? "positive" : acct.bucket === "emergency" ? "negative" : "warning"}
      />
      <MetricCard
        label="Net Delta"
        value={`${acct.net_delta >= 0 ? "+" : ""}${acct.net_delta.toFixed(4)} BTC`}
        sub={deltaSign}
        tone={acct.net_delta > 0 ? "positive" : acct.net_delta < 0 ? "negative" : "neutral"}
      />
      <MetricCard label="Equity" value={`${acct.equity_usd.toFixed(2)} USD`} />
      <MetricCard label="Margin Balance" value={`${acct.margin_balance.toFixed(4)} BTC`} />
      <MetricCard label="BTC Price" value={fmtUsd(acct.btc_price, 0)} />
    </div>
  );
}

// ---------------------------------------------------------------------------
// Config tab helpers
// ---------------------------------------------------------------------------

function useConfigForm<K extends keyof HedgeConfig>(
  cfg: HedgeConfig,
  keys: readonly K[],
) {
  const [state, setState] = useState<Pick<HedgeConfig, K>>(() => {
    const out: Partial<HedgeConfig> = {};
    for (const k of keys) out[k] = cfg[k];
    return out as Pick<HedgeConfig, K>;
  });
  // Sync local form when the upstream cfg refetches (so a server-side save
  // somewhere else doesn't get clobbered by stale local state).
  useEffect(() => {
    const out: Partial<HedgeConfig> = {};
    for (const k of keys) out[k] = cfg[k];
    setState(out as Pick<HedgeConfig, K>);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [cfg.updated_at]);
  return [state, setState] as const;
}

function useSaveConfig() {
  const qc = useQueryClient();
  const [savedAt, setSavedAt] = useState<number | null>(null);
  const mut = useMutation({
    mutationFn: (patch: HedgeConfigPatch) => patchHedgeConfig(patch),
    onSuccess: () => {
      setSavedAt(Date.now());
      qc.invalidateQueries({ queryKey: ["hedge-config"] });
    },
  });
  const err =
    (mut.error as { response?: { data?: { detail?: string } }; message?: string } | null)
      ?.response?.data?.detail ??
    (mut.error as Error | null)?.message ??
    null;
  return { mut, err, savedAt };
}

function FieldNumber({
  label,
  help,
  value,
  step,
  min,
  max,
  onChange,
}: {
  label: string;
  help?: string;
  value: number;
  step: number;
  min?: number;
  max?: number;
  onChange: (v: number) => void;
}) {
  return (
    <div className="space-y-1">
      <label className="block text-xs font-medium text-muted">{label}</label>
      <Input
        type="number"
        value={value}
        step={step}
        min={min}
        max={max}
        onChange={(e) => {
          const n = Number(e.target.value);
          if (Number.isFinite(n)) onChange(n);
        }}
      />
      {help ? <div className="text-[0.7rem] text-muted">{help}</div> : null}
    </div>
  );
}

function SaveBar({
  pending,
  savedAt,
  err,
  onSave,
}: {
  pending: boolean;
  savedAt: number | null;
  err: string | null;
  onSave: () => void;
}) {
  const [hint, setHint] = useState<string | null>(null);
  useEffect(() => {
    if (!savedAt) return;
    setHint("Saved.");
    const t = setTimeout(() => setHint(null), 2000);
    return () => clearTimeout(t);
  }, [savedAt]);
  return (
    <div className="mt-4 flex items-center gap-3">
      <Button onClick={onSave} disabled={pending}>
        <Save className="h-3.5 w-3.5" />
        Save
      </Button>
      {hint ? <span className="text-xs text-positive">{hint}</span> : null}
      {err ? <span className="text-xs text-negative">{err}</span> : null}
    </div>
  );
}

// ---------------------------------------------------------------------------
// Tabs
// ---------------------------------------------------------------------------

const MM_KEYS = [
  "mm_safe_below",
  "mm_light_below",
  "mm_medium_below",
  "mm_aggressive_below",
  "mm_bypass_cooldown",
] as const;

function MMBucketsTab({ cfg }: { cfg: HedgeConfig }) {
  const [form, setForm] = useConfigForm(cfg, MM_KEYS);
  const { mut, err, savedAt } = useSaveConfig();

  return (
    <div>
      <div className="mb-3 text-xs text-muted">
        Define the MM% levels that trigger each hedge intensity bucket.
      </div>

      <Card className="mb-4">
        <CardBody className="pt-4">
          <table className="w-full text-xs">
            <thead>
              <tr className="text-muted">
                <Th className="px-2 py-1.5">Bucket</Th>
                <Th className="px-2 py-1.5">MM% Range</Th>
                <Th className="px-2 py-1.5">Multiplier</Th>
              </tr>
            </thead>
            <tbody>
              <Tr><Td className="px-2 py-1">✅ Safe</Td><Td>below threshold</Td><Td>No hedge</Td></Tr>
              <Tr><Td className="px-2 py-1">🟡 Light</Td><Td>safe → light</Td><Td>1.0×</Td></Tr>
              <Tr><Td className="px-2 py-1">🟠 Medium</Td><Td>light → medium</Td><Td>1.5×</Td></Tr>
              <Tr><Td className="px-2 py-1">🔴 Aggressive</Td><Td>medium → aggressive</Td><Td>2.0×</Td></Tr>
              <Tr><Td className="px-2 py-1">🚨 Emergency</Td><Td>above aggressive</Td><Td>3.0×</Td></Tr>
            </tbody>
          </table>
        </CardBody>
      </Card>

      <div className="grid gap-3 md:grid-cols-2">
        <FieldNumber
          label="Safe below (%)"
          help="Below this → no hedge"
          value={form.mm_safe_below}
          step={0.5}
          min={50}
          max={99}
          onChange={(v) => setForm((s) => ({ ...s, mm_safe_below: v }))}
        />
        <FieldNumber
          label="Light below (%)"
          value={form.mm_light_below}
          step={0.5}
          min={50}
          max={99}
          onChange={(v) => setForm((s) => ({ ...s, mm_light_below: v }))}
        />
        <FieldNumber
          label="Medium below (%)"
          value={form.mm_medium_below}
          step={0.5}
          min={50}
          max={99.9}
          onChange={(v) => setForm((s) => ({ ...s, mm_medium_below: v }))}
        />
        <FieldNumber
          label="Aggressive below (%)"
          help="Above this → emergency bucket"
          value={form.mm_aggressive_below}
          step={0.1}
          min={50}
          max={100}
          onChange={(v) => setForm((s) => ({ ...s, mm_aggressive_below: v }))}
        />
        <FieldNumber
          label="Bypass cooldown above (%)"
          help="Above this MM% → cooldown is bypassed (true emergency)"
          value={form.mm_bypass_cooldown}
          step={0.1}
          min={50}
          max={100}
          onChange={(v) => setForm((s) => ({ ...s, mm_bypass_cooldown: v }))}
        />
      </div>

      <SaveBar
        pending={mut.isPending}
        savedAt={savedAt}
        err={err}
        onSave={() => mut.mutate(form)}
      />
    </div>
  );
}

const SIZING_KEYS = [
  "hedge_pct_of_equity",
  "delta_hedge_ratio",
  "min_trade_btc",
  "max_single_trade_btc",
] as const;

function SizingTab({ cfg }: { cfg: HedgeConfig }) {
  const [form, setForm] = useConfigForm(cfg, SIZING_KEYS);
  const { mut, err, savedAt } = useSaveConfig();

  return (
    <div>
      <div className="mb-3 text-xs text-muted">
        Hedge size = max(equity × pct, abs(delta) × ratio) × mm_multiplier × speed_multiplier
      </div>

      <div className="grid gap-3 md:grid-cols-2">
        <FieldNumber
          label="Equity % per hedge"
          help="Base size = equity_usd × this value (e.g. 0.02 = 2%)"
          value={form.hedge_pct_of_equity}
          step={0.001}
          min={0.001}
          max={0.2}
          onChange={(v) => setForm((s) => ({ ...s, hedge_pct_of_equity: v }))}
        />
        <FieldNumber
          label="Delta hedge ratio"
          help="Delta size = abs(net_delta) × this ratio (e.g. 0.35 = 35%)"
          value={form.delta_hedge_ratio}
          step={0.01}
          min={0.01}
          max={1}
          onChange={(v) => setForm((s) => ({ ...s, delta_hedge_ratio: v }))}
        />
        <FieldNumber
          label="Min trade size (BTC)"
          help="Skip hedge if computed size is below this"
          value={form.min_trade_btc}
          step={0.001}
          min={0.001}
          max={1}
          onChange={(v) => setForm((s) => ({ ...s, min_trade_btc: v }))}
        />
        <FieldNumber
          label="Max single trade (BTC)"
          help="Hard cap per single order"
          value={form.max_single_trade_btc}
          step={0.01}
          min={0.01}
          max={10}
          onChange={(v) => setForm((s) => ({ ...s, max_single_trade_btc: v }))}
        />
      </div>

      <SaveBar
        pending={mut.isPending}
        savedAt={savedAt}
        err={err}
        onSave={() => mut.mutate(form)}
      />
    </div>
  );
}

const SAFETY_KEYS = [
  "delta_deadband_btc",
  "cooldown_secs",
  "cooldown_fast_secs",
  "max_btc_per_5min",
] as const;

function SafetyTab({ cfg }: { cfg: HedgeConfig }) {
  const [form, setForm] = useConfigForm(cfg, SAFETY_KEYS);
  const { mut, err, savedAt } = useSaveConfig();

  return (
    <div>
      <div className="mb-3 text-xs text-muted">Protects against overtrading and noise trades.</div>

      <div className="grid gap-3 md:grid-cols-2">
        <FieldNumber
          label="Delta deadband (BTC)"
          help="Skip hedge if abs(net_delta) is below this"
          value={form.delta_deadband_btc}
          step={0.005}
          min={0}
          max={1}
          onChange={(v) => setForm((s) => ({ ...s, delta_deadband_btc: v }))}
        />
        <FieldNumber
          label="Max BTC per 5 minutes"
          help="Hard cap on total BTC hedged in any 5min rolling window"
          value={form.max_btc_per_5min}
          step={0.05}
          min={0.01}
          max={10}
          onChange={(v) => setForm((s) => ({ ...s, max_btc_per_5min: v }))}
        />
        <FieldNumber
          label="Cooldown - normal market (s)"
          help="Minimum seconds between hedges in normal conditions"
          value={form.cooldown_secs}
          step={5}
          min={0}
          max={600}
          onChange={(v) => setForm((s) => ({ ...s, cooldown_secs: Math.round(v) }))}
        />
        <FieldNumber
          label="Cooldown - fast market (s)"
          help="Shorter cooldown used when market speed is above warn threshold"
          value={form.cooldown_fast_secs}
          step={5}
          min={0}
          max={300}
          onChange={(v) => setForm((s) => ({ ...s, cooldown_fast_secs: Math.round(v) }))}
        />
      </div>

      <SaveBar
        pending={mut.isPending}
        savedAt={savedAt}
        err={err}
        onSave={() => mut.mutate(form)}
      />
    </div>
  );
}

const SPEED_KEYS = [
  "speed_warn_30s",
  "speed_danger_30s",
  "speed_warn_60s",
  "speed_danger_60s",
] as const;

function SpeedTab({ cfg }: { cfg: HedgeConfig }) {
  const [form, setForm] = useConfigForm(cfg, SPEED_KEYS);
  const { mut, err, savedAt } = useSaveConfig();

  return (
    <div>
      <div className="mb-3 text-xs text-muted">
        Speed = abs(price_now - price_Ns_ago) / price_Ns_ago. Warn → 1.5× size multiplier. Danger →
        2.0× size multiplier + shorter cooldown.
      </div>

      <div className="grid gap-3 md:grid-cols-2">
        <div className="space-y-3">
          <div className="text-xs font-semibold text-fg">30-second speed</div>
          <FieldNumber
            label="Warn threshold (30s)"
            help="e.g. 0.008 = 0.8% price move in 30s"
            value={form.speed_warn_30s}
            step={0.001}
            min={0}
            max={0.1}
            onChange={(v) => setForm((s) => ({ ...s, speed_warn_30s: v }))}
          />
          <FieldNumber
            label="Danger threshold (30s)"
            help="e.g. 0.015 = 1.5% price move in 30s"
            value={form.speed_danger_30s}
            step={0.001}
            min={0}
            max={0.1}
            onChange={(v) => setForm((s) => ({ ...s, speed_danger_30s: v }))}
          />
        </div>
        <div className="space-y-3">
          <div className="text-xs font-semibold text-fg">60-second speed</div>
          <FieldNumber
            label="Warn threshold (60s)"
            help="e.g. 0.012 = 1.2% price move in 60s"
            value={form.speed_warn_60s}
            step={0.001}
            min={0}
            max={0.1}
            onChange={(v) => setForm((s) => ({ ...s, speed_warn_60s: v }))}
          />
          <FieldNumber
            label="Danger threshold (60s)"
            help="e.g. 0.025 = 2.5% price move in 60s"
            value={form.speed_danger_60s}
            step={0.001}
            min={0}
            max={0.1}
            onChange={(v) => setForm((s) => ({ ...s, speed_danger_60s: v }))}
          />
        </div>
      </div>

      <SaveBar
        pending={mut.isPending}
        savedAt={savedAt}
        err={err}
        onSave={() => mut.mutate(form)}
      />
    </div>
  );
}

function GeneralTab({ cfg }: { cfg: HedgeConfig }) {
  const [form, setForm] = useConfigForm(cfg, ["poll_interval_secs"] as const);
  const { mut, err, savedAt } = useSaveConfig();
  return (
    <div className="max-w-md">
      <FieldNumber
        label="Poll interval (seconds)"
        help="How often the engine checks Deribit"
        value={form.poll_interval_secs}
        step={5}
        min={5}
        max={300}
        onChange={(v) => setForm((s) => ({ ...s, poll_interval_secs: Math.round(v) }))}
      />
      <SaveBar
        pending={mut.isPending}
        savedAt={savedAt}
        err={err}
        onSave={() => mut.mutate(form)}
      />
    </div>
  );
}

// ---------------------------------------------------------------------------
// Log history
// ---------------------------------------------------------------------------

function HedgeLogSection() {
  const [limit, setLimit] = useState(25);
  const q = useQuery({
    queryKey: ["hedge-logs", limit],
    queryFn: () => fetchHedgeLogs(limit),
    refetchInterval: 30_000,
  });

  return (
    <Card>
      <CardHeader
        title="📋 Hedge Execution History"
        action={
          <select
            className="h-9 rounded-md border border-border bg-surface-2 px-2 text-xs"
            value={limit}
            onChange={(e) => setLimit(Number(e.target.value))}
          >
            {[10, 25, 50, 100].map((n) => (
              <option key={n} value={n}>
                Last {n}
              </option>
            ))}
          </select>
        }
      />
      <CardBody className="pt-0">
        {q.isLoading ? (
          <LoadingState label="Loading logs…" />
        ) : q.error ? (
          <ErrorState
            message={(q.error as Error).message}
            onRetry={() => q.refetch()}
          />
        ) : !q.data || q.data.logs.length === 0 ? (
          <div className="rounded-lg border border-border bg-surface-2/30 py-8 text-center text-sm text-muted">
            No hedge executions recorded yet.
          </div>
        ) : (
          <>
            <Table>
              <Thead>
                <Tr>
                  <Th>Time (UTC)</Th>
                  <Th>Direction</Th>
                  <Th className="text-right">Size (BTC)</Th>
                  <Th className="text-right">MM% Before</Th>
                  <Th className="text-right">MM% After</Th>
                  <Th>Bucket</Th>
                  <Th className="text-right">Net Delta</Th>
                  <Th className="text-right">Speed 30s</Th>
                  <Th className="text-right">Speed 60s</Th>
                  <Th>Order ID</Th>
                  <Th className="text-right">Avg Price</Th>
                  <Th>Error</Th>
                </Tr>
              </Thead>
              <Tbody>
                {q.data.logs.map((r) => (
                  <Tr key={r.id ?? r.executed_at + r.order_id}>
                    <Td className="font-mono text-xs">{r.executed_at}</Td>
                    <Td>
                      {r.direction === "sell" ? (
                        <Badge tone="negative">📉 SELL</Badge>
                      ) : r.direction === "buy" ? (
                        <Badge tone="positive">📈 BUY</Badge>
                      ) : (
                        r.direction
                      )}
                    </Td>
                    <Td className="text-right tabular-nums">{r.size_btc.toFixed(4)}</Td>
                    <Td className="text-right tabular-nums">
                      {r.mm_before != null ? `${r.mm_before.toFixed(2)}%` : "-"}
                    </Td>
                    <Td className="text-right tabular-nums">
                      {r.mm_after != null ? `${r.mm_after.toFixed(2)}%` : "-"}
                    </Td>
                    <Td>
                      {r.mm_bucket ? (
                        <span>
                          {BUCKET_EMOJI[r.mm_bucket] ?? ""} {r.mm_bucket}
                        </span>
                      ) : (
                        "-"
                      )}
                    </Td>
                    <Td className="text-right tabular-nums">
                      {r.net_delta != null
                        ? `${r.net_delta >= 0 ? "+" : ""}${r.net_delta.toFixed(4)}`
                        : "-"}
                    </Td>
                    <Td className="text-right tabular-nums">
                      {r.speed_30s != null ? `${(r.speed_30s * 100).toFixed(3)}%` : "-"}
                    </Td>
                    <Td className="text-right tabular-nums">
                      {r.speed_60s != null ? `${(r.speed_60s * 100).toFixed(3)}%` : "-"}
                    </Td>
                    <Td className="font-mono text-[0.7rem]">{r.order_id ?? "-"}</Td>
                    <Td className="text-right tabular-nums">
                      {r.avg_price != null ? `$${r.avg_price.toLocaleString()}` : "-"}
                    </Td>
                    <Td className="text-xs text-negative">{r.error ?? ""}</Td>
                  </Tr>
                ))}
              </Tbody>
            </Table>
            <SummaryStrip summary={q.data.summary} />
          </>
        )}
      </CardBody>
    </Card>
  );
}

function SummaryStrip({
  summary,
}: {
  summary: { total: number; errors: number; successful: number; sells: number; buys: number; total_btc: number };
}) {
  return (
    <div className="mt-3 flex flex-wrap items-center gap-3 text-xs text-muted">
      <span>Total: <span className="font-semibold text-fg">{summary.total}</span></span>
      <span>·</span>
      <span className="text-positive">✅ Success: {summary.successful}</span>
      <span>·</span>
      <span className="text-negative">❌ Failed: {summary.errors}</span>
      <span>·</span>
      <span>📉 Sells: {summary.sells}</span>
      <span>·</span>
      <span>📈 Buys: {summary.buys}</span>
      <span>·</span>
      <span className="inline-flex items-center gap-1">
        <Zap className="h-3 w-3" /> Total BTC hedged: {summary.total_btc.toFixed(4)} BTC
      </span>
    </div>
  );
}
