import { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Download } from "lucide-react";
import {
  Area,
  CartesianGrid,
  ComposedChart,
  Legend,
  Line,
  ReferenceLine,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { fetchHvIvSeries } from "@/api/vol";
import { useTheme } from "@/theme/ThemeProvider";
import { PageHeader } from "@/components/shared/PageHeader";
import { VolDashboardPanel } from "./volatility/dashboard/VolDashboardPanel";
import { LoadingState } from "@/components/shared/LoadingState";
import { ErrorState } from "@/components/shared/ErrorState";
import { MetricCard } from "@/components/shared/MetricCard";
import { Card, CardBody, CardHeader } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { downloadCsv, rowsToCsv } from "@/lib/csv";
import { cn } from "@/lib/utils";

type Preset = { id: string; label: string; days: number };
const PRESETS: Preset[] = [
  { id: "7d", label: "7D", days: 7 },
  { id: "30d", label: "30D", days: 30 },
  { id: "90d", label: "90D", days: 90 },
  { id: "1y", label: "1Y", days: 365 },
  { id: "5y", label: "5Y", days: 365 * 5 },
];

const HOURLY_MAX_DAYS = 90;

export function VolatilityPage() {
  const [presetId, setPresetId] = useState<string>("30d");
  const [resolution, setResolution] = useState<"1D" | "1H">("1D");

  const days = PRESETS.find((p) => p.id === presetId)?.days ?? 30;
  const hourlyDisabled = days > HOURLY_MAX_DAYS;
  const effectiveResolution: "1D" | "1H" = hourlyDisabled ? "1D" : resolution;

  const q = useQuery({
    queryKey: ["vol-hv-iv", days, effectiveResolution],
    queryFn: () => fetchHvIvSeries(days, effectiveResolution),
    retry: false,
    placeholderData: (prev) => prev,
  });

  const rows = q.data?.rows ?? [];

  // Derived summary tiles
  const summary = useMemo(() => {
    if (!rows.length) return null;
    const latest = [...rows].reverse().find(
      (r) => r.hv_pct != null && r.iv_pct != null,
    );
    const lastHv = latest?.hv_pct ?? null;
    const lastIv = latest?.iv_pct ?? null;
    const spread =
      lastHv != null && lastIv != null ? lastIv - lastHv : null;
    // 30d-mean spread (last min(30, n) buckets where both sides exist)
    const window = rows.slice(-Math.min(rows.length, 30));
    const spreads = window
      .filter((r) => r.hv_pct != null && r.iv_pct != null)
      .map((r) => (r.iv_pct as number) - (r.hv_pct as number));
    const meanSpread =
      spreads.length > 0
        ? spreads.reduce((a, b) => a + b, 0) / spreads.length
        : null;
    return { lastHv, lastIv, spread, meanSpread };
  }, [rows]);

  // Split HV into two series: real Deribit data (saved snapshots OR the live
  // 16-day HV endpoint, both authoritative) vs our computed stdev (the
  // disappearing crutch). They render with different styles so the boundary
  // is visible, but conceptually saved+deribit are the same thing - one is
  // just from the worker's snapshot, the other from the live endpoint.
  const chartData = useMemo(
    () =>
      rows.map((r) => {
        const isReal =
          r.hv_source === "saved" || r.hv_source === "deribit";
        return {
          ts_ms: r.ts_ms,
          ts_utc: r.ts_utc,
          hv_real: isReal ? r.hv_pct : null,
          hv_computed: r.hv_source === "computed" ? r.hv_pct : null,
          iv: r.iv_pct,
          spread:
            r.hv_pct != null && r.iv_pct != null ? r.iv_pct - r.hv_pct : null,
        };
      }),
    [rows],
  );

  const handleCsv = () => {
    const exportRows = rows.map((r) => ({
      ts_utc: r.ts_utc,
      hv_pct: r.hv_pct ?? "",
      hv_source: r.hv_source ?? "",
      iv_pct: r.iv_pct ?? "",
      iv_source: r.iv_source ?? "",
      spread_pct:
        r.hv_pct != null && r.iv_pct != null
          ? (r.iv_pct - r.hv_pct).toFixed(4)
          : "",
    }));
    const csv = rowsToCsv(exportRows, [
      "ts_utc",
      "hv_pct",
      "hv_source",
      "iv_pct",
      "iv_source",
      "spread_pct",
    ]);
    downloadCsv(`hv-iv-${days}d-${effectiveResolution}.csv`, csv);
  };

  return (
    <div className="space-y-5">
      <PageHeader
        title="Volatility (HV vs IV)"
        description="Realized (HV) vs implied (DVOL) volatility. Deribit HV authoritative for the last ~16 days; older points are computed from BTC perp closes."
      />

      {/* Hedgeye-style volatility dashboard panel */}
      <VolDashboardPanel />

      {/* Controls */}
      <Card>
        <CardBody className="flex flex-wrap items-center gap-3">
          <div className="flex flex-wrap gap-1.5">
            {PRESETS.map((p) => (
              <button
                key={p.id}
                type="button"
                onClick={() => setPresetId(p.id)}
                className={cn(
                  "rounded-md border px-3 py-1.5 text-xs font-medium",
                  presetId === p.id
                    ? "border-brand bg-brand/15 text-brand"
                    : "border-border bg-surface-2 text-muted hover:text-fg",
                )}
              >
                {p.label}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-1.5">
            {(["1D", "1H"] as const).map((r) => {
              const disabled = r === "1H" && hourlyDisabled;
              const active = effectiveResolution === r;
              return (
                <button
                  key={r}
                  type="button"
                  disabled={disabled}
                  title={
                    disabled
                      ? `Hourly is only available for ranges <= ${HOURLY_MAX_DAYS} days`
                      : ""
                  }
                  onClick={() => setResolution(r)}
                  className={cn(
                    "rounded-md border px-3 py-1.5 text-xs font-medium",
                    active
                      ? "border-brand bg-brand/15 text-brand"
                      : "border-border bg-surface-2 text-muted hover:text-fg",
                    disabled && "cursor-not-allowed opacity-40 hover:text-muted",
                  )}
                >
                  {r === "1D" ? "Daily" : "Hourly"}
                </button>
              );
            })}
          </div>

          <div className="ml-auto">
            <Button
              variant="secondary"
              size="sm"
              onClick={handleCsv}
              disabled={!rows.length}
            >
              <Download className="h-3.5 w-3.5" /> Download CSV
            </Button>
          </div>
        </CardBody>
      </Card>

      {/* Summary tiles */}
      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        <MetricCard
          label="Latest HV"
          value={summary?.lastHv != null ? `${summary.lastHv.toFixed(2)}%` : "-"}
        />
        <MetricCard
          label="Latest IV (DVOL)"
          value={summary?.lastIv != null ? `${summary.lastIv.toFixed(2)}%` : "-"}
        />
        <MetricCard
          label="Spread (IV − HV)"
          value={
            summary?.spread != null
              ? `${summary.spread >= 0 ? "+" : ""}${summary.spread.toFixed(2)} pp`
              : "-"
          }
          tone={
            summary?.spread == null
              ? "neutral"
              : summary.spread >= 0
                ? "negative"
                : "positive"
          }
        />
        <MetricCard
          label="Mean Spread (last 30)"
          value={
            summary?.meanSpread != null
              ? `${summary.meanSpread >= 0 ? "+" : ""}${summary.meanSpread.toFixed(2)} pp`
              : "-"
          }
        />
      </div>

      {/* Main chart */}
      <Card>
        <CardHeader
          title="HV vs IV"
          subtitle={`${rows.length} points · ${effectiveResolution === "1D" ? "Daily" : "Hourly"}`}
        />
        <CardBody>
          {q.isLoading && !q.data ? (
            <LoadingState label="Loading vol history…" />
          ) : q.isError ? (
            <ErrorState
              message="Could not load HV/IV series."
              onRetry={() => q.refetch()}
            />
          ) : rows.length ? (
            <HvIvChart data={chartData} />
          ) : (
            <p className="py-12 text-center text-sm text-muted">No data.</p>
          )}
        </CardBody>
      </Card>

      {/* Spread overlay */}
      {rows.length > 0 && (
        <Card>
          <CardHeader
            title="Spread (IV − HV)"
            subtitle="Positive = vol rich · Negative = vol crushed"
          />
          <CardBody>
            <SpreadChart data={chartData} />
          </CardBody>
        </Card>
      )}
    </div>
  );
}

// ---------------------------------------------------------------------------

interface ChartRow {
  ts_ms: number;
  ts_utc: string;
  hv_real: number | null;
  hv_computed: number | null;
  iv: number | null;
  spread: number | null;
}

function HvIvChart({ data }: { data: ChartRow[] }) {
  const { theme } = useTheme();
  const dark = theme === "dark";
  const axis = dark ? "#8b949e" : "#6b7280";
  const grid = dark ? "rgba(139,148,161,0.15)" : "rgba(107,114,128,0.18)";
  const hvColor = dark ? "#60a5fa" : "#2563eb";
  const ivColor = dark ? "#f59e0b" : "#d97706";

  return (
    <ResponsiveContainer width="100%" height={380}>
      <ComposedChart data={data} margin={{ top: 8, right: 16, bottom: 4, left: 4 }}>
        <CartesianGrid stroke={grid} vertical={false} />
        <XAxis
          dataKey="ts_utc"
          tick={{ fill: axis, fontSize: 11 }}
          stroke={grid}
          minTickGap={48}
          tickFormatter={(v: string) => v.slice(0, 10)}
        />
        <YAxis
          tick={{ fill: axis, fontSize: 11 }}
          stroke={grid}
          width={56}
          tickFormatter={(v) => `${Number(v).toFixed(0)}%`}
        />
        <Tooltip
          contentStyle={{
            background: dark ? "#161b22" : "#ffffff",
            border: `1px solid ${grid}`,
            borderRadius: 8,
            fontSize: 12,
          }}
          labelFormatter={(v: string) => v.slice(0, 16).replace("T", " ")}
          formatter={(value: number | string, name: string) => {
            if (value == null) return ["-", name];
            return [`${Number(value).toFixed(2)}%`, name];
          }}
        />
        <Legend wrapperStyle={{ fontSize: 12 }} />
        <Line
          type="monotone"
          name="HV (Deribit / saved)"
          dataKey="hv_real"
          stroke={hvColor}
          strokeWidth={2}
          dot={false}
          isAnimationActive={false}
          connectNulls={false}
        />
        <Line
          type="monotone"
          name="HV (computed)"
          dataKey="hv_computed"
          stroke={hvColor}
          strokeWidth={2}
          strokeDasharray="6 4"
          dot={false}
          isAnimationActive={false}
          connectNulls={false}
        />
        <Line
          type="monotone"
          name="IV (DVOL)"
          dataKey="iv"
          stroke={ivColor}
          strokeWidth={2}
          dot={false}
          isAnimationActive={false}
          connectNulls
        />
      </ComposedChart>
    </ResponsiveContainer>
  );
}

function SpreadChart({ data }: { data: ChartRow[] }) {
  const { theme } = useTheme();
  const dark = theme === "dark";
  const axis = dark ? "#8b949e" : "#6b7280";
  const grid = dark ? "rgba(139,148,161,0.15)" : "rgba(107,114,128,0.18)";
  const richColor = dark ? "#f87171" : "#dc2626";

  return (
    <ResponsiveContainer width="100%" height={180}>
      <ComposedChart data={data} margin={{ top: 8, right: 16, bottom: 4, left: 4 }}>
        <CartesianGrid stroke={grid} vertical={false} />
        <XAxis
          dataKey="ts_utc"
          tick={{ fill: axis, fontSize: 11 }}
          stroke={grid}
          minTickGap={48}
          tickFormatter={(v: string) => v.slice(0, 10)}
        />
        <YAxis
          tick={{ fill: axis, fontSize: 11 }}
          stroke={grid}
          width={56}
          tickFormatter={(v) => `${Number(v).toFixed(0)}`}
        />
        <ReferenceLine y={0} stroke={axis} strokeDasharray="2 4" />
        <Tooltip
          contentStyle={{
            background: dark ? "#161b22" : "#ffffff",
            border: `1px solid ${grid}`,
            borderRadius: 8,
            fontSize: 12,
          }}
          labelFormatter={(v: string) => v.slice(0, 16).replace("T", " ")}
          formatter={(value: number | string) => {
            if (value == null) return ["-", "spread"];
            return [`${Number(value).toFixed(2)} pp`, "IV − HV"];
          }}
        />
        <Area
          type="monotone"
          dataKey="spread"
          stroke={richColor}
          fill={richColor}
          fillOpacity={0.25}
          isAnimationActive={false}
          connectNulls={false}
        />
      </ComposedChart>
    </ResponsiveContainer>
  );
}
