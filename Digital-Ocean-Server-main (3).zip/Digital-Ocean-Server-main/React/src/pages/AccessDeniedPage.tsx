import { ShieldX } from "lucide-react";

export function AccessDenied({ reason }: { reason?: string }) {
  return (
    <div className="flex flex-col items-center justify-center gap-3 py-24 text-center">
      <div className="rounded-full bg-negative/15 p-4 text-negative">
        <ShieldX className="h-8 w-8" />
      </div>
      <h2 className="text-lg font-semibold text-fg">Access denied</h2>
      <p className="max-w-md text-sm text-muted">
        {reason ?? "You do not have permission to view this page."}
      </p>
    </div>
  );
}
