import { useEffect, useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { ChevronDown, ChevronRight, Download, FileArchive, RotateCcw } from "lucide-react";
import JSZip from "jszip";
import {
  CartesianGrid,
  ComposedChart,
  Line,
  LineChart,
  ReferenceDot,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { fetchDayPositions, fetchPortfolioHistory } from "@/api/history";
import { useTheme } from "@/theme/ThemeProvider";
import { PageHeader } from "@/components/shared/PageHeader";
import { LoadingState } from "@/components/shared/LoadingState";
import { ErrorState } from "@/components/shared/ErrorState";
import { MetricCard } from "@/components/shared/MetricCard";
import { Card, CardBody, CardHeader } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { Input } from "@/components/ui/Input";
import {
  Table,
  Tbody,
  Td,
  Th,
  Thead,
  Tr,
} from "@/components/ui/Table";
import { fmtNum, fmtSignedPct, fmtUsd } from "@/lib/format";
import { downloadCsv, rowsToCsv } from "@/lib/csv";
import { cn } from "@/lib/utils";
import type { PortfolioTsRow } from "@/types/api";

const PERF_LABELS: Array<[string, string]> = [
  ["1d", "1 Day"],
  ["3d", "3 Days"],
  ["1w", "1 Week"],
  ["1m", "1 Month"],
  ["3m", "3 Months"],
  ["6m", "6 Months"],
  ["1y", "1 Year"],
  ["ytd", "YTD"],
];

const PNL_METRICS: Array<{ key: keyof PortfolioTsRow; label: string }> = [
  { key: "pnl_total_usd", label: "PnL Total (USD)" },
  { key: "pnl_float_usd", label: "PnL Floating (USD)" },
  { key: "pnl_real_usd", label: "PnL Realized (USD)" },
  { key: "pnl_total_btc", label: "PnL Total (BTC)" },
];

const SELECT_CLS =
  "h-11 rounded-lg border border-border bg-surface-2 px-2.5 text-sm text-fg focus:outline-none focus:ring-2 focus:ring-brand";

export function PositionsHistoryPage() {
  const q = useQuery({
    queryKey: ["positions-history"],
    queryFn: fetchPortfolioHistory,
    retry: false,
    refetchInterval: 60_000,
  });
  const data = q.data;

  const [fromStr, setFromStr] = useState("");
  const [toStr, setToStr] = useState("");
  const [pnlMetric, setPnlMetric] = useState<keyof PortfolioTsRow>(
    "pnl_total_usd",
  );

  const ts = data?.timeseries ?? [];
  const minDate = ts[0]?.date ?? "";
  const maxDate = ts[ts.length - 1]?.date ?? "";
  const from = fromStr || minDate;
  const to = toStr || maxDate;

  const filtered = useMemo(
    () => ts.filter((r) => r.date >= from && r.date <= to),
    [ts, from, to],
  );
  const events = useMemo(
    () => filtered.filter((r) => r.event_type === "Deposit" || r.event_type === "Withdrawal"),
    [filtered],
  );
  const latest = filtered[filtered.length - 1] ?? data?.latest ?? null;

  const resetRange = () => {
    setFromStr("");
    setToStr("");
  };

  if (q.isLoading && !data) return <LoadingState label="Loading history…" />;
  if (q.isError)
    return (
      <ErrorState
        message="Could not load portfolio history."
        onRetry={() => q.refetch()}
      />
    );

  return (
    <div className="space-y-5">
      <PageHeader
        title="Positions History"
        description="Daily portfolio snapshots, performance windows and per-day drilldown."
      />

      {/* Controls */}
      <Card>
        <CardBody className="grid grid-cols-1 gap-3 sm:grid-cols-4">
          <Field label="From">
            <Input
              type="date"
              value={from}
              min={minDate}
              max={maxDate}
              onChange={(e) => setFromStr(e.target.value)}
            />
          </Field>
          <Field label="To">
            <Input
              type="date"
              value={to}
              min={minDate}
              max={maxDate}
              onChange={(e) => setToStr(e.target.value)}
            />
          </Field>
          <Field label="PnL Series">
            <select
              value={String(pnlMetric)}
              onChange={(e) =>
                setPnlMetric(e.target.value as keyof PortfolioTsRow)
              }
              className={SELECT_CLS}
            >
              {PNL_METRICS.map((m) => (
                <option key={String(m.key)} value={String(m.key)}>
                  {m.label}
                </option>
              ))}
            </select>
          </Field>
          <div className="flex items-end">
            <Button
              variant="secondary"
              size="sm"
              className="w-full"
              onClick={resetRange}
              disabled={!fromStr && !toStr}
            >
              <RotateCcw className="h-3.5 w-3.5" /> Reset range
            </Button>
          </div>
        </CardBody>
      </Card>

      {/* Top KPIs */}
      {latest ? (
        <div className="grid grid-cols-2 gap-3 md:grid-cols-6">
          <MetricCard label="Last Snapshot" value={latest.date ?? "-"} />
          <MetricCard
            label="Open Positions"
            value={fmtNum(latest.open_positions, 0)}
          />
          <MetricCard
            label="Contracts"
            value={fmtNum(latest.contracts, 2)}
          />
          <MetricCard
            label="PnL Total (USD)"
            value={fmtUsd(latest.pnl_total_usd)}
            tone={
              Number(latest.pnl_total_usd) >= 0 ? "positive" : "negative"
            }
          />
          <MetricCard label="Theta Sum" value={fmtNum(latest.theta_sum, 2)} />
          <MetricCard label="Vega Sum" value={fmtNum(latest.vega_sum, 2)} />
        </div>
      ) : null}

      {/* Performance */}
      <Card>
        <CardHeader title="Portfolio Performance" />
        <CardBody>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4 lg:grid-cols-8">
            {PERF_LABELS.map(([key, label]) => {
              const w = data?.performance?.[key];
              const pct = Number(w?.pct ?? 0);
              const abs = Number(w?.abs ?? 0);
              const positive = pct >= 0;
              return (
                <div
                  key={key}
                  className={cn(
                    "rounded-lg border-l-4 bg-surface-2 px-3 py-2.5",
                    positive ? "border-positive" : "border-negative",
                  )}
                >
                  <div className="text-[11px] text-muted">{label}</div>
                  <div
                    className={cn(
                      "mt-0.5 text-lg font-bold tabular-nums",
                      positive ? "text-positive" : "text-negative",
                    )}
                  >
                    {fmtSignedPct(pct)}
                  </div>
                  <div className="text-xs text-muted tabular-nums">
                    {fmtUsd(abs)}
                  </div>
                </div>
              );
            })}
          </div>
        </CardBody>
      </Card>

      {/* Equity chart */}
      <Card>
        <CardHeader
          title="Total Portfolio Value (USD & BTC)"
          subtitle="Daily equity with deposit/withdrawal markers"
        />
        <CardBody>
          <EquityChart rows={filtered} events={events} />
        </CardBody>
      </Card>

      {/* PnL series */}
      <Card>
        <CardHeader
          title={PNL_METRICS.find((m) => m.key === pnlMetric)?.label ?? ""}
          subtitle="Per-day PnL"
        />
        <CardBody>
          <SimpleLineChart
            rows={filtered}
            metric={pnlMetric as string}
            currency={pnlMetric === "pnl_total_btc" ? "BTC" : "USD"}
          />
        </CardBody>
      </Card>

      {/* Open positions */}
      <Card>
        <CardHeader title="Open Positions" subtitle="Daily count" />
        <CardBody>
          <SimpleLineChart rows={filtered} metric="open_positions" />
        </CardBody>
      </Card>

      {/* Greeks */}
      <Card>
        <CardHeader
          title="Greeks Exposure Over Time"
          subtitle="Δ · Γ · Θ · V (mixed scales)"
        />
        <CardBody>
          <GreeksChart rows={filtered} />
        </CardBody>
      </Card>

      {/* Drilldown */}
      <Card>
        <CardHeader
          title="Daily Drilldown"
          subtitle={`${filtered.length} day${filtered.length === 1 ? "" : "s"} in range - click to expand`}
        />
        <CardBody className="px-0">
          <DailyDrilldown
            dates={filtered.map((r) => r.date).reverse()}
            timeseries={filtered}
          />
        </CardBody>
      </Card>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Sub-components
// ---------------------------------------------------------------------------

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="space-y-1">
      <label className="block text-[11px] font-medium uppercase tracking-wide text-muted">
        {label}
      </label>
      {children}
    </div>
  );
}

function useChartColors() {
  const { theme } = useTheme();
  const dark = theme === "dark";
  return {
    dark,
    axis: dark ? "#8b949e" : "#6b7280",
    grid: dark ? "rgba(139,148,161,0.15)" : "rgba(107,114,128,0.18)",
    usd: dark ? "#38bdf8" : "#0ea5e9",
    btc: "#f7931a",
    pos: dark ? "#3fb950" : "#16a34a",
    neg: dark ? "#f85149" : "#dc2626",
    line: dark ? "#388bfd" : "#2563eb",
  };
}

function tooltipStyle(dark: boolean, grid: string): React.CSSProperties {
  return {
    background: dark ? "#161b22" : "#ffffff",
    border: `1px solid ${grid}`,
    borderRadius: 8,
    fontSize: 12,
    padding: "6px 10px",
  };
}

function EquityChart({
  rows,
  events,
}: {
  rows: PortfolioTsRow[];
  events: PortfolioTsRow[];
}) {
  const c = useChartColors();
  if (!rows.length) {
    return <p className="py-12 text-center text-sm text-muted">No data.</p>;
  }
  return (
    <ResponsiveContainer width="100%" height={340}>
      <ComposedChart data={rows} margin={{ top: 8, right: 60, bottom: 4, left: 4 }}>
        <CartesianGrid stroke={c.grid} vertical={false} />
        <XAxis dataKey="date" tick={{ fill: c.axis, fontSize: 11 }} stroke={c.grid} />
        <YAxis
          yAxisId="usd"
          tickFormatter={(v) => `$${Math.round(Number(v) / 1000)}k`}
          tick={{ fill: c.axis, fontSize: 11 }}
          stroke={c.grid}
          width={56}
        />
        <YAxis
          yAxisId="btc"
          orientation="right"
          tickFormatter={(v) => `₿${Number(v).toFixed(3)}`}
          tick={{ fill: c.btc, fontSize: 11 }}
          stroke={c.grid}
          width={60}
        />
        <Tooltip
          contentStyle={tooltipStyle(c.dark, c.grid)}
          labelStyle={{ color: c.axis }}
          formatter={(value: number, name: string) => {
            if (name === "USD") return [fmtUsd(value), "Equity (USD)"];
            if (name === "BTC") return [`₿${Number(value).toFixed(4)}`, "Equity (BTC)"];
            return [value, name];
          }}
        />
        <Line
          yAxisId="usd"
          type="monotone"
          dataKey="total_portfolio_usd"
          name="USD"
          stroke={c.usd}
          strokeWidth={2.5}
          dot={false}
          activeDot={{ r: 4 }}
        />
        <Line
          yAxisId="btc"
          type="monotone"
          dataKey="total_portfolio_btc"
          name="BTC"
          stroke={c.btc}
          strokeWidth={1.5}
          strokeDasharray="4 4"
          dot={false}
        />
        {events.map((ev) => (
          <ReferenceDot
            key={ev.date + ev.event_type}
            yAxisId="usd"
            x={ev.date}
            y={Number(ev.total_portfolio_usd ?? 0)}
            r={5}
            fill={ev.event_type === "Deposit" ? c.pos : c.neg}
            stroke={c.dark ? "#0d1117" : "#ffffff"}
            strokeWidth={2}
          />
        ))}
      </ComposedChart>
    </ResponsiveContainer>
  );
}

function SimpleLineChart({
  rows,
  metric,
  currency,
}: {
  rows: PortfolioTsRow[];
  metric: string;
  currency?: "USD" | "BTC";
}) {
  const c = useChartColors();
  if (!rows.length) {
    return <p className="py-12 text-center text-sm text-muted">No data.</p>;
  }
  return (
    <ResponsiveContainer width="100%" height={240}>
      <LineChart data={rows} margin={{ top: 8, right: 12, bottom: 4, left: 4 }}>
        <CartesianGrid stroke={c.grid} vertical={false} />
        <XAxis dataKey="date" tick={{ fill: c.axis, fontSize: 11 }} stroke={c.grid} />
        <YAxis
          tick={{ fill: c.axis, fontSize: 11 }}
          stroke={c.grid}
          tickFormatter={(v) => {
            const n = Number(v);
            if (currency === "USD") return `$${Math.round(n / 1000)}k`;
            if (currency === "BTC") return `₿${n.toFixed(2)}`;
            return n.toLocaleString();
          }}
          width={56}
        />
        <Tooltip
          contentStyle={tooltipStyle(c.dark, c.grid)}
          labelStyle={{ color: c.axis }}
          formatter={(value: number) => {
            if (currency === "USD") return [fmtUsd(value), "Value"];
            if (currency === "BTC") return [`₿${Number(value).toFixed(4)}`, "Value"];
            return [Number(value).toLocaleString(), "Value"];
          }}
        />
        <Line
          type="monotone"
          dataKey={metric}
          stroke={c.line}
          strokeWidth={2}
          dot={false}
          activeDot={{ r: 4 }}
        />
      </LineChart>
    </ResponsiveContainer>
  );
}

function GreeksChart({ rows }: { rows: PortfolioTsRow[] }) {
  const c = useChartColors();
  if (!rows.length) {
    return <p className="py-12 text-center text-sm text-muted">No data.</p>;
  }
  const greeks: Array<[keyof PortfolioTsRow, string, string]> = [
    ["delta_sum", "Δ Delta", "#38bdf8"],
    ["gamma_sum", "Γ Gamma", "#a78bfa"],
    ["theta_sum", "Θ Theta", "#f97316"],
    ["vega_sum", "V Vega", "#22c55e"],
  ];
  return (
    <ResponsiveContainer width="100%" height={260}>
      <LineChart data={rows} margin={{ top: 8, right: 12, bottom: 4, left: 4 }}>
        <CartesianGrid stroke={c.grid} vertical={false} />
        <XAxis dataKey="date" tick={{ fill: c.axis, fontSize: 11 }} stroke={c.grid} />
        <YAxis tick={{ fill: c.axis, fontSize: 11 }} stroke={c.grid} width={56} />
        <Tooltip
          contentStyle={tooltipStyle(c.dark, c.grid)}
          labelStyle={{ color: c.axis }}
        />
        {greeks.map(([key, label, colour]) => (
          <Line
            key={String(key)}
            type="monotone"
            dataKey={String(key)}
            name={label}
            stroke={colour}
            strokeWidth={1.8}
            dot={false}
          />
        ))}
      </LineChart>
    </ResponsiveContainer>
  );
}

// ---------------------------------------------------------------------------
// Daily drilldown - lazy-loaded per day
// ---------------------------------------------------------------------------

function DailyDrilldown({
  dates,
  timeseries,
}: {
  dates: string[];
  timeseries: PortfolioTsRow[];
}) {
  const [open, setOpen] = useState<string | null>(null);
  // Specific-date filter. When set, the list narrows to that single day and
  // auto-expands it. The page-level From/To range still bounds availability.
  const [pickedDate, setPickedDate] = useState<string>("");
  // Drilldown-local From/To filter, layered on top of the page-level range.
  const [fromDate, setFromDate] = useState<string>("");
  const [toDate, setToDate] = useState<string>("");
  // Size cap: show at most N most-recent snapshots. Default 7. Applied on
  // top of the From/To filter so the user can both narrow the window AND
  // cap the count. The Jump-to-date filter ignores size (single day).
  const [size, setSize] = useState<number>(7);
  const [zipBusy, setZipBusy] = useState(false);
  const updatedByDate = useMemo(() => {
    const m = new Map<string, string>();
    for (const r of timeseries) if (r.updated_at) m.set(r.date, r.updated_at);
    return m;
  }, [timeseries]);

  const dateSet = useMemo(() => new Set(dates), [dates]);
  // Latest / earliest available snapshot dates (used as `max` / `min` on each
  // input so users can't pick outside the data window).
  const { minDate, maxDate } = useMemo(() => {
    if (!dates.length) return { minDate: "", maxDate: "" };
    let lo = dates[0];
    let hi = dates[0];
    for (const d of dates) {
      if (d < lo) lo = d;
      if (d > hi) hi = d;
    }
    return { minDate: lo, maxDate: hi };
  }, [dates]);

  const trimmedPick = pickedDate.trim();
  const pickMatches = trimmedPick !== "" && dateSet.has(trimmedPick);
  // Range filter (independent of pickedDate; pickedDate takes priority).
  const rangeFiltered = useMemo(() => {
    if (!fromDate && !toDate) return dates;
    return dates.filter(
      (d) => (!fromDate || d >= fromDate) && (!toDate || d <= toDate),
    );
  }, [dates, fromDate, toDate]);
  // When the user sets the drilldown From/To, expand `size` so every day in
  // that range is visible (otherwise the size cap would hide days the user
  // explicitly asked for). When From/To are cleared, leave `size` alone so
  // the default cap (7) takes over again.
  const rangeActiveForEffect = fromDate !== "" || toDate !== "";
  useEffect(() => {
    if (!rangeActiveForEffect) return;
    if (rangeInvalid) return;
    if (rangeFiltered.length > 0 && rangeFiltered.length !== size) {
      setSize(rangeFiltered.length);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [fromDate, toDate, rangeFiltered.length]);

  // `dates` arrives newest-first (parent calls `.reverse()`). Capping to the
  // first `size` items therefore keeps the most-recent N.
  const sizeCapped = useMemo(
    () => (size > 0 ? rangeFiltered.slice(0, size) : rangeFiltered),
    [rangeFiltered, size],
  );
  const visibleDates =
    trimmedPick === ""
      ? sizeCapped
      : pickMatches
        ? [trimmedPick]
        : [];
  const rangeActive = fromDate !== "" || toDate !== "";
  const rangeInvalid = !!(fromDate && toDate && fromDate > toDate);
  const sizeCapping = trimmedPick === "" && rangeFiltered.length > sizeCapped.length;

  const handleDownloadZip = async () => {
    if (!visibleDates.length) return;
    setZipBusy(true);
    try {
      const zip = new JSZip();
      const days = [...visibleDates];
      const CONCURRENCY = 6;
      let i = 0;
      const worker = async () => {
        while (i < days.length) {
          const idx = i++;
          const day = days[idx];
          try {
            const resp = await fetchDayPositions(day);
            const positions = resp.positions ?? [];
            if (!positions.length) continue;
            const extra = new Set<string>();
            for (const p of positions) {
              for (const k of Object.keys(p))
                if (!DAY_COLS.includes(k)) extra.add(k);
            }
            const cols = [...DAY_COLS, ...Array.from(extra).sort()];
            zip.file(`positions-${day}.csv`, rowsToCsv(positions, cols));
          } catch {
            // Skip days that fail; archive still gets the rest.
          }
        }
      };
      await Promise.all(
        Array.from({ length: Math.min(CONCURRENCY, days.length) }, worker),
      );
      const sorted = [...days].sort();
      const first = sorted[0];
      const last = sorted[sorted.length - 1];
      const blob = await zip.generateAsync({ type: "blob" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `positions-${first}_to_${last}.zip`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
    } finally {
      setZipBusy(false);
    }
  };

  return (
    <div>
      <div className="flex flex-wrap items-end gap-2 px-5 py-3 border-b border-border">
        <div className="space-y-1">
          <label className="block text-[11px] font-medium uppercase tracking-wide text-muted">
            Jump to date
          </label>
          <Input
            type="date"
            value={pickedDate}
            min={minDate || undefined}
            max={maxDate || undefined}
            onChange={(e) => {
              const v = e.target.value;
              setPickedDate(v);
              if (v && dateSet.has(v)) setOpen(v);
            }}
            className="w-44"
          />
        </div>
        <div className="space-y-1">
          <label className="block text-[11px] font-medium uppercase tracking-wide text-muted">
            From
          </label>
          <Input
            type="date"
            value={fromDate}
            min={minDate || undefined}
            max={maxDate || undefined}
            onChange={(e) => setFromDate(e.target.value)}
            disabled={trimmedPick !== ""}
            className="w-44"
          />
        </div>
        <div className="space-y-1">
          <label className="block text-[11px] font-medium uppercase tracking-wide text-muted">
            To
          </label>
          <Input
            type="date"
            value={toDate}
            min={fromDate || minDate || undefined}
            max={maxDate || undefined}
            onChange={(e) => setToDate(e.target.value)}
            disabled={trimmedPick !== ""}
            className="w-44"
          />
        </div>
        <div className="space-y-1">
          <label className="block text-[11px] font-medium uppercase tracking-wide text-muted">
            Size
          </label>
          <Input
            type="number"
            min={1}
            step={1}
            value={size}
            onChange={(e) => {
              const n = parseInt(e.target.value, 10);
              if (Number.isFinite(n) && n >= 1) setSize(n);
            }}
            disabled={trimmedPick !== ""}
            title="Show at most the N most-recent daily snapshots"
            className="w-24"
          />
        </div>
        {pickedDate || rangeActive ? (
          <Button
            variant="secondary"
            size="sm"
            onClick={() => {
              setPickedDate("");
              setFromDate("");
              setToDate("");
            }}
          >
            Clear
          </Button>
        ) : null}
        <Button
          variant="primary"
          size="sm"
          onClick={handleDownloadZip}
          disabled={zipBusy || !visibleDates.length || rangeInvalid}
          title={
            visibleDates.length
              ? `Download ${visibleDates.length} day${visibleDates.length === 1 ? "" : "s"} as ZIP of CSVs`
              : "No days in range"
          }
        >
          <FileArchive className="h-3.5 w-3.5" />
          {zipBusy ? "Zipping…" : "Download ZIP"}
        </Button>
        <span className="ml-auto self-center text-xs text-muted">
          {trimmedPick !== ""
            ? pickMatches
              ? `Showing ${trimmedPick}`
              : `No snapshot for ${trimmedPick} in range`
            : rangeInvalid
              ? "From is after To"
              : `${visibleDates.length} day${visibleDates.length === 1 ? "" : "s"}${
                  sizeCapping ? ` (capped from ${rangeFiltered.length})` : rangeActive ? " in filter" : " in range"
                }`}
        </span>
      </div>
      {rangeInvalid ? (
        <p className="px-5 py-8 text-center text-sm text-muted">
          "From" date is after "To" date — adjust the range.
        </p>
      ) : !visibleDates.length ? (
        <p className="px-5 py-8 text-center text-sm text-muted">
          {dates.length === 0
            ? "No days in range."
            : trimmedPick
              ? "Pick a date that has a snapshot, or clear the filter."
              : "No snapshots within the selected range."}
        </p>
      ) : (
        <div className="divide-y divide-border">
          {visibleDates.map((d) => {
            const isOpen = open === d;
            return (
              <div key={d}>
                <button
                  type="button"
                  onClick={() => setOpen(isOpen ? null : d)}
                  className="flex w-full items-center justify-between gap-3 px-5 py-2.5 text-left hover:bg-surface-2/60"
                >
                  <div className="flex items-center gap-2">
                    {isOpen ? (
                      <ChevronDown className="h-4 w-4 text-muted" />
                    ) : (
                      <ChevronRight className="h-4 w-4 text-muted" />
                    )}
                    <span className="font-mono text-sm text-fg">{d}</span>
                    <span className="text-xs text-muted">
                      {updatedByDate.get(d) ? `· updated ${updatedByDate.get(d)}` : ""}
                    </span>
                  </div>
                </button>
                {isOpen ? <DayPanel day={d} /> : null}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

const DAY_COLS = [
  "instrument_name",
  "side",
  "qty",
  "DTE",
  "strike",
  "index_price",
  "mark_price_btc",
  "mark_usd",
  "avg_price_btc",
  "avg_price_usd",
  "pnl_btc_total_deribit",
];

function DayPanel({ day }: { day: string }) {
  const q = useQuery({
    queryKey: ["positions-day", day],
    queryFn: () => fetchDayPositions(day),
    staleTime: 60_000,
  });
  if (q.isLoading) {
    return <div className="px-5 pb-3"><LoadingState label="Loading…" /></div>;
  }
  if (q.isError || !q.data) {
    return (
      <div className="px-5 pb-3">
        <ErrorState message="Could not load this day." onRetry={() => q.refetch()} />
      </div>
    );
  }
  const k = q.data.kpis ?? {};
  const positions = q.data.positions ?? [];
  const handleExport = () => {
    // Export the union of canonical DAY_COLS plus any extra keys present on
    // the records, so users can audit fields not shown in the on-screen table.
    const extra = new Set<string>();
    for (const p of positions) {
      for (const k of Object.keys(p)) if (!DAY_COLS.includes(k)) extra.add(k);
    }
    const cols = [...DAY_COLS, ...Array.from(extra).sort()];
    const csv = rowsToCsv(positions, cols);
    downloadCsv(`positions-${day}.csv`, csv);
  };
  return (
    <div className="space-y-3 px-5 pb-4">
      <div className="flex items-center justify-between gap-3">
        <div className="grid flex-1 grid-cols-2 gap-2 sm:grid-cols-6">
          <DK label="Open Positions" value={String(positions.length)} />
          <DK label="PnL Total" value={fmtUsd(k.pnl_total_usd)} tone={Number(k.pnl_total_usd) >= 0 ? "pos" : "neg"} />
          <DK label="PnL Floating" value={fmtUsd(k.pnl_float_usd)} tone={Number(k.pnl_float_usd) >= 0 ? "pos" : "neg"} />
          <DK label="PnL Realized" value={fmtUsd(k.pnl_real_usd)} tone={Number(k.pnl_real_usd) >= 0 ? "pos" : "neg"} />
          <DK label="Contracts" value={fmtNum(k.total_qty, 2)} />
          <DK label="PnL (BTC)" value={fmtNum(k.total_pnl_btc, 4)} tone={Number(k.total_pnl_btc) >= 0 ? "pos" : "neg"} />
        </div>
        <Button
          variant="secondary"
          size="sm"
          onClick={handleExport}
          disabled={!positions.length}
          title={positions.length ? `Download positions-${day}.csv` : "No rows to export"}
        >
          <Download className="h-3.5 w-3.5" />
          CSV
        </Button>
      </div>
      {positions.length ? (
        <Table>
          <Thead>
            <Tr>
              {DAY_COLS.map((c) => (
                <Th key={c}>{c}</Th>
              ))}
            </Tr>
          </Thead>
          <Tbody>
            {positions.map((p, i) => (
              <Tr key={String(p.instrument_name ?? i)}>
                {DAY_COLS.map((c) => (
                  <Td key={c} className="text-xs">
                    {formatCell(c, p[c])}
                  </Td>
                ))}
              </Tr>
            ))}
          </Tbody>
        </Table>
      ) : (
        <p className="text-sm text-muted">No positions recorded for this day.</p>
      )}
    </div>
  );
}

function DK({
  label,
  value,
  tone,
}: {
  label: string;
  value: string;
  tone?: "pos" | "neg";
}) {
  return (
    <div className="rounded-lg bg-surface-2 px-3 py-2">
      <div className="text-[11px] text-muted">{label}</div>
      <div
        className={cn(
          "mt-0.5 text-sm font-semibold tabular-nums",
          tone === "pos" ? "text-positive" : tone === "neg" ? "text-negative" : "text-fg",
        )}
      >
        {value}
      </div>
    </div>
  );
}

function formatCell(col: string, v: unknown): string {
  if (v === null || v === undefined) return "-";
  if (col === "instrument_name" || col === "side") return String(v);
  const n = Number(v);
  if (!Number.isFinite(n)) return String(v);
  if (col.endsWith("_usd") || col === "index_price") return fmtUsd(n);
  if (col.includes("btc")) return `₿${n.toFixed(6)}`;
  if (col === "qty" || col === "DTE" || col === "strike") return fmtNum(n, 2);
  return fmtNum(n, 4);
}

