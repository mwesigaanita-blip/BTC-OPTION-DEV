import { useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { ChevronDown, ChevronRight, Plus, Search } from "lucide-react";
import {
  createDecision,
  fetchMetrics,
  listDecisions,
  type Decision,
  type DecisionCreateInput,
  type DecisionStatus,
  type Priority,
  type SortKey,
} from "@/api/decisions";
import { PageHeader } from "@/components/shared/PageHeader";
import { MetricCard } from "@/components/shared/MetricCard";
import { LoadingState } from "@/components/shared/LoadingState";
import { ErrorState } from "@/components/shared/ErrorState";
import { Button } from "@/components/ui/Button";
import { Input } from "@/components/ui/Input";
import { DecisionCard } from "@/components/decisions/DecisionCard";
import { DecisionDetail } from "@/components/decisions/DecisionDetail";
import { NewDecisionForm } from "@/components/decisions/NewDecisionForm";
import { PRIORITIES } from "@/components/decisions/styles";

const SORT_OPTIONS: Array<{ id: SortKey; label: string }> = [
  { id: "newest", label: "Newest first" },
  { id: "oldest", label: "Oldest first" },
  { id: "recently_updated", label: "Recently updated" },
];

function groupByDate(decisions: Decision[]): Record<string, Decision[]> {
  const out: Record<string, Decision[]> = {};
  for (const d of decisions) {
    const key = (d.created_at_utc ?? "").slice(0, 10);
    if (key.length !== 10 || key[4] !== "-" || key[7] !== "-") continue;
    (out[key] ??= []).push(d);
  }
  return out;
}

export function DecisionBoardPage() {
  const qc = useQueryClient();
  const [selectedId, setSelectedId] = useState<number | null>(null);
  const [showNew, setShowNew] = useState(false);
  const [collapseOlder, setCollapseOlder] = useState(true);

  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<"All" | DecisionStatus>("All");
  const [priorityFilter, setPriorityFilter] = useState<"All" | Priority>("All");
  const [sort, setSort] = useState<SortKey>("newest");
  const [createErr, setCreateErr] = useState<string | null>(null);

  const params = useMemo(
    () => ({
      search: search.trim() || undefined,
      status: statusFilter === "All" ? undefined : statusFilter,
      priority: priorityFilter === "All" ? undefined : priorityFilter,
      sort,
    }),
    [search, statusFilter, priorityFilter, sort],
  );

  const metricsQ = useQuery({
    queryKey: ["decision-metrics"],
    queryFn: fetchMetrics,
    refetchInterval: 30_000,
  });

  const listQ = useQuery({
    queryKey: ["decisions", params],
    queryFn: () => listDecisions(params),
  });

  const createMut = useMutation({
    mutationFn: (body: DecisionCreateInput) => createDecision(body),
    onSuccess: () => {
      setShowNew(false);
      setCreateErr(null);
      qc.invalidateQueries({ queryKey: ["decisions"] });
      qc.invalidateQueries({ queryKey: ["decision-metrics"] });
    },
    onError: (e: any) => setCreateErr(e?.response?.data?.detail ?? String(e)),
  });

  if (selectedId != null) {
    return (
      <DecisionDetail
        decisionId={selectedId}
        onBack={() => setSelectedId(null)}
      />
    );
  }

  const metrics = metricsQ.data;
  const decisions = listQ.data?.decisions ?? [];
  const counts = listQ.data?.counts ?? {};
  const grouped = groupByDate(decisions);
  const sortedDates = Object.keys(grouped).sort((a, b) => (a < b ? 1 : -1));

  return (
    <div className="space-y-5 animate-fade-in">
      <PageHeader
        title="📋 Decision Board"
        description="Team collaboration board for portfolio decisions - propose, discuss, decide."
      />

      <div className="grid grid-cols-2 gap-3 md:grid-cols-5">
        <MetricCard label="Total Decisions" value={String(metrics?.total ?? 0)} />
        <MetricCard
          label="💡 Ideas"
          value={String(metrics?.by_status?.ideas ?? 0)}
        />
        <MetricCard
          label="🔍 Under Review"
          value={String(metrics?.by_status?.under_review ?? 0)}
        />
        <MetricCard
          label="✅ Done"
          value={String(metrics?.by_status?.done ?? 0)}
        />
        <MetricCard
          label="✅ Accepted"
          value={String(metrics?.by_outcome?.accepted ?? 0)}
        />
      </div>

      <div className="flex flex-wrap items-center gap-2">
        <div className="relative flex-1 min-w-[220px]">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted" />
          <Input
            placeholder="Search by title or description..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9"
          />
        </div>
        <select
          className="h-11 rounded-lg border border-border bg-surface-2 px-3 text-sm"
          value={statusFilter}
          onChange={(e) =>
            setStatusFilter(e.target.value as "All" | DecisionStatus)
          }
        >
          <option value="All">All statuses</option>
          <option value="ideas">Ideas</option>
          <option value="under_review">Under Review</option>
          <option value="done">Done</option>
        </select>
        <select
          className="h-11 rounded-lg border border-border bg-surface-2 px-3 text-sm"
          value={priorityFilter}
          onChange={(e) =>
            setPriorityFilter(e.target.value as "All" | Priority)
          }
        >
          <option value="All">All priorities</option>
          {PRIORITIES.map((p) => (
            <option key={p} value={p}>
              {p}
            </option>
          ))}
        </select>
        <select
          className="h-11 rounded-lg border border-border bg-surface-2 px-3 text-sm"
          value={sort}
          onChange={(e) => setSort(e.target.value as SortKey)}
        >
          {SORT_OPTIONS.map((s) => (
            <option key={s.id} value={s.id}>
              {s.label}
            </option>
          ))}
        </select>
        <Button onClick={() => setShowNew((v) => !v)}>
          <Plus className="h-4 w-4" /> New Decision
        </Button>
      </div>

      {showNew ? (
        <NewDecisionForm
          submitting={createMut.isPending}
          error={createErr}
          onCancel={() => {
            setShowNew(false);
            setCreateErr(null);
          }}
          onSubmit={(body) => {
            if (!body.title.trim()) {
              setCreateErr("Title is required.");
              return;
            }
            createMut.mutate(body);
          }}
        />
      ) : null}

      <label className="inline-flex cursor-pointer items-center gap-2 text-xs text-muted">
        <input
          type="checkbox"
          checked={collapseOlder}
          onChange={(e) => setCollapseOlder(e.target.checked)}
        />
        Collapse older dates
      </label>

      {listQ.isLoading ? (
        <LoadingState label="Loading board…" />
      ) : listQ.error ? (
        <ErrorState
          message={(listQ.error as Error).message}
          onRetry={() => listQ.refetch()}
        />
      ) : sortedDates.length === 0 ? (
        <div className="rounded-lg border border-border bg-surface-2/30 py-10 text-center text-sm text-muted">
          No decisions match the current filters.
        </div>
      ) : (
        <div className="space-y-3">
          {sortedDates.map((date, i) => (
            <DayGroup
              key={date}
              date={date}
              items={grouped[date]}
              counts={counts}
              defaultOpen={i === 0 || !collapseOlder}
              onOpen={(id) => setSelectedId(id)}
            />
          ))}
        </div>
      )}
    </div>
  );
}

function DayGroup({
  date,
  items,
  counts,
  defaultOpen,
  onOpen,
}: {
  date: string;
  items: Decision[];
  counts: Record<number, { actions: number; comments: number }>;
  defaultOpen: boolean;
  onOpen: (id: number) => void;
}) {
  const [open, setOpen] = useState(defaultOpen);
  const ideas = items.filter((d) => d.status === "ideas");
  const under = items.filter((d) => d.status === "under_review");
  const done = items.filter((d) => d.status === "done");

  return (
    <div className="rounded-xl border border-border bg-surface">
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        className="flex w-full items-center gap-2 px-4 py-3 text-sm font-semibold text-fg hover:bg-surface-2/40"
      >
        {open ? (
          <ChevronDown className="h-4 w-4" />
        ) : (
          <ChevronRight className="h-4 w-4" />
        )}
        <span>📅 {date}</span>
        <span className="text-muted">({items.length})</span>
      </button>
      {open ? (
        <div className="grid grid-cols-1 gap-3 px-4 pb-4 md:grid-cols-3">
          <StatusColumn
            title="💡 Ideas"
            emptyMsg="No ideas"
            items={ideas}
            counts={counts}
            onOpen={onOpen}
          />
          <StatusColumn
            title="🔍 Under Review"
            emptyMsg="No items under review"
            items={under}
            counts={counts}
            onOpen={onOpen}
          />
          <StatusColumn
            title="✅ Done"
            emptyMsg="No finalized decisions"
            items={done}
            counts={counts}
            onOpen={onOpen}
          />
        </div>
      ) : null}
    </div>
  );
}

function StatusColumn({
  title,
  emptyMsg,
  items,
  counts,
  onOpen,
}: {
  title: string;
  emptyMsg: string;
  items: Decision[];
  counts: Record<number, { actions: number; comments: number }>;
  onOpen: (id: number) => void;
}) {
  return (
    <div className="space-y-2">
      <div className="flex items-center gap-2 border-b border-border pb-2 text-sm font-bold text-fg">
        <span>{title}</span>
        <span className="text-muted">({items.length})</span>
      </div>
      {items.length === 0 ? (
        <div className="py-6 text-center text-xs text-muted">{emptyMsg}</div>
      ) : (
        items.map((d) => (
          <DecisionCard
            key={d.id}
            decision={d}
            actionsCount={counts[d.id]?.actions ?? 0}
            commentsCount={counts[d.id]?.comments ?? 0}
            onOpen={() => onOpen(d.id)}
          />
        ))
      )}
    </div>
  );
}
