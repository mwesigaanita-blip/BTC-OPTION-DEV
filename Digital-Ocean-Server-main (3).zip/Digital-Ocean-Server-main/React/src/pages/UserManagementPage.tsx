import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { ChevronDown, ChevronRight } from "lucide-react";
import {
  fetchUsers,
  createUser,
  updateUser,
  type AppUser,
  type UsersResponse,
} from "@/api/userManagement";
import { useAuth } from "@/auth/AuthContext";
import { PageHeader } from "@/components/shared/PageHeader";
import { LoadingState } from "@/components/shared/LoadingState";
import { ErrorState } from "@/components/shared/ErrorState";
import { Card, CardBody, CardHeader } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { Input } from "@/components/ui/Input";
import { Badge } from "@/components/ui/Badge";
import { cn } from "@/lib/utils";

// ── helpers ────────────────────────────────────────────────────────────────

function fmtDate(s: string | null | undefined): string {
  if (!s) return "Never";
  try {
    return new Date(s).toLocaleString("en-US", {
      year: "numeric",
      month: "short",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
    });
  } catch {
    return s;
  }
}

// ── All Users tab ──────────────────────────────────────────────────────────

function UserRow({ user }: { user: AppUser }) {
  const [open, setOpen] = useState(false);
  const isOperator = user.role === "operator";
  const isActive = Boolean(user.is_active);

  return (
    <div className="border-b border-zinc-800 last:border-0">
      <button
        onClick={() => setOpen((o) => !o)}
        className="flex w-full items-center gap-3 px-4 py-3 text-left hover:bg-zinc-800/40"
      >
        {open ? (
          <ChevronDown size={14} className="shrink-0 text-zinc-500" />
        ) : (
          <ChevronRight size={14} className="shrink-0 text-zinc-500" />
        )}
        <span
          className={cn(
            "h-2 w-2 shrink-0 rounded-full",
            isActive ? "bg-emerald-400" : "bg-red-500",
          )}
        />
        <span className="flex-1 font-medium text-zinc-100">{user.username}</span>
        <Badge tone={isOperator ? "brand" : "neutral"}>
          {isOperator ? "operator" : "viewer"}
        </Badge>
      </button>

      {open && (
        <div className="grid grid-cols-1 gap-4 px-8 pb-4 pt-1 sm:grid-cols-2">
          <div className="space-y-1 text-sm">
            <p className="text-zinc-400">
              Role: <span className="text-zinc-200">{user.role}</span>
            </p>
            <p className="text-zinc-400">
              Status:{" "}
              <span className={isActive ? "text-emerald-400" : "text-red-400"}>
                {isActive ? "Active" : "Disabled"}
              </span>
            </p>
            <p className="text-zinc-400">
              Created: <span className="text-zinc-300">{fmtDate(user.created_at)}</span>
            </p>
            <p className="text-zinc-400">
              Last login: <span className="text-zinc-300">{fmtDate(user.last_login)}</span>
            </p>
          </div>
          <div className="text-sm">
            <p className="text-zinc-400">
              Access:{" "}
              <span className="text-zinc-300">
                {isOperator
                  ? "All pages (operator)"
                  : "All pages except User Management"}
              </span>
            </p>
          </div>
        </div>
      )}
    </div>
  );
}

// ── Add User tab ───────────────────────────────────────────────────────────

interface AddFormState {
  username: string;
  password: string;
  confirmPassword: string;
  role: string;
}

function AddUserForm({ onSuccess }: { onSuccess: () => void }) {
  const queryClient = useQueryClient();
  const [form, setForm] = useState<AddFormState>({
    username: "",
    password: "",
    confirmPassword: "",
    role: "viewer",
  });
  const [errors, setErrors] = useState<string[]>([]);
  const [success, setSuccess] = useState("");

  const mutation = useMutation({
    mutationFn: () =>
      createUser({
        username: form.username.trim(),
        password: form.password,
        role: form.role,
        // Per-page grants no longer used; backend ignores this field.
        pages: [],
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["users"] });
      setSuccess(`User "${form.username.trim()}" created.`);
      setForm({ username: "", password: "", confirmPassword: "", role: "viewer" });
      setErrors([]);
      onSuccess();
    },
    onError: (err: Error) => {
      setErrors([err.message]);
    },
  });

  function validate(): string[] {
    const errs: string[] = [];
    if (!form.username.trim()) errs.push("Username cannot be empty.");
    if (form.password.length < 8) errs.push("Password must be at least 8 characters.");
    if (form.password !== form.confirmPassword) errs.push("Passwords do not match.");
    return errs;
  }

  function submit(e: React.FormEvent) {
    e.preventDefault();
    setSuccess("");
    const errs = validate();
    if (errs.length) { setErrors(errs); return; }
    setErrors([]);
    mutation.mutate();
  }

  return (
    <form onSubmit={submit} className="max-w-md space-y-4">
      <div>
        <label className="mb-1 block text-sm text-zinc-400">Username</label>
        <Input
          value={form.username}
          onChange={(e) => setForm((p) => ({ ...p, username: e.target.value }))}
          placeholder="e.g. john"
        />
      </div>
      <div>
        <label className="mb-1 block text-sm text-zinc-400">Password</label>
        <Input
          type="password"
          value={form.password}
          onChange={(e) => setForm((p) => ({ ...p, password: e.target.value }))}
          placeholder="Min 8 characters"
        />
      </div>
      <div>
        <label className="mb-1 block text-sm text-zinc-400">Confirm Password</label>
        <Input
          type="password"
          value={form.confirmPassword}
          onChange={(e) => setForm((p) => ({ ...p, confirmPassword: e.target.value }))}
        />
      </div>
      <div>
        <label className="mb-1 block text-sm text-zinc-400">Role</label>
        <select
          value={form.role}
          onChange={(e) => setForm((p) => ({ ...p, role: e.target.value }))}
          className="w-full rounded-md border border-zinc-700 bg-zinc-800 px-3 py-2 text-sm text-zinc-100 focus:border-blue-500 focus:outline-none"
        >
          <option value="operator">Operator (full access + User Management)</option>
          <option value="viewer">Viewer (all pages except User Management)</option>
        </select>
      </div>

      {errors.length > 0 && (
        <div className="space-y-1">
          {errors.map((e, i) => (
            <p key={i} className="text-sm text-red-400">{e}</p>
          ))}
        </div>
      )}
      {success && <p className="text-sm text-emerald-400">{success}</p>}

      <Button type="submit" disabled={mutation.isPending}>
        {mutation.isPending ? "Creating…" : "Create User"}
      </Button>
    </form>
  );
}

// ── Edit User tab ──────────────────────────────────────────────────────────

function EditUserForm({
  users,
  currentUsername,
}: {
  users: AppUser[];
  currentUsername: string;
}) {
  const queryClient = useQueryClient();
  const [selectedId, setSelectedId] = useState<number | null>(
    users.length > 0 ? users[0].id : null,
  );
  const [newPw, setNewPw] = useState("");
  const [newPwConfirm, setNewPwConfirm] = useState("");
  const [errors, setErrors] = useState<string[]>([]);
  const [success, setSuccess] = useState("");

  const selected = users.find((u) => u.id === selectedId) ?? users[0];
  const isSelf = selected?.username === currentUsername;

  const [editRole, setEditRole] = useState<"operator" | "viewer">(
    (selected?.role as "operator" | "viewer") ?? "viewer",
  );
  const [editActive, setEditActive] = useState(Boolean(selected?.is_active));

  // Reset local state when selected user changes
  function selectUser(id: number) {
    const u = users.find((x) => x.id === id);
    if (!u) return;
    setSelectedId(id);
    setEditRole(u.role as "operator" | "viewer");
    setEditActive(Boolean(u.is_active));
    setNewPw("");
    setNewPwConfirm("");
    setErrors([]);
    setSuccess("");
  }

  const mutation = useMutation({
    mutationFn: () =>
      updateUser(selected!.id, {
        role: isSelf ? selected!.role : editRole,
        // Backend ignores this under the role-only model.
        pages: [],
        is_active: isSelf ? Boolean(selected!.is_active) : editActive,
        new_password: newPw || undefined,
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["users"] });
      setSuccess(`User "${selected!.username}" updated.`);
      setNewPw("");
      setNewPwConfirm("");
      setErrors([]);
    },
    onError: (err: Error) => {
      setErrors([err.message]);
    },
  });

  function validate(): string[] {
    const errs: string[] = [];
    if (newPw || newPwConfirm) {
      if (newPw.length < 8) errs.push("New password must be at least 8 characters.");
      if (newPw !== newPwConfirm) errs.push("Passwords do not match.");
    }
    return errs;
  }

  function submit(e: React.FormEvent) {
    e.preventDefault();
    setSuccess("");
    const errs = validate();
    if (errs.length) { setErrors(errs); return; }
    setErrors([]);
    mutation.mutate();
  }

  if (!selected) return <p className="text-sm text-zinc-400">No users found.</p>;

  return (
    <form onSubmit={submit} className="space-y-5">
      <div>
        <label className="mb-1 block text-sm text-zinc-400">Select user to edit</label>
        <select
          value={selected.id}
          onChange={(e) => selectUser(Number(e.target.value))}
          className="w-full max-w-xs rounded-md border border-zinc-700 bg-zinc-800 px-3 py-2 text-sm text-zinc-100 focus:border-blue-500 focus:outline-none"
        >
          {users.map((u) => (
            <option key={u.id} value={u.id}>{u.username}</option>
          ))}
        </select>
      </div>

      {isSelf && (
        <div className="rounded-lg border border-amber-500/30 bg-amber-500/10 px-4 py-3 text-sm text-amber-400">
          You are editing your own account. Role and active status are locked.
        </div>
      )}

      <div className="max-w-md space-y-4">
        <div>
          <label className="mb-1 block text-sm text-zinc-400">Role</label>
          <select
            value={isSelf ? selected.role : editRole}
            onChange={(e) => setEditRole(e.target.value as "operator" | "viewer")}
            disabled={isSelf}
            className="w-full rounded-md border border-zinc-700 bg-zinc-800 px-3 py-2 text-sm text-zinc-100 focus:border-blue-500 focus:outline-none disabled:opacity-40"
          >
            <option value="operator">Operator (full access + User Management)</option>
            <option value="viewer">Viewer (all pages except User Management)</option>
          </select>
        </div>

        <label className="flex cursor-pointer items-center gap-2 text-sm">
          <input
            type="checkbox"
            checked={isSelf ? Boolean(selected.is_active) : editActive}
            onChange={(e) => setEditActive(e.target.checked)}
            disabled={isSelf}
            className="h-4 w-4 accent-blue-500 disabled:opacity-40"
          />
          <span className={cn("text-zinc-300", isSelf && "opacity-40")}>Account active</span>
        </label>

        <div>
          <p className="mb-1 text-sm text-zinc-400">Reset Password</p>
          <p className="mb-2 text-xs text-zinc-500">Leave blank to keep current password.</p>
          <div className="space-y-2">
            <Input
              type="password"
              value={newPw}
              onChange={(e) => setNewPw(e.target.value)}
              placeholder="New password (min 8 chars)"
            />
            <Input
              type="password"
              value={newPwConfirm}
              onChange={(e) => setNewPwConfirm(e.target.value)}
              placeholder="Confirm new password"
            />
          </div>
        </div>
      </div>

      {errors.length > 0 && (
        <div className="space-y-1">
          {errors.map((e, i) => (
            <p key={i} className="text-sm text-red-400">{e}</p>
          ))}
        </div>
      )}
      {success && <p className="text-sm text-emerald-400">{success}</p>}

      <Button type="submit" disabled={mutation.isPending}>
        {mutation.isPending ? "Saving…" : "Save Changes"}
      </Button>
    </form>
  );
}

// ── Page ───────────────────────────────────────────────────────────────────

type TabId = "users" | "add" | "edit";

export default function UserManagementPage() {
  const { user: authUser } = useAuth();
  const [tab, setTab] = useState<TabId>("users");

  const { data, isLoading, isError, error } = useQuery<UsersResponse>({
    queryKey: ["users"],
    queryFn: fetchUsers,
    staleTime: 30_000,
  });

  const users = data?.users ?? [];
  const currentUsername = authUser?.username ?? "";

  const TABS: { id: TabId; label: string }[] = [
    { id: "users", label: "All Users" },
    { id: "add", label: "Add User" },
    { id: "edit", label: "Edit User" },
  ];

  return (
    <div className="space-y-6">
      <PageHeader
        title="User Management"
        description={`Logged in as ${currentUsername} · operator`}
      />

      {/* Tab bar */}
      <div className="flex gap-1 border-b border-zinc-700">
        {TABS.map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={cn(
              "px-4 py-2 text-sm font-medium transition-colors",
              tab === t.id
                ? "border-b-2 border-blue-500 text-blue-400"
                : "text-zinc-400 hover:text-zinc-200",
            )}
          >
            {t.label}
          </button>
        ))}
      </div>

      {isLoading && <LoadingState />}
      {isError && (
        <ErrorState message={(error as Error).message ?? "Failed to load users"} />
      )}

      {!isLoading && !isError && (
        <>
          {tab === "users" && (
            <Card>
              <CardHeader title="Team Members" subtitle={`${users.length} user${users.length !== 1 ? "s" : ""}`} />
              {users.length === 0 ? (
                <CardBody>
                  <p className="text-sm text-zinc-400">
                    No users found. Use the Add User tab to create one.
                  </p>
                </CardBody>
              ) : (
                <div>
                  {users.map((u) => (
                    <UserRow key={u.id} user={u} />
                  ))}
                </div>
              )}
            </Card>
          )}

          {tab === "add" && (
            <Card>
              <CardHeader title="Add New Team Member" />
              <CardBody>
                <AddUserForm onSuccess={() => setTab("users")} />
              </CardBody>
            </Card>
          )}

          {tab === "edit" && (
            <Card>
              <CardHeader title="Edit Team Member" />
              <CardBody>
                {users.length === 0 ? (
                  <p className="text-sm text-zinc-400">No users found.</p>
                ) : (
                  <EditUserForm
                    users={users}
                    currentUsername={currentUsername}
                  />
                )}
              </CardBody>
            </Card>
          )}
        </>
      )}
    </div>
  );
}
