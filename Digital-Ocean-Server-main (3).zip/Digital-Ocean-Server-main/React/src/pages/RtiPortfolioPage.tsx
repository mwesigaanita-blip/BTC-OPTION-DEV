import { useEffect, useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Download, RefreshCw, Save } from "lucide-react";
import {
  fetchRtiEquityHistory,
  fetchRtiTradeRecap,
  refreshRtiTradeRecap,
  saveRtiTradeComment,
  type TradeRecapResponse,
} from "@/api/rti";
import { PageHeader } from "@/components/shared/PageHeader";
import { MetricCard } from "@/components/shared/MetricCard";
import { LoadingState } from "@/components/shared/LoadingState";
import { ErrorState } from "@/components/shared/ErrorState";
import { Card, CardBody, CardHeader } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { Input } from "@/components/ui/Input";
import { Tabs } from "@/components/ui/Tabs";
import {
  Table,
  Tbody,
  Td,
  Th,
  Thead,
  Tr,
} from "@/components/ui/Table";
import { cn } from "@/lib/utils";

// ---------------------------------------------------------------------------
// Utilities
// ---------------------------------------------------------------------------

function fmtNum(v: unknown, digits = 2): string {
  const n = Number(v);
  if (!Number.isFinite(n)) return "";
  return n.toLocaleString("en-US", {
    minimumFractionDigits: digits,
    maximumFractionDigits: digits,
  });
}

function fmtPct(v: unknown, digits = 2): string {
  const n = Number(v);
  if (!Number.isFinite(n)) return "";
  return `${n.toFixed(digits)}%`;
}

function rowsToCsv(rows: Record<string, unknown>[], columns: string[]): string {
  const escape = (cell: unknown): string => {
    if (cell == null) return "";
    const s = String(cell);
    if (/[",\n]/.test(s)) return `"${s.replace(/"/g, '""')}"`;
    return s;
  };
  const header = columns.map(escape).join(",");
  const body = rows
    .map((r) => columns.map((c) => escape(r[c])).join(","))
    .join("\n");
  return `${header}\n${body}`;
}

function downloadCsv(filename: string, content: string): void {
  const blob = new Blob([content], { type: "text/csv;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

const ACTION_ICON: Record<string, string> = {
  open: "🟢 open",
  close: "🔴 close",
  adjust: "🟡 adjust",
  expired: "⚫ expired",
  liquidated: "🚨 liquidated",
  funding: "💰 funding",
  settlement: "💰 settlement",
  spot: "💵 spot",
  deposit: "⬆️ deposit",
  withdrawal: "⬇️ withdrawal",
  transfer: "⇄ transfer",
};

// ---------------------------------------------------------------------------
// Page
// ---------------------------------------------------------------------------

type TabId = "analytics" | "recap";

export function RtiPortfolioPage() {
  const [tab, setTab] = useState<TabId>("analytics");

  return (
    <div className="space-y-5 animate-fade-in">
      <PageHeader
        title="RTI Portfolio Management"
        description="Historical account equity view + Deribit transaction log with comments."
      />
      <Tabs
        active={tab}
        onChange={(id) => setTab(id as TabId)}
        tabs={[
          { id: "analytics", label: "Analytics" },
          { id: "recap", label: "Trade Recap" },
        ]}
      />
      {tab === "analytics" ? <AnalyticsTab /> : <TradeRecapTab />}
    </div>
  );
}

// ---------------------------------------------------------------------------
// Analytics tab
// ---------------------------------------------------------------------------

const FLOAT_COLS_4 = new Set([
  "BOD Value",
  "EOD Value",
  "Change BTC",
  "BTC Amount",
]);
const FLOAT_COLS_2 = new Set([
  "Change $",
  "Spot Price",
  "% MM",
  "% IM",
  "USDT Amount",
  "USDC Amount",
  "Total USD (AUM)",
]);

function AnalyticsTab() {
  const q = useQuery({
    queryKey: ["rti-equity-history"],
    queryFn: fetchRtiEquityHistory,
    refetchInterval: 60_000,
    retry: false,
  });

  if (q.isLoading) return <LoadingState label="Loading account equity history…" />;
  if (q.error || !q.data) {
    return (
      <ErrorState
        message={(q.error as Error)?.message ?? "Failed to load equity history"}
        onRetry={() => q.refetch()}
      />
    );
  }

  const { rows, columns, last_date, total_rows } = q.data;
  if (rows.length === 0) {
    return (
      <Card>
        <CardBody className="pt-4 text-sm text-muted">
          No account equity history found in account_snapshots.
        </CardBody>
      </Card>
    );
  }

  // Latest first for display + download
  const sortedDesc = [...rows].sort((a, b) => {
    const da = String(a.Date ?? "");
    const db = String(b.Date ?? "");
    return da < db ? 1 : -1;
  });
  const latest20 = sortedDesc.slice(0, 20);

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        <MetricCard label="Latest Available Date" value={last_date ?? "-"} />
        <MetricCard label="Total Rows" value={total_rows.toLocaleString()} />
      </div>

      <div className="flex gap-2">
        <Button
          variant="secondary"
          size="sm"
          onClick={() =>
            downloadCsv(
              "account_equity_history.csv",
              rowsToCsv(sortedDesc, columns),
            )
          }
        >
          <Download className="h-3.5 w-3.5" />
          Download Full Equity History CSV
        </Button>
      </div>

      <Card>
        <CardHeader title="Latest Records" subtitle="Most recent 20 snapshots" />
        <CardBody className="px-0 pt-0">
          <EquityTable rows={latest20} columns={columns} />
        </CardBody>
      </Card>
    </div>
  );
}

function EquityTable({
  rows,
  columns,
}: {
  rows: Record<string, unknown>[];
  columns: string[];
}) {
  function renderCell(col: string, raw: unknown): string {
    if (raw == null || raw === "") return "";
    if (col === "% Change") return fmtPct(raw, 2);
    if (FLOAT_COLS_4.has(col)) return fmtNum(raw, 4);
    if (FLOAT_COLS_2.has(col)) return fmtNum(raw, 2);
    return String(raw);
  }

  return (
    <Table>
      <Thead>
        <Tr>
          {columns.map((c) => (
            <Th
              key={c}
              className={
                FLOAT_COLS_4.has(c) || FLOAT_COLS_2.has(c) || c === "% Change"
                  ? "text-right"
                  : ""
              }
            >
              {c}
            </Th>
          ))}
        </Tr>
      </Thead>
      <Tbody>
        {rows.map((r, i) => (
          <Tr key={String(r.Date ?? i)}>
            {columns.map((c) => {
              const num =
                FLOAT_COLS_4.has(c) || FLOAT_COLS_2.has(c) || c === "% Change";
              return (
                <Td
                  key={c}
                  className={cn(num && "text-right tabular-nums")}
                >
                  {renderCell(c, r[c])}
                </Td>
              );
            })}
          </Tr>
        ))}
      </Tbody>
    </Table>
  );
}

// ---------------------------------------------------------------------------
// Trade Recap tab
// ---------------------------------------------------------------------------

function TradeRecapTab() {
  const qc = useQueryClient();
  const q = useQuery({
    queryKey: ["rti-trade-recap"],
    queryFn: fetchRtiTradeRecap,
    retry: false,
  });

  const refreshMut = useMutation({
    mutationFn: () => refreshRtiTradeRecap(365, 0),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["rti-trade-recap"] });
    },
  });

  if (q.isLoading) return <LoadingState label="Loading trade recap…" />;
  if (q.error) {
    return (
      <ErrorState
        message={(q.error as Error)?.message ?? "Failed to load trade recap"}
        onRetry={() => q.refetch()}
      />
    );
  }

  const data = q.data;
  const refreshErr =
    (refreshMut.error as { response?: { data?: { detail?: string } }; message?: string } | null)
      ?.response?.data?.detail ??
    (refreshMut.error as Error | null)?.message ??
    null;

  return (
    <div className="space-y-4">
      <Card>
        <CardBody className="flex flex-wrap items-center gap-3 pt-4">
          <Button
            variant="secondary"
            onClick={() => refreshMut.mutate()}
            disabled={refreshMut.isPending}
          >
            <RefreshCw
              className={cn(
                "h-3.5 w-3.5",
                refreshMut.isPending && "animate-spin",
              )}
            />
            Refresh from Deribit
          </Button>
          {refreshMut.isSuccess ? (
            <div className="flex flex-col gap-1 text-xs">
              <div
                className={cn(
                  refreshMut.data.new_rows > 0
                    ? "text-positive"
                    : refreshMut.data.new_rows === 0
                      ? "text-muted"
                      : "text-warning",
                )}
              >
                {refreshMut.data.new_rows > 0
                  ? `${refreshMut.data.new_rows} new transaction(s) added.`
                  : refreshMut.data.new_rows === 0
                    ? "No new transactions found."
                    : "Skipped (cooldown active)."}
              </div>
              {refreshMut.data.per_currency &&
              refreshMut.data.per_currency.length > 0 ? (
                <div className="flex flex-wrap gap-2">
                  {refreshMut.data.per_currency.map((r) => (
                    <span
                      key={r.currency}
                      className={cn(
                        "rounded-md border px-2 py-0.5 text-[0.7rem]",
                        r.error
                          ? "border-negative/40 bg-negative/10 text-negative"
                          : r.new_rows > 0
                            ? "border-positive/40 bg-positive/10 text-positive"
                            : "border-border bg-surface-2 text-muted",
                      )}
                      title={r.error ?? ""}
                    >
                      <span className="font-mono">{r.currency}</span>:{" "}
                      {r.error
                        ? "error"
                        : r.new_rows === -1
                          ? "cooldown"
                          : `${r.new_rows} new`}
                    </span>
                  ))}
                </div>
              ) : null}
            </div>
          ) : null}
          {refreshErr ? <div className="text-xs text-negative">{refreshErr}</div> : null}
        </CardBody>
      </Card>

      {!data || !data.available ? (
        <Card>
          <CardBody className="pt-4 text-sm text-muted">
            No trade data available. Click{" "}
            <span className="font-semibold">Refresh from Deribit</span> to fetch.
          </CardBody>
        </Card>
      ) : (
        <TradeRecapBody data={data} />
      )}
    </div>
  );
}

const PAGE_SIZE_OPTIONS: Array<{ value: number; label: string }> = [
  { value: 10, label: "10" },
  { value: 25, label: "25" },
  { value: 50, label: "50" },
  { value: 100, label: "100" },
  { value: 200, label: "200" },
  { value: 0, label: "All" }, // 0 = unlimited
];

function TradeRecapBody({ data }: { data: TradeRecapResponse }) {
  const qc = useQueryClient();
  const rows = data.rows;

  // Filter state
  const [instType, setInstType] = useState<string>("All");
  const [action, setAction] = useState<string>("All");
  const [instrument, setInstrument] = useState<string>("All");
  const [dateFrom, setDateFrom] = useState<string>("");
  const [pageSize, setPageSize] = useState<number>(50);

  // Options derived from data. The earliest date is taken across multiple
  // candidate columns (`date` from the engine + the underlying `trade_date`)
  // so a row with one column blank still contributes to the picker's bounds.
  const { instTypes, actions, instruments, defaultFrom } = useMemo(() => {
    const it = new Set<string>();
    const ac = new Set<string>();
    const inst = new Set<string>();
    let minDate = "";
    for (const r of rows) {
      const t = String(r.instrument_type ?? "");
      if (t) it.add(t);
      const a = String(r.action ?? "");
      if (a) ac.add(a);
      const i = String(r.instrument_name ?? "").trim();
      if (i) inst.add(i);
      const d = String(r.date ?? r.trade_date ?? "").slice(0, 10);
      if (d && d.length === 10 && (minDate === "" || d < minDate)) minDate = d;
    }
    return {
      instTypes: ["All", ...Array.from(it).sort()],
      actions: ["All", ...Array.from(ac).sort()],
      instruments: ["All", ...Array.from(inst).sort()],
      defaultFrom: minDate,
    };
  }, [rows]);

  // Initialize date-from to the earliest data point
  useEffect(() => {
    if (!dateFrom && defaultFrom) setDateFrom(defaultFrom);
  }, [defaultFrom, dateFrom]);

  // Apply filters + sort newest first.
  //
  // The date filter compares the YYYY-MM-DD string directly (lexicographic
  // ordering = chronological ordering for ISO dates). The earlier version
  // used `timestamp_ms` which is `0` on account-level events that Deribit
  // doesn't stamp (transfers, some settlements), causing those rows - and
  // sometimes the whole table - to be silently filtered out.
  const filtered = useMemo(() => {
    return rows
      .filter((r) => {
        if (instType !== "All" && String(r.instrument_type ?? "") !== instType) return false;
        if (action !== "All" && String(r.action ?? "") !== action) return false;
        if (instrument !== "All" && String(r.instrument_name ?? "") !== instrument) return false;
        if (dateFrom) {
          const dStr = String(r.date ?? r.trade_date ?? "").slice(0, 10);
          if (dStr && dStr.length === 10 && dStr < dateFrom) return false;
        }
        return true;
      })
      .sort((a, b) => {
        const ta = Number(a.timestamp_ms ?? 0);
        const tb = Number(b.timestamp_ms ?? 0);
        if (tb !== ta) return tb - ta;
        // Fall back to the date string for rows with missing timestamp_ms
        // so they still land in roughly the right place.
        const da = String(a.date ?? a.trade_date ?? "");
        const db = String(b.date ?? b.trade_date ?? "");
        return da < db ? 1 : da > db ? -1 : 0;
      });
  }, [rows, instType, action, instrument, dateFrom]);

  // Apply the per-page cap AFTER filtering. pageSize=0 means "all".
  const visible = useMemo(() => {
    if (!pageSize || pageSize <= 0) return filtered;
    return filtered.slice(0, pageSize);
  }, [filtered, pageSize]);

  // Inline comment editing - one mutation, keyed by trade_id at submit time so
  // it can save any row independently. The UI tracks which row is currently
  // saving so we can render a per-row "Saving…" indicator.
  const [savingTradeId, setSavingTradeId] = useState<string | null>(null);
  const [savedFlash, setSavedFlash] = useState<string | null>(null);

  const handleSaveComment = async (tradeId: string, comment: string) => {
    if (!tradeId) return;
    setSavingTradeId(tradeId);
    try {
      await saveRtiTradeComment(tradeId, comment);
      setSavedFlash(tradeId);
      window.setTimeout(() => {
        setSavedFlash((curr) => (curr === tradeId ? null : curr));
      }, 1500);
      await qc.invalidateQueries({ queryKey: ["rti-trade-recap"] });
    } finally {
      setSavingTradeId((curr) => (curr === tradeId ? null : curr));
    }
  };

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        <MetricCard label="Total Events" value={data.kpis.total_events.toLocaleString()} />
        <MetricCard label="Trades" value={data.kpis.total_trades.toLocaleString()} />
        <MetricCard
          label="Total Fees ($)"
          value={`$${data.kpis.total_fees_usd.toLocaleString(undefined, {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2,
          })}`}
        />
        <MetricCard
          label="Total Premium ($)"
          value={`$${data.kpis.total_premium_usd.toLocaleString(undefined, {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2,
          })}`}
        />
      </div>

      <Card>
        <CardHeader title="Transaction Log" />
        <CardBody className="pt-0">
          <div className="grid grid-cols-2 gap-2 md:grid-cols-5">
            <SelectField
              label="Instrument Type"
              value={instType}
              onChange={setInstType}
              options={instTypes}
            />
            <SelectField
              label="Action"
              value={action}
              onChange={setAction}
              options={actions}
            />
            <SelectField
              label="Instrument"
              value={instrument}
              onChange={setInstrument}
              options={instruments}
            />
            <div>
              <label className="block text-xs font-medium text-muted">From</label>
              <Input
                type="date"
                value={dateFrom}
                onChange={(e) => setDateFrom(e.target.value)}
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-muted">
                Rows per page
              </label>
              <select
                className="h-11 w-full rounded-lg border border-border bg-surface-2 px-3 text-sm"
                value={String(pageSize)}
                onChange={(e) => setPageSize(Number(e.target.value))}
              >
                {PAGE_SIZE_OPTIONS.map((o) => (
                  <option key={o.value} value={o.value}>
                    {o.label}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="mt-3">
            {filtered.length === 0 ? (
              <div className="rounded-lg border border-border bg-surface-2/30 py-6 text-center text-sm text-muted">
                No events found for the selected filters.
              </div>
            ) : (
              <>
                <div className="mb-2 text-xs text-muted">
                  Showing{" "}
                  <span className="font-semibold text-fg">
                    {visible.length.toLocaleString()}
                  </span>{" "}
                  of{" "}
                  <span className="font-semibold text-fg">
                    {filtered.length.toLocaleString()}
                  </span>{" "}
                  filtered events
                  {pageSize > 0 && filtered.length > pageSize ? (
                    <>
                      {" "}
                      ·{" "}
                      <button
                        type="button"
                        className="underline hover:text-fg"
                        onClick={() => setPageSize(0)}
                      >
                        show all
                      </button>
                    </>
                  ) : null}
                </div>
                <TransactionTable
                  rows={visible}
                  onSaveComment={handleSaveComment}
                  savingTradeId={savingTradeId}
                  savedFlash={savedFlash}
                />
              </>
            )}
          </div>

          <div className="mt-4 flex flex-wrap gap-2">
            <Button
              variant="secondary"
              size="sm"
              onClick={() =>
                downloadCsv(
                  "transaction_log.csv",
                  rowsToCsv(filtered, Object.keys(filtered[0] ?? {})),
                )
              }
              disabled={filtered.length === 0}
            >
              <Download className="h-3.5 w-3.5" />
              Download Transaction Log CSV
            </Button>
          </div>
        </CardBody>
      </Card>
    </div>
  );
}

function SelectField({
  label,
  value,
  onChange,
  options,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  options: string[];
}) {
  return (
    <div>
      <label className="block text-xs font-medium text-muted">{label}</label>
      <select
        className="h-11 w-full rounded-lg border border-border bg-surface-2 px-3 text-sm"
        value={value}
        onChange={(e) => onChange(e.target.value)}
      >
        {options.map((o) => (
          <option key={o || "(none)"} value={o}>
            {o === "" ? "-" : o}
          </option>
        ))}
      </select>
    </div>
  );
}

// Dense Td / Th wrappers used inside the Transaction Log. Override the shared
// Table component's defaults so every column fits on a typical 1440-wide
// screen without horizontal scrolling.
const DTH_PAD = "px-1.5 py-1 text-[0.65rem] font-semibold uppercase tracking-tight";
const DTD_PAD = "px-1.5 py-1 text-[0.7rem]";

function ThD({
  className,
  ...props
}: React.ThHTMLAttributes<HTMLTableCellElement>) {
  return <Th className={cn(DTH_PAD, className)} {...props} />;
}
function TdD({
  className,
  ...props
}: React.TdHTMLAttributes<HTMLTableCellElement>) {
  return <Td className={cn(DTD_PAD, className)} {...props} />;
}

function TransactionTable({
  rows,
  onSaveComment,
  savingTradeId,
  savedFlash,
}: {
  rows: Record<string, unknown>[];
  onSaveComment: (tradeId: string, comment: string) => void | Promise<void>;
  savingTradeId: string | null;
  savedFlash: string | null;
}) {
  return (
    <div className="overflow-x-auto">
      <Table className="text-[0.7rem]">
        <Thead>
          <Tr>
            <ThD>#</ThD>
            <ThD>RTI ID</ThD>
            <ThD>Date</ThD>
            <ThD>Action</ThD>
            <ThD>Dir</ThD>
            <ThD>Type</ThD>
            <ThD>Instrument</ThD>
            <ThD>Description</ThD>
            <ThD className="text-right">Amount</ThD>
            <ThD className="text-right">Price</ThD>
            <ThD className="text-right">Spot</ThD>
            <ThD className="text-right">Prem USD</ThD>
            <ThD className="text-right">Fee BTC</ThD>
            <ThD className="text-right">Fee USD</ThD>
            <ThD className="text-right">Cashflow</ThD>
            <ThD className="text-right">Bal Δ</ThD>
            <ThD className="text-right">Pos</ThD>
            <ThD>Matched</ThD>
            <ThD className="w-[170px]">Comment</ThD>
          </Tr>
        </Thead>
        <Tbody>
          {rows.map((r, i) => {
            const a = String(r.action ?? "");
            const dir = String(r.direction ?? "");
            const tradeId = String(r.trade_id ?? r.id ?? "");
            return (
              <Tr key={tradeId || String(r.rti_id ?? i)}>
                <TdD className="text-muted">{i + 1}</TdD>
                <TdD className="font-mono">{String(r.rti_id ?? "")}</TdD>
                <TdD className="font-mono">{String(r.trade_date ?? "")}</TdD>
                <TdD className="whitespace-nowrap">{ACTION_ICON[a] ?? a}</TdD>
                <TdD>
                  {dir ? (
                    <span
                      className={cn(
                        "inline-flex rounded px-1 py-0.5 text-[0.65rem] font-medium",
                        dir === "long" || dir === "buy"
                          ? "bg-positive/15 text-positive"
                          : "bg-negative/15 text-negative",
                      )}
                    >
                      {dir}
                    </span>
                  ) : (
                    ""
                  )}
                </TdD>
                <TdD>{String(r.instrument_type ?? "")}</TdD>
                <TdD
                  className="max-w-[150px] truncate font-mono"
                  title={String(r.instrument_name ?? "")}
                >
                  {String(r.instrument_name ?? "")}
                </TdD>
                <TdD
                  className="max-w-[140px] truncate"
                  title={String(r.description ?? "")}
                >
                  {String(r.description ?? "")}
                </TdD>
                <TdD className="text-right tabular-nums">
                  {fmtNum(r.display_contracts, 4)}
                </TdD>
                <TdD className="text-right tabular-nums">{fmtNum(r.price, 6)}</TdD>
                <TdD className="text-right tabular-nums">
                  {r.spot_price != null
                    ? `$${Number(r.spot_price).toLocaleString(undefined, {
                        maximumFractionDigits: 0,
                      })}`
                    : ""}
                </TdD>
                <TdD className="text-right tabular-nums">
                  {r.premium_usd != null
                    ? `$${Number(r.premium_usd).toLocaleString(undefined, {
                        minimumFractionDigits: 2,
                        maximumFractionDigits: 2,
                      })}`
                    : ""}
                </TdD>
                <TdD className="text-right tabular-nums">
                  {fmtNum(r.fee_btc, 8)}
                </TdD>
                <TdD className="text-right tabular-nums">
                  {r.fee_usd != null
                    ? `$${Number(r.fee_usd).toLocaleString(undefined, {
                        minimumFractionDigits: 4,
                        maximumFractionDigits: 4,
                      })}`
                    : ""}
                </TdD>
                <TdD className="text-right tabular-nums">
                  {fmtNum(r.realized_pnl, 8)}
                </TdD>
                <TdD className="text-right tabular-nums">
                  {fmtNum(r.balance_change, 8)}
                </TdD>
                <TdD className="text-right tabular-nums">
                  {fmtNum(r.position_after, 1)}
                </TdD>
                <TdD className="max-w-[110px] truncate font-mono text-[0.65rem]"
                     title={String(r.matched_with ?? "")}>
                  {String(r.matched_with ?? "")}
                </TdD>
                <TdD className="w-[170px]">
                  <CommentCell
                    tradeId={tradeId}
                    initialValue={String(r.comments ?? "")}
                    saving={savingTradeId === tradeId}
                    saved={savedFlash === tradeId}
                    onSave={onSaveComment}
                  />
                </TdD>
              </Tr>
            );
          })}
        </Tbody>
      </Table>
    </div>
  );
}

/** Inline per-row comment editor.
 *
 * - Pre-populated with the row's current `comments` value.
 * - Resyncs when the underlying value changes (after a successful refetch).
 * - Save button is enabled only while the draft differs from the saved value.
 * - Ctrl/Cmd+Enter commits without lifting hands off the keyboard.
 */
function CommentCell({
  tradeId,
  initialValue,
  saving,
  saved,
  onSave,
}: {
  tradeId: string;
  initialValue: string;
  saving: boolean;
  saved: boolean;
  onSave: (tradeId: string, comment: string) => void | Promise<void>;
}) {
  const [draft, setDraft] = useState<string>(initialValue);
  // Resync the local draft when the server value changes (e.g. after a save
  // by this row or another user) UNLESS the user has unsaved local edits we
  // shouldn't clobber.
  useEffect(() => {
    setDraft(initialValue);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [initialValue]);

  const dirty = draft !== initialValue;
  const canSave = Boolean(tradeId) && dirty && !saving;

  // Tight inline editor: single-line input + tiny icon-only Save button.
  // Save only appears when the row is dirty so an unsaved column doesn't
  // dominate the row.
  return (
    <div className="flex w-full items-center gap-1">
      <input
        type="text"
        className="h-7 w-full rounded-md border border-border bg-surface-2 px-1.5 text-[0.7rem] focus:outline-none focus:ring-1 focus:ring-brand"
        placeholder="Add note…"
        value={draft}
        onChange={(e) => setDraft(e.target.value)}
        onKeyDown={(e) => {
          if (e.key === "Enter" && canSave) {
            e.preventDefault();
            onSave(tradeId, draft);
          } else if (e.key === "Escape" && dirty) {
            e.preventDefault();
            setDraft(initialValue);
          }
        }}
        disabled={!tradeId}
        title={!tradeId ? "no trade_id - cannot persist" : draft}
      />
      {canSave ? (
        <button
          type="button"
          onClick={() => onSave(tradeId, draft)}
          className="inline-flex h-7 w-7 shrink-0 items-center justify-center rounded-md bg-brand text-brand-fg hover:opacity-90"
          aria-label="Save comment"
          title="Save (Enter)"
        >
          <Save className="h-3 w-3" />
        </button>
      ) : null}
      {saving ? (
        <span className="text-[0.65rem] text-muted">…</span>
      ) : saved ? (
        <span className="text-[0.7rem] text-positive">✓</span>
      ) : null}
    </div>
  );
}
