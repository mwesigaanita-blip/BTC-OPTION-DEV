import { Link } from "react-router-dom";
import { Compass } from "lucide-react";
import { Button } from "@/components/ui/Button";

export function NotFoundPage() {
  return (
    <div className="flex flex-col items-center justify-center gap-3 py-24 text-center">
      <div className="rounded-full bg-surface-2 p-4 text-muted">
        <Compass className="h-8 w-8" />
      </div>
      <h2 className="text-lg font-semibold text-fg">Page not found</h2>
      <p className="text-sm text-muted">
        The page you are looking for does not exist.
      </p>
      <Link to="/account-overview">
        <Button variant="secondary" size="sm">
          Back to dashboard
        </Button>
      </Link>
    </div>
  );
}
