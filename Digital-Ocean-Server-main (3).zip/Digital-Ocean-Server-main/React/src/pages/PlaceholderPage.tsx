import { useLocation } from "react-router-dom";
import { Construction } from "lucide-react";
import { PageHeader } from "@/components/shared/PageHeader";
import { PAGE_BY_ROUTE } from "@/lib/pageMap";

/** Stub for pages not yet migrated from Streamlit. */
export function PlaceholderPage() {
  const { pathname } = useLocation();
  const page = PAGE_BY_ROUTE[pathname];

  return (
    <div className="space-y-6">
      <PageHeader
        title={page?.label ?? "Page"}
        description="This page has not been migrated to React yet."
      />
      <div className="card flex flex-col items-center gap-3 py-20 text-center">
        <div className="rounded-full bg-warning/15 p-4 text-warning">
          <Construction className="h-8 w-8" />
        </div>
        <p className="text-sm text-muted">
          Coming soon - still available in the Streamlit dashboard.
        </p>
      </div>
    </div>
  );
}
