import { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Download } from "lucide-react";
import {
  Bar,
  BarChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import {
  downloadBtcPricesCsv,
  fetchBtcPricesSeries,
  fetchBtcPricesSummary,
} from "@/api/btcPrices";
import { useTheme } from "@/theme/ThemeProvider";
import { PageHeader } from "@/components/shared/PageHeader";
import { LoadingState } from "@/components/shared/LoadingState";
import { ErrorState } from "@/components/shared/ErrorState";
import { MetricCard } from "@/components/shared/MetricCard";
import { Card, CardBody, CardHeader } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { Input } from "@/components/ui/Input";
import {
  Table,
  Tbody,
  Td,
  Th,
  Thead,
  Tr,
} from "@/components/ui/Table";
import { fmtNum, fmtSignedPct, fmtUsd } from "@/lib/format";
import { cn } from "@/lib/utils";
import type { BtcPriceRow } from "@/types/api";
import { DailyQuantPanel } from "./btc-prices/quant/DailyQuantPanel";
import { CorrelationPanel } from "./btc-prices/quant/CorrelationPanel";
import { EtfFlowsPanel } from "./btc-prices/etf/EtfFlowsPanel";

type Preset = "30d" | "90d" | "1y" | "5y" | "all" | "custom";

const PRESETS: Array<{ id: Preset; label: string; days: number | null }> = [
  { id: "30d", label: "30D", days: 30 },
  { id: "90d", label: "90D", days: 90 },
  { id: "1y", label: "1Y", days: 365 },
  { id: "5y", label: "5Y", days: 365 * 5 },
  { id: "all", label: "All", days: null },
];

function addDaysIso(iso: string, days: number): string {
  const d = new Date(iso + "T00:00:00Z");
  d.setUTCDate(d.getUTCDate() + days);
  return d.toISOString().slice(0, 10);
}

export function BtcPricesPage() {
  const summaryQ = useQuery({
    queryKey: ["btc-prices-summary"],
    queryFn: fetchBtcPricesSummary,
    refetchInterval: 60_000,
    retry: false,
  });

  const lastDate = summaryQ.data?.last_date ?? null;

  const [preset, setPreset] = useState<Preset>("1y");
  const [fromStr, setFromStr] = useState("");
  const [toStr, setToStr] = useState("");

  // Resolve range from preset (or use the custom inputs)
  const range = useMemo(() => {
    if (preset === "custom") {
      return { from: fromStr || undefined, to: toStr || undefined };
    }
    if (!lastDate) return {};
    const days = PRESETS.find((p) => p.id === preset)?.days ?? null;
    if (days == null) return {}; // "All"
    return { from: addDaysIso(lastDate, -days), to: lastDate };
  }, [preset, fromStr, toStr, lastDate]);

  const seriesQ = useQuery({
    queryKey: ["btc-prices-series", range.from, range.to],
    queryFn: () => fetchBtcPricesSeries(range.from, range.to),
    enabled: Boolean(lastDate),
    retry: false,
  });

  const rows = seriesQ.data?.rows ?? [];
  const reversed = useMemo(() => [...rows].reverse(), [rows]);
  const [tableCap, setTableCap] = useState<number>(10);
  const tableRows = reversed.slice(0, tableCap);

  const onCustomFrom = (v: string) => {
    setFromStr(v);
    setPreset("custom");
  };
  const onCustomTo = (v: string) => {
    setToStr(v);
    setPreset("custom");
  };

  if (summaryQ.isLoading && !summaryQ.data)
    return <LoadingState label="Loading BTC prices…" />;
  if (summaryQ.isError)
    return (
      <ErrorState
        message="Could not load BTC prices."
        onRetry={() => summaryQ.refetch()}
      />
    );

  const latest = summaryQ.data?.latest;
  const pctTone =
    latest?.percent_change != null
      ? Number(latest.percent_change) >= 0
        ? "positive"
        : "negative"
      : "neutral";

  return (
    <div className="space-y-5">
      <PageHeader
        title="BTC Prices"
        description="Daily OHLCV history from the system database."
      />

      {/* Daily Quant — Hedgeye-style snapshot */}
      <DailyQuantPanel />

      {/* BTC ETF Flows */}
      <EtfFlowsPanel />

      {/* Macro-crypto correlation matrix */}
      <CorrelationPanel />

      {/* Controls */}
      <Card>
        <CardBody className="flex flex-wrap items-end gap-3">
          <div className="flex flex-wrap gap-1.5">
            {PRESETS.map((p) => (
              <button
                key={p.id}
                type="button"
                onClick={() => setPreset(p.id)}
                className={cn(
                  "rounded-md border px-3 py-1.5 text-xs font-medium",
                  preset === p.id
                    ? "border-brand bg-brand/15 text-brand"
                    : "border-border bg-surface-2 text-muted hover:text-fg",
                )}
              >
                {p.label}
              </button>
            ))}
          </div>
          <Field label="From">
            <Input
              type="date"
              value={range.from ?? ""}
              onChange={(e) => onCustomFrom(e.target.value)}
              className="w-40"
            />
          </Field>
          <Field label="To">
            <Input
              type="date"
              value={range.to ?? ""}
              onChange={(e) => onCustomTo(e.target.value)}
              className="w-40"
            />
          </Field>
          <div className="ml-auto">
            <Button
              variant="secondary"
              size="sm"
              onClick={() => downloadBtcPricesCsv()}
            >
              <Download className="h-3.5 w-3.5" /> Download full CSV
            </Button>
          </div>
        </CardBody>
      </Card>

      {/* KPI strip */}
      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        <MetricCard label="Last Date" value={lastDate ?? "-"} />
        <MetricCard
          label="Total Rows"
          value={fmtNum(summaryQ.data?.total_rows ?? 0, 0)}
        />
        <MetricCard
          label="Latest Close"
          value={latest ? fmtUsd(latest.close, 2) : "-"}
        />
        <MetricCard
          label="Daily Change"
          value={
            latest?.percent_change != null
              ? fmtSignedPct(latest.percent_change)
              : "-"
          }
          tone={pctTone}
        />
      </div>

      {/* Candlestick chart */}
      <Card>
        <CardHeader
          title="Price History"
          subtitle={`${rows.length} day${rows.length === 1 ? "" : "s"} in range`}
        />
        <CardBody>
          {seriesQ.isLoading ? (
            <LoadingState label="Loading prices…" />
          ) : rows.length ? (
            <CandlestickChart rows={rows} />
          ) : (
            <p className="py-12 text-center text-sm text-muted">No data.</p>
          )}
        </CardBody>
      </Card>

      {/* Latest rows table */}
      <Card>
        <CardHeader
          title="Latest Rows"
          subtitle={
            rows.length > tableCap
              ? `Showing latest ${tableCap} of ${rows.length} rows in range`
              : `${rows.length} row${rows.length === 1 ? "" : "s"}`
          }
          action={
            <div className="flex items-center gap-2">
              <label
                htmlFor="row-cap"
                className="text-[11px] font-medium uppercase tracking-wide text-muted"
              >
                Rows
              </label>
              <select
                id="row-cap"
                value={tableCap}
                onChange={(e) => setTableCap(Number(e.target.value))}
                className="h-8 rounded-md border border-border bg-surface-2 px-2 text-xs text-fg focus:outline-none focus:ring-2 focus:ring-brand"
              >
                {[10, 25, 50, 100, 200].map((n) => (
                  <option key={n} value={n}>
                    {n}
                  </option>
                ))}
              </select>
            </div>
          }
        />
        <CardBody className="px-0">
          {tableRows.length ? (
            <PricesTable rows={tableRows} />
          ) : (
            <p className="px-5 py-8 text-center text-sm text-muted">No rows.</p>
          )}
        </CardBody>
      </Card>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Sub-components
// ---------------------------------------------------------------------------

function Field({
  label,
  children,
}: {
  label: string;
  children: React.ReactNode;
}) {
  return (
    <div className="space-y-1">
      <label className="block text-[11px] font-medium uppercase tracking-wide text-muted">
        {label}
      </label>
      {children}
    </div>
  );
}

interface CandleData extends BtcPriceRow {
  candleRange: [number, number];
}

function CandlestickChart({ rows }: { rows: BtcPriceRow[] }) {
  const { theme } = useTheme();
  const dark = theme === "dark";
  const axis = dark ? "#8b949e" : "#6b7280";
  const grid = dark ? "rgba(139,148,161,0.15)" : "rgba(107,114,128,0.18)";
  const up = dark ? "#3fb950" : "#16a34a";
  const down = dark ? "#f85149" : "#dc2626";

  const data: CandleData[] = useMemo(
    () =>
      rows.map((r) => ({
        ...r,
        candleRange: [Number(r.low), Number(r.high)],
      })),
    [rows],
  );

  return (
    <ResponsiveContainer width="100%" height={380}>
      <BarChart data={data} margin={{ top: 8, right: 12, bottom: 4, left: 4 }}>
        <CartesianGrid stroke={grid} vertical={false} />
        <XAxis
          dataKey="date"
          tick={{ fill: axis, fontSize: 11 }}
          stroke={grid}
          minTickGap={32}
        />
        <YAxis
          domain={["dataMin", "dataMax"]}
          tickFormatter={(v) => `$${Math.round(Number(v) / 1000)}k`}
          tick={{ fill: axis, fontSize: 11 }}
          stroke={grid}
          width={56}
        />
        <Tooltip
          cursor={{ fill: dark ? "rgba(255,255,255,0.04)" : "rgba(0,0,0,0.04)" }}
          content={({ active, payload }) => {
            if (!active || !payload?.length) return null;
            const p = payload[0].payload as BtcPriceRow;
            const positive = Number(p.percent_change ?? 0) >= 0;
            return (
              <div
                style={{
                  background: dark ? "#161b22" : "#ffffff",
                  border: `1px solid ${grid}`,
                  borderRadius: 8,
                  fontSize: 12,
                  padding: "8px 10px",
                  minWidth: 220,
                }}
              >
                <div style={{ color: axis, marginBottom: 4 }}>{p.date}</div>
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 4, color: dark ? "#e6e9ef" : "#111827" }}>
                  <span>O {fmtUsd(p.open, 0)}</span>
                  <span>H {fmtUsd(p.high, 0)}</span>
                  <span>L {fmtUsd(p.low, 0)}</span>
                  <span>C {fmtUsd(p.close, 0)}</span>
                </div>
                {p.percent_change != null ? (
                  <div
                    style={{
                      marginTop: 4,
                      color: positive ? up : down,
                      fontWeight: 600,
                    }}
                  >
                    {fmtSignedPct(Number(p.percent_change))}
                    {p.change != null
                      ? ` (${fmtUsd(Number(p.change), 0)})`
                      : ""}
                  </div>
                ) : null}
                {p.volume != null ? (
                  <div style={{ color: axis, marginTop: 2 }}>
                    Vol {fmtNum(p.volume, 2)}
                  </div>
                ) : null}
              </div>
            );
          }}
        />
        <Bar
          dataKey="candleRange"
          shape={(props: unknown) => (
            <CandleShape {...(props as CandleShapeProps)} upColour={up} downColour={down} />
          )}
          isAnimationActive={false}
        />
      </BarChart>
    </ResponsiveContainer>
  );
}

interface CandleShapeProps {
  x: number;
  y: number;
  width: number;
  height: number;
  payload: BtcPriceRow;
  upColour?: string;
  downColour?: string;
}

function CandleShape({
  x,
  y,
  width,
  height,
  payload,
  upColour = "#22c55e",
  downColour = "#ef4444",
}: CandleShapeProps) {
  const open = Number(payload.open);
  const close = Number(payload.close);
  const high = Number(payload.high);
  const low = Number(payload.low);
  if (![open, close, high, low].every((n) => Number.isFinite(n))) return null;
  const isUp = close >= open;
  const colour = isUp ? upColour : downColour;
  const range = Math.max(1e-9, high - low);
  const yOpen = y + ((high - open) / range) * height;
  const yClose = y + ((high - close) / range) * height;
  const bodyTop = Math.min(yOpen, yClose);
  const bodyBottom = Math.max(yOpen, yClose);
  const wickX = x + width / 2;
  const bodyW = Math.max(1, width * 0.7);
  const bodyX = x + (width - bodyW) / 2;
  return (
    <g>
      <line
        x1={wickX}
        x2={wickX}
        y1={y}
        y2={y + height}
        stroke={colour}
        strokeWidth={1}
      />
      <rect
        x={bodyX}
        y={bodyTop}
        width={bodyW}
        height={Math.max(1, bodyBottom - bodyTop)}
        fill={colour}
      />
    </g>
  );
}

const COLS: Array<{ key: keyof BtcPriceRow; label: string; fmt: (v: unknown) => string }> = [
  { key: "date", label: "Date", fmt: (v) => String(v) },
  { key: "open", label: "Open", fmt: (v) => fmtUsd(v, 2) },
  { key: "high", label: "High", fmt: (v) => fmtUsd(v, 2) },
  { key: "low", label: "Low", fmt: (v) => fmtUsd(v, 2) },
  { key: "close", label: "Close", fmt: (v) => fmtUsd(v, 2) },
  { key: "change", label: "Change", fmt: (v) => (v == null ? "-" : fmtUsd(v, 2)) },
  {
    key: "percent_change",
    label: "% Change",
    fmt: (v) => (v == null ? "-" : fmtSignedPct(Number(v))),
  },
  { key: "volume", label: "Volume", fmt: (v) => (v == null ? "-" : fmtNum(v, 2)) },
];

function PricesTable({ rows }: { rows: BtcPriceRow[] }) {
  return (
    <Table>
      <Thead>
        <Tr>
          {COLS.map((c) => (
            <Th
              key={String(c.key)}
              className={c.key === "date" ? "" : "text-right"}
            >
              {c.label}
            </Th>
          ))}
        </Tr>
      </Thead>
      <Tbody>
        {rows.map((r) => {
          const pct = Number(r.percent_change ?? 0);
          return (
            <Tr key={r.date}>
              {COLS.map((c) => {
                const right = c.key !== "date";
                const tone =
                  c.key === "percent_change" && r.percent_change != null
                    ? pct >= 0
                      ? "text-positive"
                      : "text-negative"
                    : "";
                return (
                  <Td
                    key={String(c.key)}
                    className={cn(
                      right ? "text-right tabular-nums" : "font-mono text-xs",
                      tone,
                    )}
                  >
                    {c.fmt(r[c.key])}
                  </Td>
                );
              })}
            </Tr>
          );
        })}
      </Tbody>
    </Table>
  );
}
