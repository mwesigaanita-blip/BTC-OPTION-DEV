import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { AlertTriangle, RefreshCw } from "lucide-react";
import { fetchWsHealth } from "@/api/wsHealth";
import { PageHeader } from "@/components/shared/PageHeader";
import { MetricCard } from "@/components/shared/MetricCard";
import { LoadingState } from "@/components/shared/LoadingState";
import { ErrorState } from "@/components/shared/ErrorState";
import { Card, CardBody, CardHeader } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { Badge } from "@/components/ui/Badge";
import {
  Table,
  Tbody,
  Td,
  Th,
  Thead,
  Tr,
} from "@/components/ui/Table";

function fmt(v: number | null | undefined, digits = 1): string {
  if (v == null || !Number.isFinite(Number(v))) return "-";
  return Number(v).toFixed(digits);
}

export function WsLayerHealthPage() {
  const [showCollectorRaw, setShowCollectorRaw] = useState(false);
  const [showBackendRaw, setShowBackendRaw] = useState(false);

  const q = useQuery({
    queryKey: ["ws-health"],
    queryFn: fetchWsHealth,
    refetchInterval: 5_000,
    retry: false,
  });

  if (q.isLoading) return <LoadingState label="Loading WS layer health…" />;
  if (q.error || !q.data) {
    return (
      <ErrorState
        message={(q.error as Error)?.message ?? "Failed to load WS health"}
        onRetry={() => q.refetch()}
      />
    );
  }

  const { staleness_threshold_s: threshold, collector, backend_ws } = q.data;
  const col = collector;
  const ch = col.health ?? {};
  const bws = backend_ws;
  const bh = bws.health ?? {};

  return (
    <div className="space-y-5 animate-fade-in">
      <PageHeader
        title="📡 WS Layer Health"
        description={`Collector: ${col.url} · Backend WS: ${bws.url}. Auto-refreshes every 5s.`}
        actions={
          <Button variant="secondary" size="sm" onClick={() => q.refetch()}>
            <RefreshCw className="h-3.5 w-3.5" />
            Refresh
          </Button>
        }
      />

      <section className="space-y-3">
        <h2 className="text-sm font-semibold text-fg">
          Collector - <code className="text-xs text-muted">btc_ws_collector</code>
        </h2>

        {col.health_error ? (
          <div className="flex items-center gap-2 rounded-lg border border-negative/40 bg-negative/10 px-3 py-2 text-sm text-negative">
            <AlertTriangle className="h-4 w-4" /> Collector is unreachable.
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
            <MetricCard
              label="Last msg age (s)"
              value={fmt(ch.last_msg_age_s as number, 1)}
            />
            <MetricCard
              label="Reconnects"
              value={String((ch.reconnects as number) ?? 0)}
            />
            <MetricCard
              label="Redis OK"
              value={ch.redis_ok ? "yes" : "no"}
              tone={ch.redis_ok ? "positive" : "negative"}
            />
            <MetricCard
              label="Uptime (s)"
              value={String((ch.uptime_s as number) ?? 0)}
            />
          </div>
        )}

        {!col.health_error ? (
          <div>
            <div className="mb-2 text-xs font-semibold text-fg">
              Downtime (Deribit WS disconnect → reconnect)
            </div>
            <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
              <MetricCard
                label="Current"
                value={fmt(ch.current_downtime_s as number, 1)}
                tone={Number(ch.current_downtime_s ?? 0) > 0 ? "negative" : "neutral"}
                sub={
                  Number(ch.current_downtime_s ?? 0) > 0
                    ? "WS currently disconnected"
                    : undefined
                }
              />
              <MetricCard
                label="Last"
                value={fmt(ch.last_downtime_s as number, 1)}
              />
              <MetricCard
                label="Longest"
                value={fmt(ch.longest_downtime_s as number, 1)}
              />
              <MetricCard
                label="Total"
                value={fmt(ch.total_downtime_s as number, 1)}
              />
            </div>
          </div>
        ) : null}

        {col.summary ? (
          <>
            <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
              <MetricCard
                label="Active subscriptions"
                value={String(col.summary.active_subscriptions)}
              />
              <MetricCard
                label="Connection state"
                value={col.summary.connection_state}
                tone={col.summary.connection_state === "up" ? "positive" : "negative"}
              />
              <MetricCard
                label="SQLite flushes"
                value={col.summary.sqlite_writes_total.toLocaleString()}
              />
              <MetricCard
                label="Aggregator rows"
                value={col.summary.aggregator_writes_total.toLocaleString()}
              />
            </div>

            <div>
              <div className="mb-2 text-xs font-semibold text-fg">
                Watchdog & crash-loop
              </div>
              <div className="grid grid-cols-1 gap-3 md:grid-cols-3">
                <MetricCard
                  label="Crash-loop active"
                  value={col.summary.crash_loop_active ? "YES" : "no"}
                  tone={col.summary.crash_loop_active ? "negative" : "neutral"}
                  sub={
                    col.summary.crash_loop_active
                      ? "Reconnect storm - investigate logs"
                      : undefined
                  }
                />
                <MetricCard
                  label="Reconnects in last 10 min"
                  value={String(col.summary.reconnects_window_count)}
                />
                <MetricCard
                  label="Watchdog-forced reconnects"
                  value={String(col.summary.watchdog_force_reconnects_total)}
                />
              </div>
            </div>
          </>
        ) : (
          <div className="text-xs text-muted">No Prometheus metrics parsed from collector.</div>
        )}

        <Card>
          <CardHeader
            title="Per-channel staleness"
            subtitle={`red = age > ${threshold.toFixed(0)}s (WS_STALENESS_THRESHOLD_S)`}
          />
          <CardBody className="pt-0">
            {col.channels_age.length === 0 ? (
              <div className="text-xs text-muted">
                No per-channel age gauges yet (watchdog has not ticked).
              </div>
            ) : (
              <>
                <Table>
                  <Thead>
                    <Tr>
                      <Th>Channel</Th>
                      <Th className="text-right">Age (s)</Th>
                      <Th>Stale</Th>
                    </Tr>
                  </Thead>
                  <Tbody>
                    {col.channels_age.map((r) => (
                      <Tr key={r.channel}>
                        <Td className="font-mono text-xs">{r.channel}</Td>
                        <Td className="text-right tabular-nums">{r.age_s}</Td>
                        <Td>
                          {r.stale ? (
                            <Badge tone="warning">⚠️ stale</Badge>
                          ) : (
                            <Badge tone="positive">ok</Badge>
                          )}
                        </Td>
                      </Tr>
                    ))}
                  </Tbody>
                </Table>
                {col.channels_age.some((r) => r.stale) ? (
                  <div className="mt-2 text-xs text-warning">
                    At least one channel is past the staleness threshold.
                  </div>
                ) : null}
              </>
            )}
          </CardBody>
        </Card>

        <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
          <Card>
            <CardHeader title="Messages received per channel" />
            <CardBody className="pt-0">
              {col.messages.length === 0 ? (
                <div className="text-xs text-muted">No messages received yet.</div>
              ) : (
                <Table>
                  <Thead>
                    <Tr>
                      <Th>Channel</Th>
                      <Th className="text-right">Count</Th>
                    </Tr>
                  </Thead>
                  <Tbody>
                    {col.messages.map((r) => (
                      <Tr key={r.channel}>
                        <Td className="font-mono text-xs">{r.channel}</Td>
                        <Td className="text-right tabular-nums">
                          {r.count.toLocaleString()}
                        </Td>
                      </Tr>
                    ))}
                  </Tbody>
                </Table>
              )}
            </CardBody>
          </Card>

          <Card>
            <CardHeader title="Redis subscriber count (last PUBLISH)" />
            <CardBody className="pt-0">
              {col.subscribers.length === 0 ? (
                <div className="text-xs text-muted">No publishes yet.</div>
              ) : (
                <Table>
                  <Thead>
                    <Tr>
                      <Th>Topic</Th>
                      <Th className="text-right">Subscribers</Th>
                    </Tr>
                  </Thead>
                  <Tbody>
                    {col.subscribers.map((r) => (
                      <Tr key={r.topic}>
                        <Td className="font-mono text-xs">{r.topic}</Td>
                        <Td className="text-right tabular-nums">{r.subscribers}</Td>
                      </Tr>
                    ))}
                  </Tbody>
                </Table>
              )}
            </CardBody>
          </Card>
        </div>
      </section>

      <section className="space-y-3 border-t border-border pt-5">
        <h2 className="text-sm font-semibold text-fg">
          Backend WS - <code className="text-xs text-muted">btc_backend_ws</code>
        </h2>

        {bws.health_error ? (
          <div className="flex items-center gap-2 rounded-lg border border-negative/40 bg-negative/10 px-3 py-2 text-sm text-negative">
            <AlertTriangle className="h-4 w-4" /> backend_ws is unreachable.
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-3 md:grid-cols-3">
            <MetricCard label="Redis" value={String(bh.redis ?? "?")} />
            <MetricCard
              label="Total WS clients"
              value={String((bh.ws_clients as number) ?? 0)}
            />
            <MetricCard label="Topics fanned out" value={String(bws.fanout.length)} />
          </div>
        )}

        {bws.fanout.length > 0 ? (
          <Card>
            <CardHeader title="Subscribers per fanout topic" />
            <CardBody className="pt-0">
              <Table>
                <Thead>
                  <Tr>
                    <Th>Topic</Th>
                    <Th className="text-right">Clients</Th>
                  </Tr>
                </Thead>
                <Tbody>
                  {bws.fanout.map((r) => (
                    <Tr key={r.topic}>
                      <Td className="font-mono text-xs">{r.topic}</Td>
                      <Td className="text-right tabular-nums">{r.clients}</Td>
                    </Tr>
                  ))}
                </Tbody>
              </Table>
            </CardBody>
          </Card>
        ) : null}

        {bws.redis_sub.length > 0 ? (
          <Card>
            <CardHeader
              title="Redis pubsub downtime per topic"
              subtitle="disconnect → resubscribe"
            />
            <CardBody className="pt-0">
              <Table>
                <Thead>
                  <Tr>
                    <Th>Topic</Th>
                    <Th className="text-right">Current (s)</Th>
                    <Th className="text-right">Last (s)</Th>
                    <Th className="text-right">Longest (s)</Th>
                    <Th className="text-right">Total (s)</Th>
                  </Tr>
                </Thead>
                <Tbody>
                  {bws.redis_sub.map((r) => (
                    <Tr key={r.topic}>
                      <Td className="font-mono text-xs">{r.topic}</Td>
                      <Td
                        className={
                          r.current_s > 0
                            ? "text-right tabular-nums text-negative"
                            : "text-right tabular-nums"
                        }
                      >
                        {r.current_s}
                      </Td>
                      <Td className="text-right tabular-nums">{r.last_s}</Td>
                      <Td className="text-right tabular-nums">{r.longest_s}</Td>
                      <Td className="text-right tabular-nums">{r.total_s}</Td>
                    </Tr>
                  ))}
                </Tbody>
              </Table>
              {bws.redis_sub.some((r) => r.current_s > 0) ? (
                <div className="mt-2 text-xs text-negative">
                  One or more Redis pubsub subscriptions are currently down.
                </div>
              ) : null}
            </CardBody>
          </Card>
        ) : null}

        {bws.summary ? (
          <div className="grid grid-cols-1 gap-3 md:grid-cols-3">
            <MetricCard
              label="Messages forwarded"
              value={bws.summary.fanout_messages_total.toLocaleString()}
            />
            <MetricCard
              label="Dropped (slow client)"
              value={bws.summary.fanout_drops_total.toLocaleString()}
              tone={bws.summary.fanout_drops_total > 0 ? "warning" : "neutral"}
            />
            <MetricCard
              label="Redis ping failures"
              value={bws.summary.redis_ping_failures_total.toLocaleString()}
              tone={bws.summary.redis_ping_failures_total > 0 ? "negative" : "neutral"}
            />
          </div>
        ) : null}
      </section>

      <section className="space-y-3 border-t border-border pt-5">
        <div>
          <Button
            variant="secondary"
            size="sm"
            onClick={() => setShowCollectorRaw((v) => !v)}
          >
            {showCollectorRaw ? "Hide" : "Show"} raw /metrics - collector
          </Button>
          {showCollectorRaw ? (
            <pre className="mt-2 max-h-96 overflow-auto rounded-lg border border-border bg-surface-2/40 p-3 text-[0.7rem] text-muted">
              {col.metrics_text || "(empty)"}
            </pre>
          ) : null}
        </div>
        <div>
          <Button
            variant="secondary"
            size="sm"
            onClick={() => setShowBackendRaw((v) => !v)}
          >
            {showBackendRaw ? "Hide" : "Show"} raw /metrics - backend_ws
          </Button>
          {showBackendRaw ? (
            <pre className="mt-2 max-h-96 overflow-auto rounded-lg border border-border bg-surface-2/40 p-3 text-[0.7rem] text-muted">
              {bws.metrics_text || "(empty)"}
            </pre>
          ) : null}
        </div>
      </section>
    </div>
  );
}
