import { cn } from "@/lib/utils";

/** Brand color per asset for the leading dot. */
const COLOR: Record<string, string> = {
  BTC:  "bg-[#f7931a]",
  ETH:  "bg-[#627eea]",
  SOL:  "bg-[#14f195]",
  AVAX: "bg-[#e84142]",
  ZEC:  "bg-[#f4b728]",
  MSTR: "bg-sky-500",
  MARA: "bg-amber-500",
  RIOT: "bg-rose-500",
  COIN: "bg-blue-500",
  SPX:  "bg-indigo-500",
  GOLD: "bg-amber-400",
  DXY:  "bg-emerald-500",
};

export function AssetChip({
  label,
  emphasis = false,
  className,
}: {
  label: string;
  /** Bold + slightly bigger — use for the BTC row to stand out. */
  emphasis?: boolean;
  className?: string;
}) {
  const key = label.replace(/^vs\s+/i, "").toUpperCase();
  const dot = COLOR[key] ?? "bg-muted";
  return (
    <span className={cn("inline-flex items-center gap-1.5", className)}>
      <span className={cn("h-1.5 w-1.5 rounded-full", dot)} />
      <span
        className={cn(
          "font-mono tabular-nums",
          emphasis ? "text-sm font-bold text-fg" : "text-xs font-semibold text-fg",
        )}
      >
        {label}
      </span>
    </span>
  );
}
