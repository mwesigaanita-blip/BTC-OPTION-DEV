import { Card, CardHeader } from "@/components/ui/Card";
import { LoadingState } from "@/components/shared/LoadingState";
import { ErrorState } from "@/components/shared/ErrorState";
import { useQuantCorrelations } from "@/hooks/useQuant";
import { BtcRollingCorrelationsChart } from "./BtcRollingCorrelationsChart";
import { CorrelationMatrix } from "./CorrelationMatrix";

export function CorrelationPanel() {
  const q = useQuantCorrelations();

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex flex-wrap items-end justify-between gap-3 border-b border-border pb-3">
        <div>
          <h2 className="flex items-baseline gap-2 text-xl font-bold tracking-tight text-fg">
            Return Correlations
            <span className="text-[10px] font-medium uppercase tracking-widest text-muted">
              1-Day % chg · Macro-crypto matrix
            </span>
          </h2>
          {q.data?.windows?.[0]?.asof ? (
            <p className="mt-0.5 text-xs text-muted">
              As of <span className="font-mono text-fg">{q.data.windows[0].asof}</span>
              <span className="mx-2 text-border">•</span>
              Diagonal cells are self-correlation (= 1.0)
            </p>
          ) : null}
        </div>
      </div>

      {q.isLoading && !q.data ? (
        <LoadingState label="Loading correlations…" />
      ) : q.isError ? (
        <ErrorState
          message="Could not load correlations."
          onRetry={() => q.refetch()}
        />
      ) : q.data ? (
        <div className="grid gap-4 2xl:grid-cols-2">
          {q.data.windows.map((w) => (
            <Card key={w.label} className="overflow-hidden">
              <CardHeader
                title={w.label}
                subtitle={`${w.window_days}-day calendar lookback`}
              />
              <CorrelationMatrix window={w} />
            </Card>
          ))}
        </div>
      ) : null}

      {/* Rolling 30D price-correlation chart (Hedgeye style) */}
      <BtcRollingCorrelationsChart />
    </div>
  );
}
