import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { RefreshCw } from "lucide-react";
import { triggerQuantRefresh } from "@/api/quant";
import { Card, CardHeader } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { LoadingState } from "@/components/shared/LoadingState";
import { ErrorState } from "@/components/shared/ErrorState";
import {
  useQuantRelative,
  useQuantReturns,
  useQuantSnapshot,
  useQuantVsBtc,
} from "@/hooks/useQuant";
import { cn } from "@/lib/utils";
import type { QuantHorizon } from "@/types/api";
import { BtcSnapshotStrip } from "./BtcSnapshotStrip";
import { CryptoVolumeTable } from "./CryptoVolumeTable";
import { ReturnsGrid } from "./ReturnsGrid";

const HORIZONS_FULL: QuantHorizon[] = [
  "1D", "5D", "1M", "3M", "6M", "1Y", "QTD", "YTD",
];
const HORIZONS_PERF: QuantHorizon[] = [
  "1D", "5D", "1M", "3M", "QTD", "YTD", "52W_HIGH_PCT", "52W_LOW_PCT",
];

const CRYPTO_EQUITY_ASSETS = ["BTC", "ETH", "SOL", "AVAX", "ZEC", "MSTR", "MARA", "RIOT", "COIN"];
const VS_BTC_ASSETS = ["ETH", "SOL", "AVAX", "ZEC", "MSTR", "MARA", "RIOT", "COIN"];

function ageLabel(fetchedAt: number | undefined): string {
  if (!fetchedAt) return "-";
  const sec = Math.max(0, Math.round(Date.now() / 1000 - fetchedAt));
  if (sec < 60) return `${sec}s ago`;
  if (sec < 3600) return `${Math.round(sec / 60)}m ago`;
  return `${Math.round(sec / 3600)}h ago`;
}

export function DailyQuantPanel() {
  const qc = useQueryClient();
  const snapshot = useQuantSnapshot();
  const returnsQ = useQuantReturns();
  const relativeQ = useQuantRelative();
  const vsBtcQ = useQuantVsBtc();

  const [refreshing, setRefreshing] = useState(false);
  const [refreshError, setRefreshError] = useState<string | null>(null);

  const handleRefresh = async () => {
    setRefreshing(true);
    setRefreshError(null);
    try {
      await triggerQuantRefresh();
      await qc.invalidateQueries({ queryKey: ["quant"] });
    } catch (e) {
      setRefreshError(e instanceof Error ? e.message : "refresh failed");
    } finally {
      setRefreshing(false);
    }
  };

  const asOf = snapshot.data?.as_of ?? returnsQ.data?.as_of ?? null;
  const refreshedAt = snapshot.data?.fetched_at;

  return (
    <div className="space-y-4">
      {/* Header: title + meta badges + refresh */}
      <div className="flex flex-wrap items-end justify-between gap-3 border-b border-border pb-3">
        <div>
          <h2 className="flex items-baseline gap-2 text-xl font-bold tracking-tight text-fg">
            Daily <span className="text-brand">₿</span> Quant
            <span className="text-[10px] font-medium uppercase tracking-widest text-muted">
              Hedgeye-style
            </span>
          </h2>
          {asOf ? (
            <p className="mt-0.5 text-xs text-muted">
              As of <span className="font-mono text-fg">{asOf}</span>
              <span className="mx-2 text-border">•</span>
              Refreshed {ageLabel(refreshedAt)}
            </p>
          ) : null}
        </div>
        <div className="flex items-center gap-2">
          {refreshError ? (
            <span className="text-xs text-negative">{refreshError}</span>
          ) : null}
          <Button
            variant="secondary"
            size="sm"
            onClick={handleRefresh}
            disabled={refreshing}
          >
            <RefreshCw
              className={cn("h-3.5 w-3.5", refreshing && "animate-spin")}
            />
            {refreshing ? "Refreshing…" : "Refresh data"}
          </Button>
        </div>
      </div>

      {/* BTC snapshot bar */}
      <BtcSnapshotStrip />

      {/* Top row: BTC horizons (compact) + BTC relative perf — side-by-side on xl+ */}
      <div className="grid gap-4 xl:grid-cols-5">
        <Card className="xl:col-span-2 overflow-hidden">
          <CardHeader
            title={<span><span className="text-brand">₿</span> BTC</span>}
            subtitle="Multi-horizon performance"
          />
          <div className="overflow-x-auto">
            {returnsQ.isLoading && !returnsQ.data ? (
              <LoadingState label="Loading returns…" />
            ) : returnsQ.isError ? (
              <ErrorState
                message="Could not load returns."
                onRetry={() => returnsQ.refetch()}
              />
            ) : returnsQ.data ? (
              <ReturnsGrid
                rowLabels={["BTC"]}
                rows={returnsQ.data.rows}
                horizons={HORIZONS_FULL}
                emphasis="BTC"
              />
            ) : null}
          </div>
        </Card>

        <Card className="xl:col-span-3 overflow-hidden">
          <CardHeader
            title={<span><span className="text-brand">₿</span> BTC: Relative performance</span>}
            subtitle="vs S&P 500, Gold, US Dollar"
          />
          <div className="overflow-x-auto">
            {relativeQ.isLoading && !relativeQ.data ? (
              <LoadingState label="Loading relative…" />
            ) : relativeQ.isError ? (
              <ErrorState
                message="Could not load relative performance."
                onRetry={() => relativeQ.refetch()}
              />
            ) : relativeQ.data ? (
              <ReturnsGrid
                rowLabels={["SPX", "GOLD", "DXY"].map((s) => `vs ${s}`)}
                rows={Object.fromEntries(
                  Object.entries(relativeQ.data.rows).map(([k, v]) => [`vs ${k}`, v]),
                )}
                horizons={HORIZONS_FULL}
              />
            ) : null}
          </div>
        </Card>
      </div>

      {/* Crypto volume panel (Hedgeye style) */}
      <CryptoVolumeTable />

      {/* Crypto Performance + vs BTC — side-by-side on xl+ screens */}
      <div className="grid gap-4 xl:grid-cols-2">
        <Card className="overflow-hidden">
          <CardHeader
            title="Crypto Performance"
            subtitle="BTC, alts & crypto-equity beta — with 52-week distance"
          />
          <div className="overflow-x-auto">
            {returnsQ.data ? (
              <ReturnsGrid
                rowLabels={CRYPTO_EQUITY_ASSETS}
                rows={returnsQ.data.rows}
                horizons={HORIZONS_PERF}
                separateLast52w
                emphasis="BTC"
              />
            ) : null}
          </div>
        </Card>

        <Card className="overflow-hidden">
          <CardHeader
            title="vs BTC"
            subtitle="Each asset's return minus BTC, per horizon"
          />
          <div className="overflow-x-auto">
            {vsBtcQ.isLoading && !vsBtcQ.data ? (
              <LoadingState label="Loading vs-BTC matrix…" />
            ) : vsBtcQ.isError ? (
              <ErrorState
                message="Could not load vs-BTC matrix."
                onRetry={() => vsBtcQ.refetch()}
              />
            ) : vsBtcQ.data ? (
              <ReturnsGrid
                rowLabels={VS_BTC_ASSETS}
                rows={vsBtcQ.data.rows}
                horizons={HORIZONS_FULL}
              />
            ) : null}
          </div>
        </Card>
      </div>
    </div>
  );
}
