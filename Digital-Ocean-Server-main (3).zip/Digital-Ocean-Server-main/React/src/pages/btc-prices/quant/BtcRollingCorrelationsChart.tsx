import { useMemo, useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import {
  CartesianGrid,
  Legend,
  Line,
  LineChart,
  ReferenceLine,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { Card, CardHeader } from "@/components/ui/Card";
import { LoadingState } from "@/components/shared/LoadingState";
import { ErrorState } from "@/components/shared/ErrorState";
import { useQuantRollingCorrelations } from "@/hooks/useQuant";
import { useTheme } from "@/theme/ThemeProvider";
import { cn } from "@/lib/utils";
import type { QuantRollingCorrelationsResponse } from "@/types/api";

/** Partner palette — maximum hue separation so the 3 lines stay legible
 *  even when they cross. Chosen to avoid red/green (reserved for the
 *  positive/negative semantic tones) and to keep semantic meaning where
 *  possible: GOLD = amber, DXY = sky-blue (dollar/water), SPX = violet
 *  (a strong neutral that pops against the other two). */
const COLORS: Record<string, { light: string; dark: string }> = {
  SPX:  { light: "#7c3aed", dark: "#a78bfa" },     // violet
  DXY:  { light: "#0284c7", dark: "#38bdf8" },     // sky-blue
  GOLD: { light: "#d97706", dark: "#fbbf24" },     // amber / gold
  VIX:  { light: "#dc2626", dark: "#f85149" },     // red
  TIPS: { light: "#0d9488", dark: "#2dd4bf" },     // teal
  ETH:  { light: "#db2777", dark: "#f472b6" },     // pink
};

const HISTORY_PRESETS = [
  { label: "3M",  days: 90 },
  { label: "6M",  days: 180 },
  { label: "1Y",  days: 365 },
  { label: "2Y",  days: 730 },
];

function fmtShort(iso: string): string {
  const [y, m] = iso.split("-");
  const months = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
  return `${months[Number(m) - 1]}-${y.slice(2)}`;
}

function fmtTooltipDate(iso: string): string {
  const [y, m, d] = iso.split("-");
  const months = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
  return `${months[Number(m) - 1]} ${Number(d)}, ${y}`;
}

interface RowShape {
  date: string;
  [partner: string]: string | number | null;
}

function buildChartRows(data: QuantRollingCorrelationsResponse): RowShape[] {
  // Each partner has its own dates array; union them so missing days
  // become nulls (gaps in the line).
  const all = new Set<string>();
  for (const p of data.partners) {
    for (const d of data.series[p]?.dates ?? []) all.add(d);
  }
  const dates = [...all].sort();

  const indexByDate: Record<string, Record<string, number | null>> = {};
  for (const d of dates) indexByDate[d] = {};
  for (const p of data.partners) {
    const s = data.series[p];
    if (!s) continue;
    for (let i = 0; i < s.dates.length; i++) {
      indexByDate[s.dates[i]][p] = s.values[i];
    }
  }
  return dates.map((d) => ({ date: d, ...indexByDate[d] }));
}

function monthlyTicks(rows: RowShape[]): string[] {
  const seen = new Set<string>();
  const out: string[] = [];
  for (const r of rows) {
    const key = r.date.slice(0, 7);
    if (!seen.has(key)) {
      seen.add(key);
      out.push(r.date);
    }
  }
  return out;
}

export function BtcRollingCorrelationsChart() {
  const qc = useQueryClient();
  const [historyDays, setHistoryDays] = useState(365);
  const [windowDays] = useState(30);
  const partners = "SPX,DXY,GOLD";
  const q = useQuantRollingCorrelations(partners, windowDays, historyDays);

  const { theme } = useTheme();
  const dark = theme === "dark";
  const axis = dark ? "#8b949e" : "#6b7280";
  const grid = dark ? "rgba(139,148,161,0.15)" : "rgba(107,114,128,0.18)";

  const chartRows = useMemo(
    () => (q.data ? buildChartRows(q.data) : []),
    [q.data],
  );
  const xTicks = useMemo(() => monthlyTicks(chartRows), [chartRows]);

  return (
    <Card className="overflow-hidden">
      <CardHeader
        title={
          <span>
            <span className="text-brand">₿</span>TC: Rolling{" "}
            {windowDays}D Price Correlations
          </span>
        }
        subtitle={
          q.data?.asof
            ? `Pearson correlation of daily % returns · as of ${q.data.asof}`
            : "Pearson correlation of daily % returns"
        }
        action={
          <div className="flex flex-wrap gap-1.5">
            {HISTORY_PRESETS.map((p) => (
              <button
                key={p.label}
                type="button"
                onClick={() => {
                  setHistoryDays(p.days);
                  void qc.invalidateQueries({ queryKey: ["quant", "rolling-correlations"] });
                }}
                className={cn(
                  "rounded-md border px-2.5 py-1 text-xs font-medium",
                  historyDays === p.days
                    ? "border-brand bg-brand/15 text-brand"
                    : "border-border bg-surface-2 text-muted hover:text-fg",
                )}
              >
                {p.label}
              </button>
            ))}
          </div>
        }
      />
      <div className="px-5 pb-5">
        {q.isLoading && !q.data ? (
          <LoadingState label="Loading rolling correlations…" />
        ) : q.isError ? (
          <ErrorState
            message="Could not load rolling correlations."
            onRetry={() => q.refetch()}
          />
        ) : q.data && chartRows.length ? (
          <>
            <div style={{ width: "100%", height: 320 }}>
              <ResponsiveContainer>
                <LineChart data={chartRows} margin={{ top: 8, right: 16, bottom: 4, left: 4 }}>
                  <CartesianGrid stroke={grid} vertical={false} />
                  <XAxis
                    dataKey="date"
                    ticks={xTicks}
                    tickFormatter={fmtShort}
                    tick={{ fill: axis, fontSize: 11 }}
                    stroke={grid}
                  />
                  <YAxis
                    domain={[-1, 1]}
                    ticks={[-1, -0.5, 0, 0.5, 1]}
                    tickFormatter={(v) => Number(v).toFixed(1)}
                    tick={{ fill: axis, fontSize: 11 }}
                    stroke={grid}
                    width={40}
                  />
                  <ReferenceLine y={0} stroke={axis} strokeOpacity={0.6} />
                  <Tooltip
                    cursor={{ stroke: axis, strokeOpacity: 0.4 }}
                    content={({ active, payload }) => {
                      if (!active || !payload?.length) return null;
                      const date = String(payload[0]?.payload?.date ?? "");
                      return (
                        <div
                          style={{
                            background: dark ? "#161b22" : "#ffffff",
                            border: `1px solid ${grid}`,
                            borderRadius: 8,
                            fontSize: 12,
                            padding: "8px 10px",
                            minWidth: 160,
                            color: dark ? "#e6e9ef" : "#111827",
                          }}
                        >
                          <div style={{ color: axis, marginBottom: 4 }}>
                            {fmtTooltipDate(date)}
                          </div>
                          {q.data.partners.map((p) => {
                            const v = payload[0]?.payload?.[p];
                            const num = typeof v === "number" && Number.isFinite(v) ? v : null;
                            const color = (COLORS[p] ?? COLORS.SPX)[dark ? "dark" : "light"];
                            return (
                              <div
                                key={p}
                                style={{ display: "flex", justifyContent: "space-between", gap: 12 }}
                              >
                                <span style={{ color }}>{p}</span>
                                <span style={{ fontWeight: 600 }}>
                                  {num == null ? "-" : num.toFixed(2)}
                                </span>
                              </div>
                            );
                          })}
                        </div>
                      );
                    }}
                  />
                  <Legend
                    wrapperStyle={{ fontSize: 12, color: axis }}
                    iconType="plainline"
                  />
                  {q.data.partners.map((p) => {
                    const color = (COLORS[p] ?? COLORS.SPX)[dark ? "dark" : "light"];
                    return (
                      <Line
                        key={p}
                        type="monotone"
                        dataKey={p}
                        stroke={color}
                        strokeWidth={1.75}
                        dot={false}
                        connectNulls
                        isAnimationActive={false}
                      />
                    );
                  })}
                </LineChart>
              </ResponsiveContainer>
            </div>

            {/* Per-partner stats strip */}
            <div className="mt-3 grid grid-cols-3 gap-3 text-xs">
              {q.data.partners.map((p) => {
                const s = q.data.series[p]?.stats;
                const color = (COLORS[p] ?? COLORS.SPX)[dark ? "dark" : "light"];
                return (
                  <div
                    key={p}
                    className="flex flex-col gap-0.5 rounded-md border border-border bg-surface-2/40 px-3 py-2"
                  >
                    <span
                      className="text-[10px] font-semibold uppercase tracking-wider"
                      style={{ color }}
                    >
                      BTC ↔ {p}
                    </span>
                    <span className="text-base font-semibold tabular-nums text-fg">
                      {s?.latest != null ? s.latest.toFixed(2) : "-"}
                    </span>
                    <span className="text-[10px] text-muted">
                      1Y range{" "}
                      <span className="font-mono text-fg">
                        {s?.min != null ? s.min.toFixed(2) : "-"} … {s?.max != null ? s.max.toFixed(2) : "-"}
                      </span>
                    </span>
                  </div>
                );
              })}
            </div>
          </>
        ) : (
          <p className="py-12 text-center text-sm text-muted">No data.</p>
        )}
      </div>
    </Card>
  );
}
