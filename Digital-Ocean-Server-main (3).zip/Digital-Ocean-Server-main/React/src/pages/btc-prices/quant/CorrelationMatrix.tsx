import { cn } from "@/lib/utils";
import type { QuantCorrelationWindow } from "@/types/api";

/** Heat-tint by correlation magnitude. Saturates at |r| = 0.8. */
function tintClass(v: number | null | undefined, isDiagonal: boolean): string {
  if (isDiagonal) return "bg-muted/20 text-muted";
  if (v == null || !Number.isFinite(v)) return "text-muted";
  const mag = Math.min(1, Math.abs(v) / 0.8);
  if (v >= 0) {
    if (mag > 0.75) return "bg-positive/40 text-positive font-semibold";
    if (mag > 0.5)  return "bg-positive/25 text-positive font-medium";
    if (mag > 0.25) return "bg-positive/15 text-positive";
    if (mag > 0.05) return "bg-positive/10 text-positive";
    return "text-fg/80";
  }
  if (mag > 0.75) return "bg-negative/40 text-negative font-semibold";
  if (mag > 0.5)  return "bg-negative/25 text-negative font-medium";
  if (mag > 0.25) return "bg-negative/15 text-negative";
  if (mag > 0.05) return "bg-negative/10 text-negative";
  return "text-fg/80";
}

function fmt(v: number | null | undefined): string {
  if (v == null || !Number.isFinite(v)) return "-";
  return v.toFixed(2);
}

export function CorrelationMatrix({ window: w }: { window: QuantCorrelationWindow }) {
  const { matrix } = w;
  const labels = Object.keys(matrix);

  return (
    <div className="overflow-x-auto">
      <table className="w-full border-collapse text-xs">
        <thead>
          <tr className="border-b border-border bg-surface-2/40">
            <th className="sticky left-0 z-10 bg-surface-2/40 px-3 py-2 text-left text-[10px] font-medium uppercase tracking-wider text-muted backdrop-blur">
              {w.label}
            </th>
            {labels.map((l) => (
              <th
                key={l}
                className="px-2 py-2 text-center text-[10px] font-semibold uppercase tracking-wider text-fg"
              >
                {l}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {labels.map((row) => (
            <tr
              key={row}
              className="border-b border-border/60 last:border-0 hover:bg-surface-2/40"
            >
              <td className="sticky left-0 z-10 bg-surface px-3 py-1.5 text-left font-mono text-xs font-semibold text-fg whitespace-nowrap">
                {row}
              </td>
              {labels.map((col) => {
                const v = matrix[row]?.[col];
                const isDiag = row === col;
                return (
                  <td
                    key={col}
                    className={cn(
                      "px-2 py-1.5 text-center tabular-nums",
                      tintClass(v, isDiag),
                    )}
                    title={isDiag ? row : `${row} vs ${col}: r = ${fmt(v)} (n = ${w.sample_counts[row]?.[col] ?? 0})`}
                  >
                    {isDiag ? row : fmt(v)}
                  </td>
                );
              })}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
