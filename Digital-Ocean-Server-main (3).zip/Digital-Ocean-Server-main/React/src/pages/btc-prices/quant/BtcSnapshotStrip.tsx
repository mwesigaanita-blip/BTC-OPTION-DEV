import { LoadingState } from "@/components/shared/LoadingState";
import { ErrorState } from "@/components/shared/ErrorState";
import { useQuantSnapshot } from "@/hooks/useQuant";
import { fmtNum, fmtPct, fmtSignedPct, fmtUsd } from "@/lib/format";
import { cn } from "@/lib/utils";

function tone(n: number | null | undefined): string {
  if (n == null || !Number.isFinite(n)) return "text-fg";
  return n >= 0 ? "text-positive" : "text-negative";
}

function fmtMarketCap(n: number | null | undefined): string {
  if (n == null || !Number.isFinite(n)) return "-";
  if (n >= 1e12) return `$${(n / 1e12).toFixed(2)}T`;
  if (n >= 1e9) return `$${(n / 1e9).toFixed(2)}B`;
  return fmtUsd(n, 0);
}

/** Single dense tile inside the snapshot bar. */
function Tile({
  label,
  value,
  sub,
  valueClass,
  className,
}: {
  label: string;
  value: string;
  sub?: string;
  valueClass?: string;
  className?: string;
}) {
  return (
    <div className={cn("flex flex-col gap-0.5 px-4 py-2.5", className)}>
      <span className="text-[10px] font-medium uppercase tracking-wider text-muted">
        {label}
      </span>
      <span className={cn("text-base font-semibold tabular-nums leading-tight", valueClass)}>
        {value}
      </span>
      {sub ? (
        <span className="text-[10px] text-muted leading-tight">{sub}</span>
      ) : null}
    </div>
  );
}

export function BtcSnapshotStrip() {
  const q = useQuantSnapshot();

  if (q.isLoading && !q.data) return <LoadingState label="Loading BTC snapshot…" />;
  if (q.isError) {
    return (
      <ErrorState
        message="Could not load BTC snapshot. Run the refresh job to populate the Daily Quant tables."
        onRetry={() => q.refetch()}
      />
    );
  }
  const s = q.data;
  if (!s) return null;

  return (
    <div className="card overflow-hidden">
      <div
        className={cn(
          "grid grid-cols-2 divide-y divide-border",
          "sm:grid-cols-4 sm:divide-x sm:divide-y-0",
          "lg:grid-cols-8",
        )}
      >
        <Tile
          label="Price (last)"
          value={fmtUsd(s.price, 0)}
          sub={s.as_of}
        />
        <Tile
          label="Mkt Cap"
          value={fmtMarketCap(s.market_cap)}
          sub={`${fmtNum(s.circulating_supply / 1e6, 2)}M BTC`}
        />
        <Tile
          label="1D % Chg"
          value={s.change_1d_pct == null ? "-" : fmtSignedPct(s.change_1d_pct)}
          valueClass={tone(s.change_1d_pct)}
        />
        <Tile
          label="$USD Vol D/D"
          value={s.usd_vol_dd_pct == null ? "-" : fmtSignedPct(s.usd_vol_dd_pct)}
          valueClass={tone(s.usd_vol_dd_pct)}
        />
        <Tile
          label="Coin Vol D/D"
          value={s.coin_vol_dd_pct == null ? "-" : fmtSignedPct(s.coin_vol_dd_pct)}
          valueClass={tone(s.coin_vol_dd_pct)}
        />
        <Tile
          label="1M RVOL"
          value={s.rvol_1m == null ? "-" : fmtNum(s.rvol_1m, 2)}
          sub="Realized"
        />
        <Tile
          label="1M IVOL"
          value={s.ivol_1m == null ? "-" : fmtNum(s.ivol_1m, 2)}
          sub="DVOL"
        />
        <Tile
          label="IVOL Premium"
          value={s.ivol_premium_pct == null ? "-" : fmtPct(s.ivol_premium_pct, 0)}
          valueClass={tone(s.ivol_premium_pct)}
        />
      </div>
    </div>
  );
}
