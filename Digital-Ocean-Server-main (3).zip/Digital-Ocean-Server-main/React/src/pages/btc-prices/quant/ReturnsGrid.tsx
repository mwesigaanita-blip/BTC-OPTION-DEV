import { Table, Tbody, Tr } from "@/components/ui/Table";
import { fmtSignedPct } from "@/lib/format";
import { cn } from "@/lib/utils";
import type { QuantHorizon, QuantReturnRow } from "@/types/api";
import { AssetChip } from "./AssetChip";

const HORIZON_LABEL: Record<QuantHorizon, string> = {
  "1D": "1D",
  "5D": "5D",
  "1M": "1M",
  "3M": "3M",
  "6M": "6M",
  "1Y": "1Y",
  QTD: "QTD",
  YTD: "YTD",
  "52W_HIGH_PCT": "52W H",
  "52W_LOW_PCT": "52W L",
};

/** Heat-map tint by magnitude. Saturates at ±20%. */
function tintClass(n: number | null | undefined): string {
  if (n == null || !Number.isFinite(n)) return "text-muted";
  const mag = Math.min(1, Math.abs(n) / 20);
  if (n >= 0) {
    if (mag > 0.75) return "bg-positive/30 text-positive font-semibold";
    if (mag > 0.4) return "bg-positive/20 text-positive font-medium";
    if (mag > 0.1) return "bg-positive/10 text-positive";
    return "text-positive";
  }
  if (mag > 0.75) return "bg-negative/30 text-negative font-semibold";
  if (mag > 0.4) return "bg-negative/20 text-negative font-medium";
  if (mag > 0.1) return "bg-negative/10 text-negative";
  return "text-negative";
}

export interface ReturnsGridProps {
  rowLabels: string[];
  rows: Record<string, QuantReturnRow>;
  horizons: QuantHorizon[];
  rowHeader?: string;
  /** Render a left-border divider before the 52W columns. */
  separateLast52w?: boolean;
  /** Asset label to render bold/larger (e.g. "BTC" in the perf table). */
  emphasis?: string;
}

export function ReturnsGrid({
  rowLabels,
  rows,
  horizons,
  rowHeader,
  separateLast52w = false,
  emphasis,
}: ReturnsGridProps) {
  return (
    <Table className="text-xs">
      <thead>
        <tr className="border-b border-border bg-surface-2/40">
          <th className="sticky left-0 z-10 bg-surface-2/40 px-3 py-1.5 text-left text-[10px] font-medium uppercase tracking-wider text-muted backdrop-blur">
            {rowHeader ?? ""}
          </th>
          {horizons.map((h) => {
            const is52w = h === "52W_HIGH_PCT" || h === "52W_LOW_PCT";
            return (
              <th
                key={h}
                className={cn(
                  "px-2 py-1.5 text-right text-[10px] font-medium uppercase tracking-wider text-muted",
                  separateLast52w && is52w && h === "52W_HIGH_PCT"
                    ? "border-l border-border"
                    : "",
                )}
              >
                {HORIZON_LABEL[h]}
                <div className="text-[9px] font-normal lowercase tracking-normal opacity-70">
                  % chg
                </div>
              </th>
            );
          })}
        </tr>
      </thead>
      <Tbody>
        {rowLabels.map((label) => {
          const r = rows[label] ?? {};
          const isEmph = emphasis === label;
          return (
            <Tr
              key={label}
              className={cn(
                "border-b border-border/60 last:border-0",
                isEmph ? "bg-brand/5" : "hover:bg-surface-2/40",
              )}
            >
              <td className="sticky left-0 z-10 bg-surface px-3 py-1.5 whitespace-nowrap">
                <AssetChip label={label} emphasis={isEmph} />
              </td>
              {horizons.map((h) => {
                const v = r[h];
                const tint = tintClass(v ?? null);
                const is52w = h === "52W_HIGH_PCT" || h === "52W_LOW_PCT";
                return (
                  <td
                    key={h}
                    className={cn(
                      "px-2 py-1.5 text-right tabular-nums",
                      tint,
                      separateLast52w && is52w && h === "52W_HIGH_PCT"
                        ? "border-l border-border"
                        : "",
                    )}
                  >
                    {v == null ? "-" : fmtSignedPct(v, 1)}
                  </td>
                );
              })}
            </Tr>
          );
        })}
      </Tbody>
    </Table>
  );
}
