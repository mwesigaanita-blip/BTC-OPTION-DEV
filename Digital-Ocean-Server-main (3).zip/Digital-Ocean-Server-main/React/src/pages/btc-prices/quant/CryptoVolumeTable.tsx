import { Card, CardHeader } from "@/components/ui/Card";
import { LoadingState } from "@/components/shared/LoadingState";
import { ErrorState } from "@/components/shared/ErrorState";
import { useCryptoVolume } from "@/hooks/useQuant";
import { cn } from "@/lib/utils";
import type {
  CryptoVolumeResponse,
  VolumeMetrics,
  VolumeMetricKey,
} from "@/types/api";
import { AssetChip } from "./AssetChip";

const METRIC_LABEL: Record<VolumeMetricKey, string> = {
  dd_pct:       "D/D %",
  vs_1m_pct:    "vs 1M Avg",
  vs_3m_pct:    "vs 3M Avg",
  yy_qtrly_pct: "Y/Y (Qtrly)",
};

const METRICS: VolumeMetricKey[] = ["dd_pct", "vs_1m_pct", "vs_3m_pct", "yy_qtrly_pct"];

function fmt(v: number | null | undefined): string {
  if (v == null || !Number.isFinite(v)) return "-";
  return `${v >= 0 ? "+" : ""}${v.toFixed(1)}%`;
}

/** Heat tint by % magnitude, saturating at |v| = 60 (volume swings are large). */
function tintClass(v: number | null | undefined): string {
  if (v == null || !Number.isFinite(v)) return "text-muted";
  const mag = Math.min(1, Math.abs(v) / 60);
  if (v >= 0) {
    if (mag > 0.75) return "bg-positive/35 text-positive font-semibold";
    if (mag > 0.5)  return "bg-positive/25 text-positive font-medium";
    if (mag > 0.25) return "bg-positive/15 text-positive";
    return "text-positive";
  }
  if (mag > 0.75) return "bg-negative/35 text-negative font-semibold";
  if (mag > 0.5)  return "bg-negative/25 text-negative font-medium";
  if (mag > 0.25) return "bg-negative/15 text-negative";
  return "text-negative";
}

interface SideTableProps {
  title: string;
  data: CryptoVolumeResponse;
  side: "coin" | "usd";
}

function SideTable({ title, data, side }: SideTableProps) {
  return (
    <div className="overflow-x-auto">
      <table className="w-full border-collapse text-xs">
        <thead>
          <tr className="border-b border-border bg-surface-2/40">
            <th
              colSpan={1 + METRICS.length}
              className="px-3 py-1.5 text-center text-[11px] font-bold uppercase tracking-wider text-fg"
            >
              {title}
            </th>
          </tr>
          <tr className="border-b border-border bg-surface-2/40">
            <th className="sticky left-0 z-10 bg-surface-2/40 px-3 py-1.5 text-left text-[10px] font-medium uppercase tracking-wider text-muted backdrop-blur">
              {""}
            </th>
            {METRICS.map((m) => (
              <th
                key={m}
                className="px-2 py-1.5 text-right text-[10px] font-medium uppercase tracking-wider text-muted"
              >
                {METRIC_LABEL[m]}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {data.assets.map((a) => {
            const row = data.rows[a];
            const m: VolumeMetrics | undefined = row?.[side];
            return (
              <tr
                key={a}
                className="border-b border-border/60 last:border-0 hover:bg-surface-2/40"
              >
                <td className="sticky left-0 z-10 bg-surface px-3 py-1.5 whitespace-nowrap">
                  <AssetChip label={a} emphasis={a === "BTC"} />
                </td>
                {METRICS.map((k) => {
                  const v = m?.[k];
                  return (
                    <td
                      key={k}
                      className={cn("px-2 py-1.5 text-right tabular-nums", tintClass(v))}
                    >
                      {fmt(v)}
                    </td>
                  );
                })}
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

export function CryptoVolumeTable() {
  const q = useCryptoVolume();

  return (
    <Card className="overflow-hidden">
      <CardHeader
        title="Volume"
        subtitle={
          q.data?.asof
            ? `Coin volume & USD volume across 4 lookbacks · as of ${q.data.asof}`
            : "Coin volume & USD volume across 4 lookbacks"
        }
      />
      {q.isLoading && !q.data ? (
        <LoadingState label="Loading volume metrics…" />
      ) : q.isError ? (
        <ErrorState
          message="Could not load volume metrics."
          onRetry={() => q.refetch()}
        />
      ) : q.data ? (
        <div className="grid gap-3 lg:grid-cols-2">
          <SideTable title="Coin Volume" data={q.data} side="coin" />
          <SideTable title="$USD Volume" data={q.data} side="usd" />
        </div>
      ) : null}
    </Card>
  );
}
