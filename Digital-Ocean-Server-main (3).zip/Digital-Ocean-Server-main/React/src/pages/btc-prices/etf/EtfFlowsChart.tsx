import { useMemo } from "react";
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  ReferenceLine,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { useTheme } from "@/theme/ThemeProvider";
import type { EtfFlowsHistoryPoint } from "@/types/api";

function fmtShort(iso: string): string {
  const [y, m] = iso.split("-");
  const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
                  "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  return `${months[Number(m) - 1]}-${y.slice(2)}`;
}

function fmtTooltipDate(iso: string): string {
  const [y, m, d] = iso.split("-");
  const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
                  "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  return `${months[Number(m) - 1]} ${Number(d)}, ${y}`;
}

export function EtfFlowsChart({
  history,
  height = 280,
}: {
  history: EtfFlowsHistoryPoint[];
  height?: number;
}) {
  const { theme } = useTheme();
  const dark = theme === "dark";
  const axis = dark ? "#8b949e" : "#6b7280";
  const grid = dark ? "rgba(139,148,161,0.15)" : "rgba(107,114,128,0.18)";
  const up = dark ? "#3fb950" : "#16a34a";
  const down = dark ? "#f85149" : "#dc2626";

  // Only show one tick per month on the x-axis.
  const data = useMemo(() => history.filter((d) => d.total != null), [history]);
  const monthTicks = useMemo(() => {
    const seen = new Set<string>();
    const out: string[] = [];
    for (const d of data) {
      const key = d.date.slice(0, 7);
      if (!seen.has(key)) {
        seen.add(key);
        out.push(d.date);
      }
    }
    return out;
  }, [data]);

  return (
    <div style={{ width: "100%", height }}>
      <ResponsiveContainer>
        <BarChart data={data} margin={{ top: 8, right: 12, bottom: 4, left: 4 }}>
          <CartesianGrid stroke={grid} vertical={false} />
          <XAxis
            dataKey="date"
            ticks={monthTicks}
            tickFormatter={fmtShort}
            tick={{ fill: axis, fontSize: 11 }}
            stroke={grid}
          />
          <YAxis
            tick={{ fill: axis, fontSize: 11 }}
            stroke={grid}
            width={48}
            tickFormatter={(v) => `${v}`}
          />
          <ReferenceLine y={0} stroke={axis} strokeOpacity={0.6} />
          <Tooltip
            cursor={{ fill: dark ? "rgba(255,255,255,0.04)" : "rgba(0,0,0,0.04)" }}
            content={({ active, payload }) => {
              if (!active || !payload?.length) return null;
              const p = payload[0].payload as EtfFlowsHistoryPoint;
              const v = Number(p.total ?? 0);
              const positive = v >= 0;
              return (
                <div
                  style={{
                    background: dark ? "#161b22" : "#ffffff",
                    border: `1px solid ${grid}`,
                    borderRadius: 8,
                    fontSize: 12,
                    padding: "8px 10px",
                    minWidth: 160,
                    color: dark ? "#e6e9ef" : "#111827",
                  }}
                >
                  <div style={{ color: axis, marginBottom: 4 }}>
                    {fmtTooltipDate(p.date)}
                  </div>
                  <div
                    style={{
                      color: positive ? up : down,
                      fontWeight: 600,
                      fontSize: 14,
                    }}
                  >
                    {positive ? "+" : ""}${v.toFixed(1)}M
                  </div>
                </div>
              );
            }}
          />
          <Bar dataKey="total" isAnimationActive={false}>
            {data.map((d) => (
              <Cell
                key={d.date}
                fill={Number(d.total ?? 0) >= 0 ? up : down}
              />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}
