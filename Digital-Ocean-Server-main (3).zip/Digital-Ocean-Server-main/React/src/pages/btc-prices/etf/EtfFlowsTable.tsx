import { Tbody, Tr } from "@/components/ui/Table";
import { cn } from "@/lib/utils";
import type { EtfFlowsResponse } from "@/types/api";

/** Format a $M number for the daily-flow cells. */
function fmtFlow(v: number | null | undefined): string {
  if (v == null || !Number.isFinite(v)) return "-";
  if (v === 0) return "0.0";
  return v.toLocaleString("en-US", {
    minimumFractionDigits: 1,
    maximumFractionDigits: 1,
  });
}

/** Format a $M number for the cumulative-totals row (no decimals, thousands sep). */
function fmtTotal(v: number | null | undefined): string {
  if (v == null || !Number.isFinite(v)) return "-";
  return Math.round(v).toLocaleString("en-US");
}

function shortDate(iso: string): string {
  // 2026-05-22 -> 5/22/2026
  const [y, m, d] = iso.split("-");
  return `${Number(m)}/${Number(d)}/${y}`;
}

/** Heat tint by magnitude in $M. Saturates at ±200. */
function tintClass(v: number | null | undefined): string {
  if (v == null || !Number.isFinite(v) || v === 0) return "text-muted";
  const mag = Math.min(1, Math.abs(v) / 200);
  if (v >= 0) {
    if (mag > 0.75) return "bg-positive/30 text-positive font-semibold";
    if (mag > 0.4) return "bg-positive/15 text-positive";
    return "text-positive";
  }
  if (mag > 0.75) return "bg-negative/30 text-negative font-semibold";
  if (mag > 0.4) return "bg-negative/15 text-negative";
  return "text-negative";
}

function totalTintClass(v: number | null | undefined): string {
  if (v == null || !Number.isFinite(v)) return "text-fg";
  return v >= 0 ? "text-positive" : "text-negative";
}

export function EtfFlowsTable({ data }: { data: EtfFlowsResponse }) {
  const { tickers, rows, totals } = data;
  // Newest first to match the Hedgeye image.
  const display = [...rows].reverse();

  return (
    <div className="overflow-x-auto">
      <table className="w-full border-collapse text-xs">
        <thead>
          <tr className="border-b border-border bg-surface-2/40">
            <th className="sticky left-0 z-10 bg-surface-2/40 px-3 py-2 text-left text-[10px] font-medium uppercase tracking-wider text-muted backdrop-blur">
              Date
            </th>
            {tickers.map((t) => (
              <th
                key={t}
                className="px-2 py-2 text-right text-[10px] font-semibold uppercase tracking-wider text-fg"
              >
                {t}
              </th>
            ))}
            <th className="border-l border-border px-2 py-2 text-right text-[10px] font-semibold uppercase tracking-wider text-fg">
              TOTAL
            </th>
          </tr>
        </thead>
        <Tbody>
          {/* Cumulative totals row (since inception) */}
          <Tr className="border-b-2 border-border bg-brand/5">
            <td className="sticky left-0 z-10 bg-brand/5 px-3 py-1.5 text-left text-[10px] font-bold uppercase tracking-wider text-fg backdrop-blur">
              TOTAL
            </td>
            {tickers.map((t) => {
              const v = totals[t];
              return (
                <td
                  key={t}
                  className={cn(
                    "px-2 py-1.5 text-right font-semibold tabular-nums",
                    totalTintClass(v),
                  )}
                >
                  {fmtTotal(v)}
                </td>
              );
            })}
            <td
              className={cn(
                "border-l border-border px-2 py-1.5 text-right font-bold tabular-nums",
                totalTintClass(totals.TOTAL),
              )}
            >
              {fmtTotal(totals.TOTAL)}
            </td>
          </Tr>

          {/* Daily rows, newest first */}
          {display.map((r) => (
            <Tr
              key={r.date}
              className="border-b border-border/60 last:border-0 hover:bg-surface-2/40"
            >
              <td className="sticky left-0 z-10 bg-surface px-3 py-1.5 text-left font-mono text-[11px] text-muted whitespace-nowrap">
                {shortDate(r.date)}
              </td>
              {tickers.map((t) => {
                const v = r.flows[t];
                return (
                  <td
                    key={t}
                    className={cn(
                      "px-2 py-1.5 text-right tabular-nums",
                      tintClass(v),
                    )}
                  >
                    {fmtFlow(v)}
                  </td>
                );
              })}
              <td
                className={cn(
                  "border-l border-border px-2 py-1.5 text-right font-semibold tabular-nums",
                  totalTintClass(r.total),
                )}
              >
                {fmtFlow(r.total)}
              </td>
            </Tr>
          ))}
        </Tbody>
      </table>
    </div>
  );
}
