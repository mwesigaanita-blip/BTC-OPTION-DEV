import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { RefreshCw } from "lucide-react";
import { triggerEtfRefresh } from "@/api/etf";
import { Card, CardHeader } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { LoadingState } from "@/components/shared/LoadingState";
import { ErrorState } from "@/components/shared/ErrorState";
import { useEtfFlows } from "@/hooks/useEtfFlows";
import { cn } from "@/lib/utils";
import { EtfFlowsChart } from "./EtfFlowsChart";
import { EtfFlowsTable } from "./EtfFlowsTable";

const ROW_OPTIONS = [10, 20, 30, 60];
const HISTORY_OPTIONS = [
  { label: "3M", days: 90 },
  { label: "6M", days: 180 },
  { label: "1Y", days: 365 },
  { label: "All", days: 2000 },
];

function ageLabel(fetchedAt: number | undefined): string {
  if (!fetchedAt) return "-";
  const sec = Math.max(0, Math.round(Date.now() / 1000 - fetchedAt));
  if (sec < 60) return `${sec}s ago`;
  if (sec < 3600) return `${Math.round(sec / 60)}m ago`;
  return `${Math.round(sec / 3600)}h ago`;
}

export function EtfFlowsPanel() {
  const qc = useQueryClient();
  const [days, setDays] = useState(10);
  const [historyDays, setHistoryDays] = useState(180);
  const q = useEtfFlows(days, historyDays);

  const [refreshing, setRefreshing] = useState(false);
  const [refreshError, setRefreshError] = useState<string | null>(null);

  const handleRefresh = async () => {
    setRefreshing(true);
    setRefreshError(null);
    try {
      await triggerEtfRefresh();
      await qc.invalidateQueries({ queryKey: ["etf"] });
      // Daily Quant uses the same nightly job; invalidate that too.
      await qc.invalidateQueries({ queryKey: ["quant"] });
    } catch (e) {
      setRefreshError(e instanceof Error ? e.message : "refresh failed");
    } finally {
      setRefreshing(false);
    }
  };

  const data = q.data;
  const latestDate = data?.rows?.length ? data.rows[data.rows.length - 1].date : null;

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex flex-wrap items-end justify-between gap-3 border-b border-border pb-3">
        <div>
          <h2 className="flex items-baseline gap-2 text-xl font-bold tracking-tight text-fg">
            BTC ETF Flows
            <span className="text-[10px] font-medium uppercase tracking-widest text-muted">
              $Millions
            </span>
          </h2>
          {latestDate ? (
            <p className="mt-0.5 text-xs text-muted">
              Latest <span className="font-mono text-fg">{latestDate}</span>
              <span className="mx-2 text-border">•</span>
              Refreshed {ageLabel(data?.fetched_at)}
              <span className="mx-2 text-border">•</span>
              Source <a
                href="https://farside.co.uk/bitcoin-etf-flow-all-data/"
                target="_blank"
                rel="noreferrer"
                className="text-brand hover:underline"
              >
                Farside
              </a>
            </p>
          ) : null}
        </div>
        <div className="flex items-center gap-2">
          {refreshError ? (
            <span className="text-xs text-negative">{refreshError}</span>
          ) : null}
          <Button
            variant="secondary"
            size="sm"
            onClick={handleRefresh}
            disabled={refreshing}
          >
            <RefreshCw
              className={cn("h-3.5 w-3.5", refreshing && "animate-spin")}
            />
            {refreshing ? "Refreshing…" : "Refresh data"}
          </Button>
        </div>
      </div>

      {/* Daily flows table */}
      <Card className="overflow-hidden">
        <CardHeader
          title="Daily Flows"
          subtitle="Cumulative totals at top · last N daily rows below · $Millions"
          action={
            <div className="flex items-center gap-2">
              <label className="text-[11px] font-medium uppercase tracking-wide text-muted">
                Rows
              </label>
              <select
                value={days}
                onChange={(e) => setDays(Number(e.target.value))}
                className="h-8 rounded-md border border-border bg-surface-2 px-2 text-xs text-fg focus:outline-none focus:ring-2 focus:ring-brand"
              >
                {ROW_OPTIONS.map((n) => (
                  <option key={n} value={n}>{n}</option>
                ))}
              </select>
            </div>
          }
        />
        {q.isLoading && !data ? (
          <LoadingState label="Loading ETF flows…" />
        ) : q.isError ? (
          <ErrorState
            message="Could not load ETF flows. Run the refresh job to populate the table."
            onRetry={() => q.refetch()}
          />
        ) : data ? (
          <EtfFlowsTable data={data} />
        ) : null}
      </Card>

      {/* Net flow bar chart */}
      <Card>
        <CardHeader
          title="NET FLOW: BTC ETFs"
          subtitle="Daily net creation/redemption across all 12 funds"
          action={
            <div className="flex gap-1.5">
              {HISTORY_OPTIONS.map((opt) => (
                <button
                  key={opt.label}
                  type="button"
                  onClick={() => setHistoryDays(opt.days)}
                  className={cn(
                    "rounded-md border px-2.5 py-1 text-xs font-medium",
                    historyDays === opt.days
                      ? "border-brand bg-brand/15 text-brand"
                      : "border-border bg-surface-2 text-muted hover:text-fg",
                  )}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          }
        />
        <div className="px-5 pb-5">
          {data?.history?.length ? (
            <EtfFlowsChart history={data.history} />
          ) : (
            <p className="py-12 text-center text-sm text-muted">No history.</p>
          )}
        </div>
      </Card>
    </div>
  );
}
