import { useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { AlertCircle, CheckCircle2, Play, RefreshCw } from "lucide-react";
import {
  fetchOhlcv,
  fetchSchedulerState,
  fetchSnapshotLatest,
  fetchSnapshotToday,
  runSnapshotNow,
  type SchedulerState,
} from "@/api/optionsScheduler";
import { PageHeader } from "@/components/shared/PageHeader";
import { MetricCard } from "@/components/shared/MetricCard";
import { LoadingState } from "@/components/shared/LoadingState";
import { ErrorState } from "@/components/shared/ErrorState";
import { Card, CardBody, CardHeader } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { Input } from "@/components/ui/Input";
import { Badge } from "@/components/ui/Badge";
import { Tabs } from "@/components/ui/Tabs";
import {
  Table,
  Tbody,
  Td,
  Th,
  Thead,
  Tr,
} from "@/components/ui/Table";
import { cn } from "@/lib/utils";

type TabId = "ohlcv" | "snapshot";

function todayIso(): string {
  const d = new Date();
  const yyyy = d.getUTCFullYear();
  const mm = String(d.getUTCMonth() + 1).padStart(2, "0");
  const dd = String(d.getUTCDate()).padStart(2, "0");
  return `${yyyy}-${mm}-${dd}`;
}

function fmtCell(v: unknown): string {
  if (v == null) return "";
  if (typeof v === "number") {
    if (!Number.isFinite(v)) return "";
    if (Number.isInteger(v)) return v.toLocaleString();
    return v.toLocaleString(undefined, { maximumFractionDigits: 8 });
  }
  return String(v);
}

function fmtTs(s: string | null | undefined): string {
  if (!s) return "-";
  let v = String(s);
  if (v.endsWith("Z")) v = v.slice(0, -1);
  if (v.includes(".")) v = v.split(".")[0];
  return v.replace("T", " ") + " UTC";
}

export function LiveOptionsSchedulerPage() {
  const qc = useQueryClient();
  const [tab, setTab] = useState<TabId>("ohlcv");

  const stateQ = useQuery({
    queryKey: ["options-scheduler-state"],
    queryFn: fetchSchedulerState,
    refetchInterval: 30_000,
    retry: false,
  });

  if (stateQ.isLoading) return <LoadingState label="Loading scheduler state…" />;
  if (stateQ.error || !stateQ.data) {
    return (
      <ErrorState
        message={
          (stateQ.error as Error)?.message ??
          "Failed to load options-scheduler state"
        }
        onRetry={() => stateQ.refetch()}
      />
    );
  }

  const state = stateQ.data;

  return (
    <div className="space-y-5 animate-fade-in">
      <PageHeader
        title="Live Options Scheduler"
        description="Snapshot (greeks + IV) and OHLCV 1-minute pipelines for BTC options."
        actions={
          <Button
            variant="secondary"
            size="sm"
            onClick={() => {
              qc.invalidateQueries({ queryKey: ["options-scheduler-state"] });
              qc.invalidateQueries({ queryKey: ["options-scheduler-snapshot-latest"] });
              qc.invalidateQueries({ queryKey: ["options-scheduler-snapshot-today"] });
              qc.invalidateQueries({ queryKey: ["options-scheduler-ohlcv"] });
            }}
          >
            <RefreshCw className="h-3.5 w-3.5" />
            Refresh
          </Button>
        }
      />

      <Tabs
        active={tab}
        onChange={(id) => setTab(id as TabId)}
        tabs={[
          { id: "ohlcv", label: "OHLCV 1-Minute" },
          { id: "snapshot", label: "Snapshot (Greeks)" },
        ]}
      />

      <div className="pt-2">
        {tab === "ohlcv" ? <OhlcvTab state={state} /> : null}
        {tab === "snapshot" ? <SnapshotTab state={state} /> : null}
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// OHLCV tab
// ---------------------------------------------------------------------------

function OhlcvTab({ state }: { state: SchedulerState }) {
  const [day, setDay] = useState<string>(todayIso());
  const [instrument, setInstrument] = useState<string>("All");
  const [limit, setLimit] = useState<number>(50);

  const q = useQuery({
    queryKey: ["options-scheduler-ohlcv", day, instrument, limit],
    queryFn: () => fetchOhlcv(day, instrument, limit),
    retry: false,
  });

  const data = q.data;
  const ohlcvState = state.ohlcv.state ?? {};
  const ohlcvCfg = state.ohlcv.config;
  const gaps = Array.isArray(ohlcvState.gaps) ? (ohlcvState.gaps as unknown[]) : [];

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader title="Pipeline state" />
          <CardBody className="space-y-1 pt-0 text-xs">
            <Row label="Last run" value={fmtTs(ohlcvState.last_run_at as string | null)} mono />
            <Row label="Last completed" value={(ohlcvState.last_completed_date as string) || "-"} mono />
            <Row label="Instruments fetched" value={String(ohlcvState.instruments_fetched ?? 0)} />
            <Row label="Rows written" value={String(ohlcvState.rows_written ?? 0)} />
            <Row label="Base dir" value={ohlcvCfg.base_dir} mono />
          </CardBody>
        </Card>
        <Card>
          <CardHeader title="Configuration" />
          <CardBody className="space-y-1 pt-0 text-xs">
            <Row label="OPTIONS_OHLCV_ENABLED" value={ohlcvCfg.enabled} mono />
            <Row
              label="OPTIONS_OHLCV_INTERVAL_SECONDS"
              value={ohlcvCfg.interval_seconds}
              mono
            />
            <div className="mt-2 text-[0.7rem] text-muted">
              Resolution <span className="font-semibold text-fg">1 minute</span>{" "}
              · fetched hourly. Set env vars in docker-compose.yml.
            </div>
          </CardBody>
        </Card>
      </div>

      <Card>
        <CardHeader title="OHLCV by date" />
        <CardBody className="pt-0">
          <div className="grid grid-cols-1 gap-3 md:grid-cols-3">
            <div>
              <label className="block text-xs font-medium text-muted">Date (UTC)</label>
              <Input
                type="date"
                value={day}
                onChange={(e) => setDay(e.target.value)}
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-muted">Filter by instrument</label>
              <select
                className="h-11 w-full rounded-lg border border-border bg-surface-2 px-3 text-sm"
                value={instrument}
                onChange={(e) => setInstrument(e.target.value)}
              >
                <option value="All">All</option>
                {(data?.instruments ?? []).map((i) => (
                  <option key={i} value={i}>
                    {i}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-muted">Rows shown</label>
              <select
                className="h-11 w-full rounded-lg border border-border bg-surface-2 px-3 text-sm"
                value={String(limit)}
                onChange={(e) => setLimit(Number(e.target.value))}
              >
                {[50, 100, 200, 500, 1000, 2000].map((n) => (
                  <option key={n} value={n}>
                    {n}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="mt-3">
            {q.isLoading ? (
              <LoadingState label="Loading OHLCV…" />
            ) : q.error ? (
              <ErrorState
                message={(q.error as Error).message}
                onRetry={() => q.refetch()}
              />
            ) : !data ? null : !data.available ? (
              <div className="rounded-lg border border-warning/40 bg-warning/10 px-3 py-2 text-sm text-warning">
                No OHLCV data found for {day}.
              </div>
            ) : data.total === 0 ? (
              <div className="text-xs text-muted">Parquet exists but is empty.</div>
            ) : (
              <>
                <div className="mb-3 grid grid-cols-2 gap-3 md:grid-cols-4">
                  <MetricCard label="Rows" value={data.total.toLocaleString()} />
                  <MetricCard
                    label="Instruments"
                    value={String(data.instruments.length)}
                  />
                  <MetricCard
                    label="First timestamp"
                    value={data.first_ts ? data.first_ts.slice(11, 16) : "-"}
                  />
                  <MetricCard
                    label="Last timestamp"
                    value={data.last_ts ? data.last_ts.slice(11, 16) : "-"}
                  />
                </div>
                <ParquetTable rows={data.rows} columns={data.columns} />
                <div className="mt-2 text-[0.7rem] text-muted">
                  Showing {data.rows.length.toLocaleString()} of{" "}
                  {(data.filtered ?? data.total).toLocaleString()} rows (sorted
                  by timestamp desc).
                </div>
              </>
            )}
          </div>
        </CardBody>
      </Card>

      {gaps.length > 0 ? (
        <Card>
          <CardHeader title={`Detected gaps (${gaps.length})`} />
          <CardBody className="pt-0">
            <pre className="max-h-72 overflow-auto rounded-md border border-border bg-surface-2/40 p-3 text-[0.7rem] text-muted">
              {JSON.stringify(gaps, null, 2)}
            </pre>
          </CardBody>
        </Card>
      ) : null}
    </div>
  );
}

// ---------------------------------------------------------------------------
// Snapshot tab
// ---------------------------------------------------------------------------

function SnapshotTab({ state }: { state: SchedulerState }) {
  const qc = useQueryClient();
  const snap = state.snapshot.state ?? {};
  const cfg = state.snapshot.config;

  const todayQ = useQuery({
    queryKey: ["options-scheduler-snapshot-today"],
    queryFn: fetchSnapshotToday,
    retry: false,
  });
  const latestQ = useQuery({
    queryKey: ["options-scheduler-snapshot-latest"],
    queryFn: () => fetchSnapshotLatest(20),
    retry: false,
  });

  const runMut = useMutation({
    mutationFn: runSnapshotNow,
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["options-scheduler-state"] });
      qc.invalidateQueries({ queryKey: ["options-scheduler-snapshot-today"] });
      qc.invalidateQueries({ queryKey: ["options-scheduler-snapshot-latest"] });
    },
  });
  const runErr =
    (runMut.error as { response?: { data?: { detail?: string } }; message?: string } | null)
      ?.response?.data?.detail ??
    (runMut.error as Error | null)?.message ??
    null;

  const today = state.today_utc;
  const lastCompleted = (snap.last_completed_date as string) || null;
  const ranToday = lastCompleted === today;

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader title="Pipeline state" />
          <CardBody className="space-y-1 pt-0 text-xs">
            <Row label="Last run" value={fmtTs(snap.last_run_at as string | null)} mono />
            <Row label="Last completed" value={lastCompleted || "-"} mono />
            <Row label="Instruments fetched" value={String(snap.instruments_fetched ?? 0)} />
            <Row label="Rows written" value={String(snap.rows_written ?? 0)} />
            <Row label="Base dir" value={cfg.base_dir} mono />
          </CardBody>
        </Card>
        <Card>
          <CardHeader title="Configuration" />
          <CardBody className="space-y-1 pt-0 text-xs">
            <Row label="SNAPSHOT_ENABLED" value={cfg.enabled} mono />
            <Row label="SNAPSHOT_INTERVAL_SECONDS" value={cfg.interval_seconds} mono />
            <div className="mt-2 text-[0.7rem] text-muted">
              Configure via environment variables in docker-compose.yml.
            </div>
          </CardBody>
        </Card>
      </div>

      <div className="grid grid-cols-1 gap-3 md:grid-cols-3">
        <MetricCard label="Now (UTC)" value={fmtTs(state.now_utc)} />
        <MetricCard label="Last run (UTC)" value={fmtTs(snap.last_run_at as string | null)} />
        <MetricCard
          label="Last snapshot date"
          value={lastCompleted || "-"}
          sub={`today (UTC) = ${today}`}
          tone={ranToday ? "positive" : "warning"}
        />
      </div>

      <div
        className={cn(
          "flex items-center gap-2 rounded-md border-l-4 px-3 py-2 text-sm",
          ranToday
            ? "border-positive bg-positive/10 text-positive"
            : "border-warning bg-warning/10 text-warning",
        )}
      >
        {ranToday ? (
          <CheckCircle2 className="h-4 w-4" />
        ) : (
          <AlertCircle className="h-4 w-4" />
        )}
        <span>
          {ranToday
            ? `Snapshot has run today (UTC): ${today}`
            : `Snapshot has NOT run today (UTC): ${today}`}
        </span>
      </div>

      <div className="text-xs text-muted">
        Rows in today's snapshot ({today}):{" "}
        <span className="font-semibold text-fg">
          {todayQ.isLoading
            ? "…"
            : todayQ.data?.rows != null
              ? todayQ.data.rows.toLocaleString()
              : "0"}
        </span>
      </div>

      <Card>
        <CardHeader
          title="Latest snapshot rows"
          subtitle="Most recent parquet (walks back up to 7 days)."
        />
        <CardBody className="pt-0">
          {latestQ.isLoading ? (
            <LoadingState label="Loading latest snapshot…" />
          ) : latestQ.error ? (
            <ErrorState
              message={(latestQ.error as Error).message}
              onRetry={() => latestQ.refetch()}
            />
          ) : !latestQ.data || latestQ.data.rows.length === 0 ? (
            <div className="rounded-lg border border-warning/40 bg-warning/10 px-3 py-2 text-sm text-warning">
              No snapshot data found yet.
            </div>
          ) : (
            <>
              <ParquetTable
                rows={latestQ.data.rows}
                columns={latestQ.data.columns}
              />
              <div className="mt-2 text-[0.7rem] text-muted">
                Showing 20 of {latestQ.data.total.toLocaleString()} rows from
                the latest snapshot.
              </div>
            </>
          )}
        </CardBody>
      </Card>

      <Card>
        <CardHeader
          title="Manual trigger"
          subtitle="Runs the full snapshot pipeline once. Blocking — the request waits until the run finishes (typically 5–20 s)."
        />
        <CardBody className="pt-0">
          <Button
            onClick={() => runMut.mutate()}
            disabled={runMut.isPending}
            className="w-full md:w-auto"
          >
            <Play
              className={cn("h-3.5 w-3.5", runMut.isPending && "animate-pulse")}
            />
            {runMut.isPending ? "Running…" : "Run snapshot NOW"}
          </Button>
          {runMut.isSuccess && runMut.data ? (
            <div className="mt-3 rounded-md border border-positive/40 bg-positive/10 px-3 py-2 text-xs text-positive">
              <div>
                <span className="font-semibold">Snapshot completed.</span>
              </div>
              <div className="mt-1 grid gap-x-4 gap-y-0.5 sm:grid-cols-3">
                <span>
                  Instruments: <b>{runMut.data.instruments_total}</b>
                </span>
                <span>
                  Rows written: <b>{runMut.data.rows_written.toLocaleString()}</b>
                </span>
                <span>
                  Duration: <b>{runMut.data.duration_seconds.toFixed(1)}s</b>
                </span>
              </div>
              {runMut.data.files_written &&
              Object.keys(runMut.data.files_written).length > 0 ? (
                <div className="mt-2 flex flex-wrap gap-1">
                  {Object.entries(runMut.data.files_written).map(([d, n]) => (
                    <Badge key={d} tone="positive">
                      {d}: {n.toLocaleString()}
                    </Badge>
                  ))}
                </div>
              ) : null}
            </div>
          ) : null}
          {runErr ? (
            <div className="mt-3 rounded-md border border-negative/40 bg-negative/10 px-3 py-2 text-xs text-negative">
              {runErr}
            </div>
          ) : null}
        </CardBody>
      </Card>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Small helpers
// ---------------------------------------------------------------------------

function Row({
  label,
  value,
  mono = false,
}: {
  label: string;
  value: string;
  mono?: boolean;
}) {
  return (
    <div className="flex items-baseline justify-between gap-3">
      <span className="text-muted">{label}</span>
      <span className={cn(mono && "font-mono")}>{value}</span>
    </div>
  );
}

function ParquetTable({
  rows,
  columns,
}: {
  rows: Record<string, unknown>[];
  columns: string[];
}) {
  // Cap visible columns so a parquet with 40 fields doesn't explode the page.
  const visibleColumns = useMemo(() => columns.slice(0, 14), [columns]);
  return (
    <div className="overflow-x-auto">
      <Table className="text-[0.7rem]">
        <Thead>
          <Tr>
            {visibleColumns.map((c) => (
              <Th
                key={c}
                className="px-1.5 py-1 text-[0.65rem] uppercase tracking-tight"
              >
                {c}
              </Th>
            ))}
          </Tr>
        </Thead>
        <Tbody>
          {rows.map((r, i) => (
            <Tr key={i}>
              {visibleColumns.map((c) => (
                <Td
                  key={c}
                  className={cn(
                    "px-1.5 py-1 text-[0.7rem]",
                    typeof r[c] === "number" && "text-right tabular-nums",
                  )}
                >
                  {fmtCell(r[c])}
                </Td>
              ))}
            </Tr>
          ))}
        </Tbody>
      </Table>
      {columns.length > visibleColumns.length ? (
        <div className="mt-1 text-[0.7rem] text-muted">
          + {columns.length - visibleColumns.length} more column(s) in the parquet
          (download to inspect)
        </div>
      ) : null}
    </div>
  );
}
