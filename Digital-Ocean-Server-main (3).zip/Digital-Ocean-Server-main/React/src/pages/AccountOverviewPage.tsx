import { useCallback, useRef, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import {
  Activity,
  Bitcoin,
  CircleDollarSign,
  FlaskConical,
  Gauge,
  Layers,
  LayoutDashboard,
  TrendingDown,
  TrendingUp,
  Waves,
} from "lucide-react";
import { Tabs } from "@/components/ui/Tabs";
import { CustomWhatIfPnl } from "@/components/whatif/CustomWhatIfPnl";
import {
  fetchAccountOverview,
  fetchEquityHistory,
  fetchPnlCurve,
  fetchPositions,
} from "@/api/account";
import { useWebSocket } from "@/hooks/useWebSocket";
import { PageHeader } from "@/components/shared/PageHeader";
import { StalenessBanner } from "@/components/shared/StalenessBanner";
import { MetricCard } from "@/components/shared/MetricCard";
import { LoadingState } from "@/components/shared/LoadingState";
import { ErrorState } from "@/components/shared/ErrorState";
import { PnlCurveChart } from "@/components/shared/PnlCurveChart";
import { Card, CardBody, CardHeader } from "@/components/ui/Card";
import { Badge } from "@/components/ui/Badge";
import { PositionsTree } from "@/components/shared/PositionsTree";
import { fmtNum, fmtPct, fmtSignedPct, fmtUsd } from "@/lib/format";
import { cn } from "@/lib/utils";
import type { AccountPayload, PerCurrency } from "@/types/api";

const QK = {
  account: ["account-overview"] as const,
  positions: ["positions"] as const,
  pnl: ["pnl-curve"] as const,
  equity: ["equity-history"] as const,
};

type Tone = "neutral" | "positive" | "negative" | "warning";

/** Margin-usage colour: >50% red, 30-50% yellow, <30% green. */
function marginTone(pct: unknown): Tone {
  const n = Number(pct);
  if (!Number.isFinite(n)) return "neutral";
  if (n > 50) return "negative";
  if (n >= 30) return "warning";
  return "positive";
}

/** Resolve per-currency blocks (BTC / USDT / USDC) from the account payload. */
function perCurrencyOf(acct: AccountPayload | null | undefined): PerCurrency[] {
  if (!acct) return [];
  if (acct.per_currency) {
    return ["BTC", "USDT", "USDC"]
      .map((c) => acct.per_currency?.[c])
      .filter((x): x is PerCurrency => Boolean(x));
  }
  if (acct.currency) return [acct as unknown as PerCurrency];
  return [];
}

/** Account Overview shell - two sub-tabs. */
export function AccountOverviewPage() {
  const [tab, setTab] = useState("live");
  return (
    <div className="space-y-5">
      <Tabs
        active={tab}
        onChange={setTab}
        tabs={[
          {
            id: "live",
            label: "Live Portfolio",
            icon: <LayoutDashboard className="h-4 w-4" />,
          },
          {
            id: "whatif",
            label: "Custom What-If PNL",
            icon: <FlaskConical className="h-4 w-4" />,
          },
        ]}
      />
      {tab === "live" ? <LivePortfolioTab /> : <CustomWhatIfPnl />}
    </div>
  );
}

function LivePortfolioTab() {
  const qc = useQueryClient();

  const accountQ = useQuery({
    queryKey: QK.account,
    queryFn: fetchAccountOverview,
    refetchInterval: 4000,
  });
  const positionsQ = useQuery({
    queryKey: QK.positions,
    queryFn: fetchPositions,
    refetchInterval: 4000,
  });
  const pnlQ = useQuery({
    queryKey: QK.pnl,
    queryFn: () => fetchPnlCurve({ range_pct: 50 }),
    refetchInterval: 10000,
    retry: false,
  });
  const equityQ = useQuery({
    queryKey: QK.equity,
    queryFn: fetchEquityHistory,
    refetchInterval: 60000,
    retry: false,
  });

  // WebSocket push: a message nudges a refetch (throttled so a busy market
  // tick stream cannot hammer the REST API).
  const lastInvalidate = useRef(0);
  const nudge = useCallback(() => {
    const now = Date.now();
    if (now - lastInvalidate.current < 2000) return;
    lastInvalidate.current = now;
    qc.invalidateQueries({ queryKey: QK.account });
    qc.invalidateQueries({ queryKey: QK.positions });
    qc.invalidateQueries({ queryKey: QK.pnl });
  }, [qc]);

  const wsStatus = useWebSocket("/ws/account", nudge);
  useWebSocket("/ws/positions", nudge);
  useWebSocket("/ws/market", nudge);

  if (accountQ.isLoading) return <LoadingState label="Loading account…" />;
  if (accountQ.isError) {
    return (
      <ErrorState
        message="Could not load account data."
        onRetry={() => accountQ.refetch()}
      />
    );
  }

  const data = accountQ.data!;
  const account = data.account;
  const greeks = data.greeks ?? {};
  const currencies = perCurrencyOf(account);
  const btc = currencies.find((c) => c.currency === "BTC");
  const positions = positionsQ.data?.positions ?? [];

  const btcChanges = (account?.btc_changes ?? {}) as Record<string, unknown>;
  const rocPct = (btcChanges.roc_pct ?? {}) as Record<string, unknown>;
  const dvolChanges = (account?.dvol_changes ?? {}) as Record<string, unknown>;
  const dvolRocPct = (dvolChanges.roc_pct ?? {}) as Record<string, unknown>;
  // IM card uses the SAME colour as MM (driven by the MM % thresholds).
  const mmCardTone = marginTone(btc?.mm_pct_of_mb);

  return (
    <div className="space-y-6">
      <PageHeader
        title="Account Overview"
        description="Real-time account equity, margin and risk."
        actions={
          <Badge tone={wsStatus === "open" ? "positive" : "neutral"}>
            <span
              className={
                "h-1.5 w-1.5 rounded-full " +
                (wsStatus === "open"
                  ? "bg-positive animate-pulse"
                  : "bg-muted")
              }
            />
            {wsStatus === "open" ? "WS connected" : "WS offline"}
          </Badge>
        }
      />

      <StalenessBanner source={data.source} updatedAt={data.updated_at} />

      {/* BTC index + DVOL + total equity */}
      <div className="grid gap-4 lg:grid-cols-3">
        <BtcIndexCard price={btc?.index_price_usd} roc={rocPct} />
        <DvolCard value={dvolChanges.index_value} roc={dvolRocPct} />
        <TotalEquityCard
          total={account?.total_equity_usd}
          changes={equityQ.data?.changes ?? {}}
        />
      </div>

      {/* Margin usage - IM colour mirrors MM */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <MetricCard
          label="IM % of Margin Bal."
          value={fmtPct(btc?.im_pct_of_mb)}
          icon={Layers}
          tone={mmCardTone}
        />
        <MetricCard
          label="MM % of Margin Bal."
          value={fmtPct(btc?.mm_pct_of_mb)}
          icon={Gauge}
          tone={mmCardTone}
        />
      </div>

      {/* Greeks */}
      <Card>
        <CardHeader
          title="Portfolio Greeks"
          subtitle="Aggregated across the live position book"
        />
        <CardBody>
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
            <GreekStat label="Delta (BTC)" raw={greeks.delta_btc} digits={4} />
            <GreekStat label="Gamma" raw={greeks.gamma} digits={6} />
            <GreekStat
              label="Theta (USD/day)"
              raw={greeks.theta_usd_per_day}
              digits={2}
            />
            <GreekStat label="Vega (USD)" raw={greeks.vega_usd} digits={2} />
          </div>
        </CardBody>
      </Card>

      {/* Per-currency */}
      {currencies.length > 0 ? (
        <div className="grid gap-4 md:grid-cols-3">
          {currencies.map((c) => (
            <CurrencyCard key={c.currency} c={c} />
          ))}
        </div>
      ) : null}

      {/* PnL curve */}
      <Card>
        <CardHeader
          title="PnL Payoff Curve"
          subtitle="Repriced from the live snapshot across a ±50% BTC move"
          action={<Activity className="h-4 w-4 text-muted" />}
        />
        <CardBody>
          {pnlQ.isLoading ? (
            <LoadingState label="Computing curve…" />
          ) : pnlQ.isError || !pnlQ.data?.curve?.length ? (
            <ErrorState
              message="No live data available to build the PnL curve."
              onRetry={() => pnlQ.refetch()}
            />
          ) : (
            <PnlCurveChart
              curve={pnlQ.data.curve}
              breakEven={pnlQ.data.break_even ?? []}
              spot={
                Number(
                  (pnlQ.data.context as Record<string, unknown>)
                    ?.btc_index_price,
                ) || undefined
              }
            />
          )}
        </CardBody>
      </Card>

      {/* Positions */}
      <Card>
        <CardHeader
          title="Open Positions"
          subtitle={`${positions.length} position${positions.length === 1 ? "" : "s"}`}
        />
        <CardBody className="px-0">
          <PositionsTree positions={positions} />
        </CardBody>
      </Card>
    </div>
  );
}

/** One rate-of-change pill - green up / red down / muted flat. */
function RocChip({
  label,
  value,
}: {
  label: string;
  value: unknown;
}) {
  const n = Number(value);
  const has = Number.isFinite(n) && value !== null && value !== undefined;
  const dir = !has ? 0 : n > 0 ? 1 : n < 0 ? -1 : 0;
  const tone =
    dir > 0 ? "text-positive" : dir < 0 ? "text-negative" : "text-muted";
  const Arrow = dir > 0 ? TrendingUp : dir < 0 ? TrendingDown : null;
  return (
    <div
      className={cn(
        "flex min-w-[68px] flex-col items-center rounded-lg px-2.5 py-1.5",
        dir > 0
          ? "bg-positive/10"
          : dir < 0
            ? "bg-negative/10"
            : "bg-surface-2",
      )}
    >
      <span className="text-[10px] font-medium uppercase tracking-wide text-muted">
        {label}
      </span>
      <span
        className={cn(
          "flex items-center gap-0.5 text-sm font-semibold tabular-nums",
          tone,
        )}
      >
        {Arrow ? <Arrow className="h-3 w-3" /> : null}
        {has ? fmtSignedPct(n) : "-"}
      </span>
    </div>
  );
}

/** BTC index price with the rate-of-change strip, mirroring Streamlit. */
function BtcIndexCard({
  price,
  roc,
}: {
  price: unknown;
  roc: Record<string, unknown>;
}) {
  const windows: Array<[string, string]> = [
    ["15m", "15m"],
    ["30m", "30m"],
    ["1h", "1h"],
    ["12h", "12h"],
    ["1d", "1d"],
  ];
  return (
    <div className="card animate-fade-in p-4">
      <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
        <div>
          <span className="text-xs font-medium uppercase tracking-wide text-muted">
            BTC Index
          </span>
          <div className="mt-1 flex items-center gap-2">
            <Bitcoin className="h-6 w-6 text-warning" />
            <span className="text-3xl font-semibold tabular-nums text-fg">
              {fmtUsd(price, 0)}
            </span>
          </div>
        </div>
        <div className="flex flex-wrap gap-2">
          {windows.map(([key, label]) => (
            <RocChip key={key} label={label} value={roc[key]} />
          ))}
        </div>
      </div>
    </div>
  );
}

/** Deribit Volatility Index (DVOL) with the same ROC strip as BTC. */
function DvolCard({
  value,
  roc,
}: {
  value: unknown;
  roc: Record<string, unknown>;
}) {
  const windows: Array<[string, string]> = [
    ["15m", "15m"],
    ["30m", "30m"],
    ["1h", "1h"],
    ["12h", "12h"],
    ["1d", "1d"],
  ];
  const n = Number(value);
  const has = Number.isFinite(n);
  return (
    <div className="card animate-fade-in p-4">
      <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
        <div>
          <span className="text-xs font-medium uppercase tracking-wide text-muted">
            DVOL (BTC)
          </span>
          <div className="mt-1 flex items-center gap-2">
            <Waves className="h-6 w-6 text-brand" />
            <span className="text-3xl font-semibold tabular-nums text-fg">
              {has ? fmtNum(n, 2) : "-"}
            </span>
          </div>
        </div>
        <div className="flex flex-wrap gap-2">
          {windows.map(([key, label]) => (
            <RocChip key={key} label={label} value={roc[key]} />
          ))}
        </div>
      </div>
    </div>
  );
}

/** Total account equity with daily change chips (from SQLite history). */
function TotalEquityCard({
  total,
  changes,
}: {
  total: unknown;
  changes: Record<string, unknown>;
}) {
  const windows: Array<[string, string]> = [
    ["1d", "1D"],
    ["7d", "7D"],
    ["30d", "30D"],
  ];
  return (
    <div className="card animate-fade-in p-4">
      <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
        <div>
          <span className="text-xs font-medium uppercase tracking-wide text-muted">
            Total Equity
          </span>
          <div className="mt-1 flex items-center gap-2">
            <CircleDollarSign className="h-6 w-6 text-brand" />
            <span className="text-3xl font-semibold tabular-nums text-fg">
              {fmtUsd(total)}
            </span>
          </div>
        </div>
        <div className="flex flex-wrap gap-2">
          {windows.map(([key, label]) => (
            <RocChip key={key} label={label} value={changes[key]} />
          ))}
        </div>
      </div>
    </div>
  );
}

/** A single greek - green when positive, red when negative. */
function GreekStat({
  label,
  raw,
  digits,
}: {
  label: string;
  raw: unknown;
  digits: number;
}) {
  const n = Number(raw);
  const has = Number.isFinite(n);
  const tone =
    !has || n === 0
      ? "text-fg"
      : n > 0
        ? "text-positive"
        : "text-negative";
  return (
    <div className="rounded-lg bg-surface-2 p-3">
      <div className="text-xs text-muted">{label}</div>
      <div className={cn("mt-1 text-lg font-semibold tabular-nums", tone)}>
        {has ? fmtNum(n, digits) : "-"}
      </div>
    </div>
  );
}

function CurrencyCard({ c }: { c: PerCurrency }) {
  return (
    <Card>
      <CardHeader
        title={c.currency}
        action={<Badge tone="brand">{c.capital_basis ?? "equity"}</Badge>}
      />
      <CardBody className="space-y-2 text-sm">
        <Row label="Equity (USD)" value={fmtUsd(c.equity_usd)} />
        <Row label="Available (USD)" value={fmtUsd(c.available_funds_usd)} />
        <Row label="Margin Balance" value={fmtNum(c.margin_balance, 2)} />
        <Row label="Initial Margin" value={fmtNum(c.initial_margin, 2)} />
        <Row label="Maint. Margin" value={fmtNum(c.maintenance_margin, 2)} />
      </CardBody>
    </Card>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between">
      <span className="text-muted">{label}</span>
      <span className="tabular-nums text-fg">{value}</span>
    </div>
  );
}

