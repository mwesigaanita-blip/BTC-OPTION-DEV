import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { AlertCircle, Download, RefreshCw, Star } from "lucide-react";
import {
  downloadPortfolioBotReport,
  fetchPortfolioBotDashboard,
  type CalmScore,
  type PortfolioBotDashboard,
  type Severity,
} from "@/api/portfolioBot";
import { PageHeader } from "@/components/shared/PageHeader";
import { MetricCard } from "@/components/shared/MetricCard";
import { LoadingState } from "@/components/shared/LoadingState";
import { ErrorState } from "@/components/shared/ErrorState";
import { Card, CardBody, CardHeader } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { Badge } from "@/components/ui/Badge";
import { Tabs } from "@/components/ui/Tabs";
import {
  Table,
  Tbody,
  Td,
  Th,
  Thead,
  Tr,
} from "@/components/ui/Table";
import { cn } from "@/lib/utils";

// ---------------------------------------------------------------------------
// Visual tokens (mirror the Streamlit page)
// ---------------------------------------------------------------------------

const CALM_COLOR: Record<string, string> = {
  RELAX: "#2E7D32",
  TAKE_A_LOOK: "#F9A825",
  ACTIVE_MONITORING: "#EF6C00",
  URGENT_ACTION: "#C62828",
};

const SEVERITY_TONE: Record<string, "neutral" | "warning" | "negative"> = {
  INFO: "neutral",
  WARNING: "warning",
  URGENT: "warning",
  EMERGENCY: "negative",
};

function fmtTs(s: string | null | undefined): string {
  if (!s) return "-";
  let v = String(s);
  if (v.endsWith("Z")) v = v.slice(0, -1);
  if (v.includes(".")) v = v.split(".")[0];
  return v.replace("T", " ") + " UTC";
}

function hoursAgo(s: string | null | undefined): number | null {
  if (!s) return null;
  let v = String(s);
  if (!v.endsWith("Z") && !/[+\-]\d\d:?\d\d$/.test(v)) v = v + "Z";
  const t = new Date(v).getTime();
  if (!Number.isFinite(t)) return null;
  return (Date.now() - t) / 3600_000;
}

function CalmBadge({ score }: { score: CalmScore | null | undefined }) {
  const color = (score && CALM_COLOR[score]) || "#555";
  return (
    <span
      className="inline-flex rounded-md px-3 py-1.5 text-xs font-bold tracking-wide text-white"
      style={{ backgroundColor: color }}
    >
      {score ?? "NO STATE"}
    </span>
  );
}

function SeverityBadge({ sev }: { sev: Severity }) {
  return <Badge tone={SEVERITY_TONE[sev] ?? "neutral"}>{sev}</Badge>;
}

// ---------------------------------------------------------------------------
// Page
// ---------------------------------------------------------------------------

type TabId = "overview" | "thresholds" | "reports" | "info";

export function PortfolioAnalysisBotPage() {
  const qc = useQueryClient();
  const q = useQuery({
    queryKey: ["portfolio-bot-dashboard"],
    queryFn: () => fetchPortfolioBotDashboard(50),
    refetchInterval: 30_000,
    retry: false,
  });
  const [tab, setTab] = useState<TabId>("overview");

  if (q.isLoading) return <LoadingState label="Loading Portfolio Analysis Bot…" />;
  if (q.error || !q.data) {
    return (
      <ErrorState
        message={(q.error as Error)?.message ?? "Failed to load dashboard"}
        onRetry={() => q.refetch()}
      />
    );
  }
  const d = q.data;
  const state = d.state;
  const calm = state?.calm_score;

  // Bot liveness signal: last audit row age.
  const lastAudit = d.audit[0];
  const auditAgeH = lastAudit ? hoursAgo(lastAudit.ts_utc) : null;
  const aliveMsg = lastAudit
    ? auditAgeH != null
      ? `last audit ${auditAgeH.toFixed(1)}h ago (${lastAudit.user_name} ${lastAudit.action})`
      : `last audit ${lastAudit.user_name} ${lastAudit.action}`
    : "no audit rows yet";

  const overrides = d.thresholds.filter((t) => t.overridden).length;
  const reportAgeH = d.latest_report_run
    ? hoursAgo((d.latest_report_run as { ts_utc?: string }).ts_utc)
    : null;

  return (
    <div className="space-y-5 animate-fade-in">
      <PageHeader
        title="🤖 Portfolio Analysis Bot"
        description="Control-plane view of the Portfolio Co-Pilot — thresholds, alerts, daily reports."
        actions={
          <Button
            variant="secondary"
            size="sm"
            onClick={() => qc.invalidateQueries({ queryKey: ["portfolio-bot-dashboard"] })}
            disabled={q.isFetching}
          >
            <RefreshCw className={cn("h-3.5 w-3.5", q.isFetching && "animate-spin")} />
            Refresh
          </Button>
        }
      />

      {/* Top status bar */}
      <Card>
        <CardBody className="flex flex-wrap items-center gap-5 pt-4">
          <div>
            <div className="text-[0.7rem] font-semibold uppercase tracking-wide text-muted">
              Calm Score
            </div>
            <div className="mt-1">
              <CalmBadge score={calm} />
            </div>
          </div>
          <div className="text-xs text-muted">
            <div className="font-semibold text-fg">
              {lastAudit ? "🟢" : "⚪"} bot
            </div>
            <div>{aliveMsg}</div>
          </div>
        </CardBody>
      </Card>

      {/* KPI strip */}
      <div className="grid grid-cols-2 gap-3 md:grid-cols-5">
        <MetricCard label="Active Alerts" value={String(d.alerts.length)} />
        <MetricCard label="Suppressions" value={String(d.suppressions.length)} />
        <MetricCard label="Threshold Overrides" value={String(overrides)} />
        <MetricCard
          label="Last Daily Report"
          value={reportAgeH != null ? `${reportAgeH.toFixed(1)}h ago` : "-"}
        />
        <MetricCard
          label="PDFs available"
          value={String(d.reports.length)}
          sub={d.config.report_dir}
        />
      </div>

      <Tabs
        active={tab}
        onChange={(id) => setTab(id as TabId)}
        tabs={[
          { id: "overview", label: "📋 Overview" },
          { id: "thresholds", label: "🎚️ Thresholds" },
          { id: "reports", label: "📄 Daily Reports" },
          { id: "info", label: "ℹ️ Info" },
        ]}
      />

      <div className="pt-2">
        {tab === "overview" ? <OverviewTab d={d} /> : null}
        {tab === "thresholds" ? <ThresholdsTab d={d} /> : null}
        {tab === "reports" ? <ReportsTab d={d} /> : null}
        {tab === "info" ? <InfoTab d={d} /> : null}
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Overview tab
// ---------------------------------------------------------------------------

function OverviewTab({ d }: { d: PortfolioBotDashboard }) {
  const state = d.state;
  return (
    <div className="grid grid-cols-1 gap-4 lg:grid-cols-5">
      <div className="space-y-4 lg:col-span-3">
        <Card>
          <CardHeader title="Current state" />
          <CardBody className="pt-0">
            {state ? (
              <>
                <div className="flex items-center gap-3">
                  <CalmBadge score={state.calm_score} />
                  <span className="text-xs text-muted">
                    as of {fmtTs(state.ts_utc)}
                  </span>
                </div>
                <div className="mt-3 whitespace-pre-wrap text-sm text-muted">
                  {state.reasoning || "(no reasoning recorded)"}
                </div>
              </>
            ) : (
              <div className="text-xs text-muted">
                No state recorded yet. Has the AlertWorker run?
              </div>
            )}
          </CardBody>
        </Card>

        <Card>
          <CardHeader title={`Active alerts (${d.alerts.length})`} />
          <CardBody className="pt-0">
            {d.alerts.length === 0 ? (
              <div className="rounded-lg border border-positive/40 bg-positive/10 px-3 py-2 text-sm text-positive">
                No unresolved alerts. ✅
              </div>
            ) : (
              <Table>
                <Thead>
                  <Tr>
                    <Th>Time</Th>
                    <Th>Sev.</Th>
                    <Th>Rule</Th>
                    <Th>Dedup key</Th>
                    <Th>Message</Th>
                  </Tr>
                </Thead>
                <Tbody>
                  {d.alerts.map((a, i) => (
                    <Tr key={i}>
                      <Td className="font-mono text-xs text-muted">{fmtTs(a.ts_utc)}</Td>
                      <Td>
                        <SeverityBadge sev={a.severity} />
                      </Td>
                      <Td className="font-semibold">{a.rule}</Td>
                      <Td className="font-mono text-xs">{a.dedup_key}</Td>
                      <Td className="max-w-md truncate text-xs">{a.message ?? ""}</Td>
                    </Tr>
                  ))}
                </Tbody>
              </Table>
            )}
          </CardBody>
        </Card>
      </div>

      <div className="space-y-4 lg:col-span-2">
        <Card>
          <CardHeader title={`Suppressions (${d.suppressions.length})`} />
          <CardBody className="space-y-2 pt-0">
            {d.suppressions.length === 0 ? (
              <div className="text-xs text-muted">None active.</div>
            ) : (
              d.suppressions.map((s, i) => (
                <div
                  key={i}
                  className="rounded-md border border-warning/30 bg-warning/10 px-3 py-2"
                >
                  <div className="font-mono text-xs text-warning">{s.dedup_key}</div>
                  <div className="mt-1 text-[0.7rem] text-muted">
                    set by <span className="font-semibold text-fg">{s.set_by_user_name}</span>{" "}
                    · expires {fmtTs(s.expires_at_utc)}
                  </div>
                </div>
              ))
            )}
          </CardBody>
        </Card>

        <Card>
          <CardHeader title="Recent activity" subtitle="Last 10 audit entries" />
          <CardBody className="space-y-1 pt-0">
            {d.audit.length === 0 ? (
              <div className="text-xs text-muted">(audit log empty)</div>
            ) : (
              d.audit.slice(0, 10).map((r, i) => {
                let short = r.payload_json;
                try {
                  const obj = JSON.parse(r.payload_json ?? "{}");
                  short = Object.entries(obj)
                    .slice(0, 2)
                    .map(([k, v]) => `${k}=${v}`)
                    .join(", ");
                } catch {
                  // keep raw
                }
                return (
                  <div
                    key={i}
                    className="border-l-2 border-border px-2 py-1 text-xs text-muted"
                  >
                    <span className="font-mono">{fmtTs(r.ts_utc)}</span>{" "}
                    <span className="font-semibold text-brand">{r.user_name}</span>{" "}
                    <span className="text-warning">{r.action}</span>{" "}
                    <span>· {short}</span>
                  </div>
                );
              })
            )}
          </CardBody>
        </Card>
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Thresholds tab
// ---------------------------------------------------------------------------

function ThresholdsTab({ d }: { d: PortfolioBotDashboard }) {
  const overridden = d.thresholds.filter((t) => t.overridden).length;
  return (
    <div className="space-y-4">
      <Card>
        <CardHeader
          title="Current thresholds"
          subtitle="Defaults come from portfolio_analysis/config.py. Active overrides are set via the Telegram /set command and auto-expire after their duration. Read-only here — to change, message the bot."
        />
        <CardBody className="px-0 pt-0">
          <Table>
            <Thead>
              <Tr>
                <Th>Threshold</Th>
                <Th>Internal name</Th>
                <Th className="text-right">Current</Th>
                <Th className="text-right">Default</Th>
                <Th>Overridden</Th>
                <Th>Expires (UTC)</Th>
                <Th>Set by</Th>
                <Th>Description</Th>
              </Tr>
            </Thead>
            <Tbody>
              {d.thresholds.map((t) => (
                <Tr
                  key={t.name}
                  className={cn(t.overridden && "bg-warning/10")}
                >
                  <Td className="font-semibold">{t.label}</Td>
                  <Td className="font-mono text-xs">{t.name}</Td>
                  <Td className="text-right tabular-nums">{t.current_display}</Td>
                  <Td className="text-right tabular-nums">{t.default_display}</Td>
                  <Td>
                    {t.overridden ? (
                      <Badge tone="warning">✅ YES</Badge>
                    ) : (
                      <span className="text-muted">-</span>
                    )}
                  </Td>
                  <Td className="font-mono text-xs">
                    {t.overridden ? fmtTs(t.expires_at_utc) : "-"}
                  </Td>
                  <Td>{t.set_by_user_name || "-"}</Td>
                  <Td className="max-w-md text-xs text-muted">{t.description}</Td>
                </Tr>
              ))}
            </Tbody>
          </Table>
        </CardBody>
      </Card>

      {overridden > 0 ? (
        <div className="flex items-start gap-2 rounded-md border-l-4 border-warning bg-warning/10 px-3 py-2 text-sm">
          <AlertCircle className="mt-0.5 h-4 w-4 shrink-0 text-warning" />
          <div>
            <span className="font-semibold">{overridden} override(s) active</span> —
            highlighted rows above. Send <code>/thresholds</code> to the Telegram
            bot for the same view.
          </div>
        </div>
      ) : (
        <div className="rounded-md border border-positive/40 bg-positive/10 px-3 py-2 text-sm text-positive">
          All thresholds at default values.
        </div>
      )}

      <Card>
        <CardHeader
          title="Override history"
          subtitle="Last 30 /set, /stop, /resume actions from audit_log."
        />
        <CardBody className="px-0 pt-0">
          {d.audit.length === 0 ? (
            <div className="px-5 pb-4 text-xs text-muted">(no audit entries yet)</div>
          ) : (
            <Table>
              <Thead>
                <Tr>
                  <Th>Time (UTC)</Th>
                  <Th>User</Th>
                  <Th>Action</Th>
                  <Th>Details</Th>
                </Tr>
              </Thead>
              <Tbody>
                {d.audit.slice(0, 30).map((r, i) => {
                  let payload: Record<string, unknown> = {};
                  try {
                    payload = JSON.parse(r.payload_json ?? "{}");
                  } catch {
                    payload = {};
                  }
                  return (
                    <Tr key={i}>
                      <Td className="font-mono text-xs">{fmtTs(r.ts_utc)}</Td>
                      <Td className="font-semibold">{r.user_name}</Td>
                      <Td>
                        <Badge tone="neutral">{r.action}</Badge>
                      </Td>
                      <Td className="font-mono text-xs">
                        {Object.entries(payload)
                          .map(([k, v]) => `${k}=${v}`)
                          .join(", ")}
                      </Td>
                    </Tr>
                  );
                })}
              </Tbody>
            </Table>
          )}
        </CardBody>
      </Card>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Reports tab
// ---------------------------------------------------------------------------

function ReportsTab({ d }: { d: PortfolioBotDashboard }) {
  const [selected, setSelected] = useState<string>(d.reports[0]?.name ?? "");
  const [downloadErr, setDownloadErr] = useState<string | null>(null);
  const [downloading, setDownloading] = useState(false);
  const latest = d.reports[0];

  async function handleDownload(name: string) {
    setDownloadErr(null);
    setDownloading(true);
    try {
      await downloadPortfolioBotReport(name);
    } catch (e: any) {
      setDownloadErr(e?.message ?? "Download failed");
    } finally {
      setDownloading(false);
    }
  }

  return (
    <div className="space-y-4">
      {d.reports.length === 0 ? (
        <Card>
          <CardBody className="pt-4 text-sm text-muted">
            No PDFs found in <code>{d.config.report_dir}</code>. The first one
            is generated either at the configured UTC time (
            {String(d.config.report_daily_utc_hour).padStart(2, "0")}:
            {String(d.config.report_daily_utc_minute).padStart(2, "0")}) or on
            demand via the Telegram <code>/report</code> command.
          </CardBody>
        </Card>
      ) : (
        <>
          <div className="text-xs text-muted">
            📁 {d.config.report_dir} · {d.reports.length} file(s) on disk
          </div>

          {latest ? (
            <Card>
              <CardBody className="pt-4">
                <div className="flex items-start justify-between gap-3 rounded-lg border border-brand/40 bg-brand/5 px-4 py-3">
                  <div>
                    <div className="flex items-center gap-2 text-[0.7rem] font-bold uppercase tracking-wide text-brand">
                      <Star className="h-3.5 w-3.5" /> Latest report
                    </div>
                    <div className="mt-1 font-mono text-sm text-fg">
                      {latest.name}
                    </div>
                    <div className="mt-1 text-xs text-muted">
                      {latest.size_kb.toLocaleString()} KB · generated {fmtTs(latest.modified_utc)}
                    </div>
                  </div>
                  <Button
                    size="sm"
                    onClick={() => handleDownload(latest.name)}
                    disabled={downloading}
                  >
                    <Download className="h-3.5 w-3.5" />
                    Download
                  </Button>
                </div>
              </CardBody>
            </Card>
          ) : null}

          <Card>
            <CardHeader title="All reports" subtitle="Most recent 50" />
            <CardBody className="px-0 pt-0">
              <Table>
                <Thead>
                  <Tr>
                    <Th>Filename</Th>
                    <Th>Generated (UTC)</Th>
                    <Th className="text-right">Size</Th>
                  </Tr>
                </Thead>
                <Tbody>
                  {d.reports.slice(0, 50).map((r) => (
                    <Tr key={r.name}>
                      <Td className="font-mono text-xs">{r.name}</Td>
                      <Td className="font-mono text-xs">{fmtTs(r.modified_utc)}</Td>
                      <Td className="text-right tabular-nums">
                        {r.size_kb.toLocaleString()} KB
                      </Td>
                    </Tr>
                  ))}
                </Tbody>
              </Table>
            </CardBody>
          </Card>

          <Card>
            <CardHeader title="Download any report" />
            <CardBody className="flex flex-wrap items-end gap-2 pt-0">
              <div className="min-w-[260px] flex-1">
                <label className="block text-xs font-medium text-muted">
                  Select a report
                </label>
                <select
                  className="h-11 w-full rounded-lg border border-border bg-surface-2 px-3 text-sm"
                  value={selected}
                  onChange={(e) => setSelected(e.target.value)}
                >
                  {d.reports.map((r) => (
                    <option key={r.name} value={r.name}>
                      {r.name}
                    </option>
                  ))}
                </select>
              </div>
              <Button
                onClick={() => handleDownload(selected)}
                disabled={!selected || downloading}
              >
                <Download className="h-3.5 w-3.5" />
                {downloading ? "Downloading…" : "Download"}
              </Button>
              {downloadErr ? (
                <span className="text-xs text-negative">{downloadErr}</span>
              ) : null}
            </CardBody>
          </Card>
        </>
      )}

      <Card>
        <CardHeader title="Generate a new report on demand" />
        <CardBody className="pt-0 text-sm text-muted">
          Send <code>/report</code> to the Telegram bot. The bot will build a
          fresh PDF (live Deribit market intelligence + portfolio control plane)
          and send it back to your chat. The new file will appear in this list
          after the next refresh.
        </CardBody>
      </Card>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Info tab
// ---------------------------------------------------------------------------

function InfoTab({ d }: { d: PortfolioBotDashboard }) {
  const hh = String(d.config.report_daily_utc_hour).padStart(2, "0");
  const mm = String(d.config.report_daily_utc_minute).padStart(2, "0");
  const calmStates: Array<[CalmScore, string]> = [
    ["RELAX", "Nothing to act on; routine monitoring."],
    ["TAKE_A_LOOK", "At least one INFO/WARNING signal worth glancing at."],
    ["ACTIVE_MONITORING", "At least one URGENT alert; check positions."],
    ["URGENT_ACTION", "EMERGENCY: maintenance margin or delta breach."],
  ];
  const commands: Array<[string, string]> = [
    ["/help", "Print every command."],
    ["/status", "Current Calm Score + active alerts + suppressions."],
    ["/thresholds", "List every threshold's current value."],
    [
      "/set <name> <value> <duration>",
      "Override a threshold (e.g. /set MM_WARN_PCT 25 7d).",
    ],
    ["/stop <key | RULE>", "Suppress alerts for a dedup_key or whole rule."],
    ["/resume <key | RULE>", "Lift an active suppression early."],
    ["/audit [N]", "Last N audit entries (default 20, max 100)."],
    ["/report", "Build today's PDF on demand and send it back."],
  ];
  const envs: Array<[string, string]> = [
    [
      "DERIBIT_CLIENT_ID / SECRET",
      "Required for the 12 market sections of the daily PDF. Missing → portfolio-only fallback.",
    ],
    ["TELEGRAM_PORTFOLIO_BOT_TOKEN", "Bot token for sending."],
    [
      "TELEGRAM_CHAT_IDS",
      'JSON dict of chat targets, e.g. {"andres":"111"}.',
    ],
    [
      "AUTHORIZED_TELEGRAM_USERS",
      "JSON dict of user-ids allowed to issue commands.",
    ],
    [
      "DRY_RUN",
      "1 = log instead of posting to Telegram (useful for testing).",
    ],
    [
      "REPORT_DAILY_UTC_HOUR/MINUTE",
      "Daily report fire time (defaults: 0, 5).",
    ],
    ["PORTFOLIO_REPORT_DIR", "Override the PDF output directory."],
  ];

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader title="What is the Portfolio Analysis Bot?" />
        <CardBody className="pt-0 text-sm text-muted">
          <p>
            The Portfolio Analysis Bot is the <strong>control plane</strong>{" "}
            of the Portfolio Co-Pilot system. It runs three daemon threads
            inside one process:
          </p>
          <ol className="ml-5 list-decimal space-y-1">
            <li>
              <strong>AlertWorker</strong> - evaluates the 5 alert rules every
              30 seconds and writes to <code>alerts</code> /{" "}
              <code>state_history</code>.
            </li>
            <li>
              <strong>HeartbeatWorker</strong> - sends a periodic Telegram
              digest at a cadence that scales with the Calm Score.
            </li>
            <li>
              <strong>DailyReportWorker</strong> - at <code>{hh}:{mm} UTC</code>{" "}
              every day, builds a combined PDF and ships it via Telegram{" "}
              <code>sendDocument</code>.
            </li>
          </ol>
          <p>
            A separate Telegram long-poll bot (
            <code>portfolio_analysis.bot.server</code>) accepts commands from
            authorised users.
          </p>
        </CardBody>
      </Card>

      <Card>
        <CardHeader title="Calm Score states" />
        <CardBody className="space-y-2 pt-0">
          {calmStates.map(([name, meaning]) => (
            <div
              key={name}
              className="flex items-start gap-3 rounded-md border border-border bg-surface-2/40 p-2"
            >
              <CalmBadge score={name} />
              <div className="text-xs text-muted">{meaning}</div>
            </div>
          ))}
        </CardBody>
      </Card>

      <Card>
        <CardHeader title="Telegram commands" />
        <CardBody className="px-0 pt-0">
          <Table>
            <Thead>
              <Tr>
                <Th>Command</Th>
                <Th>Effect</Th>
              </Tr>
            </Thead>
            <Tbody>
              {commands.map(([cmd, effect]) => (
                <Tr key={cmd}>
                  <Td className="font-mono text-xs">{cmd}</Td>
                  <Td className="text-sm">{effect}</Td>
                </Tr>
              ))}
            </Tbody>
          </Table>
        </CardBody>
      </Card>

      <Card>
        <CardHeader title="Environment variables" />
        <CardBody className="px-0 pt-0">
          <Table>
            <Thead>
              <Tr>
                <Th>Variable</Th>
                <Th>Purpose</Th>
              </Tr>
            </Thead>
            <Tbody>
              {envs.map(([v, p]) => (
                <Tr key={v}>
                  <Td className="font-mono text-xs">{v}</Td>
                  <Td className="text-xs text-muted">{p}</Td>
                </Tr>
              ))}
            </Tbody>
          </Table>
        </CardBody>
      </Card>

      <Card>
        <CardHeader title="Useful files" />
        <CardBody className="pt-0 text-sm text-muted">
          <ul className="ml-5 list-disc space-y-1">
            <li>
              <strong>Daily report builder:</strong>{" "}
              <code>portfolio_analysis/report_daily.py</code>
            </li>
            <li>
              <strong>Scheduler entrypoint:</strong>{" "}
              <code>python -m portfolio_analysis.scheduler</code>
            </li>
            <li>
              <strong>Telegram bot entrypoint:</strong>{" "}
              <code>python -m portfolio_analysis.bot.server</code>
            </li>
            <li>
              <strong>Telegram command reference:</strong>{" "}
              <code>portfolio_analysis/docs/telegram_commands.txt</code>
            </li>
            <li>
              <strong>Plan &amp; phases:</strong>{" "}
              <code>portfolio_analysis/docs/plan.md</code>,{" "}
              <code>implementation_plan_phase1.md</code>
            </li>
          </ul>
        </CardBody>
      </Card>
    </div>
  );
}
