import { useState } from "react";
import { Card, CardHeader } from "@/components/ui/Card";
import { LoadingState } from "@/components/shared/LoadingState";
import { ErrorState } from "@/components/shared/ErrorState";
import { useVolDashboard } from "@/hooks/useVolDashboard";
import { cn } from "@/lib/utils";
import { IvolPremiumChart } from "./IvolPremiumChart";
import { VolStatsStrip } from "./VolStatsStrip";

const HISTORY_PRESETS = [
  { label: "3M",  days: 90 },
  { label: "6M",  days: 180 },
  { label: "1Y",  days: 365 },
  { label: "2Y",  days: 730 },
];

export function VolDashboardPanel() {
  const [lookback, setLookback] = useState(180);
  const q = useVolDashboard(lookback);

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex flex-wrap items-end justify-between gap-3 border-b border-border pb-3">
        <div>
          <h2 className="flex items-baseline gap-2 text-xl font-bold tracking-tight text-fg">
            Volatility (TTM)
            <span className="text-[10px] font-medium uppercase tracking-widest text-muted">
              Realized vs Implied · Hedgeye-style
            </span>
          </h2>
          {q.data?.asof ? (
            <p className="mt-0.5 text-xs text-muted">
              As of <span className="font-mono text-fg">{q.data.asof}</span>
              <span className="mx-2 text-border">•</span>
              {q.data.lookback_days}-day lookback
            </p>
          ) : null}
        </div>
        <div className="flex gap-1.5">
          {HISTORY_PRESETS.map((p) => (
            <button
              key={p.label}
              type="button"
              onClick={() => setLookback(p.days)}
              className={cn(
                "rounded-md border px-2.5 py-1 text-xs font-medium",
                lookback === p.days
                  ? "border-brand bg-brand/15 text-brand"
                  : "border-border bg-surface-2 text-muted hover:text-fg",
              )}
            >
              {p.label}
            </button>
          ))}
        </div>
      </div>

      {q.isLoading && !q.data ? (
        <LoadingState label="Loading volatility dashboard…" />
      ) : q.isError ? (
        <ErrorState
          message="Could not load volatility dashboard."
          onRetry={() => q.refetch()}
        />
      ) : q.data ? (
        <>
          {/* Stats strip — 30D RVOL · 90D RVOL · BTC snapshot */}
          <VolStatsStrip
            rvol30={q.data.rvol_30d_stats}
            rvol90={q.data.rvol_90d_stats}
            btc={q.data.btc}
          />

          {/* IVOL Premium */}
          <Card className="overflow-hidden">
            <CardHeader
              title={
                <span>
                  <span className="text-brand">₿</span>TC: IVOL Premium
                </span>
              }
              subtitle="(IVOL / RVOL − 1) — positive = options expensive vs realized"
            />
            <div className="px-5 pb-5">
              <IvolPremiumChart data={q.data.series.ivol_premium} />
            </div>
          </Card>
        </>
      ) : null}
    </div>
  );
}
