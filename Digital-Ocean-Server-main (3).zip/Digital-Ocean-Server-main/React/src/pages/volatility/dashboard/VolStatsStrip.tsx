import { cn } from "@/lib/utils";
import type { VolBtcSnapshot, VolStatsBlock } from "@/types/vol";

function fmtNum(v: number | null | undefined, digits = 2): string {
  if (v == null || !Number.isFinite(v)) return "-";
  return v.toFixed(digits);
}

function fmtPct(v: number | null | undefined): string {
  if (v == null || !Number.isFinite(v)) return "-";
  return `${Math.round(v)}%`;
}

function fmtPremium(v: number | null | undefined): string {
  if (v == null || !Number.isFinite(v)) return "-";
  return `${v >= 0 ? "+" : ""}${v.toFixed(1)}%`;
}

/** Tint percentile: lower = cool blue, higher = warm red. */
function percentileTint(v: number | null | undefined): string {
  if (v == null || !Number.isFinite(v)) return "text-muted";
  if (v >= 80) return "bg-negative/25 text-negative font-semibold";
  if (v >= 60) return "bg-negative/15 text-negative";
  if (v >= 40) return "text-fg";
  if (v >= 20) return "bg-positive/15 text-positive";
  return "bg-positive/25 text-positive font-semibold";
}

/** Premium tint: large positive = rich (red), negative = crushed (green). */
function premiumTint(v: number | null | undefined): string {
  if (v == null || !Number.isFinite(v)) return "bg-muted/10 text-muted";
  if (v >= 50) return "bg-negative/25 text-negative font-semibold";
  if (v >= 20) return "bg-negative/15 text-negative";
  if (v >= 0)  return "text-fg";
  return "bg-positive/20 text-positive";
}

interface VolStatsCardProps {
  title: string;
  stats: VolStatsBlock;
  accent?: "neutral" | "muted";
}

function VolStatsCard({ title, stats, accent = "neutral" }: VolStatsCardProps) {
  return (
    <div
      className={cn(
        "card flex flex-col gap-3 p-4",
        accent === "muted" && "bg-surface-2/40",
      )}
    >
      <div className="flex items-baseline justify-between">
        <span className="text-xs font-semibold uppercase tracking-wider text-fg">
          {title}
        </span>
        {stats.asof ? (
          <span className="text-[10px] font-mono text-muted">{stats.asof}</span>
        ) : null}
      </div>
      <div className="grid grid-cols-3 gap-2">
        <div className="rounded-md bg-surface px-2 py-1.5">
          <div className="text-[10px] font-medium uppercase tracking-wider text-muted">Value</div>
          <div className="mt-1 text-lg font-semibold tabular-nums text-fg">
            {fmtNum(stats.latest)}
          </div>
        </div>
        <div className={cn("rounded-md px-2 py-1.5", percentileTint(stats.pct_3m))}>
          <div className="text-[10px] font-medium uppercase tracking-wider opacity-80">3M Pct</div>
          <div className="mt-1 text-lg font-semibold tabular-nums">{fmtPct(stats.pct_3m)}</div>
        </div>
        <div className={cn("rounded-md px-2 py-1.5", percentileTint(stats.pct_1y))}>
          <div className="text-[10px] font-medium uppercase tracking-wider opacity-80">1Y Pct</div>
          <div className="mt-1 text-lg font-semibold tabular-nums">{fmtPct(stats.pct_1y)}</div>
        </div>
      </div>
      <div className="flex items-center justify-between text-[10px] text-muted">
        <span>
          1Y range{" "}
          <span className="font-mono text-fg">
            {fmtNum(stats.min_1y)} … {fmtNum(stats.max_1y)}
          </span>
        </span>
        <span>
          μ {fmtNum(stats.mean_1y)} · med {fmtNum(stats.median_1y)}
        </span>
      </div>
    </div>
  );
}

interface BtcSnapshotCardProps {
  title: string;
  snapshot: VolBtcSnapshot;
}

function BtcSnapshotCard({ title, snapshot }: BtcSnapshotCardProps) {
  return (
    <div className="card flex flex-col gap-3 p-4">
      <span className="text-xs font-semibold uppercase tracking-wider text-fg">
        {title}
      </span>
      <div className="grid grid-cols-3 gap-2">
        <div className="rounded-md bg-surface-2/60 px-2 py-1.5">
          <div className="text-[10px] font-medium uppercase tracking-wider text-muted">
            30D Realized
          </div>
          <div className="mt-1 text-lg font-semibold tabular-nums text-fg">
            {fmtNum(snapshot.rvol_30d)}
          </div>
        </div>
        <div className="rounded-md bg-surface-2/60 px-2 py-1.5">
          <div className="text-[10px] font-medium uppercase tracking-wider text-muted">
            30D Implied (DVOL)
          </div>
          <div className="mt-1 text-lg font-semibold tabular-nums text-fg">
            {fmtNum(snapshot.ivol_30d)}
          </div>
        </div>
        <div className={cn("rounded-md px-2 py-1.5", premiumTint(snapshot.ivol_premium_pct))}>
          <div className="text-[10px] font-medium uppercase tracking-wider opacity-80">
            IVOL Premium
          </div>
          <div className="mt-1 text-lg font-bold tabular-nums">
            {fmtPremium(snapshot.ivol_premium_pct)}
          </div>
        </div>
      </div>
    </div>
  );
}

export function VolStatsStrip({
  rvol30,
  rvol90,
  btc,
}: {
  rvol30: VolStatsBlock;
  rvol90: VolStatsBlock;
  btc: VolBtcSnapshot;
}) {
  return (
    <div className="grid gap-3 lg:grid-cols-3">
      <VolStatsCard title="30D Realized Vol (TTM)" stats={rvol30} />
      <VolStatsCard title="90D Realized Vol (TTM)" stats={rvol90} accent="muted" />
      <BtcSnapshotCard title="BTC" snapshot={btc} />
    </div>
  );
}
