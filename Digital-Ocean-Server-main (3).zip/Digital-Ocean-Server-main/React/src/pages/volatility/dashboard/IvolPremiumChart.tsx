import {
  Area,
  CartesianGrid,
  ComposedChart,
  ReferenceLine,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { useTheme } from "@/theme/ThemeProvider";

interface Point {
  date: string;
  value: number;
}

function fmtShort(iso: string): string {
  const [y, m] = iso.split("-");
  const months = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
  return `${months[Number(m) - 1]}-${y.slice(2)}`;
}

function fmtTooltipDate(iso: string): string {
  const [y, m, d] = iso.split("-");
  const months = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
  return `${months[Number(m) - 1]} ${Number(d)}, ${y}`;
}

export function IvolPremiumChart({
  data,
  height = 200,
}: {
  data: Point[];
  height?: number;
}) {
  const { theme } = useTheme();
  const dark = theme === "dark";
  const axis = dark ? "#8b949e" : "#6b7280";
  const grid = dark ? "rgba(139,148,161,0.15)" : "rgba(107,114,128,0.18)";
  const line = dark ? "#38bdf8" : "#0284c7";

  const monthTicks = (() => {
    const seen = new Set<string>();
    const out: string[] = [];
    for (const d of data) {
      const k = d.date.slice(0, 7);
      if (!seen.has(k)) { seen.add(k); out.push(d.date); }
    }
    return out;
  })();

  const latest = data.length ? data[data.length - 1].value : null;

  return (
    <div style={{ width: "100%", height }}>
      <ResponsiveContainer>
        <ComposedChart data={data} margin={{ top: 8, right: 56, bottom: 4, left: 4 }}>
          <CartesianGrid stroke={grid} vertical={false} />
          <XAxis
            dataKey="date"
            ticks={monthTicks}
            tickFormatter={fmtShort}
            tick={{ fill: axis, fontSize: 11 }}
            stroke={grid}
          />
          <YAxis
            tick={{ fill: axis, fontSize: 11 }}
            stroke={grid}
            width={48}
            tickFormatter={(v) => `${Math.round(Number(v))}%`}
          />
          <ReferenceLine y={0} stroke={axis} strokeOpacity={0.7} />
          {latest != null ? (
            <ReferenceLine
              y={latest}
              stroke={line}
              strokeOpacity={0.35}
              strokeDasharray="3 3"
              label={{
                value: `${latest.toFixed(1)}%`,
                fill: line,
                fontSize: 11,
                fontWeight: 600,
                position: "right",
              }}
            />
          ) : null}
          <Tooltip
            cursor={{ stroke: axis, strokeOpacity: 0.4 }}
            content={({ active, payload }) => {
              if (!active || !payload?.length) return null;
              const p = payload[0]?.payload as Point | undefined;
              if (!p) return null;
              const v = Number(p.value);
              return (
                <div
                  style={{
                    background: dark ? "#161b22" : "#ffffff",
                    border: `1px solid ${grid}`,
                    borderRadius: 8,
                    fontSize: 12,
                    padding: "8px 10px",
                    color: dark ? "#e6e9ef" : "#111827",
                  }}
                >
                  <div style={{ color: axis, marginBottom: 4 }}>
                    {fmtTooltipDate(p.date)}
                  </div>
                  <div style={{ color: line, fontWeight: 700, fontSize: 14 }}>
                    {v >= 0 ? "+" : ""}{v.toFixed(1)}%
                  </div>
                </div>
              );
            }}
          />
          <Area
            type="monotone"
            dataKey="value"
            stroke={line}
            strokeWidth={2}
            fill={line}
            fillOpacity={0.18}
            isAnimationActive={false}
            connectNulls
          />
        </ComposedChart>
      </ResponsiveContainer>
    </div>
  );
}
