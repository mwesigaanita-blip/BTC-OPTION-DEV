import { useEffect, useMemo, useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { AlertTriangle, Calculator, Play, Plus, RefreshCw, Trash2, Unlock } from "lucide-react";
import {
  fetchPositionsAndChain,
  fetchQuote,
  findOption,
  priceOption,
  runSimulation,
  type Adjustment,
  type AdjustmentAction,
  type CurrencyResult,
  type InstrumentQuote,
  type NewTrade,
  type SimPosition,
  type SimulationResult,
} from "@/api/mmIm";
import { PageHeader } from "@/components/shared/PageHeader";
import { LoadingState } from "@/components/shared/LoadingState";
import { ErrorState } from "@/components/shared/ErrorState";
import { MetricCard } from "@/components/shared/MetricCard";
import { Card, CardBody, CardHeader } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { Input } from "@/components/ui/Input";
import { Badge } from "@/components/ui/Badge";
import {
  Table,
  Tbody,
  Td,
  Th,
  Thead,
  Tr,
} from "@/components/ui/Table";
import { cn } from "@/lib/utils";
import { bsPriceUsd, yearsUntil } from "@/lib/bs";

// ---------------------------------------------------------------------------
// Local form types
// ---------------------------------------------------------------------------

interface AdjForm {
  instrument_name: string;
  action: AdjustmentAction;
  amount: string; // local string for the input - parsed on submit
}

interface OptionTradeForm {
  id: string;
  expiry_ts: number | "";
  strike: number | "";
  option_type: "call" | "put";
  side: "long" | "short";
  amount: string;
  // resolved instrument + quote, fetched lazily
  resolved_name?: string | null;
  quote?: InstrumentQuote | null;
  // IV-based recalc state. iv_input is the user-editable IV (% / vol pts);
  // when locked, recalc_price_btc / recalc_price_usd are the BS-derived prices
  // and the live-quote refetch is paused. recalc_iv_pct records the IV that
  // produced the locked price.
  iv_input: string;
  locked: boolean;
  recalc_price_btc?: number | null;
  recalc_price_usd?: number | null;
  recalc_iv_pct?: number | null;
  recalc_spot?: number | null;
}

interface PerpTradeForm {
  id: string;
  side: "long" | "short";
  amount: string;
}

const CURRENCY_ORDER = ["BTC", "USDT", "USDC"] as const;

interface Scenario {
  iv_shift_pp: number;     // vol-point shift added to each option's mark_iv
  spot_override: string;   // USD or "" for live
  days_forward: number;    // days to subtract from each option's t_to_expiry
}

const DEFAULT_SCENARIO: Scenario = { iv_shift_pp: 0, spot_override: "", days_forward: 0 };

interface BsResult {
  bs_btc: number | null;
  bs_usd: number | null;
  scenario_iv_pct: number | null;
  scenario_spot: number;
  scenario_t_years: number;
}

/** Recalculate an option's Black-Scholes mark under the user's scenario.
 * Returns nulls when the option metadata isn't available (futures/perps
 * always return nulls). Pure: same inputs → same outputs, instant. */
function bsForPosition(p: SimPosition, sc: Scenario, liveSpot: number): BsResult {
  const empty: BsResult = {
    bs_btc: null,
    bs_usd: null,
    scenario_iv_pct: null,
    scenario_spot: 0,
    scenario_t_years: 0,
  };
  if (
    !p.option_type ||
    !p.strike ||
    !p.expiration_timestamp ||
    !p.mark_iv ||
    !(p.mark_iv > 0)
  )
    return empty;

  const spotOverrideNum = Number(sc.spot_override);
  const spot =
    sc.spot_override && Number.isFinite(spotOverrideNum) && spotOverrideNum > 0
      ? spotOverrideNum
      : liveSpot;
  if (!(spot > 0)) return empty;

  const ivPct = Number(p.mark_iv) + Number(sc.iv_shift_pp || 0);
  if (!(ivPct > 0)) return { ...empty, scenario_spot: spot };
  const tBase = yearsUntil(p.expiration_timestamp);
  const tYears = Math.max(0, tBase - Number(sc.days_forward || 0) / 365.25);
  const usd = bsPriceUsd({
    spot,
    strike: p.strike,
    tYears,
    iv: ivPct / 100,
    optionType: p.option_type,
  });
  const btc = spot > 0 ? usd / spot : 0;
  return {
    bs_btc: btc,
    bs_usd: usd,
    scenario_iv_pct: ivPct,
    scenario_spot: spot,
    scenario_t_years: tYears,
  };
}

function fmtPct(v: unknown, digits = 2): string {
  const n = Number(v);
  if (!Number.isFinite(n)) return "-";
  return `${n.toFixed(digits)}%`;
}

function fmtNum(v: unknown, digits = 4): string {
  const n = Number(v);
  if (!Number.isFinite(n)) return "-";
  return n.toLocaleString("en-US", {
    minimumFractionDigits: digits,
    maximumFractionDigits: digits,
  });
}

function expiryLabel(ts: number): string {
  try {
    const d = new Date(ts);
    if (!Number.isFinite(d.getTime())) return String(ts);
    const yyyy = d.getUTCFullYear();
    const mm = String(d.getUTCMonth() + 1).padStart(2, "0");
    const dd = String(d.getUTCDate()).padStart(2, "0");
    const hh = String(d.getUTCHours()).padStart(2, "0");
    const mi = String(d.getUTCMinutes()).padStart(2, "0");
    return `${yyyy}-${mm}-${dd} ${hh}:${mi} UTC`;
  } catch {
    return String(ts);
  }
}

// ---------------------------------------------------------------------------
// Page
// ---------------------------------------------------------------------------

export function MmImSimulatorPage() {
  const dataQ = useQuery({
    queryKey: ["mm-im-positions"],
    queryFn: fetchPositionsAndChain,
    enabled: false, // user clicks "Load Current Positions"
    retry: false,
  });

  const positions: SimPosition[] = dataQ.data?.positions ?? [];
  const expiries = dataQ.data?.option_chain?.expiries ?? [];

  // ---- Scenario inputs (drive BS recalculation of EXISTING option marks) ----
  const [scenario, setScenario] = useState<Scenario>(DEFAULT_SCENARIO);

  // Live BTC spot used as the BS default when no spot override is entered.
  // First option position's index_price is fine - they all share it.
  const liveSpot = useMemo(() => {
    for (const p of positions) {
      if (p.index_price && Number(p.index_price) > 0) return Number(p.index_price);
    }
    return 0;
  }, [positions]);

  // ---- Adjustments state ----
  const [adjustments, setAdjustments] = useState<Record<string, AdjForm>>({});

  // Reset adjustments whenever positions reload.
  useEffect(() => {
    if (!dataQ.data) return;
    const out: Record<string, AdjForm> = {};
    for (const p of dataQ.data.positions) {
      out[p.instrument_name] = {
        instrument_name: p.instrument_name,
        action: "no change",
        amount: "0",
      };
    }
    setAdjustments(out);
  }, [dataQ.data]);

  // ---- New trades state ----
  const [optionTrades, setOptionTrades] = useState<OptionTradeForm[]>([]);
  const [perpTrades, setPerpTrades] = useState<PerpTradeForm[]>([]);

  // ---- Simulation state ----
  const simMut = useMutation({
    mutationFn: (body: { adjustments: Adjustment[]; new_trades: NewTrade[] }) =>
      runSimulation(body.adjustments, body.new_trades),
  });

  // Derived: cleaned adjustments + new_trades for submit, plus validation errors
  const { cleanAdjustments, cleanTrades, errors } = useMemo(() => {
    const errs: string[] = [];
    const adjOut: Adjustment[] = [];
    for (const p of positions) {
      const a = adjustments[p.instrument_name];
      if (!a) continue;
      const amt = Number(a.amount);
      if (a.action === "no change" || !Number.isFinite(amt) || amt <= 0) continue;
      if (a.action === "decrease" && amt > Math.abs(Number(p.size))) {
        errs.push(
          `Adjustment error for ${p.instrument_name}: decrease amount ${amt} exceeds current size ${p.size}.`,
        );
        continue;
      }
      adjOut.push({
        instrument_name: p.instrument_name,
        action: a.action,
        amount: amt,
      });
    }
    const tradesOut: NewTrade[] = [];
    for (const o of optionTrades) {
      const amt = Number(o.amount);
      if (!Number.isFinite(amt) || amt <= 0) continue;
      if (!o.resolved_name) {
        errs.push(`Option trade ${o.id}: instrument not resolved yet.`);
        continue;
      }
      tradesOut.push({
        instrument_name: o.resolved_name,
        side: o.side,
        amount: amt,
        entry_price: o.locked && o.recalc_price_btc != null ? o.recalc_price_btc : null,
      });
    }
    for (const t of perpTrades) {
      const amt = Number(t.amount);
      if (!Number.isFinite(amt) || amt <= 0) continue;
      tradesOut.push({
        instrument_name: "BTC-PERPETUAL",
        side: t.side,
        amount: amt,
      });
    }
    return { cleanAdjustments: adjOut, cleanTrades: tradesOut, errors: errs };
  }, [positions, adjustments, optionTrades, perpTrades]);

  const result: SimulationResult | null = simMut.data ?? null;
  const simErr =
    (simMut.error as { response?: { data?: { detail?: string } }; message?: string } | null)
      ?.response?.data?.detail ??
    (simMut.error as Error | null)?.message ??
    null;

  return (
    <div className="space-y-5 animate-fade-in">
      <PageHeader
        title="MM / IM Simulator"
        description="Test how IM% and MM% may change after reducing/increasing positions or adding new simulated trades."
        actions={
          <Button
            variant="secondary"
            size="sm"
            onClick={() => dataQ.refetch()}
            disabled={dataQ.isFetching}
          >
            <RefreshCw className={cn("h-3.5 w-3.5", dataQ.isFetching && "animate-spin")} />
            {dataQ.data ? "Reload Positions" : "Load Current Positions"}
          </Button>
        }
      />

      {/* Load errors */}
      {dataQ.error ? (
        <ErrorState
          message={(dataQ.error as Error).message ?? "Failed to load positions"}
          onRetry={() => dataQ.refetch()}
        />
      ) : null}

      {dataQ.isFetching && !dataQ.data ? (
        <LoadingState label="Loading positions and option chain..." />
      ) : null}

      {/* Scenario controls - drive BS recalc of existing option marks */}
      {dataQ.data && positions.some((p) => p.kind === "option") ? (
        <ScenarioControlsCard
          scenario={scenario}
          onChange={setScenario}
          liveSpot={liveSpot}
        />
      ) : null}

      {/* Section 1 - Current Positions */}
      <Card>
        <CardHeader
          title="1. Current Positions"
          subtitle={
            positions.some((p) => p.kind === "option")
              ? "BS Mark column recalculates instantly from the Scenario Controls above."
              : undefined
          }
        />
        <CardBody className="pt-0">
          {!dataQ.data ? (
            <div className="rounded-lg border border-border bg-surface-2/30 py-6 text-center text-sm text-muted">
              Click <span className="font-semibold">Load Current Positions</span> to begin.
            </div>
          ) : positions.length === 0 ? (
            <div className="text-xs text-muted">No open positions.</div>
          ) : (
            <PositionsTable
              positions={positions}
              scenario={scenario}
              liveSpot={liveSpot}
            />
          )}
        </CardBody>
      </Card>

      {/* Section 2 - Adjustments */}
      <Card>
        <CardHeader
          title="2. Existing Position Adjustments"
          subtitle="Choose No Change / Decrease / Increase for any current position."
        />
        <CardBody className="space-y-3 pt-0">
          {positions.length === 0 ? (
            <div className="text-xs text-muted">No current positions loaded yet.</div>
          ) : (
            positions.map((p) => {
              const a =
                adjustments[p.instrument_name] ?? {
                  instrument_name: p.instrument_name,
                  action: "no change" as AdjustmentAction,
                  amount: "0",
                };
              return (
                <div
                  key={p.instrument_name}
                  className="grid grid-cols-1 gap-3 rounded-lg border border-border bg-surface-2/40 p-3 md:grid-cols-[2fr_1fr_1fr_1fr_1fr]"
                >
                  <div>
                    <div className="font-mono text-sm font-semibold text-fg">
                      {p.instrument_name}
                    </div>
                    <div className="text-xs text-muted">
                      {p.currency} · {p.kind} · {p.direction} · size {fmtNum(p.size, 4)}
                    </div>
                  </div>
                  <div>
                    <label className="block text-[0.7rem] text-muted">Action</label>
                    <select
                      className="h-10 w-full rounded-md border border-border bg-surface-2 px-2 text-sm"
                      value={a.action}
                      onChange={(e) =>
                        setAdjustments((prev) => ({
                          ...prev,
                          [p.instrument_name]: {
                            ...a,
                            action: e.target.value as AdjustmentAction,
                          },
                        }))
                      }
                    >
                      <option value="no change">no change</option>
                      <option value="decrease">decrease</option>
                      <option value="increase">increase</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-[0.7rem] text-muted">Amount</label>
                    <Input
                      type="number"
                      min={0}
                      step={0.01}
                      value={a.amount}
                      onChange={(e) =>
                        setAdjustments((prev) => ({
                          ...prev,
                          [p.instrument_name]: { ...a, amount: e.target.value },
                        }))
                      }
                      disabled={a.action === "no change"}
                    />
                  </div>
                  <div>
                    <div className="text-[0.7rem] text-muted">Mark</div>
                    <div className="text-sm font-semibold tabular-nums">
                      {fmtNum(p.mark_price, 4)}
                    </div>
                  </div>
                  <div>
                    <div className="text-[0.7rem] text-muted">Index</div>
                    <div className="text-sm font-semibold tabular-nums">
                      {fmtNum(p.index_price, 2)}
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </CardBody>
      </Card>

      {/* Section 3 - New trades */}
      <Card>
        <CardHeader title="3. Add New Simulated Trades" />
        <CardBody className="space-y-4 pt-0">
          {/* 3A - Options */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="text-sm font-semibold text-fg">3A. New Option Trades</h4>
              <Button
                variant="secondary"
                size="sm"
                onClick={() =>
                  setOptionTrades((arr) => [
                    ...arr,
                    {
                      id: crypto.randomUUID(),
                      expiry_ts: expiries[0]?.expiration_timestamp ?? "",
                      strike: expiries[0]?.strikes?.[0] ?? "",
                      option_type: "call",
                      side: "long",
                      amount: "0",
                      iv_input: "",
                      locked: false,
                    },
                  ])
                }
                disabled={!dataQ.data || expiries.length === 0}
              >
                <Plus className="h-3.5 w-3.5" />
                Add Option Trade
              </Button>
            </div>
            {!dataQ.data ? (
              <div className="text-xs text-muted">
                Load positions first to populate the BTC option chain.
              </div>
            ) : optionTrades.length === 0 ? (
              <div className="text-xs text-muted">No option trades added.</div>
            ) : (
              optionTrades.map((o) => (
                <OptionTradeRow
                  key={o.id}
                  trade={o}
                  expiries={expiries}
                  onChange={(patch) =>
                    setOptionTrades((arr) =>
                      arr.map((t) => (t.id === o.id ? { ...t, ...patch } : t)),
                    )
                  }
                  onRemove={() =>
                    setOptionTrades((arr) => arr.filter((t) => t.id !== o.id))
                  }
                />
              ))
            )}
          </div>

          {/* 3B - Perpetuals */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="text-sm font-semibold text-fg">3B. New Perpetual Trades</h4>
              <Button
                variant="secondary"
                size="sm"
                onClick={() =>
                  setPerpTrades((arr) => [
                    ...arr,
                    { id: crypto.randomUUID(), side: "long", amount: "0" },
                  ])
                }
              >
                <Plus className="h-3.5 w-3.5" />
                Add Perpetual Trade
              </Button>
            </div>
            {perpTrades.length === 0 ? (
              <div className="text-xs text-muted">No perpetual trades added.</div>
            ) : (
              perpTrades.map((t) => (
                <PerpTradeRow
                  key={t.id}
                  trade={t}
                  onChange={(patch) =>
                    setPerpTrades((arr) =>
                      arr.map((x) => (x.id === t.id ? { ...x, ...patch } : x)),
                    )
                  }
                  onRemove={() =>
                    setPerpTrades((arr) => arr.filter((x) => x.id !== t.id))
                  }
                />
              ))
            )}
          </div>
        </CardBody>
      </Card>

      {/* Section 4 - Preview */}
      <Card>
        <CardHeader title="4. Simulation Preview" />
        <CardBody className="grid grid-cols-1 gap-4 pt-0 md:grid-cols-2">
          <div>
            <div className="mb-1 text-xs font-semibold text-fg">Selected Adjustments</div>
            {cleanAdjustments.length === 0 ? (
              <div className="text-xs text-muted">No position adjustments selected.</div>
            ) : (
              <Table>
                <Thead>
                  <Tr>
                    <Th>Instrument</Th>
                    <Th>Action</Th>
                    <Th className="text-right">Amount</Th>
                  </Tr>
                </Thead>
                <Tbody>
                  {cleanAdjustments.map((a) => (
                    <Tr key={a.instrument_name}>
                      <Td className="font-mono text-xs">{a.instrument_name}</Td>
                      <Td>{a.action}</Td>
                      <Td className="text-right tabular-nums">{a.amount}</Td>
                    </Tr>
                  ))}
                </Tbody>
              </Table>
            )}
          </div>
          <div>
            <div className="mb-1 text-xs font-semibold text-fg">Selected New Trades</div>
            {cleanTrades.length === 0 ? (
              <div className="text-xs text-muted">No new trades selected.</div>
            ) : (
              <Table>
                <Thead>
                  <Tr>
                    <Th>Instrument</Th>
                    <Th>Side</Th>
                    <Th className="text-right">Amount</Th>
                  </Tr>
                </Thead>
                <Tbody>
                  {cleanTrades.map((t, i) => (
                    <Tr key={`${t.instrument_name}-${i}`}>
                      <Td className="font-mono text-xs">{t.instrument_name}</Td>
                      <Td>
                        <Badge tone={t.side === "long" ? "positive" : "negative"}>
                          {t.side}
                        </Badge>
                      </Td>
                      <Td className="text-right tabular-nums">{t.amount}</Td>
                    </Tr>
                  ))}
                </Tbody>
              </Table>
            )}
          </div>
        </CardBody>
        {errors.length > 0 ? (
          <CardBody className="pt-0">
            <div className="flex flex-col gap-1 rounded-lg border border-negative/40 bg-negative/10 px-3 py-2 text-xs text-negative">
              {errors.map((e, i) => (
                <div key={i} className="flex items-start gap-2">
                  <AlertTriangle className="mt-0.5 h-3.5 w-3.5 shrink-0" /> {e}
                </div>
              ))}
            </div>
          </CardBody>
        ) : null}
      </Card>

      {/* Section 5 - Run */}
      <Card>
        <CardHeader title="5. Run Simulation" />
        <CardBody className="pt-0">
          <Button
            onClick={() =>
              simMut.mutate({
                adjustments: cleanAdjustments,
                new_trades: cleanTrades,
              })
            }
            disabled={
              simMut.isPending ||
              errors.length > 0 ||
              !dataQ.data ||
              (cleanAdjustments.length === 0 && cleanTrades.length === 0)
            }
            className="w-full"
          >
            <Play className={cn("h-4 w-4", simMut.isPending && "animate-pulse")} />
            {simMut.isPending ? "Running..." : "Run Portfolio Simulation"}
          </Button>
          {simErr ? <div className="mt-2 text-xs text-negative">{simErr}</div> : null}
        </CardBody>
      </Card>

      {/* Section 6 - Results */}
      <ResultsSection result={result} />

      {/* Section 7 - Raw JSON */}
      <RawJsonSection result={result} />
    </div>
  );
}

// ---------------------------------------------------------------------------
// Subcomponents
// ---------------------------------------------------------------------------

function PositionsTable({
  positions,
  scenario,
  liveSpot,
}: {
  positions: SimPosition[];
  scenario: Scenario;
  liveSpot: number;
}) {
  return (
    <Table>
      <Thead>
        <Tr>
          <Th>Currency</Th>
          <Th>Instrument</Th>
          <Th>Kind</Th>
          <Th>Direction</Th>
          <Th className="text-right">Size</Th>
          <Th className="text-right">Live Mark</Th>
          <Th className="text-right">BS Mark</Th>
          <Th className="text-right">Δ vs Live</Th>
          <Th className="text-right">Index</Th>
          <Th className="text-right">IV (live)</Th>
          <Th className="text-right">Delta</Th>
          <Th className="text-right">Gamma</Th>
          <Th className="text-right">Vega</Th>
          <Th className="text-right">Theta</Th>
        </Tr>
      </Thead>
      <Tbody>
        {positions.map((p) => {
          const bs = bsForPosition(p, scenario, liveSpot);
          const liveBtc =
            p.mark_price != null && Number.isFinite(Number(p.mark_price))
              ? Number(p.mark_price)
              : null;
          const dBtc =
            liveBtc != null && bs.bs_btc != null ? bs.bs_btc - liveBtc : null;
          const dPct =
            liveBtc != null && liveBtc !== 0 && dBtc != null
              ? (dBtc / liveBtc) * 100
              : null;
          const dTone =
            dBtc == null || dBtc === 0
              ? ""
              : dBtc > 0
                ? "text-positive"
                : "text-negative";
          return (
            <Tr key={p.instrument_name}>
              <Td>{p.currency}</Td>
              <Td className="font-mono text-xs">{p.instrument_name}</Td>
              <Td>{p.kind}</Td>
              <Td>
                <Badge tone={p.direction === "buy" ? "positive" : "negative"}>
                  {p.direction}
                </Badge>
              </Td>
              <Td className="text-right tabular-nums">{fmtNum(p.size, 4)}</Td>
              <Td className="text-right tabular-nums">{fmtNum(p.mark_price, 4)}</Td>
              <Td className="text-right tabular-nums">
                {bs.bs_btc != null ? bs.bs_btc.toFixed(6) : "-"}
              </Td>
              <Td className={cn("text-right tabular-nums", dTone)}>
                {dBtc != null
                  ? `${dBtc >= 0 ? "+" : ""}${dBtc.toFixed(6)}`
                  : "-"}
                {dPct != null ? (
                  <span className="ml-1 text-[0.7rem]">
                    ({dPct >= 0 ? "+" : ""}
                    {dPct.toFixed(1)}%)
                  </span>
                ) : null}
              </Td>
              <Td className="text-right tabular-nums">{fmtNum(p.index_price, 2)}</Td>
              <Td className="text-right tabular-nums">
                {p.mark_iv != null ? `${Number(p.mark_iv).toFixed(2)}` : "-"}
              </Td>
              <Td className="text-right tabular-nums">{fmtNum(p.delta, 4)}</Td>
              <Td className="text-right tabular-nums">{fmtNum(p.gamma, 6)}</Td>
              <Td className="text-right tabular-nums">{fmtNum(p.vega, 2)}</Td>
              <Td className="text-right tabular-nums">{fmtNum(p.theta, 2)}</Td>
            </Tr>
          );
        })}
      </Tbody>
    </Table>
  );
}

function ScenarioControlsCard({
  scenario,
  onChange,
  liveSpot,
}: {
  scenario: Scenario;
  onChange: (s: Scenario) => void;
  liveSpot: number;
}) {
  const dirty =
    scenario.iv_shift_pp !== 0 ||
    scenario.days_forward !== 0 ||
    !!scenario.spot_override;
  return (
    <Card>
      <CardHeader
        title="Scenario Controls"
        subtitle="Recompute each existing option's mark price via Black-Scholes under these inputs. Futures/perps are unaffected."
        action={
          <Button
            size="sm"
            variant="secondary"
            onClick={() => onChange(DEFAULT_SCENARIO)}
            disabled={!dirty}
          >
            <RefreshCw className="h-3.5 w-3.5" /> Reset
          </Button>
        }
      />
      <CardBody className="grid grid-cols-1 gap-3 pt-0 md:grid-cols-3">
        <div>
          <label className="block text-xs font-medium text-muted">
            IV shift (vol pts)
          </label>
          <Input
            type="number"
            step={1}
            value={scenario.iv_shift_pp}
            onChange={(e) =>
              onChange({ ...scenario, iv_shift_pp: Number(e.target.value) || 0 })
            }
          />
          <div className="mt-1 text-[0.7rem] text-muted">
            Added to each option's live mark IV. e.g. +10 pushes 60 → 70.
          </div>
        </div>
        <div>
          <label className="block text-xs font-medium text-muted">
            Spot override (USD)
          </label>
          <Input
            type="number"
            min={0}
            step={100}
            value={scenario.spot_override}
            placeholder={liveSpot > 0 ? `live ${liveSpot.toFixed(0)}` : "live"}
            onChange={(e) =>
              onChange({ ...scenario, spot_override: e.target.value })
            }
          />
          <div className="mt-1 text-[0.7rem] text-muted">
            Empty = use the live BTC index. Set to model "BTC at X".
          </div>
        </div>
        <div>
          <label className="block text-xs font-medium text-muted">
            Days forward
          </label>
          <Input
            type="number"
            min={0}
            step={1}
            value={scenario.days_forward}
            onChange={(e) =>
              onChange({ ...scenario, days_forward: Number(e.target.value) || 0 })
            }
          />
          <div className="mt-1 text-[0.7rem] text-muted">
            Subtracts from each option's time-to-expiry (theta decay).
          </div>
        </div>
      </CardBody>
    </Card>
  );
}

function OptionTradeRow({
  trade,
  expiries,
  onChange,
  onRemove,
}: {
  trade: OptionTradeForm;
  expiries: { expiration_timestamp: number; strikes: number[] }[];
  onChange: (patch: Partial<OptionTradeForm>) => void;
  onRemove: () => void;
}) {
  const selectedExpiry = expiries.find(
    (e) => e.expiration_timestamp === trade.expiry_ts,
  );
  const strikes = selectedExpiry?.strikes ?? [];

  const [recalcing, setRecalcing] = useState(false);
  const [recalcErr, setRecalcErr] = useState<string | null>(null);

  // Resolve the Deribit instrument + fetch its quote when the
  // (expiry, strike, type) tuple is complete. Skipped while the row is
  // locked - the locked price + IV should not be overwritten by live data.
  useEffect(() => {
    if (trade.locked) return;
    let cancelled = false;
    async function go() {
      if (
        typeof trade.expiry_ts !== "number" ||
        typeof trade.strike !== "number" ||
        !trade.option_type
      ) {
        onChange({ resolved_name: null, quote: null });
        return;
      }
      try {
        const name = await findOption(
          trade.expiry_ts,
          trade.strike,
          trade.option_type,
        );
        if (cancelled) return;
        if (!name) {
          onChange({ resolved_name: null, quote: null });
          return;
        }
        const quote = await fetchQuote(name);
        if (cancelled) return;
        // Pre-fill iv_input from the live mark IV the first time we have one
        // for this resolved instrument and the user hasn't touched the field.
        const live_iv =
          quote.mark_iv != null && Number.isFinite(Number(quote.mark_iv))
            ? Number(quote.mark_iv)
            : null;
        const patch: Partial<OptionTradeForm> = { resolved_name: name, quote };
        if ((!trade.iv_input || trade.iv_input === "") && live_iv != null) {
          patch.iv_input = String(live_iv);
        }
        onChange(patch);
      } catch {
        if (!cancelled) onChange({ resolved_name: null, quote: null });
      }
    }
    go();
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [trade.expiry_ts, trade.strike, trade.option_type, trade.locked]);

  async function handleRecalc() {
    if (
      typeof trade.expiry_ts !== "number" ||
      typeof trade.strike !== "number"
    )
      return;
    const ivNum = Number(trade.iv_input);
    if (!Number.isFinite(ivNum) || ivNum <= 0) {
      setRecalcErr("Enter a positive IV (in vol points, e.g. 65).");
      return;
    }
    setRecalcErr(null);
    setRecalcing(true);
    try {
      const res = await priceOption(
        trade.expiry_ts,
        trade.strike,
        trade.option_type,
        ivNum,
      );
      onChange({
        locked: true,
        recalc_price_btc: res.btc_price,
        recalc_price_usd: res.usd_price,
        recalc_iv_pct: res.iv_pct,
        recalc_spot: res.spot,
      });
    } catch (e: any) {
      setRecalcErr(
        e?.response?.data?.detail ?? (e as Error)?.message ?? "Recalc failed",
      );
    } finally {
      setRecalcing(false);
    }
  }

  function handleUnlock() {
    setRecalcErr(null);
    onChange({
      locked: false,
      recalc_price_btc: null,
      recalc_price_usd: null,
      recalc_iv_pct: null,
      recalc_spot: null,
    });
  }

  return (
    <div className="space-y-2 rounded-lg border border-border bg-surface-2/40 p-3">
      <div className="grid grid-cols-2 gap-2 md:grid-cols-6">
        <div className="md:col-span-2">
          <label className="block text-[0.7rem] text-muted">Expiry</label>
          <select
            className="h-10 w-full rounded-md border border-border bg-surface-2 px-2 text-sm"
            value={trade.expiry_ts}
            disabled={trade.locked}
            onChange={(e) =>
              onChange({
                expiry_ts: e.target.value ? Number(e.target.value) : "",
                strike: "",
              })
            }
          >
            {expiries.map((ex) => (
              <option key={ex.expiration_timestamp} value={ex.expiration_timestamp}>
                {expiryLabel(ex.expiration_timestamp)}
              </option>
            ))}
          </select>
        </div>
        <div>
          <label className="block text-[0.7rem] text-muted">Strike</label>
          <select
            className="h-10 w-full rounded-md border border-border bg-surface-2 px-2 text-sm"
            value={trade.strike}
            disabled={trade.locked}
            onChange={(e) =>
              onChange({ strike: e.target.value ? Number(e.target.value) : "" })
            }
          >
            <option value="">-</option>
            {strikes.map((s) => (
              <option key={s} value={s}>
                {s}
              </option>
            ))}
          </select>
        </div>
        <div>
          <label className="block text-[0.7rem] text-muted">Type</label>
          <select
            className="h-10 w-full rounded-md border border-border bg-surface-2 px-2 text-sm"
            value={trade.option_type}
            disabled={trade.locked}
            onChange={(e) =>
              onChange({ option_type: e.target.value as "call" | "put" })
            }
          >
            <option value="call">call</option>
            <option value="put">put</option>
          </select>
        </div>
        <div>
          <label className="block text-[0.7rem] text-muted">Side</label>
          <select
            className="h-10 w-full rounded-md border border-border bg-surface-2 px-2 text-sm"
            value={trade.side}
            onChange={(e) => onChange({ side: e.target.value as "long" | "short" })}
          >
            <option value="long">long</option>
            <option value="short">short</option>
          </select>
        </div>
        <div>
          <label className="block text-[0.7rem] text-muted">Amount</label>
          <Input
            type="number"
            min={0}
            step={0.01}
            value={trade.amount}
            onChange={(e) => onChange({ amount: e.target.value })}
          />
        </div>
      </div>

      {/* Recalc strip */}
      <div className="space-y-2 rounded-md border border-border/60 bg-surface-2/30 p-2">
        <div className="flex flex-wrap items-end gap-2">
          <div className="min-w-[140px]">
            <label className="block text-[0.7rem] text-muted">
              IV (vol pts){" "}
              {trade.quote?.mark_iv != null ? (
                <span className="text-fg">
                  · live {Number(trade.quote.mark_iv).toFixed(2)}
                </span>
              ) : null}
            </label>
            <Input
              type="number"
              min={0}
              step={0.1}
              value={trade.iv_input}
              disabled={trade.locked}
              onChange={(e) => onChange({ iv_input: e.target.value })}
              placeholder={
                trade.quote?.mark_iv != null
                  ? `try a different value than ${Number(trade.quote.mark_iv).toFixed(2)}`
                  : ""
              }
            />
          </div>
          {!trade.locked ? (
            <Button size="sm" onClick={handleRecalc} disabled={recalcing || !trade.resolved_name}>
              <Calculator className={cn("h-3.5 w-3.5", recalcing && "animate-pulse")} />
              {recalcing ? "Recalculating..." : "Recalc mark & lock"}
            </Button>
          ) : (
            <Button size="sm" variant="secondary" onClick={handleUnlock}>
              <Unlock className="h-3.5 w-3.5" /> Unlock (resume live)
            </Button>
          )}
          {recalcErr ? (
            <span className="text-xs text-negative">{recalcErr}</span>
          ) : null}
        </div>

        {/* Live vs Recalc comparison block - only after locking */}
        {trade.locked && trade.recalc_price_btc != null ? (
          <RecalcCompare trade={trade} />
        ) : !trade.locked && trade.quote?.mark_iv != null ? (
          <div className="text-[0.7rem] text-muted">
            Tip: BS at the live IV ({Number(trade.quote.mark_iv).toFixed(2)}) will
            ≈ the live mark. Enter a different IV to see a different price.
          </div>
        ) : null}
      </div>

      <div className="flex flex-wrap items-center gap-3 text-xs text-muted">
        <div>
          Instrument:{" "}
          <span className="font-mono text-fg">
            {trade.resolved_name ?? "(unresolved)"}
          </span>
        </div>
        <QuotePills quote={trade.quote ?? null} />
        <Button variant="danger" size="sm" onClick={onRemove} className="ml-auto">
          <Trash2 className="h-3.5 w-3.5" /> Remove
        </Button>
      </div>
    </div>
  );
}

function RecalcCompare({ trade }: { trade: OptionTradeForm }) {
  const liveBtc =
    trade.quote?.mark_price != null && Number.isFinite(Number(trade.quote.mark_price))
      ? Number(trade.quote.mark_price)
      : null;
  const liveIv =
    trade.quote?.mark_iv != null && Number.isFinite(Number(trade.quote.mark_iv))
      ? Number(trade.quote.mark_iv)
      : null;
  const recalcBtc = trade.recalc_price_btc ?? null;
  const dBtc = liveBtc != null && recalcBtc != null ? recalcBtc - liveBtc : null;
  const dPct =
    liveBtc != null && liveBtc !== 0 && dBtc != null ? (dBtc / liveBtc) * 100 : null;
  const tone = dBtc == null || dBtc === 0 ? "" : dBtc > 0 ? "text-positive" : "text-negative";

  return (
    <div className="grid grid-cols-1 gap-2 rounded-md border border-warning/30 bg-warning/5 p-2 text-xs md:grid-cols-3">
      <div>
        <div className="text-[0.7rem] text-muted">Live (from Deribit quote)</div>
        <div className="font-mono">
          IV {liveIv != null ? liveIv.toFixed(2) : "-"} · mark{" "}
          {liveBtc != null ? liveBtc.toFixed(6) : "-"} BTC
        </div>
      </div>
      <div>
        <div className="text-[0.7rem] text-muted">Recalc (Black-Scholes, locked)</div>
        <div className="font-mono">
          IV {trade.recalc_iv_pct?.toFixed(2) ?? "-"} · mark{" "}
          {recalcBtc != null ? recalcBtc.toFixed(6) : "-"} BTC
        </div>
        <div className="text-[0.7rem] text-muted">
          ≈ $
          {trade.recalc_price_usd?.toLocaleString(undefined, {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2,
          })}{" "}
          · spot $
          {trade.recalc_spot?.toLocaleString()}
        </div>
      </div>
      <div>
        <div className="text-[0.7rem] text-muted">Δ vs live</div>
        <div className={cn("font-mono", tone)}>
          {dBtc != null
            ? `${dBtc >= 0 ? "+" : ""}${dBtc.toFixed(6)} BTC`
            : "-"}
          {dPct != null ? (
            <span className="ml-2 text-[0.7rem]">
              ({dPct >= 0 ? "+" : ""}
              {dPct.toFixed(2)}%)
            </span>
          ) : null}
        </div>
        <div className="text-[0.7rem] text-muted">
          This price flows into the simulation as <span className="font-mono">entry_price</span>.
        </div>
      </div>
    </div>
  );
}

function PerpTradeRow({
  trade,
  onChange,
  onRemove,
}: {
  trade: PerpTradeForm;
  onChange: (patch: Partial<PerpTradeForm>) => void;
  onRemove: () => void;
}) {
  const [quote, setQuote] = useState<InstrumentQuote | null>(null);
  useEffect(() => {
    let cancelled = false;
    fetchQuote("BTC-PERPETUAL")
      .then((q) => {
        if (!cancelled) setQuote(q);
      })
      .catch(() => {
        if (!cancelled) setQuote(null);
      });
    return () => {
      cancelled = true;
    };
  }, []);
  return (
    <div className="space-y-2 rounded-lg border border-border bg-surface-2/40 p-3">
      <div className="grid grid-cols-1 gap-2 md:grid-cols-4">
        <div>
          <label className="block text-[0.7rem] text-muted">Instrument</label>
          <Input value="BTC-PERPETUAL" disabled />
        </div>
        <div>
          <label className="block text-[0.7rem] text-muted">Side</label>
          <select
            className="h-10 w-full rounded-md border border-border bg-surface-2 px-2 text-sm"
            value={trade.side}
            onChange={(e) => onChange({ side: e.target.value as "long" | "short" })}
          >
            <option value="long">long</option>
            <option value="short">short</option>
          </select>
        </div>
        <div>
          <label className="block text-[0.7rem] text-muted">Amount (BTC units)</label>
          <Input
            type="number"
            min={0}
            step={0.01}
            value={trade.amount}
            onChange={(e) => onChange({ amount: e.target.value })}
          />
        </div>
        <div className="flex items-end justify-end">
          <Button variant="danger" size="sm" onClick={onRemove}>
            <Trash2 className="h-3.5 w-3.5" /> Remove
          </Button>
        </div>
      </div>
      <QuotePills quote={quote} />
    </div>
  );
}

function QuotePills({ quote }: { quote: InstrumentQuote | null }) {
  if (!quote) return <span className="text-xs text-muted">No quote.</span>;
  return (
    <div className="flex flex-wrap gap-2 text-xs">
      <Pill label="Bid" v={quote.bid_price} />
      <Pill label="Ask" v={quote.ask_price} />
      <Pill label="Mark" v={quote.mark_price} />
      <Pill label="Index" v={quote.index_price} digits={2} />
      <Pill label="IV" v={quote.mark_iv} digits={2} />
    </div>
  );
}

function Pill({
  label,
  v,
  digits = 4,
}: {
  label: string;
  v: unknown;
  digits?: number;
}) {
  return (
    <span className="rounded-md border border-border bg-surface-2 px-2 py-0.5">
      <span className="text-muted">{label}:</span>{" "}
      <span className="font-mono">{fmtNum(v, digits)}</span>
    </span>
  );
}

function ResultsSection({ result }: { result: SimulationResult | null }) {
  return (
    <Card>
      <CardHeader title="6. Results" />
      <CardBody className="pt-0">
        {!result ? (
          <div className="rounded-lg border border-border bg-surface-2/30 py-6 text-center text-sm text-muted">
            Run a simulation to see results.
          </div>
        ) : !result.ok ? (
          <div className="rounded-lg border border-negative/40 bg-negative/10 px-3 py-2 text-sm text-negative">
            {(result.errors ?? ["Unknown simulation error."]).join(" · ")}
          </div>
        ) : Object.keys(result.results_by_currency ?? {}).length === 0 ? (
          <div className="text-xs text-muted">No per-currency results returned.</div>
        ) : (
          <div className="space-y-5">
            {CURRENCY_ORDER.map((ccy) => {
              const r = result.results_by_currency[ccy];
              if (!r) return null;
              return <CurrencyBlock key={ccy} currency={ccy} r={r} />;
            })}
          </div>
        )}
      </CardBody>
    </Card>
  );
}

function CurrencyBlock({ currency, r }: { currency: string; r: CurrencyResult }) {
  const before = r.before ?? {};
  const after = r.after ?? {};
  const change = r.change ?? {};
  const currentCount = (r.current_positions ?? []).length;
  const simulatedCount = (r.simulated_positions ?? []).length;

  function deltaTone(v: unknown): "positive" | "negative" | "neutral" {
    const n = Number(v);
    if (!Number.isFinite(n) || n === 0) return "neutral";
    return n < 0 ? "positive" : "negative"; // lower IM/MM% is better
  }

  function deltaStr(v: unknown): string | undefined {
    const n = Number(v);
    if (!Number.isFinite(n)) return undefined;
    return `${n >= 0 ? "+" : ""}${n.toFixed(2)}%`;
  }

  return (
    <div className="space-y-3">
      <div className="text-sm font-semibold text-fg">{currency} Results</div>
      <div className="grid grid-cols-1 gap-3 md:grid-cols-4">
        <MetricCard
          label="IM %"
          value={fmtPct(after.im_pct)}
          sub={deltaStr(change.im_pct)}
          tone={deltaTone(change.im_pct)}
        />
        <MetricCard
          label="MM %"
          value={fmtPct(after.mm_pct)}
          sub={deltaStr(change.mm_pct)}
          tone={deltaTone(change.mm_pct)}
        />
        <MetricCard label="Current Position Count" value={String(currentCount)} />
        <MetricCard label="Simulated Position Count" value={String(simulatedCount)} />
      </div>
      <Table>
        <Thead>
          <Tr>
            <Th>Metric</Th>
            <Th className="text-right">Before</Th>
            <Th className="text-right">After</Th>
            <Th className="text-right">Change</Th>
          </Tr>
        </Thead>
        <Tbody>
          <Tr>
            <Td>IM %</Td>
            <Td className="text-right tabular-nums">{fmtPct(before.im_pct)}</Td>
            <Td className="text-right tabular-nums">{fmtPct(after.im_pct)}</Td>
            <Td className="text-right tabular-nums">{fmtPct(change.im_pct)}</Td>
          </Tr>
          <Tr>
            <Td>MM %</Td>
            <Td className="text-right tabular-nums">{fmtPct(before.mm_pct)}</Td>
            <Td className="text-right tabular-nums">{fmtPct(after.mm_pct)}</Td>
            <Td className="text-right tabular-nums">{fmtPct(change.mm_pct)}</Td>
          </Tr>
          {before.delta != null || after.delta != null ? (
            <Tr>
              <Td>Delta</Td>
              <Td className="text-right tabular-nums">{fmtNum(before.delta, 4)}</Td>
              <Td className="text-right tabular-nums">{fmtNum(after.delta, 4)}</Td>
              <Td className="text-right tabular-nums">{fmtNum(change.delta, 4)}</Td>
            </Tr>
          ) : null}
        </Tbody>
      </Table>
    </div>
  );
}

function RawJsonSection({ result }: { result: SimulationResult | null }) {
  const [openKey, setOpenKey] = useState<string | null>(null);

  if (!result || !result.ok) {
    return (
      <Card>
        <CardHeader title="7. Raw JSON" />
        <CardBody className="pt-0">
          <div className="text-xs text-muted">No raw JSON to display yet.</div>
        </CardBody>
      </Card>
    );
  }

  const byCcy = result.results_by_currency ?? {};

  return (
    <Card>
      <CardHeader title="7. Raw JSON" />
      <CardBody className="space-y-2 pt-0">
        {CURRENCY_ORDER.map((ccy) => {
          const r = byCcy[ccy];
          if (!r) return null;
          return (
            <div key={ccy} className="space-y-2">
              {(["raw_before", "raw_after"] as const).map((k) => {
                const key = `${ccy}/${k}`;
                const open = openKey === key;
                return (
                  <div key={key}>
                    <Button
                      variant="secondary"
                      size="sm"
                      onClick={() => setOpenKey(open ? null : key)}
                    >
                      {open ? "Hide" : "Show"} {ccy} - {k.replace("raw_", "Raw ").replace("_", " ")}
                    </Button>
                    {open ? (
                      <pre className="mt-2 max-h-96 overflow-auto rounded-lg border border-border bg-surface-2/40 p-3 text-[0.7rem] text-muted">
                        {JSON.stringify(r[k] ?? {}, null, 2)}
                      </pre>
                    ) : null}
                  </div>
                );
              })}
            </div>
          );
        })}
      </CardBody>
    </Card>
  );
}
