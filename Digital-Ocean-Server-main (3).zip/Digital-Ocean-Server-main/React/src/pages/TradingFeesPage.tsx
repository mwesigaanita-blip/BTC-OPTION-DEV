import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { RefreshCw } from "lucide-react";
import {
  fetchFeeEvents,
  syncFees,
  type FeeEvent,
  type FeesResponse,
} from "@/api/tradingFees";
import { PageHeader } from "@/components/shared/PageHeader";
import { LoadingState } from "@/components/shared/LoadingState";
import { ErrorState } from "@/components/shared/ErrorState";
import { Card, CardBody, CardHeader } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { Badge } from "@/components/ui/Badge";
import { fmtUsd } from "@/lib/format";

function fmtFee(amount: number, ccy: string | null): string {
  if (!Number.isFinite(amount)) return "-";
  const precision = (ccy || "").toUpperCase() === "BTC" ? 8 : 2;
  return `${amount.toFixed(precision)} ${ccy ?? ""}`.trim();
}

function fmtTime(iso: string | null | undefined): string {
  if (!iso) return "-";
  return new Date(iso).toLocaleString("en-US", {
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    timeZoneName: "short",
  });
}

function SyncResultBanner({
  result,
  onClose,
}: {
  result: { fetched_trades?: number; inserted?: number; notified?: number };
  onClose: () => void;
}) {
  return (
    <div className="flex items-center gap-3 rounded-lg border border-emerald-500/30 bg-emerald-500/10 px-4 py-3 text-sm text-emerald-400">
      <span className="flex-1">
        Sync done — fetched {result.fetched_trades ?? 0} trades, inserted{" "}
        {result.inserted ?? 0} new fee rows, notified {result.notified ?? 0}{" "}
        via Telegram.
      </span>
      <button onClick={onClose} className="text-emerald-400 hover:text-emerald-300">
        ✕
      </button>
    </div>
  );
}

interface Controls {
  days_back: number;
  limit: number;
  only_unnotified: boolean;
}

export default function TradingFeesPage() {
  const queryClient = useQueryClient();
  const [controls, setControls] = useState<Controls>({
    days_back: 7,
    limit: 500,
    only_unnotified: false,
  });
  const [syncResult, setSyncResult] = useState<{
    fetched_trades?: number;
    inserted?: number;
    notified?: number;
  } | null>(null);

  const { data, isLoading, isError, error } = useQuery<FeesResponse>({
    queryKey: ["trading-fees", controls],
    queryFn: () => fetchFeeEvents(controls),
    staleTime: 30_000,
  });

  const syncMutation = useMutation({
    mutationFn: syncFees,
    onSuccess: (res) => {
      setSyncResult(res);
      queryClient.invalidateQueries({ queryKey: ["trading-fees"] });
    },
  });

  function applyControls(next: Partial<Controls>) {
    setSyncResult(null);
    setControls((prev) => ({ ...prev, ...next }));
  }

  const rows: FeeEvent[] = data?.rows ?? [];
  const summary = data?.summary;

  return (
    <div className="space-y-6">
      <PageHeader title="Trading Fees" />

      {/* Sync card */}
      <Card>
        <CardHeader title="Sync Fees from Deribit" />
        <CardBody className="space-y-3">
          <p className="text-sm text-zinc-400">
            Pulls BTC + USDT trade fills from Deribit and upserts new fee rows
            (idempotent by trade ID). Notifies via Telegram for unnotified rows.
          </p>
          <div className="flex items-center gap-3">
            <Button
              onClick={() => syncMutation.mutate()}
              disabled={syncMutation.isPending}
              className="gap-2"
            >
              <RefreshCw
                size={14}
                className={syncMutation.isPending ? "animate-spin" : ""}
              />
              {syncMutation.isPending ? "Syncing…" : "Sync Now"}
            </Button>
            {syncMutation.isError && (
              <span className="text-sm text-red-400">
                {String((syncMutation.error as Error).message)}
              </span>
            )}
          </div>
          {syncResult && (
            <SyncResultBanner
              result={syncResult}
              onClose={() => setSyncResult(null)}
            />
          )}
        </CardBody>
      </Card>

      {/* Controls */}
      <Card>
        <CardHeader title="Filters" />
        <CardBody>
          <div className="flex flex-wrap items-end gap-4">
            <label className="flex flex-col gap-1 text-sm">
              <span className="text-zinc-400">Days back</span>
              <input
                type="number"
                min={1}
                max={365}
                value={controls.days_back}
                onChange={(e) =>
                  applyControls({ days_back: Math.max(1, Math.min(365, Number(e.target.value))) })
                }
                className="w-24 rounded-md border border-zinc-700 bg-zinc-800 px-3 py-1.5 text-sm text-zinc-100 focus:border-blue-500 focus:outline-none"
              />
            </label>
            <label className="flex flex-col gap-1 text-sm">
              <span className="text-zinc-400">Max rows</span>
              <input
                type="number"
                min={50}
                max={5000}
                step={50}
                value={controls.limit}
                onChange={(e) =>
                  applyControls({ limit: Math.max(50, Math.min(5000, Number(e.target.value))) })
                }
                className="w-28 rounded-md border border-zinc-700 bg-zinc-800 px-3 py-1.5 text-sm text-zinc-100 focus:border-blue-500 focus:outline-none"
              />
            </label>
            <label className="flex cursor-pointer items-center gap-2 text-sm text-zinc-300">
              <input
                type="checkbox"
                checked={controls.only_unnotified}
                onChange={(e) => applyControls({ only_unnotified: e.target.checked })}
                className="h-4 w-4 rounded border-zinc-600 accent-blue-500"
              />
              Only unnotified
            </label>
          </div>
        </CardBody>
      </Card>

      {/* Summary */}
      {data && (
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
          {Object.entries(summary?.total_fee_by_ccy ?? {}).map(([ccy, total]) => (
            <Card key={ccy}>
              <CardBody>
                <p className="text-xs font-medium uppercase tracking-wide text-zinc-400">
                  Total Fees ({ccy})
                </p>
                <p className="mt-1 text-xl font-semibold text-zinc-100">
                  {fmtFee(total, ccy)}
                </p>
                <p className="mt-0.5 text-xs text-zinc-500">{rows.length} events</p>
              </CardBody>
            </Card>
          ))}
          {summary?.total_usd != null && (
            <Card>
              <CardBody>
                <p className="text-xs font-medium uppercase tracking-wide text-zinc-400">
                  Total Fees (USD approx)
                </p>
                <p className="mt-1 text-xl font-semibold text-zinc-100">
                  {fmtUsd(summary.total_usd)}
                </p>
              </CardBody>
            </Card>
          )}
        </div>
      )}

      {/* Table */}
      {isLoading && <LoadingState />}
      {isError && (
        <ErrorState message={(error as Error).message ?? "Failed to load fee events"} />
      )}
      {!isLoading && !isError && rows.length === 0 && (
        <Card>
          <CardBody>
            <p className="text-center text-sm text-zinc-400">
              No fee events found in this time range.
            </p>
          </CardBody>
        </Card>
      )}
      {!isLoading && !isError && rows.length > 0 && (
        <Card>
          <CardHeader
            title="Fee Events"
            subtitle={`${rows.length} rows, newest first`}
          />
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-zinc-700 text-left text-xs font-medium uppercase tracking-wide text-zinc-400">
                  <th className="px-4 py-2">Time (UTC)</th>
                  <th className="px-4 py-2">Instrument</th>
                  <th className="px-4 py-2">Side</th>
                  <th className="px-4 py-2 text-right">Fee</th>
                  <th className="px-4 py-2 text-right">Fee USD</th>
                  <th className="px-4 py-2 text-right">Price</th>
                  <th className="px-4 py-2 text-right">Amount</th>
                  <th className="px-4 py-2">Trade ID</th>
                  <th className="px-4 py-2 text-center">Notified</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((row) => (
                  <tr
                    key={row.id}
                    className="border-b border-zinc-800 hover:bg-zinc-800/40"
                  >
                    <td className="whitespace-nowrap px-4 py-2 font-mono text-xs text-zinc-300">
                      {fmtTime(row.time_utc)}
                    </td>
                    <td className="whitespace-nowrap px-4 py-2 font-mono text-xs text-zinc-200">
                      {row.instrument_name ?? "-"}
                    </td>
                    <td className="px-4 py-2">
                      {row.side ? (
                        <Badge
                          tone={
                            row.side.toUpperCase() === "BUY"
                              ? "positive"
                              : row.side.toUpperCase() === "SELL"
                              ? "negative"
                              : "neutral"
                          }
                        >
                          {row.side}
                        </Badge>
                      ) : (
                        "-"
                      )}
                    </td>
                    <td className="px-4 py-2 text-right font-mono text-xs text-zinc-200">
                      {fmtFee(row.fee_amount, row.fee_currency)}
                    </td>
                    <td className="px-4 py-2 text-right font-mono text-xs text-zinc-300">
                      {row.fee_usd != null ? fmtUsd(row.fee_usd) : "-"}
                    </td>
                    <td className="px-4 py-2 text-right font-mono text-xs text-zinc-400">
                      {row.price != null ? row.price.toLocaleString("en-US") : "-"}
                    </td>
                    <td className="px-4 py-2 text-right font-mono text-xs text-zinc-400">
                      {row.amount != null ? row.amount.toLocaleString("en-US") : "-"}
                    </td>
                    <td className="max-w-[8rem] truncate px-4 py-2 font-mono text-xs text-zinc-500">
                      {row.trade_id ?? "-"}
                    </td>
                    <td className="px-4 py-2 text-center text-xs">
                      {row.notified_telegram ? (
                        <span className="text-emerald-400">✓</span>
                      ) : (
                        <span className="text-zinc-600">–</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      )}
    </div>
  );
}
