import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { fetchLlmFees, type LlmFeesParams, type LlmFeesResponse } from "@/api/llmFees";
import { PageHeader } from "@/components/shared/PageHeader";
import { LoadingState } from "@/components/shared/LoadingState";
import { ErrorState } from "@/components/shared/ErrorState";
import { Card, CardBody, CardHeader } from "@/components/ui/Card";

const CHART_COLORS = [
  "#3b82f6", "#10b981", "#f59e0b", "#ef4444",
  "#8b5cf6", "#06b6d4", "#f97316", "#84cc16",
];

function fmtCost(n: number, digits = 4): string {
  if (!Number.isFinite(n)) return "-";
  return `$${n.toFixed(digits)}`;
}

function fmtTime(s: string | null | undefined): string {
  if (!s) return "-";
  try {
    return new Date(s).toLocaleString("en-US", {
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
      timeZoneName: "short",
    });
  } catch {
    return s;
  }
}

interface KpiCardProps {
  label: string;
  value: string;
  sub?: string;
}
function KpiCard({ label, value, sub }: KpiCardProps) {
  return (
    <Card>
      <CardBody>
        <p className="text-xs font-medium uppercase tracking-wide text-zinc-400">{label}</p>
        <p className="mt-1 text-xl font-semibold text-zinc-100">{value}</p>
        {sub && <p className="mt-0.5 text-xs text-zinc-500">{sub}</p>}
      </CardBody>
    </Card>
  );
}

export default function LlmFeesPage() {
  const [filters, setFilters] = useState<LlmFeesParams>({
    include_zero: true,
  });

  // We need filter options from an unfiltered call first, but the endpoint
  // always returns filter_options from the full dataset regardless of filters.
  const { data, isLoading, isError, error } = useQuery<LlmFeesResponse>({
    queryKey: ["llm-fees", filters],
    queryFn: () => fetchLlmFees(filters),
    staleTime: 60_000,
  });

  function setFilter(patch: Partial<LlmFeesParams>) {
    setFilters((prev) => ({ ...prev, ...patch }));
  }

  const summary = data?.summary;
  const rows = data?.rows ?? [];
  const daily = data?.daily ?? [];
  const byModel = data?.by_model ?? [];
  const byProvider = data?.by_provider ?? [];
  const filterOpts = data?.filter_options ?? { providers: [], model_labels: [] };

  // Collect model keys for stacked area chart
  const modelKeys = Array.from(
    new Set((data?.daily_by_model ?? []).flatMap((d) => Object.keys(d).filter((k) => k !== "day")))
  );

  return (
    <div className="space-y-6">
      <PageHeader title="LLM Cost" />

      {/* Filters */}
      <Card>
        <CardHeader title="Filters" />
        <CardBody>
          <div className="flex flex-wrap items-end gap-4">
            <label className="flex flex-col gap-1 text-sm">
              <span className="text-zinc-400">Start date</span>
              <input
                type="date"
                value={filters.start_date ?? ""}
                onChange={(e) => setFilter({ start_date: e.target.value || undefined })}
                className="rounded-md border border-zinc-700 bg-zinc-800 px-3 py-1.5 text-sm text-zinc-100 focus:border-blue-500 focus:outline-none"
              />
            </label>
            <label className="flex flex-col gap-1 text-sm">
              <span className="text-zinc-400">End date</span>
              <input
                type="date"
                value={filters.end_date ?? ""}
                onChange={(e) => setFilter({ end_date: e.target.value || undefined })}
                className="rounded-md border border-zinc-700 bg-zinc-800 px-3 py-1.5 text-sm text-zinc-100 focus:border-blue-500 focus:outline-none"
              />
            </label>
            <label className="flex flex-col gap-1 text-sm">
              <span className="text-zinc-400">Provider</span>
              <select
                value={filters.provider ?? ""}
                onChange={(e) => setFilter({ provider: e.target.value || undefined })}
                className="rounded-md border border-zinc-700 bg-zinc-800 px-3 py-1.5 text-sm text-zinc-100 focus:border-blue-500 focus:outline-none"
              >
                <option value="">All</option>
                {filterOpts.providers.map((p) => (
                  <option key={p} value={p}>{p}</option>
                ))}
              </select>
            </label>
            <label className="flex flex-col gap-1 text-sm">
              <span className="text-zinc-400">Model label</span>
              <select
                value={filters.model_label ?? ""}
                onChange={(e) => setFilter({ model_label: e.target.value || undefined })}
                className="rounded-md border border-zinc-700 bg-zinc-800 px-3 py-1.5 text-sm text-zinc-100 focus:border-blue-500 focus:outline-none"
              >
                <option value="">All</option>
                {filterOpts.model_labels.map((l) => (
                  <option key={l} value={l}>{l}</option>
                ))}
              </select>
            </label>
            <label className="flex cursor-pointer items-center gap-2 text-sm text-zinc-300">
              <input
                type="checkbox"
                checked={filters.include_zero ?? true}
                onChange={(e) => setFilter({ include_zero: e.target.checked })}
                className="h-4 w-4 rounded border-zinc-600 accent-blue-500"
              />
              Include $0 runs
            </label>
          </div>
        </CardBody>
      </Card>

      {isLoading && <LoadingState />}
      {isError && (
        <ErrorState message={(error as Error).message ?? "Failed to load LLM cost data"} />
      )}

      {!isLoading && !isError && rows.length === 0 && (
        <Card>
          <CardBody>
            <p className="text-center text-sm text-zinc-400">
              No cost data found. Try adjusting your filters.
            </p>
          </CardBody>
        </Card>
      )}

      {!isLoading && !isError && summary && rows.length > 0 && (
        <>
          {/* KPI strip */}
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-5">
            <KpiCard label="Total cost" value={fmtCost(summary.total_cost_usd)} />
            <KpiCard label="Runs" value={summary.n_runs.toLocaleString()} />
            <KpiCard label="Avg / run" value={fmtCost(summary.avg_cost_usd)} />
            <KpiCard label="Last 7 days" value={fmtCost(summary.last_7_days_usd)} />
            <KpiCard label="Last 30 days" value={fmtCost(summary.last_30_days_usd)} />
          </div>

          {/* Daily cost line chart */}
          {daily.length > 0 && (
            <Card>
              <CardHeader title="Daily Cost" />
              <CardBody>
                <ResponsiveContainer width="100%" height={220}>
                  <AreaChart data={daily} margin={{ top: 4, right: 16, left: 0, bottom: 4 }}>
                    <defs>
                      <linearGradient id="costGrad" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3} />
                        <stop offset="95%" stopColor="#3b82f6" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="#3f3f46" />
                    <XAxis
                      dataKey="day"
                      tick={{ fill: "#a1a1aa", fontSize: 11 }}
                      tickLine={false}
                    />
                    <YAxis
                      tick={{ fill: "#a1a1aa", fontSize: 11 }}
                      tickLine={false}
                      axisLine={false}
                      tickFormatter={(v: number) => `$${v.toFixed(3)}`}
                    />
                    <Tooltip
                      contentStyle={{ background: "#18181b", border: "1px solid #3f3f46", borderRadius: 6 }}
                      labelStyle={{ color: "#a1a1aa" }}
                      formatter={(v: number) => [fmtCost(v), "Cost"]}
                    />
                    <Area
                      type="monotone"
                      dataKey="cost"
                      stroke="#3b82f6"
                      strokeWidth={2}
                      fill="url(#costGrad)"
                      dot={false}
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </CardBody>
            </Card>
          )}

          {/* Daily cost by model (stacked area) */}
          {modelKeys.length > 1 && (data?.daily_by_model ?? []).length > 0 && (
            <Card>
              <CardHeader title="Daily Cost by Model" />
              <CardBody>
                <ResponsiveContainer width="100%" height={220}>
                  <AreaChart
                    data={data!.daily_by_model}
                    margin={{ top: 4, right: 16, left: 0, bottom: 4 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" stroke="#3f3f46" />
                    <XAxis
                      dataKey="day"
                      tick={{ fill: "#a1a1aa", fontSize: 11 }}
                      tickLine={false}
                    />
                    <YAxis
                      tick={{ fill: "#a1a1aa", fontSize: 11 }}
                      tickLine={false}
                      axisLine={false}
                      tickFormatter={(v: number) => `$${v.toFixed(3)}`}
                    />
                    <Tooltip
                      contentStyle={{ background: "#18181b", border: "1px solid #3f3f46", borderRadius: 6 }}
                      labelStyle={{ color: "#a1a1aa" }}
                      formatter={(v: number, name: string) => [fmtCost(v), name]}
                    />
                    {modelKeys.map((key, i) => (
                      <Area
                        key={key}
                        type="monotone"
                        dataKey={key}
                        stackId="1"
                        stroke={CHART_COLORS[i % CHART_COLORS.length]}
                        fill={CHART_COLORS[i % CHART_COLORS.length]}
                        fillOpacity={0.5}
                        dot={false}
                      />
                    ))}
                  </AreaChart>
                </ResponsiveContainer>
              </CardBody>
            </Card>
          )}

          {/* Breakdowns */}
          <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
            {byModel.length > 0 && (
              <Card>
                <CardHeader title="Cost by Model" />
                <CardBody>
                  <ResponsiveContainer width="100%" height={200}>
                    <BarChart
                      data={byModel}
                      layout="vertical"
                      margin={{ top: 4, right: 16, left: 8, bottom: 4 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" stroke="#3f3f46" horizontal={false} />
                      <XAxis
                        type="number"
                        tick={{ fill: "#a1a1aa", fontSize: 11 }}
                        tickLine={false}
                        axisLine={false}
                        tickFormatter={(v: number) => `$${v.toFixed(3)}`}
                      />
                      <YAxis
                        type="category"
                        dataKey="model_label"
                        tick={{ fill: "#a1a1aa", fontSize: 11 }}
                        tickLine={false}
                        width={120}
                      />
                      <Tooltip
                        contentStyle={{ background: "#18181b", border: "1px solid #3f3f46", borderRadius: 6 }}
                        formatter={(v: number) => [fmtCost(v), "Cost"]}
                      />
                      <Bar dataKey="cost" radius={[0, 3, 3, 0]}>
                        {byModel.map((_, i) => (
                          <Cell key={i} fill={CHART_COLORS[i % CHART_COLORS.length]} />
                        ))}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </CardBody>
              </Card>
            )}
            {byProvider.length > 0 && (
              <Card>
                <CardHeader title="Cost by Provider" />
                <CardBody>
                  <ResponsiveContainer width="100%" height={200}>
                    <BarChart
                      data={byProvider}
                      layout="vertical"
                      margin={{ top: 4, right: 16, left: 8, bottom: 4 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" stroke="#3f3f46" horizontal={false} />
                      <XAxis
                        type="number"
                        tick={{ fill: "#a1a1aa", fontSize: 11 }}
                        tickLine={false}
                        axisLine={false}
                        tickFormatter={(v: number) => `$${v.toFixed(3)}`}
                      />
                      <YAxis
                        type="category"
                        dataKey="provider"
                        tick={{ fill: "#a1a1aa", fontSize: 11 }}
                        tickLine={false}
                        width={100}
                      />
                      <Tooltip
                        contentStyle={{ background: "#18181b", border: "1px solid #3f3f46", borderRadius: 6 }}
                        formatter={(v: number) => [fmtCost(v), "Cost"]}
                      />
                      <Bar dataKey="cost" radius={[0, 3, 3, 0]}>
                        {byProvider.map((_, i) => (
                          <Cell key={i} fill={CHART_COLORS[i % CHART_COLORS.length]} />
                        ))}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </CardBody>
              </Card>
            )}
          </div>

          {/* Runs table */}
          <Card>
            <CardHeader
              title="Runs"
              subtitle={`${rows.length} rows, newest first`}
            />
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-zinc-700 text-left text-xs font-medium uppercase tracking-wide text-zinc-400">
                    <th className="px-4 py-2">ID</th>
                    <th className="px-4 py-2">Model Label</th>
                    <th className="px-4 py-2">Provider</th>
                    <th className="px-4 py-2">Model ID</th>
                    <th className="px-4 py-2">Run Time (UTC)</th>
                    <th className="px-4 py-2 text-right">Cost (USD)</th>
                  </tr>
                </thead>
                <tbody>
                  {rows.map((row) => (
                    <tr
                      key={row.id}
                      className="border-b border-zinc-800 hover:bg-zinc-800/40"
                    >
                      <td className="px-4 py-2 font-mono text-xs text-zinc-500">{row.id}</td>
                      <td className="px-4 py-2 text-zinc-200">{row.model_label ?? "-"}</td>
                      <td className="px-4 py-2 text-zinc-300">{row.provider ?? "-"}</td>
                      <td className="max-w-[12rem] truncate px-4 py-2 font-mono text-xs text-zinc-400">
                        {row.model_id ?? "-"}
                      </td>
                      <td className="whitespace-nowrap px-4 py-2 font-mono text-xs text-zinc-300">
                        {fmtTime(row.run_time_utc)}
                      </td>
                      <td className="px-4 py-2 text-right font-mono text-xs text-zinc-200">
                        {fmtCost(row.total_cost_usd)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>
        </>
      )}
    </div>
  );
}
