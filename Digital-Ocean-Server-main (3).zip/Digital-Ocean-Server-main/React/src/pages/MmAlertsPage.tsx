import { useEffect, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { AlertTriangle, RefreshCw, Save } from "lucide-react";
import {
  fetchMmAlertsConfig,
  saveMmAlertsConfig,
  type MmAlertConfig,
  type MmAlertConfigPatch,
} from "@/api/mmAlerts";
import { PageHeader } from "@/components/shared/PageHeader";
import { LoadingState } from "@/components/shared/LoadingState";
import { ErrorState } from "@/components/shared/ErrorState";
import { Card, CardBody, CardHeader } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { Input } from "@/components/ui/Input";
import { Badge } from "@/components/ui/Badge";
import { cn } from "@/lib/utils";

const AVAILABLE_CURRENCIES = ["BTC", "ETH", "USDC", "USDT"] as const;

interface FormState {
  is_enabled: boolean;
  warning_threshold: string;
  critical_threshold: string;
  warning_cooldown_minutes: string;
  critical_cooldown_minutes: string;
  check_interval_seconds: string;
  currencies: string[];
}

function cfgToForm(c: MmAlertConfig): FormState {
  return {
    is_enabled: Boolean(c.is_enabled),
    warning_threshold: String(c.warning_threshold ?? 80),
    critical_threshold: String(c.critical_threshold ?? 95),
    warning_cooldown_minutes: String(c.warning_cooldown_minutes ?? 5),
    critical_cooldown_minutes: String(c.critical_cooldown_minutes ?? 1),
    check_interval_seconds: String(c.check_interval_seconds ?? 30),
    currencies: Array.isArray(c.currencies) ? c.currencies : ["BTC"],
  };
}

function formToPatch(f: FormState): MmAlertConfigPatch {
  return {
    is_enabled: f.is_enabled,
    warning_threshold: Number(f.warning_threshold),
    critical_threshold: Number(f.critical_threshold),
    warning_cooldown_minutes: Math.round(Number(f.warning_cooldown_minutes)),
    critical_cooldown_minutes: Math.round(Number(f.critical_cooldown_minutes)),
    check_interval_seconds: Math.round(Number(f.check_interval_seconds)),
    currencies: f.currencies,
  };
}

function isFormDirty(f: FormState, c: MmAlertConfig): boolean {
  const base = cfgToForm(c);
  if (f.is_enabled !== base.is_enabled) return true;
  if (f.warning_threshold !== base.warning_threshold) return true;
  if (f.critical_threshold !== base.critical_threshold) return true;
  if (f.warning_cooldown_minutes !== base.warning_cooldown_minutes) return true;
  if (f.critical_cooldown_minutes !== base.critical_cooldown_minutes) return true;
  if (f.check_interval_seconds !== base.check_interval_seconds) return true;
  if (f.currencies.length !== base.currencies.length) return true;
  const a = [...f.currencies].sort();
  const b = [...base.currencies].sort();
  for (let i = 0; i < a.length; i++) if (a[i] !== b[i]) return true;
  return false;
}

function validate(f: FormState): string[] {
  const errs: string[] = [];
  const warn = Number(f.warning_threshold);
  const crit = Number(f.critical_threshold);
  if (!Number.isFinite(warn) || warn < 0 || warn > 200)
    errs.push("Warning threshold must be between 0 and 200.");
  if (!Number.isFinite(crit) || crit < 0 || crit > 200)
    errs.push("Critical threshold must be between 0 and 200.");
  if (Number.isFinite(warn) && Number.isFinite(crit) && crit < warn)
    errs.push(
      "Critical threshold should be ≥ warning threshold (otherwise critical fires before warning).",
    );
  const wcd = Number(f.warning_cooldown_minutes);
  const ccd = Number(f.critical_cooldown_minutes);
  const interval = Number(f.check_interval_seconds);
  if (!Number.isFinite(wcd) || wcd < 1 || wcd > 1440)
    errs.push("Warning cooldown must be 1-1440 minutes.");
  if (!Number.isFinite(ccd) || ccd < 1 || ccd > 1440)
    errs.push("Critical cooldown must be 1-1440 minutes.");
  if (!Number.isFinite(interval) || interval < 5 || interval > 3600)
    errs.push("Check interval must be 5-3600 seconds.");
  if (f.currencies.length === 0)
    errs.push("At least one currency must be monitored.");
  return errs;
}

export function MmAlertsPage() {
  const qc = useQueryClient();
  const q = useQuery({
    queryKey: ["mm-alerts-config"],
    queryFn: fetchMmAlertsConfig,
    refetchInterval: 30_000,
    retry: false,
  });

  const [form, setForm] = useState<FormState | null>(null);

  // Sync the local draft when the server-side config refetches AND the user
  // has no unsaved local edits (we don't clobber in-flight typing).
  useEffect(() => {
    if (!q.data) return;
    setForm((curr) => {
      if (curr == null) return cfgToForm(q.data);
      if (!isFormDirty(curr, q.data)) return cfgToForm(q.data);
      return curr;
    });
  }, [q.data]);

  const saveMut = useMutation({
    mutationFn: (patch: MmAlertConfigPatch) => saveMmAlertsConfig(patch),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["mm-alerts-config"] }),
  });
  const saveErr =
    (saveMut.error as { response?: { data?: { detail?: string } }; message?: string } | null)
      ?.response?.data?.detail ??
    (saveMut.error as Error | null)?.message ??
    null;

  if (q.isLoading || !form) return <LoadingState label="Loading MM alert config…" />;
  if (q.error || !q.data) {
    return (
      <ErrorState
        message={(q.error as Error)?.message ?? "Failed to load MM alert config"}
        onRetry={() => q.refetch()}
      />
    );
  }

  const cfg = q.data;
  const errs = validate(form);
  const dirty = isFormDirty(form, cfg);

  function patch(p: Partial<FormState>) {
    setForm((curr) => (curr ? { ...curr, ...p } : curr));
  }

  function toggleCurrency(c: string) {
    setForm((curr) => {
      if (!curr) return curr;
      const has = curr.currencies.includes(c);
      const next = has
        ? curr.currencies.filter((x) => x !== c)
        : [...curr.currencies, c];
      return { ...curr, currencies: next };
    });
  }

  return (
    <div className="space-y-5 animate-fade-in">
      <PageHeader
        title="📣 MM Alert Bot Settings"
        description="Maintenance-margin threshold + cooldown config for the alert bot. Saved values take effect on the bot's next check cycle."
        actions={
          <Button
            variant="secondary"
            size="sm"
            onClick={() => qc.invalidateQueries({ queryKey: ["mm-alerts-config"] })}
            disabled={q.isFetching}
          >
            <RefreshCw className={cn("h-3.5 w-3.5", q.isFetching && "animate-spin")} />
            Refresh
          </Button>
        }
      />

      <Card>
        <CardBody className="flex flex-wrap items-center justify-between gap-3 pt-4">
          <label className="flex cursor-pointer items-center gap-3 text-sm">
            <input
              type="checkbox"
              checked={form.is_enabled}
              onChange={(e) => patch({ is_enabled: e.target.checked })}
              className="h-4 w-4 accent-brand"
            />
            <span className="font-semibold text-fg">Enable alerts</span>
            <span className="text-xs text-muted">
              Turn the alert system on or off without stopping the bot.
            </span>
          </label>
          <Badge tone={form.is_enabled ? "positive" : "negative"}>
            {form.is_enabled ? "ENABLED" : "DISABLED"}
          </Badge>
        </CardBody>
      </Card>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader title="Thresholds" subtitle="Maintenance-margin % triggers." />
          <CardBody className="space-y-4 pt-0">
            <FieldNumber
              label="Warning threshold (%)"
              help="⚠️ WARNING fires when maintenance margin reaches this level. e.g. 80% = approaching risk."
              value={form.warning_threshold}
              step={1}
              min={0}
              max={200}
              onChange={(v) => patch({ warning_threshold: v })}
            />
            <FieldNumber
              label="Critical threshold (%)"
              help="🚨 CRITICAL fires when maintenance margin reaches this level. e.g. 95% = liquidation risk is very close."
              value={form.critical_threshold}
              step={1}
              min={0}
              max={200}
              onChange={(v) => patch({ critical_threshold: v })}
            />
          </CardBody>
        </Card>

        <Card>
          <CardHeader
            title="Cooldowns & cadence"
            subtitle="How often alerts repeat and how frequently margin is checked."
          />
          <CardBody className="space-y-4 pt-0">
            <FieldNumber
              label="Warning cooldown (minutes)"
              help="⏳ After a warning alert is sent, the system waits this many minutes before sending another warning."
              value={form.warning_cooldown_minutes}
              step={1}
              min={1}
              max={1440}
              onChange={(v) => patch({ warning_cooldown_minutes: v })}
            />
            <FieldNumber
              label="Critical cooldown (minutes)"
              help="🔥 Prevents repeated critical alerts during extreme volatility. Lower = more frequent urgent alerts."
              value={form.critical_cooldown_minutes}
              step={1}
              min={1}
              max={1440}
              onChange={(v) => patch({ critical_cooldown_minutes: v })}
            />
            <FieldNumber
              label="Check interval (seconds)"
              help="🔄 How often margin is checked. Smaller values = faster reaction, higher system load."
              value={form.check_interval_seconds}
              step={5}
              min={5}
              max={3600}
              onChange={(v) => patch({ check_interval_seconds: v })}
            />
          </CardBody>
        </Card>
      </div>

      <Card>
        <CardHeader
          title="Currencies to monitor"
          subtitle="Which Deribit margin currencies the alert system tracks."
        />
        <CardBody className="pt-0">
          <div className="flex flex-wrap gap-2">
            {AVAILABLE_CURRENCIES.map((c) => {
              const on = form.currencies.includes(c);
              return (
                <button
                  key={c}
                  type="button"
                  onClick={() => toggleCurrency(c)}
                  className={cn(
                    "rounded-md border px-3 py-1.5 text-sm font-mono transition-colors",
                    on
                      ? "border-brand bg-brand/15 text-brand"
                      : "border-border bg-surface-2 text-muted hover:text-fg",
                  )}
                >
                  {on ? "✓ " : ""}
                  {c}
                </button>
              );
            })}
          </div>
        </CardBody>
      </Card>

      {errs.length > 0 ? (
        <div className="flex flex-col gap-1 rounded-md border border-negative/40 bg-negative/10 px-3 py-2 text-xs text-negative">
          {errs.map((e, i) => (
            <div key={i} className="flex items-start gap-2">
              <AlertTriangle className="mt-0.5 h-3.5 w-3.5 shrink-0" /> {e}
            </div>
          ))}
        </div>
      ) : null}

      <Card>
        <CardBody className="flex flex-wrap items-center gap-3 pt-4">
          <Button
            onClick={() => saveMut.mutate(formToPatch(form))}
            disabled={!dirty || errs.length > 0 || saveMut.isPending}
          >
            <Save className="h-3.5 w-3.5" />
            {saveMut.isPending ? "Saving…" : "Save settings"}
          </Button>
          {saveMut.isSuccess ? (
            <span className="text-xs text-positive">Saved ✅</span>
          ) : null}
          {!dirty && !saveMut.isPending ? (
            <span className="text-xs text-muted">No changes to save.</span>
          ) : null}
          {dirty ? (
            <button
              type="button"
              className="text-xs text-muted hover:text-fg underline"
              onClick={() => setForm(cfgToForm(cfg))}
            >
              Discard changes
            </button>
          ) : null}
          {saveErr ? <span className="text-xs text-negative">{saveErr}</span> : null}
          <span className="ml-auto text-[0.7rem] text-muted">
            Last updated:{" "}
            <span className="font-mono text-fg">
              {cfg.updated_at_utc ?? "-"}
            </span>
          </span>
        </CardBody>
      </Card>

      <Card>
        <CardHeader
          title="Current config (DB)"
          subtitle="Raw state of the persisted row, for verification."
        />
        <CardBody className="pt-0">
          <pre className="max-h-80 overflow-auto rounded-md border border-border bg-surface-2/40 p-3 text-[0.7rem] text-muted">
            {JSON.stringify(cfg, null, 2)}
          </pre>
        </CardBody>
      </Card>
    </div>
  );
}

function FieldNumber({
  label,
  help,
  value,
  step,
  min,
  max,
  onChange,
}: {
  label: string;
  help?: string;
  value: string;
  step: number;
  min?: number;
  max?: number;
  onChange: (v: string) => void;
}) {
  return (
    <div>
      <label className="block text-xs font-medium text-muted">{label}</label>
      <Input
        type="number"
        value={value}
        step={step}
        min={min}
        max={max}
        onChange={(e) => onChange(e.target.value)}
      />
      {help ? <div className="mt-1 text-[0.7rem] text-muted">{help}</div> : null}
    </div>
  );
}
