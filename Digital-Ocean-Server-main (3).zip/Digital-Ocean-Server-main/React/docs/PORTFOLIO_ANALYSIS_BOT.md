# Portfolio Analysis Bot - Page Reference

This document describes the **Portfolio Analysis Bot** page in the
React dashboard. Both the user-facing model and the implementation.

> Live route: `/portfolio-analysis-bot`
> File: [`React/src/pages/PortfolioAnalysisBotPage.tsx`](../src/pages/PortfolioAnalysisBotPage.tsx)
> Backend: `/api/portfolio-bot/*` ([`backend_api/routes_portfolio_bot.py`](../../backend_api/routes_portfolio_bot.py))

---

## 1. What is this page, in plain terms

The Portfolio Analysis Bot is the **control plane** for the Portfolio
Co-Pilot system - a server-side process that runs three daemons:

1. **AlertWorker** - evaluates the 5 alert rules every 30s and writes
   to `alerts` / `state_history`.
2. **HeartbeatWorker** - sends a periodic Telegram digest at a cadence
   that scales with the Calm Score.
3. **DailyReportWorker** - at the configured UTC hour every day,
   builds a combined PDF (12 Deribit market sections + portfolio
   control plane) and ships it via Telegram `sendDocument`.

The bot exposes mutations (override a threshold, suppress an alert,
trigger an on-demand report) through a long-poll Telegram interface,
gated by `AUTHORIZED_TELEGRAM_USERS`.

This React page is **strictly read-only**: it surfaces the bot's
current state, alerts, suppressions, thresholds, audit log, and the
generated PDFs. Every change still has to flow through Telegram so
the audit trail stays clean.

---

## 2. The page at a glance

**Top status bar** - the current Calm Score (coloured pill) + a bot
liveness signal computed from the age of the most recent audit row +
a **Refresh** button.

**KPI strip** (5 cards) - Active Alerts · Suppressions · Threshold
Overrides · Last Daily Report age · PDFs available.

**Four tabs:**

### 📋 Overview

Two columns:

- **Left:** Current state (Calm Score + as-of timestamp + reasoning
  text). Active alerts table (Time, Severity, Rule, Dedup key,
  Message). When there are zero unresolved alerts, a green "No
  unresolved alerts" banner.
- **Right:** Active suppressions list (dedup key + who set it + when
  it expires). Recent activity feed (last 10 audit rows with the
  payload's first two key/value pairs).

### 🎚️ Thresholds

A wide table with one row per threshold:

| Column | Notes |
|---|---|
| Threshold | Human-readable label (`portfolio_analysis.bot.wizard.label_for`) |
| Internal name | The `name` stored in the DB and used in `/set` commands |
| Current | Pre-formatted via `portfolio_analysis._fmt.format_threshold_value` so durations show as `30m` rather than `1800` |
| Default | Same formatting |
| Overridden | "✅ YES" badge for overridden rows; the row is highlighted with a soft warning background |
| Expires (UTC) | Only set when overridden |
| Set by | Name of the Telegram user who set the override |
| Description | Static reference text mirroring `docs/telegram_commands.txt` §4 |

A banner below the table tells you the number of active overrides;
all-default shows a green "All thresholds at default values" panel.

**Override history** card below: last 30 audit rows in table form
(`/set`, `/stop`, `/resume`) with a payload column that flattens the
JSON into `k=v` pairs.

### 📄 Daily Reports

If the report directory is empty, a single panel explains where the
first PDF will appear (the configured UTC time or via the Telegram
`/report` command).

Otherwise:

- **Latest report card** - filename, size, timestamp, plus a one-click
  **Download** button.
- **All reports table** - up to 50 most recent files (Filename ·
  Generated UTC · Size).
- **Download any report** - select-box + Download button. Uses a
  blob-based download so the file goes straight to disk with the
  original filename.

Below: a static panel pointing at the Telegram `/report` command for
on-demand generation.

### ℹ️ Info

Four reference panels:

1. **What is the Portfolio Analysis Bot?** - the daemon architecture
   summary.
2. **Calm Score states** - RELAX / TAKE_A_LOOK / ACTIVE_MONITORING /
   URGENT_ACTION with their meanings, each rendered with the same
   coloured pill used at the top of the page.
3. **Telegram commands** - table of every command and its effect.
4. **Environment variables** - the env vars the bot honours (Deribit
   creds, Telegram tokens, dry-run flag, report time / dir).
5. **Useful files** - pointers to `report_daily.py`, the scheduler
   entrypoint, the bot server entrypoint, the Telegram command
   reference, and the implementation plan docs.

---

## 3. Auth model

- The endpoints are JWT-protected and gated by the
  `Portfolio_Analysis_Bot` page grant. Same trust model as the
  Streamlit page.
- The PDF download honours the JWT via the standard `Authorization:
  Bearer` header (the React client attaches it manually via
  `fetch()` so the browser can stream the blob).
- The page never holds Telegram or Deribit credentials. Those live
  in the backend env and are used only by the bot process - the
  React surface only reads what the bot has already persisted.

---

## 4. Request / response shapes

### 4.1 `GET /api/portfolio-bot/dashboard?audit_limit=N`

Returns a single bundle so the page doesn't have to make N parallel
calls. All cheap reads (SQLite + directory listing).

```jsonc
{
  "state": {
    "calm_score": "TAKE_A_LOOK",
    "ts_utc": "2026-05-20T12:21:50",
    "reasoning": "..."
  },
  "alerts": [
    {
      "ts_utc": "2026-05-20T12:21:50",
      "severity": "WARNING",
      "rule": "Rule1_MM",
      "dedup_key": "Rule1_MM:BTC",
      "message": "..."
    }
  ],
  "suppressions": [
    { "dedup_key": "Rule3_DTE:BTC-30MAY26-100000-C",
      "set_by_user_name": "remo",
      "expires_at_utc": "2026-05-22T00:00:00" }
  ],
  "audit": [
    { "ts_utc": "...", "user_name": "remo", "action": "/set",
      "payload_json": "{\"name\":\"MM_WARN_PCT\",\"value\":25,\"duration\":\"7d\"}" }
  ],
  "thresholds": [
    { "name": "MM_WARN_PCT",
      "label": "Maintenance Margin (Warn)",
      "current": 25, "default": 20,
      "current_display": "25%", "default_display": "20%",
      "overridden": true,
      "expires_at_utc": "2026-05-27T00:00:00",
      "set_by_user_name": "remo",
      "description": "Maintenance-margin % above which Rule 1 emits a WARNING." }
  ],
  "latest_report_run": { "ts_utc": "2026-05-20T00:05:00", "...": "..." },
  "reports": [
    { "name": "portfolio_2026-05-20.pdf",
      "size_kb": 4567,
      "modified_utc": "2026-05-20T00:05:12Z" }
  ],
  "config": {
    "report_dir": "/opt/.../data/reports",
    "report_daily_utc_hour": 0,
    "report_daily_utc_minute": 5
  }
}
```

### 4.2 `GET /api/portfolio-bot/reports/{filename}`

Streams a PDF back to the browser. Filename is restricted to
`portfolio_*.pdf` *inside* `REPORT_DIR`; any `/`, `\`, `..`, or
resolved path outside the dir yields `400 Bad Request`. Missing file
yields `404 Not Found`.

If the `portfolio_analysis` package failed to import (missing deps),
both endpoints return `503 Service Unavailable` with the import error
in the body.

---

## 5. File map

### Frontend

```
React/src/
├── pages/PortfolioAnalysisBotPage.tsx          The page. Top bar + KPI strip + 4 tabs.
├── api/portfolioBot.ts                         Typed client + JWT-aware PDF downloader.
└── components/ui/*, shared/*                   Card, Button, Badge, Table, Tabs, MetricCard.
```

Local state is minimal:

- `tab` at the page level.
- `selected` + `downloading` + `downloadErr` inside the Reports tab.

The dashboard is fetched as one query with a 30 s `refetchInterval`,
keyed `["portfolio-bot-dashboard"]`. Refresh = invalidate.

### Backend

```
backend_api/
└── routes_portfolio_bot.py                     2 endpoints listed in §4. Lazy-imports
                                                portfolio_analysis so a broken package
                                                surfaces as 503, not a startup crash.

portfolio_analysis/
├── config.py                                   REPORT_DIR, REPORT_DAILY_UTC_HOUR/MINUTE.
├── storage.py                                  latest_state, unresolved_alerts,
│                                               active_suppressions, recent_audit,
│                                               latest_report_run.
├── thresholds.py                               list_active() + invalidate_cache().
├── _fmt.py                                     format_threshold_value() - pretty-prints
│                                               raw threshold numbers (durations etc).
└── bot/wizard.py                               label_for() - human-readable names.
```

---

## 6. Common pitfalls

- **All mutations go through Telegram.** This page has no Save
  buttons by design. If you find yourself wanting to edit a threshold
  here, message the bot instead. The audit trail relies on commands
  coming from one channel.
- **PDF download is JWT-authenticated.** The link doesn't work in a
  plain `<a href>` because the `Authorization` header is required.
  The page uses `fetch` + `Blob` to bypass that.
- **Filename validation is strict.** The backend rejects any filename
  that isn't `portfolio_*.pdf` or that escapes `REPORT_DIR`. Don't
  rename downloaded files server-side and expect them to be served
  back.
- **Empty `state` is normal on a brand-new install** - it means the
  AlertWorker hasn't run yet. Hit refresh once the worker has had a
  cycle.
- **`audit_limit` caps at 500** - the Override-history table only
  shows 30 anyway, but the Recent-activity feed and the Audit ribbon
  both pull from the same bundle.

---

## 7. Quick recipes

**"Is the bot alive?"**
Top status bar → look at the 🟢/⚪ next to `bot` and the "last audit
Xh ago" caption. If audit age > a few hours and you haven't been
manually quiet, something is up.

**"Why did I get an alert at 03:00?"**
Overview → Active alerts table → find the row by dedup key. Then
Thresholds tab → Override history → see if anyone changed a
threshold around that time.

**"Get yesterday's PDF report."**
Daily Reports → either click Download on the Latest report card or
pick from the select-box at the bottom.

---

## 8. Glossary

- **Calm Score** - one of `RELAX`, `TAKE_A_LOOK`, `ACTIVE_MONITORING`,
  `URGENT_ACTION`. Drives the heartbeat cadence and the colour pill
  used everywhere.
- **Dedup key** - the alert's identity. Same key → same alert (used
  for suppression).
- **Suppression** - "mute alerts matching this dedup key (or whole
  rule) until expiry". Set via Telegram `/stop`.
- **Audit log** - append-only record of every `/set`, `/stop`,
  `/resume`, `/report` action. The source of truth for "what
  changed."
- **DRY_RUN** - `DRY_RUN=1` makes the bot log to stdout instead of
  posting to Telegram. Useful for staging.
