# RTI Portfolio Management - Page Reference

This document describes the **RTI Portfolio Management** page in the
React dashboard. Both user-facing model and implementation.

> Live route: `/rti-portfolio-management`
> File: [`React/src/pages/RtiPortfolioPage.tsx`](../src/pages/RtiPortfolioPage.tsx)
> Backend: `/api/rti/*` ([`backend_api/routes_rti.py`](../../backend_api/routes_rti.py))

---

## 1. What is this page, in plain terms

Two tools in one page, on separate tabs:

- **Analytics** - a historical view of your account equity. One row per
  UTC day, built from `account_snapshots`. Shows BOD / EOD value, daily
  % change, MM% / IM%, BTC / USDT / USDC balances and Total USD AUM,
  plus a one-click CSV export of the full history.
- **Trade Recap** - the normalized Deribit transaction log (trades +
  funding + settlement + deposits + transfers), enriched with FIFO
  matching, RTI IDs, action icons, fees in USD/BTC, premium in USD,
  cashflow, balance change, and your own per-trade comments. With KPI
  cards, filters, CSV export, and an editor to attach a note to any
  row.

Both tabs are read-only against the database with the exception of two
write actions in the Trade Recap tab: **Refresh from Deribit** (re-pull
fresh transactions) and **Save Comment** (per-trade note).

---

## 2. The page in two tabs

### Analytics

| Element | Purpose |
|---|---|
| KPI strip | Latest Available Date + Total Rows |
| **Download Full Equity History CSV** | Dumps the entire daily history (sorted newest first) as CSV |
| **Latest Records** table | The most recent 20 daily snapshots with the full column set |

Columns rendered:

- `Date`
- `BOD Value`, `EOD Value`, `Change BTC` (4 decimals)
- `% Change` (`X.YY%` format)
- `Change $`, `Spot Price`, `% MM`, `% IM`, `BTC Amount`,
  `USDT Amount`, `USDC Amount`, `Total USD (AUM)` (2 decimals each, or
  4 for `BTC Amount` to preserve sats-level precision)

Whatever columns the underlying DataFrame returns are rendered - so if
`shared/data_service.get_account_equity_history` grows new columns they
appear automatically.

### Trade Recap

| Element | Purpose |
|---|---|
| **Refresh from Deribit** | Calls `POST /api/rti/trade-recap/refresh` (days_back=365, cooldown=0). Surfaces new-rows count or "Skipped (cooldown active)" |
| KPI strip | Total Events · Trades · Total Fees ($) · Total Premium ($) |
| Filters | Instrument Type · Action · Instrument · From-date |
| Transaction log table | One row per event, sorted newest first |
| **Download Transaction Log CSV** | The current filtered view as CSV |
| Add / Edit Comment | Pick a row by RTI ID, edit, save - persists to `trade_recap_comments` |

The table renders one event per row with columns: #, RTI ID, Date,
Action (with emoji icon), Direction (badge), Type, Instrument,
Description, Amount, Price, Spot, Premium USD, Fee BTC, Fee USD,
Cashflow, Balance Δ, Position (after), Matched, Comments.

Action icons:

| Action | Icon |
|---|---|
| open | 🟢 open |
| close | 🔴 close |
| adjust | 🟡 adjust |
| expired | ⚫ expired |
| liquidated | 🚨 liquidated |
| funding / settlement | 💰 |
| spot | 💵 spot |
| deposit / withdrawal / transfer | ⬆️ / ⬇️ / ⇄ |

---

## 3. Auth and credentials

- All endpoints are JWT-protected and gated by the
  `RTI_Portfolio_Management` page grant (same trust model as the
  Streamlit page).
- The Refresh-from-Deribit call uses `DERIBIT_CLIENT_ID` /
  `DERIBIT_CLIENT_SECRET` from the backend `.env`. The browser never
  sees those credentials.
- If the creds are missing, the refresh endpoint returns a `502 Bad
  Gateway` with the underlying error; the page surfaces it inline next
  to the Refresh button.

---

## 4. Request / response shapes

### 4.1 `GET /api/rti/equity-history`

```jsonc
{
  "rows": [
    {
      "Date": "2025-12-01",
      "BOD Value": 12.3456,
      "EOD Value": 12.4567,
      "Change BTC": 0.1111,
      "% Change": 0.9,
      "Change $": 5678.0,
      "Spot Price": 99876.0,
      "BTC Amount": 12.34,
      "USDT Amount": 1234.56,
      "USDC Amount": 0,
      "Total USD (AUM)": 1234567.89,
      "% MM": 6.1,
      "% IM": 12.3
    },
    ...
  ],
  "columns": ["Date", "BOD Value", ...],
  "last_date": "2025-12-31",
  "total_rows": 730
}
```

### 4.2 `GET /api/rti/trade-recap`

```jsonc
{
  "available": true,
  "kpis": {
    "total_events": 1234,
    "total_trades": 987,
    "total_fees_usd": 4567.89,
    "total_premium_usd": 123456.78
  },
  "rows": [
    {
      "rti_id": "RTI-101-2026",
      "trade_id": "...",
      "trade_date": "2026-05-20",
      "timestamp_ms": 1747743456000,
      "action": "open",
      "direction": "long",
      "instrument_type": "option",
      "instrument_name": "BTC-30MAY26-100000-C",
      "description": "Open long 1 BTC-30MAY26-100000-C",
      "display_contracts": 1.0,
      "price": 0.0123,
      "spot_price": 99876,
      "premium_usd": 1228.34,
      "fee_btc": 0.00012345,
      "fee_usd": 12.34,
      "realized_pnl": 0,
      "balance_change": -0.0125,
      "position_after": 1.0,
      "matched_with": "",
      "comments": ""
    },
    ...
  ],
  "columns": [...]
}
```

If the table has never been ingested, `available: false` and `rows: []`
- the page renders the "click Refresh from Deribit" prompt instead of
the body.

### 4.3 `POST /api/rti/trade-recap/refresh`

Request (all fields optional):

```jsonc
{ "days_back": 365, "cooldown_minutes": 0 }
```

Response:

```jsonc
{ "new_rows": 42 }
```

`new_rows` interpretation:

- `> 0` - rows inserted
- `0` - up-to-date, nothing new
- `-1` - cooldown active, the call was skipped (the page surfaces a hint)

### 4.4 `POST /api/rti/trade-recap/comment`

Request:

```jsonc
{ "trade_id": "...", "comment": "free text" }
```

Response: `{ "ok": true }`. Persists to `trade_recap_comments` with
`(trade_id, comment, updated_at)` and overwrites on conflict.

---

## 5. File map

### Frontend

```
React/src/
├── pages/RtiPortfolioPage.tsx          The page. Tabs + Analytics tab + Trade Recap tab.
├── api/rti.ts                          Typed axios wrappers for /api/rti/*.
└── components/ui/*, shared/*           Card, Button, Input, Table, Tabs, MetricCard, etc.
```

Key local state inside the page:

- `tab: "analytics" | "recap"` at the page level.
- Trade Recap filters: `instType`, `action`, `instrument`, `dateFrom`.
- Comment editor: `selectedRti`, `commentDraft`.

Filter + sort happen client-side via `useMemo` over the full rows
returned by the backend - no extra round-trip when changing filters.

### Backend

```
backend_api/
└── routes_rti.py                       4 endpoints listed in §4.

shared/
└── data_service.py                     get_account_equity_history()
                                        get_account_equity_history_latest()
                                        get_account_equity_history_last_date()

trade_recap/
├── service.py                          ingest, get_trade_recap, save_trade_comment
├── ingestion.py                        Deribit transaction-log pull + SQLite mirror
├── engine.py                           normalize + FIFO matching + RTI IDs + actions
└── db.py                               trade_recap_comments table + ensure_tables
```

---

## 6. CSV export rules

Both tabs share one client-side CSV helper (`rowsToCsv`):

- Cells containing `"`, `,`, or `\n` are quoted; inner quotes doubled.
- `null` / `undefined` → empty cell.
- Header row is the column list in source order.
- Analytics download uses the **full** equity-history rows, sorted
  newest first.
- Trade Recap download uses the **currently filtered** view (so the
  filters double as a slice tool).

---

## 7. Comment editor

- The select dropdown is populated from the **currently filtered**
  rows' `rti_id` values. Filter first, then pick - the row you want
  has to be in view.
- The textarea pre-populates with the row's existing `comments` value.
- Saving sends `{ trade_id, comment }` to the backend. We use
  `trade_id` (the Deribit row id) as the persistence key, not the
  RTI ID - the RTI ID is for display only and recomputed on every
  recap rebuild.
- After save the trade-recap query is invalidated so the table picks
  up the new comment on the next render.

---

## 8. Common pitfalls

- **Empty page after first load** - means `transaction_log` is empty.
  Click **Refresh from Deribit**.
- **"Skipped (cooldown active)"** - the ingestion service enforces a
  cooldown between fetches to avoid hammering Deribit. The button
  shows this state for visibility. If you really need to force a
  fetch, the backend accepts `cooldown_minutes: 0` (which is what
  the page sends already).
- **Filter dropdowns include "All"** - that's a no-op filter, not a
  literal `All` value in the data. Same goes for the comment-row
  selector (`""` means "none selected").
- **CSV downloads what you see** - the Transaction Log CSV respects
  the active filters. If you want the full log, set all filters to
  All / clear the From date.
- **Comments are keyed by `trade_id`, not by `rti_id`** - re-running
  the FIFO matcher may renumber RTI IDs across rebuilds, but the
  comments stay attached to the underlying Deribit trade row.

---

## 9. Quick recipes

**"How did my equity change vs a month ago?"**

Analytics → Latest Records table. Subtract `Total USD (AUM)` between
the desired rows. For multi-month series download the full CSV.

**"Show me all of last week's option closes."**

Trade Recap → set `From` to last Monday → set `Action = close` →
`Instrument Type = option`. Optionally download the filtered CSV.

**"Annotate a trade with the thesis."**

Trade Recap → make sure your filters keep the trade visible → expand
the Add / Edit Comment card → pick the RTI ID → type → Save.

---

## 10. Glossary

- **RTI ID** - per-event display identifier shaped `RTI-<seq>-<year>`,
  recomputed on every recap rebuild. Use it to refer to a row in a
  conversation; don't rely on it for persistence.
- **trade_id** - the underlying Deribit row identifier. Stable across
  recap rebuilds; used as the persistence key for comments.
- **FIFO matching** - the engine pairs opens with later closes in
  first-in-first-out order and populates `matched_with` + recomputes
  `position_after`.
- **Cashflow** - the realized PnL on a closing row (`0` on opens).
- **Balance Δ** - the net BTC balance change on the event (premium +
  cashflow + fees).
- **Premium USD** - the cash value of the trade (USD equivalent of
  `price * size`).
