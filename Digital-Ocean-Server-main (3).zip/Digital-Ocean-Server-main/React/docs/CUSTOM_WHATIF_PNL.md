# Custom What-If PnL - Page Reference

This document describes the **Custom What-If PnL** sub-tab of the Account
Overview page in the React dashboard. It covers both the user-facing model
(what every control does, what every number means) and the implementation
(file map, request/response shape, the math used on the backend).

> Live route: `/account-overview` → tab **Custom What-If PNL**
> File: [`React/src/components/whatif/CustomWhatIfPnl.tsx`](../src/components/whatif/CustomWhatIfPnl.tsx)
> Backend: `POST /api/stress/whatif` ([`backend_api/routes_stress.py`](../../backend_api/routes_stress.py))

---

## 1. What is this page, in plain terms

The Custom What-If is a **portfolio simulator**. It takes your **live BTC
options + futures book** as it stands right now, lets you change it in any
way - resize positions, flip sides, exclude legs, add hypothetical options
that you don't own yet - and shows what your **PnL curve, greeks, and
projected equity** would look like under that hypothetical portfolio.

It is *not* a trading interface. Nothing here places orders or modifies
your account. Every input is local to the page; refresh and everything
resets to "your live portfolio, untouched".

You use it for things like:

- "If BTC dropped 15% by Friday, what's my PnL?"
- "What if I close half of my long calls?"
- "What if I add a 100k strike put at $40 cost?"
- "What does my delta look like if I flip this short straddle to long?"

---

## 2. The page in four boxes

The page is split into four horizontal sections (top to bottom):

### Row 1 - Three control cards

#### BTC price control
You can either **track the live BTC index price** (default) or **freeze
the price at a value you pick**. Freezing doesn't change pricing - it
re-centres the curve window on that price, so the chart x-axis sweeps
around the frozen price instead of around live spot. Useful for
"what if BTC ends the day at $90k?".

#### Scenario controls (Sim Sliders)
Three independent sliders:
- **IV shift** (vol points): adds N volatility points to every option's
  implied volatility for the simulation. Negative shifts move IV down.
- **Time forward** (days): advances each option's time-to-expiry by N
  days, so theta decay kicks in.
- **Range** (%): how far either side of the centre price the curve
  sweeps. A wider range gives you more chart, less detail near spot.

#### Simulated positions (Hypothetical Manager)
Add option positions you **don't own**. Pick the option type
(call/put), the expiry, the strike, the side (buy/sell), the size, and
the IV at which the option is priced. They show up in the Portfolio
Editor table below with a 🧪 marker. You can add as many as you want
and remove them with the ✕ button.

### Row 2 - PnL Curve (with Account Equity inside)

Full-width card. On the left, three stacked tiles:

- **Live Equity** - your current account equity, in USD. Pulled
  straight from the live account snapshot. Flashes green/red on tick.
- **Scenario Δ vs Now** - how much your equity would change if the
  scenario (BTC price, IV, time, position edits) were realised. This
  is the *change* from your current state, not the absolute scenario
  PnL. Includes a percentage of equity.
- **Projected Equity** - `Live Equity + Scenario Δ`. The number you'd
  have if the scenario plays out. The caption "no double-counting
  unrealized PnL" is a reminder of how the math is built (see
  Section 4).

On the right, the **What-If Payoff Curve** chart itself. The x-axis is
BTC price; the y-axis is portfolio PnL in USD. Break-even points
(where the curve crosses zero) are marked. A vertical line shows the
currently-selected price (live or frozen).

Below the chart: a one-line footer of `Included L/total · IV ±N pts ·
+Md · Break-even $...`.

### Row 3 - Scenario Greeks

A 4-tile strip showing the summed portfolio greeks at the selected
price: **Delta (BTC)**, **Gamma**, **Theta (USD/day)**, **Vega
(USD/pt)**. Each tile colours by sign. Only **included** legs are
counted.

### Row 4 - Portfolio Editor (positions table)

A grouped tree:

```
BTC ▸ Options ▸ <expiry> ▸ <instrument>
BTC ▸ Futures ▸ <expiry> ▸ <instrument>
```

Columns: include-checkbox, Instrument, Side, Size, Avg Price (BTC),
Avg Price (USD), Mark Price (BTC), Mark Price (USD), ROI (PnL %),
PnL @ scenario, Delta, Gamma, Theta, Vega, Reset-row.

Per row:
- **Untick the checkbox** to exclude the leg. The whole row dims, the
  curve and greeks re-sum *instantly* (no backend round-trip), and the
  group counts show `(included/total)`.
- **Click the Side button** (buy/sell pill) to flip the leg's side.
- **Edit the Size cell** to change contract count. Press Enter or
  click away to commit.
- **Reset row** (circular arrow) restores the leg to its live values.
  Only visible when the row has been edited.

Per group (BTC, Options, Futures, every expiry node): a **tri-state
checkbox** on the row. Clicking includes or excludes every leaf below
it in one go. The state shows `all` (checked), `none` (unchecked), or
`some` (indeterminate).

Hypotheticals you added in Row 1 appear under their expiry node, with
a 🧪 marker. If a hypothetical's expiry isn't currently in your live
book, a brand-new expiry group is created on the fly.

---

## 3. What changes when you do X

| Action | What recomputes |
|---|---|
| Untick a leg | Curve, break-even, scenario greeks, scenario Δ - **instant** (no backend call). |
| Re-tick a leg | Same - instant. |
| Edit a size | Curve shape, break-even, greeks - via a backend call (debounced 300 ms). At the live spot itself equity does **not** change (see Section 4). |
| Flip a side | Curve, break-even, greeks - debounced backend call. Equity at live spot doesn't change. |
| Add / remove a hypothetical | Backend call. The new leg appears in the table. |
| Move IV / time / range slider | Backend call. |
| Freeze BTC at a price | Backend call. Curve window shifts; pricing still uses live spot. |
| Live WS push (positions / account / market) | Throttled to once per 2.5 s. Refetches the what-if with the current scenario so prices/marks stay current. |
| Reset Simulation | Clears all overrides, hypotheticals, exclusions, freeze, slider state. Equivalent to a fresh page load. |

---

## 4. The math

This is the part that took the most iteration. Read carefully if you're
debugging "why didn't X change when I did Y".

### 4.1 Per-leg PnL curve

For each leg we compute a payoff curve as

```
leg_pnl(p) = anchor + scenario_delta(p)
```

where:
- `anchor = total_profit_loss * spot` (the leg's **current** unrealized
  PnL converted to USD).
- `scenario_delta(p)` is the *change* in the leg's PnL when BTC moves to
  price `p` (with the selected IV shift, time forward, and pricing
  method). At `p == spot` and no IV/time shift, `scenario_delta = 0`.

So at the live BTC price, `leg_pnl(spot) = anchor`. That is the leg's
contribution to your current unrealized PnL, by definition.

### 4.2 Total scenario PnL

Sum over the included legs:

```
scenarioPnl = Σ leg_pnl(p) at the evaluation price
            = Σ anchor + Σ scenario_delta
            = current_pnl_usd + total_scenario_delta
```

`current_pnl_usd` is returned in `response.context.current_pnl_usd`.

### 4.3 Why "Scenario Δ vs Now" is not just `scenarioPnl`

This is the trap. Live equity already includes your current unrealized
PnL (`current_pnl_usd`), because Deribit marks positions to market
continuously. So if you display `Projected Equity = Live + scenarioPnl`,
you double-count `current_pnl_usd`. The card actually computes:

```
scenario_change   = scenarioPnl - current_pnl_usd
projected_equity  = liveEquity + scenario_change
```

Which equals:

```
projected_equity = liveEquity + Σ scenario_delta
```

i.e. live equity adjusted by the *future* change only, not double
counting today's PnL.

### 4.4 Why resizing a position **does not** change equity at the live BTC price

This is the most-asked question. Walk through it:

1. You change a leg's size from `S0` to `S1`. The backend interprets
   this as "transact at the current mark price":
   - Adding contracts → new contracts enter at mark, so they have zero
     unrealized PnL.
   - Closing contracts → those contracts settle at mark; their PnL is
     **realised into cash**, equity is unchanged at that instant.
2. The leg's `total_profit_loss` (the anchor) is therefore left
   unchanged. Only `size` and `direction` are overridden in the
   position dict passed to `run_pnl_curve`.
3. At the live BTC price, `scenario_delta = 0` for every leg. So:

   ```
   scenarioPnl = Σ anchor = current_pnl_usd
   scenario_change = scenarioPnl - current_pnl_usd = 0
   projected_equity = live + 0 = live
   ```

   Equity is unchanged. **That is the correct answer** for "I bought
   N more contracts at the mark and BTC didn't move". You haven't
   gained or lost anything yet.
4. Where the resize **does** show up:
   - The **curve shape** (slope, curvature, break-even) changes,
     because the scenario_delta away from spot scales with size.
   - The **per-leg greeks** (Δ, Γ, Θ, V) change linearly with size.
   - If you **freeze BTC** at a different price, or move **time** or
     **IV**, the scenario delta is no longer zero, and the new size is
     reflected in the equity numbers.

This is the realistic model: a paper transaction at mark doesn't move
your equity; only subsequent market changes do.

### 4.5 Frozen-BTC behaviour

Frozen-BTC is purely a chart/eval-point shift, **not** a re-pricing.

- All Black-Scholes pricing in `run_scenario` uses `spot = live BTC
  index`. We never re-imply IV at a fake spot - that would corrupt the
  implied vols (the leg's mark price was observed at the live spot).
- The frozen value is passed as `eval_price`. The endpoint computes
  asymmetric `pct_min`/`pct_max` so the curve window is re-centred on
  the frozen price. Greeks and `pnl_at_spot` are reported at the
  curve point nearest the frozen price.

This bug was introduced once (calling `run_pnl_curve` with `spot =
frozen_price`) and explicitly fixed. **Do not re-undo it.**

### 4.6 Per-leg greeks (finite difference)

When `with_greeks=True` (the React app always passes this for the
what-if), the backend computes greeks per leg by finite difference on
each leg's curve:

- `delta = (pnl[si+1] - pnl[si-1]) / (price[si+1] - price[si-1])`
- `gamma = (pnl[si+1] - 2*pnl[si] + pnl[si-1]) / h^2`
- `theta = (run_scenario at days+1, centre) - centre_pnl`
- `vega  = (run_scenario at iv+1, centre) - centre_pnl`

These are **not** closed-form Black-Scholes greeks. They are
consistent with the displayed PnL curve by construction, which is
what the simulator panel needs. Two extra `run_scenario` calls are
made per request to compute theta and vega; the cost is one
finite-difference width on either side of the centre.

### 4.7 Hypotheticals

A hypothetical option (`option_type`, `expiry`, `strike`, `side`,
`size`, `iv_pct`) is converted in
`shared/stress_scenarios_service.py:build_hypothetical_option` into a
position dict shaped like a real Deribit position, with:
- `total_profit_loss = 0` (no historical PnL)
- a synthetic `instrument_name` like `BTC-30MAY26-100000-C`
- `mark_price` derived from the entered IV at live spot

It is appended to the position list before pricing. From there on the
math is identical to a real leg.

If a hypothetical's expiry doesn't exist in your live book, the React
tree creates a brand-new `Options ▸ <expiry>` node for it.

---

## 5. Request / response shape

### 5.1 Request - `POST /api/stress/whatif`

```jsonc
{
  "range_pct": 50,           // ±% sweep around centre (default 50)
  "points": 121,             // curve resolution
  "iv_points": 0,            // IV shift in vol points
  "days_forward": 0,         // time forward in days
  "spot_override": null,     // null = track live spot; number = freeze at this price
  "overrides": [
    {
      "instrument_name": "BTC-30MAY26-100000-C",
      "size": 5.0,           // absolute contracts (positive)
      "side": "buy"          // "buy" | "sell"
    }
  ],
  "hypotheticals": [
    {
      "option_type": "C",    // "C" | "P"
      "expiry": "2026-05-30",
      "strike": 100000,
      "side": "buy",
      "size": 1.0,
      "iv_pct": 60.0
    }
  ]
}
```

`overrides[*].instrument_name` must match a live position name exactly
for the override to apply. Hypotheticals always create new legs - they
never modify existing ones.

### 5.2 Response

```jsonc
{
  "context": {
    "btc_index_price": 100000,
    "equity_usd": 1234567.89,
    "position_count": 12,
    "hypothetical_count": 1,
    "current_pnl_usd": -1234.5,    // anchor sum across real legs
    "iv_points": 0,
    "days_forward": 0,
    "live_spot": 100000,           // always the live BTC index
    "spot_frozen": false
  },
  "curve": [
    { "btc_pct": -50, "btc_price": 50000, "pnl_usd": -..., "pnl_pct": -..., "severity": "..." },
    ...
    { "btc_pct": +50, "btc_price": 150000, "pnl_usd": ..., "pnl_pct": ... }
  ],
  "break_even": [98765, 101234],
  "legs": [
    {
      "instrument_name": "BTC-30MAY26-100000-C",
      "kind": "option",
      "size": 5.0,
      "is_hypothetical": false,
      "curve": [{ "btc_price": ..., "pnl_usd": ... }, ...],
      "pnl_at_spot": 1234.5,
      "break_even": [...],
      "greeks": { "delta": 0.42, "gamma": 0.00012, "theta": -5.6, "vega": 78.9 }
    },
    ...
  ]
}
```

Legs are returned sorted by `abs(pnl_at_spot)` descending.

---

## 6. File map

### Frontend

```
React/src/
├── pages/AccountOverviewPage.tsx        Hosts the two sub-tabs (Live Portfolio / Custom What-If)
├── components/whatif/
│   ├── CustomWhatIfPnl.tsx              Page container. Holds all sim state, builds the request,
│   │                                    triggers React-Query, lays out the four rows.
│   ├── BtcPriceControls.tsx             Three synced controls for the BTC anchor (live/freeze).
│   ├── SimSliders.tsx                   IV / time / range sliders.
│   ├── HypotheticalManager.tsx          Add/remove simulated options form.
│   ├── AccountEquityCard.tsx            Live equity / scenario Δ / projected equity tiles.
│   │                                    Has `embedded` + `layout="vertical"` modes.
│   ├── ScenarioGreeksPanel.tsx          Summed greeks card (Δ Γ Θ V).
│   └── WhatIfPositionsTable.tsx         Tree-grouped position editor (BTC ▸ Kind ▸ Expiry ▸ Leg).
│                                        Per-row checkbox + group tri-state checkbox, editable
│                                        size/side, hypothetical badge, ROI/avg/mark columns,
│                                        per-row reset.
├── components/shared/PnlCurveChart.tsx  Recharts chart with break-even markers.
├── lib/whatifCalc.ts                    Client-side helpers: sumCurve, sumGreeks, zeroCrossings.
├── api/whatif.ts                        Typed POST to /api/stress/whatif.
└── hooks/useDebounce.ts                 300 ms debounce on the request payload.
```

### Backend

```
backend_api/
└── routes_stress.py                     POST /api/stress/whatif. Reads live positions, applies
                                         the overrides, builds hypotheticals, calls run_pnl_curve.

shared/
└── stress_scenarios_service.py          run_pnl_curve + build_hypothetical_option. Anchors,
                                         per-leg finite-difference greeks, frozen-BTC handling.

portfolio_analysis_AI_Agent/tools/analysis/
└── stress_scenarios.py                  Pure-math run_scenario (Black-Scholes per leg, IV imply,
                                         theta / vega via re-price).
```

---

## 7. State, debouncing, and live refresh

All simulation state lives in `CustomWhatIfPnl.tsx`. Five pieces:

```ts
const [excluded, setExcluded]         = useState<Set<string>>(...);
const [overrides, setOverrides]       = useState<Record<string, RowOverride>>(...);
const [hypotheticals, setHypotheticals] = useState<HypoItem[]>(...);
const [sim, setSim]                   = useState<SimParams>(DEFAULT_SIM);
const [btcOverride, setBtcOverride]   = useState<number | null>(null);
```

`reqInputs` is a `useMemo` that assembles the request body from these.
`useDebounce(reqInputs, 300)` gates how often the query refires - so
rapid slider scrubs collapse into one backend call.

The React Query `queryKey` is `["whatif", JSON.stringify(debouncedReq)]`,
so any change to the debounced inputs triggers a fresh fetch and the
last response is shown until the new one lands.

Three WebSocket hooks listen to live data:

```ts
useWebSocket("/ws/positions", nudge);
useWebSocket("/ws/account",   nudge);
useWebSocket("/ws/market",    nudge);
```

`nudge()` invalidates the `whatif` cache with a 2.5 s minimum interval,
so live data refreshes the projection while you have it open.

The live positions map (for avg/mark prices in the table) is a
separate query - `["positions-live"]` - polling every 5 s.

Include/exclude is computed **client-side** via `sumCurve` / `sumGreeks`
/ `zeroCrossings` against the per-leg data already in the response.
Toggling a checkbox is therefore instant - no backend round-trip
needed.

---

## 8. Common pitfalls (read before debugging)

- **Resizing a position doesn't move equity at the live spot.** That
  is correct. See Section 4.4. The curve and greeks *do* change.
- **`pnl_at_spot` per leg is the leg's anchor**, not the leg's
  scenario delta. If you want to see "PnL change under scenario",
  subtract `current_pnl_usd / N_legs` (or use the equity card's
  Scenario Δ vs Now, which already does this for the whole
  portfolio).
- **Frozen-BTC pricing.** Black-Scholes always uses live spot.
  Freezing only re-centres the curve window. Don't pass `spot =
  frozen_price` to `run_pnl_curve` - that breaks implied vols.
- **Hypothetical expiries get their own group.** If you added an
  option for an expiry you don't currently trade, look for the new
  expiry node in the table - it's there, just collapsed.
- **WS-driven refetch is throttled to 2.5 s.** This is deliberate -
  market ticks could otherwise hammer the endpoint while you're
  building a scenario.
- **`overrides[].instrument_name` must match exactly.** A typo means
  the override silently does nothing.

---

## 9. Quick recipes

**"What if BTC drops 15% by Friday and IV pops 10 vols?"**

1. Sim Sliders → Time forward = 5, IV shift = +10.
2. BTC price control → Freeze BTC at `live_spot * 0.85`.
3. Read **Scenario Δ vs Now** in the equity card and the **break-even**
   in the chart footer.

**"What if I close half my long calls?"**

1. Find each long call row in the Portfolio Editor.
2. Halve the **Size** cell, press Enter.
3. The chart steepness drops; per-leg greeks halve; equity at live
   spot is unchanged (you closed at mark - no instantaneous PnL).
4. Drag the BTC price slider to see what your equity looks like at
   other prices.

**"What if I add a long 100k put for protection?"**

1. Hypothetical Manager → Put, expiry, strike 100000, side buy,
   size 1, IV ~60.
2. The new leg appears as `🧪 BTC-...-100000-P` under
   `Options ▸ <expiry>`.
3. Watch the chart's downside shape flatten; theta cost shows up
   in Scenario Greeks.

---

## 10. Glossary

- **Anchor** - a leg's current unrealized PnL converted to USD,
  used as the y-offset of its PnL curve.
- **Scenario delta** - the change in a leg's PnL caused by the
  scenario inputs (BTC move, IV shift, time forward). Zero at the
  live spot when no IV / time shift is applied.
- **Live spot** - the current BTC index price as reported by the
  backend (`/ws/market` / `redis_live.get_market_live`).
- **Frozen BTC** - a user-chosen evaluation price that re-centres
  the curve window. Pricing math still uses live spot.
- **Included leg** - a leg whose include-checkbox is ticked. Excluded
  legs contribute nothing to curve / greeks / Scenario Δ.
- **Hypothetical** - a position you don't actually own but want in
  the scenario. Has `is_hypothetical: true` on the wire and a 🧪
  marker in the UI. Initial PnL is zero.
- **Override** - a `(size, side)` replacement applied to an existing
  live leg. Conceptually: "if I transacted at the current mark to
  arrive at this size/side."
