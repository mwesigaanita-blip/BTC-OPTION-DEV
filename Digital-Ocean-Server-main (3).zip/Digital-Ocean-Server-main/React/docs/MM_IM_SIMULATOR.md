# MM / IM Simulator - Page Reference

This document describes the **MM / IM Simulator** page in the React
dashboard. It covers both the user-facing model (every section, every
input, what every number means) and the implementation (file map,
request/response shape, the math used on the backend).

> Live route: `/mm-im-simulator`
> File: [`React/src/pages/MmImSimulatorPage.tsx`](../src/pages/MmImSimulatorPage.tsx)
> Backend: `/api/mm-im/*` ([`backend_api/routes_mm_im.py`](../../backend_api/routes_mm_im.py))

---

## 1. What is this page, in plain terms

The MM / IM Simulator answers the question: **"if I adjusted my open
Deribit positions today - reduced one, increased another, opened a new
option leg, sold a perpetual - what would my Initial Margin (IM%) and
Maintenance Margin (MM%) look like *after* the change?"**

It does this **without placing any orders**. It uses Deribit's
`private/simulate_portfolio` endpoint, which is a server-side dry-run:
you describe the hypothetical position set, Deribit replies with the
margin numbers your account *would* have if those positions were
real.

Use this when you want to:

- Quickly check "can I sell this call without blowing my MM%?"
- See the IM% / MM% impact of closing half a losing position.
- Stack several hypothetical adjustments + new trades together and
  read the combined margin impact, per currency.

It is **not** a trading interface and **not** a PnL simulator (use the
[Custom What-If PnL](CUSTOM_WHATIF_PNL.md) tab on Account Overview for
that). This page is specifically about **margin** (IM, MM), not P&L.

---

## 2. The page in seven sections

The page is a linear stack of cards labelled 1 through 7.

### Section 1 - Current Positions

A flat table of every open position across the three supported
currencies (**BTC, USDT, USDC**), with: currency, instrument, kind
(option / future / perp), direction (buy / sell), size, mark, index,
delta, gamma, vega, theta.

Loaded on demand via the **Load Current Positions** button in the page
header. Reloading wipes the adjustments/new-trades you'd built up.

### Section 2 - Existing Position Adjustments

Per position, three controls:

- **Action**: `no change` | `decrease` | `increase`
- **Amount**: the contract count to add or remove (must be > 0 when
  action is decrease/increase).
- **Mark / Index**: read-only sanity values for the row.

A `decrease` amount larger than the current size produces a validation
error that is surfaced in Section 4 and blocks the Run button.

If action stays at `no change` the row contributes nothing to the
simulation, regardless of the amount field.

### Section 3 - Add New Simulated Trades

Two sub-sections.

#### 3A. New Option Trades

Each row picks:

- **Expiry** - from the Deribit option chain loaded in Section 1.
- **Strike** - filtered to the strikes available for the chosen
  expiry.
- **Type** - call or put.
- **Side** - long or short.
- **Amount** - contract count.

As soon as expiry + strike + type are picked the page:

1. Calls `POST /api/mm-im/find-option` to resolve the Deribit
   instrument name (`BTC-30MAY26-100000-C`).
2. Calls `GET /api/mm-im/quote/{name}` to fetch a live bid / ask /
   mark / index / IV preview.

Both are surfaced inline so you can see what you're about to trade
before submitting the simulation.

#### 3B. New Perpetual Trades

Side + amount, against `BTC-PERPETUAL` (fixed). The quote preview
loads on row mount.

You can add multiple rows of each. Remove any row with its **Remove**
button.

### Section 4 - Simulation Preview

Two side-by-side tables that show the **cleaned, validated** payload
that will be sent to the backend: selected adjustments and selected
new trades. Any validation errors (e.g. decrease > size) are listed in
a red box below.

### Section 5 - Run Simulation

A single button. Disabled while:

- The simulation is in flight,
- There are validation errors,
- Positions haven't been loaded yet, or
- No adjustments / new trades are queued.

Hitting Run posts to `POST /api/mm-im/simulate`. The backend calls
Deribit twice per currency (`private/simulate_portfolio` for the
*current* book, then again for the *adjusted + new-trades* book) and
returns the diff.

### Section 6 - Results

For each currency that has positions before *or* after:

- **MetricCards**: IM%, MM%, current position count, simulated
  position count. The IM/MM cards colour the delta:
  - **Green** when the % *decreases* (better - lower margin usage).
  - **Red** when the % *increases* (worse).
  - Neutral when unchanged.
- **Before / After / Change** table for IM%, MM%, and Delta.

If the simulation errors out (validation or Deribit failure), the
errors are surfaced here as a single red banner.

### Section 7 - Raw JSON

Per currency, two collapsible blocks (`Raw Before` / `Raw After`)
containing the full Deribit response. Use for debugging or when you
need a field the page doesn't surface (initial_margin_btc,
projected_maintenance_margin, etc.).

---

## 3. Auth and credentials

- The endpoints are JWT-protected and gated by the `MM_IM_Simulator`
  page grant (same trust model as the Streamlit page).
- Deribit credentials (`DERIBIT_CLIENT_ID`, `DERIBIT_CLIENT_SECRET`)
  live in the backend `.env`. The browser never holds them.
- If those env vars are missing, `/api/mm-im/positions` and
  `/api/mm-im/simulate` return `503 Service Unavailable` with a
  clear error - that error renders in the page.

---

## 4. Request / response shapes

### 4.1 `GET /api/mm-im/positions`

```jsonc
{
  "positions": [
    {
      "currency": "BTC",
      "instrument_name": "BTC-30MAY26-100000-C",
      "kind": "option",
      "direction": "buy",
      "size": 1.5,
      "mark_price": 0.0123,
      "index_price": 99876,
      "delta": 0.42, "gamma": 0.00012, "vega": 78.9, "theta": -5.6
    },
    ...
  ],
  "option_chain": {
    "expiries": [
      { "expiration_timestamp": 1748563200000, "strikes": [80000, 85000, 90000, ...] },
      ...
    ]
  }
}
```

### 4.2 `POST /api/mm-im/find-option`

Request:

```jsonc
{ "expiration_timestamp": 1748563200000, "strike": 100000, "option_type": "call" }
```

Response:

```jsonc
{ "instrument_name": "BTC-30MAY26-100000-C" }
```

### 4.3 `GET /api/mm-im/quote/{instrument_name}`

```jsonc
{
  "instrument_name": "BTC-30MAY26-100000-C",
  "bid_price": 0.0120, "ask_price": 0.0126,
  "mark_price": 0.0123, "index_price": 99876,
  "mark_iv": 56.7
}
```

### 4.4 `POST /api/mm-im/simulate`

Request:

```jsonc
{
  "adjustments": [
    { "instrument_name": "BTC-30MAY26-100000-C", "action": "decrease", "amount": 0.5 }
  ],
  "new_trades": [
    { "instrument_name": "BTC-30MAY26-95000-P", "side": "long",  "amount": 1.0 },
    { "instrument_name": "BTC-PERPETUAL",       "side": "short", "amount": 0.20 }
  ]
}
```

Response (truncated):

```jsonc
{
  "ok": true,
  "errors": [],
  "current_positions": [...],
  "simulated_positions": [...],
  "priced_new_trades": [
    { "instrument_name": "BTC-30MAY26-95000-P", "side": "long", "amount": 1.0, "entry_price": 0.011 }
  ],
  "results_by_currency": {
    "BTC": {
      "before": { "im_pct": 12.3, "mm_pct": 6.1, "delta": 0.42 },
      "after":  { "im_pct": 9.8,  "mm_pct": 4.7, "delta": 0.18 },
      "change": { "im_pct": -2.5, "mm_pct": -1.4, "delta": -0.24 },
      "current_positions":   [...],
      "simulated_positions": [...],
      "raw_before": { ... full Deribit response ... },
      "raw_after":  { ... full Deribit response ... }
    },
    "USDT": { ... },
    "USDC": { ... }
  }
}
```

On error (validation or Deribit), the shape is:

```jsonc
{
  "ok": false,
  "errors": ["Adjustment error for BTC-...: decrease amount 5 exceeds current size 3."],
  "current_positions": [],
  "simulated_positions": [],
  "results_by_currency": {}
}
```

---

## 5. File map

### Frontend

```
React/src/
├── pages/MmImSimulatorPage.tsx          The whole page - all seven sections + result rendering.
├── api/mmIm.ts                           Typed axios wrappers for /api/mm-im/*.
└── components/ui/*, shared/*             Buttons, Cards, MetricCard, Table, Badge, etc.
```

The page keeps three buckets of local state:

- `adjustments: Record<instrument_name, AdjForm>` - one form row per
  current position.
- `optionTrades: OptionTradeForm[]` - dynamic list, each row resolves
  its instrument and fetches a quote on (expiry, strike, type)
  change.
- `perpTrades: PerpTradeForm[]` - dynamic list.

A `useMemo` over the three buckets produces the cleaned `Adjustment[]`
and `NewTrade[]` arrays plus a `string[]` of validation errors. The
Run button consumes them; the Preview section displays them.

### Backend

```
backend_api/
└── routes_mm_im.py                      All four endpoints. Wraps shared/simulation_service.

shared/
└── simulation_service.py                Deribit REST orchestration:
                                         - fetch_current_positions_for_simulation
                                         - get_option_chain_selection_data
                                         - find_option_instrument
                                         - fetch_instrument_quote
                                         - run_portfolio_simulation_compare
                                           (calls Deribit's `private/simulate_portfolio`
                                            twice, computes the diff)
```

---

## 6. Validation rules

These live on the frontend (immediate feedback) **and** are enforced
by the backend via `validate_adjustments` + `validate_new_trades`:

- Adjustment with action != "no change" must have amount > 0.
- Decrease amount can't exceed current size.
- New option trade must resolve to a real Deribit instrument.
- New trade amount must be > 0.

Frontend validation errors block the Run button. Backend errors come
back as `{ ok: false, errors: [...] }` and are surfaced in Section 6.

---

## 7. Quick recipes

**"Can I close half my big call without my MM% going over 80%?"**

1. Load Current Positions.
2. Find the call in Section 2. Set Action = `decrease`, Amount = (half
   of current size).
3. Run. Check the BTC MM% After in Section 6 - the delta will be
   green if the close lowered your margin usage (which it should).

**"What would buying a 95k put for protection do to my IM?"**

1. Load Current Positions.
2. In Section 3A, click **Add Option Trade**.
3. Pick the expiry, set Strike = 95000, Type = put, Side = long,
   Amount = 1.
4. Sanity-check the resolved instrument and quote that appears below
   the row.
5. Run. The IM% delta will turn positive (worse) - that's the cost
   of the protection in margin terms.

**"What does a -0.5 BTC perp short do to my delta?"**

1. Section 3B → Add Perpetual Trade → side = short, amount = 0.5.
2. Run. Section 6's BTC block shows Delta Before / After / Change.

---

## 8. Common pitfalls (read before debugging)

- **Reloading positions wipes all your form state.** The page
  intentionally resets every adjustment row to "no change" and clears
  new-trade rows on a successful reload, because the underlying
  instrument list may have changed.
- **The Run button is disabled until you've queued at least one real
  change.** "Action = no change" rows and rows with amount = 0 don't
  count. If Run stays disabled, check Section 4's Preview tables - if
  they're empty, the backend would have nothing to simulate.
- **A 503 from `/api/mm-im/positions`** means the backend can't see
  Deribit credentials. Set `DERIBIT_CLIENT_ID` and
  `DERIBIT_CLIENT_SECRET` in the server `.env` and restart
  `backend_api`.
- **Lower IM% / MM% is better.** The page colours the *change*
  green when the number decreases, red when it increases. Don't read
  green-positive as "PnL went up" - this is a margin metric.
- **Currencies with no positions are omitted.** If you only hold BTC,
  Section 6 will only show BTC. That's expected.
- **`private/simulate_portfolio` is rate-limited by Deribit.** Don't
  spam-click Run; one simulation is two Deribit calls per currency.

---

## 9. Glossary

- **IM (Initial Margin)** - the margin Deribit *requires* you to post
  to open / hold positions. IM% = IM / equity.
- **MM (Maintenance Margin)** - the margin floor below which Deribit
  liquidates. MM% = MM / equity. MM > 100% means liquidation.
- **`simulate_portfolio`** - Deribit's server-side endpoint that
  accepts a hypothetical position set and returns the margin numbers
  *as if* those positions were real. No orders are placed.
- **Adjustment** - a modification to an *existing* position
  (`no change` / `decrease` / `increase` by an amount).
- **New Trade** - a fresh leg added on top of the (possibly adjusted)
  current book.
- **Priced new trade** - a new trade with an `entry_price` attached by
  the backend from the live quote at submit time.
- **Currency** - BTC / USDT / USDC. Each is margined independently on
  Deribit; the simulator runs a separate before/after for each.
