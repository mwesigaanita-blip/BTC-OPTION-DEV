"""Ensure plain ``pytest`` (without ``python -m``) can import top-level
packages like ``portfolio_analysis_AI_Agent``, ``backend_api``, ``shared``.

Pytest's own rootdir discovery does not put the project root on
``sys.path``; ``python -m pytest`` does, which is why running it that way
worked but bare ``pytest`` did not. Prepending here is idempotent.
"""
from __future__ import annotations

import sys
from pathlib import Path

_PROJECT_ROOT = Path(__file__).resolve().parent
if str(_PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(_PROJECT_ROOT))
