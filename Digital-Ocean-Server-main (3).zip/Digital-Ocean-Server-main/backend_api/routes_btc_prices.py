"""BTC daily price history routes - wraps the SQLite `btc_prices` table."""
from __future__ import annotations

import io
import logging
import sqlite3

import pandas as pd
from fastapi import APIRouter, Depends, Query
from fastapi.responses import StreamingResponse

from backend_api.auth_jwt import require_page
from shared.data_service import (
    get_btc_prices_full,
    get_btc_prices_last_date,
    get_btc_prices_latest,
)
from shared.db_paths import MARKET_DATA_DB

log = logging.getLogger("backend-api.btc-prices")
router = APIRouter(prefix="/api/btc-prices", tags=["btc-prices"])

_PAGE = "BTC_Prices"


def _clean(rec: dict) -> dict:
    out: dict = {}
    for k, v in rec.items():
        if v is None:
            out[k] = None
        elif isinstance(v, float) and not pd.notna(v):
            out[k] = None
        elif hasattr(v, "item"):
            try:
                out[k] = v.item()
            except Exception:
                out[k] = v
        else:
            out[k] = v
    return out


@router.get("/summary")
def summary(user: dict = Depends(require_page(_PAGE))) -> dict:
    """Latest row + last date + total row count."""
    last_date = get_btc_prices_last_date()
    latest_df = get_btc_prices_latest(limit=1)
    latest = None
    if latest_df is not None and not latest_df.empty:
        latest = _clean(latest_df.iloc[0].to_dict())
    total = 0
    try:
        with sqlite3.connect(str(MARKET_DATA_DB)) as conn:
            total = int(
                conn.execute("SELECT COUNT(*) FROM btc_prices").fetchone()[0] or 0
            )
    except Exception:  # pragma: no cover - table missing
        log.warning("btc_prices count failed", exc_info=True)
    return {"last_date": last_date, "total_rows": total, "latest": latest}


@router.get("/series")
def series(
    from_date: str | None = Query(default=None, alias="from"),
    to_date: str | None = Query(default=None, alias="to"),
    user: dict = Depends(require_page(_PAGE)),
) -> dict:
    """Daily OHLCV rows for an optional date range (ASC by date)."""
    df = get_btc_prices_full()
    if df is None or df.empty:
        return {"rows": []}
    if from_date:
        df = df[df["date"] >= from_date]
    if to_date:
        df = df[df["date"] <= to_date]
    df = df.sort_values("date").reset_index(drop=True)
    return {"rows": [_clean(r) for r in df.to_dict("records")]}


@router.get("/export.csv")
def export_csv(user: dict = Depends(require_page(_PAGE))) -> StreamingResponse:
    """Full BTC daily history as CSV (newest first, matching Streamlit)."""
    df = get_btc_prices_full()
    csv = (
        df.to_csv(index=False)
        if df is not None and not df.empty
        else "date,open,high,low,close,change,percent_change,volume\n"
    )
    return StreamingResponse(
        io.BytesIO(csv.encode("utf-8")),
        media_type="text/csv",
        headers={"Content-Disposition": 'attachment; filename="btc_prices_full.csv"'},
    )
