from __future__ import annotations
import os
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]
import dotenv
dotenv.load_dotenv(REPO_ROOT / ".env")
# You said you moved the DB into data/
DATA_DIR = Path(os.getenv("DATA_DIR", str(REPO_ROOT / "data"))).resolve()
DATA_DIR.mkdir(parents=True, exist_ok=True)

DB_PATH = Path(os.getenv("DB_PATH", str(DATA_DIR / "btc_trading.sqlite"))).resolve()

# API auth (optional now; recommended later behind NGINX + token)
API_BEARER_TOKEN = os.getenv("API_BEARER_TOKEN", "")

# Scheduler interval
REFRESH_INTERVAL_SECONDS = int(os.getenv("REFRESH_INTERVAL_SECONDS", "30"))
