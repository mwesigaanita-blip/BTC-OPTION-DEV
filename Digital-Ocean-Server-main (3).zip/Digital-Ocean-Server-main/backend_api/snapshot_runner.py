# backend_api/snapshot_runner.py

import logging
from datetime import datetime, timezone

log = logging.getLogger("snapshot.runner")


def run_snapshot(*, days_ahead: int = 1000) -> dict:
    """
    Thin wrapper around the snapshot pipeline, callable from the scheduler
    or from a manual trigger.
    """
    started_at = datetime.now(timezone.utc)

    try:
        from multi_agent_system.snapshot_pipeline import run_snapshot_pipeline

        result = run_snapshot_pipeline(days_ahead=days_ahead)
    except Exception as exc:
        log.exception("Snapshot pipeline failed: %s", exc)
        return {
            "error": str(exc),
            "started_at_utc": started_at.strftime("%Y-%m-%dT%H:%M:%SZ"),
            "finished_at_utc": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        }

    finished_at = datetime.now(timezone.utc)
    result["started_at_utc"] = started_at.strftime("%Y-%m-%dT%H:%M:%SZ")
    result["finished_at_utc"] = finished_at.strftime("%Y-%m-%dT%H:%M:%SZ")

    log.info("Snapshot run completed: %s", {
        "rows_written": sum(result.get("files_written", {}).values()),
        "instruments": result.get("instruments_total", 0),
        "duration_s": result.get("duration_seconds", 0),
    })

    return result
