"""Account data routes - thin wrappers over `shared/*` readers.

Live WS->Redis snapshot is preferred; falls back to the SQLite snapshot when
the collector is down or stale - exactly the logic in `Account_Overview.py`.
"""
from __future__ import annotations

import logging

from fastapi import APIRouter, Depends

from shared.data_service import (
    get_account_equity_history,
    get_account_greeks_today,
    get_account_today,
    get_vol_metrics_today,
)
from shared.redis_live import get_account_greeks_live, get_account_live

from backend_api.auth_jwt import require_page

log = logging.getLogger("backend-api.account")

router = APIRouter(prefix="/api/account", tags=["account"])

_PAGE = "Account_Overview"


@router.get("/overview")
def overview(user: dict = Depends(require_page(_PAGE))) -> dict:
    """Assembled account payload + portfolio greeks, live or snapshot."""
    live, updated_at = get_account_live()
    if live is not None:
        greeks, _ = get_account_greeks_live()
        return {
            "source": "live",
            "updated_at": updated_at,
            "account": live,
            "greeks": greeks,
        }
    snap, snap_updated = get_account_today()
    greeks, _ = get_account_greeks_today()
    return {
        "source": "snapshot",
        "updated_at": snap_updated,
        "account": snap,
        "greeks": greeks,
    }


@router.get("/vol-metrics")
def vol_metrics(user: dict = Depends(require_page(_PAGE))) -> dict:
    """Volatility / forecast metrics (SQLite snapshot path)."""
    payload, _images, updated_at = get_vol_metrics_today()
    return {"updated_at": updated_at, "vol": payload}


@router.get("/equity-history")
def equity_history(user: dict = Depends(require_page(_PAGE))) -> dict:
    """Equity % change over daily windows, from the account_snapshots history.

    Snapshots are daily, so windows are 1d / 7d / 30d.
    """
    empty = {"current_usd": None, "as_of": None, "changes": {}}
    try:
        df = get_account_equity_history()
    except Exception:  # pragma: no cover - history is best-effort
        log.warning("equity_history failed", exc_info=True)
        return empty
    if df is None or df.empty or "Total USD (AUM)" not in df.columns:
        return empty

    aum = [float(x or 0.0) for x in df["Total USD (AUM)"].tolist()]
    dates = [str(x) for x in df["Date"].tolist()]
    if not aum:
        return empty
    cur = aum[-1]

    def _pct(n: int):
        if len(aum) > n:
            base = aum[-1 - n]
            if base:
                return round((cur - base) / base * 100.0, 2)
        return None

    return {
        "current_usd": cur,
        "as_of": dates[-1] if dates else None,
        "changes": {"1d": _pct(1), "7d": _pct(7), "30d": _pct(30)},
    }
