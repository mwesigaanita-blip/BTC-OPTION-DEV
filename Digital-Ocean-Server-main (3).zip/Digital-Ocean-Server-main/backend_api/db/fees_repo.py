# backend_api/db/fees_repo.py
from __future__ import annotations

import sqlite3
from datetime import datetime, timezone
from typing import Any, Optional, List, Dict

from shared.db_paths import TRADING_DB as DB_PATH

print(f"[DB] Using {DB_PATH} in {__file__}", flush=True)


def _utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def get_conn() -> sqlite3.Connection:
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    return conn


def ensure_fee_tables() -> None:
    """
    Stores fee events (trade fills fees) idempotently.
    """
    with get_conn() as conn:
        conn.execute("""
        CREATE TABLE IF NOT EXISTS fee_events (
          id INTEGER PRIMARY KEY AUTOINCREMENT,

          source TEXT NOT NULL DEFAULT 'deribit',
          trade_id TEXT,
          order_id TEXT,
          instrument_name TEXT,
          side TEXT,

          fee_currency TEXT,
          fee_amount REAL NOT NULL,

          price REAL,
          amount REAL,
          timestamp_ms INTEGER NOT NULL,

          fee_usd REAL,
          index_price_usd REAL,

          inserted_at_utc TEXT NOT NULL,
          notified_telegram INTEGER NOT NULL DEFAULT 0,

          UNIQUE(source, trade_id) ON CONFLICT IGNORE
        );
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_fee_events_ts ON fee_events(timestamp_ms);")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_fee_events_notified ON fee_events(notified_telegram, timestamp_ms);")


def get_latest_fee_timestamp_ms() -> Optional[int]:
    with get_conn() as conn:
        row = conn.execute("SELECT MAX(timestamp_ms) AS mx FROM fee_events;").fetchone()
        if not row or row["mx"] is None:
            return None
        return int(row["mx"])


def insert_fee_events(rows: List[Dict[str, Any]]) -> int:
    """
    Inserts idempotently (UNIQUE(source, trade_id) ON CONFLICT IGNORE).
    Returns number of rows attempted.
    """
    if not rows:
        return 0

    now_iso = _utc_now_iso()
    payload = []

    for r in rows:
        payload.append((
            r.get("source", "deribit"),
            r.get("trade_id"),
            r.get("order_id"),
            r.get("instrument_name"),
            r.get("side"),
            r.get("fee_currency"),
            float(r.get("fee_amount") or 0.0),
            float(r["price"]) if r.get("price") is not None else None,
            float(r["amount"]) if r.get("amount") is not None else None,
            int(r["timestamp_ms"]),
            float(r["fee_usd"]) if r.get("fee_usd") is not None else None,
            float(r["index_price_usd"]) if r.get("index_price_usd") is not None else None,
            now_iso,
            0,
        ))

    with get_conn() as conn:
        conn.executemany("""
            INSERT INTO fee_events (
                source, trade_id, order_id, instrument_name, side,
                fee_currency, fee_amount,
                price, amount, timestamp_ms,
                fee_usd, index_price_usd,
                inserted_at_utc, notified_telegram
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
        """, payload)

    return len(rows)


def get_unnotified_fee_events(limit: int = 50, min_fee: float = 0.0) -> List[Dict[str, Any]]:
    with get_conn() as conn:
        rows = conn.execute("""
            SELECT *
            FROM fee_events
            WHERE notified_telegram = 0
              AND ABS(fee_amount) >= ?
            ORDER BY timestamp_ms ASC
            LIMIT ?;
        """, (float(min_fee), int(limit))).fetchall()
    return [dict(r) for r in rows]


def mark_fee_events_notified(ids: List[int]) -> None:
    if not ids:
        return
    with get_conn() as conn:
        conn.executemany(
            "UPDATE fee_events SET notified_telegram = 1 WHERE id = ?;",
            [(int(i),) for i in ids]
        )


def list_fee_events(
    *,
    start_ms: Optional[int] = None,
    end_ms: Optional[int] = None,
    limit: int = 500,
    offset: int = 0
) -> List[Dict[str, Any]]:
    q = "SELECT * FROM fee_events WHERE 1=1"
    params: list[Any] = []

    if start_ms is not None:
        q += " AND timestamp_ms >= ?"
        params.append(int(start_ms))
    if end_ms is not None:
        q += " AND timestamp_ms <= ?"
        params.append(int(end_ms))

    q += " ORDER BY timestamp_ms DESC LIMIT ? OFFSET ?"
    params.extend([int(limit), int(offset)])

    with get_conn() as conn:
        rows = conn.execute(q, params).fetchall()
    return [dict(r) for r in rows]
