from __future__ import annotations

import logging
import os

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from backend_api.routes_jobs import router as jobs_router
from backend_api.jobs import init_jobs_table

logging.basicConfig(level=logging.INFO, force=True)
log = logging.getLogger("backend-api")

app = FastAPI(title="BTC Worker API", version="1.0")

# CORS - needed for the Vite dev server (the prod nginx proxy is same-origin).
_cors_origins = [
    o.strip() for o in os.getenv("CORS_ORIGINS", "").split(",") if o.strip()
]
if _cors_origins:
    app.add_middleware(
        CORSMiddleware,
        allow_origins=_cors_origins,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

app.include_router(jobs_router, prefix="/v1")

from backend_api.routes_mm_alert import router as mm_alert_router
app.include_router(mm_alert_router)

# React front-end API - auth + data routers.
from backend_api.routes_auth import router as auth_router
from backend_api.routes_account import router as account_router
from backend_api.routes_positions import router as positions_router
from backend_api.routes_market import router as market_router
from backend_api.routes_stress import router as stress_router
from backend_api.routes_history import router as history_router
from backend_api.routes_btc_prices import router as btc_prices_router
from backend_api.routes_decisions import router as decisions_router
from backend_api.routes_ws_health import router as ws_health_router
from backend_api.routes_hedge import router as hedge_router
from backend_api.routes_mm_im import router as mm_im_router
from backend_api.routes_rti import router as rti_router
from backend_api.routes_portfolio_bot import router as portfolio_bot_router
from backend_api.routes_options_scheduler import router as options_scheduler_router
from backend_api.routes_mm_alerts import router as mm_alerts_router
from backend_api.routes_trading_fees import router as trading_fees_router
from backend_api.routes_llm_fees import router as llm_fees_router
from backend_api.routes_user_management import router as user_management_router
from backend_api.routes_vol import router as vol_router
from backend_api.routes_quant import router as quant_router
from backend_api.routes_etf import router as etf_router

app.include_router(auth_router)
app.include_router(account_router)
app.include_router(positions_router)
app.include_router(market_router)
app.include_router(stress_router)
app.include_router(history_router)
app.include_router(btc_prices_router)
app.include_router(decisions_router)
app.include_router(ws_health_router)
app.include_router(hedge_router)
app.include_router(mm_im_router)
app.include_router(rti_router)
app.include_router(portfolio_bot_router)
app.include_router(options_scheduler_router)
app.include_router(mm_alerts_router)
app.include_router(trading_fees_router)
app.include_router(llm_fees_router)
app.include_router(user_management_router)
app.include_router(vol_router)
app.include_router(quant_router)
app.include_router(etf_router)


@app.on_event("startup")
def on_startup():
    # Web-only: ensure table exists, no scheduler, no background workers
    init_jobs_table()
    log.info("API started (web-only)")


@app.get("/healthz")
def healthz():
    return {"ok": True}
