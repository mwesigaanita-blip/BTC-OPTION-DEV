"""Portfolio Analysis Bot routes - read-only control-plane view.

Mirrors `Streamlit/pages/Portfolio_Analysis_Bot.py`. Every mutation
(threshold override, suppression, resume, on-demand report) still
flows through the Telegram bot - the React page is intentionally
read-only so the audit trail stays clean.

JWT-protected; access gated by the `Portfolio_Analysis_Bot` page grant.
"""
from __future__ import annotations

import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Query, status
from fastapi.responses import FileResponse

from backend_api.auth_jwt import require_page

log = logging.getLogger("backend-api.portfolio_bot")

router = APIRouter(prefix="/api/portfolio-bot", tags=["portfolio-bot"])

_PAGE = "Portfolio_Analysis_Bot"


# Lazy import so the API process degrades gracefully if portfolio_analysis
# can't import (missing deps, broken DB) instead of crashing on startup.
_pa_err: Exception | None = None
try:
    from portfolio_analysis import config as pa_config
    from portfolio_analysis import storage as pa_storage
    from portfolio_analysis import thresholds as pa_thresholds
    from portfolio_analysis._fmt import format_threshold_value
    from portfolio_analysis.bot import wizard as pa_wizard
except Exception as exc:  # pragma: no cover
    _pa_err = exc


_THRESHOLD_DESCRIPTIONS: dict[str, str] = {
    "MM_WARN_PCT": "Maintenance-margin % above which Rule 1 emits a WARNING.",
    "MM_URGENT_PCT": "Maintenance-margin % above which Rule 1 emits an URGENT alert.",
    "MM_CRITICAL_PCT": (
        "Maintenance-margin % above which Rule 1 emits an EMERGENCY "
        "(forces URGENT_ACTION Calm Score)."
    ),
    "DELTA_GOOD_BTC": "|delta| BTC at-or-below which the book is considered well-hedged.",
    "DELTA_WARN_BTC": "|delta| BTC above which Rule 2 emits a WARNING.",
    "DELTA_CRITICAL_BTC": "|delta| BTC above which Rule 2 emits an EMERGENCY.",
    "DTE_WARN_DAYS": "Days-to-expiry below which Rule 3 emits a WARNING for any position.",
    "DTE_CRITICAL_DAYS": "Days-to-expiry below which Rule 3 emits an URGENT alert.",
    "HEARTBEAT_RELAX_S": "Heartbeat cadence (seconds) while Calm Score = RELAX.",
    "HEARTBEAT_TAKE_A_LOOK_S": "Heartbeat cadence (seconds) while Calm Score = TAKE_A_LOOK.",
    "HEARTBEAT_ACTIVE_MONITORING_S": (
        "Heartbeat cadence (seconds) while Calm Score = ACTIVE_MONITORING."
    ),
    "HEARTBEAT_URGENT_ACTION_S": "Heartbeat cadence (seconds) while Calm Score = URGENT_ACTION.",
}


def _ensure_loaded() -> None:
    if _pa_err is not None:
        raise HTTPException(
            status.HTTP_503_SERVICE_UNAVAILABLE,
            f"portfolio_analysis package unavailable: {_pa_err}",
        )


def _row_to_dict(row: Any) -> dict[str, Any] | None:
    if row is None:
        return None
    try:
        return dict(row)
    except Exception:
        return None


def _list_pdf_reports() -> list[dict[str, Any]]:
    rdir: Path = pa_config.REPORT_DIR
    if not rdir.is_dir():
        return []
    files = sorted(
        rdir.glob("portfolio_*.pdf"),
        key=lambda p: p.stat().st_mtime,
        reverse=True,
    )
    out: list[dict[str, Any]] = []
    for p in files:
        s = p.stat()
        out.append(
            {
                "name": p.name,
                "size_kb": int(s.st_size / 1024),
                "modified_utc": datetime.fromtimestamp(s.st_mtime, tz=timezone.utc)
                .isoformat()
                .replace("+00:00", "Z"),
            }
        )
    return out


def _thresholds_list() -> list[dict[str, Any]]:
    pa_thresholds.invalidate_cache()
    rows = pa_thresholds.list_active()
    enriched: list[dict[str, Any]] = []
    for r in rows:
        name = r["name"]
        enriched.append(
            {
                **r,
                "label": pa_wizard.label_for(name),
                "current_display": format_threshold_value(name, r["current"]),
                "default_display": format_threshold_value(name, r["default"]),
                "description": _THRESHOLD_DESCRIPTIONS.get(name, ""),
            }
        )
    return enriched


@router.get("/dashboard")
def dashboard(
    audit_limit: int = Query(default=50, ge=1, le=500),
    user: dict = Depends(require_page(_PAGE)),
) -> dict[str, Any]:
    """One-shot bundle of every read needed by the page. Cheap - all
    backed by SQLite reads + a directory listing - so a single endpoint
    keeps the React side simple and refresh-time predictable."""
    _ensure_loaded()
    state = _row_to_dict(pa_storage.latest_state())
    alerts = [dict(r) for r in pa_storage.unresolved_alerts()]
    suppressions = [dict(r) for r in pa_storage.active_suppressions()]
    audit = [dict(r) for r in pa_storage.recent_audit(audit_limit)]
    latest_report_run = _row_to_dict(pa_storage.latest_report_run())
    thresholds = _thresholds_list()
    reports = _list_pdf_reports()
    return {
        "state": state,
        "alerts": alerts,
        "suppressions": suppressions,
        "audit": audit,
        "thresholds": thresholds,
        "latest_report_run": latest_report_run,
        "reports": reports,
        "config": {
            "report_dir": str(pa_config.REPORT_DIR),
            "report_daily_utc_hour": int(pa_config.REPORT_DAILY_UTC_HOUR),
            "report_daily_utc_minute": int(pa_config.REPORT_DAILY_UTC_MINUTE),
        },
    }


@router.get("/reports/{filename}")
def download_report(
    filename: str, user: dict = Depends(require_page(_PAGE))
) -> FileResponse:
    """Stream a generated PDF back to the browser. Filename is restricted
    to `portfolio_*.pdf` inside `REPORT_DIR` to prevent path traversal."""
    _ensure_loaded()
    if "/" in filename or "\\" in filename or ".." in filename:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "invalid filename")
    if not filename.startswith("portfolio_") or not filename.endswith(".pdf"):
        raise HTTPException(
            status.HTTP_400_BAD_REQUEST,
            "filename must match portfolio_*.pdf",
        )
    path: Path = pa_config.REPORT_DIR / filename
    # Resolve and reconfirm the path is still inside REPORT_DIR.
    try:
        resolved = path.resolve()
        rdir = pa_config.REPORT_DIR.resolve()
        resolved.relative_to(rdir)
    except Exception:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "invalid filename")
    if not resolved.is_file():
        raise HTTPException(status.HTTP_404_NOT_FOUND, "report not found")
    return FileResponse(
        path=str(resolved),
        media_type="application/pdf",
        filename=filename,
    )
