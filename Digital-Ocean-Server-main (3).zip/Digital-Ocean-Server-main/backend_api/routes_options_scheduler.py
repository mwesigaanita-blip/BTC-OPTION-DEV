"""Live Options Scheduler routes - read-only view + manual trigger.

Mirrors `Streamlit/pages/Live_Options_Scheduler.py`. Surfaces the state of
two background pipelines:

- Options OHLCV 1-minute (per-instrument candles, hourly fetch).
- Snapshot (greeks, IV, mark prices) - one parquet file per UTC day.

Both pipelines write to parquet under `data/raw/cefi/options/...`. The
React page reads those files via the helpers in
`multi_agent_system.snapshot_pipeline` and `multi_agent_system.options_ohlcv`.

JWT-protected; access gated by the `Live_Options_Scheduler` page grant.
"""
from __future__ import annotations

import json
import logging
import math
import os
from datetime import date, datetime, timezone
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Query, status

from backend_api.auth_jwt import require_page

log = logging.getLogger("backend-api.options_scheduler")

router = APIRouter(prefix="/api/options-scheduler", tags=["options-scheduler"])

_PAGE = "Live_Options_Scheduler"


_import_err: Exception | None = None
try:
    from multi_agent_system.options_ohlcv import (
        OHLCV_BASE,
        build_partition_path as ohlcv_partition_path,
        load_state as load_ohlcv_state,
    )
    from multi_agent_system.snapshot_pipeline import (
        SNAPSHOT_BASE,
        load_state as load_snapshot_state,
        read_latest_snapshot,
        read_snapshot_for_date,
        run_snapshot_pipeline,
    )
except Exception as exc:  # pragma: no cover
    _import_err = exc


def _ensure_loaded() -> None:
    if _import_err is not None:
        raise HTTPException(
            status.HTTP_503_SERVICE_UNAVAILABLE,
            f"multi_agent_system package unavailable: {_import_err}",
        )


def _json_safe(value: Any) -> Any:
    """Strip NaN / Inf out of pandas-derived records."""
    if isinstance(value, float):
        if math.isnan(value) or math.isinf(value):
            return None
        return value
    if isinstance(value, dict):
        return {k: _json_safe(v) for k, v in value.items()}
    if isinstance(value, list):
        return [_json_safe(v) for v in value]
    return value


def _df_records(df) -> list[dict[str, Any]]:
    if df is None or df.empty:
        return []
    return _json_safe(json.loads(df.to_json(orient="records", date_format="iso")))


def _parse_iso_date(s: str) -> date:
    try:
        return date.fromisoformat(s)
    except Exception as exc:
        raise HTTPException(
            status.HTTP_400_BAD_REQUEST, f"invalid date '{s}' (expected YYYY-MM-DD)"
        ) from exc


@router.get("/state")
def state(user: dict = Depends(require_page(_PAGE))) -> dict[str, Any]:
    """Combined state of both pipelines + their env config + 'now' clock."""
    _ensure_loaded()
    snap = load_snapshot_state() or {}
    ohlcv = load_ohlcv_state() or {}
    now_utc = datetime.now(timezone.utc)
    return {
        "now_utc": now_utc.isoformat().replace("+00:00", "Z"),
        "today_utc": now_utc.date().isoformat(),
        "snapshot": {
            "state": _json_safe(snap),
            "config": {
                "enabled": os.getenv("SNAPSHOT_ENABLED", "1"),
                "interval_seconds": os.getenv("SNAPSHOT_INTERVAL_SECONDS", "3600"),
                "base_dir": str(SNAPSHOT_BASE),
            },
        },
        "ohlcv": {
            "state": _json_safe(ohlcv),
            "config": {
                "enabled": os.getenv("OPTIONS_OHLCV_ENABLED", "1"),
                "interval_seconds": os.getenv("OPTIONS_OHLCV_INTERVAL_SECONDS", "3600"),
                "base_dir": str(OHLCV_BASE),
            },
        },
    }


@router.get("/snapshot/today")
def snapshot_today(user: dict = Depends(require_page(_PAGE))) -> dict[str, Any]:
    """Row count for today's snapshot parquet."""
    _ensure_loaded()
    today = datetime.now(timezone.utc).date()
    df = read_snapshot_for_date(today)
    return {"date": today.isoformat(), "rows": int(0 if df is None or df.empty else len(df))}


@router.get("/snapshot/latest")
def snapshot_latest(
    limit: int = Query(default=20, ge=1, le=500),
    user: dict = Depends(require_page(_PAGE)),
) -> dict[str, Any]:
    """First N rows of the most recent snapshot (walks back up to 7 days)."""
    _ensure_loaded()
    df = read_latest_snapshot()
    if df is None or df.empty:
        return {"rows": [], "total": 0, "columns": []}
    preferred = [
        "snapshot_ts", "instrument_name", "expiration", "strike", "option_type",
        "mark_price", "underlying_price",
        "delta", "theta", "vega", "gamma",
        "mark_iv", "bid_iv", "ask_iv",
        "volume", "open_interest", "qty", "qty_max_sell", "qty_max_buy", "POP",
    ]
    cols = [c for c in preferred if c in df.columns] + [
        c for c in df.columns if c not in preferred
    ]
    ordered = df[cols]
    head = ordered.head(limit)
    return {
        "rows": _df_records(head),
        "total": int(len(df)),
        "columns": [str(c) for c in ordered.columns.tolist()],
    }


@router.get("/ohlcv/{day}")
def ohlcv_for_date(
    day: str,
    instrument: str | None = Query(default=None),
    limit: int = Query(default=50, ge=1, le=2000),
    user: dict = Depends(require_page(_PAGE)),
) -> dict[str, Any]:
    """1-minute OHLCV rows for a single UTC date. Optional instrument filter.
    Top `limit` rows sorted by timestamp descending."""
    _ensure_loaded()
    import pandas as pd  # local import - keeps the page lazy

    d = _parse_iso_date(day)
    path = ohlcv_partition_path(d)
    if not path.exists():
        return {
            "date": d.isoformat(),
            "available": False,
            "rows": [],
            "total": 0,
            "columns": [],
            "instruments": [],
            "first_ts": None,
            "last_ts": None,
        }
    try:
        df = pd.read_parquet(path)
    except Exception as exc:
        log.exception("read_parquet failed: %s", path)
        raise HTTPException(
            status.HTTP_500_INTERNAL_SERVER_ERROR, f"Read failed: {exc}"
        )

    if df is None or df.empty:
        return {
            "date": d.isoformat(),
            "available": True,
            "rows": [],
            "total": 0,
            "columns": [],
            "instruments": [],
            "first_ts": None,
            "last_ts": None,
        }

    total = int(len(df))
    instruments = (
        sorted(df["instrument_name"].dropna().unique().tolist())
        if "instrument_name" in df.columns
        else []
    )

    first_ts = None
    last_ts = None
    if "timestamp" in df.columns:
        try:
            first_ts = str(df["timestamp"].min())
            last_ts = str(df["timestamp"].max())
        except Exception:
            pass

    if instrument and instrument != "All" and "instrument_name" in df.columns:
        df = df[df["instrument_name"] == instrument]

    preferred = ["timestamp", "instrument_name", "open", "high", "low", "close", "volume", "cost"]
    cols = [c for c in preferred if c in df.columns] + [
        c for c in df.columns if c not in preferred
    ]
    ordered = df[cols]
    if "timestamp" in ordered.columns:
        ordered = ordered.sort_values("timestamp", ascending=False)
    head = ordered.head(limit)

    return {
        "date": d.isoformat(),
        "available": True,
        "rows": _df_records(head),
        "total": total,
        "filtered": int(len(df)),
        "columns": [str(c) for c in ordered.columns.tolist()],
        "instruments": instruments,
        "first_ts": first_ts,
        "last_ts": last_ts,
    }


@router.post("/snapshot/run")
def snapshot_run(user: dict = Depends(require_page(_PAGE))) -> dict[str, Any]:
    """Trigger a one-off snapshot pipeline run. Blocking - the caller waits
    for the run to finish before getting a response. Returns the per-day
    file-write summary so the page can render a success / failure banner."""
    _ensure_loaded()
    try:
        result = run_snapshot_pipeline()
    except Exception as exc:
        log.exception("run_snapshot_pipeline failed")
        raise HTTPException(
            status.HTTP_502_BAD_GATEWAY, f"Manual run failed: {exc}"
        )
    files_written = result.get("files_written") or {}
    rows = sum(int(v or 0) for v in files_written.values())
    return {
        "ok": True,
        "instruments_total": int(result.get("instruments_total", 0) or 0),
        "rows_written": rows,
        "duration_seconds": float(result.get("duration_seconds", 0) or 0),
        "files_written": files_written,
    }
