from typing import Dict, Any
from fastapi import APIRouter

from backend_api.mm_alert_config_store import read_config, upsert_config

router = APIRouter(prefix="/mm-alert", tags=["mm-alert"])


@router.get("/config")
def get_config() -> Dict[str, Any]:
    # No internal API key required
    return read_config()


@router.post("/config")
def set_config(payload: Dict[str, Any]) -> Dict[str, Any]:
    # No internal API key required
    return upsert_config(payload)
