"""RTI Portfolio Management routes.

Two surfaces:
  * Analytics - daily account-equity history derived from
    `account_snapshots` (via `shared/data_service.get_account_equity_history`).
  * Trade Recap - normalized Deribit transaction log with KPIs +
    user-editable per-trade comments. Refresh button pulls fresh rows
    from Deribit; reads serve cached SQLite data.

JWT-protected; access gated by the `RTI_Portfolio_Management` page grant.
"""
from __future__ import annotations

import json
import logging
import math
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Query, status
from pydantic import BaseModel, Field

from backend_api.auth_jwt import require_page
from shared.data_service import get_account_equity_history
from trade_recap.ingestion import ingest_transaction_log
from trade_recap.service import (
    get_trade_recap,
    init_db,
    save_trade_comment,
)

log = logging.getLogger("backend-api.rti")

router = APIRouter(prefix="/api/rti", tags=["rti"])

_PAGE = "RTI_Portfolio_Management"


try:
    init_db()
except Exception:  # pragma: no cover
    log.exception("trade_recap init_db failed at import time")


def _json_safe(value: Any) -> Any:
    """Replace NaN/Inf with None so the JSON encoder doesn't choke."""
    if isinstance(value, float):
        if math.isnan(value) or math.isinf(value):
            return None
        return value
    if isinstance(value, dict):
        return {k: _json_safe(v) for k, v in value.items()}
    if isinstance(value, list):
        return [_json_safe(v) for v in value]
    return value


@router.get("/equity-history")
def equity_history(user: dict = Depends(require_page(_PAGE))) -> dict[str, Any]:
    """Full daily account-equity history as records. Sorted ascending by Date,
    ready for a CSV download or for the page to slice the latest N."""
    try:
        df = get_account_equity_history()
    except Exception as e:  # pragma: no cover - surfaced via empty payload
        log.exception("get_account_equity_history failed")
        raise HTTPException(
            status.HTTP_500_INTERNAL_SERVER_ERROR, f"equity history failed: {e}"
        )
    if df is None or df.empty:
        return {"rows": [], "columns": [], "last_date": None, "total_rows": 0}

    # Coerce timestamps / numpy ints to plain JSON-able values.
    records = json.loads(df.to_json(orient="records", date_format="iso"))
    return {
        "rows": _json_safe(records),
        "columns": [str(c) for c in df.columns.tolist()],
        "last_date": str(df["Date"].iloc[-1]) if "Date" in df.columns else None,
        "total_rows": int(len(df)),
    }


@router.get("/trade-recap")
def trade_recap(user: dict = Depends(require_page(_PAGE))) -> dict[str, Any]:
    """KPIs + the normalized transaction log + per-trade comments. Empty
    payload means the table has never been ingested - the page surfaces a
    'click Refresh' hint."""
    try:
        data = get_trade_recap()
    except Exception as e:
        log.exception("get_trade_recap failed")
        raise HTTPException(
            status.HTTP_500_INTERNAL_SERVER_ERROR, f"trade recap failed: {e}"
        )
    if not data:
        return {
            "available": False,
            "kpis": {
                "total_events": 0,
                "total_trades": 0,
                "total_fees_usd": 0.0,
                "total_premium_usd": 0.0,
            },
            "rows": [],
            "columns": [],
        }
    df = data["df"]
    records = json.loads(df.to_json(orient="records", date_format="iso"))
    return {
        "available": True,
        "kpis": {
            "total_events": int(data.get("total_events", 0) or 0),
            "total_trades": int(data.get("total_trades", 0) or 0),
            "total_fees_usd": float(data.get("total_fees_usd", 0.0) or 0.0),
            "total_premium_usd": float(data.get("total_premium_usd", 0.0) or 0.0),
        },
        "rows": _json_safe(records),
        "columns": [str(c) for c in df.columns.tolist()],
    }


class RefreshBody(BaseModel):
    days_back: int = Field(default=365, ge=1, le=3650)
    cooldown_minutes: int = Field(default=0, ge=0, le=1440)
    currencies: list[str] | None = Field(
        default=None,
        description=(
            "Per-currency Deribit fetch list. Defaults to [BTC, USDT, USDC] so "
            "accounts that trade USDT/USDC products don't quietly come back "
            "empty (Deribit's get_transaction_log is per-currency)."
        ),
    )


_DEFAULT_REFRESH_CURRENCIES = ("BTC", "USDT", "USDC")


@router.post("/trade-recap/refresh")
def refresh(
    body: RefreshBody | None = None, user: dict = Depends(require_page(_PAGE))
) -> dict[str, Any]:
    """Pull fresh rows from Deribit into the `transaction_log` table.

    Loops over every currency in `body.currencies` (defaulting to
    BTC + USDT + USDC) so non-BTC accounts don't silently return zero. Each
    currency's outcome is reported separately - if BTC succeeds but USDT
    fails (e.g. account isn't enabled for it), the user sees that breakdown.

    Top-level `new_rows` is the sum across all successful currencies;
    `-1` means *every* attempted currency was on cooldown.
    """
    payload = body or RefreshBody()
    days = payload.days_back
    cooldown = payload.cooldown_minutes
    ccys = [c.strip().upper() for c in (payload.currencies or _DEFAULT_REFRESH_CURRENCIES)]

    per_currency: list[dict[str, Any]] = []
    total_new = 0
    any_success = False
    any_cooldown = False
    last_err: str | None = None

    for ccy in ccys:
        try:
            n = ingest_transaction_log(
                days_back=days, currency=ccy, cooldown_minutes=cooldown
            )
        except Exception as e:
            log.exception("trade_recap_ingest failed (currency=%s)", ccy)
            per_currency.append(
                {"currency": ccy, "new_rows": 0, "error": f"{type(e).__name__}: {e}"}
            )
            last_err = f"{ccy}: {type(e).__name__}: {e}"
            continue
        per_currency.append({"currency": ccy, "new_rows": int(n), "error": None})
        if n == -1:
            any_cooldown = True
        else:
            any_success = True
            total_new += int(n)

    if not any_success and last_err is not None and not any_cooldown:
        # Every currency we tried errored out - surface the last error so
        # the React side renders a clear failure (instead of "0 new rows").
        raise HTTPException(
            status.HTTP_502_BAD_GATEWAY, f"Refresh failed: {last_err}"
        )

    if not any_success and any_cooldown and total_new == 0:
        # Every attempted currency was on cooldown.
        return {"new_rows": -1, "per_currency": per_currency}

    return {"new_rows": int(total_new), "per_currency": per_currency}


class CommentBody(BaseModel):
    trade_id: str
    comment: str


@router.post("/trade-recap/comment")
def set_comment(
    body: CommentBody, user: dict = Depends(require_page(_PAGE))
) -> dict[str, Any]:
    save_trade_comment(body.trade_id, body.comment)
    return {"ok": True}


@router.get(
    "/trade-recap/comment/{trade_id}/raw",
    include_in_schema=False,
)
def _placeholder_for_old_clients(trade_id: str) -> dict[str, Any]:
    # The Streamlit page never used a GET-per-comment endpoint - comments come
    # back inline with the rows. This is a placeholder so a misbehaving client
    # gets a clean 404 instead of a route-matching surprise.
    raise HTTPException(status.HTTP_404_NOT_FOUND, "Use /trade-recap instead")
