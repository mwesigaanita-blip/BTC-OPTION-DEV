from __future__ import annotations

from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, field_validator

from backend_api.auth_jwt import get_current_user, require_operator
from shared.auth import (
    ALL_PAGES,
    ROLES,
    get_all_users,
    hash_password,
    insert_user,
    update_user,
    username_exists,
)

router = APIRouter(prefix="/api/users", tags=["users"])

_DB_PATH = ""  # shared.auth.db ignores this; ALL writes go to AUTH_DB


# ── Read ──────────────────────────────────────────────────────────────────────

@router.get("")
def list_users(
    _operator: dict = Depends(require_operator),
) -> Dict[str, Any]:
    users = get_all_users(_DB_PATH)
    return {"users": users, "all_pages": ALL_PAGES, "roles": ROLES}


# ── Create ────────────────────────────────────────────────────────────────────

class CreateUserRequest(BaseModel):
    username: str
    password: str
    role: str
    # Kept for backward compat with older clients; ignored under the
    # simplified role-only security model. Both roles get ALL_PAGES.
    pages: List[str] = []

    @field_validator("username")
    @classmethod
    def username_not_empty(cls, v: str) -> str:
        v = v.strip()
        if not v:
            raise ValueError("Username cannot be empty")
        return v

    @field_validator("role")
    @classmethod
    def valid_role(cls, v: str) -> str:
        if v not in ROLES:
            raise ValueError(f"Role must be one of {ROLES}")
        return v

    @field_validator("password")
    @classmethod
    def password_min_length(cls, v: str) -> str:
        if len(v) < 8:
            raise ValueError("Password must be at least 8 characters")
        return v


@router.post("")
def create_user(
    body: CreateUserRequest,
    _operator: dict = Depends(require_operator),
) -> Dict[str, Any]:
    if username_exists(_DB_PATH, body.username):
        raise HTTPException(status_code=409, detail=f"Username '{body.username}' already exists")

    # Role-only model: viewers automatically have access to every page
    # except User Management (enforced by `require_operator` on that route).
    pages_to_store = ALL_PAGES
    try:
        insert_user(
            db_path=_DB_PATH,
            username=body.username,
            hashed_password=hash_password(body.password),
            role=body.role,
            pages=pages_to_store,
        )
    except ValueError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc

    return {"ok": True, "username": body.username}


# ── Update ────────────────────────────────────────────────────────────────────

class UpdateUserRequest(BaseModel):
    role: str
    # Ignored under the role-only model; accepted for backward compatibility.
    pages: List[str] = []
    is_active: bool
    new_password: Optional[str] = None

    @field_validator("role")
    @classmethod
    def valid_role(cls, v: str) -> str:
        if v not in ROLES:
            raise ValueError(f"Role must be one of {ROLES}")
        return v

    @field_validator("new_password")
    @classmethod
    def password_min_length(cls, v: Optional[str]) -> Optional[str]:
        if v is not None and len(v) < 8:
            raise ValueError("New password must be at least 8 characters")
        return v


@router.patch("/{user_id}")
def patch_user(
    user_id: int,
    body: UpdateUserRequest,
    current_user: dict = Depends(get_current_user),
    _operator: dict = Depends(require_operator),
) -> Dict[str, Any]:
    # Self-protection: cannot change own role or disable yourself
    is_self = current_user.get("sub") == _get_username_by_id(user_id)
    if is_self:
        users = get_all_users(_DB_PATH)
        original = next((u for u in users if u["id"] == user_id), None)
        if original:
            # Keep original role and active status for self
            role = original["role"]
            is_active = bool(original["is_active"])
        else:
            role = body.role
            is_active = body.is_active
    else:
        role = body.role
        is_active = body.is_active

    # Role-only model: every user (operator or viewer) is granted all pages.
    # The operator-only User Management page is gated separately via
    # `require_operator`, which checks role at request time.
    pages_to_save = ALL_PAGES
    hashed_pw = hash_password(body.new_password) if body.new_password else None

    try:
        update_user(
            db_path=_DB_PATH,
            user_id=user_id,
            role=role,
            pages=pages_to_save,
            is_active=int(is_active),
            hashed_password=hashed_pw,
        )
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc

    return {"ok": True, "user_id": user_id}


def _get_username_by_id(user_id: int) -> Optional[str]:
    users = get_all_users(_DB_PATH)
    u = next((x for x in users if x["id"] == user_id), None)
    return u["username"] if u else None
