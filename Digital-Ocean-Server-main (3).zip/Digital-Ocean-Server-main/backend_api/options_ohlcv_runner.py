# backend_api/options_ohlcv_runner.py

import logging
from datetime import datetime, timezone

log = logging.getLogger("options_ohlcv.runner")


def run_options_ohlcv_hourly(*, lookback_hours: int = 2) -> dict:
    """
    Thin wrapper around the core pipeline, callable from the scheduler
    or from a manual trigger.

    Returns summary dict for logging/UI.
    """
    started_at = datetime.now(timezone.utc)

    try:
        from multi_agent_system.options_ohlcv import run_options_ohlcv_pipeline

        result = run_options_ohlcv_pipeline(lookback_hours=lookback_hours)
    except Exception as exc:
        log.exception("Options OHLCV pipeline failed: %s", exc)
        return {
            "error": str(exc),
            "started_at_utc": started_at.strftime("%Y-%m-%dT%H:%M:%SZ"),
            "finished_at_utc": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        }

    finished_at = datetime.now(timezone.utc)

    result["started_at_utc"] = started_at.strftime("%Y-%m-%dT%H:%M:%SZ")
    result["finished_at_utc"] = finished_at.strftime("%Y-%m-%dT%H:%M:%SZ")

    log.info("Options OHLCV 1m run completed: %s", {
        "rows_written": sum(result.get("files_written", {}).values()),
        "instruments": result.get("instruments_total", 0),
        "duration_s": result.get("duration_seconds", 0),
    })

    return result
