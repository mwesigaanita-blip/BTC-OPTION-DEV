from __future__ import annotations

import logging
import os
import threading
import time
import traceback
from typing import Any, Dict, Optional

from backend_api.settings import REFRESH_INTERVAL_SECONDS
from backend_api.jobs import (
    create_job,
    set_job_running,
    set_job_succeeded,
    set_job_failed,
    get_scheduler_config,
    has_running_job,
    should_run_scheduler_state,
    mark_scheduler_ran_state,
)

log = logging.getLogger("worker-scheduler")
log.propagate = True


def _do_refresh_once() -> Dict[str, Any]:
    """
    One-shot refresh:
      - fetch account/positions
      - compute greeks/ROC (if implemented)
      - upsert into SQLite snapshot tables

    Returns a small dict for logging.
    """
    # Import inside function so worker still boots even if refresh module has issues
    import shared.data_service

    # Your shared refresh function (DB writes happen inside it)
    return shared.data_service.refresh_now()


def start_scheduler(stop_event: threading.Event) -> threading.Thread:
    """
    Background thread that refreshes every REFRESH_INTERVAL_SECONDS.

    IMPORTANT (Phase 2):
    - This runs ONLY in the worker container.
    - We do NOT enqueue a refresh job every interval (keeps api_jobs clean).
    - On errors, we optionally create a job row so Streamlit can see failures.
    """

    interval = float(REFRESH_INTERVAL_SECONDS)

    def loop():
        log.info("Scheduler started. Refresh interval=%ss", interval)

        # run immediately once on startup
        next_run = 0.0

        while not stop_event.is_set():
            now = time.time()

            if now >= next_run:
                try:
                    out = _do_refresh_once()
                    log.info("Refresh succeeded: %s", out)
                except Exception as e:
                    # Optional: record failures in api_jobs so UI can see them
                    job_id = create_job("refresh_1min", payload={"interval_seconds": interval})
                    try:
                        set_job_running(job_id)
                        err = f"{e}\n{traceback.format_exc()}"
                        set_job_failed(job_id, err)
                    except Exception:
                        # if DB write fails, still log the original error
                        pass

                    log.error("Refresh failed: %s", e)

                next_run = now + interval

            # sleep small so we can stop fast
            stop_event.wait(1.0)

        log.info("Scheduler stopped.")

    t = threading.Thread(target=loop, daemon=True, name="refresh-scheduler")
    t.start()
    return t


def start_models_scheduler(stop_event: threading.Event) -> threading.Thread:
    """
    ENQUEUE-ONLY scheduler for models (FIXED TIMES ONLY).

    - Reads config from SQLite (scheduler_config key='models'):
        enabled, timezone, fixed_times
    - If enabled and now is within a 10-minute window after a configured time,
      enqueue a 'run_models_sequence' job.
    - Prevents overlap: won't enqueue if a run_models_sequence job is already running.
    - Restart-safe: dedupes per day+slot using scheduler_state.
    - Runtime enable/disable is driven by the DB-backed 'enabled' flag
      (controlled from the "AI Models Scheduler" page in Streamlit).
    """
    def loop():
        log.info("Models scheduler started (DB-config, fixed-times only).")

        # defaults (if config missing)
        cfg = {
            "enabled": False,
            "timezone": "America/New_York",
            "fixed_times": ["08:00", "21:00"],
        }
        last_cfg_check = 0.0

        while not stop_event.is_set():
            now = time.time()

            # Reload config every 30s so Streamlit changes apply quickly
            if now - last_cfg_check >= 30:
                try:
                    db_cfg = get_scheduler_config("models") or {}
                    cfg["enabled"] = bool(db_cfg.get("enabled", cfg["enabled"]))
                    cfg["timezone"] = db_cfg.get("timezone") or cfg["timezone"]
                    ft = db_cfg.get("fixed_times")
                    if isinstance(ft, list) and ft:
                        cfg["fixed_times"] = ft
                except Exception as e:
                    log.error("Failed reading scheduler_config(models): %s", e)
                last_cfg_check = now

            if not cfg.get("enabled"):
                stop_event.wait(2.0)
                continue

            try:
                # Don't overlap
                if has_running_job("run_models_sequence"):
                    stop_event.wait(2.0)
                    continue

                from datetime import datetime, timedelta
                from zoneinfo import ZoneInfo

                tzname = str(cfg.get("timezone") or "America/New_York")
                fixed_times = cfg.get("fixed_times") or ["08:00", "21:00"]

                now_local = datetime.now(ZoneInfo(tzname))
                today = now_local.date().isoformat()

                window_minutes = 10

                for tstr in fixed_times:
                    try:
                        hh, mm = [int(x) for x in str(tstr).split(":")]
                    except Exception:
                        continue

                    target = now_local.replace(hour=hh, minute=mm, second=0, microsecond=0)
                    if target <= now_local < (target + timedelta(minutes=window_minutes)):
                        # Dedupe per slot per day
                        state_key = f"models_fixed_{today}_{tstr}_{tzname}"

                        # IMPORTANT: large dedupe so it never re-enqueues inside the window
                        if should_run_scheduler_state(state_key, interval_seconds=12 * 3600):
                            job_id = create_job(
                                "run_models_sequence",
                                payload={
                                    "trigger": "scheduler_fixed",
                                    "timezone": tzname,
                                    "time_str": tstr,
                                    "model_ids": ["gpt-5", "claude-sonnet-4-20250514", "grok-4"],
                                    "params": {},
                                },
                            )
                            mark_scheduler_ran_state(state_key)
                            log.info(
                                "Enqueued fixed-time models run. job_id=%s slot=%s %s",
                                job_id, tstr, tzname
                            )

            except Exception as e:
                log.error("Models scheduler loop error: %s", e)

            stop_event.wait(2.0)

        log.info("Models scheduler stopped.")

    t = threading.Thread(target=loop, daemon=True, name="models-scheduler")
    t.start()
    return t


def start_live_options_scheduler(stop_event: threading.Event) -> threading.Thread:
    """
    Scheduler for Deribit BTC options snapshot ingestion (Greeks, IV, prices).
    Runs every SNAPSHOT_INTERVAL_SECONDS.

    Fetches a full ticker snapshot for all active BTC options and writes
    daily-partitioned Parquet files under DATA_ROOT/raw/cefi/options/snapshot/.

    Env:
      SNAPSHOT_ENABLED=1                   (default: 1)
      SNAPSHOT_INTERVAL_SECONDS=300       (default: 300 = 5 minutes)
    """
    def loop():
        enabled = os.getenv("SNAPSHOT_ENABLED", "1").strip().lower() in (
            "1", "true", "yes", "y", "on",
        )
        interval = float(os.getenv("SNAPSHOT_INTERVAL_SECONDS", "300"))

        if not enabled:
            log.info("Snapshot scheduler disabled (SNAPSHOT_ENABLED != 1).")
            return

        log.info(
            "Snapshot scheduler started. interval=%ss enabled=%s",
            interval, enabled,
        )

        # Small delay on startup
        stop_event.wait(15.0)

        last_run = 0.0

        while not stop_event.is_set():
            now = time.time()

            if now - last_run >= interval:
                try:
                    from backend_api.snapshot_runner import run_snapshot

                    result = run_snapshot()
                    log.info("Snapshot run completed: %s", {
                        k: result.get(k)
                        for k in ("instruments_total", "rows_after_validation", "duration_seconds")
                        if k in result
                    })
                except Exception as e:
                    log.error("Snapshot scheduler run failed: %s", e)

                last_run = time.time()

            # Sleep in chunks for responsive shutdown
            stop_event.wait(min(60.0, max(1.0, interval - (time.time() - last_run))))

        log.info("Snapshot scheduler stopped.")

    t = threading.Thread(target=loop, name="snapshot-scheduler", daemon=True)
    t.start()
    return t


def start_fees_scheduler(stop_event: threading.Event) -> threading.Thread:
    """
    Polls Deribit user trades and stores fees.
    Sends Telegram alert for any new fee rows, and marks them notified.

    Env:
      FEES_ENABLED=1
      FEES_POLL_SECONDS=60
      FEES_BACKFILL_HOURS=24
      FEES_NOTIFY_MIN=0.0
      FEES_NOTIFY_BATCH=20
      FEES_CURRENCY=BTC
    """
    def loop():
        poll = float(os.getenv("FEES_POLL_SECONDS", "60"))

        log.info("Fees scheduler started. poll_seconds=%s", poll)

        # Ensure schema once (correct place)
        try:
            from backend_api.db.fees_repo import ensure_fee_tables
            ensure_fee_tables()
        except Exception as e:
            log.error("Fees ensure_fee_tables failed: %s", e)

        while not stop_event.is_set():
            try:
                from backend_api.services.fees_service import ingest_fees_once
                out = ingest_fees_once()
                log.info("Fees ingest succeeded: %s", out)
            except Exception as e:
                log.error("Fees ingest failed: %s", e)

            stop_event.wait(poll)

        log.info("Fees scheduler stopped.")

    t = threading.Thread(target=loop, daemon=True, name="fees-scheduler")
    t.start()
    return t


def start_options_ohlcv_scheduler(stop_event: threading.Event) -> threading.Thread:
    """
    Hourly scheduler for Deribit BTC options OHLCV ingestion.

    Fetches 1-minute candlestick data for all active BTC options and writes
    daily-partitioned Parquet files under DATA_ROOT/raw/cefi/options/ohlcv/.

    Env:
      OPTIONS_OHLCV_ENABLED=1          (default: 1)
      OPTIONS_OHLCV_INTERVAL_SECONDS=3600  (default: 3600 = 1 hour)
    """
    def loop():
        enabled = os.getenv("OPTIONS_OHLCV_ENABLED", "1").strip().lower() in (
            "1", "true", "yes", "y", "on",
        )
        interval = float(os.getenv("OPTIONS_OHLCV_INTERVAL_SECONDS", "3600"))

        if not enabled:
            log.info("Options OHLCV scheduler disabled (OPTIONS_OHLCV_ENABLED != 1).")
            return

        log.info(
            "Options OHLCV scheduler started. interval=%ss enabled=%s",
            interval, enabled,
        )

        # Small delay on startup to let other services settle
        stop_event.wait(30.0)

        last_run = 0.0

        while not stop_event.is_set():
            now = time.time()

            if now - last_run >= interval:
                try:
                    from backend_api.options_ohlcv_runner import run_options_ohlcv_hourly

                    result = run_options_ohlcv_hourly(lookback_hours=2)
                    log.info("Options OHLCV run completed: %s", {
                        k: result.get(k)
                        for k in ("instruments_total", "rows_after_validation", "duration_seconds")
                        if k in result
                    })
                except Exception as e:
                    log.error("Options OHLCV scheduler run failed: %s", e)

                last_run = time.time()

            # Sleep in chunks for responsive shutdown
            stop_event.wait(min(60.0, max(1.0, interval - (time.time() - last_run))))

        log.info("Options OHLCV scheduler stopped.")

    t = threading.Thread(target=loop, daemon=True, name="options-ohlcv-scheduler")
    t.start()
    return t
