"""Positions data routes - live WS->Redis snapshot with SQLite fallback."""
from __future__ import annotations

import logging

from fastapi import APIRouter, Depends

from shared.data_service import get_positions_today
from shared.redis_live import get_positions_live

from backend_api.auth_jwt import require_page

log = logging.getLogger("backend-api.positions")

router = APIRouter(prefix="/api/positions", tags=["positions"])

_PAGE = "Account_Overview"


@router.get("/live")
def live(user: dict = Depends(require_page(_PAGE))) -> dict:
    """Current position book, shaped like `get_positions_today()`."""
    records, updated_at = get_positions_live()
    if records is not None:
        return {"source": "live", "updated_at": updated_at, "positions": records}
    records, updated_at = get_positions_today()
    return {"source": "snapshot", "updated_at": updated_at, "positions": records or []}
