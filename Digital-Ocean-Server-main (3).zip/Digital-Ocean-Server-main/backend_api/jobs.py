from __future__ import annotations

import json
import sqlite3
import time
import uuid
from typing import Any, Optional

from shared.db_paths import INFRA_DB as DB_PATH

print(f"[DB] Using {DB_PATH} in {__file__}", flush=True)

JOB_STATUS_QUEUED = "queued"
JOB_STATUS_RUNNING = "running"
JOB_STATUS_SUCCEEDED = "succeeded"
JOB_STATUS_FAILED = "failed"
JOB_STATUS_CANCELLED = "cancelled"

def _connect() -> sqlite3.Connection:
    conn = sqlite3.connect(str(DB_PATH), timeout=30, check_same_thread=False)
    conn.row_factory = sqlite3.Row

    # Cloud-safe SQLite settings (multi-process read/write)
    cur = conn.cursor()
    cur.execute("PRAGMA journal_mode=WAL;")
    cur.execute("PRAGMA synchronous=NORMAL;")
    cur.execute("PRAGMA busy_timeout=30000;")
    conn.commit()

    return conn

def init_jobs_table() -> None:
    with _connect() as conn:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS api_jobs (
                job_id TEXT PRIMARY KEY,
                job_type TEXT NOT NULL,
                status TEXT NOT NULL,
                created_ts INTEGER NOT NULL,
                started_ts INTEGER,
                finished_ts INTEGER,
                payload_json TEXT,
                result_json TEXT,
                error TEXT
            )
            """
        )
        # Migration: add cancel columns if missing (used by request_cancel / worker checkpoints)
        for sql in [
            "ALTER TABLE api_jobs ADD COLUMN cancel_requested INTEGER NOT NULL DEFAULT 0",
            "ALTER TABLE api_jobs ADD COLUMN cancel_ts INTEGER",
        ]:
            try:
                conn.execute(sql)
            except sqlite3.OperationalError:
                pass

        # 1) Admin-configurable scheduler settings (editable from Streamlit)
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS scheduler_config (
                key TEXT PRIMARY KEY,
                enabled INTEGER NOT NULL,
                interval_seconds INTEGER NOT NULL,
                mode TEXT NOT NULL DEFAULT 'interval',
                timezone TEXT NOT NULL DEFAULT 'America/New_York',
                fixed_times_json TEXT NOT NULL DEFAULT '[]',
                updated_at_utc TEXT NOT NULL
            )
            """
        )

        # Migration for older DBs (safe if columns already exist)
        for sql in [
            "ALTER TABLE scheduler_config ADD COLUMN mode TEXT NOT NULL DEFAULT 'interval'",
            "ALTER TABLE scheduler_config ADD COLUMN timezone TEXT NOT NULL DEFAULT 'America/New_York'",
            "ALTER TABLE scheduler_config ADD COLUMN fixed_times_json TEXT NOT NULL DEFAULT '[]'",
        ]:
            try:
                conn.execute(sql)
            except sqlite3.OperationalError:
                pass

        # Insert defaults if missing (models scheduler)
        # (Set to FIXED with 08:00 & 21:00 ET by default; you can change enabled later in Streamlit)
        conn.execute(
            """
            INSERT OR IGNORE INTO scheduler_config(
                key, enabled, interval_seconds, mode, timezone, fixed_times_json, updated_at_utc
            )
            VALUES (
                'models', 0, 43200, 'fixed', 'America/New_York', '["08:00","21:00"]',
                strftime('%Y-%m-%dT%H:%M:%fZ','now')
            )
            """
        )


        # 2) Scheduler runtime state (dedupe + restart safety)
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS scheduler_state (
                key TEXT PRIMARY KEY,
                last_run_ts INTEGER NOT NULL
            )
            """
        )

        conn.commit()


def create_job(job_type: str, payload: dict[str, Any] | None = None) -> str:
    job_id = str(uuid.uuid4())
    now = int(time.time())
    payload_json = json.dumps(payload or {}, ensure_ascii=False)

    with _connect() as conn:
        conn.execute(
            """
            INSERT INTO api_jobs(job_id, job_type, status, created_ts, payload_json)
            VALUES (?, ?, ?, ?, ?)
            """,
            (job_id, job_type, JOB_STATUS_QUEUED, now, payload_json),
        )
        conn.commit()

    return job_id

def set_job_running(job_id: str) -> None:
    now = int(time.time())
    with _connect() as conn:
        conn.execute(
            "UPDATE api_jobs SET status=?, started_ts=? WHERE job_id=?",
            (JOB_STATUS_RUNNING, now, job_id),
        )
        conn.commit()

def set_job_succeeded(job_id: str, result: dict[str, Any] | None = None) -> None:
    now = int(time.time())
    result_json = json.dumps(result or {}, ensure_ascii=False)
    with _connect() as conn:
        conn.execute(
            """
            UPDATE api_jobs
            SET status=?, finished_ts=?, result_json=?, error=NULL
            WHERE job_id=?
            """,
            (JOB_STATUS_SUCCEEDED, now, result_json, job_id),
        )
        conn.commit()

def set_job_failed(job_id: str, error: str) -> None:
    now = int(time.time())
    with _connect() as conn:
        conn.execute(
            """
            UPDATE api_jobs
            SET status=?, finished_ts=?, error=?
            WHERE job_id=?
            """,
            (JOB_STATUS_FAILED, now, (error or "")[:4000], job_id),
        )
        conn.commit()

def get_job(job_id: str) -> Optional[dict[str, Any]]:
    with _connect() as conn:
        row = conn.execute(
            "SELECT * FROM api_jobs WHERE job_id=?",
            (job_id,),
        ).fetchone()

    if not row:
        return None

    out = dict(row)
    for k in ("payload_json", "result_json"):
        if out.get(k):
            try:
                out[k] = json.loads(out[k])
            except Exception:
                pass
    return out

def set_job_progress(job_id: str, progress: dict[str, Any]) -> None:
    result_json = json.dumps(progress or {}, ensure_ascii=False)
    with _connect() as conn:
        conn.execute("UPDATE api_jobs SET result_json=? WHERE job_id=?", (result_json, job_id))
        conn.commit()

def claim_next_job(
    *,
    allowed_job_types: Optional[set[str]] = None,
    exclude_job_types: Optional[set[str]] = None,
) -> Optional[dict[str, Any]]:
    """
    Atomically claim the next queued job by marking it RUNNING.
    Returns the full job row dict (with payload_json parsed) or None if none available.
    """
    allowed_job_types = allowed_job_types or set()
    exclude_job_types = exclude_job_types or set()

    with _connect() as conn:
        conn.execute("BEGIN IMMEDIATE")  # acquire write lock for claim

        where = ["status=?"]
        params: list[Any] = [JOB_STATUS_QUEUED]

        if allowed_job_types:
            where.append("job_type IN (%s)" % ",".join(["?"] * len(allowed_job_types)))
            params.extend(sorted(list(allowed_job_types)))

        if exclude_job_types:
            where.append("job_type NOT IN (%s)" % ",".join(["?"] * len(exclude_job_types)))
            params.extend(sorted(list(exclude_job_types)))

        sql = f"""
            SELECT job_id FROM api_jobs
            WHERE {' AND '.join(where)}
            ORDER BY created_ts ASC
            LIMIT 1
        """

        row = conn.execute(sql, tuple(params)).fetchone()
        if not row:
            conn.commit()
            return None

        job_id = row["job_id"]
        now = int(time.time())
        conn.execute(
            "UPDATE api_jobs SET status=?, started_ts=? WHERE job_id=? AND status=?",
            (JOB_STATUS_RUNNING, now, job_id, JOB_STATUS_QUEUED),
        )
        conn.commit()

    return get_job(job_id)
 
def recover_stale_running_jobs(max_age_seconds: int = 1800) -> int:
    """
    Mark running jobs that have been running too long as failed.
    Useful on worker startup after a container restart.
    """
    now = int(time.time())
    cutoff = now - int(max_age_seconds)

    with _connect() as conn:
        rows = conn.execute(
            """
            SELECT job_id FROM api_jobs
            WHERE status=? AND started_ts IS NOT NULL AND started_ts < ?
            """,
            (JOB_STATUS_RUNNING, cutoff),
        ).fetchall()

        count = 0
        for r in rows:
            jid = r["job_id"]
            conn.execute(
                """
                UPDATE api_jobs
                SET status=?, finished_ts=?, error=?
                WHERE job_id=?
                """,
                (JOB_STATUS_FAILED, now, "Worker restart: stale running job recovered", jid),
            )
            count += 1

        conn.commit()

    return count



def request_cancel(job_id: str) -> bool:
    """
    Request cancellation.
    - If job is queued: mark cancelled immediately.
    - If job is running: set cancel_requested=1 so worker stops at next checkpoint.
    Returns True if a row was updated, else False (job not found).
    """
    now = int(time.time())
    with _connect() as conn:
        cur = conn.cursor()

        # Cancel queued immediately
        cur.execute(
            """
            UPDATE api_jobs
            SET status=?, finished_ts=?, cancel_requested=1, cancel_ts=?, error=NULL
            WHERE job_id=? AND status=?
            """,
            (JOB_STATUS_CANCELLED, now, now, job_id, JOB_STATUS_QUEUED),
        )
        if cur.rowcount > 0:
            conn.commit()
            return True

        # If running, just request cancel
        cur.execute(
            """
            UPDATE api_jobs
            SET cancel_requested=1, cancel_ts=?
            WHERE job_id=? AND status=?
            """,
            (now, job_id, JOB_STATUS_RUNNING),
        )

        updated = cur.rowcount > 0
        conn.commit()
        return updated

def is_cancel_requested(job_id: str) -> bool:
    with _connect() as conn:
        row = conn.execute(
            "SELECT cancel_requested FROM api_jobs WHERE job_id=? LIMIT 1",
            (job_id,),
        ).fetchone()
    if not row:
        return False
    try:
        return int(row["cancel_requested"]) == 1
    except Exception:
        return False

def set_job_cancelled(job_id: str, result: dict[str, Any] | None = None) -> None:
    now = int(time.time())
    result_json = json.dumps(result or {}, ensure_ascii=False)
    with _connect() as conn:
        conn.execute(
            """
            UPDATE api_jobs
            SET status=?, finished_ts=?, result_json=?, error=NULL
            WHERE job_id=?
            """,
            (JOB_STATUS_CANCELLED, now, result_json, job_id),
        )
        conn.commit()



def set_scheduler_config(
    key: str,
    enabled: bool,
    *,
    timezone: str = "America/New_York",
    fixed_times: list[str] | None = None,        # ["08:00","21:00"]
) -> None:
    """
    FIXED-TIMES ONLY scheduler config.
    Stores times as 24-hour HH:MM strings in fixed_times_json.
    """
    fixed_times = fixed_times or ["08:00", "21:00"]
    fixed_times_json = json.dumps(fixed_times, ensure_ascii=False)
    timezone = (timezone or "America/New_York").strip()

    with _connect() as conn:
        conn.execute("BEGIN IMMEDIATE")
        conn.execute(
            """
            INSERT INTO scheduler_config(key, enabled, interval_seconds, mode, timezone, fixed_times_json, updated_at_utc)
            VALUES (?, ?, ?, 'fixed', ?, ?, strftime('%Y-%m-%dT%H:%M:%fZ','now'))
            ON CONFLICT(key) DO UPDATE SET
                enabled=excluded.enabled,
                mode='fixed',
                timezone=excluded.timezone,
                fixed_times_json=excluded.fixed_times_json,
                updated_at_utc=excluded.updated_at_utc
            """,
            (key, 1 if enabled else 0, 43200, timezone, fixed_times_json),
        )
        conn.commit()

def get_scheduler_config(key: str) -> dict[str, Any]:
    """
    FIXED-TIMES ONLY scheduler config fetch.
    Always returns mode='fixed'.
    """
    with _connect() as conn:
        row = conn.execute(
            """
            SELECT key, enabled, updated_at_utc,
                   mode, timezone, fixed_times_json
            FROM scheduler_config
            WHERE key=?
            """,
            (key,),
        ).fetchone()

    if not row:
        return {
            "key": key,
            "enabled": False,
            "mode": "fixed",
            "timezone": "America/New_York",
            "fixed_times": ["08:00", "21:00"],
            "updated_at_utc": None,
        }

    try:
        fixed_times = json.loads(row["fixed_times_json"] or "[]")
        if not isinstance(fixed_times, list) or not fixed_times:
            fixed_times = ["08:00", "21:00"]
    except Exception:
        fixed_times = ["08:00", "21:00"]

    return {
        "key": str(row["key"]),
        "enabled": bool(row["enabled"]),
        "mode": "fixed",
        "timezone": str(row["timezone"] or "America/New_York"),
        "fixed_times": fixed_times,
        "updated_at_utc": str(row["updated_at_utc"]),
    }

def has_running_job(job_type: str) -> bool:
    with _connect() as conn:
        row = conn.execute(
            "SELECT 1 FROM api_jobs WHERE status=? AND job_type=? LIMIT 1",
            (JOB_STATUS_RUNNING, job_type),
        ).fetchone()
    return row is not None

def should_run_scheduler_state(key: str, interval_seconds: int) -> bool:
    now = int(time.time())
    with _connect() as conn:
        row = conn.execute(
            "SELECT last_run_ts FROM scheduler_state WHERE key=?",
            (key,),
        ).fetchone()

    if not row:
        return True

    last_ts = int(row["last_run_ts"])
    return (now - last_ts) >= int(interval_seconds)

def mark_scheduler_ran_state(key: str) -> None:
    now = int(time.time())
    with _connect() as conn:
        conn.execute("BEGIN IMMEDIATE")
        conn.execute(
            """
            INSERT INTO scheduler_state(key, last_run_ts)
            VALUES (?, ?)
            ON CONFLICT(key) DO UPDATE SET last_run_ts=excluded.last_run_ts
            """,
            (key, now),
        )
        conn.commit()



def get_live_options_schedule() -> dict:
    with _connect() as conn:
        # ✅ ENSURE TABLE EXISTS (critical)
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS live_options_schedule (
              id INTEGER PRIMARY KEY CHECK (id = 1),
              tz_name TEXT NOT NULL DEFAULT 'UTC',
              run_time TEXT NOT NULL DEFAULT '00:05',
              days_ahead INTEGER NOT NULL DEFAULT 365,
              enabled INTEGER NOT NULL DEFAULT 0,
              updated_at_utc TEXT NOT NULL,
              last_run_at_utc TEXT,
              last_run_date_key TEXT
            )
            """
        )

        row = conn.execute(
            """
            SELECT tz_name, run_time, days_ahead, enabled,
                   updated_at_utc, last_run_at_utc, last_run_date_key
            FROM live_options_schedule
            WHERE id = 1
            """
        ).fetchone()

    if not row:
        return {
            "tz_name": "UTC",
            "run_time": "00:05",
            "days_ahead": 365,
            "enabled": False,
            "updated_at_utc": None,
            "last_run_at_utc": None,
            "last_run_date_key": None,
        }

    return {
        "tz_name": str(row["tz_name"] or "UTC"),
        "run_time": str(row["run_time"] or "00:05"),
        "days_ahead": int(row["days_ahead"] or 365),
        "enabled": bool(int(row["enabled"] or 0)),
        "updated_at_utc": row["updated_at_utc"],
        "last_run_at_utc": row["last_run_at_utc"],
        "last_run_date_key": row["last_run_date_key"],
    }

def set_live_options_schedule(*, run_time_utc: str, days_ahead: int, enabled: bool) -> None:
    """
    Update live options schedule in DB (UTC). Overwrites previous settings.
    """
    from datetime import datetime, timezone

    # basic validation
    rt = (run_time_utc or "").strip()
    hh, mm = 0, 0
    try:
        hh, mm = [int(x) for x in rt.split(":")]
        assert 0 <= hh <= 23 and 0 <= mm <= 59
    except Exception:
        raise ValueError("run_time_utc must be in HH:MM (00-23:00-59)")

    now_utc = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

    with _connect() as conn:
        conn.execute(
            """
            INSERT INTO live_options_schedule (id, tz_name, run_time, days_ahead, enabled, updated_at_utc)
            VALUES (1, 'UTC', ?, ?, ?, ?)
            ON CONFLICT(id) DO UPDATE SET
                tz_name='UTC',
                run_time=excluded.run_time,
                days_ahead=excluded.days_ahead,
                enabled=excluded.enabled,
                updated_at_utc=excluded.updated_at_utc
            """,
            (f"{hh:02d}:{mm:02d}", int(days_ahead), 1 if enabled else 0, now_utc),
        )
        conn.commit()

def upsert_live_options_schedule(
    *,
    tz_name: str,
    run_time: str,
    days_ahead: int,
    enabled: bool = True,
    db_path: str = DB_PATH,
) -> dict:
    import sqlite3
    from datetime import datetime, timezone

    now_utc = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

    con = sqlite3.connect(db_path)
    try:
        con.execute("""
        CREATE TABLE IF NOT EXISTS live_options_schedule (
          id INTEGER PRIMARY KEY CHECK (id = 1),
          tz_name TEXT NOT NULL DEFAULT 'Africa/Cairo',
          run_time TEXT NOT NULL DEFAULT '00:05',
          days_ahead INTEGER NOT NULL DEFAULT 365,
          enabled INTEGER NOT NULL DEFAULT 1,
          updated_at_utc TEXT NOT NULL,
          last_run_at_utc TEXT,
          last_run_date_key TEXT
        );
        """)

        # Upsert single row id=1, overwriting if changed
        con.execute("""
        INSERT INTO live_options_schedule
          (id, tz_name, run_time, days_ahead, enabled, updated_at_utc)
        VALUES
          (1, ?, ?, ?, ?, ?)
        ON CONFLICT(id) DO UPDATE SET
          tz_name       = excluded.tz_name,
          run_time      = excluded.run_time,
          days_ahead    = excluded.days_ahead,
          enabled       = excluded.enabled,
          updated_at_utc= excluded.updated_at_utc;
        """, (tz_name, run_time, int(days_ahead), 1 if enabled else 0, now_utc))

        con.commit()

        row = con.execute("SELECT tz_name, run_time, days_ahead, enabled FROM live_options_schedule WHERE id=1").fetchone()
        return {"tz_name": row[0], "run_time": row[1], "days_ahead": row[2], "enabled": bool(row[3])}
    finally:
        con.close()

def get_last_live_options_rows(limit: int = 10) -> list[dict]:
    """Read latest snapshot rows from Parquet (replaces SQLite btc_live_options)."""
    try:
        from multi_agent_system.snapshot_pipeline import read_latest_snapshot
        df = read_latest_snapshot()
        if df.empty:
            return []
        # Sort by snapshot_ts descending if available
        if "snapshot_ts" in df.columns:
            df = df.sort_values("snapshot_ts", ascending=False)
        return df.head(int(limit)).to_dict(orient="records")
    except Exception:
        return []

def count_live_options_for_snapshot_date(snapshot_date: str) -> int:
    """Count snapshot rows for a given date from Parquet."""
    try:
        from datetime import date as _date
        from multi_agent_system.snapshot_pipeline import read_snapshot_for_date
        dt = _date.fromisoformat(snapshot_date)
        df = read_snapshot_for_date(dt)
        return len(df)
    except Exception:
        return 0

def mark_live_options_ran(*, date_key_utc: str, ran_at_utc: str) -> None:
    with _connect() as conn:
        conn.execute(
            """
            UPDATE live_options_schedule
            SET last_run_at_utc=?, last_run_date_key=?
            WHERE id=1
            """,
            (ran_at_utc, date_key_utc),
        )
        conn.commit()
