"""Auth routes for the React front-end: login + token re-hydration.

Verifies credentials against the SAME `auth.sqlite` / `streamlit_users` table
the Streamlit app uses (identical bcrypt hashes). `shared/auth` is reused
unchanged - no separate user store, no password migration.
"""
from __future__ import annotations

import logging

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel

from shared.auth import (
    ALL_PAGES,
    create_streamlit_users_table,
    get_user,
    update_last_login,
    verify_password,
)
from shared.db_paths import AUTH_DB

from backend_api.auth_jwt import get_current_user, issue_token

log = logging.getLogger("backend-api.auth")

router = APIRouter(prefix="/api/auth", tags=["auth"])

_DB = str(AUTH_DB)
try:
    create_streamlit_users_table(_DB)
except Exception as e:  # pragma: no cover - startup best-effort
    log.error("could not ensure streamlit_users table in %s: %s", AUTH_DB, e)


class LoginRequest(BaseModel):
    username: str
    password: str


class UserOut(BaseModel):
    username: str
    role: str
    pages: list[str]


class LoginResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    expires_at: int
    user: UserOut


def _effective_pages(role: str, pages: list[str]) -> list[str]:
    """Operators get every page; viewers get exactly their DB list.

    Mirrors `shared/streamlit_auth._set_session`.
    """
    return list(ALL_PAGES) if role == "operator" else list(pages or [])


@router.post("/login", response_model=LoginResponse)
def login(req: LoginRequest) -> LoginResponse:
    username = (req.username or "").strip()
    if not username or not req.password:
        raise HTTPException(
            status.HTTP_400_BAD_REQUEST, "Username and password are required"
        )

    user = get_user(_DB, username)
    if user is None or not verify_password(req.password, user["password"]):
        log.warning("login failed for '%s'", username)
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Invalid credentials")

    pages = _effective_pages(user["role"], user["pages"])
    token, exp = issue_token(username, user["role"], pages)
    try:
        update_last_login(_DB, username)
    except Exception:  # pragma: no cover - non-critical
        pass
    log.info("user '%s' logged in (role=%s)", username, user["role"])
    return LoginResponse(
        access_token=token,
        expires_at=exp,
        user=UserOut(username=username, role=user["role"], pages=pages),
    )


@router.get("/me", response_model=UserOut)
def me(user: dict = Depends(get_current_user)) -> UserOut:
    """Re-hydrate the current user from a stored token (React app load)."""
    return UserOut(username=user["username"], role=user["role"], pages=user["pages"])
