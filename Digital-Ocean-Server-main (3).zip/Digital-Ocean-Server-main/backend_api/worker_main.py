from __future__ import annotations

import logging
import sys
import threading
import time
import traceback
from typing import Any, Optional
import os
from backend_api.jobs import (
    init_jobs_table,
    claim_next_job,
    recover_stale_running_jobs,
    set_job_failed,
)
from backend_api.executor import run_job_in_background
from backend_api.scheduler import (
    start_scheduler,
    start_models_scheduler,
    start_live_options_scheduler,
    start_fees_scheduler,
    start_options_ohlcv_scheduler,
)

log = logging.getLogger("worker")


def configure_logging(level: int = logging.INFO) -> None:
    """
    Worker should OWN the logging config so everything prints in the worker terminal.
    """
    root = logging.getLogger()
    root.setLevel(level)

    # Hard reset handlers so we don't inherit weird configs from imports
    for h in list(root.handlers):
        root.removeHandler(h)

    handler = logging.StreamHandler(sys.stdout)  # IMPORTANT: stdout (not stderr)
    handler.setLevel(level)
    handler.setFormatter(logging.Formatter(
        "%(asctime)s | %(levelname)s | %(name)s | %(message)s"
    ))
    root.addHandler(handler)

    logging.captureWarnings(True)

    # Ensure common loggers propagate to root
    for name in ("uvicorn", "uvicorn.error", "uvicorn.access", "fastapi"):
        lg = logging.getLogger(name)
        lg.propagate = True


def main():
    configure_logging(logging.INFO)
    log.info("### WORKER_MAIN main() reached ###")

    # Ensure jobs table exists
    init_jobs_table()

    # Recover stale running jobs (e.g., after container restart)
    recovered = recover_stale_running_jobs(max_age_seconds=30 * 60)
    if recovered:
        log.warning("Recovered %s stale running jobs", recovered)

    # Start refresh scheduler loop in this worker
    stop_event = threading.Event()

    refresh_thread = start_scheduler(stop_event)
    log.info("Worker started; refresh_thread=%s", refresh_thread.name)

    models_thread = start_models_scheduler(stop_event)
    log.info("Worker started; models_thread=%s", models_thread.name)
    
    live_opts_thread = start_live_options_scheduler(stop_event)
    log.info("Worker started; live_opts_thread=%s", live_opts_thread.name)

    fees_thread = start_fees_scheduler(stop_event)
    log.info("Worker started; fees_thread=%s", fees_thread.name)

    options_ohlcv_thread = start_options_ohlcv_scheduler(stop_event)
    log.info("Worker started; options_ohlcv_thread=%s", options_ohlcv_thread.name)

    try:
        while True:
            job = claim_next_job(exclude_job_types={"refresh_1min"})
            if not job:
                time.sleep(1.0)
                continue

            job_id = str(job["job_id"])
            job_type = str(job["job_type"])
            payload = job.get("payload_json") or {}

            log.info("Claimed job job_id=%s job_type=%s", job_id, job_type)

            try:
                run_job_in_background(job_id, job_type, payload)
            except Exception as e:
                err = f"{e}\n{traceback.format_exc()}"
                log.error("Job crashed job_id=%s: %s", job_id, err)
                set_job_failed(job_id, err)

    except KeyboardInterrupt:
        log.info("Worker stopping (KeyboardInterrupt)")
    finally:
        stop_event.set()
        log.info("Worker shutdown complete")


if __name__ == "__main__":
    main()
