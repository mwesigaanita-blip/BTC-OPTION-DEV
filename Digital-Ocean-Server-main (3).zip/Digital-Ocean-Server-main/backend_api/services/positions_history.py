"""Positions-history analytics.

Ports the Streamlit ``Positions_History`` page logic to a JSON service:
reads daily snapshots from ``snapshots.sqlite`` (``positions_snapshots`` +
``account_snapshots``) and deposit/withdrawal flows from ``trading.sqlite``,
builds a per-day time series and performance windows. Business logic is kept
identical to the Streamlit page.
"""
from __future__ import annotations

import json
import sqlite3
from typing import Any

import numpy as np
import pandas as pd

from shared.db_paths import SNAPSHOTS_DB, TRADING_DB

_NUM_COLS = [
    "qty", "size", "DTE", "strike",
    "pnl_usd_total", "pnl_usd_total_deribit", "pnl_usd_total_model",
    "pnl_btc_total_deribit",
    "total_profit_loss", "floating_profit_loss", "realized_profit_loss",
    "mark_usd", "avg_price_usd", "mark_price_btc", "avg_price_btc",
    "index_price", "delta", "gamma", "theta", "vega",
    "initial_margin", "maintenance_margin",
]


def _records_to_df(payload_json: str) -> pd.DataFrame:
    try:
        records = json.loads(payload_json) if payload_json else []
        if isinstance(records, dict) and "rows" in records:
            records = records["rows"]
        return pd.DataFrame(records)
    except Exception:
        return pd.DataFrame([])


def _coerce(df: pd.DataFrame, cols: list[str]) -> pd.DataFrame:
    for c in cols:
        if c in df.columns:
            df[c] = pd.to_numeric(df[c], errors="coerce")
    return df


def _clean(v: Any) -> Any:
    """JSON-safe scalar - NaN/inf → None."""
    if v is None:
        return None
    if isinstance(v, float) and not np.isfinite(v):
        return None
    if isinstance(v, (np.integer,)):
        return int(v)
    if isinstance(v, (np.floating,)):
        f = float(v)
        return f if np.isfinite(f) else None
    return v


def _compute_pnl_kpis(df: pd.DataFrame) -> dict:
    """Per-day PnL KPIs - mirrors the Streamlit `compute_pnl_kpis`."""
    pnl_total_usd = 0.0
    pnl_float_usd = 0.0
    pnl_real_usd = 0.0

    if "pnl_usd_total" in df.columns and df["pnl_usd_total"].notna().any():
        pnl_total_usd = float(df["pnl_usd_total"].fillna(0).sum())
    elif {"total_profit_loss", "index_price"} <= set(df.columns):
        pnl_total_usd = float(
            (df["total_profit_loss"].fillna(0).astype(float)
             * df["index_price"].fillna(0).astype(float)).sum()
        )
    elif {"mark_usd", "avg_price_usd", "qty", "side"} <= set(df.columns):
        diff = df["mark_usd"].astype(float) - df["avg_price_usd"].astype(float)
        per = np.where(df["side"].astype(str).str.upper().eq("SELL"), -diff, diff)
        pnl_total_usd = float(np.nansum(per * df["qty"].fillna(0).astype(float)))

    if {"floating_profit_loss", "index_price"} <= set(df.columns):
        pnl_float_usd = float(
            (df["floating_profit_loss"].fillna(0).astype(float)
             * df["index_price"].fillna(0).astype(float)).sum()
        )
    elif {"mark_usd", "avg_price_usd", "qty", "side"} <= set(df.columns):
        diff = df["mark_usd"].astype(float) - df["avg_price_usd"].astype(float)
        per = np.where(df["side"].astype(str).str.upper().eq("SELL"), -diff, diff)
        pnl_float_usd = float(np.nansum(per * df["qty"].fillna(0).astype(float)))

    if {"realized_profit_loss", "index_price"} <= set(df.columns):
        pnl_real_usd = float(
            (df["realized_profit_loss"].fillna(0).astype(float)
             * df["index_price"].fillna(0).astype(float)).sum()
        )

    total_qty = float(df["qty"].fillna(0).sum()) if "qty" in df.columns else 0.0
    total_pnl_btc = (
        float(df["pnl_btc_total_deribit"].fillna(0).sum())
        if "pnl_btc_total_deribit" in df.columns
        else 0.0
    )
    return {
        "pnl_total_usd": pnl_total_usd,
        "pnl_float_usd": pnl_float_usd,
        "pnl_real_usd": pnl_real_usd,
        "total_qty": total_qty,
        "total_pnl_btc": total_pnl_btc,
    }


def _compute_day_metrics(df: pd.DataFrame) -> dict:
    df = _coerce(df, _NUM_COLS)
    k = _compute_pnl_kpis(df)
    greeks = {
        g: (float(df[g].fillna(0).sum()) if g in df.columns else 0.0)
        for g in ("delta", "gamma", "theta", "vega")
    }
    contracts = (
        float(df["qty"].fillna(0).sum()) if "qty" in df.columns else float(len(df))
    )
    min_dte = (
        float(df["DTE"].min())
        if "DTE" in df.columns and df["DTE"].notna().any()
        else None
    )
    idx_price = (
        float(df["index_price"].dropna().iloc[0])
        if "index_price" in df.columns and df["index_price"].notna().any()
        else None
    )
    return {
        "pnl_total_usd": k["pnl_total_usd"],
        "pnl_float_usd": k["pnl_float_usd"],
        "pnl_real_usd": k["pnl_real_usd"],
        "pnl_total_btc": k["total_pnl_btc"],
        "contracts": contracts,
        "open_positions": float(len(df)),
        "delta_sum": greeks["delta"],
        "gamma_sum": greeks["gamma"],
        "theta_sum": greeks["theta"],
        "vega_sum": greeks["vega"],
        "min_dte": min_dte,
        "index_price": idx_price,
    }


def _load_position_snapshots() -> pd.DataFrame:
    with sqlite3.connect(str(SNAPSHOTS_DB)) as conn:
        return pd.read_sql_query(
            "SELECT date, payload_json, updated_at FROM positions_snapshots "
            "ORDER BY date DESC",
            conn,
        )


def _load_capital_history() -> pd.DataFrame:
    with sqlite3.connect(str(SNAPSHOTS_DB)) as conn:
        df = pd.read_sql_query(
            "SELECT date, payload_json FROM account_snapshots", conn
        )
    rows = []
    for _, row in df.iterrows():
        try:
            data = json.loads(row["payload_json"])
            cap = data.get("total_equity_usd")
            if cap is None or float(cap) <= 0:
                cap = data.get("capital_usd") or data.get("equity_usd") or 0
            cap = float(cap)
            per_cur = data.get("per_currency") or {}
            btc_acc = per_cur.get("BTC") or {}
            idx = float(
                btc_acc.get("index_price_usd")
                or (data.get("btc_changes") or {}).get("index_price_usd")
                or data.get("index_price_usd")
                or 0
            )
            btc = (cap / idx) if cap > 0 and idx > 0 else None
            rows.append({
                "date": row["date"],
                "total_portfolio_usd": cap,
                "total_portfolio_btc": round(btc, 6) if btc is not None else None,
            })
        except Exception:
            continue
    res = pd.DataFrame(rows)
    if not res.empty:
        res["date"] = pd.to_datetime(res["date"]).dt.tz_localize(None).dt.normalize()
        res = (
            res.groupby("date")[["total_portfolio_usd", "total_portfolio_btc"]]
            .last()
            .reset_index()
            .sort_values("date")
            .reset_index(drop=True)
        )
        for col in ("total_portfolio_usd", "total_portfolio_btc"):
            res[col] = res[col].replace(0, pd.NA).ffill().bfill().fillna(0)
    return res


def _load_flows() -> pd.DataFrame:
    with sqlite3.connect(str(TRADING_DB)) as conn:
        df = pd.read_sql_query(
            "SELECT ts_utc, type, amount_btc FROM account_flows", conn
        )
    if df.empty:
        return pd.DataFrame(columns=["date", "flow_val"])
    df["date"] = pd.to_datetime(df["ts_utc"]).dt.tz_localize(None).dt.normalize()
    df["flow_val"] = df.apply(
        lambda x: x["amount_btc"]
        if str(x["type"]).lower() == "deposit"
        else -x["amount_btc"],
        axis=1,
    )
    return df.groupby("date")["flow_val"].sum().reset_index()


def _pct_change(ts: pd.DataFrame, days: int | None = None, ytd: bool = False) -> dict:
    if ts.empty or "total_portfolio_usd" not in ts.columns:
        return {"pct": 0.0, "abs": 0.0}
    latest_val = ts["total_portfolio_usd"].iloc[-1]
    latest_date = ts["date"].iloc[-1]
    if ytd:
        target = pd.Timestamp(year=latest_date.year, month=1, day=1)
    else:
        target = latest_date - pd.Timedelta(days=days or 0)
    past = ts[ts["date"] <= target]
    past_val = (
        past["total_portfolio_usd"].iloc[-1]
        if not past.empty
        else ts["total_portfolio_usd"].iloc[0]
    )
    if not past_val:
        return {"pct": 0.0, "abs": 0.0}
    return {
        "pct": round((latest_val - past_val) / past_val * 100.0, 2),
        "abs": round(latest_val - past_val, 2),
    }


def get_portfolio_history() -> dict:
    """Per-day time series + performance windows + drilldown dates."""
    snaps = _load_position_snapshots()
    if snaps.empty:
        return {"timeseries": [], "performance": {}, "dates": [], "latest": None}

    rows = []
    for _, row in snaps.iterrows():
        df_day = _records_to_df(row.get("payload_json", ""))
        if df_day.empty:
            rows.append({"date": str(row["date"]), "open_positions": 0})
            continue
        m = _compute_day_metrics(df_day)
        m["date"] = str(row["date"])
        m["updated_at"] = str(row.get("updated_at") or "")
        rows.append(m)

    ts = pd.DataFrame(rows)
    ts["date"] = pd.to_datetime(ts["date"], errors="coerce")
    ts = ts.dropna(subset=["date"]).sort_values("date").reset_index(drop=True)
    ts["date_only"] = ts["date"].dt.tz_localize(None).dt.normalize()

    cap = _load_capital_history()
    if not cap.empty:
        ts = pd.merge(
            ts, cap, left_on="date_only", right_on="date",
            how="left", suffixes=("", "_drop"),
        )
        ts["total_portfolio_usd"] = ts["total_portfolio_usd"].ffill().round(2)
        if "total_portfolio_btc" in ts.columns:
            ts["total_portfolio_btc"] = (
                pd.to_numeric(ts["total_portfolio_btc"], errors="coerce")
                .ffill()
                .round(4)
            )
    if "total_portfolio_usd" not in ts.columns:
        ts["total_portfolio_usd"] = 0.0
    if "total_portfolio_btc" not in ts.columns:
        ts["total_portfolio_btc"] = np.nan

    flows = _load_flows()
    if not flows.empty:
        ts = pd.merge(
            ts, flows, left_on="date_only", right_on="date",
            how="left", suffixes=("", "_f"),
        )
        ts["flow_val"] = ts["flow_val"].fillna(0).round(4)
    else:
        ts["flow_val"] = 0.0
    ts["event_type"] = "None"
    ts.loc[ts["flow_val"] > 0.0001, "event_type"] = "Deposit"
    ts.loc[ts["flow_val"] < -0.0001, "event_type"] = "Withdrawal"

    # Fill gaps so charts stay continuous instead of dropping to zero on
    # missing days. ffill carries the previous known value forward; bfill
    # then handles any leading NaNs (= take the nearest next value).
    _FILL_COLS = [
        "pnl_total_usd", "pnl_float_usd", "pnl_real_usd", "pnl_total_btc",
        "open_positions", "contracts",
        "delta_sum", "gamma_sum", "theta_sum", "vega_sum",
        "index_price", "min_dte",
    ]
    for col in _FILL_COLS:
        if col in ts.columns:
            ts[col] = pd.to_numeric(ts[col], errors="coerce").ffill().bfill()

    perf = {
        "1d": _pct_change(ts, days=1),
        "3d": _pct_change(ts, days=3),
        "1w": _pct_change(ts, days=7),
        "1m": _pct_change(ts, days=30),
        "3m": _pct_change(ts, days=90),
        "6m": _pct_change(ts, days=180),
        "1y": _pct_change(ts, days=365),
        "ytd": _pct_change(ts, ytd=True),
    }

    keep = [
        "date", "total_portfolio_usd", "total_portfolio_btc",
        "pnl_total_usd", "pnl_float_usd", "pnl_real_usd", "pnl_total_btc",
        "open_positions", "contracts", "delta_sum", "gamma_sum",
        "theta_sum", "vega_sum", "flow_val", "event_type", "index_price",
        "min_dte", "updated_at",
    ]
    series = []
    for _, r in ts.iterrows():
        item: dict[str, Any] = {}
        for c in keep:
            if c == "date":
                item["date"] = r["date"].strftime("%Y-%m-%d")
            elif c in ts.columns:
                item[c] = _clean(r[c])
            else:
                item[c] = None
        series.append(item)

    latest = series[-1] if series else None
    return {
        "timeseries": series,
        "performance": perf,
        "dates": [str(d) for d in snaps["date"].tolist()],
        "latest": latest,
    }


def get_day_positions(day: str) -> dict:
    """Positions + KPIs for a single snapshot day (drilldown)."""
    with sqlite3.connect(str(SNAPSHOTS_DB)) as conn:
        cur = conn.execute(
            "SELECT payload_json, updated_at FROM positions_snapshots "
            "WHERE date = ?",
            (day,),
        )
        row = cur.fetchone()
    if not row:
        return {"date": day, "updated_at": None, "kpis": {}, "positions": []}

    df = _coerce(_records_to_df(row[0]), _NUM_COLS)
    kpis = _compute_pnl_kpis(df) if not df.empty else {}
    positions: list[dict] = []
    if not df.empty:
        for rec in df.to_dict(orient="records"):
            positions.append({k: _clean(v) for k, v in rec.items()})
    return {
        "date": day,
        "updated_at": row[1],
        "kpis": {k: _clean(v) for k, v in kpis.items()},
        "positions": positions,
    }
