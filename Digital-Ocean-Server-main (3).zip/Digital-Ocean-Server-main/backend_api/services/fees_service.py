from __future__ import annotations

import os
import time
import logging
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

import requests # type: ignore

from backend_api.db.fees_repo import (
    ensure_fee_tables,
    get_latest_fee_timestamp_ms,
    insert_fee_events,
    get_unnotified_fee_events,
    mark_fee_events_notified,
)
from backend_api.notify.telegram_sender import send_telegram_message

log = logging.getLogger("fees-service")
log.propagate = True


def _env_bool(name: str, default: str = "1") -> bool:
    v = (os.getenv(name, default) or default).strip().lower()
    return v in ("1", "true", "yes", "y", "on")


def _env_int(name: str, default: str) -> int:
    return int((os.getenv(name, default) or default).strip())


def _env_float(name: str, default: str) -> float:
    return float((os.getenv(name, default) or default).strip())


def _ms_to_iso(ms: int) -> str:
    return datetime.fromtimestamp(ms / 1000.0, tz=timezone.utc).isoformat()


class DeribitRPC:
    """
    Minimal Deribit JSON-RPC client for:
      - public/auth (client_credentials)
      - private/get_user_trades_by_currency_and_time
    """

    def __init__(self, *, client_id: str, client_secret: str, base_url: str = "https://www.deribit.com/api/v2"):
        self.client_id = client_id
        self.client_secret = client_secret
        self.base_url = base_url.rstrip("/")
        self._access_token: Optional[str] = None
        self._token_expiry_epoch: float = 0.0

    def _rpc(self, method: str, params: Dict[str, Any], *, access_token: Optional[str] = None) -> Dict[str, Any]:
        payload = {"jsonrpc": "2.0", "id": 1, "method": method, "params": params}
        headers = {"Content-Type": "application/json"}
        if access_token:
            headers["Authorization"] = f"bearer {access_token}"

        url = f"{self.base_url}/{method}"
        r = requests.post(url, json=payload, headers=headers, timeout=20)
        r.raise_for_status()
        j = r.json()

        if "error" in j and j["error"]:
            raise RuntimeError(f"Deribit RPC error: {j['error']}")
        return j.get("result") or {}

    def ensure_token(self) -> str:
        now = time.time()
        if self._access_token and now < (self._token_expiry_epoch - 30):
            return self._access_token

        res = self._rpc(
            "public/auth",
            {
                "grant_type": "client_credentials",
                "client_id": self.client_id,
                "client_secret": self.client_secret,
            },
        )

        token = res.get("access_token")
        expires_in = float(res.get("expires_in") or 0.0)
        if not token:
            raise RuntimeError(f"Deribit auth failed: {res}")

        self._access_token = token
        self._token_expiry_epoch = time.time() + expires_in
        return token

    def get_user_trades_since(
        self,
        *,
        currency: str,
        start_timestamp_ms: int,
        end_timestamp_ms: Optional[int] = None,
        count: int = 1000,
    ) -> List[Dict[str, Any]]:
        token = self.ensure_token()
        all_trades: List[Dict[str, Any]] = []
        continuation: Optional[str] = None

        while True:
            params: Dict[str, Any] = {
                "currency":        currency,
                "start_timestamp": int(start_timestamp_ms),
                "count":           int(count),
                "historical":      True,   # REQUIRED: access full indexed archive
                "sorting":         "asc",  # oldest first → safe incremental inserts
            }
            if end_timestamp_ms is not None:
                params["end_timestamp"] = int(end_timestamp_ms)
            if continuation:
                params["continuation"] = continuation

            res = self._rpc(
                "private/get_user_trades_by_currency_and_time",
                params,
                access_token=token,
            )
            trades = res.get("trades") or []
            all_trades.extend(trades)

            continuation = res.get("continuation")
            if not continuation or not trades:
                break

            time.sleep(0.25)  # respect rate limit between pages

        return all_trades


def _format_fee_alert(rows: List[Dict[str, Any]]) -> str:
    total_fee = sum(float(r.get("fee_amount") or 0.0) for r in rows)
    ccy = (rows[0].get("fee_currency") or "").upper() if rows else ""
    n = len(rows)

    lines = [
        "💸 <b>FEES DETECTED</b>",
        f"Count: {n}",
        f"Total: {total_fee:.8f} {ccy}",
        "",
    ]

    for r in rows[:10]:
        t = _ms_to_iso(int(r["timestamp_ms"]))
        inst = r.get("instrument_name") or "?"
        side = r.get("side") or "?"
        fee = float(r.get("fee_amount") or 0.0)
        fee_usd = r.get("fee_usd")
        if fee_usd is not None:
            lines.append(f"- {t} | {inst} | {side} | {fee:.8f} {ccy} (~${float(fee_usd):.2f})")
        else:
            lines.append(f"- {t} | {inst} | {side} | {fee:.8f} {ccy}")

    if n > 10:
        lines.append(f"... plus {n-10} more")

    return "\n".join(lines)


def ingest_fees_once() -> Dict[str, Any]:
    """
    One-shot fees ingestion + telegram notify.
    Safe to call repeatedly; DB insert is idempotent by (source, trade_id).
    Fetches BTC + USDT currencies. Uses historical=true for full archive access.
    """
    ensure_fee_tables()

    if not _env_bool("FEES_ENABLED", "1"):
        return {"enabled": False}

    client_id = (os.getenv("DERIBIT_CLIENT_ID") or "").strip()
    client_secret = (os.getenv("DERIBIT_CLIENT_SECRET") or "").strip()
    if not client_id or not client_secret:
        raise RuntimeError("Missing DERIBIT_CLIENT_ID / DERIBIT_CLIENT_SECRET")

    # Always fetch both currencies - account is multi-currency (BTC + USDT)
    currencies = ["BTC", "USDT"]
    min_fee = _env_float("FEES_NOTIFY_MIN", "0.0")
    notify_batch = _env_int("FEES_NOTIFY_BATCH", "20")

    # Start timestamp: resume from last saved, or fetch full history (epoch 0)
    last_ts = get_latest_fee_timestamp_ms()
    start_ts = (last_ts + 1) if last_ts is not None else 0
    end_ts = int(time.time() * 1000)

    log.info(f"Fee sync: {_ms_to_iso(start_ts)} → {_ms_to_iso(end_ts)}, currencies={currencies}")

    rpc = DeribitRPC(client_id=client_id, client_secret=client_secret)
    total_trades = 0
    fee_rows: List[Dict[str, Any]] = []

    for currency in currencies:
        trades = rpc.get_user_trades_since(
            currency=currency,
            start_timestamp_ms=start_ts,
            end_timestamp_ms=end_ts,
        )
        total_trades += len(trades)
        log.info(f"  [{currency}] fetched {len(trades)} trades")

        for t in trades:
            fee = t.get("fee")
            if fee is None:
                continue
            fee_amt = abs(float(fee or 0.0))  # store as positive cost
            if fee_amt == 0.0:
                continue

            ts_ms = t.get("timestamp")
            if ts_ms is None:
                continue

            idx = t.get("index_price")
            fee_usd = None
            idx_f = None
            if idx is not None:
                try:
                    idx_f = float(idx)
                    fee_ccy = (t.get("fee_currency") or currency).upper()
                    if fee_ccy == "BTC":
                        fee_usd = fee_amt * idx_f
                    elif fee_ccy in ("USDT", "USDC", "USD"):
                        fee_usd = fee_amt  # already USD-denominated
                except Exception:
                    pass

            fee_rows.append({
                "source":          "deribit",
                "trade_id":        t.get("trade_id"),
                "order_id":        t.get("order_id"),
                "instrument_name": t.get("instrument_name"),
                "side":            (t.get("direction") or t.get("side") or "").upper(),
                "fee_currency":    (t.get("fee_currency") or currency).upper(),
                "fee_amount":      fee_amt,
                "price":           t.get("price"),
                "amount":          t.get("amount"),
                "timestamp_ms":    int(ts_ms),
                "index_price_usd": idx_f,
                "fee_usd":         fee_usd,
            })

    inserted = insert_fee_events(fee_rows)
    log.info(f"Inserted {inserted} fee rows")

    # Telegram notify
    pending = get_unnotified_fee_events(limit=notify_batch, min_fee=min_fee)
    if pending:
        send_telegram_message(_format_fee_alert(pending))
        mark_fee_events_notified([int(r["id"]) for r in pending])

    return {
        "enabled":        True,
        "fetched_trades": total_trades,
        "fee_rows":       len(fee_rows),
        "inserted":       inserted,
        "notified":       len(pending),
    }