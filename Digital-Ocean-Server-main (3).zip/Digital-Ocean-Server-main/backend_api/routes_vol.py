"""Volatility (HV vs IV) routes."""

from __future__ import annotations

import logging
import threading
import time
from typing import Literal

from fastapi import APIRouter, Depends, HTTPException, Query, status

from backend_api.auth_jwt import require_page
from portfolio_analysis_AI_Agent.tools.composite.hv_iv_series import hv_iv_series
from portfolio_analysis_AI_Agent.tools.composite.volatility_dashboard import (
    volatility_dashboard,
)

log = logging.getLogger("backend-api.vol")

router = APIRouter(prefix="/api/vol", tags=["vol"])

_PAGE = "Volatility"

# --- TTL cache (5 min). Vol moves slowly. ---------------------------------
_TTL_SEC = 300
_cache_lock = threading.Lock()
_cache: dict[object, tuple[float, dict]] = {}


def _cached_series(days: int, resolution: str) -> dict:
    key = (days, resolution)
    now = time.time()
    with _cache_lock:
        hit = _cache.get(key)
        if hit and now - hit[0] < _TTL_SEC:
            return hit[1]
    payload = hv_iv_series(days=days, resolution=resolution)  # type: ignore[arg-type]
    with _cache_lock:
        _cache[key] = (now, payload)
    return payload


@router.get("/dashboard")
def vol_dashboard(
    lookback_days: int = Query(default=365, ge=30, le=1825,
                                description="History window for series and 1Y stats"),
    user: dict = Depends(require_page(_PAGE)),
) -> dict:
    """Hedgeye-style vol panel: RVOL/IVOL + 30D/90D stats + premium series."""
    key = f"vol_dashboard:{lookback_days}"
    now = time.time()
    with _cache_lock:
        hit = _cache.get(key)
        if hit and now - hit[0] < _TTL_SEC:
            return hit[1]
    try:
        payload = volatility_dashboard(lookback_days=lookback_days)
    except Exception as e:  # pragma: no cover
        log.exception("vol dashboard failed")
        raise HTTPException(
            status.HTTP_502_BAD_GATEWAY,
            f"Failed to build vol dashboard: {e}",
        )
    with _cache_lock:
        _cache[key] = (now, payload)
    return payload


@router.get("/hv-iv")
def hv_iv(
    days: int = Query(default=30, ge=1, le=1825, description="Lookback in days (1..1825)"),
    resolution: Literal["1D", "1H"] = Query(default="1D"),
    user: dict = Depends(require_page(_PAGE)),
) -> dict:
    """Unified HV vs IV series.

    Hourly resolution is gated to ``days <= 90`` to keep payloads sane (a
    5-year hourly pull would be ~44k rows and pointless visually).
    """
    if resolution == "1H" and days > 90:
        raise HTTPException(
            status.HTTP_422_UNPROCESSABLE_ENTITY,
            "Hourly resolution is limited to days <= 90; use 1D for longer lookbacks.",
        )
    try:
        return _cached_series(days, resolution)
    except Exception as e:  # pragma: no cover
        log.exception("hv-iv failed")
        raise HTTPException(
            status.HTTP_502_BAD_GATEWAY,
            f"Failed to build HV/IV series: {e}",
        )
