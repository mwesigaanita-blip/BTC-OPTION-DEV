"""MM / IM Simulator routes - wrap `shared/simulation_service.py`.

The page lets users mutate their live Deribit book (adjust existing
positions, add new option/perpetual trades) and pulls fresh MM% / IM%
numbers from Deribit's `private/simulate_portfolio` API for both the
*before* and the *after* states. All Deribit calls happen server-side -
the browser never holds API credentials.

JWT-protected; access gated by the `MM_IM_Simulator` page grant.
"""
from __future__ import annotations

import logging
import os
import time
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, Field

from backend_api.auth_jwt import require_page
from hedge_engine.risk.stress.pricing_bs import black_scholes_price
from shared.redis_live import get_market_live
from shared.simulation_service import (
    fetch_current_positions_for_simulation,
    fetch_instrument_quote,
    find_option_instrument,
    get_option_chain_selection_data,
    run_portfolio_simulation_compare,
)

log = logging.getLogger("backend-api.mm_im")

router = APIRouter(prefix="/api/mm-im", tags=["mm-im"])

_PAGE = "MM_IM_Simulator"


def _creds() -> tuple[str, str]:
    cid = os.getenv("DERIBIT_CLIENT_ID", "").strip()
    sec = os.getenv("DERIBIT_CLIENT_SECRET", "").strip()
    if not cid or not sec:
        raise HTTPException(
            status.HTTP_503_SERVICE_UNAVAILABLE,
            "DERIBIT_CLIENT_ID / DERIBIT_CLIENT_SECRET not configured on server",
        )
    return cid, sec


# ---------------------------------------------------------------------------
# Reads
# ---------------------------------------------------------------------------


@router.get("/positions")
def positions_and_chain(user: dict = Depends(require_page(_PAGE))) -> dict[str, Any]:
    """Single load: current positions across BTC/USDT/USDC + the option
    chain (expiries + strikes) used by the new-trade selector."""
    cid, sec = _creds()
    try:
        positions = fetch_current_positions_for_simulation(cid, sec)
    except Exception as e:
        log.exception("fetch_current_positions_for_simulation failed")
        raise HTTPException(
            status.HTTP_502_BAD_GATEWAY, f"Deribit positions fetch failed: {e}"
        )
    try:
        chain = get_option_chain_selection_data()
    except Exception as e:
        log.exception("get_option_chain_selection_data failed")
        raise HTTPException(
            status.HTTP_502_BAD_GATEWAY, f"Option chain fetch failed: {e}"
        )
    return {"positions": positions, "option_chain": chain}


@router.get("/quote/{instrument_name}")
def instrument_quote(
    instrument_name: str, user: dict = Depends(require_page(_PAGE))
) -> dict[str, Any]:
    try:
        return fetch_instrument_quote(instrument_name)
    except Exception as e:
        raise HTTPException(
            status.HTTP_502_BAD_GATEWAY, f"Quote fetch failed: {e}"
        )


class FindOptionParams(BaseModel):
    expiration_timestamp: int
    strike: float
    option_type: str  # "call" | "put"


@router.post("/find-option")
def find_option(
    body: FindOptionParams, user: dict = Depends(require_page(_PAGE))
) -> dict[str, Any]:
    """Resolve an (expiry, strike, type) tuple into a Deribit instrument
    name. Front-end could do this itself by string-formatting, but
    delegating keeps the format authoritative on the backend."""
    name = find_option_instrument(
        expiry_timestamp=int(body.expiration_timestamp),
        strike=float(body.strike),
        option_type=body.option_type,
    )
    return {"instrument_name": name}


# ---------------------------------------------------------------------------
# Run simulation
# ---------------------------------------------------------------------------


class Adjustment(BaseModel):
    instrument_name: str
    action: str = Field(pattern="^(no change|decrease|increase)$")
    amount: float = Field(ge=0.0)


class NewTrade(BaseModel):
    instrument_name: str
    side: str = Field(pattern="^(long|short)$")
    amount: float = Field(gt=0.0)
    # Optional user-locked entry price (BTC, the Deribit native unit for BTC
    # options). When provided, the backend uses this value instead of pulling
    # a fresh quote at submit time - so a user-recalculated IV-based price
    # flows through to the simulation as-is.
    entry_price: float | None = None


class PriceOptionBody(BaseModel):
    expiration_timestamp: int
    strike: float = Field(gt=0.0)
    option_type: str = Field(pattern="^(call|put)$")
    iv_pct: float = Field(gt=0.0, le=500.0)
    # Optional client-supplied spot override. If omitted, we use the live
    # BTC index from the WS->Redis snapshot (or fall back to a Deribit quote).
    spot_override: float | None = None


@router.post("/price-option")
def price_option(
    body: PriceOptionBody, user: dict = Depends(require_page(_PAGE))
) -> dict[str, Any]:
    """Recalculate an option's mark price under a user-supplied IV.

    Uses the pure Black-Scholes implementation from
    `hedge_engine.risk.stress.pricing_bs`. Returns both the USD price
    (BS native) and the BTC price (USD / spot) since Deribit BTC options
    are quoted in BTC.
    """
    if body.spot_override and body.spot_override > 0:
        spot = float(body.spot_override)
    else:
        market, _ = get_market_live()
        spot = float(
            (market or {}).get("btc_index") or (market or {}).get("perp_index") or 0.0
        )
        if spot <= 0:
            try:
                q = fetch_instrument_quote("BTC-PERPETUAL")
                spot = float(q.get("index_price") or 0.0)
            except Exception as e:  # pragma: no cover
                raise HTTPException(
                    status.HTTP_502_BAD_GATEWAY, f"Live spot lookup failed: {e}"
                )
    if spot <= 0:
        raise HTTPException(
            status.HTTP_503_SERVICE_UNAVAILABLE, "Live BTC spot unavailable"
        )

    now_ms = int(time.time() * 1000)
    t_years = max(
        0.0,
        (body.expiration_timestamp - now_ms) / (365.25 * 24 * 3600 * 1000),
    )
    iv = body.iv_pct / 100.0
    usd_price = black_scholes_price(
        spot=spot,
        strike=body.strike,
        t_years=t_years,
        iv=iv,
        option_type=body.option_type,  # type: ignore[arg-type]
    )
    btc_price = (usd_price / spot) if spot > 0 else 0.0
    log.info(
        "mm_im price-option: type=%s strike=%s exp_ts=%s iv_pct=%.4f "
        "t_years=%.6f spot=%.2f -> usd=%.4f btc=%.8f",
        body.option_type, body.strike, body.expiration_timestamp,
        body.iv_pct, t_years, spot, usd_price, btc_price,
    )
    return {
        "spot": spot,
        "t_years": t_years,
        "iv_decimal": iv,
        "iv_pct": body.iv_pct,
        "usd_price": round(usd_price, 4),
        "btc_price": round(btc_price, 8),
    }


class SimulateBody(BaseModel):
    adjustments: list[Adjustment] = []
    new_trades: list[NewTrade] = []


@router.post("/simulate")
def simulate(
    body: SimulateBody, user: dict = Depends(require_page(_PAGE))
) -> dict[str, Any]:
    cid, sec = _creds()
    return run_portfolio_simulation_compare(
        client_id=cid,
        client_secret=sec,
        adjustments=[a.model_dump() for a in body.adjustments],
        new_trades=[t.model_dump() for t in body.new_trades],
    )
