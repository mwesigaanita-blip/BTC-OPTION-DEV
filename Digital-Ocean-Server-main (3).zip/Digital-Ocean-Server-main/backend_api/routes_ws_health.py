"""WS Layer Health - proxies `/healthz` + `/metrics` from `ws_collector`
and `backend_ws` into one JSON blob the React page can consume.

The Streamlit equivalent (`Streamlit/pages/WS_Layer_Health.py`) scraped the
two services directly from the browser-side Streamlit process. The React
front-end can't do that (the services aren't on the public network), so
this backend route does it server-side and parses the Prometheus text-format
metrics into structured rows.
"""
from __future__ import annotations

import logging
import os
import re
from typing import Any

import requests
from fastapi import APIRouter, Depends

from backend_api.auth_jwt import require_page

log = logging.getLogger("backend-api.ws_health")

router = APIRouter(prefix="/api/ws-health", tags=["ws-health"])

_PAGE = "WS_Layer_Health"

_COLLECTOR_URL = os.getenv("WS_COLLECTOR_URL", "http://ws_collector:8101").rstrip("/")
_BACKEND_WS_URL = os.getenv("BACKEND_WS_URL", "http://backend_ws:8100").rstrip("/")
_STALENESS_THRESHOLD_S = float(os.getenv("WS_STALENESS_THRESHOLD_S", "90"))

_PROM_LINE = re.compile(
    r"^(?P<name>[a-zA-Z_:][a-zA-Z0-9_:]*)(?P<labels>\{[^}]*\})?\s+"
    r"(?P<value>[-+0-9.eEnaN]+)\s*$"
)
_CHANNEL_LABEL = re.compile(r'channel="([^"]+)"')


def _get_json(url: str, timeout: float = 3.0) -> tuple[dict | None, str | None]:
    try:
        r = requests.get(url, timeout=timeout)
        r.raise_for_status()
        return r.json(), None
    except Exception as e:
        return None, f"GET {url} failed: {e}"


def _get_text(url: str, timeout: float = 3.0) -> tuple[str | None, str | None]:
    try:
        r = requests.get(url, timeout=timeout)
        r.raise_for_status()
        return r.text, None
    except Exception as e:
        return None, f"GET {url} failed: {e}"


def _parse_prom(text: str) -> dict[tuple[str, str], float]:
    out: dict[tuple[str, str], float] = {}
    for raw in text.splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        m = _PROM_LINE.match(line)
        if not m:
            continue
        try:
            val = float(m.group("value"))
        except ValueError:
            continue
        out[(m.group("name"), m.group("labels") or "")] = val
    return out


def _sum_metric(parsed: dict, name: str) -> float:
    return sum(v for (n, _), v in parsed.items() if n == name)


def _per_label(parsed: dict, name: str) -> dict[str, float]:
    return {labels: v for (n, labels), v in parsed.items() if n == name}


def _channel_from_labels(labels: str) -> str:
    m = _CHANNEL_LABEL.search(labels)
    return m.group(1) if m else labels.strip("{}")


def _build_collector_block() -> dict[str, Any]:
    health, h_err = _get_json(f"{_COLLECTOR_URL}/healthz")
    metrics_text, m_err = _get_text(f"{_COLLECTOR_URL}/metrics")
    parsed = _parse_prom(metrics_text) if metrics_text else {}

    summary: dict[str, Any] | None = None
    if parsed:
        summary = {
            "active_subscriptions": int(
                _sum_metric(parsed, "ws_collector_subscriptions_active")
            ),
            "connection_state": (
                "up"
                if _sum_metric(parsed, "ws_collector_connection_state") >= 1
                else "down"
            ),
            "sqlite_writes_total": int(
                _sum_metric(parsed, "ws_collector_sqlite_writes_total")
            ),
            "aggregator_writes_total": int(
                _sum_metric(parsed, "ws_collector_aggregator_writes_total")
            ),
            "crash_loop_active": _sum_metric(parsed, "ws_collector_crash_loop_active")
            >= 1,
            "reconnects_window_count": int(
                _sum_metric(parsed, "ws_collector_reconnect_window_count")
            ),
            "watchdog_force_reconnects_total": int(
                _sum_metric(
                    parsed, "ws_collector_watchdog_force_reconnects_total"
                )
            ),
        }

    channels_age: list[dict[str, Any]] = []
    if parsed:
        for labels, v in _per_label(
            parsed, "ws_collector_channel_last_message_age_seconds"
        ).items():
            channels_age.append(
                {
                    "channel": _channel_from_labels(labels),
                    "age_s": round(float(v), 1),
                    "stale": float(v) > _STALENESS_THRESHOLD_S,
                }
            )
        channels_age.sort(key=lambda r: -r["age_s"])

    messages: list[dict[str, Any]] = []
    if parsed:
        for labels, v in _per_label(
            parsed, "ws_collector_messages_received_total"
        ).items():
            messages.append(
                {"channel": _channel_from_labels(labels), "count": int(v)}
            )
        messages.sort(key=lambda r: -r["count"])

    subscribers: list[dict[str, Any]] = []
    if parsed:
        for labels, v in _per_label(
            parsed, "ws_collector_redis_subscribers_last"
        ).items():
            # topic label is "redis_topic" not "channel" - fall back to raw label-stripped
            m = re.search(r'redis_topic="([^"]+)"', labels)
            topic = m.group(1) if m else labels.strip("{}")
            subscribers.append({"topic": topic, "subscribers": int(v)})

    return {
        "url": _COLLECTOR_URL,
        "health": health,
        "health_error": h_err,
        "metrics_text": metrics_text,
        "metrics_error": m_err,
        "summary": summary,
        "channels_age": channels_age,
        "messages": messages,
        "subscribers": subscribers,
    }


def _build_backend_ws_block() -> dict[str, Any]:
    health, h_err = _get_json(f"{_BACKEND_WS_URL}/healthz")
    metrics_text, m_err = _get_text(f"{_BACKEND_WS_URL}/metrics")
    parsed = _parse_prom(metrics_text) if metrics_text else {}

    summary: dict[str, Any] | None = None
    if parsed:
        summary = {
            "fanout_messages_total": int(
                _sum_metric(parsed, "backend_ws_fanout_messages_total")
            ),
            "fanout_drops_total": int(
                _sum_metric(parsed, "backend_ws_fanout_drops_total")
            ),
            "redis_ping_failures_total": int(
                _sum_metric(parsed, "backend_ws_redis_ping_failures_total")
            ),
        }

    fanout_rows: list[dict[str, Any]] = []
    if health and isinstance(health.get("fanout_subs"), dict):
        for topic, n in health["fanout_subs"].items():
            fanout_rows.append({"topic": topic, "clients": int(n)})

    redis_sub_rows: list[dict[str, Any]] = []
    if health and isinstance(health.get("redis_sub"), dict):
        for topic, s in health["redis_sub"].items():
            redis_sub_rows.append(
                {
                    "topic": topic,
                    "current_s": round(float(s.get("current_downtime_s") or 0.0), 1),
                    "last_s": round(float(s.get("last_downtime_s") or 0.0), 1),
                    "longest_s": round(float(s.get("longest_downtime_s") or 0.0), 1),
                    "total_s": round(float(s.get("total_downtime_s") or 0.0), 1),
                }
            )
        redis_sub_rows.sort(key=lambda r: -r["current_s"])

    return {
        "url": _BACKEND_WS_URL,
        "health": health,
        "health_error": h_err,
        "metrics_text": metrics_text,
        "metrics_error": m_err,
        "summary": summary,
        "fanout": fanout_rows,
        "redis_sub": redis_sub_rows,
    }


@router.get("")
def ws_health(user: dict = Depends(require_page(_PAGE))) -> dict[str, Any]:
    return {
        "staleness_threshold_s": _STALENESS_THRESHOLD_S,
        "collector": _build_collector_block(),
        "backend_ws": _build_backend_ws_block(),
    }
