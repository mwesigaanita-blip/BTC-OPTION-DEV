"""Stress / PnL-curve routes - wrap `shared/stress_scenarios_service`."""
from __future__ import annotations

import logging
import re
from datetime import date, datetime

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, Field

from portfolio_analysis_AI_Agent.tools.datafetch.market.get_ticker import get_ticker
from shared.redis_live import get_account_live, get_market_live, get_raw_positions_live
from shared.stress_scenarios_service import (
    build_hypothetical_option,
    get_stress_latest,
    get_stress_today,
    run_pnl_curve,
)

from backend_api.auth_jwt import require_page
from backend_api.routes_market import get_cached_option_instruments

log = logging.getLogger("backend-api.stress")

router = APIRouter(prefix="/api/stress", tags=["stress"])

_PAGE = "Account_Overview"


@router.get("/today")
def today(user: dict = Depends(require_page(_PAGE))) -> dict:
    """Today's cached stress snapshot (may be null if not yet computed)."""
    return {"stress": get_stress_today()}


@router.get("/latest")
def latest(user: dict = Depends(require_page(_PAGE))) -> dict:
    """Most recent stress snapshot regardless of date."""
    return {"stress": get_stress_latest()}


class PnlCurveRequest(BaseModel):
    range_pct: float = Field(default=50.0, ge=1.0, le=90.0)
    points: int = Field(default=121, ge=11, le=401)
    iv_points: float = Field(default=0.0, ge=-80.0, le=80.0)
    days_forward: int = Field(default=0, ge=0, le=120)


@router.post("/pnl-curve")
def pnl_curve(
    req: PnlCurveRequest, user: dict = Depends(require_page(_PAGE))
) -> dict:
    """Live PnL payoff curve, repriced from the WS->Redis snapshot."""
    raw_pos, _ = get_raw_positions_live()
    market, _ = get_market_live()
    spot = float(
        (market or {}).get("btc_index") or (market or {}).get("perp_index") or 0.0
    )
    acct, _ = get_account_live()
    equity = float((acct or {}).get("total_equity_usd") or 0.0) or None

    if not raw_pos or spot <= 0:
        raise HTTPException(
            status.HTTP_503_SERVICE_UNAVAILABLE,
            "No live WS data available for the PnL curve",
        )
    try:
        return run_pnl_curve(
            pct_min=-req.range_pct,
            pct_max=req.range_pct,
            points=req.points,
            iv_points=req.iv_points,
            days_forward=req.days_forward,
            positions=raw_pos,
            spot=spot,
            equity_usd=equity,
        )
    except Exception as e:  # pragma: no cover - surface compute failure
        log.exception("pnl_curve failed")
        raise HTTPException(
            status.HTTP_500_INTERNAL_SERVER_ERROR, f"PnL curve failed: {e}"
        )


# ---------------------------------------------------------------------------
# Custom What-If simulator
# ---------------------------------------------------------------------------


class PositionOverride(BaseModel):
    instrument_name: str
    size: float = Field(ge=0.0)  # absolute contracts
    side: str = "buy"  # "buy" | "sell"


class HypotheticalSpec(BaseModel):
    # Preferred path: full Deribit instrument name (e.g. "BTC-29MAY26-65000-C").
    # When supplied, the server resolves strike / expiry / type from the name
    # and pulls live `mark_iv` from Deribit so the simulated leg tracks the
    # live book like a real position. Legacy free-form fields are optional and
    # only used when `instrument_name` is absent.
    instrument_name: str | None = None
    side: str = "buy"
    size: float = Field(gt=0.0, default=1.0)
    # Legacy / override fields - optional.
    option_type: str | None = None
    expiry: str | None = None
    strike: float | None = None
    iv_pct: float | None = Field(default=None, gt=0.0, le=500.0)


class WhatIfRequest(BaseModel):
    range_pct: float = Field(default=50.0, ge=1.0, le=90.0)
    points: int = Field(default=121, ge=11, le=401)
    # Multiplicative IV shift in percent (-95...+500). new_sigma = old_sigma * (1 + pct/100).
    iv_pct_shift: float = Field(default=0.0, ge=-95.0, le=500.0)
    # Fractional days-forward so the timeline can land precisely on each
    # per-leg expiry (where the dynamic curve collapses onto the static one).
    days_forward: float = Field(default=0.0, ge=0.0, le=730.0)
    annual_rate_shift_bps: float = Field(default=0.0, ge=-1000.0, le=1000.0)
    spot_override: float | None = None
    overrides: list[PositionOverride] = []
    hypotheticals: list[HypotheticalSpec] = []


def _parse_expiry(s: str) -> date:
    s = (s or "").strip()
    for fmt in ("%Y-%m-%d", "%d%b%y", "%d-%b-%Y"):
        try:
            return datetime.strptime(s.upper() if "%b" in fmt else s, fmt).date()
        except ValueError:
            continue
    raise ValueError(f"unparseable expiry '{s}'")


_INSTRUMENT_RE = re.compile(r"^([A-Z]+)-([0-9]{1,2}[A-Z]{3}[0-9]{2})-(\d+)-([CP])$")


def _parse_instrument_name(name: str) -> tuple[str, date, float, str]:
    """Returns (currency, expiry_date, strike, option_type) for a Deribit option name."""
    m = _INSTRUMENT_RE.match((name or "").strip().upper())
    if not m:
        raise ValueError(f"unrecognised Deribit option name '{name}'")
    currency, expiry_label, strike_str, opt = m.groups()
    return currency, _parse_expiry(expiry_label), float(strike_str), opt


def _resolve_live_iv(
    instrument_name: str,
    expiry_label: str,
    live_spot: float,
    memo: dict,
    currency: str = "BTC",
) -> float:
    """Returns a positive `mark_iv` for `instrument_name`.

    Tries the instrument's own ticker first. If Deribit has no quote, falls
    back to the ATM-of-expiry mark_iv (closest-to-spot strike on the same
    expiry). `memo` is an in-request cache keyed by instrument_name to avoid
    repeated REST calls.
    """
    if instrument_name in memo:
        return memo[instrument_name]

    iv = None
    try:
        t = get_ticker(instrument_name)
        iv = t.get("mark_iv")
    except Exception:
        iv = None
    if iv and float(iv) > 0:
        memo[instrument_name] = float(iv)
        return float(iv)

    # ATM-of-expiry fallback - find the closest strike on the same expiry and
    # try its ticker. Walk the 5 nearest strikes in case the exact ATM has no
    # quote either.
    try:
        payload = get_cached_option_instruments(currency)
        bucket = next(
            (e for e in payload["expiries"] if e["expiry_label"] == expiry_label),
            None,
        )
        if bucket and live_spot > 0:
            sorted_inst = sorted(
                bucket["instruments"],
                key=lambda x: abs(float(x["strike"]) - live_spot),
            )
            for cand in sorted_inst[:5]:
                cname = cand["instrument_name"]
                if cname == instrument_name:
                    continue
                if cname in memo:
                    memo[instrument_name] = memo[cname]
                    return memo[cname]
                try:
                    cv = get_ticker(cname).get("mark_iv")
                except Exception:
                    cv = None
                if cv and float(cv) > 0:
                    memo[cname] = float(cv)
                    memo[instrument_name] = float(cv)
                    return float(cv)
    except Exception:
        log.exception("ATM-of-expiry IV fallback failed for %s", instrument_name)

    # Final fallback - constant default consistent with the legacy path.
    memo[instrument_name] = 60.0
    return 60.0


@router.post("/whatif")
def whatif(req: WhatIfRequest, user: dict = Depends(require_page(_PAGE))) -> dict:
    """Custom what-if PnL curve + per-leg greeks.

    Pulls live positions, applies size/side overrides, adds hypothetical
    options, and reprices around either the live spot or a frozen
    `spot_override`. Per-leg curves + greeks let the frontend include/exclude
    instantly without a recompute.
    """
    raw_pos, _ = get_raw_positions_live()
    market, _ = get_market_live()
    live_spot = float(
        (market or {}).get("btc_index") or (market or {}).get("perp_index") or 0.0
    )
    acct, _ = get_account_live()
    equity = float((acct or {}).get("total_equity_usd") or 0.0) or None

    if not raw_pos:
        raise HTTPException(
            status.HTTP_503_SERVICE_UNAVAILABLE, "No live positions available"
        )
    if live_spot <= 0:
        raise HTTPException(
            status.HTTP_503_SERVICE_UNAVAILABLE, "No live BTC price available"
        )
    # Pricing always uses the LIVE spot so implied vols and the PnL anchor stay
    # correct. A frozen `spot_override` only shifts the curve WINDOW - the swept
    # price range is re-centred on the frozen price.
    frozen = bool(req.spot_override and req.spot_override > 0)
    centre = float(req.spot_override) if frozen else live_spot

    # Apply size/side overrides onto copies of the live raw positions.
    #
    # Execution model: resize == transact at the *current mark price*. So:
    # - Increasing a position adds new contracts that enter at mark, i.e.
    #   carry zero unrealized PnL. The existing contracts keep theirs.
    # - Reducing a position closes the surplus at mark, realizing that
    #   portion's PnL into cash. The remaining open contracts keep their
    #   per-unit unrealized PnL.
    # Either way the leg's *unrealized PnL anchor* (`total_profit_loss`)
    # stays at its current value - we only swap `size` and `direction`.
    # At the live BTC price scenario_delta is ~0, so resizing won't move the
    # equity card; the curve shape away from spot (slope, break-even,
    # greeks) is what changes with size.
    ov = {o.instrument_name: o for o in req.overrides}
    positions: list[dict] = []
    for p in raw_pos:
        q = dict(p)
        o = ov.get(str(q.get("instrument_name") or ""))
        if o is not None:
            q["size"] = abs(float(o.size))
            q["direction"] = "sell" if str(o.side).lower().startswith("s") else "buy"
        positions.append(q)

    # Build hypothetical options.
    extras: list[dict] = []
    iv_memo: dict = {}
    for h in req.hypotheticals:
        try:
            if h.instrument_name:
                _, exp_d, strike, opt = _parse_instrument_name(h.instrument_name)
                if h.iv_pct and h.iv_pct > 0:
                    iv_use = float(h.iv_pct)
                else:
                    iv_use = _resolve_live_iv(
                        h.instrument_name,
                        exp_d.strftime("%d%b%y").upper(),
                        live_spot,
                        iv_memo,
                    )
                extras.append(
                    build_hypothetical_option(
                        opt, exp_d, strike, h.side, h.size, iv_use,
                    )
                )
            else:
                if not (h.option_type and h.expiry and h.strike):
                    raise ValueError(
                        "instrument_name or (option_type, expiry, strike) required"
                    )
                iv_use = float(h.iv_pct) if h.iv_pct and h.iv_pct > 0 else 60.0
                extras.append(
                    build_hypothetical_option(
                        h.option_type, _parse_expiry(h.expiry), h.strike,
                        h.side, h.size, iv_use,
                    )
                )
        except Exception as e:
            raise HTTPException(
                status.HTTP_400_BAD_REQUEST, f"Bad hypothetical option: {e}"
            )

    # Curve window: ±range_pct around `centre`, expressed as % moves off the
    # live spot (asymmetric when the centre is a frozen price).
    half = req.range_pct / 100.0
    pct_min = ((centre * (1.0 - half)) / live_spot - 1.0) * 100.0
    pct_max = ((centre * (1.0 + half)) / live_spot - 1.0) * 100.0

    try:
        out = run_pnl_curve(
            pct_min=pct_min,
            pct_max=pct_max,
            points=req.points,
            iv_points=0.0,
            days_forward=req.days_forward,
            positions=positions,
            spot=live_spot,
            equity_usd=equity,
            extra_positions=extras,
            with_greeks=True,
            eval_price=centre,
            annual_rate_shift_bps=req.annual_rate_shift_bps,
            iv_pct_shift=req.iv_pct_shift,
        )
    except Exception as e:  # pragma: no cover
        log.exception("whatif curve failed")
        raise HTTPException(
            status.HTTP_500_INTERNAL_SERVER_ERROR, f"What-if curve failed: {e}"
        )

    out.setdefault("context", {})["live_spot"] = live_spot
    out["context"]["spot_frozen"] = frozen
    return out
