"""MM Alerts config routes - JWT-gated mirror of `/mm-alert/config`.

The existing `/mm-alert/config` route was designed for internal-key consumers
(Streamlit + the MM alert bot itself). The React dashboard needs JWT auth +
the `MM_Alerts` page grant, so we expose a parallel `/api/mm-alerts/config`
that wraps the same SQLite store. The old route stays in place so the
non-React callers keep working.
"""
from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, Field

from backend_api.auth_jwt import require_page
from backend_api.mm_alert_config_store import read_config, upsert_config

log = logging.getLogger("backend-api.mm_alerts")

router = APIRouter(prefix="/api/mm-alerts", tags=["mm-alerts"])

_PAGE = "MM_Alerts"


class MmAlertConfigPatch(BaseModel):
    is_enabled: bool | None = None
    warning_threshold: float | None = Field(default=None, ge=0.0, le=200.0)
    critical_threshold: float | None = Field(default=None, ge=0.0, le=200.0)
    warning_cooldown_minutes: int | None = Field(default=None, ge=1, le=1440)
    critical_cooldown_minutes: int | None = Field(default=None, ge=1, le=1440)
    check_interval_seconds: int | None = Field(default=None, ge=5, le=3600)
    currencies: list[str] | None = None


@router.get("/config")
def get_config(user: dict = Depends(require_page(_PAGE))) -> dict[str, Any]:
    return read_config()


@router.post("/config")
def set_config(
    body: MmAlertConfigPatch, user: dict = Depends(require_page(_PAGE))
) -> dict[str, Any]:
    payload = body.model_dump(exclude_unset=True)
    if not payload:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "No fields provided")
    return upsert_config(payload)
