"""JWT issuing / verification for the React front-end API.

Mirrors `shared/streamlit_auth.py` semantics: operators get every page,
viewers get exactly their DB `pages` list. Tokens are HS256, signed with the
`JWT_SECRET` env var - there is intentionally NO default, so a misconfigured
deployment fails loudly instead of issuing forgeable tokens.
"""
from __future__ import annotations

import os
import time
from typing import Any, Callable

import jwt
from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

JWT_ALGORITHM = "HS256"
JWT_TTL_SECONDS = int(os.getenv("JWT_TTL_SECONDS", str(12 * 3600)))


def _secret() -> str:
    secret = os.getenv("JWT_SECRET", "").strip()
    if not secret:
        raise RuntimeError(
            "JWT_SECRET is not set - refusing to issue or verify tokens. "
            "Set JWT_SECRET in the environment."
        )
    return secret


def issue_token(username: str, role: str, pages: list[str]) -> tuple[str, int]:
    """Return `(token, expires_at_epoch)` for a verified user."""
    now = int(time.time())
    exp = now + JWT_TTL_SECONDS
    token = jwt.encode(
        {"sub": username, "role": role, "pages": pages, "iat": now, "exp": exp},
        _secret(),
        algorithm=JWT_ALGORITHM,
    )
    return token, exp


def decode_token(token: str) -> dict[str, Any]:
    try:
        return jwt.decode(token, _secret(), algorithms=[JWT_ALGORITHM])
    except jwt.ExpiredSignatureError:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Token expired")
    except jwt.PyJWTError:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Invalid token")


_bearer = HTTPBearer(auto_error=False)


def get_current_user(
    creds: HTTPAuthorizationCredentials | None = Depends(_bearer),
) -> dict[str, Any]:
    """FastAPI dependency - decodes the bearer token into a user dict."""
    if creds is None or not creds.credentials:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Not authenticated")
    claims = decode_token(creds.credentials)
    return {
        "username": claims.get("sub", ""),
        "role": claims.get("role", ""),
        "pages": claims.get("pages", []) or [],
    }


def require_page(page_stem: str) -> Callable:
    """Dependency factory - gate a route to any authenticated user.

    Security model (simplified): role decides everything.
      * operator → every page (including User Management)
      * viewer   → every page **except** operator-only ones
    Per-page grants are no longer enforced; `page_stem` is kept in the
    signature so existing call-sites compile and so audit logs / future
    re-introduction of per-page ACLs remain easy. Operator-only pages
    must use ``require_operator`` instead of (or in addition to) this.
    """
    _ = page_stem  # accepted for forward-compat; intentionally unused

    def _dep(user: dict = Depends(get_current_user)) -> dict:
        return user

    return _dep


def require_operator(user: dict = Depends(get_current_user)) -> dict:
    """Dependency - gate a route behind the operator role."""
    if user.get("role") != "operator":
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Operator role required")
    return user
