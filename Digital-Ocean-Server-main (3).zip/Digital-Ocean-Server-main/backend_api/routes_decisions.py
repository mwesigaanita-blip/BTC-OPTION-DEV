"""Decision Board routes - wrap `decision_board.service`.

JWT-protected; access gated by the `Decision_Board` page grant.
"""
from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Query, status
from pydantic import BaseModel, Field

from backend_api.auth_jwt import require_page
from decision_board import service as svc

log = logging.getLogger("backend-api.decisions")

router = APIRouter(prefix="/api/decisions", tags=["decisions"])

_PAGE = "Decision_Board"

# Ensure the SQLite schema exists when this module is imported, so the first
# request doesn't 500 on a fresh deploy.
try:
    svc.init_db()
except Exception:  # pragma: no cover - surfaced via the first request anyway
    log.exception("decision_board init_db failed at import time")


# ---------------------------------------------------------------------------
# Pydantic request models
# ---------------------------------------------------------------------------


class ActionIn(BaseModel):
    action_type: str = "note"
    reason_text: str = ""
    instrument_name: str | None = None
    side: str | None = None
    quantity: float | None = None
    price_reference: float | None = None
    sort_order: int = 0


class DecisionCreate(BaseModel):
    title: str
    description: str = ""
    priority: str = "medium"
    actions: list[ActionIn] = Field(default_factory=list)


class DecisionUpdate(BaseModel):
    title: str | None = None
    description: str | None = None
    priority: str | None = None


class MoveStatusBody(BaseModel):
    new_status: str


class FinalizeBody(BaseModel):
    final_outcome: str
    final_summary_reason: str


class ActionUpdate(BaseModel):
    action_type: str | None = None
    reason_text: str | None = None
    instrument_name: str | None = None
    side: str | None = None
    quantity: float | None = None
    price_reference: float | None = None
    sort_order: int | None = None


class CommentIn(BaseModel):
    comment_text: str


class CommentUpdate(BaseModel):
    new_text: str


# ---------------------------------------------------------------------------
# Helper
# ---------------------------------------------------------------------------


def _raise_400(exc: Exception) -> None:
    raise HTTPException(status.HTTP_400_BAD_REQUEST, str(exc))


# ---------------------------------------------------------------------------
# Decisions: list / create / detail / update / delete
# ---------------------------------------------------------------------------


@router.get("")
def list_decisions(
    status_: str | None = Query(default=None, alias="status"),
    priority: str | None = None,
    created_by: str | None = None,
    final_outcome: str | None = None,
    search: str | None = None,
    sort: str = "newest",
    limit: int = Query(default=200, ge=1, le=500),
    offset: int = Query(default=0, ge=0),
    user: dict = Depends(require_page(_PAGE)),
) -> dict[str, Any]:
    rows = svc.list_decisions(
        status=status_,
        priority=priority,
        created_by=created_by,
        final_outcome=final_outcome,
        search=search,
        sort=sort,
        limit=limit,
        offset=offset,
    )
    # Pre-compute counts once so the board UI doesn't N+1 from the client.
    counts: dict[int, dict[str, int]] = {}
    for d in rows:
        counts[int(d["id"])] = {
            "actions": svc.count_actions(int(d["id"])),
            "comments": svc.count_comments(int(d["id"])),
        }
    return {"decisions": rows, "counts": counts}


@router.get("/metrics")
def metrics(user: dict = Depends(require_page(_PAGE))) -> dict:
    return svc.get_metrics()


@router.post("", status_code=status.HTTP_201_CREATED)
def create_decision(
    body: DecisionCreate, user: dict = Depends(require_page(_PAGE))
) -> dict:
    try:
        return svc.create_decision(
            title=body.title,
            description=body.description,
            created_by=user["username"],
            priority=body.priority,
            actions=[a.model_dump() for a in body.actions],
        )
    except ValueError as e:
        _raise_400(e)


@router.get("/{decision_id}")
def get_decision(
    decision_id: int,
    comments_limit: int = Query(default=20, ge=1, le=200),
    actions_limit: int = Query(default=50, ge=1, le=200),
    events_limit: int = Query(default=100, ge=1, le=500),
    user: dict = Depends(require_page(_PAGE)),
) -> dict:
    detail = svc.get_decision_detail(
        decision_id,
        comments_limit=comments_limit,
        actions_limit=actions_limit,
        events_limit=events_limit,
    )
    if detail is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Decision not found")
    return detail


@router.patch("/{decision_id}")
def update_decision(
    decision_id: int,
    body: DecisionUpdate,
    user: dict = Depends(require_page(_PAGE)),
) -> dict:
    fields = {k: v for k, v in body.model_dump(exclude_unset=True).items() if v is not None}
    if not fields:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "No fields provided")
    try:
        return svc.update_decision(
            decision_id=decision_id, actor=user["username"], **fields
        )
    except ValueError as e:
        _raise_400(e)


@router.delete("/{decision_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_decision(
    decision_id: int, user: dict = Depends(require_page(_PAGE))
) -> None:
    try:
        svc.delete_decision(decision_id=decision_id, actor=user["username"])
    except ValueError as e:
        _raise_400(e)


# ---------------------------------------------------------------------------
# Status / finalize
# ---------------------------------------------------------------------------


@router.post("/{decision_id}/move")
def move_status(
    decision_id: int,
    body: MoveStatusBody,
    user: dict = Depends(require_page(_PAGE)),
) -> dict:
    try:
        return svc.move_decision_status(
            decision_id=decision_id,
            new_status=body.new_status,
            actor=user["username"],
        )
    except ValueError as e:
        _raise_400(e)


@router.post("/{decision_id}/finalize")
def finalize(
    decision_id: int,
    body: FinalizeBody,
    user: dict = Depends(require_page(_PAGE)),
) -> dict:
    try:
        return svc.finalize_decision(
            decision_id=decision_id,
            final_outcome=body.final_outcome,
            final_summary_reason=body.final_summary_reason,
            actor=user["username"],
        )
    except ValueError as e:
        _raise_400(e)


# ---------------------------------------------------------------------------
# Actions
# ---------------------------------------------------------------------------


@router.post("/{decision_id}/actions", status_code=status.HTTP_201_CREATED)
def add_action(
    decision_id: int,
    body: ActionIn,
    user: dict = Depends(require_page(_PAGE)),
) -> dict:
    try:
        return svc.add_action(
            decision_id=decision_id,
            action_type=body.action_type,
            reason_text=body.reason_text,
            actor=user["username"],
            instrument_name=body.instrument_name,
            side=body.side,
            quantity=body.quantity,
            price_reference=body.price_reference,
            sort_order=body.sort_order,
        )
    except ValueError as e:
        _raise_400(e)


@router.patch("/actions/{action_id}")
def update_action(
    action_id: int,
    body: ActionUpdate,
    user: dict = Depends(require_page(_PAGE)),
) -> dict:
    fields = {k: v for k, v in body.model_dump(exclude_unset=True).items()}
    if not fields:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "No fields provided")
    try:
        return svc.update_action(
            action_id=action_id, actor=user["username"], **fields
        )
    except ValueError as e:
        _raise_400(e)


@router.delete("/actions/{action_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_action(
    action_id: int, user: dict = Depends(require_page(_PAGE))
) -> None:
    try:
        svc.delete_action(action_id=action_id, actor=user["username"])
    except ValueError as e:
        _raise_400(e)


# ---------------------------------------------------------------------------
# Comments
# ---------------------------------------------------------------------------


@router.get("/{decision_id}/comments")
def list_comments(
    decision_id: int,
    limit: int = Query(default=50, ge=1, le=500),
    offset: int = Query(default=0, ge=0),
    user: dict = Depends(require_page(_PAGE)),
) -> dict:
    return {
        "comments": svc.list_comments(decision_id, limit=limit, offset=offset),
        "total": svc.count_comments(decision_id),
    }


@router.post("/{decision_id}/comments", status_code=status.HTTP_201_CREATED)
def add_comment(
    decision_id: int,
    body: CommentIn,
    user: dict = Depends(require_page(_PAGE)),
) -> dict:
    try:
        return svc.add_comment(
            decision_id=decision_id,
            author=user["username"],
            comment_text=body.comment_text,
        )
    except ValueError as e:
        _raise_400(e)


@router.patch("/comments/{comment_id}")
def update_comment(
    comment_id: int,
    body: CommentUpdate,
    user: dict = Depends(require_page(_PAGE)),
) -> dict:
    try:
        return svc.update_comment(
            comment_id=comment_id,
            actor=user["username"],
            new_text=body.new_text,
        )
    except ValueError as e:
        _raise_400(e)


@router.delete("/comments/{comment_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_comment(
    comment_id: int, user: dict = Depends(require_page(_PAGE))
) -> None:
    try:
        svc.delete_comment(comment_id=comment_id, actor=user["username"])
    except ValueError as e:
        _raise_400(e)


# ---------------------------------------------------------------------------
# Events (audit trail)
# ---------------------------------------------------------------------------


@router.get("/{decision_id}/events")
def list_events(
    decision_id: int,
    limit: int = Query(default=100, ge=1, le=1000),
    offset: int = Query(default=0, ge=0),
    user: dict = Depends(require_page(_PAGE)),
) -> dict:
    return {
        "events": svc.list_events(
            decision_id=decision_id, limit=limit, offset=offset
        ),
        "total": svc.count_events(decision_id=decision_id),
    }
