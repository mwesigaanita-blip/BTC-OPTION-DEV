"""Hedge Engine routes - wrap `simple_hedge` config store + Deribit client.

JWT-protected; access gated by the `Hedge_Engine` page grant. Mirrors the
Streamlit page semantics exactly (same trust model: a user with the page
grant can flip the engine on/off and edit config).
"""
from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Query, status
from pydantic import BaseModel

from backend_api.auth_jwt import require_page
from simple_hedge.config_store import (
    ensure_tables,
    get_hedge_logs,
    read_config,
    upsert_config,
)
from simple_hedge.deribit_client import DeribitClient
from simple_hedge.hedge_logic import (
    get_mm_bucket,
    make_config_from_dict,
    parse_account_state,
)

log = logging.getLogger("backend-api.hedge")

router = APIRouter(prefix="/api/hedge", tags=["hedge"])

_PAGE = "Hedge_Engine"


try:
    ensure_tables()
except Exception:  # pragma: no cover - first request will resurface
    log.exception("simple_hedge ensure_tables failed at import time")


class HedgeConfigPatch(BaseModel):
    """Every field is optional - only present keys are merged into the row."""

    is_enabled: bool | None = None
    poll_interval_secs: int | None = None
    mm_safe_below: float | None = None
    mm_light_below: float | None = None
    mm_medium_below: float | None = None
    mm_aggressive_below: float | None = None
    mm_bypass_cooldown: float | None = None
    hedge_pct_of_equity: float | None = None
    delta_hedge_ratio: float | None = None
    min_trade_btc: float | None = None
    max_single_trade_btc: float | None = None
    delta_deadband_btc: float | None = None
    cooldown_secs: int | None = None
    cooldown_fast_secs: int | None = None
    max_btc_per_5min: float | None = None
    speed_warn_30s: float | None = None
    speed_danger_30s: float | None = None
    speed_warn_60s: float | None = None
    speed_danger_60s: float | None = None


class ToggleBody(BaseModel):
    enabled: bool


@router.get("/config")
def get_config(user: dict = Depends(require_page(_PAGE))) -> dict[str, Any]:
    return read_config()


@router.patch("/config")
def patch_config(
    body: HedgeConfigPatch, user: dict = Depends(require_page(_PAGE))
) -> dict[str, Any]:
    payload = body.model_dump(exclude_unset=True)
    if not payload:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "No fields provided")
    return upsert_config(payload)


@router.post("/toggle")
def toggle(
    body: ToggleBody, user: dict = Depends(require_page(_PAGE))
) -> dict[str, Any]:
    return upsert_config({"is_enabled": bool(body.enabled)})


@router.post("/account-state")
def fetch_account_state(user: dict = Depends(require_page(_PAGE))) -> dict[str, Any]:
    """Pull the latest account snapshot from Deribit REST + compute the
    current MM bucket against the saved config. Mirrors the Streamlit
    "Fetch from Deribit" button - the browser never sees Deribit creds."""
    try:
        client = DeribitClient()
        summary = client.get_account_summary()
        btc_price = client.get_index_price()
    except Exception as e:
        log.exception("hedge fetch_account_state failed")
        raise HTTPException(
            status.HTTP_502_BAD_GATEWAY, f"Deribit fetch failed: {e}"
        )

    state = parse_account_state(summary)
    cfg = read_config()
    hedge_cfg = make_config_from_dict(cfg)
    bucket = get_mm_bucket(state.mm_percent, hedge_cfg)
    return {
        "mm_percent": state.mm_percent,
        "net_delta": state.net_delta,
        "equity_usd": state.equity_usd,
        "margin_balance": state.margin_balance,
        "maintenance_margin": state.maintenance_margin,
        "btc_price": btc_price,
        "bucket": bucket,
    }


@router.get("/logs")
def list_logs(
    limit: int = Query(default=25, ge=1, le=500),
    user: dict = Depends(require_page(_PAGE)),
) -> dict[str, Any]:
    rows = get_hedge_logs(limit=limit)
    total = len(rows)
    errors = sum(1 for r in rows if r.get("error"))
    sells = sum(1 for r in rows if r.get("direction") == "sell")
    buys = sum(1 for r in rows if r.get("direction") == "buy")
    total_btc = sum(
        float(r.get("size_btc") or 0.0) for r in rows if not r.get("error")
    )
    return {
        "logs": rows,
        "summary": {
            "total": total,
            "errors": errors,
            "successful": total - errors,
            "sells": sells,
            "buys": buys,
            "total_btc": round(total_btc, 6),
        },
    }
