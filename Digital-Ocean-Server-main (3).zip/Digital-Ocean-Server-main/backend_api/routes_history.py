"""History routes - daily portfolio / positions analytics."""
from __future__ import annotations

import logging

from fastapi import APIRouter, Depends

from backend_api.auth_jwt import require_page
from backend_api.services.positions_history import (
    get_day_positions,
    get_portfolio_history,
)

log = logging.getLogger("backend-api.history")

router = APIRouter(prefix="/api/history", tags=["history"])

_POSITIONS_PAGE = "Positions_History"


@router.get("/positions/portfolio")
def positions_portfolio(user: dict = Depends(require_page(_POSITIONS_PAGE))) -> dict:
    """Daily portfolio time series + performance windows + drilldown dates."""
    return get_portfolio_history()


@router.get("/positions/day/{day}")
def positions_day(
    day: str, user: dict = Depends(require_page(_POSITIONS_PAGE))
) -> dict:
    """Positions + KPIs for a single snapshot day."""
    return get_day_positions(day)
