from __future__ import annotations

from datetime import datetime, timezone, timedelta
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query

from backend_api.auth_jwt import get_current_user, require_page
from backend_api.db.fees_repo import ensure_fee_tables, list_fee_events
from backend_api.services.fees_service import ingest_fees_once

router = APIRouter(prefix="/api/trading-fees", tags=["trading-fees"])


@router.get("/events")
def get_fee_events(
    days_back: int = Query(7, ge=1, le=365),
    limit: int = Query(500, ge=1, le=5000),
    only_unnotified: bool = Query(False),
    _user: dict = Depends(require_page("Trading_Fees")),
) -> Dict[str, Any]:
    ensure_fee_tables()
    now = datetime.now(timezone.utc)
    start = now - timedelta(days=days_back)
    start_ms = int(start.timestamp() * 1000)
    end_ms = int(now.timestamp() * 1000)

    rows = list_fee_events(start_ms=start_ms, end_ms=end_ms, limit=limit, offset=0)

    if only_unnotified:
        rows = [r for r in rows if not r.get("notified_telegram")]

    # Enrich with ISO time string
    for r in rows:
        ts = r.get("timestamp_ms")
        if ts is not None:
            r["time_utc"] = datetime.fromtimestamp(ts / 1000.0, tz=timezone.utc).isoformat()
        else:
            r["time_utc"] = None

    # Summary metrics
    total_fee_by_ccy: Dict[str, float] = {}
    total_usd = 0.0
    for r in rows:
        ccy = (r.get("fee_currency") or "").upper()
        amt = float(r.get("fee_amount") or 0.0)
        total_fee_by_ccy[ccy] = total_fee_by_ccy.get(ccy, 0.0) + amt
        usd = r.get("fee_usd")
        if usd is not None:
            total_usd += float(usd)

    return {
        "rows": rows,
        "total_rows": len(rows),
        "summary": {
            "total_fee_by_ccy": total_fee_by_ccy,
            "total_usd": total_usd if total_usd > 0 else None,
        },
    }


@router.post("/sync")
def sync_fees(
    _user: dict = Depends(require_page("Trading_Fees")),
) -> Dict[str, Any]:
    try:
        result = ingest_fees_once()
        return result
    except Exception as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc
