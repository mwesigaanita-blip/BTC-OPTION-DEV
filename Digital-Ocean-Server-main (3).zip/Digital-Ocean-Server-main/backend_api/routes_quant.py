"""Daily Quant dashboard routes - thin HTTP wrappers over the agent tools.

Each endpoint is a 5-min cached wrapper around a single tool function in
``portfolio_analysis_AI_Agent.tools.{composite,jobs}``. Keeping the
business logic in the tools means the same code powers (a) this React
endpoint and (b) future LLM-agent tool calls.

Endpoints (all under ``/api/quant``):

- ``GET  /snapshot``  -> composite.daily_quant_snapshot
- ``GET  /returns``   -> composite.daily_quant_returns
- ``GET  /relative``  -> composite.daily_quant_relative
- ``GET  /vs-btc``    -> composite.daily_quant_relative.daily_quant_vs_btc
- ``POST /refresh``   -> jobs.refresh_market_data
"""
from __future__ import annotations

import logging
import threading
import time

from fastapi import APIRouter, Depends, HTTPException, Query, status

from backend_api.auth_jwt import require_page
from portfolio_analysis_AI_Agent.tools.composite.btc_rolling_correlations import (
    DEFAULT_PARTNERS as ROLLING_DEFAULT_PARTNERS,
    btc_rolling_correlations,
)
from portfolio_analysis_AI_Agent.tools.composite.crypto_volume_panel import (
    DEFAULT_ASSETS as VOLUME_DEFAULT_ASSETS,
    crypto_volume_panel,
)
from portfolio_analysis_AI_Agent.tools.composite.correlation_matrix import (
    DEFAULT_ASSETS as CORR_DEFAULT_ASSETS,
    DEFAULT_WINDOWS as CORR_DEFAULT_WINDOWS,
    correlation_matrix,
)
from portfolio_analysis_AI_Agent.tools.composite.daily_quant_relative import (
    daily_quant_relative,
    daily_quant_vs_btc,
)
from portfolio_analysis_AI_Agent.tools.composite.daily_quant_returns import (
    DEFAULT_ASSETS,
    daily_quant_returns,
)
from portfolio_analysis_AI_Agent.tools.composite.daily_quant_snapshot import (
    daily_quant_snapshot,
)
from portfolio_analysis_AI_Agent.tools.jobs.refresh_market_data import (
    refresh_market_data,
)

log = logging.getLogger("backend-api.quant")
router = APIRouter(prefix="/api/quant", tags=["quant"])

_PAGE = "BTC_Prices"

# --- TTL cache (5 min). Daily series move slowly. -------------------------
_TTL_SEC = 300
_cache_lock = threading.Lock()
_cache: dict[str, tuple[float, dict]] = {}


def _cached(key: str, builder):
    now = time.time()
    with _cache_lock:
        hit = _cache.get(key)
        if hit and now - hit[0] < _TTL_SEC:
            return hit[1]
    payload = builder()
    with _cache_lock:
        _cache[key] = (now, payload)
    return payload


def _split_csv(s: str) -> list[str]:
    return [x.strip().upper() for x in s.split(",") if x.strip()]


DEFAULT_ASSETS_CSV = ",".join(DEFAULT_ASSETS)
DEFAULT_BENCHMARKS_CSV = "SPX,GOLD,DXY"


@router.get("/snapshot")
def snapshot(user: dict = Depends(require_page(_PAGE))) -> dict:
    try:
        return _cached("snapshot", daily_quant_snapshot)
    except RuntimeError as e:
        raise HTTPException(status.HTTP_503_SERVICE_UNAVAILABLE, str(e))


@router.get("/returns")
def returns(
    assets: str = Query(default=DEFAULT_ASSETS_CSV, description="Comma-separated asset labels"),
    user: dict = Depends(require_page(_PAGE)),
) -> dict:
    asset_list = _split_csv(assets)
    if not asset_list:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "no assets specified")
    try:
        return _cached(f"returns:{','.join(asset_list)}", lambda: daily_quant_returns(asset_list))
    except ValueError as e:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, str(e))


@router.get("/relative")
def relative(
    base: str = Query(default="BTC"),
    vs: str = Query(default=DEFAULT_BENCHMARKS_CSV, description="Comma-separated benchmark labels"),
    user: dict = Depends(require_page(_PAGE)),
) -> dict:
    base_u = base.strip().upper()
    vs_list = _split_csv(vs)
    if not vs_list:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "no benchmark assets specified")
    try:
        return _cached(
            f"relative:{base_u}:{','.join(vs_list)}",
            lambda: daily_quant_relative(base=base_u, vs=vs_list),
        )
    except ValueError as e:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, str(e))


@router.get("/vs-btc")
def vs_btc(
    assets: str = Query(default=DEFAULT_ASSETS_CSV),
    user: dict = Depends(require_page(_PAGE)),
) -> dict:
    asset_list = [a for a in _split_csv(assets) if a != "BTC"]
    if not asset_list:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "no non-BTC assets specified")
    try:
        return _cached(f"vs_btc:{','.join(asset_list)}", lambda: daily_quant_vs_btc(asset_list))
    except ValueError as e:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, str(e))


@router.get("/correlations")
def correlations(
    assets: str = Query(
        default=",".join(CORR_DEFAULT_ASSETS),
        description="Comma-separated assets (matrix axis order).",
    ),
    windows: str = Query(
        default=",".join(f"{lbl}:{d}" for lbl, d in CORR_DEFAULT_WINDOWS),
        description="Comma-separated label:days pairs, e.g. '1M:30,3M:91'.",
    ),
    user: dict = Depends(require_page(_PAGE)),
) -> dict:
    asset_list = _split_csv(assets)
    if not asset_list:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "no assets specified")
    parsed_windows: list[tuple[str, int]] = []
    for raw in windows.split(","):
        raw = raw.strip()
        if not raw:
            continue
        if ":" not in raw:
            raise HTTPException(
                status.HTTP_400_BAD_REQUEST,
                f"window {raw!r} must be 'label:days'",
            )
        lbl, days_str = raw.split(":", 1)
        try:
            d = int(days_str)
        except ValueError:
            raise HTTPException(
                status.HTTP_400_BAD_REQUEST,
                f"window days must be an integer (got {days_str!r})",
            )
        if d < 2 or d > 3650:
            raise HTTPException(
                status.HTTP_400_BAD_REQUEST,
                "window days must be in [2, 3650]",
            )
        parsed_windows.append((lbl.strip(), d))
    if not parsed_windows:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "no windows specified")

    key = f"corr:{','.join(asset_list)}:{','.join(f'{l}:{d}' for l,d in parsed_windows)}"
    return _cached(
        key,
        lambda: correlation_matrix(assets=asset_list, windows=parsed_windows),
    )


@router.get("/btc-rolling-correlations")
def btc_rolling_correlations_route(
    partners: str = Query(
        default=",".join(ROLLING_DEFAULT_PARTNERS),
        description="Comma-separated partner assets (e.g. 'SPX,DXY,GOLD,VIX').",
    ),
    window: int = Query(default=30, ge=2, le=365, description="Rolling window in days"),
    history_days: int = Query(
        default=365, ge=30, le=3650,
        description="How much of the rolling series to return (calendar days)",
    ),
    user: dict = Depends(require_page(_PAGE)),
) -> dict:
    partner_list = _split_csv(partners)
    if not partner_list:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "no partners specified")
    key = f"roll:{','.join(partner_list)}:{window}:{history_days}"
    return _cached(
        key,
        lambda: btc_rolling_correlations(
            partners=partner_list, window=window, history_days=history_days,
        ),
    )


@router.get("/crypto-volume")
def crypto_volume(
    assets: str = Query(
        default=",".join(VOLUME_DEFAULT_ASSETS),
        description="Comma-separated assets (e.g. 'BTC,ETH,SOL,AVAX,XRP').",
    ),
    user: dict = Depends(require_page(_PAGE)),
) -> dict:
    asset_list = _split_csv(assets)
    if not asset_list:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "no assets specified")
    return _cached(
        f"crypto_volume:{','.join(asset_list)}",
        lambda: crypto_volume_panel(assets=asset_list),
    )


@router.post("/refresh")
def refresh(user: dict = Depends(require_page(_PAGE))) -> dict:
    """Manual rebuild of the Daily Quant SQLite tables.

    Auth-gated by the BTC_Prices page permission. Blocks the caller
    until upstream pulls finish (10-30 s) and then clears the in-process
    cache so the next read sees fresh data.
    """
    summary = refresh_market_data()
    with _cache_lock:
        _cache.clear()
    return summary
