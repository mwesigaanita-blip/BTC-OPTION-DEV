from __future__ import annotations

import sqlite3
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, Query

from backend_api.auth_jwt import require_page
from shared.db_paths import MODELS_DB

router = APIRouter(prefix="/api/llm-fees", tags=["llm-fees"])

RUN_META_TABLE = "model_run_meta"


def _get_runs() -> List[Dict[str, Any]]:
    try:
        with sqlite3.connect(str(MODELS_DB), timeout=10) as conn:
            conn.row_factory = sqlite3.Row
            rows = conn.execute(
                f"SELECT * FROM {RUN_META_TABLE} ORDER BY id DESC"
            ).fetchall()
        return [dict(r) for r in rows]
    except Exception:
        return []


@router.get("/runs")
def get_llm_runs(
    start_date: Optional[str] = Query(None, description="ISO date string, inclusive (YYYY-MM-DD)"),
    end_date: Optional[str] = Query(None, description="ISO date string, inclusive (YYYY-MM-DD)"),
    provider: Optional[str] = Query(None),
    model_label: Optional[str] = Query(None),
    include_zero: bool = Query(True),
    _user: dict = Depends(require_page("LLM_Fees")),
) -> Dict[str, Any]:
    rows = _get_runs()

    # Normalize cost and parse timestamps
    for r in rows:
        try:
            r["total_cost_usd"] = float(r.get("total_cost_usd") or 0.0)
        except (TypeError, ValueError):
            r["total_cost_usd"] = 0.0

    # Apply filters
    if start_date:
        rows = [r for r in rows if (r.get("run_time_utc") or "") >= start_date]
    if end_date:
        # end_date is inclusive, compare up to end of day
        rows = [r for r in rows if (r.get("run_time_utc") or "")[:10] <= end_date]
    if provider:
        rows = [r for r in rows if r.get("provider") == provider]
    if model_label:
        rows = [r for r in rows if r.get("model_label") == model_label]
    if not include_zero:
        rows = [r for r in rows if r["total_cost_usd"] > 0]

    # Compute summary KPIs
    total_cost = sum(r["total_cost_usd"] for r in rows)
    n_runs = len(rows)
    avg_cost = total_cost / n_runs if n_runs > 0 else 0.0

    now_utc = datetime.now(timezone.utc)
    now_iso = now_utc.isoformat()

    # Last 7 / 30 days based on run_time_utc
    cutoff_7 = now_utc.replace(hour=0, minute=0, second=0, microsecond=0)
    from datetime import timedelta
    cutoff_7 = now_utc - timedelta(days=7)
    cutoff_30 = now_utc - timedelta(days=30)

    def _parse_ts(s: Any) -> Optional[datetime]:
        if not s:
            return None
        try:
            return datetime.fromisoformat(str(s).replace("Z", "+00:00")).replace(tzinfo=timezone.utc)
        except Exception:
            return None

    last_7_cost = sum(
        r["total_cost_usd"]
        for r in rows
        if (_parse_ts(r.get("run_time_utc")) or datetime.min.replace(tzinfo=timezone.utc)) >= cutoff_7
    )
    last_30_cost = sum(
        r["total_cost_usd"]
        for r in rows
        if (_parse_ts(r.get("run_time_utc")) or datetime.min.replace(tzinfo=timezone.utc)) >= cutoff_30
    )

    # Daily aggregates (by run_time_utc date)
    daily: Dict[str, float] = {}
    daily_by_model: Dict[str, Dict[str, float]] = {}
    for r in rows:
        day = (r.get("run_time_utc") or "")[:10]
        if not day:
            continue
        daily[day] = daily.get(day, 0.0) + r["total_cost_usd"]
        lbl = r.get("model_label") or "unknown"
        if day not in daily_by_model:
            daily_by_model[day] = {}
        daily_by_model[day][lbl] = daily_by_model[day].get(lbl, 0.0) + r["total_cost_usd"]

    # By-model and by-provider breakdowns
    by_model: Dict[str, float] = {}
    by_provider: Dict[str, float] = {}
    for r in rows:
        lbl = r.get("model_label") or "unknown"
        prov = r.get("provider") or "unknown"
        by_model[lbl] = by_model.get(lbl, 0.0) + r["total_cost_usd"]
        by_provider[prov] = by_provider.get(prov, 0.0) + r["total_cost_usd"]

    # Available filter options (from full unfiltered rows so dropdowns stay stable)
    all_rows = _get_runs()
    providers = sorted({r.get("provider") for r in all_rows if r.get("provider")})
    model_labels = sorted({r.get("model_label") for r in all_rows if r.get("model_label")})

    return {
        "rows": rows,
        "total_rows": n_runs,
        "summary": {
            "total_cost_usd": total_cost,
            "n_runs": n_runs,
            "avg_cost_usd": avg_cost,
            "last_7_days_usd": last_7_cost,
            "last_30_days_usd": last_30_cost,
        },
        "daily": [
            {"day": d, "cost": c} for d, c in sorted(daily.items())
        ],
        "daily_by_model": [
            {"day": d, **costs} for d, costs in sorted(daily_by_model.items())
        ],
        "by_model": [
            {"model_label": lbl, "cost": c}
            for lbl, c in sorted(by_model.items(), key=lambda x: x[1], reverse=True)
        ],
        "by_provider": [
            {"provider": p, "cost": c}
            for p, c in sorted(by_provider.items(), key=lambda x: x[1], reverse=True)
        ],
        "filter_options": {
            "providers": providers,
            "model_labels": model_labels,
        },
    }
