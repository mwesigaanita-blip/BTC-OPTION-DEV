# backend_api/live_options_runner.py

import logging
from datetime import datetime, timezone

log = logging.getLogger("live_options.runner")


def run_live_options_daily_snapshot(*, days_ahead: int = 1000, snapshot_date_utc: str | None = None) -> dict:
    """
    Runs the snapshot pipeline (Parquet-based, replaces old SQLite/CSV path).
    Kept for backward compatibility with Streamlit manual trigger.
    """
    started_at = datetime.now(timezone.utc)

    try:
        from multi_agent_system.snapshot_pipeline import run_snapshot_pipeline

        result = run_snapshot_pipeline(days_ahead=int(days_ahead))
    except Exception as exc:
        log.exception("Snapshot pipeline failed: %s", exc)
        return {
            "error": str(exc),
            "snapshot_date": snapshot_date_utc or started_at.strftime("%Y-%m-%d"),
            "rows_saved": 0,
            "started_at_utc": started_at.strftime("%Y-%m-%dT%H:%M:%SZ"),
            "finished_at_utc": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        }

    finished_at = datetime.now(timezone.utc)
    rows = sum(result.get("files_written", {}).values())

    out = {
        "snapshot_date": snapshot_date_utc or started_at.strftime("%Y-%m-%d"),
        "rows_saved": rows,
        "started_at_utc": started_at.strftime("%Y-%m-%dT%H:%M:%SZ"),
        "finished_at_utc": finished_at.strftime("%Y-%m-%dT%H:%M:%SZ"),
    }

    log.info("Live options snapshot completed: %s", out)
    return out
