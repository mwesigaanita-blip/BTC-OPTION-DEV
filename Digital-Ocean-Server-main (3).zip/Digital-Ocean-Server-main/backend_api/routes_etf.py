"""BTC ETF Flows routes — thin HTTP wrapper over the agent tools.

Endpoints (all under ``/api/etf``):

- ``GET  /flows?days=10&history_days=180``  -> composite.btc_etf_flows_panel
- ``POST /refresh``                          -> jobs.refresh_market_data (full)

Read endpoint serves from SQLite (no upstream calls) and is cached for
5 minutes. Refresh triggers the same nightly job as the Daily Quant
panel so a single button reseeds everything.
"""
from __future__ import annotations

import logging
import threading
import time

from fastapi import APIRouter, Depends, Query

from backend_api.auth_jwt import require_page
from portfolio_analysis_AI_Agent.tools.composite.btc_etf_flows_panel import (
    btc_etf_flows_panel,
)
from portfolio_analysis_AI_Agent.tools.jobs.refresh_market_data import (
    refresh_market_data,
)

log = logging.getLogger("backend-api.etf")
router = APIRouter(prefix="/api/etf", tags=["etf"])

_PAGE = "BTC_Prices"

_TTL_SEC = 300
_cache_lock = threading.Lock()
_cache: dict[str, tuple[float, dict]] = {}


def _cached(key: str, builder):
    now = time.time()
    with _cache_lock:
        hit = _cache.get(key)
        if hit and now - hit[0] < _TTL_SEC:
            return hit[1]
    payload = builder()
    with _cache_lock:
        _cache[key] = (now, payload)
    return payload


@router.get("/flows")
def flows(
    days: int = Query(default=10, ge=1, le=365, description="Daily rows in the table"),
    history_days: int = Query(
        default=180, ge=1, le=2000,
        description="Bar-chart history length in days",
    ),
    user: dict = Depends(require_page(_PAGE)),
) -> dict:
    return _cached(f"flows:{days}:{history_days}",
                   lambda: btc_etf_flows_panel(days=days, history_days=history_days))


@router.post("/refresh")
def refresh(user: dict = Depends(require_page(_PAGE))) -> dict:
    """Trigger the shared nightly refresh (also rebuilds Daily Quant tables)."""
    summary = refresh_market_data()
    with _cache_lock:
        _cache.clear()
    return summary
