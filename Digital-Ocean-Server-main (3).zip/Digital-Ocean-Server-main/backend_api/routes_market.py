"""Market data routes - live BTC index + perp ticker from WS->Redis."""
from __future__ import annotations

import logging
import threading
import time
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException, status

from portfolio_analysis_AI_Agent.tools.datafetch.market.get_instruments import (
    get_instruments,
)
from shared.redis_live import get_market_live

from backend_api.auth_jwt import require_page

log = logging.getLogger("backend-api.market")

router = APIRouter(prefix="/api/market", tags=["market"])

_PAGE = "Account_Overview"

# ---------------------------------------------------------------------------
# Option instruments cache - 5 min TTL, process-local.
# ---------------------------------------------------------------------------

_INSTRUMENTS_TTL_SEC = 300
_instruments_lock = threading.Lock()
_instruments_cache: dict[str, tuple[float, dict]] = {}  # key: currency


def _build_option_instruments_payload(currency: str) -> dict:
    raw = get_instruments(currency=currency, kind="option", expired=False)
    rows = raw.get("instruments") or []

    groups: dict[str, dict] = {}
    for r in rows:
        name = str(r.get("instrument_name") or "")
        if not name:
            continue
        # Deribit name: BTC-{DDMMMYY}-{strike}-{C|P}
        parts = name.split("-")
        if len(parts) < 4:
            continue
        expiry_label = parts[1].upper()
        try:
            strike = float(r.get("strike") or 0)
        except (TypeError, ValueError):
            continue
        option_type = "C" if str(r.get("option_type") or "").lower().startswith("c") else "P"
        ts_ms = r.get("expiration_timestamp")
        try:
            ts = int(ts_ms) // 1000 if ts_ms else 0
        except (TypeError, ValueError):
            ts = 0

        g = groups.get(expiry_label)
        if g is None:
            iso = (
                datetime.fromtimestamp(ts, tz=timezone.utc).strftime("%Y-%m-%d")
                if ts
                else ""
            )
            g = {
                "expiry_label": expiry_label,
                "expiry_iso": iso,
                "expiry_ts": ts,
                "instruments": [],
            }
            groups[expiry_label] = g
        g["instruments"].append(
            {
                "instrument_name": name,
                "strike": strike,
                "option_type": option_type,
            }
        )

    for g in groups.values():
        g["instruments"].sort(key=lambda x: (x["strike"], x["option_type"]))

    expiries = sorted(groups.values(), key=lambda x: x["expiry_ts"] or 0)
    return {
        "currency": currency,
        "fetched_at": int(time.time()),
        "expiries": expiries,
    }


def get_cached_option_instruments(currency: str = "BTC") -> dict:
    """Process-local cached option-instruments payload (5 min TTL).

    Shared by the public HTTP route and the whatif IV-resolution path so a
    single What-If request can derive ATM-of-expiry fallback IV without
    re-hitting Deribit's `public/get_instruments`.
    """
    now = time.time()
    with _instruments_lock:
        hit = _instruments_cache.get(currency)
        if hit and now - hit[0] < _INSTRUMENTS_TTL_SEC:
            log.debug("option-instruments cache HIT (%s)", currency)
            return hit[1]
    payload = _build_option_instruments_payload(currency)
    with _instruments_lock:
        _instruments_cache[currency] = (now, payload)
    log.info(
        "option-instruments cache MISS (%s) - %d expiries",
        currency,
        len(payload["expiries"]),
    )
    return payload


@router.get("/live")
def live(user: dict = Depends(require_page(_PAGE))) -> dict:
    """Latest merged market state (`btc_index`, `perp_*`)."""
    market, updated_at = get_market_live()
    return {"updated_at": updated_at, "market": market or {}}


@router.get("/option-instruments")
def option_instruments(
    currency: str = "BTC",
    user: dict = Depends(require_page(_PAGE)),
) -> dict:
    """Active Deribit option instruments grouped by expiry. 5-min cached."""
    try:
        return get_cached_option_instruments(currency.upper())
    except Exception as e:  # pragma: no cover
        log.exception("option-instruments failed")
        raise HTTPException(
            status.HTTP_502_BAD_GATEWAY,
            f"Failed to load option instruments: {e}",
        )
