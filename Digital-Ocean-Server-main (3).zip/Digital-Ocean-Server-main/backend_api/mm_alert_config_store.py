import json
import sqlite3
from datetime import datetime, timezone
from typing import Any, Dict
from shared.db_paths import INFRA_DB

DB_PATH = INFRA_DB  # backward-compat alias for any external importer
print(f"[DB] Using {DB_PATH} in {__file__}", flush=True)


def _utc_now_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _db_path() -> str:
    return str(INFRA_DB)


def _connect() -> sqlite3.Connection:
    conn = sqlite3.connect(_db_path())
    conn.row_factory = sqlite3.Row
    return conn

def ensure_table(conn: sqlite3.Connection) -> None:
    conn.execute("""
    CREATE TABLE IF NOT EXISTS mm_alert_config (
        id INTEGER PRIMARY KEY CHECK (id = 1),
        warning_threshold REAL NOT NULL DEFAULT 80.0,
        critical_threshold REAL NOT NULL DEFAULT 95.0,
        warning_cooldown_minutes INTEGER NOT NULL DEFAULT 5,
        critical_cooldown_minutes INTEGER NOT NULL DEFAULT 1,
        check_interval_seconds INTEGER NOT NULL DEFAULT 30,
        currencies_json TEXT NOT NULL DEFAULT '["BTC"]',
        is_enabled INTEGER NOT NULL DEFAULT 1,
        updated_at_utc TEXT NOT NULL
    )
    """)
    cur = conn.execute("SELECT 1 FROM mm_alert_config WHERE id=1")
    if cur.fetchone() is None:
        conn.execute("""
        INSERT INTO mm_alert_config (
            id, warning_threshold, critical_threshold,
            warning_cooldown_minutes, critical_cooldown_minutes,
            check_interval_seconds, currencies_json, is_enabled, updated_at_utc
        ) VALUES (1, 80.0, 95.0, 5, 1, 30, '["BTC"]', 1, ?)
        """, (_utc_now_iso(),))
    conn.commit()

def read_config() -> Dict[str, Any]:
    conn = _connect()
    try:
        ensure_table(conn)
        row = conn.execute("SELECT * FROM mm_alert_config WHERE id=1").fetchone()
        out = dict(row)
        out["currencies"] = json.loads(out.pop("currencies_json") or '["BTC"]')
        out["is_enabled"] = bool(out["is_enabled"])
        return out
    finally:
        conn.close()

def upsert_config(payload: Dict[str, Any]) -> Dict[str, Any]:
    conn = _connect()
    try:
        ensure_table(conn)
        current = read_config()
        merged = {**current, **payload}

        currencies = merged.get("currencies", ["BTC"])
        currencies_json = json.dumps(currencies)

        conn.execute("""
        UPDATE mm_alert_config
        SET warning_threshold=?,
            critical_threshold=?,
            warning_cooldown_minutes=?,
            critical_cooldown_minutes=?,
            check_interval_seconds=?,
            currencies_json=?,
            is_enabled=?,
            updated_at_utc=?
        WHERE id=1
        """, (
            float(merged["warning_threshold"]),
            float(merged["critical_threshold"]),
            int(merged["warning_cooldown_minutes"]),
            int(merged["critical_cooldown_minutes"]),
            int(merged["check_interval_seconds"]),
            currencies_json,
            1 if merged.get("is_enabled", True) else 0,
            _utc_now_iso(),
        ))
        conn.commit()
        return read_config()
    finally:
        conn.close()
