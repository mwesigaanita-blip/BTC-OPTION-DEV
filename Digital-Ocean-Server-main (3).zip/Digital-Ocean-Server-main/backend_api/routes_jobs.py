from __future__ import annotations

from typing import Any

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from backend_api.jobs import init_jobs_table, create_job, get_job, request_cancel


router = APIRouter(tags=["jobs"])


class CreateJobRequest(BaseModel):
    job_type: str = Field(..., description="run_model | run_all_models | run_models_sequence | refresh_1min")
    payload: dict[str, Any] = Field(default_factory=dict)


@router.on_event("startup")
def _startup():
    init_jobs_table()


@router.post("/jobs")
def create_job_endpoint(req: CreateJobRequest):
    """
    Enqueue-only endpoint.
    Worker service is responsible for executing queued jobs.
    """
    job_id = create_job(job_type=req.job_type, payload=req.payload)
    return {"job_id": job_id}


@router.get("/jobs/{job_id}")
def get_job_endpoint(job_id: str):
    job = get_job(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="job not found")
    return job


@router.post("/jobs/{job_id}/cancel")
def cancel_job_endpoint(job_id: str):
    ok = request_cancel(job_id)
    if not ok:
        raise HTTPException(status_code=404, detail="job not found or not cancellable")
    return {"ok": True, "job_id": job_id}
