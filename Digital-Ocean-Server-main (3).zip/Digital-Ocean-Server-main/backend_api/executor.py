from __future__ import annotations

import logging
import traceback
from typing import Any

from backend_api.jobs import (
    set_job_running,
    set_job_succeeded,
    set_job_failed,
    set_job_progress,
    is_cancel_requested,
    set_job_cancelled,
)

log = logging.getLogger("worker.executor")
log.propagate = True

def run_job_in_background(job_id: str, job_type: str, payload: dict[str, Any]) -> None:
    """
    Executes a claimed job (worker thread).
    Writes progress to DB so Streamlit can poll /v1/jobs/{id}.
    """
    try:
        set_job_running(job_id)

        # Import inside function to isolate import errors
        from multi_agent_system.runner import run_one_model, run_all_models

        def progress(stage: str, pct: int, line: str) -> None:
            set_job_progress(job_id, {"stage": str(stage), "pct": int(pct), "line": str(line)})
            msg = f"[job={job_id}] {stage} {pct}% {line}"
            log.info(msg)
            print(msg, flush=True)   # <-- SAFETY NET


        def should_stop() -> bool:
            return bool(is_cancel_requested(job_id))

        # ------------------------------------------------------------
        # run_model
        # ------------------------------------------------------------
        if job_type == "run_model":
            model_id = payload.get("model_id")
            if not model_id:
                raise ValueError("payload.model_id is required for run_model")

            params = payload.get("params") or {}

            progress("prepare", 1, f"Starting run_one_model({model_id})")
            result = run_one_model(model_id, progress=progress, should_stop=should_stop, params=params)

            # runner returns {"ok":False,"error":"stopped"} when cancelled
            if isinstance(result, dict) and result.get("error") == "stopped":
                set_job_cancelled(job_id, result={"ok": False, "cancelled": True, "result": result})
                return

            progress("done", 100, "run_model finished")
            set_job_succeeded(job_id, result={"ok": True, "model_id": model_id, "result": result})
            return

        # ------------------------------------------------------------
        # run_all_models
        # ------------------------------------------------------------
        if job_type == "run_all_models":
            params = payload.get("params") or {}
            progress("prepare", 1, "Starting run_all_models()")
            result = run_all_models(progress=progress, should_stop=should_stop, params=params)

            if isinstance(result, dict) and result.get("error") == "stopped":
                # FIX: no undefined all_results variable
                set_job_cancelled(job_id, result={"ok": False, "cancelled": True, "result": result})
                return

            progress("done", 100, "run_all_models finished")
            set_job_succeeded(job_id, result={"ok": True, "result": result})
            return

        # ------------------------------------------------------------
        # run_models_sequence (optional)
        # Runs a list of model_ids sequentially by calling run_one_model per id.
        # ------------------------------------------------------------
        if job_type == "run_models_sequence":
            model_ids = payload.get("model_ids") or []
            if not isinstance(model_ids, list) or not model_ids:
                raise ValueError("payload.model_ids must be a non-empty list for run_models_sequence")

            params = payload.get("params") or {}

            results: list[dict[str, Any]] = []
            n = len(model_ids)

            for idx, model_id in enumerate(model_ids, start=1):
                if should_stop():
                    set_job_cancelled(job_id, result={"ok": False, "cancelled": True, "results": results})
                    return

                pct_base = int(((idx - 1) / max(n, 1)) * 100)
                progress("prepare", pct_base, f"Sequence starting {model_id} ({idx}/{n})")

                # Wrap progress to map each model's progress into a portion of 0..100
                def seq_progress(stage: str, pct: int, line: str, _pct_base=pct_base, _idx=idx) -> None:
                    # each model gets a slice
                    slice_size = int(100 / max(n, 1))
                    mapped = min(99, _pct_base + int((pct / 100) * slice_size))
                    progress(f"{stage}", mapped, f"[{_idx}/{n}] {line}")

                one = run_one_model(model_id, progress=seq_progress, should_stop=should_stop, params=params)
                results.append({"model_id": model_id, "result": one})

            progress("done", 100, "Sequence finished")
            set_job_succeeded(job_id, result={"ok": True, "results": results})
            return

        # ------------------------------------------------------------
        # Unknown job type
        # ------------------------------------------------------------
        raise ValueError(f"Unknown job_type: {job_type}")

    except Exception as e:
        tb = traceback.format_exc()
        log.error("[job=%s] FAILED %s\n%s", job_id, e, tb)
        # Keep error short; store stack trace in result_json if you want
        set_job_failed(job_id, error=f"{type(e).__name__}: {e}")
