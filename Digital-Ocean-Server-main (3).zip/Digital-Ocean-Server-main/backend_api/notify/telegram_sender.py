from __future__ import annotations

import os
import json
import urllib.request
import urllib.parse
from dotenv import load_dotenv
load_dotenv()  # Load .env file if present

def send_telegram_message(text: str) -> None:
    """
    Pure-Python Telegram sender.
    Env vars (any combination allowed):
      TELEGRAM_OWNER_CHAT_ID
      REMO_CHAT_ID
      AHMED_CHAT_ID
      TELEGRAM_BOT_TOKEN (required)
    """

    token = (os.getenv("TELEGRAM_BOT_TOKEN") or "").strip()
    owner_id = (os.getenv("TELEGRAM_OWNER_CHAT_ID") or "").strip()
    remo_id = (os.getenv("REMO_CHAT_ID") or "").strip()
    ahmed_id = (os.getenv("AHMED_CHAT_ID") or "").strip()

    if not token:
        raise RuntimeError("Missing TELEGRAM_BOT_TOKEN in env")

    # Collect all valid chat IDs
    chat_ids = [cid for cid in (owner_id, remo_id, ahmed_id) if cid]

    if not chat_ids:
        raise RuntimeError("No Telegram chat IDs configured")

    url = f"https://api.telegram.org/bot{token}/sendMessage"

    errors = []

    for chat_id in chat_ids:
        try:
            data = urllib.parse.urlencode(
                {
                    "chat_id": chat_id,
                    "text": text,
                    "parse_mode": "HTML",
                    "disable_web_page_preview": "true",
                }
            ).encode("utf-8")

            req = urllib.request.Request(url, data=data, method="POST")

            with urllib.request.urlopen(req, timeout=20) as resp:
                body = resp.read().decode("utf-8", errors="replace")
                j = json.loads(body)

                if not j.get("ok"):
                    errors.append(f"{chat_id}: {body}")

        except Exception as e:
            errors.append(f"{chat_id}: {str(e)}")

    # Only raise if ALL failed
    if len(errors) == len(chat_ids):
        raise RuntimeError(f"Telegram send failed for all chat IDs: {errors}")

