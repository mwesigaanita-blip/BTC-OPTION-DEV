import os
import sqlite3
from datetime import datetime
from db_tools import DB_PATH
# ==== CHANGE THIS ==== 

TABLE = "x_score"

DDL_NEW = f"""
CREATE TABLE IF NOT EXISTS {TABLE}__migrated (
    date TEXT,
    score_now REAL,
    score_7d REAL,
    score_30d REAL,
    x_sentiment_sentence TEXT
);
"""

def migrate_x_score(db_path: str):
    if not os.path.exists(db_path):
        raise FileNotFoundError(f"DB not found: {db_path}")

    conn = sqlite3.connect(db_path)
    conn.isolation_level = None  # manual transactions
    cur = conn.cursor()

    try:
        # --- sanity: table exists? ---
        cur.execute("BEGIN;")
        cur.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name=?;",
            (TABLE,)
        )
        row = cur.fetchone()
        if not row:
            raise RuntimeError(f"Table '{TABLE}' not found in {db_path}")

        # --- inspect columns ---
        cur.execute(f"PRAGMA table_info({TABLE});")
        cols = [r[1] for r in cur.fetchall()]
        print(f"[INFO] Existing columns in {TABLE}: {cols}")

        # --- backup original table (safety) ---
        backup_name = f"{TABLE}__backup_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}"
        cur.execute(f"ALTER TABLE {TABLE} RENAME TO {backup_name};")
        print(f"[OK] Backed up original table to: {backup_name}")

        # --- create new target table ---
        cur.execute(DDL_NEW)
        print(f"[OK] Created target table: {TABLE}__migrated")

        # --- copy data with mapping ---
        # old -> new:
        # date                    -> date
        # x_score                 -> score_now
        # score_7d                -> NULL
        # score_30d               -> NULL
        # x_sentiment_sentence    -> x_sentiment_sentence
        cur.execute(f"""
            INSERT INTO {TABLE}__migrated (date, score_now, score_7d, score_30d, x_sentiment_sentence)
            SELECT
                date,
                x_score AS score_now,
                NULL AS score_7d,
                NULL AS score_30d,
                x_sentiment_sentence
            FROM {backup_name};
        """)
        print(f"[OK] Copied data from {backup_name} → {TABLE}__migrated")

        # --- drop any old table named {TABLE} if exists (we already renamed it to backup) ---
        # (nothing to drop here, the live name {TABLE} doesn't exist now)

        # --- rename migrated to live name ---
        cur.execute(f"ALTER TABLE {TABLE}__migrated RENAME TO {TABLE};")
        print(f"[OK] Renamed {TABLE}__migrated → {TABLE}")

        # --- optional: index on date for fast lookups ---
        cur.execute(f"CREATE INDEX IF NOT EXISTS idx_{TABLE}__date ON {TABLE}(date);")
        print(f"[OK] Created index idx_{TABLE}__date on {TABLE}(date)")

        cur.execute("COMMIT;")
        print("[DONE] Migration committed successfully.")

        print("\n[NOTE] Backup of old table is kept as:", backup_name)
        print("       Verify the new schema and data, then you may DROP the backup manually if desired.")

    except Exception as e:
        cur.execute("ROLLBACK;")
        raise
    finally:
        conn.close()

if __name__ == "__main__":
    migrate_x_score(DB_PATH)
