# Streamlit/pages/3_Positions_History.py
import os
import sys
import json
import sqlite3
from datetime import datetime
import streamlit.components.v1 as components # type: ignore
import numpy as np # type: ignore
import pandas as pd # type: ignore
import streamlit as st # type: ignore

st.set_page_config(page_title="Positions History", page_icon="📜", layout="wide")
st.markdown("## Positions History")

# --- Ensure we can import Streamlit/data_service (for DB_PATH), else compute from repo root
import os, sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[2]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from shared.streamlit_auth import require_login
require_login()


try:
    from shared.db_paths import SNAPSHOTS_DB, TRADING_DB
    SNAPSHOTS_DB_PATH = str(SNAPSHOTS_DB)
    TRADING_DB_PATH = str(TRADING_DB)
except Exception:
    _data_dir = os.environ.get("DATA_DIR") or os.environ.get("DB_BASE_DIR") \
        or os.path.join(REPO_ROOT, "data")
    SNAPSHOTS_DB_PATH = os.path.abspath(os.path.join(_data_dir, "snapshots.sqlite"))
    TRADING_DB_PATH = os.path.abspath(os.path.join(_data_dir, "trading.sqlite"))

DB_PATH = SNAPSHOTS_DB_PATH

def load_cumulative_flows(db_path: str) -> pd.DataFrame:
    with sqlite3.connect(db_path) as conn:
        df_flows = pd.read_sql_query("SELECT ts_utc, type, amount_btc FROM account_flows", conn)
    
    if df_flows.empty:
        return pd.DataFrame(columns=["date", "flow_val", "cum_flow"])

    df_flows["date"] = pd.to_datetime(df_flows["ts_utc"]).dt.normalize()
    
    # Positive for deposits, negative for withdrawals
    df_flows["flow_val"] = df_flows.apply(
        lambda x: x["amount_btc"] if x["type"].lower() == "deposit" else -x["amount_btc"], 
        axis=1
    )
    
    # Sort by date
    df_flows = df_flows.sort_values("date")
    
    # Group by date to handle multiple transactions in one day
    daily = df_flows.groupby("date")["flow_val"].sum().reset_index()
    daily["cum_flow"] = daily["flow_val"].cumsum()
    
    return daily # Returns: date, flow_val, cum_flowx   

def load_account_capital_history(db_path: str) -> pd.DataFrame:
    with sqlite3.connect(db_path) as conn:
        df = pd.read_sql_query("SELECT date, payload_json FROM account_snapshots", conn)

    rows = []
    for _, row in df.iterrows():
        try:
            data = json.loads(row["payload_json"])

            # USD equity
            cap = data.get("total_equity_usd")
            if cap is None or float(cap) <= 0:
                cap = data.get("capital_usd") or data.get("equity_usd") or 0

            # BTC equity - top-level "equity" field is BTC-denominated
            btc = data.get("equity")

            rows.append({
                "date": row["date"],
                "total_portfolio_usd": float(cap),
                "total_portfolio_btc": float(btc) if btc is not None else None,
            })
        except Exception:
            continue

    res = pd.DataFrame(rows)
    if not res.empty:
        res["date"] = pd.to_datetime(res["date"]).dt.tz_localize(None).dt.normalize()
        res = res.groupby("date")[["total_portfolio_usd", "total_portfolio_btc"]].last().reset_index()
    return res



def round_numeric_for_plot(df: pd.DataFrame, decimals: int = 2) -> pd.DataFrame:
    """
    Return a COPY of df where all numeric columns are rounded
    (used ONLY for plotting, not for calculations).
    """
    out = df.copy()
    num_cols = out.select_dtypes(include=["number"]).columns
    out[num_cols] = out[num_cols].round(decimals)
    return out


def compute_day_metrics(day_df: pd.DataFrame) -> dict:
    """
    Compute time-series metrics per day from the flattened positions dataframe for that day.
    Uses only columns that may exist.
    """
    df = day_df.copy()

    # safe numeric coercions
    df = coerce_numeric(df, [
        "qty", "size", "DTE",
        "pnl_usd_total", "pnl_usd_total_deribit", "pnl_usd_total_model",
        "pnl_btc_total_deribit",
        "mark_usd", "avg_price_usd", "index_price",
        "delta", "gamma", "theta", "vega",
        "initial_margin", "maintenance_margin"
    ])

    k = compute_pnl_kpis(df)

    # Greeks totals (sum of position greeks)
    greek_sum = {}
    for g in ["delta", "gamma", "theta", "vega"]:
        greek_sum[g] = float(df[g].fillna(0).sum()) if g in df.columns else 0.0

    # Contracts count
    contracts = float(df["qty"].fillna(0).sum()) if "qty" in df.columns else float(len(df))

    # Margin proxies (only if present in payload)
    mm = float(df["maintenance_margin"].fillna(0).sum()) if "maintenance_margin" in df.columns else None
    im = float(df["initial_margin"].fillna(0).sum()) if "initial_margin" in df.columns else None

    # Expiry concentration (nearest DTE)
    min_dte = float(df["DTE"].min()) if "DTE" in df.columns and df["DTE"].notna().any() else None

    # Spot/index proxy
    idx_price = float(df["index_price"].dropna().iloc[0]) if "index_price" in df.columns and df["index_price"].notna().any() else None

    return {
        "pnl_total_usd": k["pnl_total_usd"],
        "pnl_float_usd": k["pnl_float_usd"],
        "pnl_real_usd": k["pnl_real_usd"],
        "pnl_total_btc": k["total_pnl_btc"],
        "contracts": contracts,
        "open_positions": float(len(df)),
        "delta_sum": greek_sum["delta"],
        "gamma_sum": greek_sum["gamma"],
        "theta_sum": greek_sum["theta"],
        "vega_sum": greek_sum["vega"],
        "mm_btc_sum": mm,
        "im_btc_sum": im,
        "min_dte": min_dte,
        "index_price": idx_price,
    }


def build_history_timeseries(snapshots_df: pd.DataFrame) -> pd.DataFrame:
    """
    Build one-row-per-day time-series from positions_snapshots.
    """
    rows = []
    for _, row in snapshots_df.iterrows():
        day = str(row["date"])
        df_day = records_to_df(row.get("payload_json", ""))
        if df_day.empty:
            rows.append({"date": day, "open_positions": 0})
            continue

        metrics = compute_day_metrics(df_day)
        metrics["date"] = day
        metrics["updated_at"] = str(row.get("updated_at") or "")
        rows.append(metrics)

    ts = pd.DataFrame(rows)
    if "date" in ts.columns:
        ts["date"] = pd.to_datetime(ts["date"], errors="coerce")
        ts = ts.sort_values("date")
    return ts


# ---- Load all snapshots (date, payload_json, updated_at) ----
def load_all_position_snapshots(db_path: str) -> pd.DataFrame:
    with sqlite3.connect(db_path) as conn:
        df = pd.read_sql_query(
            "SELECT date, payload_json, updated_at FROM positions_snapshots ORDER BY date DESC",
            conn
        )
    return df

def records_to_df(payload_json: str) -> pd.DataFrame:
    try:
        records = json.loads(payload_json) if payload_json else []
        if isinstance(records, dict) and "rows" in records:
            records = records["rows"]
        return pd.DataFrame(records)
    except Exception:
        return pd.DataFrame([])

def coerce_numeric(df: pd.DataFrame, cols: list[str]) -> pd.DataFrame:
    for c in cols:
        if c in df.columns:
            df[c] = pd.to_numeric(df[c], errors="coerce")
    return df

def compute_pnl_kpis(df: pd.DataFrame) -> dict:
    # Try several shapes (like Account Overview page)
    pnl_total_usd = 0.0
    pnl_float_usd = 0.0
    pnl_real_usd  = 0.0

    if "pnl_usd_total" in df.columns and df["pnl_usd_total"].notna().any():
        pnl_total_usd = float(df["pnl_usd_total"].fillna(0).sum())
    elif {"total_profit_loss", "index_price"} <= set(df.columns):
        pnl_total_usd = float((df["total_profit_loss"].fillna(0).astype(float) *
                               df["index_price"].fillna(0).astype(float)).sum())
    elif {"mark_usd", "avg_price_usd", "qty", "side"} <= set(df.columns):
        delta = (df["mark_usd"].astype(float) - df["avg_price_usd"].astype(float))
        per_contract = np.where(df["side"].astype(str).str.upper().eq("SELL"), -delta, delta)
        pnl_total_usd = float(np.nansum(per_contract * df["qty"].fillna(0).astype(float)))

    if {"floating_profit_loss", "index_price"} <= set(df.columns):
        pnl_float_usd = float((df["floating_profit_loss"].fillna(0).astype(float) *
                               df["index_price"].fillna(0).astype(float)).sum())
    elif {"mark_usd", "avg_price_usd", "qty", "side"} <= set(df.columns):
        delta = (df["mark_usd"].astype(float) - df["avg_price_usd"].astype(float))
        per_contract = np.where(df["side"].astype(str).str.upper().eq("SELL"), -delta, delta)
        pnl_float_usd = float(np.nansum(per_contract * df["qty"].fillna(0).astype(float)))

    if {"realized_profit_loss", "index_price"} <= set(df.columns):
        pnl_real_usd = float((df["realized_profit_loss"].fillna(0).astype(float) *
                              df["index_price"].fillna(0).astype(float)).sum())

    total_qty = float(df["qty"].fillna(0).sum()) if "qty" in df.columns else 0.0
    total_pnl_btc = float(df["pnl_btc_total_deribit"].fillna(0).sum()) if "pnl_btc_total_deribit" in df.columns else 0.0

    return {
        "pnl_total_usd": pnl_total_usd,
        "pnl_float_usd": pnl_float_usd,
        "pnl_real_usd":  pnl_real_usd,
        "total_qty":     total_qty,
        "total_pnl_btc": total_pnl_btc,
    }

def kpi_block(label: str, value: float, money: bool = True, good_color: bool | None = None):
    if good_color is None:
        color = "#16a34a" if (money and value >= 0) else ("#dc2626" if money else "#ffffff")
    else:
        color = "#16a34a" if good_color else "#dc2626"
    txt = f"${value:,.4f}" if money else f"{value:,.2f}"
    st.markdown(
        f"""
        <div style="display:flex; flex-direction:column;">
          <div style="font-size:12px; color:#cbd5e1; margin-bottom:4px;">{label}</div>
          <div style="font-size:26px; font-weight:800; color:{color}; line-height:1.1;">{txt}</div>
        </div>
        """,
        unsafe_allow_html=True,
    )

# ---- Main render ----
try:
    snapshots = load_all_position_snapshots(SNAPSHOTS_DB_PATH)
except Exception as e:
    st.error(f"Failed to read `positions_snapshots`: {e}")
    snapshots = pd.DataFrame(columns=["date", "payload_json", "updated_at"])

if snapshots.empty:
    st.info("No historical positions found in `positions_snapshots` yet.")
else:
    st.caption(f"Rows: **{len(snapshots)}**  • Columns: **{', '.join(snapshots.columns)}**")
    st.markdown("## Portfolio History Overview")

    # ----------------------------
    # Build time-series once
    # ----------------------------
    ts = build_history_timeseries(snapshots)
    # --- Load Portfolio History & Flows ---
    cap_history = load_account_capital_history(SNAPSHOTS_DB_PATH)
    flows_df = load_cumulative_flows(TRADING_DB_PATH)

    if not cap_history.empty:
        ts["date_only"] = pd.to_datetime(ts["date"]).dt.tz_localize(None).dt.normalize()
        
        # Merge and forward fill
        ts = pd.merge(ts, cap_history, left_on="date_only", right_on="date", how="left", suffixes=('', '_drop'))
        
        # Round the portfolio value to 2 decimals
        ts["total_portfolio_usd"] = ts["total_portfolio_usd"].ffill().round(2)

        # Forward fill BTC equity and round to 4 decimals
        if "total_portfolio_btc" in ts.columns:
            ts["total_portfolio_btc"] = (
                pd.to_numeric(ts["total_portfolio_btc"], errors="coerce")
                .ffill()
                .round(4)
            )

        # Round the BTC flow values to 4 decimals (since BTC is small) but USD to 2
        if "flow_val" in ts.columns:
            ts["flow_val"] = ts["flow_val"].fillna(0).round(4)

        if not flows_df.empty:
            flows_df["date_only"] = pd.to_datetime(flows_df["date"]).dt.tz_localize(None).dt.normalize()
            daily_flows = flows_df.groupby("date_only")["flow_val"].sum().reset_index()
            
            ts = pd.merge(ts, daily_flows, on="date_only", how="left")
            ts["flow_val"] = ts["flow_val"].fillna(0)
            
            ts["event_type"] = "None"
            ts.loc[ts["flow_val"] > 0.0001, "event_type"] = "Deposit"
            ts.loc[ts["flow_val"] < -0.0001, "event_type"] = "Withdrawal"
        
    # ----------------------------
    min_date = ts["date"].min()
    max_date = ts["date"].max()
    def get_pct_change(df, days=None, is_ytd=False):
        if df.empty or "total_portfolio_usd" not in df.columns:
            return 0.0, 0.0
        
        latest_val = df["total_portfolio_usd"].iloc[-1]
        latest_date = df["date"].iloc[-1]
        
        if is_ytd:
            # First day of the current year
            target_date = pd.Timestamp(year=latest_date.year, month=1, day=1)
        else:
            # Specific number of days ago
            target_date = latest_date - pd.Timedelta(days=days)
        
        # Find the row closest to that target date
        past_data = df[df["date"] <= target_date]
        if past_data.empty:
            # If history isn't long enough, use the first available record
            past_val = df["total_portfolio_usd"].iloc[0]
        else:
            past_val = past_data["total_portfolio_usd"].iloc[-1]
        
        if past_val == 0: return 0.0, 0.0
        
        pct_change = ((latest_val - past_val) / past_val) * 100
        abs_change = latest_val - past_val
        return pct_change, abs_change

    # Calculate Metrics
    d1_pct, d1_abs   = get_pct_change(ts, days=1)
    d3_pct, d3_abs   = get_pct_change(ts, days=3)
    w1_pct, w1_abs   = get_pct_change(ts, days=7)
    m1_pct, m1_abs   = get_pct_change(ts, days=30)
    m3_pct, m3_abs   = get_pct_change(ts, days=90)
    m6_pct, m6_abs   = get_pct_change(ts, days=180)
    y1_pct, y1_abs   = get_pct_change(ts, days=365)
    ytd_pct, ytd_abs = get_pct_change(ts, is_ytd=True)
    cA, cB, cC = st.columns([2, 2, 2])

    with cA:
        dcol, rcol = st.columns([12, 1], gap="small", vertical_alignment="bottom")

        # --- Reset click flag (different key) ---
        with rcol:
            reset_clicked = st.button("↺", help="Reset date range", key="btn_reset_positions_history_date")

        # --- If reset clicked, update the date_input key BEFORE it is created ---
        if reset_clicked and pd.notna(min_date) and pd.notna(max_date):
            st.session_state["positions_history_date_range"] = (min_date.date(), max_date.date())

        # --- Now create the date_input ---
        with dcol:
            date_val = st.date_input(
                "Date range (UTC) - Min / Max",
                value=st.session_state.get(
                    "positions_history_date_range",
                    (min_date.date(), max_date.date()),
                ),
                min_value=min_date.date(),
                max_value=max_date.date(),
                key="positions_history_date_range",
            )

        # Normalize date_val -> min_sel/max_sel
        min_sel, max_sel = None, None
        if isinstance(date_val, tuple) and len(date_val) == 2:
            min_sel, max_sel = date_val
        elif date_val is not None:
            min_sel, max_sel = date_val, date_val

        # Safety: scalarize if list-like slips through
        if isinstance(min_sel, (list, tuple, np.ndarray)):
            min_sel = min_sel[0] if len(min_sel) else None
        if isinstance(max_sel, (list, tuple, np.ndarray)):
            max_sel = max_sel[0] if len(max_sel) else None




    with cB:
        show_points = st.checkbox("Show points", value=False)

    with cC:
        metric_mode = st.selectbox(
            "PnL series",
            ["pnl_total_usd", "pnl_float_usd", "pnl_real_usd", "pnl_total_btc"],
            index=0,
        )

    # ----------------------------
    # Filter time series (logic)
    # ----------------------------
    ts_show = ts.copy().dropna(subset=["date"])

    if min_sel is not None and max_sel is not None:
        start = pd.Timestamp(min_sel)
        end   = pd.Timestamp(max_sel)

        if start > end:
            start, end = end, start

        end = end + pd.Timedelta(days=1) - pd.Timedelta(microseconds=1)
        ts_show = ts_show[(ts_show["date"] >= start) & (ts_show["date"] <= end)]

    # Rounded COPY for plotting only
    ts_plot = round_numeric_for_plot(ts_show, decimals=2)

    # ----------------------------
    # Top KPIs (last day)
    # ----------------------------
    last = ts_show.dropna(subset=["date"]).tail(1)
    if not last.empty:
        L = last.iloc[0].to_dict()
        k1, k2, k3, k4, k5, k6 = st.columns(6)
        k1.metric("Last Snapshot", L["date"].strftime("%Y-%m-%d"))
        k2.metric("Open Positions", int(L.get("open_positions", 0)))
        k3.metric("Total Contracts", f'{float(L.get("contracts", 0)):,.0f}')
        k4.metric("PnL Total (USD)", f'{float(L.get("pnl_total_usd", 0)):,.0f}')
        k5.metric("Theta Sum", f'{float(L.get("theta_sum", 0)):,.2f}')
        k6.metric("Vega Sum", f'{float(L.get("vega_sum", 0)):,.2f}')


    st.markdown("### 📈 Portfolio Performance")
    perf_cols = st.columns(8)

    metrics = [
        ("1 Day",    d1_pct,  d1_abs),
        ("3 Days",   d3_pct,  d3_abs),
        ("1 Week",   w1_pct,  w1_abs),
        ("1 Month",  m1_pct,  m1_abs),
        ("3 Months", m3_pct,  m3_abs),
        ("6 Months", m6_pct,  m6_abs),
        ("1 Year",   y1_pct,  y1_abs),
        ("YTD",      ytd_pct, ytd_abs),
    ]

    for col, (label, pct, val) in zip(perf_cols, metrics):
        with col:
            color = "#22c55e" if pct >= 0 else "#ef4444"
            st.markdown(
                f"""
                <div style="background-color: rgba(255,255,255,0.05); padding: 15px; border-radius: 10px; border-left: 5px solid {color};">
                    <div style="font-size: 0.8rem; color: #94a3b8;">{label}</div>
                    <div style="font-size: 1.4rem; font-weight: bold; color: {color};">{pct:+.2f}%</div>
                    <div style="font-size: 0.9rem; color: #cbd5e1;">${val:,.2f}</div>
                </div>
                """,
                unsafe_allow_html=True
            )
    st.divider()

    # ----------------------------
    # Charts (use ts_plot)
                # ----------------------------
    import plotly.graph_objects as go

    st.markdown("### Total Portfolio Value (USD & BTC)")

    if "total_portfolio_usd" in ts.columns:
        fig = go.Figure()

        # 1. USD Equity Line (primary Y)
        fig.add_trace(go.Scatter(
            x=ts_show["date"],
            y=ts_show["total_portfolio_usd"],
            mode='lines',
            name='Equity (USD)',
            yaxis='y1',
            line=dict(color='#00f2ff', width=3),
            fill='tozeroy',
            fillcolor='rgba(0, 242, 255, 0.07)',
            hovertemplate="Date: %{x}<br>Equity USD: $%{y:,.2f}<extra></extra>"
        ))

        # 2. BTC Equity Line (secondary Y)
        if "total_portfolio_btc" in ts_show.columns and ts_show["total_portfolio_btc"].notna().any():
            fig.add_trace(go.Scatter(
                x=ts_show["date"],
                y=ts_show["total_portfolio_btc"],
                mode='lines',
                name='Equity (BTC)',
                yaxis='y2',
                line=dict(color='#f7931a', width=2, dash='dot'),
                hovertemplate="Date: %{x}<br>Equity BTC: ₿%{y:,.4f}<extra></extra>"
            ))

        # 3. Event Markers (on USD axis)
        for event, color, symbol in [("Deposit", "#22c55e", "triangle-up"), 
                                    ("Withdrawal", "#ef4444", "triangle-down")]:
            ev_df = ts[ts["event_type"] == event]
            if not ev_df.empty:
                fig.add_trace(go.Scatter(
                    x=ev_df["date"],
                    y=ev_df["total_portfolio_usd"],
                    mode='markers',
                    name=event,
                    yaxis='y1',
                    marker=dict(color=color, size=12, symbol=symbol, line=dict(width=1, color="white")),
                    text=[f"Flow: {v:,.4f} BTC" for v in ev_df["flow_val"]],
                    hovertemplate="<b>%{text}</b><br>Equity: $%{y:,.2f}<extra></extra>"
                ))

        fig.update_layout(
            template="plotly_dark",
            hovermode="x unified",
            xaxis=dict(showgrid=False),
            yaxis=dict(
                title="USD Value",
                tickformat="$,.0f",
                side="left",
                showgrid=True,
                gridcolor="rgba(255,255,255,0.05)",
            ),
            yaxis2=dict(
                title=dict(text="BTC Value", font=dict(color="#f7931a")),
                tickformat=",.3f",
                side="right",
                overlaying="y",
                showgrid=False,
                tickfont=dict(color="#f7931a"),
            ),
            legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
            margin=dict(l=0, r=60, t=30, b=0)
        )

        st.plotly_chart(fig, width='stretch')
    
    
    st.markdown("### Key Trends")
    components.html(
        """
        <div style="
            background-color: rgba(255,255,255,0.04);
            padding: 14px 18px;
            border-radius: 12px;
            margin-bottom: 14px;
            font-size: 0.9rem;
            color: #cbd5e1;
            line-height: 1.5;
            font-family: sans-serif;
        ">
            <div style="font-weight:600; margin-bottom:6px;">
                What this shows
            </div>

            <div style="margin-bottom:8px;">
                These charts track how the portfolio evolves over time using daily snapshots.
            </div>

            <ul style="margin: 6px 0 10px 18px;">
                <li>
                    <b>PnL Series</b> reflects realized, unrealized, or total portfolio performance
                    depending on the selected metric.
                </li>
                <li>
                    <b>Open Positions</b> highlights changes in portfolio structure, indicating
                    periods of risk build-up, de-risking, or consolidation.
                </li>
            </ul>

            <div style="opacity:0.9;">
                Together, these trends help explain <i>how</i> returns are generated,
                not just <i>what</i> the returns are.
            </div>
        </div>
        """,
        height=180,
    )




    st.line_chart(
        ts_plot.set_index("date")[metric_mode].fillna(0),
        height=260,
    )

    st.line_chart(
        ts_plot.set_index("date")["open_positions"].fillna(0),
        height=240,
    )

    st.markdown("### Greeks Exposure Over Time")
    gcols = [c for c in ["delta_sum", "gamma_sum", "theta_sum", "vega_sum"] if c in ts_plot.columns]
    if gcols:
        st.line_chart(ts_plot.set_index("date")[gcols].fillna(0), height=260)

    st.divider()

    
    # ----------------------------
    # Filter snapshots for drilldown
    # ----------------------------
    snapshots_show = snapshots.copy()

    if min_sel is not None and max_sel is not None:
        start_day = pd.Timestamp(min_sel).date()
        end_day   = pd.Timestamp(max_sel).date()
        if start_day > end_day:
            start_day, end_day = end_day, start_day

        snap_dt = pd.to_datetime(snapshots_show["date"], errors="coerce").dt.date
        snapshots_show = snapshots_show[snap_dt.between(start_day, end_day)]

    # Optional quick filter by date
    dates = snapshots_show["date"].astype(str).tolist()
    default_sel = dates[:10]
    sel_dates = st.multiselect("Filter by date (UTC)", dates, default=default_sel)

    # ----------------------------
    # Daily Drilldown
    # ----------------------------
    st.markdown("## Daily Drilldown")

    for _, row in snapshots_show.iterrows():
        day = str(row["date"])
        if sel_dates and day not in sel_dates:
            continue

        updated = str(row.get("updated_at") or "-")
        df = records_to_df(row.get("payload_json", ""))

        with st.expander(f"{day}  • Updated: {updated}", expanded=False):
            if df.empty:
                st.info("No positions recorded for this day.")
                continue

            df = coerce_numeric(df, [
                "pnl_usd_total", "avg_price_usd", "mark_usd", "index_price",
                "total_profit_loss", "floating_profit_loss", "realized_profit_loss",
                "qty", "size", "DTE", "strike", "pnl_btc_total_deribit",
                "mark_price_btc", "avg_price_btc"
            ])

            kpis = compute_pnl_kpis(df)
            c1, c2, c3, c4, c5, c6 = st.columns(6)
            c1.metric("Open Positions", len(df))
            c2.metric("PnL Total (USD)", f"{kpis['pnl_total_usd']:,.2f}")
            c3.metric("PnL Floating (USD)", f"{kpis['pnl_float_usd']:,.2f}")
            c4.metric("PnL Realized (USD)", f"{kpis['pnl_real_usd']:,.2f}")
            c5.metric("Total Contracts", f"{kpis['total_qty']:,.0f}")
            c6.metric("Total PnL (BTC)", f"{kpis['total_pnl_btc']:,.4f}")

            default_cols = [c for c in [
                "instrument_name", "side", "qty", "DTE", "strike",
                "index_price", "mark_price_btc", "mark_usd",
                "avg_price_btc", "avg_price_usd", "pnl_btc_total_deribit"
            ] if c in df.columns] or list(df.columns)

            st.dataframe(df[default_cols], width="stretch", hide_index=True)

        st.divider()