from multi_agent_system.config import DB_PATH
import sqlite3
import json

# Connect
with sqlite3.connect(DB_PATH) as conn:
    cursor = conn.cursor()

    # Get latest row by date (or updated_at if you prefer)
    cursor.execute("""
        SELECT date, payload_json, updated_at
        FROM vol_metrics_snapshots
        ORDER BY date DESC
        LIMIT 1
    """)

    row = cursor.fetchone()

    if row:
        date, payload_json, updated_at = row

        print(f"\nLatest Snapshot")
        print(f"Date: {date}")
        print(f"Updated At: {updated_at}")
        print("\nPayload JSON:\n")

        # Pretty print JSON
        parsed = json.loads(payload_json)
        print(json.dumps(parsed, indent=4, ensure_ascii=False))

    else:
        print("No rows found.")