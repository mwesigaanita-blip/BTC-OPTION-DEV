# DB_mangment/delete_table.py

import os
import sqlite3
import pandas as pd


def list_tables_and_sizes(conn: sqlite3.Connection) -> list[str]:
    cursor = conn.cursor()
    cursor.execute(
        "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name;"
    )
    tables = [row[0] for row in cursor.fetchall()]

    if not tables:
        print("\u26a0\ufe0f No tables found in the database.")
        return []

    print("\n\U0001f4cb Available Tables:\n")
    for i, table in enumerate(tables, start=1):
        try:
            count = pd.read_sql_query(
                f"SELECT COUNT(*) AS c FROM [{table}]", conn
            ).iloc[0]["c"]
            print(f"{i}. {table} \u2014 \U0001f9fe {count} rows")
        except Exception as e:
            print(f"{i}. {table} \u2014 \u26a0\ufe0f Error reading: {e}")

    return tables


def delete_table(conn: sqlite3.Connection, table_name: str) -> None:
    cursor = conn.cursor()
    cursor.execute(f"DROP TABLE IF EXISTS [{table_name}];")
    conn.commit()
    print(f"\n\u2705 Table `{table_name}` has been deleted.")


def main(db_path: str | None = None) -> None:
    """Interactive table-deletion. If db_path is None, falls back to the
    main config's DB_PATH - but the interactive tool in db_tools.py passes
    an explicit path that was chosen by the user."""
    if db_path is None:
        from multi_agent_system.config import DB_PATH as _DEFAULT
        db_path = str(_DEFAULT)

    if not os.path.exists(db_path):
        print(f"\u274c Database not found at: {db_path}")
        return

    conn = sqlite3.connect(db_path)
    try:
        tables = list_tables_and_sizes(conn)
        if not tables:
            return

        choice = input(
            "\nEnter the exact table name you want to delete: "
        ).strip()
        if choice not in tables:
            print("\u274c Table not found. Please check the name and try again.")
            return

        confirm = input(
            f"\u26a0\ufe0f Really delete `{choice}`? This is irreversible! (yes/no): "
        ).strip().lower()
        if confirm == "yes":
            delete_table(conn, choice)
        else:
            print("\u274e Table deletion canceled.")
    finally:
        conn.close()


if __name__ == "__main__":
    main()
