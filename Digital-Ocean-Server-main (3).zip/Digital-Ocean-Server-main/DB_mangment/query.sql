SELECT datetime(min(ts_utc),'unixepoch') AS min_ts,
       datetime(max(ts_utc),'unixepoch') AS max_ts,
       count(*) AS n
FROM hedge_engine_spot_ticks;