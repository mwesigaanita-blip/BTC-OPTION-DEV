# tools/sqlite_query.py
from __future__ import annotations

import argparse
import csv
import json
import os
import sqlite3
import sys
from typing import Any, Dict, List, Optional, Sequence, Tuple


def _connect(db_path: str) -> sqlite3.Connection:
    con = sqlite3.connect(db_path)
    con.row_factory = sqlite3.Row
    return con


def _read_sql_from_file(path: str) -> str:
    with open(path, "r", encoding="utf-8") as f:
        return f.read()


def _format_table(rows: List[sqlite3.Row], max_rows: int = 50) -> str:
    if not rows:
        return "(no rows)"

    cols = rows[0].keys()
    display_rows = rows[:max_rows]

    # compute widths
    widths = {c: len(str(c)) for c in cols}
    for r in display_rows:
        for c in cols:
            widths[c] = max(widths[c], len(str(r[c])) if r[c] is not None else 4)

    # build table
    def fmt_row(values: Sequence[Any]) -> str:
        parts = []
        for c, v in zip(cols, values):
            s = "None" if v is None else str(v)
            parts.append(s.ljust(widths[c]))
        return " | ".join(parts)

    header = fmt_row(cols)
    sep = "-+-".join("-" * widths[c] for c in cols)
    lines = [header, sep]
    for r in display_rows:
        lines.append(fmt_row([r[c] for c in cols]))

    if len(rows) > max_rows:
        lines.append(f"... ({len(rows) - max_rows} more rows)")
    return "\n".join(lines)


def _rows_to_dicts(rows: List[sqlite3.Row]) -> List[Dict[str, Any]]:
    return [{k: row[k] for k in row.keys()} for row in rows]


def run_query(
    *,
    db_path: str,
    sql: str,
    params: Optional[Tuple[Any, ...]] = None,
    max_rows: int = 50,
    out_json: Optional[str] = None,
    out_csv: Optional[str] = None,
) -> int:
    con = _connect(db_path)
    try:
        cur = con.execute(sql, params or ())
        rows = cur.fetchall()

        print(f"[OK] rows={len(rows)}")
        print(_format_table(rows, max_rows=max_rows))

        if out_json:
            os.makedirs(os.path.dirname(out_json) or ".", exist_ok=True)
            with open(out_json, "w", encoding="utf-8") as f:
                json.dump(_rows_to_dicts(rows), f, indent=2, ensure_ascii=False, default=str)
            print(f"[OK] wrote JSON: {out_json}")

        if out_csv:
            os.makedirs(os.path.dirname(out_csv) or ".", exist_ok=True)
            dict_rows = _rows_to_dicts(rows)
            with open(out_csv, "w", newline="", encoding="utf-8") as f:
                if dict_rows:
                    w = csv.DictWriter(f, fieldnames=list(dict_rows[0].keys()))
                    w.writeheader()
                    w.writerows(dict_rows)
                else:
                    f.write("")
            print(f"[OK] wrote CSV: {out_csv}")

        return 0
    finally:
        con.close()


def main() -> int:
    ap = argparse.ArgumentParser(description="Run a SQL query against a SQLite DB and print the output.")
    ap.add_argument("--db", required=True, help="Path to SQLite database (e.g., data/btc_trading.sqlite)")
    group = ap.add_mutually_exclusive_group(required=True)
    group.add_argument("--sql", help="SQL query as a string (wrap in quotes)")
    group.add_argument("--sql-file", help="Path to a .sql file containing the query")

    ap.add_argument("--max-rows", type=int, default=50, help="Max rows to print")
    ap.add_argument("--json-out", help="Optional path to write results as JSON")
    ap.add_argument("--csv-out", help="Optional path to write results as CSV")

    args = ap.parse_args()

    sql = args.sql if args.sql else _read_sql_from_file(args.sql_file)
    return run_query(
        db_path=args.db,
        sql=sql,
        max_rows=int(args.max_rows),
        out_json=args.json_out,
        out_csv=args.csv_out,
    )


if __name__ == "__main__":
    raise SystemExit(main())


# python -m DB_mangment.sqlite_query --db data/btc_trading.sqlite --sql-file DB_mangment/query.sql