import sqlite3
import json
import sys
from typing import Any, Dict, List, Set, Tuple
import pandas as pd


def _flatten_json(obj: Any, parent_key: str = "", sep: str = ".") -> Dict[str, Any]:
    """
    Flatten nested JSON (dicts + lists) into dot-notation keys.
    Lists are indexed numerically.
    """
    items: Dict[str, Any] = {}

    if isinstance(obj, dict):
        for k, v in obj.items():
            new_key = f"{parent_key}{sep}{k}" if parent_key else k
            items.update(_flatten_json(v, new_key, sep))

    elif isinstance(obj, list):
        for i, v in enumerate(obj):
            new_key = f"{parent_key}{sep}{i}" if parent_key else str(i)
            items.update(_flatten_json(v, new_key, sep))

    else:
        items[parent_key] = obj

    return items


def inspect_positions_snapshots(
    db_path: str,
    *,
    flatten: bool = True,
    max_examples_per_key: int = 5,
) -> Tuple[Set[str], Dict[str, List[Any]], pd.DataFrame]:
    """
    Inspect all JSON keys and values in positions_snapshots.

    Parameters
    ----------
    db_path : str
        Path to SQLite database.
    flatten : bool
        Flatten nested JSON keys (recommended).
    max_examples_per_key : int
        Max number of example values to store per key.

    Returns
    -------
    all_keys : set[str]
        All discovered JSON keys.
    key_examples : dict[str, list[Any]]
        Example values per key.
    flat_df : pd.DataFrame
        Flattened DataFrame (one row per position).
    """

    conn = sqlite3.connect(db_path)
    try:
        df = pd.read_sql_query(
            "SELECT date, payload_json, updated_at FROM positions_snapshots",
            conn,
        )
    finally:
        conn.close()

    all_keys: Set[str] = set()
    key_examples: Dict[str, List[Any]] = {}
    rows: List[Dict[str, Any]] = []

    for _, r in df.iterrows():
        snapshot_date = r["date"]
        updated_at = r["updated_at"]

        try:
            payload = json.loads(r["payload_json"])
        except Exception as e:
            print(f"[WARN] Failed to parse JSON for date={snapshot_date}: {e}")
            continue

        if not isinstance(payload, list):
            payload = [payload]

        for position in payload:
            flat = _flatten_json(position) if flatten else position

            flat["_snapshot_date"] = snapshot_date
            flat["_updated_at"] = updated_at

            rows.append(flat)

            for k, v in flat.items():
                all_keys.add(k)
                if k not in key_examples:
                    key_examples[k] = []
                if len(key_examples[k]) < max_examples_per_key:
                    key_examples[k].append(v)

    flat_df = pd.DataFrame(rows)
    return all_keys, key_examples, flat_df


# ---------------------------------------------------------
# CLI ENTRY POINT
# ---------------------------------------------------------
from db_tools import DB_PATH
if __name__ == "__main__":
    keys, examples, flat_df = inspect_positions_snapshots(DB_PATH)

    print(f"\nFound {len(keys)} unique JSON keys:\n")
    for k in sorted(keys):
        print(f"{k}: {examples.get(k)}")

    print(f"\nFlattened DataFrame shape: {flat_df.shape}")
