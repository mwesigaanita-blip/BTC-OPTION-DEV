# DB_mangment/db_tools.py
"""Interactive SQLite management CLI.

Run with:
    python -m DB_mangment.db_tools

Why the DB picker exists:
    There are two SQLite files in production:
      - Main trading DB:   /opt/btc_app/data/btc_trading.sqlite
      - Decision board DB: /opt/btc_app/data/decision_board.sqlite
    When this module is run on the host (outside Docker), the config
    fallback resolves to the repo-local ./data directory, which is NOT
    the real server DB. The picker below probes the known production
    paths plus env overrides so the right file is opened regardless of
    where you run the tool from.
"""

from __future__ import annotations

import os
import sqlite3
from pathlib import Path
from typing import Callable

import pandas as pd

from DB_mangment.delete_table import delete_table, list_tables_and_sizes
from DB_mangment.verify_db import verify_database


# ---------------------------------------------------------------------------
# DB discovery
# ---------------------------------------------------------------------------

_MAIN_CANDIDATES_FIXED = [
    "/opt/btc_app/data/btc_trading.sqlite",
    "/data/btc_trading.sqlite",
]
_DECISION_BOARD_CANDIDATES_FIXED = [
    "/opt/btc_app/data/decision_board.sqlite",
    "/data/decision_board.sqlite",
]


def _first_existing(paths: list[str | None]) -> str | None:
    for p in paths:
        if p and Path(p).exists():
            return str(Path(p).resolve())
    return None


def _main_candidates() -> list[str | None]:
    candidates: list[str | None] = [os.getenv("DB_PATH")]
    candidates.extend(_MAIN_CANDIDATES_FIXED)
    try:
        from multi_agent_system.config import DB_PATH as _CFG
        candidates.append(str(_CFG))
    except Exception:
        pass
    return candidates


def _decision_board_candidates() -> list[str | None]:
    candidates: list[str | None] = [os.getenv("DECISION_BOARD_DB_PATH")]
    candidates.extend(_DECISION_BOARD_CANDIDATES_FIXED)
    try:
        from decision_board.db import DB_PATH as _CFG
        candidates.append(str(_CFG))
    except Exception:
        pass
    return candidates


def resolve_main_db() -> str | None:
    return _first_existing(_main_candidates())


def resolve_decision_board_db() -> str | None:
    return _first_existing(_decision_board_candidates())


# ---------------------------------------------------------------------------
# Human-readable helpers
# ---------------------------------------------------------------------------

def _format_size(path: str) -> str:
    try:
        size: float = Path(path).stat().st_size
    except OSError:
        return "(missing)"
    for unit in ("B", "KB", "MB", "GB"):
        if size < 1024:
            return f"{size:.1f} {unit}"
        size /= 1024
    return f"{size:.1f} TB"


def _count_tables(path: str) -> int | None:
    try:
        conn = sqlite3.connect(path)
        try:
            cur = conn.execute(
                "SELECT COUNT(*) FROM sqlite_master WHERE type='table';"
            )
            return int(cur.fetchone()[0])
        finally:
            conn.close()
    except Exception:
        return None


# ---------------------------------------------------------------------------
# DB picker
# ---------------------------------------------------------------------------

def pick_database(current: str | None) -> str | None:
    main_path = resolve_main_db()
    dbb_path = resolve_decision_board_db()

    def _summary(p: str | None) -> str:
        if not p:
            return "(not found)"
        n = _count_tables(p)
        tbl = f"{n} tables" if n is not None else "unreadable"
        return f"{p}   [{_format_size(p)}, {tbl}]"

    print("\n===== Select Database =====")
    print(f"1. Main Trading DB    \u2192 {_summary(main_path)}")
    print(f"2. Decision Board DB  \u2192 {_summary(dbb_path)}")
    print("3. Enter a custom path")
    print(f"0. Keep current       \u2192 {current or '(none)'}")

    choice = input("Choice (0-3): ").strip()

    if choice == "1":
        if main_path is None:
            print("\u274c Main DB not found on disk \u2014 use option 3 for a custom path.")
            return current
        return main_path
    if choice == "2":
        if dbb_path is None:
            print("\u274c Decision Board DB not found on disk \u2014 use option 3 for a custom path.")
            return current
        return dbb_path
    if choice == "3":
        raw = input("Absolute path to .sqlite file: ").strip()
        if not raw:
            return current
        resolved = str(Path(raw).expanduser().resolve())
        if not Path(resolved).exists():
            print(f"\u26a0\ufe0f File does not exist: {resolved}")
            confirm = input("Use it anyway? (yes/no): ").strip().lower()
            if confirm != "yes":
                return current
        return resolved
    return current


# ---------------------------------------------------------------------------
# Actions
# ---------------------------------------------------------------------------

def _ensure_exists(db_path: str | None) -> bool:
    if not db_path:
        print("\u274c No database selected. Use option 5 to pick one.")
        return False
    if not os.path.exists(db_path):
        print(f"\u274c Database file not found at: {db_path}")
        return False
    return True


def action_list_tables(db_path: str) -> None:
    verify_database(db_path)


def action_delete_table(db_path: str) -> None:
    conn = sqlite3.connect(db_path)
    try:
        tables = list_tables_and_sizes(conn)
        if not tables:
            return
        choice = input(
            "\nEnter the exact table name you want to delete: "
        ).strip()
        if choice not in tables:
            print("\u274c Table not found.")
            return
        confirm = input(
            f"\u26a0\ufe0f Really delete `{choice}`? (yes/no): "
        ).strip().lower()
        if confirm == "yes":
            delete_table(conn, choice)
        else:
            print("\u274e Deletion cancelled.")
    finally:
        conn.close()


def action_view_table(db_path: str) -> None:
    conn = sqlite3.connect(db_path)
    try:
        tables = pd.read_sql_query(
            "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name;",
            conn,
        )["name"].tolist()
        if not tables:
            print("\u274c No tables found in the database.")
            return

        print("\nAvailable tables:")
        for t in tables:
            print(f"\u2022 {t}")

        table_name = input(
            "\nEnter the exact table name to view its details: "
        ).strip()
        if table_name not in tables:
            print("\u274c Table not found.")
            return

        df = pd.read_sql_query(f"SELECT * FROM [{table_name}]", conn)

        print(f"\n===== Info of `{table_name}` =====")
        df.info()
        print(f"\n===== Columns of `{table_name}` =====")
        print(df.columns.tolist())
        print(f"\n===== Head of `{table_name}` =====")
        print(df.head())
        print(f"\n===== Tail of `{table_name}` =====")
        print(df.tail())
    finally:
        conn.close()


def action_run_sql(db_path: str) -> None:
    print(
        "\nEnter a read-only SQL query (SELECT / PRAGMA / EXPLAIN / WITH)."
    )
    print("Use option 2 if you want to drop a table.")
    query = input("SQL> ").strip()
    if not query:
        return

    first_word = query.split(maxsplit=1)[0].lower()
    if first_word not in ("select", "pragma", "explain", "with"):
        print(
            "\u274c Only SELECT / PRAGMA / EXPLAIN / WITH queries are allowed here."
        )
        return

    conn = sqlite3.connect(db_path)
    try:
        df = pd.read_sql_query(query, conn)
        print()
        print(df.to_string(index=False, max_rows=50))
        print(f"\n{len(df)} rows returned.")
    except Exception as e:
        print(f"\u26a0\ufe0f Query failed: {e}")
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Menu loop
# ---------------------------------------------------------------------------

def _print_header(db_path: str | None) -> None:
    print("\n" + "=" * 66)
    print(f" Current DB: {db_path or '(none \u2014 choose one with option 5)'}")
    if db_path and os.path.exists(db_path):
        n = _count_tables(db_path)
        tbl = f"{n} tables" if n is not None else "?"
        print(f" Size:       {_format_size(db_path)}   |   Tables: {tbl}")
    print("=" * 66)


def show_menu(db_path: str | None) -> str:
    _print_header(db_path)
    print("1. List tables and preview content")
    print("2. Delete a table")
    print("3. View a specific table's details")
    print("4. Run a read-only SQL query")
    print("5. Switch database")
    print("6. Exit")
    return input("Enter your choice (1-6): ").strip()


_ACTIONS: dict[str, Callable[[str], None]] = {
    "1": action_list_tables,
    "2": action_delete_table,
    "3": action_view_table,
    "4": action_run_sql,
}


def main() -> None:
    db_path = resolve_main_db() or resolve_decision_board_db()
    if db_path is None:
        print("\u26a0\ufe0f No known DB file found automatically.")
        db_path = pick_database(None)

    while True:
        choice = show_menu(db_path)

        if choice in _ACTIONS:
            if _ensure_exists(db_path):
                _ACTIONS[choice](db_path)  # type: ignore[arg-type]
        elif choice == "5":
            db_path = pick_database(db_path)
        elif choice == "6":
            print("\U0001f44b Exiting.")
            break
        else:
            print("\u274c Invalid choice. Please try again.")


if __name__ == "__main__":
    main()
