# DB_mangment/verify_db.py

import os
import sqlite3
import pandas as pd


def verify_database(db_path: str | None = None) -> None:
    """List every table in a SQLite DB and preview the first rows.

    Args:
        db_path: Absolute path to the .sqlite file. If None, falls back to
            multi_agent_system.config.DB_PATH - but callers should pass an
            explicit path, because the fallback resolves relative to the
            repo on the host, which may not point at the real production DB.
    """
    if db_path is None:
        from multi_agent_system.config import DB_PATH as _DEFAULT
        db_path = str(_DEFAULT)

    if not os.path.exists(db_path):
        print(f"\u274c Database file not found at: {db_path}")
        return

    conn = sqlite3.connect(db_path)
    try:
        cursor = conn.cursor()
        cursor.execute(
            "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name;"
        )
        tables = [row[0] for row in cursor.fetchall()]

        if not tables:
            print("\u274c No tables found in the database.")
            return

        print(f"\n\U0001f4cb Found {len(tables)} tables in {db_path}:\n")
        for t in tables:
            print(f" - {t}")

        print("\n\U0001f4ca Displaying first few rows from each table:\n")

        for table_name in tables:
            print(f"\n--- Table: `{table_name}` ---")
            try:
                df = pd.read_sql_query(
                    f"SELECT * FROM [{table_name}] LIMIT 5", conn
                )
                count = pd.read_sql_query(
                    f"SELECT COUNT(*) AS c FROM [{table_name}]", conn
                ).iloc[0]["c"]
                print(df.to_string(index=False))
                print(f"\U0001f9fe Total rows: {count}")
            except Exception as e:
                print(f"\u26a0\ufe0f Failed to read table '{table_name}': {e}")
    finally:
        conn.close()


if __name__ == "__main__":
    verify_database()
