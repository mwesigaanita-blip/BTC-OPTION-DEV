#!/usr/bin/env python3
"""
One-time schema migration for `macro_daily` table to v2 layout.

- Creates a backup of existing `macro_daily` as `macro_daily_backup_<UTCstamp>` if it exists.
- Drops and recreates `macro_daily` with the new schema (v2).
- (Optional) Creates a backward-compat VIEW `macro_daily_compat_v1`
  to emulate a v1-style daily score (day_utc, score, ts_utc) computed from v2 rows.

Usage:
  python migrate_macro_daily_v2.py --db btc_trading.sqlite --no-backcompat-view
  python migrate_macro_daily_v2.py --db /path/to/db.sqlite --dry-run

Defaults:
  --db defaults to env MACRO_SQLITE_DB_PATH or ./btc_trading.sqlite

New schema (v2):
  CREATE TABLE macro_daily (
      asof_utc TEXT PRIMARY KEY,
      sentence TEXT NOT NULL,
      score_now REAL NOT NULL,
      score_7d REAL NOT NULL,
      score_30d REAL NOT NULL,
      model_provider TEXT,
      model_id TEXT,
      features_json TEXT,
      meta_json TEXT
  )
"""
import os
import sys
import sqlite3
import argparse
from datetime import datetime, timezone

NEW_SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS macro_daily (
    asof_utc TEXT PRIMARY KEY,
    sentence TEXT NOT NULL,
    score_now REAL NOT NULL,
    score_7d REAL NOT NULL,
    score_30d REAL NOT NULL,
    model_provider TEXT,
    model_id TEXT,
    features_json TEXT,
    meta_json TEXT
);
"""

BACKCOMPAT_VIEW_SQL = """
CREATE VIEW IF NOT EXISTS macro_daily_compat_v1 AS
SELECT
    substr(asof_utc, 1, 10) AS day_utc,  -- YYYY-MM-DD from ISO ts
    score_now              AS score,     -- use 'now' as the legacy single score
    asof_utc               AS ts_utc     -- keep full timestamp
FROM macro_daily;
"""

def table_exists(conn, name: str) -> bool:
    cur = conn.execute(
        "SELECT name FROM sqlite_master WHERE type IN ('table','view') AND name=?;",
        (name,),
    )
    return cur.fetchone() is not None

def backup_table(conn, src: str, dry: bool = False) -> str:
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    backup = f"{src}_backup_{stamp}"
    if dry:
        print(f"[DRY-RUN] Would create backup table: {backup} AS SELECT * FROM {src}")
        return backup
    conn.execute(f"CREATE TABLE {backup} AS SELECT * FROM {src};")
    print(f"[OK] Backup created: {backup}")
    return backup

def drop_table(conn, name: str, dry: bool = False):
    if dry:
        print(f"[DRY-RUN] Would DROP TABLE IF EXISTS {name}")
        return
    conn.execute(f"DROP TABLE IF EXISTS {name};")
    print(f"[OK] Dropped table (if existed): {name}")

def create_new_schema(conn, dry: bool = False):
    if dry:
        print("[DRY-RUN] Would create new macro_daily schema (v2)")
        print(NEW_SCHEMA_SQL)
        return
    conn.executescript(NEW_SCHEMA_SQL)
    print("[OK] Created new macro_daily schema (v2)")

def create_backcompat_view(conn, dry: bool = False):
    if dry:
        print("[DRY-RUN] Would create back-compat VIEW macro_daily_compat_v1")
        print(BACKCOMPAT_VIEW_SQL)
        return
    conn.executescript(BACKCOMPAT_VIEW_SQL)
    print("[OK] Created VIEW macro_daily_compat_v1 (v1-style projection)")
from db_tools import DB_PATH
def main():
    db_path = DB_PATH
    conn = sqlite3.connect(db_path)
    try:
        conn.execute("PRAGMA foreign_keys = OFF;")

        # Backup if old table exists
        if table_exists(conn, "macro_daily"):
            backup_table(conn, "macro_daily", dry=False)
        else:
            print("[INFO] No existing macro_daily table found; skipping backup.")

        # Drop table and recreate new schema
        drop_table(conn, "macro_daily", dry=False)
        create_new_schema(conn, dry=False)

        # Always create the back-compat view
        create_backcompat_view(conn, dry=False)

        conn.commit()
        print(f"[DONE] Migration completed on DB: {db_path}")
    finally:
        conn.close()

if __name__ == "__main__":
    # main()
    import sqlite3, os, re
    from db_tools import DB_PATH  # or hardcode path

    conn = sqlite3.connect(DB_PATH)
    try:
        conn.execute("PRAGMA foreign_keys = OFF;")
        # find latest backup table
        cur = conn.execute("SELECT name FROM sqlite_master WHERE type='table' AND name LIKE 'macro_daily_backup_%';")
        backups = [r[0] for r in cur.fetchall()]
        if not backups:
            raise SystemExit("No macro_daily_backup_* table found.")
        backups.sort(reverse=True)  # latest first
        src = backups[0]
        print(f"Using backup table: {src}")

        # insert-migrate
        conn.execute("""
        INSERT INTO macro_daily (
        asof_utc, sentence, score_now, score_7d, score_30d,
        model_provider, model_id, features_json, meta_json
        )
        SELECT
        ts_utc, '', score, score, score, NULL, NULL, NULL, NULL
        FROM %s
        """ % src)
        conn.commit()
        print("Backfill completed.")
    finally:
        conn.close()

