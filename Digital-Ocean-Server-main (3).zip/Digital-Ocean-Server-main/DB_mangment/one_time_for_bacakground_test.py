#!/usr/bin/env python3
"""
reset_scheduler_tables.py

Deletes the existing rows for the models scheduler so you can test from scratch.

What you edit:
- Set DB_PATH to your sqlite file path.

What it does:
- DELETE FROM scheduler_state   WHERE key='models'
- DELETE FROM scheduler_config  WHERE key='models'
- Re-inserts a default scheduler_config row (disabled, 12h) so the system boots cleanly.

Run:
  python reset_scheduler_tables.py
"""

import sqlite3
from datetime import datetime, timezone
from db_tools import DB_PATH
# =========================
# EDIT THIS ONLY
# =========================
DB_PATH = DB_PATH 


KEY = "models"
DEFAULT_ENABLED = 0
DEFAULT_INTERVAL_SECONDS = 12 * 60 * 60  # 43200


def main() -> None:
    now_utc = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

    con = sqlite3.connect(DB_PATH, timeout=30)
    try:
        cur = con.cursor()

        # Safety: ensure tables exist (no-op if they already do)
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS scheduler_config (
                key TEXT PRIMARY KEY,
                enabled INTEGER NOT NULL,
                interval_seconds INTEGER NOT NULL,
                updated_at_utc TEXT NOT NULL
            )
            """
        )
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS scheduler_state (
                key TEXT PRIMARY KEY,
                last_run_ts INTEGER NOT NULL
            )
            """
        )

        # Delete current rows (reset state)
        cur.execute("BEGIN IMMEDIATE")
        cur.execute("DELETE FROM scheduler_state WHERE key=?", (KEY,))
        cur.execute("DELETE FROM scheduler_config WHERE key=?", (KEY,))

        # Reinsert defaults (so system starts from clean baseline)
        cur.execute(
            """
            INSERT INTO scheduler_config(key, enabled, interval_seconds, updated_at_utc)
            VALUES (?, ?, ?, ?)
            """,
            (KEY, DEFAULT_ENABLED, DEFAULT_INTERVAL_SECONDS, now_utc),
        )
        con.commit()

        # Print confirmation
        cur.execute("SELECT key, enabled, interval_seconds, updated_at_utc FROM scheduler_config WHERE key=?", (KEY,))
        cfg = cur.fetchone()

        cur.execute("SELECT key, last_run_ts FROM scheduler_state WHERE key=?", (KEY,))
        st = cur.fetchone()

        print("✅ Reset complete.")
        print("scheduler_config:", cfg)
        print("scheduler_state :", st)  # should be None after reset

    finally:
        con.close()


if __name__ == "__main__":
    main()
