#!/usr/bin/env python3
"""
rename_macro_daily_safe.py

Safely rename 'macro_daily_rebuilt' -> 'macro_daily' even if views (e.g.
'macro_daily_compat_v1') reference 'macro_daily'.

Steps:
- BEGIN IMMEDIATE
- Find & cache view SQL that reference 'macro_daily'
- DROP those views
- If 'macro_daily' exists, rename to 'macro_daily_old_<ts>'
- RENAME 'macro_daily_rebuilt' TO 'macro_daily'
- Recreate cached views
- Recreate a non-unique index on asof_utc
- COMMIT

On any error: ROLLBACK; nothing destructive is committed.
"""

import sqlite3
from datetime import datetime, timezone
import sys
from typing import Optional, Dict
from multi_agent_system.config import DB_PATH
# Change or pass as CLI arg
DEFAULT_DB_PATH = DB_PATH

def _now_tag() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")

def _table_exists(cur: sqlite3.Cursor, name: str) -> bool:
    cur.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?;", (name,))
    return cur.fetchone() is not None

def _view_sql_by_name(cur: sqlite3.Cursor, name: str) -> Optional[str]:
    cur.execute("SELECT sql FROM sqlite_master WHERE type='view' AND name=?;", (name,))
    row = cur.fetchone()
    return row[0] if row and row[0] else None

def _views_referencing_table(cur: sqlite3.Cursor, table: str) -> Dict[str, str]:
    """Return {view_name: sql} for views whose SQL mentions the table name."""
    cur.execute("SELECT name, sql FROM sqlite_master WHERE type='view' AND sql IS NOT NULL;")
    out: Dict[str, str] = {}
    needle = table.lower()
    for name, sql in cur.fetchall():
        if sql and needle in sql.lower():
            out[name] = sql
    return out

def main(db_path: Optional[str] = None):
    db_path = db_path or DEFAULT_DB_PATH
    print(f"Using DB: {db_path}")
    con = sqlite3.connect(db_path, timeout=60)
    try:
        cur = con.cursor()
        cur.execute("PRAGMA journal_mode=WAL;")
        cur.execute("PRAGMA foreign_keys=OFF;")  # avoid rename blockers

        if not _table_exists(cur, "macro_daily_rebuilt"):
            print("❌ 'macro_daily_rebuilt' not found. Nothing to rename.")
            return

        # Find any views that reference 'macro_daily'
        views = _views_referencing_table(cur, "macro_daily")
        if views:
            print("🔎 Views referencing 'macro_daily' that will be temporarily dropped:")
            for v in views:
                print(f"   - {v}")
        else:
            print("ℹ️ No views found referencing 'macro_daily'.")

        has_macro_daily = _table_exists(cur, "macro_daily")
        ts = _now_tag()

        print("🔐 Beginning transaction…")
        cur.execute("BEGIN IMMEDIATE;")

        # Drop dependent views (cache SQL first)
        for vname, vsql in views.items():
            # Double-check SQL is present
            if not vsql:
                raise RuntimeError(f"View {vname} has no SQL; aborting for safety.")
            print(f"🧹 Dropping view: {vname}")
            cur.execute(f"DROP VIEW IF EXISTS {vname};")

        # Backup existing macro_daily (optional but recommended)
        if has_macro_daily:
            old_name = f"macro_daily_old_{ts}"
            print(f"📦 Backing up existing 'macro_daily' as '{old_name}' …")
            cur.execute(f"ALTER TABLE macro_daily RENAME TO {old_name};")

        # Rename rebuilt -> macro_daily
        print("🔁 Renaming 'macro_daily_rebuilt' -> 'macro_daily' …")
        cur.execute("ALTER TABLE macro_daily_rebuilt RENAME TO macro_daily;")

        # Recreate non-unique index on asof_utc
        print("🧱 Recreating index on asof_utc …")
        cur.execute("DROP INDEX IF EXISTS idx_macro_daily_asof;")
        cur.execute("CREATE INDEX IF NOT EXISTS idx_macro_daily_asof ON macro_daily(asof_utc);")

        # Recreate views exactly as before
        for vname, vsql in views.items():
            print(f"🛠️ Recreating view: {vname}")
            cur.execute(vsql)

        con.commit()
        print("✅ Rename completed successfully.")

        # Sanity check
        cur.execute("SELECT COUNT(*) FROM macro_daily;")
        cnt = cur.fetchone()[0]
        cur.execute("SELECT asof_utc, sentence, score_now FROM macro_daily ORDER BY asof_utc DESC LIMIT 5;")
        sample = cur.fetchall()
        print(f"📊 macro_daily row count: {cnt}")
        print("🔎 Latest 5 rows:")
        for r in sample:
            print("   asof_utc=", r[0], "| score_now=", r[2])

        if has_macro_daily:
            print(f"ℹ️ Previous table kept as backup: {old_name}")

    except Exception as e:
        try:
            con.rollback()
        except Exception:
            pass
        print("❌ Error during rename:", e)
        print("⚠️ No destructive changes were committed.")
    finally:
        con.close()

if __name__ == "__main__":
    # Usage:
    #   python rename_macro_daily_safe.py
    #   python rename_macro_daily_safe.py "D:\\path\\to\\btc_trading.sqlite"
    path = sys.argv[1] if len(sys.argv) > 1 else None
    main(path)
