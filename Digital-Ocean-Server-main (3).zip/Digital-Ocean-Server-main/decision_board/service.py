from __future__ import annotations

import json
import logging
from typing import Any, Optional

from decision_board import db as db_mod
from decision_board import repository as repo
from decision_board.enums import (
    DecisionStatus,
    FinalOutcome,
    ActionType,
    Priority,
    EventType,
)
from decision_board.db import transaction, utc_now_iso

logger = logging.getLogger(__name__)

_VALID_STATUSES = {s.value for s in DecisionStatus}
_VALID_OUTCOMES = {o.value for o in FinalOutcome}
_VALID_ACTION_TYPES = {a.value for a in ActionType}
_VALID_PRIORITIES = {p.value for p in Priority}
_VALID_SIDES = {"buy", "sell"}


# ---------------------------------------------------------------------------
# Validation helpers (fail fast with clear errors)
# ---------------------------------------------------------------------------

def _validate_action_fields(
    *,
    side: Optional[str],
    quantity: Optional[float],
    price_reference: Optional[float],
) -> None:
    """Validate the optional trade-shape fields on an action.
    Unset values (None / empty string) pass through - only reject clearly
    bad values."""
    if side is not None and side != "":
        if str(side).lower() not in _VALID_SIDES:
            raise ValueError(
                f"Invalid side '{side}'. Must be one of {_VALID_SIDES}."
            )
    if quantity is not None:
        try:
            q = float(quantity)
        except (TypeError, ValueError):
            raise ValueError(f"Invalid quantity '{quantity}'. Must be a number.")
        if q <= 0:
            raise ValueError(f"Invalid quantity {q}. Must be > 0.")
    if price_reference is not None:
        try:
            p = float(price_reference)
        except (TypeError, ValueError):
            raise ValueError(
                f"Invalid price_reference '{price_reference}'. Must be a number."
            )
        if p < 0:
            raise ValueError(
                f"Invalid price_reference {p}. Must be >= 0."
            )


# ---------------------------------------------------------------------------
# DB init
# ---------------------------------------------------------------------------

def init_db() -> None:
    db_mod.ensure_tables()


# ---------------------------------------------------------------------------
# Editable guard
# ---------------------------------------------------------------------------

def assert_editable(decision_id: int) -> dict:
    dec = repo.get_decision(decision_id)
    if dec is None:
        raise ValueError(f"Decision {decision_id} not found.")
    if dec["locked_flag"] == 1:
        raise ValueError(
            f"Decision {decision_id} is finalized and locked for editing."
        )
    return dec


# ---------------------------------------------------------------------------
# Decisions
# ---------------------------------------------------------------------------

def create_decision(
    *,
    title: str,
    description: str = "",
    created_by: str,
    priority: str = "medium",
    actions: list[dict] | None = None,
) -> dict:
    """Create a decision + its initial actions + create_decision event
    atomically. If any step fails, the whole operation rolls back."""
    if not title or not title.strip():
        raise ValueError("Decision title must not be empty.")
    if priority not in _VALID_PRIORITIES:
        raise ValueError(f"Invalid priority '{priority}'. Must be one of {_VALID_PRIORITIES}.")

    # Pre-validate all actions upfront so we don't insert the decision only
    # to discover a bad action halfway through.
    for act in (actions or []):
        at = act.get("action_type", "note")
        if at not in _VALID_ACTION_TYPES:
            raise ValueError(f"Invalid action_type '{at}'.")
        _validate_action_fields(
            side=act.get("side"),
            quantity=act.get("quantity"),
            price_reference=act.get("price_reference"),
        )

    with transaction() as conn:
        dec = repo.insert_decision(
            title=title.strip(),
            description=description.strip(),
            created_by=created_by,
            priority=priority,
            conn=conn,
        )
        repo.insert_event(
            decision_id=dec["id"],
            event_type=EventType.CREATE_DECISION.value,
            actor=created_by,
            payload={"title": dec["title"], "priority": priority},
            conn=conn,
        )
        if actions:
            for i, act in enumerate(actions):
                act_row = repo.insert_action(
                    decision_id=dec["id"],
                    action_type=act.get("action_type", "note"),
                    reason_text=(act.get("reason_text") or "").strip(),
                    instrument_name=act.get("instrument_name"),
                    side=act.get("side"),
                    quantity=act.get("quantity"),
                    price_reference=act.get("price_reference"),
                    sort_order=act.get("sort_order", i),
                    conn=conn,
                )
                repo.insert_event(
                    decision_id=dec["id"],
                    event_type=EventType.ADD_ACTION.value,
                    actor=created_by,
                    payload={
                        "action_id": act_row["id"],
                        "action_type": act_row["action_type"],
                    },
                    conn=conn,
                )

    logger.info("Decision #%d created by %s: %s", dec["id"], created_by, dec["title"])
    return dec


def update_decision(
    *,
    decision_id: int,
    actor: str,
    **fields: Any,
) -> dict:
    dec = assert_editable(decision_id)

    updatable = {"title", "description", "priority"}
    to_update = {k: v for k, v in fields.items() if k in updatable}
    if not to_update:
        raise ValueError("No valid updatable fields provided.")

    if "priority" in to_update and to_update["priority"] not in _VALID_PRIORITIES:
        raise ValueError(f"Invalid priority '{to_update['priority']}'.")
    if "title" in to_update:
        if not to_update["title"] or not to_update["title"].strip():
            raise ValueError("Title must not be empty.")
        to_update["title"] = to_update["title"].strip()

    old_vals = {k: dec.get(k) for k in to_update}
    result = repo.update_decision(decision_id, **to_update)

    repo.insert_event(
        decision_id=decision_id,
        event_type=EventType.EDIT_DECISION.value,
        actor=actor,
        payload={"old": old_vals, "new": to_update},
    )

    logger.info("Decision #%d updated by %s: %s", decision_id, actor, list(to_update.keys()))
    return result


def get_decision(decision_id: int) -> dict | None:
    return repo.get_decision(decision_id)


def delete_decision(*, decision_id: int, actor: str) -> None:
    """Permanently remove a decision and all of its actions, comments, and
    events. Works on finalized decisions too - the lock prevents edits, not
    discarding the idea.

    A DELETE_DECISION audit event is written to a dedicated 'tombstones'
    channel (same decision_event_log table) BEFORE the parent row is
    deleted, so the trail survives the cascade. The minimal metadata
    captured: title, status, priority, final_outcome, locked_flag,
    created_by.
    """
    dec = repo.get_decision(decision_id)
    if dec is None:
        raise ValueError(f"Decision {decision_id} not found.")

    metadata = {
        "decision_id": decision_id,
        "title": dec.get("title"),
        "status": dec.get("status"),
        "priority": dec.get("priority"),
        "final_outcome": dec.get("final_outcome"),
        "locked_flag": bool(dec.get("locked_flag")),
        "created_by": dec.get("created_by"),
    }

    with transaction() as conn:
        # 1) Log BEFORE deletion so the row still exists for FK purposes
        repo.insert_event(
            decision_id=decision_id,
            event_type=EventType.DELETE_DECISION.value,
            actor=actor,
            payload=metadata,
            conn=conn,
        )
        # 2) Cascade-delete everything belonging to this decision, including
        #    the event we just wrote - this is intentional: tombstone metadata
        #    is also captured in logger.info below for out-of-band retention
        repo.delete_decision(decision_id, conn=conn)

    logger.info(
        "Decision #%d deleted by %s | tombstone=%s",
        decision_id, actor, json.dumps(metadata, default=str),
    )


def list_decisions(
    *,
    status: str | None = None,
    priority: str | None = None,
    created_by: str | None = None,
    final_outcome: str | None = None,
    search: str | None = None,
    sort: str = "newest",
    limit: int = 200,
    offset: int = 0,
) -> list[dict]:
    return repo.list_decisions(
        status=status,
        priority=priority,
        created_by=created_by,
        final_outcome=final_outcome,
        search=search,
        sort=sort,
        limit=limit,
        offset=offset,
    )


# ---------------------------------------------------------------------------
# Status movement
# ---------------------------------------------------------------------------

def move_decision_status(
    *,
    decision_id: int,
    new_status: str,
    actor: str,
) -> dict:
    dec = assert_editable(decision_id)

    if new_status not in _VALID_STATUSES:
        raise ValueError(f"Invalid status '{new_status}'. Must be one of {_VALID_STATUSES}.")
    if new_status == DecisionStatus.DONE.value:
        raise ValueError(
            "Cannot move directly to 'done'. Use finalize_decision() instead."
        )

    old_status = dec["status"]
    if old_status == new_status:
        return dec

    result = repo.update_decision(decision_id, status=new_status)

    repo.insert_event(
        decision_id=decision_id,
        event_type=EventType.MOVE_STATUS.value,
        actor=actor,
        payload={"from": old_status, "to": new_status},
    )

    logger.info(
        "Decision #%d moved %s -> %s by %s",
        decision_id, old_status, new_status, actor,
    )
    return result


# ---------------------------------------------------------------------------
# Finalization
# ---------------------------------------------------------------------------

def finalize_decision(
    *,
    decision_id: int,
    final_outcome: str,
    final_summary_reason: str,
    actor: str,
) -> dict:
    """Lock a decision with an outcome + summary reason. The status update
    and the finalize_decision event are written in ONE transaction - if the
    event insert fails, the lock is rolled back."""
    dec = assert_editable(decision_id)

    if final_outcome not in _VALID_OUTCOMES:
        raise ValueError(
            f"Invalid final_outcome '{final_outcome}'. Must be one of {_VALID_OUTCOMES}."
        )
    if not final_summary_reason or not final_summary_reason.strip():
        raise ValueError("final_summary_reason is required when finalizing.")

    now = utc_now_iso()
    with transaction() as conn:
        conn.execute(
            "UPDATE decisions SET "
            "status = ?, final_outcome = ?, final_summary_reason = ?, "
            "locked_flag = 1, finalized_at_utc = ?, finalized_by = ?, "
            "updated_at_utc = ? "
            "WHERE id = ?",
            (
                DecisionStatus.DONE.value,
                final_outcome,
                final_summary_reason.strip(),
                now,
                actor,
                now,
                decision_id,
            ),
        )
        repo.insert_event(
            decision_id=decision_id,
            event_type=EventType.FINALIZE_DECISION.value,
            actor=actor,
            payload={
                "outcome": final_outcome,
                "reason": final_summary_reason.strip(),
            },
            conn=conn,
        )
        row = conn.execute(
            "SELECT * FROM decisions WHERE id = ?", (decision_id,)
        ).fetchone()
        result = dict(row)

    logger.info(
        "Decision #%d finalized as '%s' by %s",
        decision_id, final_outcome, actor,
    )
    return result


# ---------------------------------------------------------------------------
# Actions
# ---------------------------------------------------------------------------

def add_action(
    *,
    decision_id: int,
    action_type: str,
    reason_text: str = "",
    actor: str,
    instrument_name: str | None = None,
    side: str | None = None,
    quantity: float | None = None,
    price_reference: float | None = None,
    sort_order: int = 0,
) -> dict:
    """Insert a new action + its add_action event atomically."""
    assert_editable(decision_id)

    if action_type not in _VALID_ACTION_TYPES:
        raise ValueError(f"Invalid action_type '{action_type}'.")
    _validate_action_fields(
        side=side,
        quantity=quantity,
        price_reference=price_reference,
    )

    with transaction() as conn:
        act = repo.insert_action(
            decision_id=decision_id,
            action_type=action_type,
            reason_text=(reason_text or "").strip(),
            instrument_name=instrument_name,
            side=side,
            quantity=quantity,
            price_reference=price_reference,
            sort_order=sort_order,
            conn=conn,
        )
        repo.insert_event(
            decision_id=decision_id,
            event_type=EventType.ADD_ACTION.value,
            actor=actor,
            payload={"action_id": act["id"], "action_type": action_type},
            conn=conn,
        )

    logger.info("Action #%d added on decision #%d by %s", act["id"], decision_id, actor)
    return act


def update_action(
    *,
    action_id: int,
    actor: str,
    **fields: Any,
) -> dict:
    act = repo.get_action(action_id)
    if act is None:
        raise ValueError(f"Action {action_id} not found.")
    assert_editable(act["decision_id"])

    if "action_type" in fields and fields["action_type"] not in _VALID_ACTION_TYPES:
        raise ValueError(f"Invalid action_type '{fields['action_type']}'.")
    _validate_action_fields(
        side=fields.get("side"),
        quantity=fields.get("quantity"),
        price_reference=fields.get("price_reference"),
    )

    result = repo.update_action(action_id, **fields)

    repo.insert_event(
        decision_id=act["decision_id"],
        event_type=EventType.EDIT_ACTION.value,
        actor=actor,
        payload={"action_id": action_id, "fields": list(fields.keys())},
    )

    return result


def delete_action(
    *,
    action_id: int,
    actor: str,
) -> None:
    act = repo.get_action(action_id)
    if act is None:
        raise ValueError(f"Action {action_id} not found.")
    assert_editable(act["decision_id"])

    repo.delete_action(action_id)

    repo.insert_event(
        decision_id=act["decision_id"],
        event_type=EventType.DELETE_ACTION.value,
        actor=actor,
        payload={"action_id": action_id, "action_type": act["action_type"]},
    )


def list_actions(
    decision_id: int,
    limit: int = 50,
    offset: int = 0,
) -> list[dict]:
    return repo.list_actions(decision_id, limit=limit, offset=offset)


def count_actions(decision_id: int) -> int:
    return repo.count_actions(decision_id)


# ---------------------------------------------------------------------------
# Comments
# ---------------------------------------------------------------------------

def add_comment(
    *,
    decision_id: int,
    author: str,
    comment_text: str,
) -> dict:
    assert_editable(decision_id)

    if not comment_text or not comment_text.strip():
        raise ValueError("Comment text must not be empty.")

    cmt = repo.insert_comment(
        decision_id=decision_id,
        author=author,
        comment_text=comment_text.strip(),
    )

    repo.insert_event(
        decision_id=decision_id,
        event_type=EventType.ADD_COMMENT.value,
        actor=author,
        payload={"comment_id": cmt["id"]},
    )

    return cmt


def update_comment(
    *,
    comment_id: int,
    actor: str,
    new_text: str,
) -> dict:
    cmt = repo.get_comment(comment_id)
    if cmt is None:
        raise ValueError(f"Comment {comment_id} not found.")
    assert_editable(cmt["decision_id"])

    if not new_text or not new_text.strip():
        raise ValueError("Comment text must not be empty.")

    result = repo.update_comment(comment_id, new_text.strip())

    repo.insert_event(
        decision_id=cmt["decision_id"],
        event_type=EventType.EDIT_COMMENT.value,
        actor=actor,
        payload={"comment_id": comment_id},
    )

    return result


def delete_comment(*, comment_id: int, actor: str) -> None:
    """Soft-delete a comment and log a delete_comment event atomically.
    Idempotent: deleting an already-deleted comment is a no-op.
    Respects the locked-for-edits rule: can't delete on a finalized
    decision."""
    cmt = repo.get_comment(comment_id)
    if cmt is None:
        raise ValueError(f"Comment {comment_id} not found.")
    if int(cmt.get("deleted_flag") or 0) == 1:
        return  # already deleted - no-op, no new audit noise

    assert_editable(cmt["decision_id"])

    with transaction() as conn:
        repo.delete_comment(comment_id, conn=conn)
        repo.insert_event(
            decision_id=cmt["decision_id"],
            event_type=EventType.DELETE_COMMENT.value,
            actor=actor,
            payload={
                "comment_id": comment_id,
                "author": cmt.get("author"),
            },
            conn=conn,
        )

    logger.info(
        "Comment #%d deleted by %s on decision #%d",
        comment_id, actor, cmt["decision_id"],
    )


def list_comments(
    decision_id: int,
    limit: int = 50,
    offset: int = 0,
) -> list[dict]:
    return repo.list_comments(decision_id, limit=limit, offset=offset)


def count_comments(decision_id: int) -> int:
    return repo.count_comments(decision_id)


# ---------------------------------------------------------------------------
# Event log
# ---------------------------------------------------------------------------

def list_events(
    decision_id: int | None = None,
    event_type: str | None = None,
    limit: int = 100,
    offset: int = 0,
) -> list[dict]:
    return repo.list_events(
        decision_id=decision_id,
        event_type=event_type,
        limit=limit,
        offset=offset,
    )


def count_events(
    decision_id: int | None = None,
    event_type: str | None = None,
) -> int:
    return repo.count_events(decision_id=decision_id, event_type=event_type)


# ---------------------------------------------------------------------------
# Board helpers
# ---------------------------------------------------------------------------

def get_board_data() -> dict[str, list[dict]]:
    board: dict[str, list[dict]] = {}
    for status in DecisionStatus:
        board[status.value] = repo.list_decisions(status=status.value)
    return board


def get_metrics() -> dict:
    by_status = repo.count_by_status()
    by_outcome = repo.count_by_outcome()
    total = sum(by_status.values())
    return {
        "total": total,
        "by_status": by_status,
        "by_outcome": by_outcome,
    }


def get_decision_detail(
    decision_id: int,
    *,
    comments_limit: int = 20,
    actions_limit: int = 50,
    events_limit: int = 100,
) -> dict | None:
    """Fetch a decision with its first page of children. Counts are
    attached so the UI can render "Load more" controls without a second
    round-trip."""
    dec = repo.get_decision(decision_id)
    if dec is None:
        return None
    dec["comments"] = repo.list_comments(decision_id, limit=comments_limit, offset=0)
    dec["actions"] = repo.list_actions(decision_id, limit=actions_limit, offset=0)
    dec["events"] = repo.list_events(
        decision_id=decision_id, limit=events_limit, offset=0
    )
    dec["comments_total"] = repo.count_comments(decision_id)
    dec["actions_total"] = repo.count_actions(decision_id)
    dec["events_total"] = repo.count_events(decision_id=decision_id)
    return dec


# ---------------------------------------------------------------------------
# Debug
# ---------------------------------------------------------------------------

def export_debug_snapshot() -> dict:
    return repo.export_all()
