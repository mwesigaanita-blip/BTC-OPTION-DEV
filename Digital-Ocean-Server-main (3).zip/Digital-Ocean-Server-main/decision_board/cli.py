"""
Decision Board CLI

Usage:
    python -m decision_board.cli init-db
    python -m decision_board.cli seed-demo
    python -m decision_board.cli summary
    python -m decision_board.cli debug-dump
    python -m decision_board.cli test-create-decision
    python -m decision_board.cli test-pagination
    python -m decision_board.cli test-format-comment
"""
from __future__ import annotations

import argparse
import json
import sys

from decision_board import service as svc
from decision_board.db import DB_PATH
from decision_board.utils import format_comment


def cmd_init_db() -> int:
    svc.init_db()
    print(f"Tables created/verified at: {DB_PATH}")
    return 0


def cmd_seed_demo() -> int:
    svc.init_db()

    d1 = svc.create_decision(
        title="Buy BTC 30-Jun 100K Call",
        description="Bullish thesis for Q3. BTC momentum is strong. Consider 1-lot call spread.",
        created_by="alice",
        priority="high",
        actions=[
            {
                "action_type": "open",
                "reason_text": "Long vol play on Q3 rally expectations",
                "instrument_name": "BTC-30JUN25-100000-C",
                "side": "buy",
                "quantity": 1.0,
                "price_reference": 2800.0,
            },
        ],
    )
    svc.add_comment(decision_id=d1["id"], author="bob", comment_text="I like the thesis. What about gamma exposure?")
    svc.add_comment(decision_id=d1["id"], author="alice", comment_text="Gamma is manageable given current vol surface.")

    d2 = svc.create_decision(
        title="Reduce Short Gamma on Near-Term Expiry",
        description="We are short gamma on the weekly expiry. Consider rolling or closing.",
        created_by="bob",
        priority="critical",
        actions=[
            {
                "action_type": "close",
                "reason_text": "Close short weekly straddle to reduce gamma risk",
                "instrument_name": "BTC-WEEKLY-STRADDLE",
                "side": "buy",
                "quantity": 2.0,
            },
            {
                "action_type": "hedge",
                "reason_text": "Hedge remaining delta with perp",
                "instrument_name": "BTC-PERPETUAL",
                "side": "sell",
                "quantity": 0.3,
            },
        ],
    )
    svc.move_decision_status(decision_id=d2["id"], new_status="under_review", actor="alice")
    svc.add_comment(decision_id=d2["id"], author="charlie", comment_text="Agreed. The weekly gamma is too aggressive.")
    svc.add_comment(decision_id=d2["id"], author="alice", comment_text="Let's close the straddle first, then evaluate perp hedge.")

    d3 = svc.create_decision(
        title="Hedge Delta with BTC Perp",
        description="Portfolio delta is +0.8 BTC. Need to reduce to target range.",
        created_by="charlie",
        priority="medium",
        actions=[
            {
                "action_type": "hedge",
                "reason_text": "Sell perp to neutralize delta",
                "instrument_name": "BTC-PERPETUAL",
                "side": "sell",
                "quantity": 0.5,
                "price_reference": 97500.0,
            },
        ],
    )
    svc.add_comment(decision_id=d3["id"], author="alice", comment_text="Approved. Execute at market.")
    svc.finalize_decision(
        decision_id=d3["id"],
        final_outcome="accepted",
        final_summary_reason="Delta hedge executed. Portfolio delta reduced to +0.3 BTC within target.",
        actor="alice",
    )

    d4 = svc.create_decision(
        title="Add Vega via Long Straddle",
        description="IV is historically low. Opportunity to go long vega.",
        created_by="bob",
        priority="low",
        actions=[
            {
                "action_type": "open",
                "reason_text": "Buy straddle for vega exposure",
                "instrument_name": "BTC-30JUN25-ATM-STRADDLE",
            },
        ],
    )
    svc.add_comment(decision_id=d4["id"], author="charlie", comment_text="IV may stay low for a while. Not urgent.")
    svc.finalize_decision(
        decision_id=d4["id"],
        final_outcome="rejected",
        final_summary_reason="Team decided IV compression may continue. Revisit in 2 weeks.",
        actor="charlie",
    )

    d5 = svc.create_decision(
        title="Review ETH/BTC Spread Position",
        description="ETH/BTC ratio is at multi-year low. Informational review for potential opportunity.",
        created_by="alice",
        priority="low",
    )
    svc.add_comment(decision_id=d5["id"], author="bob", comment_text="Interesting setup but no immediate action needed.")
    svc.finalize_decision(
        decision_id=d5["id"],
        final_outcome="informational",
        final_summary_reason="Logged for future reference. No action taken.",
        actor="alice",
    )

    d6 = svc.create_decision(
        title="Adjust Collar Strike Prices",
        description="Current collar is too wide. Consider tightening the strikes.",
        created_by="charlie",
        priority="medium",
        actions=[
            {
                "action_type": "adjust",
                "reason_text": "Roll put strike up from 85K to 90K",
                "instrument_name": "BTC-30JUN25-90000-P",
            },
            {
                "action_type": "adjust",
                "reason_text": "Roll call strike down from 120K to 110K",
                "instrument_name": "BTC-30JUN25-110000-C",
            },
        ],
    )

    print(f"Seeded 6 demo decisions with actions and comments.")
    print(f"  - 2 in Ideas")
    print(f"  - 1 in Under Review")
    print(f"  - 3 in Done (accepted, rejected, informational)")
    return 0


def cmd_summary() -> int:
    svc.init_db()
    m = svc.get_metrics()
    print("=" * 50)
    print("  DECISION BOARD SUMMARY")
    print("=" * 50)
    print(f"  Total decisions:  {m['total']}")
    print()
    print("  By Status:")
    for status in ["ideas", "under_review", "done"]:
        count = m["by_status"].get(status, 0)
        print(f"    {status:<16} {count}")
    print()
    print("  By Outcome (Done only):")
    for outcome in ["accepted", "rejected", "partial", "informational"]:
        count = m["by_outcome"].get(outcome, 0)
        print(f"    {outcome:<16} {count}")
    print("=" * 50)
    return 0


def cmd_debug_dump() -> int:
    svc.init_db()
    snapshot = svc.export_debug_snapshot()
    print(json.dumps(snapshot, indent=2, default=str))
    return 0


# ---------------------------------------------------------------------------
# Test commands (for smoke-testing the upgraded pipeline end-to-end)
# ---------------------------------------------------------------------------

def cmd_test_create_decision() -> int:
    """Create a decision with 2 actions and verify all pieces exist.
    Verifies: atomic create, audit events, action validation."""
    svc.init_db()

    dec = svc.create_decision(
        title="CLI smoke-test decision",
        description="Created by test-create-decision CLI.",
        created_by="cli_tester",
        priority="medium",
        actions=[
            {
                "action_type": "open",
                "reason_text": "Smoke-test action 1",
                "instrument_name": "BTC-TEST-CALL",
                "side": "buy",
                "quantity": 1.5,
                "price_reference": 97500.0,
            },
            {
                "action_type": "hedge",
                "reason_text": "Smoke-test action 2",
                "side": "sell",
                "quantity": 0.3,
            },
        ],
    )

    detail = svc.get_decision_detail(dec["id"])
    output = {
        "decision_id": dec["id"],
        "title": dec["title"],
        "priority": dec["priority"],
        "status": dec["status"],
        "actions_total": detail["actions_total"],
        "events_total": detail["events_total"],
        "events_by_type": {
            e["event_type"]: sum(
                1 for x in detail["events"] if x["event_type"] == e["event_type"]
            )
            for e in detail["events"]
        },
    }
    print(json.dumps(output, indent=2, default=str))

    # Negative cases
    negative = {}
    try:
        svc.add_action(
            decision_id=dec["id"], action_type="open",
            actor="cli_tester", side="maybe", quantity=1,
        )
        negative["bad_side"] = "NOT_REJECTED"
    except ValueError as e:
        negative["bad_side"] = f"rejected: {e}"
    try:
        svc.add_action(
            decision_id=dec["id"], action_type="open",
            actor="cli_tester", side="buy", quantity=-5,
        )
        negative["bad_qty"] = "NOT_REJECTED"
    except ValueError as e:
        negative["bad_qty"] = f"rejected: {e}"
    try:
        svc.add_action(
            decision_id=dec["id"], action_type="open",
            actor="cli_tester", side="buy", quantity=1, price_reference=-10,
        )
        negative["bad_price"] = "NOT_REJECTED"
    except ValueError as e:
        negative["bad_price"] = f"rejected: {e}"

    print(json.dumps({"validation_negatives": negative}, indent=2))

    # Clean up the smoke-test decision
    svc.delete_decision(decision_id=dec["id"], actor="cli_tester")
    print(json.dumps({"cleanup": f"deleted decision {dec['id']}"}, indent=2))
    return 0


def cmd_test_pagination() -> int:
    """Create a decision with 35 comments, then page through them 20 at
    a time. Verifies: pagination limit+offset + counts."""
    svc.init_db()

    dec = svc.create_decision(
        title="CLI pagination test",
        created_by="cli_tester",
        priority="low",
    )

    for i in range(35):
        svc.add_comment(
            decision_id=dec["id"],
            author=f"user_{i % 3}",
            comment_text=f"Comment #{i + 1}",
        )

    page1 = svc.list_comments(dec["id"], limit=20, offset=0)
    page2 = svc.list_comments(dec["id"], limit=20, offset=20)
    total = svc.count_comments(dec["id"])

    output = {
        "decision_id": dec["id"],
        "total_comments": total,
        "page1_len": len(page1),
        "page2_len": len(page2),
        "page1_first_text": page1[0]["comment_text"] if page1 else None,
        "page1_last_text": page1[-1]["comment_text"] if page1 else None,
        "page2_first_text": page2[0]["comment_text"] if page2 else None,
        "page2_last_text": page2[-1]["comment_text"] if page2 else None,
    }
    print(json.dumps(output, indent=2, default=str))

    svc.delete_decision(decision_id=dec["id"], actor="cli_tester")
    print(json.dumps({"cleanup": f"deleted decision {dec['id']}"}, indent=2))
    return 0


def cmd_test_format_comment() -> int:
    """Verify format_comment (a) inserts the two-space hard-break
    sequence required by CommonMark for multi-line markdown rendering,
    and (b) escapes `$` so Streamlit doesn't collapse price text into
    LaTeX math."""
    cases = [
        "",
        "single line",
        "line one\nline two",
        "a\nb\nc\n\nd",
        "BTC at $80k\nsupport $76,362",
        "Cycle top $125k / Fib 0.382 at $81,442",
    ]
    output = []
    for raw in cases:
        formatted = format_comment(raw)
        output.append({
            "raw": raw,
            "formatted": formatted,
            "raw_repr": repr(raw),
            "formatted_repr": repr(formatted),
            "line_breaks_preserved": (
                formatted.count("  \n") == raw.count("\n")
            ),
            "dollars_escaped": (
                formatted.count("\\$") == raw.count("$")
                and "$" not in formatted.replace("\\$", "")
            ),
        })
    print(json.dumps({"cases": output}, indent=2))
    return 0


def main() -> int:
    ap = argparse.ArgumentParser(
        prog="decision_board.cli",
        description="Decision Board CLI utility",
    )
    sub = ap.add_subparsers(dest="command")
    sub.add_parser("init-db", help="Create/verify DB tables (idempotent)")
    sub.add_parser("seed-demo", help="Insert sample decisions for testing")
    sub.add_parser("summary", help="Print board summary to stdout")
    sub.add_parser("debug-dump", help="Export full DB snapshot as JSON")
    sub.add_parser(
        "test-create-decision",
        help="Smoke test: create decision + actions + validate negatives",
    )
    sub.add_parser(
        "test-pagination",
        help="Smoke test: paginate through 35 comments, 20 per page",
    )
    sub.add_parser(
        "test-format-comment",
        help="Smoke test: format_comment markdown line-break helper",
    )

    args = ap.parse_args()

    if args.command is None:
        ap.print_help()
        return 1

    commands = {
        "init-db": cmd_init_db,
        "seed-demo": cmd_seed_demo,
        "summary": cmd_summary,
        "debug-dump": cmd_debug_dump,
        "test-create-decision": cmd_test_create_decision,
        "test-pagination": cmd_test_pagination,
        "test-format-comment": cmd_test_format_comment,
    }
    return commands[args.command]()


if __name__ == "__main__":
    raise SystemExit(main())
