from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Optional


@dataclass
class DecisionRecord:
    id: int
    title: str
    description: str
    status: str
    final_outcome: Optional[str]
    final_summary_reason: Optional[str]
    priority: str
    created_by: str
    locked_flag: int
    finalized_at_utc: Optional[str]
    finalized_by: Optional[str]
    created_at_utc: str
    updated_at_utc: str

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class ActionRecord:
    id: int
    decision_id: int
    action_type: str
    instrument_name: Optional[str]
    side: Optional[str]
    quantity: Optional[float]
    price_reference: Optional[float]
    reason_text: str
    sort_order: int
    created_at_utc: str
    updated_at_utc: str

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class CommentRecord:
    id: int
    decision_id: int
    author: str
    comment_text: str
    created_at_utc: str
    edited_at_utc: Optional[str]
    deleted_flag: int

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class EventLogRecord:
    id: int
    decision_id: int
    event_type: str
    actor: str
    event_payload_json: str
    created_at_utc: str

    def to_dict(self) -> dict:
        return asdict(self)
