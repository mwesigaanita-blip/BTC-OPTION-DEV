from __future__ import annotations

from datetime import datetime, timezone


PRIORITY_ORDER = {"critical": 0, "high": 1, "medium": 2, "low": 3}

STATUS_EMOJI = {
    "ideas": "\U0001f4a1",        # light bulb
    "under_review": "\U0001f50d",  # magnifying glass
    "done": "\u2705",              # check mark
}

STATUS_LABEL = {
    "ideas": "Ideas",
    "under_review": "Under Review",
    "done": "Done",
}

OUTCOME_STYLE: dict[str, tuple[str, str]] = {
    "accepted": ("\u2705", "#16c784"),
    "rejected": ("\u274c", "#ff4d4f"),
    "partial": ("\u26a0\ufe0f", "#ffb300"),
    "informational": ("\u2139\ufe0f", "#3b82f6"),
}

PRIORITY_STYLE: dict[str, tuple[str, str]] = {
    "critical": ("\U0001f534", "#ff4d4f"),
    "high": ("\U0001f7e0", "#ffb300"),
    "medium": ("\U0001f535", "#3b82f6"),
    "low": ("\u26aa", "#9ca3af"),
}

ACTION_TYPE_LABEL = {
    "open": "Open Position",
    "close": "Close Position",
    "adjust": "Adjust Position",
    "hedge": "Hedge",
    "note": "Note",
    "other": "Other",
}


def priority_sort_key(priority: str) -> int:
    return PRIORITY_ORDER.get(priority, 99)


def truncate(text: str, max_len: int = 120) -> str:
    if len(text) <= max_len:
        return text
    return text[: max_len - 3].rstrip() + "..."


def escape_md_dollars(text: str) -> str:
    """Escape `$` so Streamlit's Markdown/LaTeX pass does not collapse
    user text into math. Streamlit 1.50 has no flag to disable LaTeX in
    st.markdown - escaping each `$` is the canonical workaround.

    Apply this to every user-authored string that reaches st.markdown,
    st.info, or an HTML f-string that Streamlit will still parse as
    Markdown.
    """
    if not text:
        return ""
    return text.replace("$", "\\$")


def format_comment(text: str) -> str:
    """Preserve line breaks AND escape `$` when rendering a comment with
    Markdown. In CommonMark a single newline is rendered as a space; two
    trailing spaces + newline become a hard line break. Dollar signs are
    escaped up front so trade comments containing prices ($80k, $76,362,
    etc.) don't collapse into LaTeX math expressions.

    This is HTML-safe: we do NOT enable unsafe_allow_html at the call
    site, so Markdown will escape any embedded HTML.
    """
    if not text:
        return ""
    return escape_md_dollars(text).replace("\n", "  \n")


def format_relative_time(iso_str: str) -> str:
    try:
        dt = datetime.fromisoformat(iso_str)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        delta = datetime.now(timezone.utc) - dt
        seconds = int(delta.total_seconds())
        if seconds < 60:
            return "just now"
        if seconds < 3600:
            m = seconds // 60
            return f"{m}m ago"
        if seconds < 86400:
            h = seconds // 3600
            return f"{h}h ago"
        d = seconds // 86400
        if d == 1:
            return "1 day ago"
        if d < 30:
            return f"{d} days ago"
        return dt.strftime("%Y-%m-%d")
    except Exception:
        return iso_str
