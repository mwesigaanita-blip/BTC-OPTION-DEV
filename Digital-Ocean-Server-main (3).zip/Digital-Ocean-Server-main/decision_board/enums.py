from enum import Enum


class DecisionStatus(str, Enum):
    IDEAS = "ideas"
    UNDER_REVIEW = "under_review"
    DONE = "done"


class FinalOutcome(str, Enum):
    ACCEPTED = "accepted"
    REJECTED = "rejected"
    PARTIAL = "partial"
    INFORMATIONAL = "informational"


class ActionType(str, Enum):
    OPEN = "open"
    CLOSE = "close"
    ADJUST = "adjust"
    HEDGE = "hedge"
    NOTE = "note"
    OTHER = "other"


class Priority(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class EventType(str, Enum):
    CREATE_DECISION = "create_decision"
    EDIT_DECISION = "edit_decision"
    DELETE_DECISION = "delete_decision"
    ADD_ACTION = "add_action"
    EDIT_ACTION = "edit_action"
    DELETE_ACTION = "delete_action"
    MOVE_STATUS = "move_status"
    ADD_COMMENT = "add_comment"
    EDIT_COMMENT = "edit_comment"
    DELETE_COMMENT = "delete_comment"
    FINALIZE_DECISION = "finalize_decision"
    REOPEN_ATTEMPT_REJECTED = "reopen_attempt_rejected"
