from __future__ import annotations

import json
import logging
from typing import Any, Optional

from decision_board.db import get_conn, transaction, utc_now_iso

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Decisions
# ---------------------------------------------------------------------------

def insert_decision(
    *,
    title: str,
    description: str,
    created_by: str,
    priority: str = "medium",
    status: str = "ideas",
    conn: Any = None,
) -> dict:
    """Insert a decision. If `conn` is passed, reuse it (caller owns the
    transaction); otherwise open and auto-commit our own connection."""
    now = utc_now_iso()
    sql = (
        "INSERT INTO decisions "
        "(title, description, status, priority, created_by, "
        " created_at_utc, updated_at_utc) "
        "VALUES (?, ?, ?, ?, ?, ?, ?)"
    )
    params = (title, description, status, priority, created_by, now, now)
    if conn is not None:
        cur = conn.execute(sql, params)
        row = conn.execute(
            "SELECT * FROM decisions WHERE id = ?", (cur.lastrowid,)
        ).fetchone()
        return dict(row)

    with get_conn() as own:
        cur = own.execute(sql, params)
        own.commit()
        row = own.execute(
            "SELECT * FROM decisions WHERE id = ?", (cur.lastrowid,)
        ).fetchone()
    return dict(row)


def get_decision(decision_id: int) -> dict | None:
    with get_conn() as conn:
        row = conn.execute(
            "SELECT * FROM decisions WHERE id = ?", (decision_id,)
        ).fetchone()
    return dict(row) if row else None


def update_decision(decision_id: int, **fields: Any) -> dict:
    allowed = {
        "title", "description", "status", "priority",
        "final_outcome", "final_summary_reason",
        "locked_flag", "finalized_at_utc", "finalized_by", "updated_at_utc",
    }
    fields["updated_at_utc"] = utc_now_iso()
    to_set = {k: v for k, v in fields.items() if k in allowed}
    if not to_set:
        raise ValueError("No valid fields provided for update.")

    set_clause = ", ".join(f"{k} = ?" for k in to_set)
    params = list(to_set.values()) + [decision_id]

    with get_conn() as conn:
        conn.execute(
            f"UPDATE decisions SET {set_clause} WHERE id = ?", params
        )
        conn.commit()
        row = conn.execute(
            "SELECT * FROM decisions WHERE id = ?", (decision_id,)
        ).fetchone()
    return dict(row)


def delete_decision(decision_id: int, conn: Any = None) -> None:
    """Hard-delete a decision and ALL of its child rows (actions, comments,
    events). Intended for discarding an idea entirely - not a soft-delete.

    Explicitly deletes children first for compatibility with older DBs that
    were created without ON DELETE CASCADE. New DBs rely on cascade, but the
    explicit DELETEs are idempotent and safe either way.
    """
    def _run(c):
        c.execute("DELETE FROM decision_event_log WHERE decision_id = ?", (decision_id,))
        c.execute("DELETE FROM decision_comments WHERE decision_id = ?", (decision_id,))
        c.execute("DELETE FROM decision_actions WHERE decision_id = ?", (decision_id,))
        c.execute("DELETE FROM decisions WHERE id = ?", (decision_id,))

    if conn is not None:
        _run(conn)
        return

    with get_conn() as own:
        _run(own)
        own.commit()


def list_decisions(
    *,
    status: str | None = None,
    priority: str | None = None,
    created_by: str | None = None,
    final_outcome: str | None = None,
    search: str | None = None,
    sort: str = "newest",
    limit: int = 200,
    offset: int = 0,
) -> list[dict]:
    q = "SELECT * FROM decisions WHERE 1=1"
    params: list[Any] = []

    if status is not None:
        q += " AND status = ?"
        params.append(status)
    if priority is not None:
        q += " AND priority = ?"
        params.append(priority)
    if created_by is not None:
        q += " AND created_by = ?"
        params.append(created_by)
    if final_outcome is not None:
        q += " AND final_outcome = ?"
        params.append(final_outcome)
    if search:
        q += " AND (title LIKE ? OR description LIKE ?)"
        pattern = f"%{search}%"
        params.extend([pattern, pattern])

    if sort == "oldest":
        q += " ORDER BY created_at_utc ASC"
    elif sort == "recently_updated":
        q += " ORDER BY updated_at_utc DESC"
    else:
        q += " ORDER BY created_at_utc DESC"

    q += " LIMIT ? OFFSET ?"
    params.extend([limit, offset])

    with get_conn() as conn:
        rows = conn.execute(q, params).fetchall()
    return [dict(r) for r in rows]


def count_by_status() -> dict[str, int]:
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT status, COUNT(*) as cnt FROM decisions GROUP BY status"
        ).fetchall()
    return {r["status"]: r["cnt"] for r in rows}


def count_by_outcome() -> dict[str, int]:
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT final_outcome, COUNT(*) as cnt FROM decisions "
            "WHERE final_outcome IS NOT NULL GROUP BY final_outcome"
        ).fetchall()
    return {r["final_outcome"]: r["cnt"] for r in rows}


# ---------------------------------------------------------------------------
# Actions
# ---------------------------------------------------------------------------

def insert_action(
    *,
    decision_id: int,
    action_type: str,
    reason_text: str,
    instrument_name: str | None = None,
    side: str | None = None,
    quantity: float | None = None,
    price_reference: float | None = None,
    sort_order: int = 0,
    conn: Any = None,
) -> dict:
    now = utc_now_iso()
    sql = (
        "INSERT INTO decision_actions "
        "(decision_id, action_type, instrument_name, side, "
        " quantity, price_reference, reason_text, sort_order, "
        " created_at_utc, updated_at_utc) "
        "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
    )
    params = (
        decision_id, action_type, instrument_name, side,
        quantity, price_reference, reason_text, sort_order,
        now, now,
    )
    if conn is not None:
        cur = conn.execute(sql, params)
        row = conn.execute(
            "SELECT * FROM decision_actions WHERE id = ?", (cur.lastrowid,)
        ).fetchone()
        return dict(row)

    with get_conn() as own:
        cur = own.execute(sql, params)
        own.commit()
        row = own.execute(
            "SELECT * FROM decision_actions WHERE id = ?", (cur.lastrowid,)
        ).fetchone()
    return dict(row)


def get_action(action_id: int) -> dict | None:
    with get_conn() as conn:
        row = conn.execute(
            "SELECT * FROM decision_actions WHERE id = ?", (action_id,)
        ).fetchone()
    return dict(row) if row else None


def update_action(action_id: int, **fields: Any) -> dict:
    allowed = {
        "action_type", "instrument_name", "side",
        "quantity", "price_reference", "reason_text", "sort_order",
    }
    to_set = {k: v for k, v in fields.items() if k in allowed}
    if not to_set:
        raise ValueError("No valid fields provided for action update.")

    to_set["updated_at_utc"] = utc_now_iso()
    set_clause = ", ".join(f"{k} = ?" for k in to_set)
    params = list(to_set.values()) + [action_id]

    with get_conn() as conn:
        conn.execute(
            f"UPDATE decision_actions SET {set_clause} WHERE id = ?", params
        )
        conn.commit()
        row = conn.execute(
            "SELECT * FROM decision_actions WHERE id = ?", (action_id,)
        ).fetchone()
    return dict(row)


def delete_action(action_id: int) -> None:
    with get_conn() as conn:
        conn.execute("DELETE FROM decision_actions WHERE id = ?", (action_id,))
        conn.commit()


def list_actions(
    decision_id: int,
    limit: int = 50,
    offset: int = 0,
) -> list[dict]:
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT * FROM decision_actions WHERE decision_id = ? "
            "ORDER BY sort_order ASC, created_at_utc ASC "
            "LIMIT ? OFFSET ?",
            (decision_id, int(limit), int(offset)),
        ).fetchall()
    return [dict(r) for r in rows]


def count_actions(decision_id: int) -> int:
    with get_conn() as conn:
        row = conn.execute(
            "SELECT COUNT(*) AS c FROM decision_actions WHERE decision_id = ?",
            (decision_id,),
        ).fetchone()
    return int(row["c"]) if row else 0


# ---------------------------------------------------------------------------
# Comments
# ---------------------------------------------------------------------------

def insert_comment(
    *,
    decision_id: int,
    author: str,
    comment_text: str,
    conn: Any = None,
) -> dict:
    now = utc_now_iso()
    sql = (
        "INSERT INTO decision_comments "
        "(decision_id, author, comment_text, created_at_utc) "
        "VALUES (?, ?, ?, ?)"
    )
    params = (decision_id, author, comment_text, now)
    if conn is not None:
        cur = conn.execute(sql, params)
        row = conn.execute(
            "SELECT * FROM decision_comments WHERE id = ?", (cur.lastrowid,)
        ).fetchone()
        return dict(row)

    with get_conn() as own:
        cur = own.execute(sql, params)
        own.commit()
        row = own.execute(
            "SELECT * FROM decision_comments WHERE id = ?", (cur.lastrowid,)
        ).fetchone()
    return dict(row)


def get_comment(comment_id: int) -> dict | None:
    with get_conn() as conn:
        row = conn.execute(
            "SELECT * FROM decision_comments WHERE id = ?", (comment_id,)
        ).fetchone()
    return dict(row) if row else None


def update_comment(comment_id: int, new_text: str) -> dict:
    now = utc_now_iso()
    with get_conn() as conn:
        conn.execute(
            "UPDATE decision_comments SET comment_text = ?, edited_at_utc = ? WHERE id = ?",
            (new_text, now, comment_id),
        )
        conn.commit()
        row = conn.execute(
            "SELECT * FROM decision_comments WHERE id = ?", (comment_id,)
        ).fetchone()
    return dict(row)


def delete_comment(comment_id: int, conn: Any = None) -> None:
    """Soft-delete: flip deleted_flag to 1. `list_comments` already
    filters `deleted_flag = 0`, so the row disappears from UI while the
    audit trail stays intact."""
    sql = "UPDATE decision_comments SET deleted_flag = 1 WHERE id = ?"
    if conn is not None:
        conn.execute(sql, (comment_id,))
        return
    with get_conn() as own:
        own.execute(sql, (comment_id,))
        own.commit()


def list_comments(
    decision_id: int,
    limit: int = 50,
    offset: int = 0,
) -> list[dict]:
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT * FROM decision_comments WHERE decision_id = ? AND deleted_flag = 0 "
            "ORDER BY created_at_utc ASC "
            "LIMIT ? OFFSET ?",
            (decision_id, int(limit), int(offset)),
        ).fetchall()
    return [dict(r) for r in rows]


def count_comments(decision_id: int) -> int:
    with get_conn() as conn:
        row = conn.execute(
            "SELECT COUNT(*) AS c FROM decision_comments "
            "WHERE decision_id = ? AND deleted_flag = 0",
            (decision_id,),
        ).fetchone()
    return int(row["c"]) if row else 0


# ---------------------------------------------------------------------------
# Event Log
# ---------------------------------------------------------------------------

def insert_event(
    *,
    decision_id: int,
    event_type: str,
    actor: str,
    payload: dict | None = None,
    conn: Any = None,
) -> int:
    now = utc_now_iso()
    payload_json = json.dumps(payload or {}, default=str)
    sql = (
        "INSERT INTO decision_event_log "
        "(decision_id, event_type, actor, event_payload_json, created_at_utc) "
        "VALUES (?, ?, ?, ?, ?)"
    )
    params = (decision_id, event_type, actor, payload_json, now)
    if conn is not None:
        cur = conn.execute(sql, params)
        return cur.lastrowid

    with get_conn() as own:
        cur = own.execute(sql, params)
        own.commit()
    return cur.lastrowid


def list_events(
    decision_id: int | None = None,
    event_type: str | None = None,
    limit: int = 100,
    offset: int = 0,
) -> list[dict]:
    q = "SELECT * FROM decision_event_log WHERE 1=1"
    params: list[Any] = []

    if decision_id is not None:
        q += " AND decision_id = ?"
        params.append(decision_id)
    if event_type is not None:
        q += " AND event_type = ?"
        params.append(event_type)

    q += " ORDER BY created_at_utc DESC LIMIT ? OFFSET ?"
    params.extend([int(limit), int(offset)])

    with get_conn() as conn:
        rows = conn.execute(q, params).fetchall()
    return [dict(r) for r in rows]


def count_events(
    decision_id: int | None = None,
    event_type: str | None = None,
) -> int:
    q = "SELECT COUNT(*) AS c FROM decision_event_log WHERE 1=1"
    params: list[Any] = []
    if decision_id is not None:
        q += " AND decision_id = ?"
        params.append(decision_id)
    if event_type is not None:
        q += " AND event_type = ?"
        params.append(event_type)
    with get_conn() as conn:
        row = conn.execute(q, params).fetchone()
    return int(row["c"]) if row else 0


# ---------------------------------------------------------------------------
# Debug / Export
# ---------------------------------------------------------------------------

def export_all() -> dict:
    with get_conn() as conn:
        decisions = [dict(r) for r in conn.execute("SELECT * FROM decisions").fetchall()]
        actions = [dict(r) for r in conn.execute("SELECT * FROM decision_actions").fetchall()]
        comments = [dict(r) for r in conn.execute("SELECT * FROM decision_comments").fetchall()]
        events = [dict(r) for r in conn.execute("SELECT * FROM decision_event_log").fetchall()]
    return {
        "decisions": decisions,
        "actions": actions,
        "comments": comments,
        "events": events,
    }
