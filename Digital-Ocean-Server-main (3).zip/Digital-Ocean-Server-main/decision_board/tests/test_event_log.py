import json
import pytest
from decision_board import service as svc


class TestEventLogging:

    def test_create_logs_event(self):
        dec = svc.create_decision(title="Test", created_by="alice")
        events = svc.list_events(decision_id=dec["id"])
        assert len(events) >= 1
        create_events = [e for e in events if e["event_type"] == "create_decision"]
        assert len(create_events) == 1
        assert create_events[0]["actor"] == "alice"

    def test_update_logs_event(self):
        dec = svc.create_decision(title="Test", created_by="alice")
        svc.update_decision(decision_id=dec["id"], actor="bob", title="Updated")
        events = svc.list_events(decision_id=dec["id"], event_type="edit_decision")
        assert len(events) == 1
        assert events[0]["actor"] == "bob"

    def test_move_logs_event(self):
        dec = svc.create_decision(title="Test", created_by="alice")
        svc.move_decision_status(
            decision_id=dec["id"], new_status="under_review", actor="bob"
        )
        events = svc.list_events(decision_id=dec["id"], event_type="move_status")
        assert len(events) == 1
        payload = json.loads(events[0]["event_payload_json"])
        assert payload["from"] == "ideas"
        assert payload["to"] == "under_review"

    def test_finalize_logs_event(self):
        dec = svc.create_decision(title="Test", created_by="alice")
        svc.finalize_decision(
            decision_id=dec["id"],
            final_outcome="accepted",
            final_summary_reason="Go ahead",
            actor="charlie",
        )
        events = svc.list_events(decision_id=dec["id"], event_type="finalize_decision")
        assert len(events) == 1
        payload = json.loads(events[0]["event_payload_json"])
        assert payload["outcome"] == "accepted"

    def test_add_action_logs_event(self):
        dec = svc.create_decision(title="Test", created_by="alice")
        svc.add_action(
            decision_id=dec["id"], action_type="open",
            reason_text="reason", actor="alice",
        )
        events = svc.list_events(decision_id=dec["id"], event_type="add_action")
        assert len(events) == 1

    def test_edit_action_logs_event(self):
        dec = svc.create_decision(title="Test", created_by="alice")
        act = svc.add_action(
            decision_id=dec["id"], action_type="note",
            reason_text="original", actor="alice",
        )
        svc.update_action(action_id=act["id"], actor="bob", reason_text="updated")
        events = svc.list_events(decision_id=dec["id"], event_type="edit_action")
        assert len(events) == 1

    def test_delete_action_logs_event(self):
        dec = svc.create_decision(title="Test", created_by="alice")
        act = svc.add_action(
            decision_id=dec["id"], action_type="note",
            reason_text="to delete", actor="alice",
        )
        svc.delete_action(action_id=act["id"], actor="bob")
        events = svc.list_events(decision_id=dec["id"], event_type="delete_action")
        assert len(events) == 1

    def test_add_comment_logs_event(self):
        dec = svc.create_decision(title="Test", created_by="alice")
        svc.add_comment(
            decision_id=dec["id"], author="bob", comment_text="Hello"
        )
        events = svc.list_events(decision_id=dec["id"], event_type="add_comment")
        assert len(events) == 1

    def test_edit_comment_logs_event(self):
        dec = svc.create_decision(title="Test", created_by="alice")
        cmt = svc.add_comment(
            decision_id=dec["id"], author="bob", comment_text="Original"
        )
        svc.update_comment(comment_id=cmt["id"], actor="bob", new_text="Edited")
        events = svc.list_events(decision_id=dec["id"], event_type="edit_comment")
        assert len(events) == 1

    def test_event_payload_is_valid_json(self):
        dec = svc.create_decision(title="Test", created_by="alice")
        events = svc.list_events(decision_id=dec["id"])
        for ev in events:
            parsed = json.loads(ev["event_payload_json"])
            assert isinstance(parsed, dict)

    def test_list_events_with_limit(self):
        dec = svc.create_decision(title="Test", created_by="alice")
        for i in range(5):
            svc.add_comment(
                decision_id=dec["id"], author="alice", comment_text=f"Comment {i}"
            )
        events = svc.list_events(decision_id=dec["id"], limit=3)
        assert len(events) == 3

    def test_list_events_newest_first(self):
        dec = svc.create_decision(title="Test", created_by="alice")
        svc.add_comment(decision_id=dec["id"], author="alice", comment_text="First")
        svc.add_comment(decision_id=dec["id"], author="bob", comment_text="Second")
        events = svc.list_events(decision_id=dec["id"])
        assert events[0]["created_at_utc"] >= events[-1]["created_at_utc"]
