import pytest
from decision_board import service as svc


class TestCreateDecision:

    def test_creates_with_defaults(self):
        dec = svc.create_decision(title="Test Idea", created_by="alice")
        assert dec["id"] > 0
        assert dec["title"] == "Test Idea"
        assert dec["status"] == "ideas"
        assert dec["priority"] == "medium"
        assert dec["created_by"] == "alice"
        assert dec["locked_flag"] == 0
        assert dec["created_at_utc"] is not None

    def test_creates_with_all_fields(self):
        dec = svc.create_decision(
            title="Urgent Hedge",
            description="Need to hedge delta exposure",
            created_by="bob",
            priority="critical",
        )
        assert dec["title"] == "Urgent Hedge"
        assert dec["description"] == "Need to hedge delta exposure"
        assert dec["priority"] == "critical"

    def test_empty_title_raises(self):
        with pytest.raises(ValueError, match="title must not be empty"):
            svc.create_decision(title="", created_by="alice")

    def test_whitespace_title_raises(self):
        with pytest.raises(ValueError, match="title must not be empty"):
            svc.create_decision(title="   ", created_by="alice")

    def test_invalid_priority_raises(self):
        with pytest.raises(ValueError, match="Invalid priority"):
            svc.create_decision(title="Test", created_by="alice", priority="urgent")

    def test_creates_with_inline_actions(self):
        dec = svc.create_decision(
            title="Multi-action idea",
            created_by="alice",
            actions=[
                {"action_type": "open", "reason_text": "Buy BTC call"},
                {"action_type": "hedge", "reason_text": "Hedge with perp"},
            ],
        )
        actions = svc.list_actions(dec["id"])
        assert len(actions) == 2
        assert actions[0]["action_type"] == "open"
        assert actions[1]["action_type"] == "hedge"

    def test_title_is_stripped(self):
        dec = svc.create_decision(title="  padded title  ", created_by="alice")
        assert dec["title"] == "padded title"


class TestUpdateDecision:

    def test_updates_title(self):
        dec = svc.create_decision(title="Original", created_by="alice")
        updated = svc.update_decision(decision_id=dec["id"], actor="bob", title="Updated")
        assert updated["title"] == "Updated"

    def test_updates_description(self):
        dec = svc.create_decision(title="Test", created_by="alice")
        updated = svc.update_decision(
            decision_id=dec["id"], actor="bob", description="New description"
        )
        assert updated["description"] == "New description"

    def test_updates_priority(self):
        dec = svc.create_decision(title="Test", created_by="alice")
        updated = svc.update_decision(decision_id=dec["id"], actor="bob", priority="high")
        assert updated["priority"] == "high"

    def test_invalid_priority_raises(self):
        dec = svc.create_decision(title="Test", created_by="alice")
        with pytest.raises(ValueError, match="Invalid priority"):
            svc.update_decision(decision_id=dec["id"], actor="bob", priority="asap")

    def test_empty_title_raises(self):
        dec = svc.create_decision(title="Test", created_by="alice")
        with pytest.raises(ValueError, match="Title must not be empty"):
            svc.update_decision(decision_id=dec["id"], actor="bob", title="")

    def test_no_valid_fields_raises(self):
        dec = svc.create_decision(title="Test", created_by="alice")
        with pytest.raises(ValueError, match="No valid updatable fields"):
            svc.update_decision(decision_id=dec["id"], actor="bob", fake_field="val")

    def test_nonexistent_decision_raises(self):
        with pytest.raises(ValueError, match="not found"):
            svc.update_decision(decision_id=9999, actor="bob", title="New")


class TestGetDecision:

    def test_returns_existing(self):
        dec = svc.create_decision(title="Test", created_by="alice")
        fetched = svc.get_decision(dec["id"])
        assert fetched is not None
        assert fetched["title"] == "Test"

    def test_returns_none_for_missing(self):
        assert svc.get_decision(9999) is None


class TestListDecisions:

    def test_returns_empty_when_no_decisions(self):
        result = svc.list_decisions()
        assert result == []

    def test_returns_all_decisions(self):
        svc.create_decision(title="A", created_by="alice")
        svc.create_decision(title="B", created_by="bob")
        result = svc.list_decisions()
        assert len(result) == 2

    def test_filter_by_status(self):
        d1 = svc.create_decision(title="Idea", created_by="alice")
        d2 = svc.create_decision(title="Review", created_by="alice")
        svc.move_decision_status(decision_id=d2["id"], new_status="under_review", actor="alice")
        ideas = svc.list_decisions(status="ideas")
        assert len(ideas) == 1
        assert ideas[0]["title"] == "Idea"

    def test_filter_by_created_by(self):
        svc.create_decision(title="A", created_by="alice")
        svc.create_decision(title="B", created_by="bob")
        result = svc.list_decisions(created_by="alice")
        assert len(result) == 1

    def test_search_by_title(self):
        svc.create_decision(title="BTC Hedge Idea", created_by="alice")
        svc.create_decision(title="ETH Position", created_by="bob")
        result = svc.list_decisions(search="Hedge")
        assert len(result) == 1
        assert "Hedge" in result[0]["title"]

    def test_search_by_description(self):
        svc.create_decision(
            title="General", description="need to hedge delta", created_by="alice"
        )
        result = svc.list_decisions(search="delta")
        assert len(result) == 1


class TestGetMetrics:

    def test_empty_board(self):
        m = svc.get_metrics()
        assert m["total"] == 0
        assert m["by_status"] == {}
        assert m["by_outcome"] == {}

    def test_counts_by_status(self):
        svc.create_decision(title="A", created_by="alice")
        d2 = svc.create_decision(title="B", created_by="alice")
        svc.move_decision_status(decision_id=d2["id"], new_status="under_review", actor="alice")
        m = svc.get_metrics()
        assert m["total"] == 2
        assert m["by_status"].get("ideas") == 1
        assert m["by_status"].get("under_review") == 1


class TestGetBoardData:

    def test_returns_all_three_columns(self):
        board = svc.get_board_data()
        assert "ideas" in board
        assert "under_review" in board
        assert "done" in board

    def test_decisions_in_correct_columns(self):
        d1 = svc.create_decision(title="Idea", created_by="alice")
        d2 = svc.create_decision(title="Review", created_by="alice")
        svc.move_decision_status(decision_id=d2["id"], new_status="under_review", actor="alice")
        board = svc.get_board_data()
        assert len(board["ideas"]) == 1
        assert len(board["under_review"]) == 1
        assert len(board["done"]) == 0


class TestGetDecisionDetail:

    def test_includes_comments_actions_events(self):
        dec = svc.create_decision(title="Test", created_by="alice")
        svc.add_action(
            decision_id=dec["id"], action_type="open",
            reason_text="Buy call", actor="alice",
        )
        svc.add_comment(decision_id=dec["id"], author="bob", comment_text="Looks good")
        detail = svc.get_decision_detail(dec["id"])
        assert detail is not None
        assert len(detail["actions"]) == 1
        assert len(detail["comments"]) == 1
        assert len(detail["events"]) > 0

    def test_returns_none_for_missing(self):
        assert svc.get_decision_detail(9999) is None
