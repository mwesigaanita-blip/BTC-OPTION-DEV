import pytest
from decision_board import service as svc


class TestAddComment:

    def test_add_comment(self):
        dec = svc.create_decision(title="Test", created_by="alice")
        cmt = svc.add_comment(
            decision_id=dec["id"], author="bob", comment_text="Great idea!"
        )
        assert cmt["id"] > 0
        assert cmt["author"] == "bob"
        assert cmt["comment_text"] == "Great idea!"
        assert cmt["decision_id"] == dec["id"]

    def test_empty_comment_raises(self):
        dec = svc.create_decision(title="Test", created_by="alice")
        with pytest.raises(ValueError, match="must not be empty"):
            svc.add_comment(decision_id=dec["id"], author="bob", comment_text="")

    def test_whitespace_comment_raises(self):
        dec = svc.create_decision(title="Test", created_by="alice")
        with pytest.raises(ValueError, match="must not be empty"):
            svc.add_comment(decision_id=dec["id"], author="bob", comment_text="   ")

    def test_comment_on_nonexistent_raises(self):
        with pytest.raises(ValueError, match="not found"):
            svc.add_comment(decision_id=9999, author="bob", comment_text="Hello")

    def test_comment_text_is_stripped(self):
        dec = svc.create_decision(title="Test", created_by="alice")
        cmt = svc.add_comment(
            decision_id=dec["id"], author="bob", comment_text="  trimmed  "
        )
        assert cmt["comment_text"] == "trimmed"


class TestUpdateComment:

    def test_update_comment_text(self):
        dec = svc.create_decision(title="Test", created_by="alice")
        cmt = svc.add_comment(
            decision_id=dec["id"], author="bob", comment_text="Original"
        )
        updated = svc.update_comment(
            comment_id=cmt["id"], actor="bob", new_text="Updated"
        )
        assert updated["comment_text"] == "Updated"
        assert updated["edited_at_utc"] is not None

    def test_update_empty_text_raises(self):
        dec = svc.create_decision(title="Test", created_by="alice")
        cmt = svc.add_comment(
            decision_id=dec["id"], author="bob", comment_text="Original"
        )
        with pytest.raises(ValueError, match="must not be empty"):
            svc.update_comment(comment_id=cmt["id"], actor="bob", new_text="")

    def test_update_nonexistent_raises(self):
        with pytest.raises(ValueError, match="not found"):
            svc.update_comment(comment_id=9999, actor="bob", new_text="New")


class TestCommentOnFinalized:

    def test_add_comment_on_finalized_raises(self):
        dec = svc.create_decision(title="Test", created_by="alice")
        svc.finalize_decision(
            decision_id=dec["id"],
            final_outcome="accepted",
            final_summary_reason="Done",
            actor="alice",
        )
        with pytest.raises(ValueError, match="locked"):
            svc.add_comment(decision_id=dec["id"], author="bob", comment_text="Late")

    def test_update_comment_on_finalized_raises(self):
        dec = svc.create_decision(title="Test", created_by="alice")
        cmt = svc.add_comment(
            decision_id=dec["id"], author="bob", comment_text="Before lock"
        )
        svc.finalize_decision(
            decision_id=dec["id"],
            final_outcome="rejected",
            final_summary_reason="No go",
            actor="alice",
        )
        with pytest.raises(ValueError, match="locked"):
            svc.update_comment(comment_id=cmt["id"], actor="bob", new_text="After lock")


class TestListComments:

    def test_list_in_chronological_order(self):
        dec = svc.create_decision(title="Test", created_by="alice")
        svc.add_comment(decision_id=dec["id"], author="alice", comment_text="First")
        svc.add_comment(decision_id=dec["id"], author="bob", comment_text="Second")
        svc.add_comment(decision_id=dec["id"], author="charlie", comment_text="Third")
        comments = svc.list_comments(dec["id"])
        assert len(comments) == 3
        assert comments[0]["comment_text"] == "First"
        assert comments[2]["comment_text"] == "Third"

    def test_empty_list(self):
        dec = svc.create_decision(title="Test", created_by="alice")
        assert svc.list_comments(dec["id"]) == []
