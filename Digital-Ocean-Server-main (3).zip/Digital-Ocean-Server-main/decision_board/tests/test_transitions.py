import pytest
from decision_board import service as svc


class TestMoveDecisionStatus:

    def test_ideas_to_under_review(self):
        dec = svc.create_decision(title="Test", created_by="alice")
        moved = svc.move_decision_status(
            decision_id=dec["id"], new_status="under_review", actor="alice"
        )
        assert moved["status"] == "under_review"

    def test_under_review_to_ideas(self):
        dec = svc.create_decision(title="Test", created_by="alice")
        svc.move_decision_status(decision_id=dec["id"], new_status="under_review", actor="alice")
        moved = svc.move_decision_status(
            decision_id=dec["id"], new_status="ideas", actor="alice"
        )
        assert moved["status"] == "ideas"

    def test_move_to_done_raises(self):
        dec = svc.create_decision(title="Test", created_by="alice")
        with pytest.raises(ValueError, match="finalize_decision"):
            svc.move_decision_status(
                decision_id=dec["id"], new_status="done", actor="alice"
            )

    def test_invalid_status_raises(self):
        dec = svc.create_decision(title="Test", created_by="alice")
        with pytest.raises(ValueError, match="Invalid status"):
            svc.move_decision_status(
                decision_id=dec["id"], new_status="archived", actor="alice"
            )

    def test_move_same_status_is_noop(self):
        dec = svc.create_decision(title="Test", created_by="alice")
        result = svc.move_decision_status(
            decision_id=dec["id"], new_status="ideas", actor="alice"
        )
        assert result["status"] == "ideas"

    def test_move_finalized_raises(self):
        dec = svc.create_decision(title="Test", created_by="alice")
        svc.finalize_decision(
            decision_id=dec["id"],
            final_outcome="accepted",
            final_summary_reason="Done",
            actor="alice",
        )
        with pytest.raises(ValueError, match="locked"):
            svc.move_decision_status(
                decision_id=dec["id"], new_status="ideas", actor="alice"
            )


class TestFinalizeDecision:

    def test_finalize_from_ideas(self):
        dec = svc.create_decision(title="Quick decide", created_by="alice")
        result = svc.finalize_decision(
            decision_id=dec["id"],
            final_outcome="accepted",
            final_summary_reason="Proceed immediately",
            actor="bob",
        )
        assert result["status"] == "done"
        assert result["final_outcome"] == "accepted"
        assert result["final_summary_reason"] == "Proceed immediately"
        assert result["locked_flag"] == 1
        assert result["finalized_by"] == "bob"
        assert result["finalized_at_utc"] is not None

    def test_finalize_from_under_review(self):
        dec = svc.create_decision(title="Test", created_by="alice")
        svc.move_decision_status(decision_id=dec["id"], new_status="under_review", actor="alice")
        result = svc.finalize_decision(
            decision_id=dec["id"],
            final_outcome="rejected",
            final_summary_reason="Too risky",
            actor="charlie",
        )
        assert result["status"] == "done"
        assert result["final_outcome"] == "rejected"

    def test_finalize_all_outcomes(self):
        for outcome in ["accepted", "rejected", "partial", "informational"]:
            dec = svc.create_decision(title=f"Test {outcome}", created_by="alice")
            result = svc.finalize_decision(
                decision_id=dec["id"],
                final_outcome=outcome,
                final_summary_reason=f"Reason for {outcome}",
                actor="alice",
            )
            assert result["final_outcome"] == outcome

    def test_invalid_outcome_raises(self):
        dec = svc.create_decision(title="Test", created_by="alice")
        with pytest.raises(ValueError, match="Invalid final_outcome"):
            svc.finalize_decision(
                decision_id=dec["id"],
                final_outcome="maybe",
                final_summary_reason="reason",
                actor="alice",
            )

    def test_empty_reason_raises(self):
        dec = svc.create_decision(title="Test", created_by="alice")
        with pytest.raises(ValueError, match="final_summary_reason is required"):
            svc.finalize_decision(
                decision_id=dec["id"],
                final_outcome="accepted",
                final_summary_reason="",
                actor="alice",
            )

    def test_whitespace_reason_raises(self):
        dec = svc.create_decision(title="Test", created_by="alice")
        with pytest.raises(ValueError, match="final_summary_reason is required"):
            svc.finalize_decision(
                decision_id=dec["id"],
                final_outcome="accepted",
                final_summary_reason="   ",
                actor="alice",
            )

    def test_double_finalize_raises(self):
        dec = svc.create_decision(title="Test", created_by="alice")
        svc.finalize_decision(
            decision_id=dec["id"],
            final_outcome="accepted",
            final_summary_reason="Done",
            actor="alice",
        )
        with pytest.raises(ValueError, match="locked"):
            svc.finalize_decision(
                decision_id=dec["id"],
                final_outcome="rejected",
                final_summary_reason="Changed mind",
                actor="bob",
            )


class TestFullLifecycle:

    def test_create_move_finalize_lock(self):
        dec = svc.create_decision(
            title="Buy BTC Call",
            description="30-day call at 100k strike",
            created_by="alice",
            priority="high",
        )
        assert dec["status"] == "ideas"

        svc.add_action(
            decision_id=dec["id"], action_type="open",
            reason_text="Bullish thesis on BTC", actor="alice",
            instrument_name="BTC-30JUN25-100000-C", side="buy",
            quantity=1.0, price_reference=2500.0,
        )
        svc.add_comment(
            decision_id=dec["id"], author="bob",
            comment_text="I agree with the bullish thesis",
        )

        moved = svc.move_decision_status(
            decision_id=dec["id"], new_status="under_review", actor="bob"
        )
        assert moved["status"] == "under_review"

        svc.add_comment(
            decision_id=dec["id"], author="charlie",
            comment_text="Risk is acceptable, proceed",
        )

        finalized = svc.finalize_decision(
            decision_id=dec["id"],
            final_outcome="accepted",
            final_summary_reason="Team agrees to proceed with call purchase",
            actor="charlie",
        )
        assert finalized["locked_flag"] == 1

        with pytest.raises(ValueError, match="locked"):
            svc.update_decision(decision_id=dec["id"], actor="alice", title="New Title")
        with pytest.raises(ValueError, match="locked"):
            svc.move_decision_status(decision_id=dec["id"], new_status="ideas", actor="alice")
        with pytest.raises(ValueError, match="locked"):
            svc.add_comment(decision_id=dec["id"], author="alice", comment_text="More")
        with pytest.raises(ValueError, match="locked"):
            svc.add_action(
                decision_id=dec["id"], action_type="note",
                reason_text="Late note", actor="alice",
            )

        detail = svc.get_decision_detail(dec["id"])
        assert len(detail["comments"]) == 2
        assert len(detail["actions"]) == 1
        assert len(detail["events"]) > 0

    def test_anyone_can_edit_non_finalized(self):
        dec = svc.create_decision(title="Original", created_by="alice")
        svc.update_decision(decision_id=dec["id"], actor="bob", title="Bob's Edit")
        svc.update_decision(decision_id=dec["id"], actor="charlie", title="Charlie's Edit")
        result = svc.get_decision(dec["id"])
        assert result["title"] == "Charlie's Edit"

    def test_anyone_can_finalize(self):
        dec = svc.create_decision(title="Test", created_by="alice")
        result = svc.finalize_decision(
            decision_id=dec["id"],
            final_outcome="informational",
            final_summary_reason="Noted for future reference",
            actor="charlie",
        )
        assert result["finalized_by"] == "charlie"
