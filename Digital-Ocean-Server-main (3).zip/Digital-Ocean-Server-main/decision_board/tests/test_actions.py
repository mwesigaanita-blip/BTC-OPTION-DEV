import pytest
from decision_board import service as svc


class TestAddAction:

    def test_add_basic_action(self):
        dec = svc.create_decision(title="Test", created_by="alice")
        act = svc.add_action(
            decision_id=dec["id"],
            action_type="open",
            reason_text="Buy BTC call for upside",
            actor="alice",
        )
        assert act["id"] > 0
        assert act["action_type"] == "open"
        assert act["reason_text"] == "Buy BTC call for upside"
        assert act["decision_id"] == dec["id"]

    def test_add_action_with_all_fields(self):
        dec = svc.create_decision(title="Test", created_by="alice")
        act = svc.add_action(
            decision_id=dec["id"],
            action_type="hedge",
            reason_text="Hedge delta with perp",
            actor="alice",
            instrument_name="BTC-PERPETUAL",
            side="sell",
            quantity=0.5,
            price_reference=95000.0,
            sort_order=1,
        )
        assert act["instrument_name"] == "BTC-PERPETUAL"
        assert act["side"] == "sell"
        assert act["quantity"] == 0.5
        assert act["price_reference"] == 95000.0
        assert act["sort_order"] == 1

    def test_invalid_action_type_raises(self):
        dec = svc.create_decision(title="Test", created_by="alice")
        with pytest.raises(ValueError, match="Invalid action_type"):
            svc.add_action(
                decision_id=dec["id"],
                action_type="sell_everything",
                reason_text="reason",
                actor="alice",
            )

    def test_empty_reason_raises(self):
        dec = svc.create_decision(title="Test", created_by="alice")
        with pytest.raises(ValueError, match="reason_text is required"):
            svc.add_action(
                decision_id=dec["id"],
                action_type="note",
                reason_text="",
                actor="alice",
            )

    def test_add_on_nonexistent_decision_raises(self):
        with pytest.raises(ValueError, match="not found"):
            svc.add_action(
                decision_id=9999,
                action_type="note",
                reason_text="reason",
                actor="alice",
            )


class TestUpdateAction:

    def test_update_reason_text(self):
        dec = svc.create_decision(title="Test", created_by="alice")
        act = svc.add_action(
            decision_id=dec["id"],
            action_type="open",
            reason_text="Original reason",
            actor="alice",
        )
        updated = svc.update_action(
            action_id=act["id"], actor="bob", reason_text="Updated reason"
        )
        assert updated["reason_text"] == "Updated reason"

    def test_update_action_type(self):
        dec = svc.create_decision(title="Test", created_by="alice")
        act = svc.add_action(
            decision_id=dec["id"],
            action_type="note",
            reason_text="reason",
            actor="alice",
        )
        updated = svc.update_action(
            action_id=act["id"], actor="bob", action_type="hedge"
        )
        assert updated["action_type"] == "hedge"

    def test_update_nonexistent_raises(self):
        with pytest.raises(ValueError, match="not found"):
            svc.update_action(action_id=9999, actor="bob", reason_text="new")


class TestDeleteAction:

    def test_delete_action(self):
        dec = svc.create_decision(title="Test", created_by="alice")
        act = svc.add_action(
            decision_id=dec["id"],
            action_type="note",
            reason_text="Will delete",
            actor="alice",
        )
        svc.delete_action(action_id=act["id"], actor="bob")
        actions = svc.list_actions(dec["id"])
        assert len(actions) == 0

    def test_delete_nonexistent_raises(self):
        with pytest.raises(ValueError, match="not found"):
            svc.delete_action(action_id=9999, actor="bob")


class TestActionOnFinalized:

    def _make_finalized(self):
        dec = svc.create_decision(title="Test", created_by="alice")
        act = svc.add_action(
            decision_id=dec["id"],
            action_type="note",
            reason_text="Before lock",
            actor="alice",
        )
        svc.finalize_decision(
            decision_id=dec["id"],
            final_outcome="accepted",
            final_summary_reason="Done",
            actor="alice",
        )
        return dec, act

    def test_add_action_on_finalized_raises(self):
        dec, _ = self._make_finalized()
        with pytest.raises(ValueError, match="locked"):
            svc.add_action(
                decision_id=dec["id"],
                action_type="note",
                reason_text="Late action",
                actor="bob",
            )

    def test_update_action_on_finalized_raises(self):
        _, act = self._make_finalized()
        with pytest.raises(ValueError, match="locked"):
            svc.update_action(
                action_id=act["id"], actor="bob", reason_text="New reason"
            )

    def test_delete_action_on_finalized_raises(self):
        _, act = self._make_finalized()
        with pytest.raises(ValueError, match="locked"):
            svc.delete_action(action_id=act["id"], actor="bob")


class TestListActions:

    def test_list_ordered_by_sort_order(self):
        dec = svc.create_decision(title="Test", created_by="alice")
        svc.add_action(
            decision_id=dec["id"], action_type="note",
            reason_text="Third", actor="alice", sort_order=3,
        )
        svc.add_action(
            decision_id=dec["id"], action_type="note",
            reason_text="First", actor="alice", sort_order=1,
        )
        svc.add_action(
            decision_id=dec["id"], action_type="note",
            reason_text="Second", actor="alice", sort_order=2,
        )
        actions = svc.list_actions(dec["id"])
        assert actions[0]["reason_text"] == "First"
        assert actions[1]["reason_text"] == "Second"
        assert actions[2]["reason_text"] == "Third"

    def test_empty_list(self):
        dec = svc.create_decision(title="Test", created_by="alice")
        assert svc.list_actions(dec["id"]) == []
