import pytest
import sqlite3
from unittest.mock import patch

import decision_board.db as db_mod
import decision_board.repository as repo_mod


def _make_conn(db_file):
    conn = sqlite3.connect(str(db_file))
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL;")
    conn.execute("PRAGMA synchronous=NORMAL;")
    conn.execute("PRAGMA foreign_keys=ON;")
    return conn


@pytest.fixture(autouse=True)
def isolated_db(tmp_path):
    db_file = tmp_path / "test_decision_board.db"
    factory = lambda: _make_conn(db_file)

    with (
        patch.object(db_mod, "get_conn", factory),
        patch.object(repo_mod, "get_conn", factory),
    ):
        db_mod.ensure_tables()
        yield db_file
