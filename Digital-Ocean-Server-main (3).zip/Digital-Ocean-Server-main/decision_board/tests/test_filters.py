import pytest
from decision_board import service as svc


class TestFilterByStatus:

    def test_filter_ideas(self):
        svc.create_decision(title="Idea A", created_by="alice")
        d2 = svc.create_decision(title="Idea B", created_by="alice")
        svc.move_decision_status(decision_id=d2["id"], new_status="under_review", actor="alice")
        result = svc.list_decisions(status="ideas")
        assert all(r["status"] == "ideas" for r in result)
        assert len(result) == 1

    def test_filter_under_review(self):
        d1 = svc.create_decision(title="A", created_by="alice")
        svc.move_decision_status(decision_id=d1["id"], new_status="under_review", actor="alice")
        result = svc.list_decisions(status="under_review")
        assert len(result) == 1
        assert result[0]["status"] == "under_review"

    def test_filter_done(self):
        d1 = svc.create_decision(title="A", created_by="alice")
        svc.finalize_decision(
            decision_id=d1["id"],
            final_outcome="accepted",
            final_summary_reason="Done",
            actor="alice",
        )
        result = svc.list_decisions(status="done")
        assert len(result) == 1
        assert result[0]["status"] == "done"


class TestFilterByPriority:

    def test_filter_critical(self):
        svc.create_decision(title="A", created_by="alice", priority="critical")
        svc.create_decision(title="B", created_by="alice", priority="low")
        result = svc.list_decisions(priority="critical")
        assert len(result) == 1
        assert result[0]["priority"] == "critical"


class TestFilterByCreatedBy:

    def test_filter_by_user(self):
        svc.create_decision(title="A", created_by="alice")
        svc.create_decision(title="B", created_by="bob")
        svc.create_decision(title="C", created_by="alice")
        result = svc.list_decisions(created_by="alice")
        assert len(result) == 2
        assert all(r["created_by"] == "alice" for r in result)


class TestFilterByOutcome:

    def test_filter_accepted(self):
        d1 = svc.create_decision(title="A", created_by="alice")
        d2 = svc.create_decision(title="B", created_by="alice")
        svc.finalize_decision(
            decision_id=d1["id"],
            final_outcome="accepted",
            final_summary_reason="Yes",
            actor="alice",
        )
        svc.finalize_decision(
            decision_id=d2["id"],
            final_outcome="rejected",
            final_summary_reason="No",
            actor="alice",
        )
        result = svc.list_decisions(final_outcome="accepted")
        assert len(result) == 1
        assert result[0]["final_outcome"] == "accepted"


class TestSearch:

    def test_search_title_substring(self):
        svc.create_decision(title="BTC Hedge Strategy", created_by="alice")
        svc.create_decision(title="ETH Position Review", created_by="bob")
        result = svc.list_decisions(search="Hedge")
        assert len(result) == 1

    def test_search_description_substring(self):
        svc.create_decision(
            title="General", description="We need to hedge the delta", created_by="alice"
        )
        svc.create_decision(
            title="Other", description="Simple note", created_by="bob"
        )
        result = svc.list_decisions(search="delta")
        assert len(result) == 1

    def test_search_case_insensitive(self):
        svc.create_decision(title="BTC HEDGE", created_by="alice")
        result = svc.list_decisions(search="btc hedge")
        assert len(result) == 1

    def test_search_no_matches(self):
        svc.create_decision(title="Test", created_by="alice")
        result = svc.list_decisions(search="nonexistent")
        assert result == []


class TestSorting:

    def test_newest_first_default(self):
        svc.create_decision(title="First", created_by="alice")
        svc.create_decision(title="Second", created_by="alice")
        result = svc.list_decisions(sort="newest")
        assert result[0]["title"] == "Second"

    def test_oldest_first(self):
        svc.create_decision(title="First", created_by="alice")
        svc.create_decision(title="Second", created_by="alice")
        result = svc.list_decisions(sort="oldest")
        assert result[0]["title"] == "First"


class TestCombinedFilters:

    def test_status_and_priority(self):
        svc.create_decision(title="A", created_by="alice", priority="high")
        svc.create_decision(title="B", created_by="alice", priority="low")
        d3 = svc.create_decision(title="C", created_by="alice", priority="high")
        svc.move_decision_status(decision_id=d3["id"], new_status="under_review", actor="alice")
        result = svc.list_decisions(status="ideas", priority="high")
        assert len(result) == 1
        assert result[0]["title"] == "A"

    def test_status_and_search(self):
        svc.create_decision(title="BTC Hedge", created_by="alice")
        d2 = svc.create_decision(title="BTC Close", created_by="alice")
        svc.move_decision_status(decision_id=d2["id"], new_status="under_review", actor="alice")
        result = svc.list_decisions(status="ideas", search="BTC")
        assert len(result) == 1
        assert result[0]["title"] == "BTC Hedge"


class TestCountByStatus:

    def test_counts_after_creates_and_moves(self):
        svc.create_decision(title="A", created_by="alice")
        svc.create_decision(title="B", created_by="alice")
        d3 = svc.create_decision(title="C", created_by="alice")
        svc.move_decision_status(decision_id=d3["id"], new_status="under_review", actor="alice")
        metrics = svc.get_metrics()
        assert metrics["by_status"].get("ideas") == 2
        assert metrics["by_status"].get("under_review") == 1
