import pytest
import sqlite3

import decision_board.db as db_mod


class TestEnsureTables:

    def test_creates_decisions_table(self):
        conn = db_mod.get_conn()
        row = conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='decisions'"
        ).fetchone()
        conn.close()
        assert row is not None

    def test_creates_actions_table(self):
        conn = db_mod.get_conn()
        row = conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='decision_actions'"
        ).fetchone()
        conn.close()
        assert row is not None

    def test_creates_comments_table(self):
        conn = db_mod.get_conn()
        row = conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='decision_comments'"
        ).fetchone()
        conn.close()
        assert row is not None

    def test_creates_event_log_table(self):
        conn = db_mod.get_conn()
        row = conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='decision_event_log'"
        ).fetchone()
        conn.close()
        assert row is not None

    def test_idempotent_safe_to_call_twice(self):
        db_mod.ensure_tables()
        db_mod.ensure_tables()
        conn = db_mod.get_conn()
        tables = conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name"
        ).fetchall()
        conn.close()
        names = [r["name"] for r in tables]
        assert "decisions" in names
        assert "decision_actions" in names
        assert "decision_comments" in names
        assert "decision_event_log" in names

    def test_decisions_indexes_exist(self):
        conn = db_mod.get_conn()
        rows = conn.execute(
            "SELECT name FROM sqlite_master WHERE type='index' AND name LIKE 'idx_decisions_%'"
        ).fetchall()
        conn.close()
        names = {r["name"] for r in rows}
        assert "idx_decisions_status" in names
        assert "idx_decisions_priority" in names
        assert "idx_decisions_created_by" in names

    def test_actions_index_exists(self):
        conn = db_mod.get_conn()
        row = conn.execute(
            "SELECT name FROM sqlite_master WHERE type='index' AND name='idx_actions_decision'"
        ).fetchone()
        conn.close()
        assert row is not None

    def test_comments_index_exists(self):
        conn = db_mod.get_conn()
        row = conn.execute(
            "SELECT name FROM sqlite_master WHERE type='index' AND name='idx_comments_decision'"
        ).fetchone()
        conn.close()
        assert row is not None

    def test_event_log_indexes_exist(self):
        conn = db_mod.get_conn()
        rows = conn.execute(
            "SELECT name FROM sqlite_master WHERE type='index' AND name LIKE 'idx_events_%'"
        ).fetchall()
        conn.close()
        names = {r["name"] for r in rows}
        assert "idx_events_decision" in names
        assert "idx_events_type" in names

    def test_status_check_constraint_rejects_invalid(self):
        conn = db_mod.get_conn()
        with pytest.raises(sqlite3.IntegrityError):
            conn.execute(
                "INSERT INTO decisions (title, status, created_by, created_at_utc, updated_at_utc) "
                "VALUES ('test', 'invalid', 'user', '2025-01-01', '2025-01-01')"
            )
        conn.close()

    def test_priority_check_constraint_rejects_invalid(self):
        conn = db_mod.get_conn()
        with pytest.raises(sqlite3.IntegrityError):
            conn.execute(
                "INSERT INTO decisions (title, priority, created_by, created_at_utc, updated_at_utc) "
                "VALUES ('test', 'urgent', 'user', '2025-01-01', '2025-01-01')"
            )
        conn.close()

    def test_locked_flag_constraint(self):
        conn = db_mod.get_conn()
        with pytest.raises(sqlite3.IntegrityError):
            conn.execute(
                "INSERT INTO decisions (title, locked_flag, created_by, created_at_utc, updated_at_utc) "
                "VALUES ('test', 2, 'user', '2025-01-01', '2025-01-01')"
            )
        conn.close()

    def test_action_type_constraint_rejects_invalid(self):
        conn = db_mod.get_conn()
        conn.execute(
            "INSERT INTO decisions (title, created_by, created_at_utc, updated_at_utc) "
            "VALUES ('test', 'user', '2025-01-01', '2025-01-01')"
        )
        with pytest.raises(sqlite3.IntegrityError):
            conn.execute(
                "INSERT INTO decision_actions (decision_id, action_type, reason_text, created_at_utc, updated_at_utc) "
                "VALUES (1, 'invalid_type', 'reason', '2025-01-01', '2025-01-01')"
            )
        conn.close()
