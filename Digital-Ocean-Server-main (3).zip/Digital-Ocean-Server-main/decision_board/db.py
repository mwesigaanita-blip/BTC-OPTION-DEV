from __future__ import annotations

import os
import sqlite3
import logging
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterator

import dotenv

logger = logging.getLogger(__name__)

_REPO_ROOT = Path(__file__).resolve().parents[1]
dotenv.load_dotenv(_REPO_ROOT / ".env")

# Match multi_agent_system/config.py: inside Docker the persistent volume is
# mounted at /data - falling back to the repo-local ./data would write the DB
# into the container's ephemeral FS and it would never appear on the host.
_IS_DOCKER = Path("/.dockerenv").exists() or os.getenv("CLOUD", "0") == "1"
_DEFAULT_DATA_DIR = Path("/data") if _IS_DOCKER else (_REPO_ROOT / "data")
_DATA_DIR = Path(os.getenv("DATA_DIR", str(_DEFAULT_DATA_DIR))).resolve()
_DATA_DIR.mkdir(parents=True, exist_ok=True)

DB_PATH: Path = Path(
    os.getenv("DECISION_BOARD_DB_PATH", str(_DATA_DIR / "decision_board.sqlite"))
).resolve()


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def get_conn() -> sqlite3.Connection:
    conn = sqlite3.connect(str(DB_PATH), timeout=30)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL;")
    conn.execute("PRAGMA synchronous=NORMAL;")
    conn.execute("PRAGMA foreign_keys=ON;")
    return conn


@contextmanager
def transaction() -> Iterator[sqlite3.Connection]:
    """
    Single-connection atomic block. All writes commit together or roll back
    together.

    Usage:
        with transaction() as conn:
            conn.execute(...)
            conn.execute(...)
    """
    conn = get_conn()
    try:
        conn.execute("BEGIN IMMEDIATE;")
        yield conn
        conn.commit()
    except Exception:
        try:
            conn.rollback()
        except Exception:
            logger.exception("Rollback failed")
        raise
    finally:
        try:
            conn.close()
        except Exception:
            pass


def ensure_tables() -> None:
    with get_conn() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS decisions (
                id                    INTEGER PRIMARY KEY AUTOINCREMENT,
                title                 TEXT NOT NULL,
                description           TEXT NOT NULL DEFAULT '',
                status                TEXT NOT NULL DEFAULT 'ideas'
                                      CHECK(status IN ('ideas','under_review','done')),
                final_outcome         TEXT CHECK(final_outcome IS NULL
                                      OR final_outcome IN ('accepted','rejected','partial','informational')),
                final_summary_reason  TEXT,
                priority              TEXT NOT NULL DEFAULT 'medium'
                                      CHECK(priority IN ('low','medium','high','critical')),
                created_by            TEXT NOT NULL,
                locked_flag           INTEGER NOT NULL DEFAULT 0
                                      CHECK(locked_flag IN (0,1)),
                finalized_at_utc      TEXT,
                finalized_by          TEXT,
                created_at_utc        TEXT NOT NULL,
                updated_at_utc        TEXT NOT NULL
            );
        """)
        conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_decisions_status ON decisions(status);"
        )
        conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_decisions_priority ON decisions(priority);"
        )
        conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_decisions_created_by ON decisions(created_by);"
        )

        conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_decisions_created_at ON decisions(created_at_utc);"
        )
        conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_decisions_updated_at ON decisions(updated_at_utc);"
        )

        conn.execute("""
            CREATE TABLE IF NOT EXISTS decision_actions (
                id                INTEGER PRIMARY KEY AUTOINCREMENT,
                decision_id       INTEGER NOT NULL REFERENCES decisions(id) ON DELETE CASCADE,
                action_type       TEXT NOT NULL DEFAULT 'note'
                                  CHECK(action_type IN ('open','close','adjust','hedge','note','other')),
                instrument_name   TEXT,
                side              TEXT,
                quantity          REAL,
                price_reference   REAL,
                reason_text       TEXT NOT NULL,
                sort_order        INTEGER NOT NULL DEFAULT 0,
                created_at_utc    TEXT NOT NULL,
                updated_at_utc    TEXT NOT NULL
            );
        """)
        conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_actions_decision ON decision_actions(decision_id);"
        )
        conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_actions_created_at ON decision_actions(created_at_utc);"
        )
        conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_actions_updated_at ON decision_actions(updated_at_utc);"
        )

        conn.execute("""
            CREATE TABLE IF NOT EXISTS decision_comments (
                id              INTEGER PRIMARY KEY AUTOINCREMENT,
                decision_id     INTEGER NOT NULL REFERENCES decisions(id) ON DELETE CASCADE,
                author          TEXT NOT NULL,
                comment_text    TEXT NOT NULL,
                created_at_utc  TEXT NOT NULL,
                edited_at_utc   TEXT,
                deleted_flag    INTEGER NOT NULL DEFAULT 0
            );
        """)
        conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_comments_decision ON decision_comments(decision_id);"
        )
        conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_comments_created_at ON decision_comments(created_at_utc);"
        )

        conn.execute("""
            CREATE TABLE IF NOT EXISTS decision_event_log (
                id                  INTEGER PRIMARY KEY AUTOINCREMENT,
                decision_id         INTEGER NOT NULL REFERENCES decisions(id) ON DELETE CASCADE,
                event_type          TEXT NOT NULL,
                actor               TEXT NOT NULL,
                event_payload_json  TEXT NOT NULL DEFAULT '{}',
                created_at_utc      TEXT NOT NULL
            );
        """)
        conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_events_decision ON decision_event_log(decision_id);"
        )
        conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_events_type ON decision_event_log(event_type);"
        )
        conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_events_created_at ON decision_event_log(created_at_utc);"
        )

        conn.commit()

    logger.info("decision_board tables ready (DB: %s)", DB_PATH)
